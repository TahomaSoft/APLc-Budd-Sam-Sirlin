#include "aplc.h"
#include <setjmp.h>
extern jmp_buf aplc_env;
/* ------------- user ------------- */
int i_user[3] = {0, 1, 1};
int
user(struct trs_struct *r, struct trs_struct *_no2, struct trs_struct *a)
{
/* a, class PARAM, is_parm 1 */
/* r, class APARAM, is_parm 1 */
int stmtno;
struct trs_struct trs1; 
union mp_struct mp1, mp2, mp3, mp4; 
union res_struct res0, res1, res2, res3, res4, res5; 
int i0 = 0;/* for singleton indices */
int i1, i2, i3, i4, i5, i6, i7, i8; /* end of declarations */

trs1.type = APLC_UKTYPE;
trs1.alloc_ind = APLC_UNALLOC;

stmtno = 1;
while (stmtno)
 switch(stmtno) {
default: stmtno = 0;
   break;
case 1: stmtno = 1;
aplc_trace("user", 1);
/* asgn shape */
if (a->type == APLC_UKTYPE) aplc_error("undefined value (a) used");
mp3 = a->value;
i3 = aplc_dsfunt(APLC_CIRCLE, APLC_BOOL, a->type);
/* asgn shape val */
/* typesmatch(node, RIGHT) 1, asgn_pass_trs(node) 0 */
/* type(node) i3; type(right) i3*/
aplc_settrs(&trs1, i3, a->rank, a->shape);
i1 = aplc_talloc(&trs1);
mp1 = trs1.value;
for (i2 = 0; i2 < i1; i2++) {
aplc_mp2res(&res4, &mp3, 
(((a->rank == 0) || (a->rank == 1) && (*a->shape ==1) )  ? 0: i2 )
, a->type);
(res2.i = 1);
aplc_circle_res(&res2, &res2, APLC_BOOL, &res4, a->type);
 /* asntchk types unknown or boxed */
aplc_setmp(&res2, &mp1, i2, trs1.type);
}
/* asgn fin */
aplc_detalloc( r);
aplc_assign( r, &trs1);
stmtno = 0;
}
/* -- doprog finish */
/* -- */
return 0;
}

