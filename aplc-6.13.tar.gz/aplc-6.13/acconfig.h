/* acconfig.h - for inclusion in aplc_config.h.in */

#ifndef _APLC_CONFIG
#define _APLC_CONFIG

@TOP@

/* define if we have gnu readline */
#undef HAVE_READLINE

@BOTTOM@

#endif
/* end of acconfig.h - for inclusion in aplc_config.h.in */
