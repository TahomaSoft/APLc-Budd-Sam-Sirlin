/*
	APL compiler

	structures and definitions for code trees.
	tim budd

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_CTREE_H
#define _APLC_CTREE_H

/* parse tree processing modes */
enum pmodes {SHAPE, COMBINE, VALUE, FINISH};

/* types of operations for the code trees */

enum codeops {
  coasgn,	/* assignment */
  castop,	/* cast operator */
  coconst,	/* constants - index into constant tables */
  condop,	/* conditional operation */
  dsfun,	/* dyadic scalar ops */
  deref, 	/* pointer dereference */
  icnst,	/* actual integer constant (not index) */
  idptr,	/* pointer to an identifier, with fields */
  coindex,     /* vector index (L)[(R)] */
  coiptr,	/* index register value */
  coixorgin,	/* index origin */
  cofun,       /* function start */
  cofunarg,    /* function argument */
  cstring,      /* simple string (mon) */
  memptr,	/* memory pointer */
  msfun,	/* monadic scalar ops */
  postinc,	/* postincrement (for pointers) */
  coref,	/* pointer ref */
  resptr,	/* result register pointer */
  tcnst,	/* type constant */
  trsptr,	/* type/rank/shape register pointer */
  trsvptr 	/* trs.value pointer */
};

enum tfields { ctypefield, crankfield, cshapefield, cvalfield };

typedef struct codetree {
  enum codeops cop;
  union {
    struct codetree *cleft;
    int cindex;
    char *cident;
  } c0;
  union {
    struct codetree *cright;
    enum tfields ctfield;
  } c1;
  union {
    int ctype;
    enum sfuns csfun;
    struct codetree *cmiddle;
  } c2;
} codetree_t;

#endif
/* end of ctree.h */
