/*
	APL Compiler

	switchbox - control transfer for code generation
	tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

# include <stdio.h>
# include "parse.h"
# include "y_tab.h"
# include "gen.h"

/* sws  extra printout for debugging  */
#define SDEBUG 0



/* function to coordinate code generation */
void 
switchbox(struct node *node, enum pmodes mode, int top)
{

#if SDEBUG
  /*printf("\nswitch: nodetype %d\n",node->nodetype);*/
  fprintf(stderr,"switch: nodetype %d %s, mode %d, top %d\n", 
	  node->nodetype, prtoken(node->nodetype), mode, top);
#endif

    switch(node->nodetype) {
    default:
      fprintf(stderr,"unknown node in switch box %d\n",
	      node->nodetype);
      exit(1);
      break;

    case ASSIGN:
      genassign(node, mode, top);
      break;

    case AVEC:
      genavec(node, mode, top);
      break;

    case TCAV:
      gentcav(node, mode, top);
      break;

    case TYPECON:
      gentypecon(node, mode, top);
      break;

    case QUAD:
      genquad(node, mode, top);
      break;

    case QQUAD: 
      genqquad(node, mode, top);
      break;

    case DQUAD: 
      fprintf(stderr,"[switchbox] dbox or \n ");
    case DQQUAD:
      fprintf(stderr,
	      "[switchbox] dqquad not implemented yet\n ");
      exit(1);
      break;

    case QQUADASSIGN: 
      genqquad_assign(node, mode, top);
      break;

    case QUADASSIGN:
      genqassign(node, mode, top);
      break;

    case DQUADASSIGN: 
      fprintf(stderr,"[switchbox] dboxas,\n ");
    case DQQUADASSIGN:
      fprintf(stderr, "[switchbox] dqboxas not implemented yet\n ");
      exit(1);
      break;

    case BOX:
      genbox(node, mode, top);
      break;

    case CAT:
      gencat(node, mode, top);
      break;

    case RESHAPEX:
      /*gencat(node, mode, top);*/
      /*error("[gen] catx not done yet");*/
      genreshapex(node, mode, top);
      break;

    case LINK:
      genlink(node, mode, top);
      break;

    case CATCH:
      gencatch(node, mode, top);
      break;

    case CISCALAR:
      genciscalar(node, mode, top);
      break;

    case CIVEC:
      gencivec(node, mode, top);
      break;

    case COLLECT:
    case CVEC:
      gencollect(node, mode, top);
      break;

    case CCOLLECT:
      genccollect(node, mode, top);
      break;

    case COMMENT:
      break;

    case COMPRESS:
      gencompress(node, mode, top);
      break;

    case CSCALAR:
      gencscalar(node, mode, top);
      break;

    case DEAL:
      gendeal(node, mode, top);
      break;

    case DECODE:
    case INNERCHILD:
      gendecode(node, mode, top);
      break;

    case DFORMAT:
    case INDEXFN:
    case MATCH:
    case MSOLVE:
      gendfun(node, mode, top);
      break;

    case DOMINO:
    case EXECUTE:
    case FORMAT:
    case UNBOX:
      genmfun(node, mode, top);
      break;

    case GWDROP:
      gengwdrop(node, mode, top);
      break;

    case DROP:
      gendrop(node, mode, top);
      break;

    case DSFUN:
      gendsfun(node, mode, top);
      break;

    case DTRANS:
      gendtrans(node, mode, top);
      break;

    case EPSILON:
      genmember(node, mode, top);
      break;

    case EMPTSEMI:
      genempt(node, mode, top);
      break;

    case ENCODE:
      genencode(node,mode,top);
      break;

    case EXPAND:
      genexpand(node, mode, top);
      break;

    case APPLY:
      genapplyfun(node, mode, top);
      break;

    case COND:
      gencond(node, mode, top);
      break;

    case FIDENT:
      genfun(node, mode, top);
      break;

    case OPIDENT:
      genop(node, mode, top);
      break;

    case ASYSVAR:
      genasysvar(node, mode, top);
      break;

    case SYSVAR:
      /* optype = (enum sysvars) node->optype;*/
      gensysvar(node, mode, top);
      break;

    case GO:
      gengo(node, mode, top);
      break;

    case ICON: 
    case BCON: 
    case RCON: 
    case SCON: 
    case FNCON:
      genconst(node, mode, top);
      break;

    case ZCON:
    case QCON:
    case OCON:
      genconst_trs(node, mode, top);
      break;
      
    case LCON:
      /* treat labels specially */
      genlabel(node, mode, top);
      break;

    case IDENT:
      genident(node, mode, top);
      break;

    case INDEXOF:
      genindexof(node, mode, top);
      break;

    case INNER:
      geninner(node, mode, top);
      break;

    case IOTA:
      geniota(node, mode, top);
      break;

    case LAM:
      fprintf(stderr,
	      "[switchbox] laminate not implemented yet\n ");
      exit(1);
      break;

    case MSFUN:
      genmsfun(node, mode, top);
      break;

    case DSYSFUN: 
      gendfun(node, mode, top);
      break;

    case ESYSFUN: 
      if (LEFT != NILP)
	gendfun(node, mode, top);
      else
	genmfun(node, mode, top);
      break;

    case MSYSFUN:
      if ( node->optype==SYS_FREE )
	if (RIGHT->nodetype != IDENT)
	  error("[gen] .bxfree: ident right argument required");
	else
	  genmfun_free_ident(node,mode,top);
      else if ( (node->optype==SYS_VTYPE) && (RIGHT->nodetype==IDENT) )
	genmfun_type_ident(node,mode,top);
      else
	genmfun(node, mode, top);
      break;

    case OUTER:
      genouter(node, mode, top);
      break;

    case RAVEL:
      genravel(node, mode, top);
      break;

    case REDUCE:
      genred(node, mode, top);
      break;

    case RESHAPE:
      genreshape(node, mode, top);
      break;

    case REVERSE:
      genreverse(node, mode, top);
      break;

    case RHO:
      genrho(node, mode, top);
      break;

    case RHORHO:
      genrrho(node, mode, top);
      break;

    case ROLL:
      genroll(node, mode, top);
      break;

    case ROTATE:
      genrotate(node, mode, top);
      break;

    case SCAN:
      genscan(node, mode, top);
      break;

    case SM:
      gensemi(node, mode, top);
      break;

    case SORT:
      gensort(node, mode, top);
      break;

    case SUB:
      gensub(node, mode, top);
      break;

    case SUBASSIGN:
      gensubassign(node, mode, top);
      break;

    case GWTAKE:
      gengwtake(node, mode, top);
      break;

    case TAKE:
      gentake(node, mode, top);
      break;

    case TRANS:
      gentrans(node, mode, top);
      break;
    }
#if SDEBUG
    /*fprintf(stderr,"switch: done\n"); */
    fprintf(stderr,"switch: nodetype %d %s, mode %d, top %d done.\n", 
	    node->nodetype, prtoken(node->nodetype), mode, top);
#endif
}

/* end of switch.c */
