/*
	APL Compiler

	New parse tree functions for array input
	Samuel W.  Sirlin (sws)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.

*/
#include <stdio.h>
#include <string.h>

#include "parse.h"
#include "ptree.h"
#include "y_tab.h"

/* externals from yacc */
extern void prog(struct headnode * head, struct statenode * code);
extern void yyerror(char *c);

/* local functions */
static void show_ivec(int *s, int r);

static void show_shapes(struct node *x, char *n);
static void show_status(struct node *x);
static void show_status_exp(struct node *x);

static int isIorB(int type);
static void shiftcon(int type, int n, int start, int end);
static void mvcon(int otype, int type, int ostart, int oend, int nstart);
static int node_type(int type);

/* > 0 for debugging prints */ 
#define ARdebug 2

#if ARdebug > 1
static void pr_ivec(int *s, int r, char *c);
static void pr_rvec(double *s, int r, char *c);

static void show_rvec(double *s, int r);

static void show_consts(void);
#endif

/* string arrays:

shape 1,2
('aa'
)

shape 2,3
('aaa'
'bbb')

shape 1,2,3
('aaa'
'bbb'
)

shape 2,2,3
('aaa'
'bbb'

'ccc'
'ddd')

shape 3,2,3
('aaa'
'bbb'

'ccc'
'ddd'

'ddd'
'fff')


*/ 
/* storage of information on char strings */
/* indication if we're in the middle of a string array */
/*static int building_str = 0;*/
static int building_array = 0;
/* save first last axis length for checking */
static int len_check;
/* count nl's between strings */
static int nl_count = 0;

/* numeric stuff */
static int itemp[MAXCONSTS];

/* for expression arrays 
   need nl_count, rank, shape
static int shape_ptr;
   
*/

#if ARdebug > 1
static void
pr_ivec(int *s, int r, char *c)
{
  fprintf(stderr,"%s = ",c);
  show_ivec(s,r);
  fprintf(stderr,"\n");
}

static void
pr_rvec(double *s, int r, char *c)
{
  fprintf(stderr,"%s = ",c);
  show_rvec(s,r);
  fprintf(stderr,"\n");
}
#endif

static void
show_ivec(int *s, int r)
{
  int i;

  fprintf(stderr,"[");
  for (i=0; i<r; i++)
    fprintf(stderr," %d", s[i]);
  fprintf(stderr,"]");
}

#if ARdebug > 1
static void
show_rvec(double *s, int r)
{
  int i;

  fprintf(stderr,"[");
  for (i=0; i<r; i++)
    fprintf(stderr," %g", s[i]);
  fprintf(stderr,"]");
}
#endif

static void
show_shapes(struct node *x, char *n)
{
  fprintf(stderr, "%s rank %d, shape ", n, x->n.rank);
  if (x->n.rank)
    show_ivec( &iconsts[x->n.shape], x->n.rank);
  fprintf(stderr, "\n");
}

static void
show_status(struct node *x)
{
  fprintf(stderr, "nl_count %d\n", nl_count);
  fprintf(stderr, "type %d, ", x->n.type);
  show_shapes(x,"current");
}

static void
show_status_exp(struct node *x)
{
  fprintf(stderr, "nl_count %d\n", x->ptr0);
  fprintf(stderr, "type %d, ", x->n.type);

  /*show_shapes(x,"current");*/
  fprintf(stderr, "current rank %d, shape ", x->n.rank);
  if (x->n.rank)
    show_ivec( x->ip, x->n.rank);
  fprintf(stderr, "\n");
  return;
}

#if ARdebug > 1
static void
show_consts(void)
{
  int i,k;

  pr_ivec(iconsts, ictop, "ic");
  pr_rvec(rconsts, rctop, "rc");

  fprintf(stderr,"zc = [");    
  for (i=0; i<zctop; i++) {
    fprintf(stderr,"(");    
    for (k=0; k<2; k++)
      fprintf(stderr," %g ",zconsts[k][i]);
    fprintf(stderr,")");    
  }
  fprintf(stderr,"]\n");    
}
#endif

/* ----------------------------------------------- */

/* start a string array 
   - we know the rank is at least 2 */
extern struct node *
ptsta(char *chars)
{
  struct node *x;
  int len;

  x = newnode(SCON);
  x->n.type = (int) APLC_CHAR;
  len = slen(chars);
  len_check = len;
  x->n.shape = addicon(1);
  addicon(len);
  x->n.rank = 2; /* at least an array */
  x->n.size = len;
  x->n.values = slen(sconsts);/* starting point */
  x->n.info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN |
	      SHAPEKNOWN | VALUESKNOWN);
  if (strlen(chars) + strlen(sconsts) > MAXCONSTS)
    yyerror("too many string constants(1)");
  strcat(sconsts, chars);
  building_array = 1;
  nl_count = 1;

#if 0
  free(chars);/* was built with strdup */ 
#endif
#if ARdebug >0
  fprintf(stderr,"[ptsta] len %d, [%s]\n",len, chars);
#endif
  return (x);
}

/* add a string to a string array 
   - update new_shape */
extern struct node *
addsta(struct node *x, char *chars)
{
  int len, new_rank;
  int i;

#if ARdebug >0
  show_status(x);
#endif
  len = slen(chars);
  /* check len against last axis */
  if (len !=  len_check) {
    fprintf(stderr,"[addsta] current shape ");
    show_ivec( &iconsts[x->n.shape], x->n.rank);
    fprintf(stderr,", new length %d\n", len);
    yyerror("shape error");    
  }
  if (strlen(chars) + strlen(sconsts) > MAXCONSTS)
    yyerror("too many string constants(2)");
  strcat(sconsts, chars);

  /* consider nl's before this */
  new_rank = nl_count+1;
  if (new_rank > x->n.rank) {
    /* at least 1 new axis */
    while (new_rank > x->n.rank) { 
      addicon(1);
      for (i=x->n.rank; i>0; i--)
	iconsts[x->n.shape +i] = iconsts[x->n.shape + i-1];
      iconsts[x->n.shape] = 1;
      x->n.rank++;  
    }
    iconsts[x->n.shape]++;
  } else if (new_rank == x->n.rank) {
    /* increment current shape */
    iconsts[x->n.shape]++;
  }
  /* else lesser shape; already done */

  nl_count = 0;
#if 0
  free(chars);/* was built with strdup */ 
#endif
#if ARdebug >0
  fprintf(stderr,"[addsta] len %d, [%s]\n",len, chars);
#endif
  return x;
}

/* add an nl to a string array */  
extern struct node *
addstanl(struct node * x)
{
  nl_count++;
#if ARdebug >0
  fprintf(stderr,"[addstanl] count %d\n", nl_count);
#endif
  return x;
}

/* finish a string array */
extern struct node *
finsta(struct node *x)
{
  building_array = 0;
  update_info_size(&(x->n));
#if ARdebug >0
  fprintf(stderr,"[finsta]\n");
  show_status(x);
#endif
  return x;
}

/* ----------------------------------------------- */
/* extra for numeric arrays */
/*static int vec_type = 0;*/

/* start a numeric array 
   - we know the rank is at least 2 
   - must have called ptvec() just before this 
   - ptvec() only builds shape vector for >1 elements
*/
extern struct node *
pt_na(struct node *x)
{
  if (x->n.size==1) {
    x->n.shape = addicon(1);
#if ARdebug >0
    fprintf(stderr,"[pt_na] adding shape vector\n");
#endif
  }

  len_check = iconsts[x->n.shape];
  x->n.rank = 2; /* at least an array */
  addicon(len_check);
  iconsts[x->n.shape] = 1;
  /* shape is now (1, len_check) */
  building_array = 1;
  nl_count = 1;
  x->n.size = len_check;
#if ARdebug >0
  fprintf(stderr,"[pt_na] type %d, len %d\n",x->n.type, len_check);
#endif
  return (x);
}

/* ----------------------------------------------- */

static int
isIorB(int type)
{
  return (type==APLC_INT) || (type == APLC_BOOL);
}


/* shift const[type] from start to top by n  
   - open up space to insert other stuff
   - don't increment top
   - numeric type only */
static void
shiftcon(int type, int n, int start, int end)
{
  int i,j;

  if (end > MAXCONSTS) {
    fprintf(stderr, "[shiftcon] type %d\n", type);
    error("too many constants(1)");
  }
  switch(type) {
  default:
    yyerror("[shiftcon] bad type for shift");
    break;
  case APLC_BOOL:
  case APLC_INT:
    for (i=end; i>= start; i--)
      iconsts[i+n] = iconsts[i];
    break;
  case APLC_REAL:
    for (i=end; i>= start; i--)
      rconsts[i+n] = rconsts[i];
    break;
  case APLC_COMPLEX:
    for (i=end; i>= start; i--)
      for (j=0; j<2; j++)
	zconsts[j][i+n] = zconsts[j][i];
    break;
  case APLC_QUAT:
    for (i=end; i>= start; i--)
      for (j=0; j<4; j++)
	qconsts[j][i+n] = qconsts[j][i];
    break;
  case APLC_OCT: 
    for (i=end; i>= start; i--)
      for (j=0; j<8; j++)
	oconsts[j][i+n] = oconsts[j][i];
    break;
  }
  return;
}

/* move a set of constants from one type to a larger type 
   - increment new top
   - decrement old top
 */  
static void
mvcon(int otype, int type, int ostart, int oend, int nstart)
{
  int i,j,k, n, nend;

  n = 1+oend-ostart;
  nend = nstart + n - 1;
  if ((n+nstart) > MAXCONSTS) {
    fprintf(stderr, "[mvcon] type %d\n", type);
    error("too many constants(2)");
  }
  switch(type) {
  default:
    yyerror("[mvcon] bad type");
    break;

  case APLC_BOOL:
  case APLC_INT:
    yyerror("[mvcon] bad type to int");
    break;

  case APLC_REAL:
    switch(otype) {
    default:
      yyerror("[mvcon] bad type to real");
      break;
    case APLC_BOOL:
    case APLC_INT:
      rctop +=n;
      ictop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--)
	rconsts[j] = iconsts[i];
      break;
    }
    break;

  case APLC_COMPLEX:
    switch(otype) {
    default:
      yyerror("[mvcon] bad type to complex");
      break;
    case APLC_BOOL:
    case APLC_INT:
      zctop +=n;
      ictop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	zconsts[0][j] = iconsts[i];
	for (k=1; k<2; k++)
	  zconsts[k][j] = 0.0;
      }
      break;
    case APLC_REAL:
      zctop +=n;
      rctop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	zconsts[0][j] = rconsts[i];
	for (k=1; k<2; k++)
	  zconsts[k][j] = 0.0;
      }
      break;
    }
    break;

  case APLC_QUAT:
    switch(otype) {
    default:
      yyerror("[mvcon] bad type to quat");
      break;
    case APLC_BOOL:
    case APLC_INT:
      qctop +=n;
      ictop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	qconsts[0][j] = iconsts[i];
	for (k=1; k<4; k++)
	  qconsts[k][j] = 0.0;
      }
      break;
    case APLC_REAL:
      qctop +=n;
      rctop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	qconsts[0][j] = rconsts[i];
	for (k=1; k<4; k++)
	  qconsts[k][j] = 0.0;
      }
      break;
    case APLC_COMPLEX:
      qctop +=n;
      zctop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	for (k=0; k<2; k++)
	  qconsts[k][j] = zconsts[k][i];
	for (k=2; k<4; k++)
	  qconsts[k][j] = 0.0;
      }
      break;
    }
    break;

  case APLC_OCT: 
    switch(otype) {
    default:
      yyerror("[mvcon] bad type to oct");
      break;
    case APLC_BOOL:
    case APLC_INT:
      octop +=n;
      ictop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	oconsts[0][j] = iconsts[i];
	for (k=1; k<8; k++)
	  oconsts[k][j] = 0.0;
      }
      break;
    case APLC_REAL:
      octop +=n;
      rctop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	oconsts[0][j] = rconsts[i];
	for (k=1; k<8; k++)
	  oconsts[k][j] = 0.0;
      }
      break;
    case APLC_COMPLEX:
      octop +=n;
      zctop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	for (k=0; k<2; k++)
	  oconsts[k][j] = zconsts[k][i];
	for (k=2; k<8; k++)
	  oconsts[k][j] = 0.0;
      }
      break;
    case APLC_QUAT:
      octop +=n;
      qctop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	for (k=0; k<4; k++)
	  oconsts[k][j] = qconsts[k][i];
	for (k=4; k<8; k++)
	  oconsts[k][j] = 0.0;
      }
      break;
    }
    break;
  }
  return;
}

static int
node_type(int type)
{
  int n = 0;

  switch(type) {
  default:
    break;
  case APLC_BOOL:
  case APLC_INT:
    n = ICON;
    break;
  case APLC_REAL:
    n = RCON;
    break;
  case APLC_COMPLEX:
    n = ZCON;
    break;
  case APLC_QUAT:
    n = QCON;
    break;
  case APLC_OCT: 
    n = OCON;
    break;
  }
  return n;
} 


/* add an nvec to a numeric array 
   - update new_shape */
extern struct node *
add_na(struct node *x, struct node *new)
{
  int len, maxtype;
  int i;
  int oend, end;
  int new_rank;

#if ARdebug >0
  fprintf(stderr,"[add_na]-\n");
  show_status(x);
#endif
  len = new->n.size;

  /* check len against last axis */
  if (len !=  len_check) {
    fprintf(stderr,"[add_na] current shape ");
    show_ivec( &iconsts[x->n.shape], x->n.rank);
    fprintf(stderr,", new length %d\n", len);
    yyerror("shape error");    
  }
  /* if new was a vector, drop shape */
  if (new->n.rank)
    ictop--; 
  /* join the data; types may not match
     note shapes tricky */
  /* get max type */
  maxtype = max(x->n.type, new->n.type);
#if ARdebug >0
  fprintf(stderr," types %d =  %d,%d\n", maxtype, 
	  x->n.type, new->n.type );
  show_status(x);
  show_shapes(new," new");
#endif
  /* if x is an int/bool
        need to shift
        if new is int/bool
           have 
	     (new scalar)
	     (x.val,x.shape,new.val)->(x.val,new.val,x.shape)
	     (new vector)
             (x.val,x.shape,new.val,new.shape)->(x.val,new.val,x.shape)
        else
           shift new
           promote x
           shift x.shape
           promote node
     if types not equal
        if xtype > newtype
           promote new
        else 
           shift new
           promote x        
           promote node
   */
  if ( isIorB(x->n.type) ) {
    if ( isIorB(new->n.type) ) {
      /* have (x.val,x.shape,new.val,new.shape)->
	      (x.val,new.val,x.shape) */
      /* save x shape */
      for (i=0; i<x->n.rank; i++)
	itemp[i] = iconsts[x->n.shape+i];
      /* copy new values to x shape */
      for (i=0; i<len; i++) 
	iconsts[x->n.shape+i] = iconsts[new->n.values+i];
#if 0
      show_ivec(&iconsts[x->n.values], x->n.size+len);
      fprintf(stderr,"\n");
#endif
      new->n.values = x->n.shape;/* temp */
      end = x->n.values + x->n.size + len;
      /* put the shape back, unchanged */
      for (i=0; i<x->n.rank; i++)
	iconsts[end+i] = itemp[i];
      /* reset pointer to x shape */
      x->n.shape = end;
      /* ensure we have the max type */
      if (new->n.type > x->n.type) {
	x->n.type = new->n.type;
	/* promote node type */
	x->nodetype = node_type(x->n.type);
      }
    } else {
      /* int -> larger */
#if ARdebug > 1
      show_consts();
#endif
      /* shift new up by size of x */
      end = new->n.values + new->n.size;
      shiftcon(new->n.type, x->n.size, new->n.values, end);
      /* promote x from int to new, before new */ 
      oend = x->n.values + x->n.size - 1;
      mvcon(x->n.type, new->n.type, x->n.values, oend, new->n.values);
      /* show_consts();*/
      /* shift x shape down to where x was */
      for (i=0; i<x->n.rank; i++)
	iconsts[x->n.values+i] = iconsts[x->n.shape+i];
      x->n.shape = x->n.values;
      x->n.values = new->n.values;
      x->n.type = new->n.type;
      /* promote node type */
      x->nodetype = node_type(x->n.type);
    }
  } else if (x->n.type != new->n.type) {
    if (x->n.type > new->n.type) {
      /* x > new */
      /*      pr_ivec(iconsts, ictop, "ic0");
	      pr_rvec(rconsts, rctop, "rc0");*/
      oend = new->n.values + new->n.size - 1;
      end = x->n.values + x->n.size;
      mvcon(new->n.type, x->n.type, new->n.values, oend, end);
      /*      pr_ivec(iconsts, ictop, "ic1");
	      pr_rvec(rconsts, rctop, "rc1");*/
    } else {
      /* new > x */
#if ARdebug > 1
      show_consts();
#endif
      /* shift new by size of x */
      end = new->n.values + new->n.size;
      shiftcon(new->n.type, x->n.size, new->n.values, end);
      /* promote x to new, before new */ 
      oend = x->n.values + x->n.size - 1;
      mvcon(x->n.type, new->n.type, x->n.values, oend, new->n.values);
      /*show_consts();*/
      x->n.values = new->n.values;
      x->n.type = new->n.type;
      /* promote node type */
      x->nodetype = node_type(x->n.type);
    }
  }
  /* get rid of new */
#if 0
  free(new);
#endif
  /* consider nl's before this */
  new_rank = nl_count+1;
  if (new_rank > x->n.rank) {
    /* at least 1 new axis */
    while (new_rank > x->n.rank) { 
      addicon(1);
      for (i=x->n.rank; i>0; i--)
	iconsts[x->n.shape +i] = iconsts[x->n.shape + i-1];
      iconsts[x->n.shape] = 1;
      x->n.rank++;  
    }
    iconsts[x->n.shape]++;
  } else if (new_rank == x->n.rank) {
    /* increment current shape, along first axis */
    iconsts[x->n.shape]++;
  }
  /* else lesser shape; already done */

  x->n.size += len;
  nl_count = 0;

#if ARdebug >0
  fprintf(stderr,"[add_na]+ len %d\n",len);
  show_status(x);
#endif
  return x;
}

/* add an nl to a numeric array */  
extern struct node *
add_nanl(struct node * x)
{
  nl_count++;
#if ARdebug >0
  fprintf(stderr,"[add_nanl] count %d\n", nl_count);
#endif
  return x;
}

/* finish a numeric array */
extern struct node *
fin_na(struct node *x)
{
  building_array = 0;
  update_info_size(&(x->n));
#if ARdebug >0
  fprintf(stderr,"[fin_na]\n");
  show_status(x);
#endif
  return x;
}

/* ----------------------------------------------- */
/* extra for expression arrays */

/* start */
extern struct node *
pt_expa(struct node *node)
{
  struct node *x;
 
#if ARdebug >0
  fprintf(stderr,"[pt_expa]\n");
  fprintf(stderr,"node: %s\n", prtoken(node->nodetype));
  print_info(stderr, &(node->n));  fprintf(stderr,"\n");
  /*fprintf(stderr,"right: \n");
  print_info(stderr, &(RIGHT->n));*/
#endif

#if ARdebug >0
  fprintf(stderr,"[pt_expa] adding shape vector\n");
#endif
  x = pt1(RESHAPEX, node);
  x->n.rank = 2; /* at least an array */
  x->ip = Imalloc(x->n.rank);
  if (! x->ip)
    yyerror("[pt_expa] malloc failed!");
  x->ip[0] = 1;
  x->ip[1] = 0;
  /* shape is now (1, 0) */
  building_array = 1;
  /*nl_count = 1;*/
  x->ptr0 = 1;/* use this for nl_count */
  x->n.size = 0;
#if ARdebug >0
  fprintf(stderr,"[pt_expa]+\n");
  fprintf(stderr," x: ");
  print_info(stderr, &(x->n));
  fprintf(stderr,"\n ");
  show_status_exp(x);

  fprintf(stderr,"ip %p\n",x->ip);
#endif

  /*return node;*/
  return x;
}

/* add an expression to a expression array 
   - update new_shape */
extern struct node *
add_expa(struct node *x, struct node *new)
{
  int new_rank;
  int i, rd;
  int *iptemp;

#if ARdebug >0
  fprintf(stderr,"[add_expa]-\n");
  fprintf(stderr,"ip %p\n",x->ip);
  show_status_exp(x);
  fprintf(stderr," x: {");
  print_info(stderr, &(x->n));
  fprintf(stderr,"}\n new: {");
  print_info(stderr, &(new->n));
  fprintf(stderr,"}\n x-status: {\n ");
  show_status_exp(x);
  fprintf(stderr,"}\n");
#endif
  
  /*return pt2a(CAT,NULL, FIRSTAXIS, x, new);*/
  x->right = pt2a(CAT,NILP, FIRSTAXIS, x->right, new);

  /* consider nl's before this */
  new_rank = x->ptr0 + 1;
  if (new_rank > x->n.rank) {
    /* at least 1 new axis 
       have new_rank-x->n.rank (1)
    */
    rd = new_rank - x->n.rank;
#if 1
    fprintf(stderr,"[malloc: %d]", new_rank);
#endif
    /* create a new shape vector */
    iptemp = Imalloc(new_rank);
    if (! iptemp)
      yyerror("[add_expa] malloc failed!");
    /* copy the old shape vector onto the end 
       start with 1's */
    for (i=0; i < new_rank; i++)
      if (i >= rd)
	iptemp[i] = x->ip[i-rd];
      else
	iptemp[i] = 1;
    x->n.rank = new_rank;
    iptemp[0]++;
#if 0
    free(x->ip);
#endif
    x->ip = iptemp;
  } else if (new_rank == x->n.rank) {
    /* increment current shape, along first axis */
    (x->ip[0])++;
  }
  /* else lesser shape; already done */

  x->ptr0 = 0;

#if ARdebug >0
  fprintf(stderr,"[add_expa]+ \n");
  show_status_exp(x);
  
#endif
  return x;
}

/* add an nl to an expression array */  
extern struct node *
add_expanl(struct node * x)
{
  x->ptr0++;
#if ARdebug >0
  fprintf(stderr,"[pt_expa_nl] count %d\n", x->ptr0);
#endif
  return x;
}

extern struct node *
fin_expa(struct node * x)
{
  int i;

  building_array = 0;
#if ARdebug >0
  fprintf(stderr,"[fin_expa] \n");
  show_status_exp(x);
#endif
#if 1
  /* copy new shape to new left CIVEC */
  x->left = newnode(CIVEC);
  x->left->n.rank = 1;
  x->left->n.shape = x->n.rank;/* temp */
  ptvec(x->left, CIVEC, APLC_INT);
  x->left->n.info |= (TYPEDECL | RANKDECL | RANKKNOWN | SHAPEKNOWN | VALUESKNOWN);

  x->left->right = newnode(ICON);
  x->left->right->n.rank = 1;
  x->left->right->n.shape = x->n.rank;/* temp */
  ptvec(x->left->right, ICON, APLC_INT);
  x->left->right->n.info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN |
      SHAPEKNOWN | VALUESKNOWN);
  x->left->n.values = ictop;/* same as right */
  x->left->right->n.values = ictop;
  for (i=0; i < x->n.rank; i++)
    addicon(x->ip[i]);
#endif
#if 0
  /* copy new shape to integer constants */
  x->n.shape = ictop;
  for (i=0; i < x->n.rank; i++)
    addicon(x->ip[i]);
#endif
#if 0
  free(x->ip);
#endif
  return x;
}

/* end */

