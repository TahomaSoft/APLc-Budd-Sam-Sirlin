/*
	apl compiler
		intra-procedural dataflow analysis
		timothy a. budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever


 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include <stdio.h>
#include "parse.h"
#include "y_tab.h"
#include "nutil.h"
#include "util2.h"
#include "trs.h"


/* sws for debugging */
/* level can be 0, 1, 2 
*/
#define IDEBUG 0

extern void error(char *);

/* global variables */
static int nbranchto;
static int branchto[MAXSTMTS];

/* current symbol */
static struct symnode *currentlist;
/* copy of global symbol table */
static struct symnode *symtab;

/* ---------------------------------------------- */
/* local function declarations */

static void finish_symb(struct symnode *syms);

static struct symnode *makelist(struct symnode * syms);
static struct symnode *getsinfo(char *name);

int update_shape(info_t *s1, info_t *s2);
int update_shape_strict(info_t *s1, info_t *s2);

int mrgrank(int t1, int t2);
int update_rank(info_t *s1, info_t *s2);
int update_rank_strict(info_t *s1, info_t *s2);

static int is_type(int t);
static int is_num_type(int t);
int mrgtype(int t1, int t2);
int update_type(info_t *s1, info_t *s2);

int merge(struct symnode * list1, int up1, struct symnode * list2,
    int up2);

void doassign(char *name, struct node * node);
void doident(struct node * node);
void dolcon(struct node * node);

static void dodecl(struct node * node);
static void doinit(struct node *node);
static void doinf_reinit(struct node *node, int top);


#if IDEBUG
/* print out rank */
static void 
prrank(FILE *f, int n)
{
  if (n==NORANK)
    fprintf(f,"(no rank (%d))",n);
  else if(n==ANYRANK)
    fprintf(f,"(any rank (%d))",n);
  else
    fprintf(f,"%d",n);
}
#endif

/* main run routine called from pass */
void
doprog(int type, struct headnode * head, struct symnode * syms,
       struct statenode * code)
{
  struct statenode *s, *s2;
  struct statenode *vs[MAXSTMTS];
  int countstmts = 0;
  int newstate, i, j;

  symtab = syms;/* sws do we need this copy? - probably just for names*/
#if IDEBUG
  if (head->fname == (char *) 0)
    fprintf(stderr, "\n>>[intra] main\n");
  else
    fprintf(stderr, "\n>>[intra] %s\n", head->fname);
  fprintf(stderr, "starting symbol table\n");
  print_symtab(stderr, syms);
#endif

  /* associate a copy of the symbol table with each statement 
     count the statements 
     and make a statlist vector */
  for (s = code, i=0; s != NILSTATE; s = s->nextstate, i++) {
    countstmts++;
    s->list = makelist(syms);
    vs[i] = s;
  }
  /* make a copy of the symbol table corresponding to the cursor 
     - initialized to lowest information state */
  currentlist = makelist(syms);

#if IDEBUG
  fprintf(stderr, "starting current symbol table\n");
  print_symtab(stderr, currentlist);
#endif

  /* initialize globals, fns to any */
  for (s = code, stmtno=1; s != NILSTATE; s = s->nextstate, stmtno++) {
    /* march through the nodes */
    doinit(s->code);
  }

  /* this step is necessary to catch params, globals, and declarations 
     - merge the curentlist with the real symbol table */
  merge(currentlist, 1, syms, 0);

  /*- now march through the code, updating the cursor, and
      make the local versions into the most general form known */
#if IDEBUG
  fprintf(stderr, "\n[intra] update local symbol tables");
#endif
  stmtno = 1;
  s = code;
  while (s != NILSTATE) {

#if IDEBUG
    /*fprintf(stderr, "\n[%d]", stmtno);*/
    fprintf(stderr, "\n--------------------\n");
    fprintf(stderr, "[%d]-------------------\n", stmtno);
#endif

    /* initialize branch list */
    nbranchto = 0;
    for (i = 0; i < countstmts; i++)
      branchto[i] = 0;

    /* merge the two lists as they are; current and local */
    merge(currentlist, 1, s->list, 1);
    /* update current */
    doinf(s->code, 1);
#if IDEBUG > 1
    fprintf(stderr,"\ncurrent symbol table, after doinf\n");
    print_symtab(stderr, currentlist);
    fprintf(stderr, "  ----------\n");
#endif
    /* update the (saved) local list */
    merge(currentlist, 0, s->list, 1);

#if IDEBUG
    /* sws   debugging */
    if (nbranchto > 0) {
      fprintf(stderr, "\n[intra] branchto[%d] = [", stmtno);
      for (i=0; i<nbranchto; i++)
	fprintf(stderr, " %d", branchto[i]);
      fprintf(stderr,"]\n");
    }
#endif

    if (nbranchto > 0) {
      /* there are branches we need to check */
      /* check each branch statement */
      newstate = stmtno + 1;
      for (i = 0; i < nbranchto; i++) {
	j = branchto[i]; 
#if IDEBUG
	fprintf(stderr,"\n[%d] checking branch [%d]",stmtno,j);
#endif	
	/* sws; 
	   note vs is origin 0, branches, statment numbers origin 1 */ 
	s2 = vs[j-1];
	/* update local at the branch point based on current */
	if (merge(currentlist, 0, s2->list, 1) && j < newstate)
	  newstate = j;
      }
      /* now setup next state, at earliest changed branch or next 
	 - need to set s and stmtno */
#if IDEBUG
      fprintf(stderr,"\n[%d]next is [%d]",stmtno,newstate);
#endif
      if (newstate < stmtno) {
	/* check past states - jump back */
	stmtno = newstate;
	s = vs[newstate-1];
      } else {
	/* just march on */
	stmtno++;
	s = s->nextstate;
      }
    } else {
      /* no branches, just march on */
      stmtno++;
      s = s->nextstate;
    }
  }

  /* need to merge what we know into the fn top */
#if IDEBUG 
  fprintf(stderr, "  ----------\n");
  fprintf(stderr,"\ninitial symbol list\n");
  print_symtab(stderr, syms);
#endif
#if IDEBUG > 2
  fprintf(stderr, "  ----------\n", stmtno);
  fprintf(stderr,"current \n");
  print_symtab(stderr, currentlist);
#endif
  /* merge the curentlist with the real symtab */
  merge(currentlist, 0, syms, 1);
#if IDEBUG 
  fprintf(stderr, "  ----------\n");
  fprintf(stderr,">>current symbol list\n");
  print_symtab(stderr, syms);
#endif

  /* now go back through the code, for the purpose of adjusting idents
     - globally known things should become declarations
     */
#if IDEBUG
  fprintf(stderr, "  ----------\n");
  fprintf(stderr,">>[intra] redeclare\n");
#endif
  for (s = code, stmtno=1; s != NILSTATE; s = s->nextstate, stmtno++) {
    /* march through the nodes, just changing idents */
#if IDEBUG
    fprintf(stderr, "  ----------\n");
    fprintf(stderr,"[%d]\n",stmtno);
#endif
    dodecl(s->code);
    /* also redo inferencing */
    doinf_reinit(s->code, 1);
    doinf(s->code, 1);
  }
  finish_symb(syms);
#if IDEBUG
  fprintf(stderr,"\n>>intra done\n");
#endif
}

/* 
  update final symbol, removing typeknown any */
static void
finish_symb(struct symnode *syms)
{
  struct symnode *s;

  for (s=syms; s != NILSYM; s = s->next) {
    if (s->s.info & TYPEKNOWN)
      if (s->s.type == APLC_ANY)
	s->s.info ^= TYPEKNOWN;
  }
  return;
}


/* makelist 
   - generate a copy of the local symbol table list 
   - initialize to lowest information state */
static struct symnode *
makelist(struct symnode *syms)
{
  struct symnode *new, *onew, *syms0;

  syms0 = syms;
  /* first build up a chain the same length (reverse order) */
  new = onew = NILSYM;
  for (; syms != NILSYM; syms = syms->next) {
    new = structalloc(symnode);
    new->s.info = 0;
    new->s.type = APLC_UKTYPE;
    /* still usefull for a while */
    new->s.rank = NORANK;
    /*new->s.rank = 0;*/
    new->s.shape = 0;
    new->s.size = 0;
    new->s.values = 0;
    new->next = onew;
    onew = new;
  }
  /* now add the names */
  syms = syms0;
  for (; syms != NILSYM; syms = syms->next, onew = onew->next) {
    onew->name = syms->name;
  }
  return (new);
}

/* getsinfo - get current symbol table info for a particular name */
static struct symnode *
getsinfo(char *name)
{
  struct symnode *s, *s2;

  for (s = symtab, s2 = currentlist;
      s != NILSYM; s = s->next, s2 = s2->next)
    if (strcmp(s->name, name) == 0) {
      return (s2);
    }
  return (NILSYM);
}

#define SHAPEUNKNOWN(i) ((!(i & SHAPEKNOWN)) && (!(i & SHAPEARB)))

/* 
   possibly update shape information in s1 based on s2
op table 
  U K   A   
U U K   A
K K K/A A
A A A   A */
int 
update_shape(info_t *s1, info_t *s2)
{
  int changed = 0;
  int i, nomat;

  if ( s1->info & SHAPEKNOWN ) {
    if (s2->info & SHAPEKNOWN) {
      if (s1->shape != s2->shape) {
	/* pointers don't match, but shapes still could */
	nomat = 0;
	for (i=0; i<s1->rank; i++)
	  if (iconsts[s1->shape+i] != iconsts[s2->shape+i])
	    nomat = 1;
	if (nomat) {
	  arb_shape_info(s1);
	  changed = 1;
	} else {
	  /* shapes match - make pointers match as well */
	  if (s1->shape < s2->shape)
	    s2->shape = s1->shape;
	  else
	    s1->shape = s2->shape;
	}
      }
    } else if (s2->info & SHAPEARB) {
      arb_shape_info(s1);
      changed = 1;
    }
  } else if ( !(s1->info & SHAPEARB) ) {
    /* shape unknown */
    if (s2->info & SHAPEKNOWN) {
      /*fprintf(stderr,"fix shape to %d\n", s2->shape);*/
      s1->info |= SHAPEKNOWN;
      s1->shape = s2->shape;
      s1->size = s2->size;
      changed = 1;
    }
    if (s2->info & SHAPEARB) {
      /*fprintf(stderr,"break shape\n");*/
      arb_shape_info(s1);
      changed = 1;
    }
  } /* else must be arbitrary already - no change */
  return changed;
}

/* 
   possibly update shape information in s1 based on s2
op table 
  U K   A   
U U K   A
K A K/A A
A A A   A */
int 
update_shape_strict(info_t *s1, info_t *s2)
{
  int changed = 0;
  int i, nomat;

#if IDEBUG >1
  fprintf(stderr,"[update_shape_strict]\n");
#endif
  if ( s1->info & SHAPEKNOWN ) {
    if (s2->info & SHAPEKNOWN) {
      if (s1->shape != s2->shape) {
	/* pointers don't match, but shapes still could */
	nomat = 0;
	for (i=0; i<s1->rank; i++)
	  if (iconsts[s1->shape+i] != iconsts[s2->shape+i])
	    nomat = 1;
	if (nomat) {
	  arb_shape_info(s1);
	  changed = 1;
	} else {
	  /* shapes match - make pointers match as well */
	  if (s1->shape < s2->shape)
	    s2->shape = s1->shape;
	  else
	    s1->shape = s2->shape;
	}
      }
    } else {
      /* s2 not known, force s1 arbitrary  */
      if (! (s1->info & SHAPEARB) ) {
	arb_shape_info(s1);
	changed = 1;
      }
    }
  } else if ( !(s1->info & SHAPEARB) ) {
    /* shape unknown */
    if (s2->info & SHAPEKNOWN) {
      /*fprintf(stderr,"fix shape to %d\n", s2->shape);*/
      s1->info |= SHAPEKNOWN;
      s1->shape = s2->shape;
      s1->size = s2->size;
      changed = 1;
    }
    if (s2->info & SHAPEARB) {
      /*fprintf(stderr,"break shape\n");*/
      arb_shape_info(s1);
      changed = 1;
    }
  } /* else must be arbitrary already - no change */
  return changed;
}

/* 
   mrgrank - find the most general category for a pair of ranks
 */
int
mrgrank(int t1, int t2)
{
  int maxrank;

  if (t1 == t2)
    maxrank = t1;
  else if (t2 == NORANK)
    maxrank = t1;
  else if (t1 == NORANK)
    maxrank = t2;
  else {
    /* two different numerical values */
    maxrank = ANYRANK;
  }
  return maxrank;
}

/* possibly update s1
   op table for max rank 
    U K   A   
 U  U K   A
 K  K K/A A
 A  A A   A */
int 
update_rank(info_t *s1, info_t *s2)
{
  int changed = 0;

  if (s2->info & RANKKNOWN) {
    if ( s1->info & RANKKNOWN ) {
      /* s1 rank already known; must match */
      if (s1->rank != s2->rank) {
	s1->rank = ANYRANK;
	arb_shape_info(s1);
	changed = 1;
      } else {
	/* ranks match; check shapes */
	if (! (s1->rank == ANYRANK) ) {
	  changed = update_shape(s1, s2);
	}
      }
    } else {
      /* s2 known, s1 unknown */
      changed = 1;
      s1->rank = s2->rank;
      s1->info |= RANKKNOWN;
      if (s1->rank == ANYRANK)
	arb_shape_info(s1);
      else
	update_shape(s1, s2);
    }
  }
  return changed;
}

/* possibly update s1
   op table for max rank 
    U K   A   
 U  A K   A
 K  A K/A A
 A  A A   A */
int 
update_rank_strict(info_t *s1, info_t *s2)
{
  int changed = 0;

  if (s2->info & RANKKNOWN) {
    if ( s1->info & RANKKNOWN ) {
      /* s1 rank already known; must match */
      if (s1->rank != s2->rank) {
	s1->rank = ANYRANK;
	arb_shape_info(s1);
	changed = 1;
      } else {
	/* ranks match; check shapes */
	if (s1->rank != ANYRANK) {
	  changed = update_shape_strict(s1, s2);
	}
      }
    } else {
      /* s2 known, s1 unknown */
      changed = 1;
      s1->rank = s2->rank;
      s1->info |= RANKKNOWN;
      if (s1->rank == ANYRANK)
	arb_shape_info(s1);
      else
	update_shape_strict(s1, s2);
    }
  } else {
    /* since s2 isn't known, must make s1 more general */
    if (s1->rank != ANYRANK) {
      changed = 1;
      s1->rank = ANYRANK;
      s1->info |= RANKKNOWN;
      arb_shape_info(s1);
    }
  }
  return changed;
}


/* check for corruption in a type field */
static int
is_type(int t)
{
  int r = 0;

  switch (t) {
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
  case APLC_CHAR:
  case APLC_BOXED:
  case APLC_FNP:
  case APLC_OPP:
  case APLC_ANY:
  case APLC_UKTYPE:
    r = 1;
    break;
  default:
    r = 0;
    break;
  }
  return r;
}


static int
is_num_type(int t)
{
  int r = 0;

  switch(t) {
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    r = 1;
    break;
  default:
    r = 0;
    break;
  }
  return r;
}


#if 0
/* mrgtype 
   - find the most general category for a pair of types 
   - used in merging symbol tables */
int
mrgtype(int t1, int t2)
{
  int mrmaxtype=0;
  /* int errorflag = 0;*/

  /* first check t2 for validity */
  switch (t2) {
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
  case APLC_CHAR:
  case APLC_BOXED:
  case APLC_ANY:
  case APLC_UKTYPE:
    break;
  default:
    fprintf(stderr, "\ntypes are %s(%d) %s(%d)", 
	    str_type_name(t1),t1, str_type_name(t2), t2);
    error("impossible condition in mrgtype");
  }
  if (t1 == t2)
    mrmaxtype = t1;
  else if (t2 == APLC_UKTYPE)
    mrmaxtype = t1;
  else
    switch (t1) {
    case APLC_BOOL:
    case APLC_INT:
      if (t2 == APLC_INT || t2 == APLC_BOOL)
	mrmaxtype = APLC_INT;
      else 
	mrmaxtype = APLC_ANY;
      break;
    case APLC_REAL:
    case APLC_COMPLEX:
    case APLC_QUAT:
    case APLC_OCT:
      /* t2=same case already caught above 
         don't allow anything else for now... */
      mrmaxtype = APLC_ANY;
      break;
    case APLC_CHAR:
    case APLC_BOXED:
      mrmaxtype = APLC_ANY;
      break;
    case APLC_ANY:
      mrmaxtype = APLC_ANY;
      break;
    case APLC_UKTYPE:
      mrmaxtype = t2;
      break;
    default:
      fprintf(stderr, "\ntypes are %s(%d) %s(%d)", 
	      str_type_name(t1),t1, str_type_name(t2), t2);
      error("impossible condition in mrgtype");
    }
#if 0
  if (errorflag)
    error("some error in mrgtype");
#endif
  return (mrmaxtype);
}


#else
/* better inferencing
?   - currently can't make quaternion contain complex,
     as then trouble in assign q .is z
   */
/* mrgtype - find the most general category for a pair of types */
int
mrgtype(int t1, int t2)
{
  int mrmaxtype=0;

  /* first check types for validity */
  if ( !(is_type(t1) && is_type(t2)) ) {
    fprintf(stderr, "\ntypes are %s(%d) %s(%d)", 
	    str_type_name(t1),t1, str_type_name(t2), t2);
    error("impossible condition in mrgtype");
  }

  if (t1 == t2)
    mrmaxtype = t1;
  else if (t1 == APLC_UKTYPE)
    mrmaxtype = t2;
  else if (t2 == APLC_UKTYPE)
    mrmaxtype = t1;
  else {
    if (is_num_type(t1)) {
      if (is_num_type(t2))
	mrmaxtype = max(t1,t2);	
      else
	mrmaxtype = APLC_ANY;
    } else
      mrmaxtype = APLC_ANY;
  }
  return (mrmaxtype);
}
#endif

int
update_type(info_t *s1, info_t *s2)
{
  int changed = 0;
  int maxt = mrgtype(s1->type, s2->type);

  if (s1->type != maxt) {
    changed = 1;
    s1->type = maxt;
    /* we've increased the type, so must be known (could be any) */ 
    s1->info |= TYPEKNOWN;
  }
  return changed;
}

/* merge - merge two symbol table lists together,
     returning 1 if any changes are noted.
     Only update a list if the corresponding ``up'' argument is 1 */

int
merge(struct symnode * list1, int up1, struct symnode * list2, int up2)
{
  int errorflag, changed;
  struct symnode *s;

#if IDEBUG >1
  fprintf(stderr,"[merge]\n");
#endif
  s = symtab; /* ? just used for the name ? */
  changed = errorflag = 0;
  for (; list1 != NILSYM; list1 = list1->next, list2 = list2->next, s=s->next) {
    if (list2 == NILSYM)
      error("impossible merge condition");
#if IDEBUG >1
    /*fprintf(stderr,"%s: t,r = (%d %d) (%d %d)\n",
	    s->name, list1->s.type, list1->s.rank,
	    list2->s.type, list2->s.rank);*/
    fprintf(stderr,"%s: (L1)(%d)", s->name, up1);
    print_info(stderr, &(list1->s));
    fprintf(stderr,"\n  (L2)(%d)", up2);
    print_info(stderr, &(list2->s));
    fprintf(stderr,"\n");
#endif 
    /* type */
    if (up1)
      changed = update_type(&(list1->s), &(list2->s));
    if (up2)
      changed = changed + update_type(&(list2->s), &(list1->s)) ;
    /* rank */
    /* shape */
    /* size */
    if (up1)
      changed = changed + update_rank(&(list1->s), &(list2->s));
    if (up2)
      changed = changed + update_rank(&(list2->s), &(list1->s));
    /* values */
    /* info */

#if IDEBUG >1
    /*fprintf(stderr," + %s, t,r = (%d %d) (%d %d)\n",
	    s->name, list1->s.type, list1->s.rank,
	    list2->s.type, list2->s.rank);*/
    if (changed) {
      fprintf(stderr,"%s+: (L1)", s->name);
      print_info(stderr, &(list1->s));
      fprintf(stderr,"\n  (L2)");
      print_info(stderr, &(list2->s));
      fprintf(stderr,"\n");
    } else {
      fprintf(stderr,"nochange %s+: (L1)", s->name);
      print_info(stderr, &(list1->s));
      fprintf(stderr,"\n  (L2)");
      print_info(stderr, &(list2->s));
      fprintf(stderr,"\n");
    }
#endif	
  }
  return (changed);
}

/* sws  routines called in itrs.c */

/* doassign 
   - update the currentlist (symbol table) in an assignment */
void
doassign(char *name, struct node * node)
{
  struct symnode *s, *s2;
  int chg;

  /* look for name in currentlist - current symbol table */
  for (s = symtab, s2 = currentlist; s != NILSYM; 
       s = s->next, s2 = s2->next)
    if (strcmp(s->name, name) == 0) {
      /* found the name */
#if (IDEBUG > 1)
      fprintf(stderr, "\ndoassign: ");
      fprintf(stderr,"var %s; node: ", name);
      print_info(stderr, &(node->n));
      fprintf(stderr,"\n  current symb: ");
      print_info(stderr, &(s2->s));
#endif 
      if (node->n.info & TYPEKNOWN)
	update_type(&(s2->s), &(node->n));
      else {
	s2->s.info |= TYPEKNOWN;
	s2->s.type = APLC_ANY;
      }
      /*chg = update_rank(&(s2->s), &(node->n));*/
      /* need to be strict here 
	 - if symbol table is more defined than node, then we could 
	 be messing things up */
      chg = update_rank_strict(&(s2->s), &(node->n));

#if (IDEBUG > 1)
      if (chg ) {
	fprintf(stderr, "\n[intra/assign] %s ", name);
	fprintf(stderr, " current symbol table+:");
	print_info(stderr, &(s2->s));
      }
#endif
#if IDEBUG > 1
      fprintf(stderr, "\n symbol table for %s updated to: ", name);
      print_info(stderr, &(s2->s));
#endif
    }
  /*--- sws   for debugging rank inferencing: */
  switch(node->nodetype) {
  default:
    break;
  case ASSIGN:
#if IDEBUG > 1
    s = getsinfo(LEFT->namep);
    if (s) {
      fprintf(stderr, "\n[intra/asign] %s ", LEFT->namep);
      print_info(stderr, &(s->s));
    }
#endif
    /* now see if we can update the ident information */
    doident(LEFT);
    break;
  case SM:
    /* sub asssign store child */
#if IDEBUG > 1
    s = getsinfo(name);
    if (s) {
      fprintf(stderr, "\n[intra/asign] the type of %s is %s(%d)",
	      name, str_type_name(s->s.type),s->s.type);
      fprintf(stderr,"\n[intra/asign] the rank for %s is ",
	      name); prrank(stderr,s->s.rank);
    }
#endif
    break;
  }
  return;
}


/* doident - do trs inferencing on an identifier
   sws   based on code from trs.c 
   - update an ident node  based on symbol table information */
void
doident(struct node * node)
{
  struct symnode *s;
  int chg;

  s = getsinfo(node->namep);
  if (s) {
#if (IDEBUG > 1)
    fprintf(stderr, "\n[intra/doident] ");
    fprintf(stderr,"var %s; node: ", node->namep);
    print_info(stderr, &(node->n));
    /* fprintf(stderr, " node->n.shape = %d\n", node->n.shape);*/
    fprintf(stderr,"\n  current symb: ");
    print_info(stderr, &(s->s));
    /*fprintf(stderr, " s->s.shape = %d\n", s->s.shape);*/
#endif
    if (node->n.info & TYPEKNOWN) {
      /* must have been declared */
      if (s->s.type != APLC_UKTYPE) {
	/* check to see if we should update the type */
	if (node->n.type != s->s.type) {
	  node->n.type = mrgtype(node->n.type, s->s.type);

#if IDEBUG > 1
	  fprintf(stderr,"\n[intra/doident] ");
	  fprintf(stderr,"improving the type for %s to %s(%d)",
		  node->namep, str_type_name(node->n.type),
		  node->n.type);
#endif
	}
      }
    } else if (s->s.type != APLC_UKTYPE) {
      node->n.type = s->s.type;
      node->n.info |= TYPEKNOWN;
#if (IDEBUG > 1)
      fprintf(stderr,"\n[intra/doident] ");
      fprintf(stderr,"inferring the type for %s to %s(%d)",
	      node->namep, str_type_name(node->n.type), node->n.type);
#endif
    }
    chg = update_rank(&(node->n), &(s->s));
#if (IDEBUG > 1)
    if (chg) {
      fprintf(stderr,"\n[intra/doident] ");
      fprintf(stderr,"updating node %s to ", node->namep); 
      print_info(stderr, &(node->n) );
    } else {
      fprintf(stderr,"\n[intra/doident] ");
      fprintf(stderr,"node %s unchanged: ", node->namep); 
      print_info(stderr, &(node->n) );
      fprintf(stderr," symb: ");
      print_info(stderr, &(s->s) );
    }
#endif 
  }
  return;
}

/* dolcon - store branch information for intra
   sws   new code 
*/
void
dolcon(struct node * node)
{
  /* assume we are in a branch statement */
  /* later add flag in go */

  /* add current value to list */
  branchto[nbranchto++] = lconsts[node->n.values].label_num;
  return;
}

/* just march through a line, adjusting ident declarations 
   - update to current symbol table 
   - ??update only if symbol table knowledge is real */
static void
dodecl(struct node * node)
{
  struct symnode *s;
  int chg;

  /* fprintf(stderr,"[dodecl] %s\n", prtoken(node->nodetype)); */
  switch (node->nodetype) {
  default:
    if (node->nodetype==COND) {
      dodecl(STORE);
    }
    if (LEFT != NILP) {
      /* fprintf(stderr,"[dodecl] left\n"); */
      dodecl(LEFT);
    }
    if (RIGHT != NILP) {
      /* fprintf(stderr,"[dodecl] right\n"); */
      dodecl(RIGHT);
    }
    if ( use_axis_node(node->nodetype) && (AXIS != NILP) ){
      /* fprintf(stderr,"[dodecl] axis\n"); */
      dodecl(AXIS);
    }
    break;
  case IDENT:
    /* fprintf(stderr,"[dodecl] ident\n"); */
    s = getsinfo(node->namep);
    if (s) {
#if 1
      /* adjust type */
      if ( (s->s.type != APLC_UKTYPE) && (s->s.type != APLC_ANY) ) {
#if IDEBUG
	fprintf(stderr,"declaring the type for %s as %s(%d)\n",
		node->namep, str_type_name(s->s.type),s->s.type);
#endif
	node->n.type = s->s.type;
	node->n.info |= TYPEDECL;
      }
      chg = update_rank(&(node->n), &(s->s));
      if (node->n.info & RANKKNOWN)
	node->n.info |= RANKDECL;
#if (IDEBUG > 1)
      if (chg) {
	fprintf(stderr,"\n[intra/dodecl] ");
	fprintf(stderr,"updating node %s to ", node->namep); 
	print_info(stderr, &(node->n) );
      }
#endif 

#else /* old method */
      /* adjust type */
      if ( (s->s.type != APLC_UKTYPE) && (s->s.type != APLC_ANY) ) {
#if IDEBUG
	fprintf(stderr,"declaring the type for %s as %s(%d)\n",
		node->namep, str_type_name(s->s.type),s->s.type);
#endif
	node->n.type = s->s.type;
	node->n.info |= TYPEDECL;
      }
      /* adjust rank */
      if ( s->s.info & RANKKNOWN ) {
#if IDEBUG
	fprintf(stderr,"declaring the rank for %s to ",
		node->namep); prrank(stderr,s->s.rank); 
		fprintf(stderr,"\n");
#endif
	node->n.rank = s->s.rank;
	node->n.info |= RANKDECL;
      } 
#endif
    }
    break;
  }
  return;
}

/* just march through a line, 
 */
static void
doinit(struct node *node)
{
  struct symnode *ids;

  /* fprintf(stderr,"[doinit] %s\n", prtoken(node->nodetype)); */
  switch (node->nodetype) {
  case APPLY:
  case COND:
  case FIDENT:
  case OPIDENT:
    init_arb(node);
    break;
  case IDENT:
    if ( (ids = lookup_name(node->namep, symtab)) ) {
#if IDEBUG >1
      fprintf(stderr," (name %s, class %s)\n", node->namep, 
	      str_class(ids->class));
#endif
      if (GLOBAL == ids->class)
	init_arb(node);
    } else
      init_arb(node);/* not found in symbol table */
    break;
  default:
    break;
  }
  if (node->nodetype==COND) {
    doinit(STORE);
  }
  if (LEFT != NILP) {
    /* fprintf(stderr,"[doinit] left\n"); */
    doinit(LEFT);
  }
  if (RIGHT != NILP) {
    /* fprintf(stderr,"[doinit] right\n"); */
    doinit(RIGHT);
  }
  if ( use_axis_node(node->nodetype) && (AXIS != NILP) ){
    /* fprintf(stderr,"[doinit] axis\n"); */
    doinit(AXIS);
  }
  return;
}

/* re-initialize nodes to allow for changing declarations of idents 
   - don't mess with leaves (e.g. constants) 
   - run before the last doinf stage
*/
static void
doinf_reinit(struct node *node, int top)
{

  switch (node->nodetype) {
  default:
    caserr("doinf_reinit", node->nodetype);
    break;

  case ASSIGN:
  case QUAD:
  case DQUAD:
  case DQQUAD:
  case QQUAD:
  case QQUADASSIGN:
  case QUADASSIGN:
  case DQUADASSIGN:
  case DQQUADASSIGN:
  case BOX:
  case UNBOX:
  case CAT:
  case RESHAPEX:
  case LINK:
  case CATCH:
  case CCOLLECT:
  case COLLECT:
  case COMPRESS:
  case EXPAND:
   case CIVEC:
  case CVEC:
  case CISCALAR:
  case CSCALAR:
  case DEAL:
  case DECODE:
  case INNERCHILD:
  case DFORMAT:
  case DOMINO:
  case DROP:
  case GWDROP:
  case DSFUN:
  case DTRANS:
  case EMPTSEMI:
  case ENCODE:
  case EPSILON:
  case EXECUTE:
  case FORMAT:
  case GO:
  case INDEXFN:
  case INDEXOF:
  case INNER:
  case IOTA:
  case MATCH:
  case MSOLVE:
  case MSFUN:
  case OUTER:
  case RAVEL:
  case REDUCE:
  case REVERSE:
  case RESHAPE:
  case RHO:
  case RHORHO:
  case ROLL:
  case ROTATE:
  case SCAN:
  case SM:
  case SORT:
  case SUB:
  case SUBASSIGN:

  case DSYSFUN:
  case ESYSFUN:
  case MSYSFUN:

  case TAKE:
  case GWTAKE:
  case TRANS:

  case COND:
    /* ensure init to 0 */
    /*node->n.info = 0;*/
    remove_type_info(&(node->n));
    remove_rank_info(&(node->n));
    remove_shape_info(&(node->n));
    remove_value_info(&(node->n));
    if (node->nodetype==COND)
      doinf_reinit(STORE, 0);
    if (RIGHT)
      doinf_reinit(RIGHT, 0);
    if (LEFT)
      doinf_reinit(LEFT, 0);
    break;

    /* leaves */
  case AVEC:
  case BCON:
  case ICON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case SCON:
  case FNCON:
  case COMMENT:
  case APPLY:
    /*case COND:*/
  case FIDENT:
  case OPIDENT:
  case IDENT:
  case LCON:
  case ASYSVAR:
  case SYSVAR:
  case TCAV:
  case TYPECON:
    break;

    /* other */
  case LAM:
    error("laminate not implemented yet");
    /* sws   it is actually, in cat... */
    break;
  }
  return;
}

/* end of intra.c */

