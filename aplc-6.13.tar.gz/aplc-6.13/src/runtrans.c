/*
	APL Compiler

	run time system -
	routines having to do with universal accessor/ merged steppers
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

#include <stdio.h>
#include "aplc.h"


/* 
   qsdalloc - allocate the q, s and d vectors for a stepper
              and initialize with identity values
	      (note s is t in the book)
 */
extern int 
aplc_qsdalloc(int rank, union mp_struct *q, union mp_struct *s, 
	 union mp_struct *d)
{
  int i;

  aplc_vectalloc(q, rank, APLC_INT);
  aplc_vectalloc(s, rank, APLC_INT);
  aplc_vectalloc(d, rank, APLC_INT);
  for (i = rank-1; i >= 0; i--) {
    q->ip[i] = i;
    s->ip[i] = 0;
    d->ip[i] = 1;
  }
  return(rank);
}

/* 
   accessor - construct the accessor values for a stepper 
   sws: note that delta is allocated space 

*/
extern int 
aplc_accessor(int toprank, int *topshape, int rank, int *shape, 
         union mp_struct *delta, int *q, int *t, int *d)
{
  int e, alpha, i;

  e = 1; alpha = 0;
  aplc_vectalloc(delta, toprank, APLC_INT);
  for (i = 0; i <toprank; i++) {
    delta->ip[i] = 0;
  }
  for (i = rank - 1; i >= 0; i--) {
    delta->ip[q[i]] += d[i] * e;
    alpha += t[i] * e;
    e *= shape[i];
  }
  for (i = 0; i < toprank-1; i++) {
    delta->ip[i] -= delta->ip[i+1] * topshape[i+1];
  }
  return(alpha);
}


/* sws
   specialized accessor for take and drop only 
   q[i] = i
   d[i] = 1
   */
extern int 
aplc_td_accessor(int toprank, int *topshape, 
	    int rank, int *shape, 
	    union mp_struct *delta, int *t)
{
  int e, alpha, i;

  e = 1; alpha = 0;
  aplc_vectalloc(delta, toprank, APLC_INT);
  for (i = 0; i <toprank; i++) {
    delta->ip[i] = 0;
  }
  for (i = rank - 1; i >= 0; i--) {
    delta->ip[i] += e;
    alpha += t[i] * e;
    e *= shape[i];
  }
  for (i = 0; i < toprank-1; i++) {
    delta->ip[i] -= delta->ip[i+1] * topshape[i+1];
  }
  return(alpha);
}



/* trmerge - merge the information from a monadic transpose */
extern void 
aplc_trmerge(int rank, int *q, int *s, int *d)
{
  int i, j, k;

  for (i = rank/2 - 1; i >= 0; i--) {
    j = (rank - i) - 1;
    k = *(q +i);
    *(q +i) = *(q + j);
    *(q +j) = k;
    k = *(s + i);
    *(s + i) = *(s + j);
    *(s + j) = k;
    k = *(d + i);
    *(d + i) = *(d + j);
    *(d + j) = k;
  }
}

/* dtmerge - dyadic transpose merge */
extern void 
aplc_dtmerge(int *control, int rank, union mp_struct *q, 
        union mp_struct *s, union mp_struct *d)
{
  int i, j, *od, *os, *oq;

  oq = q->ip;
  os = s->ip;
  od = d->ip;
  aplc_vectalloc(q, rank, APLC_INT);
  aplc_vectalloc(s, rank, APLC_INT);
  aplc_vectalloc(d, rank, APLC_INT);
  for (i = 0; i < rank; i++) {
    j = *(control + i) - 1;
    q->ip[i] = oq[j];
    s->ip[i] = os[j];
    d->ip[i] = od[j];
  }
}

/* end of runtrans.c */



