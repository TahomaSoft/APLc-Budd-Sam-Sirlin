/*
	APL Compiler

	print (and other) utilities for parse stage
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.
*/

#include <stdio.h>

#include "parse.h"
#include "y_tab.h"

/* ----------------------------------------------- */


/* special check for type match */
extern int
types_match(int t1, int t2)
{
  int mat = 0;

  if (t1 == t2)
    return 1;

  switch (t1) {
  case APLC_BIT:   
  case APLC_BOOL:
  case APLC_LABEL: 
  case APLC_INT:
    switch(t2) {
    case APLC_BIT:   
    case APLC_BOOL:
    case APLC_LABEL: 
    case APLC_INT:
      mat = 1;
      break;
    default:
      break;
    }
    break;

  default:
    break;
  }

  return mat;
}


extern int
check_nsrank( info_t *s1, info_t *s2)
{
  int r1a, r2a;
  int i, j;

  /* first get non-singleton rank count */
  r1a = 0;
  for (i=0; i<s1->rank; i++)
    if ( iconsts[ s1->shape+i ] != 1)
      r1a++;
  r2a = 0;
  for (i=0; i<s2->rank; i++)
    if ( iconsts[ s2->shape+i ] != 1)
      r2a++;
  if (r1a != r2a) {
    fprintf(stderr, "[trs:check_nsrank] rank missmatch %d vs %d\n",
	    r1a, r2a);
    return 1;
  }
  /* now check shapes */
  for (i=0, j=0; i<s1->rank; i++) {
    r1a = iconsts[ s1->shape+i ];
    if ( r1a != 1) {
      r2a = -1;
      while ( (j<s2->rank) && (iconsts[ s2->shape+j ] == 1) )  
	j++;
      if (j<s2->rank)
	r2a = iconsts[s2->shape+j];
      if (r1a != r2a){
	fprintf(stderr, "[trs:check_nsrank] shape missmatch (%d)%d vs (%d)%d\n",
		i, r1a, j, r2a);
	return 1;
      }
      j++;
    }
  }
  return 0;
} 

/* update size information in an info structure, if possible */
extern void
update_info_size(info_t *s)
{
  int j;

  s->size = 1;
  if ( (s->info & RANKKNOWN) && (s->info & SHAPEKNOWN) ) {
    for (j=s->rank-1; j>=0; j--)
      s->size *= iconsts[s->shape +j];
  }
  return;
}

/* ----------------------------------------------- */

/* 
   to get through the list, we need to know which node types might use
   axis for another node

   we can't just test for a null pointer, as the axis space is a union... 
 
   */
extern int 
use_axis_node( int type )
{
  switch(type) {
  default:
    return 0;
    break;

  case COMPRESS:
  case EXPAND:
  case ROTATE:
  case CAT:
  case LAM:
  case REVERSE:
  case REDUCE:
  case SCAN:
  case SM:
    /* sm axis seems to be just ident */
  case SUBASSIGN:
    return 1;
    break;
  }
}

/* ----------------------------------------------- */

/* classes defined in psym.h */
extern char *
str_class(class_t xx)
{
  switch(xx) {
  default:
  case NOCLASS:
    return "NOCLASS";
    break;
  case GLOBAL:
    return "GLOBAL";
    break;
  case PARAM:
    return "PARAM";
    break;
  case APARAM:
    return "APARAM";
    break;
  case LABCLASS:
    return "LABCLASS";
    break;
  case LOCAL:
    return "LOCAL";
    break;
  case LFUNCTION:
    return "LFUNCTION";
    break;
  case FUNCTION:
    return "FUNCTION";
    break;
  case OPERATOR:
    return "OPERATOR";
    break;
  case GLOCAL:
    return "GLOCAL";
    break;
  case GLOCALCOPY:
    return "GLOCALCOPY";
    break;
  case GLFUNCTION:
    return "GLFUNCTION";
    break;
  case GLFUNCTIONCOPY:
    return "GLFUNCTIONCOPY";
    break;
  }
}


/* sws  error printing 1/91 */
extern void
prstatenode(struct statenode * code)
{
  fprintf(stderr, "  contents of statenode\n");
  if (code->label)
    fprintf(stderr, "   label= %s\n", code->label);
#if 1
  prt_node_list(code->code);
#else
  fprintf(stderr, "    node.nodetype= %d (%s)\n", code->code->nodetype, prtoken(code->code->nodetype));
  fprintf(stderr, "    node.info= %d\n", code->code->n.info);
#endif
#if 0
  fprintf(stderr, "   nextstate ld= %ld\n", (long int) code->nextstate);
#endif
  if (code->list) 
    fprintf(stderr, "   list= %s\n", code->list->name);
  
  return;
}

/* sws  error printing 5/91 */
extern void
prtcode(struct statenode * code)
{
  struct statenode *p;
  int k;

  for (p=code, k=1; p != NILSTATE; p=p->nextstate, k++) {
    fprintf(stderr, "statement[%d]\n",k);
    prstatenode(p);
  }
  fprintf(stderr, "end code\n");
}

extern void
prt_spaces(FILE*fp, int n)
{
  int k;
  for (k=0; k<n; k++)
    fprintf(fp," ");
  return;
}

static int prt_node_list_indent = 0;
extern void
prt_node_list(struct node *node) 
{
  prt_spaces(stderr,prt_node_list_indent);
  fprintf(stderr, "nodetype= %d %s; ", node->nodetype, prtoken(node->nodetype));
  if ( (node->nodetype == DSFUN) ||
       (node->nodetype == MSFUN) ||
       (node->nodetype == REDUCE) ||
       (node->nodetype == SCAN) )
    fprintf(stderr, "{%s}", str_sfun(node->optype));
  if (node->namep)
    fprintf(stderr,"{%s};",node->namep);
  fprintf(stderr, "info= %d\n", node->n.info);
  if (LEFT != NILP) {
    prt_node_list_indent++;
    prt_spaces(stderr,prt_node_list_indent);
    fprintf(stderr, "[(%s left): ", prtoken(node->nodetype)); 
    prt_node_list(LEFT);
    prt_spaces(stderr,prt_node_list_indent);
    fprintf(stderr, "]\n"); 
    prt_node_list_indent--;
  }
  if (RIGHT != NILP) {
    prt_node_list_indent++;
    prt_spaces(stderr,prt_node_list_indent);
    fprintf(stderr, "[(%s right): ", prtoken(node->nodetype)); 
    prt_node_list(RIGHT);
    prt_spaces(stderr,prt_node_list_indent);
    fprintf(stderr, "]\n"); 
    prt_node_list_indent--;
  }
  if (STORE != NILP) {
    prt_node_list_indent++;
    prt_spaces(stderr,prt_node_list_indent);
    fprintf(stderr, "[(%s store): ", prtoken(node->nodetype)); 
    prt_node_list(STORE);
    prt_spaces(stderr,prt_node_list_indent);
    fprintf(stderr, "]\n"); 
    prt_node_list_indent--;
  }
  return;
}

extern void
print_rkshape(FILE *fp, char *name, info_t *s)
{
  fprintf(fp, "%s rank [%s], shape = [", name, str_ranki(s));
  print_shape(fp, s);
  fprintf(fp, "]\n");
  return;
}

/* sws  string representation of rank */
extern char *
str_ranki(info_t *s)
{
  char *str;
  static char tmp[20];

  if ( s->info & RANKKNOWN) {
    if (s->rank != ANYRANK) {
      sprintf(tmp, "%d", s->rank);
      str = tmp;
    } else 
      str = "arbitrary";
  } else
    str = "unknown";
  return(str);
}

extern char *
str_rank(int rank)
{
  char *str;
  static char tmp[20];

  if (rank == NORANK)
    str = "unknown";
  else if (rank == ANYRANK)
    str = "arbitrary";
  else {
    sprintf(tmp, "%d", rank);
    str = tmp;
  }
  return(str);
}

/* sws  print out rank */
extern void
prnrank(FILE *fp, int rank)
{
  fprintf(fp, "{%s}", str_rank(rank));
  return;
}

extern void
print_rank(FILE *fp, info_t *s)
{
  fprintf(fp, "{%s}", str_ranki(s));
  return;
}

/* sws  list shape vector of node with known shape */
extern void
print_shape(FILE *fp, info_t *s)
{
  int j;

  if (s->rank > 0) {
    /* size = 1; */
    fprintf(fp, "(%d) ", s->shape);
    for (j = 0; j < s->rank; j++)
      fprintf(fp, "%d ", iconsts[s->shape + j]);
  } else if (s->rank > -1)
    fprintf(fp, " scalar ");
  else
    fprintf(fp, " unknown ");
  return;
}

/* print out integer vector declaration */
extern void
print_ivec_dec(FILE *fp, int ipt, int n)
{
  int i;

  fprintf(fp, "{ ");  
  for (i=0; i<n; i++) {
    fprintf(fp, "%d", iconsts[ipt+i]);
    if (i<n-1)
      fprintf(fp,", ");
  }
  fprintf(fp, "} ");  
  return;
}

/* type strings    - must match type list in aplc.h */
static char *types[] = { "unknown type", 
			 "bit", "bool", "label", "int",
			 "real", "complex", "quaternion", "octonion",
			 "char", "boxed", "function", "operator",
			 "any" };
/* sws  string representation of type */
extern char *
str_type_name(int type)
{
  return(types[type]);
}

/* sws
get a string representation of a parser token type */
static char tmp[50];

extern char *
prtoken(int type)
{
  char *token;

  switch (type) {
  default:
    sprintf(tmp,"[prtoken] unknown type %d",type);
    token = tmp;
    break;

  case CLASS:
    token = "{CLASS}";
    break;
  case TYPE:
    token = "{TYPE}";
    break;
  case RANK:
    token = "{RANK}";
    break;
  case DEL:
    token = "{DEL}";
    break;
  case GO:
    token = "{GO}";
    break;
  case COMMENT:
    token = "{COMMENT}";
    break;
  case COLLECT:
    token = "{COLLECT}";
    break;
  case CVEC:
    token = "{CVEC}";
    break;
  case CIVEC:
    token = "{CIVEC}";
    break;
  case CSCALAR:
    token = "{CSCALAR}";
    break;
  case CISCALAR:
    token = "{CISCALAR}";
    break;
  case CCOLLECT:
    token = "{CCOLLECT}";
    break;
  case ASSIGN:
    token = "{ASSIGN}";
    break;
  case QUADASSIGN:
    token = "{QUADASSIGN}";
    break;
  case SUBASSIGN:
    token = "{SUBASSIGN}";
    break;
  case QUAD:
    token = "{QUAD}";
    break;
  case DQUAD:
    token = "{DQUAD}";
    break;
  case QQUAD:
    token = "{QQUAD}";
    break;
  case DQQUAD:
    token = "{DQQUAD}";
    break;
  case DQUADASSIGN:
    token = "{DQUADASSIGN}";
    break;
  case QQUADASSIGN:
    token = "{QQUADASSIGN}";
    break;
  case DQQUADASSIGN:
    token = "{DQQUADASSIGN}";
    break;
  case QUADLZ:
    token = "{QUADLZ}";
    break;
  case IDENT:
    token = "{IDENT}";
    break;
  case APPLY:
    token = "{APPLY}";
    break;
  case COND:
    token = "{COND}";
    break;
  case FIDENT:
    token = "{FIDENT}";
    break;
  case OPIDENT:
    token = "{OPIDENT}";
    break;
  case UIDENT:
    token = "{UIDENT}";
    break;
  case LCON:
    token = "{LCON}";
    break;
  case SCON:
    token = "{SCON}";
    break;
  case BCON:
    token = "{BCON}";
    break;
  case ICON:
    token = "{ICON}";
    break;
  case FNCON:
    token = "{FNCON}";
    break;
  case RCON:
    token = "{RCON}";
    break;
  case ZCON:
    token = "{ZCON}";
    break;
  case QCON:
    token = "{QCON}";
    break;
  case OCON:
    token = "{OCON}";
    break;
  case NL:
    token = "{NL}";
    break;
  case LP:
    token = "{LP}";
    break;
  case RP:
    token = "{RP}";
    break;
  case LB:
    token = "{LB}";
    break;
  case RB:
    token = "{RB}";
    break;
  case BQT:
    token = "{BQT}";
    break;
  case CM:
    token = "{CM}";
    break;
  case SM:
    token = "{SM}";
    break;
  case COLON:
    token = "{COLON}";
    break;
  case DOLLAR:
    token = "{DOLLAR}";
    break;
  case DOT:
    token = "{DOT}";
    break;
  case MSFUN:
    token = "{MSFUN}";
    break;
  case DSFUN:
    token = "{DSFUN}";
    break;
  case OUTER:
    token = "{OUTER}";
    break;
  case INNER:
    token = "{INNER}";
    break;
  case INNERCHILD:
    token = "{INNERCHILD}";
    break;
  case DECODE:
    token = "{DECODE}";
    break;
  case SLASH:
    token = "{SLASH}";
    break;
  case BSLASH:
    token = "{BSLASH}";
    break;
  case REDUCE:
    token = "{REDUCE}";
    break;
  case EXPAND:
    token = "{EXPAND}";
    break;
  case COMPRESS:
    token = "{COMPRESS}";
    break;
  case SCAN:
    token = "{SCAN}";
    break;
  case SORT:
    token = "{SORT}";
    break;
  case GRADEUP:
    token = "{GRADEUP}";
    break;
  case GRADEDOWN:
    token = "{GRADEDOWN}";
    break;
  case EPSILON:
    token = "{EPSILON}";
    break;
  case INDEXFN:
    token = "{INDEXFN}";
    break;
  case INDEXOF:
    token = "{INDEXOF}";
    break;
  case TRANS:
    token = "{TRANS}";
    break;
  case DTRANS:
    token = "{DTRANS}";
    break;
  case REVERSE:
    token = "{REVERSE}";
    break;
  case ROTATE:
    token = "{ROTATE}";
    break;
  case TAKE:
    token = "{TAKE}";
    break;
  case DROP:
    token = "{DROP}";
    break;
  case GWTAKE:
    token = "{GWTAKE}";
    break;
  case GWDROP:
    token = "{GWDROP}";
    break;
  case RHO:
    token = "{RHO}";
    break;
  case RHORHO:
    token = "{RHORHO}";
    break;
  case RESHAPE:
    token = "{RESHAPE}";
    break;
  case SUB:
    token = "{SUB}";
    break;
  case EMPTSEMI:
    token = "{EMPTSEMI}";
    break;
  case IOTA:
    token = "{IOTA}";
    break;
  case RAVEL:
    token = "{RAVEL}";
    break;
  case CAT:
    token = "{CAT}";
    break;
  case RESHAPEX:
    token = "{RESHAPEX}";
    break;
  case LAM:
    token = "{LAM}";
    break;
  case ROLL:
    token = "{ROLL}";
    break;
  case DEAL:
    token = "{DEAL}";
    break;
  case ENCODE:
    token = "{ENCODE}";
    break;
  case FORMAT:
    token = "{FORMAT}";
    break;
  case DFORMAT:
    token = "{DFORMAT}";
    break;
  case EXECUTE:
    token = "{EXECUTE}";
    break;
  case LCARET:
    token = "{LCARET}";
    break;
  case RCARET:
    token = "{RCARET}";
    break;
  case ANON:
    token = "{ANON}";
    break;
  case BOX:
    token = "{BOX}";
    break;
  case UNBOX:
    token = "{UNBOX}";
    break;
  case LINK:
    token = "{LINK}";
    break;
  case MATCH:
    token = "{MATCH}";
    break;
  case MSOLVE:
    token = "{MSOLVE}";
    break;
  case DOMINO:
    token = "{DOMINO}";
    break;
  case AVEC:
    token = "{AVEC}";
    break;
  case TCAV:
    token = "{TCAV}";
    break;
  case TYPECON:
    token = "{TYPECON}";
    break;
  case ASYSVAR:
    token = "{ASYSVAR}";
    break;
  case SYSVAR:
    token = "{SYSVAR}";
    break;
  case DSYSFUN:
    token = "{DSYSFUN}";
    break;
  case ESYSFUN:
    token = "{ESYSFUN}";
    break;
  case MSYSFUN:
    token = "{MSYSFUN}";
    break;
  case ALPHA:
    token = "{ALPHA}";
    break;
  case OMEGA:
    token = "{OMEGA}";
    break;
  case CGOTO:
    token = "{CGOTO}";
    break;
  case CATCH:
    token = "{CATCH}";
    break;
  case EACH:
    token = "{EACH}";
    break;
  case ATERM:
    token = "{ATERM}";
    break;
  case TERM:
    token = "{TERM}";
    break;
  case AXISO:
    token = "{AXISO}";
    break;
  }
  return (token);
}

/* print out symbol table */
extern void
print_symtab(FILE *fp, struct symnode *syms)
{
  struct symnode *s;

  fprintf(fp, "Symbols (name, class, type, rank)\n");
  for (s = syms; s != (struct symnode *) 0; s = s->next) {
#if 1
    fprintf(fp, "\t%s: ", s->name);
    if (s->glbname)
      fprintf(fp, "(%s) ", s->glbname);
    fprintf(fp, "%s: ", str_class(s->class));
    if (s->s.info) {
      print_info(fp, &(s->s));
      fprintf(fp, "\n");
    } else {
      fprintf(fp, "type= {%s}", str_type_name(s->s.type));
      fprintf(fp, " rank= ");
      prnrank(fp, s->s.rank);
      if (s->s.oinfo) {
        if (s->class == OPERATOR ) {
          fprintf(fp, " valence %s, optype %s", 
                  str_valence(s->s.oinfo), str_optype(s->s.oinfo));
          fprintf(fp, " LF(%d), RF(%d)", s->s.oinfo & O_LF,
                  s->s.oinfo & O_RF);
        } else
            fprintf(fp, " valence %s", str_fnvalence(s->s.oinfo));
      }
      fprintf(fp, "\n");
    }
#else
    fprintf(fp, "\t%s: type= {%s}", s->name, str_type_name(s->s.type));
    fprintf(fp, " rank= ");
    prnrank(fp, s->s.rank);
    fprintf(fp, "\n");
#endif
  }
  return;
}

/* print out a single symbol */
extern void
print_sym(FILE *fp, struct symnode *s)
{
#if 1
  if (!s) {
    fprintf(fp,"nilsym");
    return;
  }
#else
  if (!s)
    error("[print_sym] bad symnode");
#endif
  /*fprintf(fp, "[print_sym] s==%p\n", (void *) s);*/
  /*fprintf(fp, "Symbols (name, class, type, rank)\n");*/
  fprintf(fp, "\t%s: ", s->name);
  if (s->glbname)
    fprintf(fp, "(%s) ", s->glbname);
  fprintf(fp, "%s ", str_class(s->class));
  fprintf(fp, " depth %d: ", s->depth);
  if ((s->s.info) || (s->s.oinfo)) {
    print_info(fp, &(s->s));
    fprintf(fp, "\n");
  } else {
    fprintf(fp, "type= {%s}", str_type_name(s->s.type));
    fprintf(fp, " rank= ");
    prnrank(fp, s->s.rank);
    /*fprintf(fp, " info= %d", s->s.info);*/
    fprintf(fp, "\n");
  }
  return;
}

/* print out known values of an info_t  */
extern void
print_values(FILE *fp, info_t *s)
{
  int rank, size, i, j;
  int shape;

  rank = s->rank;
  shape = s->shape;
  size = 1;
  for (i=0; i<rank; i++)
    size *= iconsts[shape +i];
  /*fprintf(fp, "( type %d)", s->type);*/
  switch(s->type) {
  default: 
    fprintf(fp, "unknown type %d\n", s->type);
    break;
  case APLC_BOOL:
  case APLC_INT:
    fprintf(fp, "(int)");
    for (i=0; i<size; i++)
      fprintf(fp, " %d ", iconsts[i+s->values]);
    break;
  case APLC_LABEL:
    fprintf(fp, "(label)");
    for (i=0; i<size; i++)
      fprintf(fp, " %d ", lconsts[i+s->values].label_num);
    break;
  case APLC_REAL:
    fprintf(fp, "(real)");
    for (i=0; i<size; i++) {
      /* fprintf(fp, " %g ", rconsts[i+s->values]);*/
      /*fprintf(fp, " %22.15g ", rconsts[i+s->values]);*/
      fprintf(fp, " %1.15g ", rconsts[i+s->values]);
    }
    break;    
  case APLC_COMPLEX:
    fprintf(fp, "(complex)");
    for (i=0; i<size; i++) {
      fprintf(fp, " (%1.15g, %1.15g) ", 
	      zconsts[0][i+s->values], zconsts[1][i+s->values]);
    }
    break;
  case APLC_QUAT:
    fprintf(fp, "(quat)");
    for (i=0; i<size; i++) {
      fprintf(fp, " ("); 
      for (j=0; j<4; j++) {
	fprintf(fp, "%1.15g", qconsts[j][i+s->values]);
	if (j < 3)
	  fprintf(fp, ", "); 
      }
      fprintf(fp, ") "); 
    }
    break;
  case APLC_OCT:
    fprintf(fp, "(oct)");
    for (i=0; i<size; i++) {
      fprintf(fp, " ("); 
      for (j=0; j<7; j++) {
	fprintf(fp, "%1.15g", oconsts[j][i+s->values]);
	if (j < 6)
	  fprintf(fp, ", "); 
      }
      fprintf(fp, ") "); 
    }
    break;
  case APLC_CHAR:
    fprintf(fp, "(char)");
    fprintf(fp, "[");
    for (i=0; i<size; i++)
      fprintf(fp, "%c", sconsts[i+s->values]);
    fprintf(fp, "]");
    break;    
  case APLC_FNP:
    fprintf(fp, "(function)");
    for (i=0; i<size; i++)
      fprintf(fp, " %s ", fnconsts[i+s->values]);
    break;
  }
}

/* decode info and print to fp */
extern void
print_info(FILE *fp, info_t *s)
{
  /*fprintf(fp, " [info %o] ", s->info);*/
  if (s->info & TYPEKNOWN)
    fprintf(fp, " TYPEKNOWN (%s)", str_type_name(s->type));
  if (s->info & RANKKNOWN) {
    if (s->rank != ANYRANK) {
      fprintf(fp, " RANKKNOWN (");
      prnrank(fp, s->rank);
      fprintf(fp, ")");
    } else
      fprintf(fp, " ANYRANK");
  }
  if (s->info & SHAPEKNOWN) {
    fprintf(fp, " SHAPEKNOWN (");
    print_shape(fp, s);
    fprintf(fp, ")");
    fprintf(fp, " size %d",s->size);
  }
  if (s->info & SHAPEARB)
    fprintf(fp, " SHAPEARB");

  /*  if (s->info)
      fprintf(fp, "\n   ");*/
  if (s->info & TYPEDECL)
    fprintf(fp, " TYPEDECL ");
  if (s->info & RANKDECL)
    fprintf(fp, " RANKDECL ");
  if (s->info & VALUESKNOWN) {
    fprintf(fp, " VALUESKNOWN [%d]", s->values);
    fprintf(fp, " = ("); print_values(fp, s); fprintf(fp, ")"); 
  }
  if (s->oinfo)
    fprintf(fp, " valence %s, optype %s", 
            str_valence(s->oinfo), str_optype(s->oinfo));

  if (s->info & FIRSTAXIS)
    fprintf(fp, "\n    FIRSTAXIS");
  if (s->info & LASTAXIS)
    fprintf(fp, "\n    LASTAXIS");
  if (s->info & SEQUENTIAL)
    fprintf(fp, " SEQUENTIAL");
  if (s->info & HAVEVALUE)
    fprintf(fp, " HAVEVALUE");
  if (s->info & NOINDEX)
    fprintf(fp, " NOINDEX");
  if (s->info & MERGED)
    fprintf(fp, "\n    MERGED");
  if (s->info & ASSIGNP)
    fprintf(fp, "\n    ASSIGNP");
  if (s->info & EARLYBIND)
    fprintf(fp, "\n    EARLYBIND");
  if (s->info & HAVETRS)
    fprintf(fp, "\n    HAVETRS");
  if (s->info & ASSNAMEREF)
    fprintf(fp, "\n    HAVETRS");
  if (s->info & ASSNAMEOK)
    fprintf(fp, "\n    ASSNAMEOK");

  return;
}

/* return as a string the monadic system function name */
extern char *
str_msysfun(int ntype)
{
  switch(ntype) {
  default:
    error("str_sysfun error");
    break;

  case DOMINO:
    return "aplc_domino";
    break;
  case EXECUTE:
    return "aplc_execute";
    break;
  case FORMAT:
    return "aplc_format";
    break;
  case UNBOX:
    return "aplc_unbox";
    break;

    /* sysvar */
  case SYS_AZ:
    return "aplc_az";
    break;
  case SYS_ZA:
    return "aplc_za";
    break;

    /* msysfun */
  case SYS_DL:
    return "aplc_dl";
    break;
  case SYS_FFLUSH:
    return "aplc_fflush";
    break;
  case SYS_OP:
    return "aplc_mopen";
    break;
  case SYS_FREAD:
    return "aplc_read";
    break;
  case SYS_READLINE:
    return "aplc_readline";
    break;
  case SYS_SPAWN:
    return "aplc_spawn_mon";
    break;
  case SYS_SYS:
    return "aplc_sys";
    break;
  case SYS_FI:
    return "aplc_fi";
    break;
  case SYS_VI:
    return "aplc_vi";
    break;
  case SYS_VTYPE:
    return "aplc_type";
    break;
  case SYS_CL:
    return "aplc_close";
    break;
  }
  return "";
}

/* return as a string the monadic system function name */
extern char *
str_dsysfun(int ntype)
{
  switch(ntype) {
  default:
    error("str_dsysfun error");
    break;
  case DFORMAT:
    return "aplc_dformat";
    break;
  case MATCH:
    return "aplc_msolve";
    break;
  case MSOLVE:
    return "aplc_msolve";
    break;
  case SYS_AZ:
    return "aplc_daz";
    break;
  case SYS_ZA:
    return "aplc_dza";
    break;
  case SYS_FREAD:
    return "aplc_readn";
    break;
  case SYS_FWRITE:
    return "aplc_write";
    break;
  case SYS_FAPPEND:
    return "aplc_fappend";
    break;
  case SYS_PIPE:
    return "aplc_pipe";
    break;
  case SYS_SPAWN:
    return "aplc_spawn";
    break;
  case SYS_FCNTL:
    return "aplc_fcntl";
    break;
  case SYS_OP:
    return "aplc_open";
    break;
  case SYS_LSEEK:
    return "aplc_lseek";
    break;
  case SYS_SS:
    return "aplc_strsrch";
    break;
  }
  return "";
}

/* return as a string the scalar function name */
extern char *
str_sfun(enum sfuns st)
{
  switch(st) {
  default:
    error("str_sfun error");
    break;
  case APLC_NOT:
    return "APLC_NOT";
    break;
  case APLC_FLOOR:
    return "APLC_FLOOR";
    break;
  case APLC_CEIL:
    return "APLC_CEIL";
    break;
  case APLC_PLUS:
    return "APLC_PLUS";
    break;
  case APLC_MINUS:
    return "APLC_MINUS";
    break;
  case APLC_TIMES:
    return "APLC_TIMES";
    break;
  case APLC_ABS:
    return "APLC_ABS";
    break;
  case APLC_DIVIDE:
    return "APLC_DIVIDE";
    break;
  case APLC_EXP:
    return "APLC_EXP";
    break;
  case APLC_LOG:
    return "APLC_LOG";
    break;
  case APLC_CIRCLE:
    return "APLC_CIRCLE";
    break;
  case APLC_FACT:
    return "APLC_FACT";
    break;
  case APLC_AND:
    return "APLC_AND";
    break;
  case APLC_OR:
    return "APLC_OR";
    break;
  case APLC_NAND:
    return "APLC_NAND";
    break;
  case APLC_NOR:
    return "APLC_NOR";
    break;
  case APLC_LT:
    return "APLC_LT";
    break;
  case APLC_LE:
    return "APLC_LE";
    break;
  case APLC_EQ:
    return "APLC_EQ";
    break;
  case APLC_NE:
    return "APLC_NE";
    break;
  case APLC_GE:
    return "APLC_GE";
    break;
  case APLC_GT:
    return "APLC_GT";
    break;
  }
  return "";
}

/* return as a string the operator type 
   - this is the type of the inner arguments 
     which can be variables or functions */
extern char *
str_optype(int optype)
{
  if ( optype & O_VALENCE) {
    if (optype & O_F_DYADIC)
      return str_doptype(optype);
    else
      return str_moptype(optype);
  } else 
    return str_doptype(optype);/* guess dyadic */
  return " ";
}

/* for monadic operator */
extern char *
str_moptype(int optype)
{
  if (optype & O_OPTYPE) {
    if (optype & O_LF)
      return "FO";
    else
      return "VO";
  } else
    return "UNK";
  return " ";
}

/* for dyadic operator */
extern char *
str_doptype(int optype)
{
  if (optype & O_OPTYPE) {
    if (optype & O_LF)
      if (optype & O_RF)
        return "FOF";
      else
        return "FOV";
    else
      if (optype & O_RF)
        return "VOF";
      else
        return "VOV";
  } else
    return "UNK";
  return " ";
}

/* return the valence of an operator 
   note that operators can have inner and outer valence
   the inner arguments are either monadic or dyadic
   the outer are either monadic or ambivalent
   f o v      is monadic/monadic    MM
   v f o f v  is dyadic/ambivalent  DA
*/
extern char *
str_valence(int val)
{
  if (val & O_VALENCE) {
    if (val & O_F_DYADIC) {
      if (val& O_V_AMBIVALENT)
        return "DA";
      else
        return "DM";
    } else if (val & O_V_AMBIVALENT)
      return "MA";
    else
      return "MM";
  } else 
    return "UNK";
}  

/* for fns, just look at outer valence */
extern char *
str_fnvalence(int val)
{
  if (val & O_VALENCE) {
    if (val& O_V_AMBIVALENT)
      return "D";
    else
      return "M";
  } else
    return "UNK";
}  

#if 0
/* print a node tree 
   - need a string library
   - will heavily use cat, realloc 
 */
static nodenum = 0;
char *
str_node_tree(node_t *node)
{
  char *s;

  node nodenum [label=print_node_type]; 

  if (node->left) {
    node nodenum -> (left) [label=left]; 
    strcat(s, str_node_tree(left));
  }
  ...

  return s;
}

#endif

/* end of putil.c */

