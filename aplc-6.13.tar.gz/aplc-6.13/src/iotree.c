/*
	APL compiler
		parse tree i/o utilities
		timothy a. budd

	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/
#include <stdio.h>
#include "parse.h"
#include "y_tab.h"


/* to print debug info */
#define IODEBUG 0

/* ---------------------------------------------- */
/* some global variables */
int stmtno = 0;			     /* the current statement number */
char *funname = "main";		     /* the current function name */
char *passname = "main";            /* the current program */ 


/* temp string */
static char iname[MAX_NAME_LEN];
static char *getname(void);

/* ---------------------------------------------- */
/* error - print error message and quit 

   list current function name and statement number as well as 
   given message
*/
extern void
error(char *c)
{
  int *x=0;
  fprintf(stderr, "error: [%s] %s:%d:%s\n", passname, funname, stmtno, c);
  /* cause a crash, to allow gdb to stop in the right place */
  fprintf(stderr, "[error] causing deliberate crash\n");
  *x = 1;
  exit(1);
}

/* putname - print a name */
void
putname(char *c)
{
  if (c != NILCHAR)
    fputs(c, stdout);
  putchar('\n');
}

/* put function header */
void
putheader(struct headnode * head)
{
  /* sws check for 0 header pointer */
#if IODEBUG
  fprintf(stderr,"putheader: %ld\n", (long) head);
#endif
  if (head != 0) {
    fwriten((char *) head, sizeof(struct headnode), (size_t)1, stdout);
    putname(head->opname);
    putname(head->lfname);
    putname(head->rfname);
    putname(head->asvar);
    putname(head->parm1);
    putname(head->parm2);
  } else
    error("putheader: null header");
  return;
}

/* sws - a safe version of gets 
   used since this originally used gets */
char *
gets_safe(char *c)
{
  fgets(c, MAX_NAME_LEN, stdin);
  /* unlike gets, fgets can return a newline as the last char */
  if ('\n' == c[strlen(c)-1])
    c[strlen(c)-1] = '\0';
  return(c);
}

/* return a pointer to a char string, or nil */
static char *
getname(void)
{
  gets_safe(iname);
  if (iname[0] == '\0')
    return NILCHAR;
  else {
    return name_strcpy(iname);
  }
}

/* getfname - get function name field 
   -- requires existing char storage in c */
char *
getfname(char *c)
{
  c[0] = 0;
  gets_safe(c);
  if (c[0] == '\0')
    return NILCHAR;
  else
    return (c);
}

/* get function header */
void
gethead(struct headnode * head, 
	char *opname, char *lfname, char *rfname, 
	char *asvar, char *parm1, char *parm2)
{
  freadn((char *) head, sizeof(struct headnode), (size_t)1, stdin);
  head->opname = getfname(opname);
  head->lfname = getfname(lfname);
  head->rfname = getfname(rfname);
  head->asvar = getfname(asvar);
  head->parm1 = getfname(parm1);
  head->parm2 = getfname(parm2);
  return;
}

/* put symbol table */
void
putsyms(struct symnode * syms)
{
  struct symnode *p;

  for (p = syms; p != 0; p = p->next) {
    if (p->name) {
      putcharn(SYMS);
      fwriten((char *) p, sizeof(struct symnode), (size_t)1, stdout);
      putname(p->name);
      putname(p->glbname); 
    }
  }
  putcharn(ESYMS);
}

/* read symbol table */
struct symnode *
getsyms(void)
{
  struct symnode *fs, *os, *cs;
  int c;

  fs = 0;
  os = (struct symnode *) 0;/* initialize for lint */
  while ((c = getcharn()) == SYMS) {
#if IODEBUG >1
    fprintf(stderr, "getsyms: char read is %d\n", c);
#endif
    cs = structalloc(symnode);
    freadn((char *) cs, sizeof(struct symnode), (size_t)1, stdin);
    cs->name = getname();
#if IODEBUG >1
    fprintf(stderr,"getsyms: name read is %s\n", iname);
#endif
    cs->glbname = getname();
    cs->next = NILSYM;
    if (fs == NILSYM)
      fs = os = cs;
    else
      os->next = cs;
    os = cs;
  }
  if (c != ESYMS) {
    fprintf(stderr, "getsyms: char is %d\n", c);
    error("bad symbol table format");
  }
  return (fs);
}

/* free symbol table */
void
fresyms(struct symnode * syms)
{
  if (syms != (struct symnode *) 0) {
    if (syms->next != (struct symnode *) 0)
      fresyms(syms->next);
    free((char *) syms);
  }
}

/* put lcon (sws) */
void 
put_lcon(void)
{
  int i;

  if (lctop) {
    for (i = 0; i<lctop; i++) {
      fwriten((char *) &(lconsts[i]), sizeof(struct label_struct), (size_t)1, stdout);
      putname(lconsts[i].label_name);
    }
  }
  return;
}

/* sws */
void
get_lcon(void)
{
  int i;

  for (i=0; i<lctop; i++) {
    freadn((char *) &(lconsts[i]), sizeof(struct label_struct), (size_t)1, stdin);
    gets_safe(iname);
    lconsts[i].label_name = name_strcpy(iname);
  }
  return;
}

/* put constants */
void
putconsts(void)
{
  int a[8], i;

  putcharn(CONSTS);

  a[0] = strlen(sconsts);
  a[1] = lctop;
  a[2] = ictop;
  a[3] = rctop;
  a[4] = zctop;
  a[5] = qctop;
  a[6] = octop;
  a[7] = fnctop;
  fwriten((char *) a, sizeof(int), (size_t)8, stdout);
#if IODEBUG
  fprintf(stderr,"putconsts: ictop %d, fnctop %d\n",
	  ictop, fnctop);
#endif
  for (i = 0; i < a[0]; i++)
    putcharn(sconsts[i]);
  put_lcon();
  if (a[2])
    fwriten((char *) iconsts, sizeof(int), (size_t) ictop, stdout);
  if (a[3])
    fwriten((char *) rconsts, sizeof(double), (size_t) rctop, stdout);
  if (a[4]) {
    fwriten((char *) zconsts[0], sizeof(double), (size_t) zctop, stdout);
    fwriten((char *) zconsts[1], sizeof(double), (size_t) zctop, stdout);
  }
  if (a[5]) {
    for(i =0; i<4; i++)
      fwriten((char *) qconsts[i], sizeof(double), (size_t) qctop, stdout);
  }
  if (a[6]) {
    for(i =0; i<8; i++)
      fwriten((char *) oconsts[i], sizeof(double), (size_t) octop, stdout);
  }
  for(i=0; i<a[7]; i++) {
    putname(fnconsts[i]);
#if IODEBUG
    fprintf(stderr,"putconsts: fn %d %s\n",
	    i, fnconsts[i]);
#endif
  }
  return;
}

/* read constants */
extern void
rdconsts(void)
{
  int a[8], i;

  if (getcharn() != CONSTS)
    error("bad format reading constants");
  freadn((char *) a, sizeof(int), (size_t)8, stdin);
  sctop = a[0];
  lctop = a[1];
  ictop = a[2];
  rctop = a[3];
  zctop = a[4];
  qctop = a[5];
  octop = a[6];
  fnctop = a[7];
#if IODEBUG
  fprintf(stderr,"rdconsts: ictop %d, fnctop %d\n",
	  ictop, fnctop);
#endif
  for (i = 0; i < sctop; i++)
    sconsts[i] = getcharn();
  sconsts[i] = 0;
  get_lcon();
  if (ictop)
    freadn((char *) iconsts, sizeof(int), (size_t) a[2], stdin);
  if (rctop)
    freadn((char *) rconsts, sizeof(double), (size_t) a[3], stdin);
  if (zctop) {
    freadn((char *) zconsts[0], sizeof(double), (size_t) a[4], stdin);
    freadn((char *) zconsts[1], sizeof(double), (size_t) a[4], stdin);
  }
  if (qctop) {
    for (i=0; i<4; i++)
      freadn((char *) qconsts[i], sizeof(double), (size_t) a[5], stdin);
  }
  if (octop) {
    for (i=0; i<8; i++)
      freadn((char *) oconsts[i], sizeof(double), (size_t) a[6], stdin);
  }
  for (i=0; i<fnctop; i++) {
    gets_safe(iname);
    fnconsts[i] = name_strcpy(iname); 
#if IODEBUG
    fprintf(stderr,"rdconsts: fn %d %s\n",
	    i, iname);
#endif
  }
  return;
}

/* put out code */
void
putcode(struct statenode * code)
{
  struct statenode *p;

  stmtno = 0;
  for (p = code; p != NILSTATE; p = p->nextstate) {
    stmtno++;
    putcharn(STMT);
    fwriten((char *) &p->label, sizeof(char *), (size_t)1, stdout);
    putnode(p->code);
  }
  putcharn(ESTMT);
  return;
}

/* free storage used by code 
   - note this goes to the end first, and frees backwards  */
void
frecode(struct statenode * code)
{
  if (code->nextstate != NILSTATE)
    frecode(code->nextstate);
  frenode(code->code);
  free((char *) code);
}

/* read code */
struct statenode *
rdcode(void)
{
  struct statenode *sp, *op, *fp;
  char c;

  /* sws */
#if IODEBUG
  fprintf(stderr,"[rdcode] \n");
#endif

  fp = (struct statenode *) 0;/* initialize for lint */
  op = NILSTATE;
  while ((c = getcharn()) == STMT) {
    sp = structalloc(statenode);
    freadn((char *) &sp->label, sizeof(char *), (size_t)1, stdin);
    sp->code = innode();
    sp->nextstate = NILSTATE;
    sp->list = NILSYM;
    if (op == NILSTATE)
      op = fp = sp;
    else
      op->nextstate = sp;
    op = sp;
#if IODEBUG
    fprintf(stderr,"[rdcode] read 1 stmt\n");
#endif
  }
  if (c != ESTMT) {
    fprintf(stderr, "[rdcode] last character is %d\n", c);
    fprintf(stderr, "[rdcode] expect %d\n", ESTMT);
    error("[iotree/rdcode] bad format");
  }
  return (fp);
}

/* put out node */
void
putnode(struct node * node)
{
  if (!node)
    error("[putnode] nil node");
  fwriten((char *) node, sizeof(struct node), (size_t)1, stdout);

  if (node->namep)
    puts(node->namep);
  else
    puts(" ");

  if (node->namea)
    puts(node->namea);
  else
    puts(" ");

  switch (node->nodetype) {
  default:
    fprintf(stderr, "putnode: node type %d\n", node->nodetype);
    error("illegal node type output");

  case IDENT:
    /*puts(node->namep);*/
    break;

  case BCON:
  case ICON:
  case FNCON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case LCON:
  case SCON:
  case AVEC:
  case TCAV:
  case TYPECON:
  case QQUAD:
  case QUAD:
  case COMMENT:
    break;

  case EMPTSEMI:
    if (axisgiven(node->axis))
      putnode(node->axis);
    break;

  case REVERSE:
  case REDUCE:
  case SCAN:
    if (axisgiven(node->axis))
      putnode(node->axis);
    putnode(node->right);
    break;

  case COMPRESS:
  case EXPAND:
  case ROTATE:
  case CAT:
  case LAM:
  case CATCH:
    putnode(node->left);
    if (axisgiven(node->axis))
      putnode(node->axis);
    putnode(node->right);
    break;

  case APPLY:
  case COND:
  case FIDENT:
    if (LEFT != NILP)
      putnode(node->left);
    if (RIGHT != NILP)
      putnode(node->right);
    if (STORE != NILP)
      putnode(node->store);
    /*puts(node->namep);
      puts(node->namea);*/
    break;

  case OPIDENT:
    if (node->funleft != NILP)
      putnode(node->funleft);
    if (node->funright != NILP)
      putnode(node->funright);
    if (LEFT != NILP)
      putnode(node->left);
    if (RIGHT != NILP)
      putnode(node->right);
    if (STORE != NILP)
      putnode(node->store);
    /*puts(node->namep);
      puts(node->namea);*/
    break;

  case SM:
    if (LEFT != NILP)
      putnode(node->left);
    if (axisgiven(node->axis))
      putnode(node->axis);
    if (RIGHT != NILP)
      putnode(node->right);
    break;

  case ASYSVAR:
  case SYSVAR:
    if (node->left != NILP)
      putnode(node->left);
    if (node->right != NILP)
      putnode(node->right);
    break;

  case SUBASSIGN:
    putnode(node->left);
    putnode(node->right);
    putnode(node->axis);
    putnode(node->store);
    break;

  case QUADASSIGN:
  case CIVEC:
  case COLLECT:
  case CCOLLECT:
  case CISCALAR:
  case CSCALAR:
  case CVEC:
  case DQQUAD:
  case DQUAD:
  case DOMINO:
  case BOX:
  case UNBOX:
  case EXECUTE:
  case FORMAT:
  case GO:
  case INNER:
  case IOTA:
  case MSFUN:
  case MSYSFUN:
  case QQUADASSIGN:
  case RAVEL:
  case RHO:
  case RHORHO:
  case ROLL:
  case SORT:
  case TRANS:
    if (node->right != NILP)
      putnode(node->right);
    break;

  case DECODE:
  case INNERCHILD:
    if (node->left != NILP)
      putnode(node->left);
    if (node->right != NILP)
      putnode(node->right);
    if (STORE != NILP)
      putnode(node->store);
    break;

  case ASSIGN:
  case RESHAPEX:
  case CGOTO:
  case DQUADASSIGN:
  case DEAL:
  case DFORMAT:
  case DQQUADASSIGN:
  case DROP:
  case DSFUN:
  case DSYSFUN:
  case DTRANS:
  case ENCODE:
  case EPSILON:
  case ESYSFUN:
  case INDEXFN:
  case INDEXOF:
  case LINK:
  case MATCH:
  case MSOLVE:
  case OUTER:
  case RESHAPE:
  case SUB:
  case TAKE:
  case GWTAKE:
  case GWDROP:
    putnode(node->left);
    putnode(node->right);
    break;
  }
}

/* read nodes */
struct node *
innode(void)
{
  struct node *node;

  /* try to allocate space */
  node = structalloc(node);

  if (node == (struct node *) 0)
    error("no room for parse tree");
  /* get stuff */
  freadn((char *) node, sizeof(struct node), (size_t)1, stdin);
#if 0
  fprintf(stderr, "[iotree] node->n.shape = %d\n", node->n.shape);
#endif
  /* read possible name */
  gets_safe(iname);
  node->namep = name_strcpy(iname);
  /* read possible assign name */
  gets_safe(iname);
  node->namea = name_strcpy(iname);

  switch (node->nodetype) {
  default:
    fprintf(stderr, "node type %d\n", node->nodetype);
    error("illegal node type input");

  case IDENT:
    break;

  case BCON:
  case ICON:
  case FNCON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case LCON:
  case SCON:
  case AVEC:
  case TCAV:
  case TYPECON:
  case QQUAD:
  case QUAD:
  case COMMENT:
    break;

  case EMPTSEMI:
    if (axisgiven(node->axis))
      node->axis = innode();
    break;

  case REDUCE:
  case REVERSE:
  case SCAN:
    if (axisgiven(node->axis))
      node->axis = innode();
    node->right = innode();
    break;

  case COMPRESS:
  case EXPAND:
  case ROTATE:
  case CAT:
  case LAM:
  case CATCH:
    node->left = innode();
    if (axisgiven(node->axis))
      node->axis = innode();
    node->right = innode();
    break;

  case APPLY:
  case COND:
  case FIDENT:
    if (LEFT != NILP)
      node->left = innode();
    if (RIGHT != NILP)
      node->right = innode();
    if (STORE != NILP)
      node->store = innode();
    break;

  case OPIDENT:
    if (node->funleft != NILP)
      node->funleft = innode();
    if (node->funright != NILP)
      node->funright = innode();
    if (LEFT != NILP)
      node->left = innode();
    if (RIGHT != NILP)
      node->right = innode();
    if (STORE != NILP)
      node->store = innode();
    break;

  case SM:
    if (LEFT != NILP)
      node->left = innode();
    if (axisgiven(node->axis))
      node->axis = innode();
    if (RIGHT != NILP)
      node->right = innode();
    break;

  case ASYSVAR:
  case SYSVAR:
    if (node->left != NILP)
      node->left = innode();
    if (node->right != NILP)
      node->right = innode();
    break;

  case SUBASSIGN:
    if (node->left != NILP)
      node->left = innode();
    if (node->right != NILP)
      node->right = innode();
    node->axis = innode();
    if (STORE != NILP)
      node->store = innode();
    break;

  case QUADASSIGN:
  case CIVEC:
  case COLLECT:
  case CCOLLECT:
  case CISCALAR:
  case CSCALAR:
  case CVEC:
  case DQUAD:
  case DOMINO:
  case DQQUAD:
  case BOX:
  case UNBOX:
  case EXECUTE:
  case FORMAT:
  case GO:
  case INNER:
  case IOTA:
  case MSFUN:
  case QQUADASSIGN:
  case RHO:
  case RHORHO:
  case ROLL:
  case MSYSFUN:
  case RAVEL:
  case SORT:
  case TRANS:
    if (node->right != NILP)
      node->right = innode();
    break;

  case DECODE:
  case INNERCHILD:
    if (node->left != NILP)
      node->left = innode();
    if (node->right != NILP)
      node->right = innode();
    if (STORE != NILP)
      node->store = innode();
    break;

  case ASSIGN:
  case RESHAPEX:
  case CGOTO:
  case DQUADASSIGN:
  case DEAL:
  case DFORMAT:
  case DQQUADASSIGN:
  case DROP:
  case DSFUN:
  case DSYSFUN:
  case DTRANS:
  case ENCODE:
  case EPSILON:
  case ESYSFUN:
  case INDEXFN:
  case INDEXOF:
  case LINK:
  case MATCH:
  case MSOLVE:
  case OUTER:
  case RESHAPE:
  case SUB:
  case TAKE:
  case GWTAKE:
  case GWDROP:
    node->left = innode();
    node->right = innode();
    break;
  }
  return (node);
}

/* free storage taken by node */
void
frenode(struct node * node)
{
#if IODEBUG
  fprintf(stderr, "[%s] %s [frenode] [%d], node %s\n", 
	  passname, funname, stmtno, prtoken(node->nodetype));
#endif
  switch (node->nodetype) {
    default:
    fprintf(stderr, "node type %d\n", node->nodetype);
    error("frenode: illegal node type freed");
    break;

  case IDENT:
  case BCON:
  case ICON:
  case FNCON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case LCON:
  case SCON:
  case AVEC:
  case TCAV:
  case TYPECON:
  case QQUAD:
  case QUAD:
  case COMMENT:
    break;

  case EMPTSEMI:
#if 0
    if (axisgiven(node->axis)) {
      fprintf(stderr,"[EMPTSEMI axis:%s]", prtoken(AXIS->nodetype)); 
      frenode(node->axis);
    }
#endif
    break;

  case REVERSE:
  case REDUCE:
  case SCAN:
    if (axisgiven(node->axis))
      frenode(node->axis);
    frenode(node->right);
    break;

  case COMPRESS:
  case EXPAND:
  case ROTATE:
  case CAT:
  case LAM:
  case CATCH:
    frenode(node->left);
    if (axisgiven(node->axis))
      frenode(node->axis);
    frenode(node->right);
    break;

  case APPLY:
  case COND:
  case FIDENT:
    if (LEFT != NILP)
      frenode(node->left);
    if (RIGHT != NILP)
      frenode(node->right);
    if (STORE != NILP)
      frenode(node->store);
    break;

  case OPIDENT:
    if (node->funleft != NILP)
      frenode(node->funleft);
    if (node->funright != NILP)
      frenode(node->funright);
    if (LEFT != NILP)
      frenode(node->left);
    if (RIGHT != NILP)
      frenode(node->right);
    if (STORE != NILP)
      frenode(node->store);
    break;

  case SM:
    if (LEFT != NILP) {
#if IODEBUG
      fprintf(stderr,"[SM left: %s]", prtoken(LEFT->nodetype)); 
#endif
      frenode(node->left);
    }
    /*
    if (AXIS != NILP)
      frenode(node->axis);
    */
    if (RIGHT != NILP) {
#if IODEBUG
      fprintf(stderr,"[SM right:%s]", prtoken(RIGHT->nodetype)); 
#endif
      frenode(node->right);
    }
    break;

  case ASYSVAR:
  case SYSVAR:
    if (node->left != NILP)
      frenode(node->left);
    if (node->right != NILP)
      frenode(node->right);
    break;

  case SUBASSIGN:
    frenode(node->left);
    frenode(node->right);
    frenode(node->axis);
    frenode(node->store);
    break;

  case QUADASSIGN:
  case CISCALAR:
  case CIVEC:
  case COLLECT:
  case CCOLLECT:
  case CSCALAR:
  case CVEC:
  case DQQUAD:
  case DQUAD:
  case DOMINO:
  case BOX:
  case UNBOX:
  case EXECUTE:
  case FORMAT:
  case GO:
  case INNER:
  case IOTA:
  case MSFUN:
  case MSYSFUN:
  case QQUADASSIGN:
  case RAVEL:
  case RHO:
  case RHORHO:
  case ROLL:
  case SORT:
  case TRANS:
    frenode(node->right);
    break;

  case DECODE:
    frenode(node->left);
    frenode(node->right);
    frenode(node->store);
    break;

  case ASSIGN:
  case RESHAPEX:
  case CGOTO:
  case DQUADASSIGN:
  case DQQUADASSIGN:
  case DSFUN:
  case DEAL:
  case DFORMAT:
  case DROP:
  case DSYSFUN:
  case DTRANS:
  case ENCODE:
  case EPSILON:
  case ESYSFUN:
  case INDEXFN:
  case INDEXOF:
  case INNERCHILD:
  case LINK:
  case MATCH:
  case MSOLVE:
  case OUTER:
  case RESHAPE:
  case SUB:
  case TAKE:
  case GWTAKE:
  case GWDROP:
    frenode(node->left);
    frenode(node->right);
    break;
  }
  free((char *) node);
}

/* sws  collect code writing functions 6/91
   used in pass.c
   aplparse.c (parser) */
extern void
writecode(int top, struct headnode * head,
	  struct symnode * syms, struct statenode * code)
{
#ifdef CHARINT
  printf("\n");
  putcharn((char) top);
  printf("\n");
#else
  putcharn((char) top);
#endif
  putheader(head);
#if IODEBUG
  fprintf(stderr, "[writecode] %s symtab\n", funname);
  print_symtab(stderr, syms);
#endif
  putsyms(syms);
  putconsts();
  putcode(code);
  return;
}

/* sws

Test for flag to pipe intermediate results as integers rather than
characters. For dos text file mode.

The functions are used in: iotree.c, pass.c, psym.c

*/

#ifdef CHARINT
/* sws */
/* write c*n chars as ints */
void
fwriten(char *p, int n, int c, FILE * iop)
{
  int i, s;

  s = n * c;
  for (i = 0; i < s; i++) {
    /* (void) fprintf(iop,"%5d",*(p+i) ); */
    printf("%5d", *(p + i));
  }
  return;
}

/* sws */
/* put a single char as an int */
void
putcharn(char c)
{
  printf("%5d ", c);
}

/* sws */
/* read n*c chars as ints */
void
freadn(char *p, int n, int c, FILE * iop)
{
  int i, val, s;

  s = n * c;
  for (i = 0; i < s; i++) {
    /* (void) fscanf(iop,"%d", &val );*/
    scanf("%d", &val);
    *(p + i) = val;
    /* (void) fprintf(stderr,"freadn charn is %d \n",val ); */
  }
  return;
}

/* sws */
/* get a single char as an int */
int
getcharn(void)
{
  int val;

  if (scanf("%d", &val) != EOF) {
    /* (void) fprintf(stderr,"charn is %d\n",val ); */
    return (val);
  }
  return (int) EOF;
}

#endif /* #ifdef CHARINT */

/* end of iotree.c */
