/*
	APL Compiler

	utilities used in code generation
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/
#include "parse.h"
#include "y_tab.h"
#include "gen.h"
#include <stdio.h>


/* copychild - copy information for a child node into the parent node */
void
copychild(struct node * node, struct node * child,
    int type, int rank, int shape)
{
  if (type && !(node->n.info & TYPEKNOWN))
    node->c.type = child->c.type;
  if (rank && !(node->n.info & RANKKNOWN))
    node->c.rank = child->c.rank;
  if (shape && !(node->n.info & SHAPEKNOWN))
    node->c.shape = child->c.shape;
}

/* sws coptype  print which codeop we have */
char *
str_coptype(enum codeops cop)
{
  switch (cop) {
  case coasgn:
    return "assignment";
    break;

  case castop:
    return "cast operator";
    break;

  case coconst:
    return "constants - index into constant tables";
    break;

  case condop:
    return "conditional operation";
    break;

  case dsfun:
    return "dyadic scalar ops";
    break;

  case deref:
    return "pointer dereference";
    break;

  case icnst:
    return "actual integer constant (not index)";
    break;

  case idptr:
    return "pointer to an identifier with fields";
    break;

  case coiptr:
    return "index register value";
    break;

  case coixorgin:
    return "index origin";
    break;

  case memptr:
    return "memory pointer";
    break;

  case msfun:
    return "monadic scalar ops";
    break;

  case postinc:
    return "postincrement (for pointers)";
    break;

  case resptr:
    return "result register pointer";
    break;

  case tcnst:
    return "type constant";
    break;

  case trsptr:
    return "type";
    break;

  case trsvptr:
    return "trs.value pointer";
    break;

  default:
    return "unknown codeop\n";
    break;
  }
  return "unknown codeop\n";
}


void
coptype(enum codeops cop)
{
  printf( "/* %s */\n", str_coptype(cop));
  return;
}
#if 0
void
coptype(enum codeops cop)
{
  switch (cop) {

    case coasgn:
    printf("/* assignment */\n");
    break;

  case castop:
    printf("/* cast operator */\n");
    break;

  case coconst:
    printf("/* constants - index into constant tables */\n");
    break;

  case condop:
    printf("/* conditional operation */\n");
    break;

  case dsfun:
    printf("/* dyadic scalar ops */\n");
    break;

  case deref:
    printf("/* pointer dereference */\n");
    break;

  case icnst:
    printf("/* actual integer constant (not index) */\n");
    break;

  case idptr:
    printf("/* pointer to an identifier with fields */\n");
    break;

  case coindex:
    printf("/* vector index (L)[(R)] */\n");
    break;

  case coiptr:
    printf("/* index register value */\n");
    break;

  case coixorgin:
    printf("/* index origin */\n");
    break;

  case memptr:
    printf("/* memory pointer */\n");
    break;

  case msfun:
    printf("/* monadic scalar ops */\n");
    break;

  case postinc:
    printf("/* postincrement (for pointers) */\n");
    break;

  case resptr:
    printf("/* result register pointer */\n");
    break;

  case tcnst:
    printf("/* type constant */\n");
    break;

  case trsptr:
    printf("/* type */\n");
    break;

  case trsvptr:
    printf("/* trs.value pointer */\n");
    break;

  default:
    printf("unknown codeop\n");
    break;
  }
}
#endif

/* gcant_happen - something that can't happen just did */
void
gcant_happen(char *s, int n)
{
  /*  fprintf(stderr, "[%s] during code generation, impossible condition %d\n",
      s, n);*/
  fprintf(stderr, "%s [%d][%s] during code generation, impossible condition %d\n",
	  funname, stmtno, s, n);
  /*exit(1);*/
  error("can't happen");
  return;
}

/* moved to nutil.c */
/* rtype - return the constant known type of a node */
#if 0
int
rtype(struct node * node)
{
  if (!(node->n.info & TYPEKNOWN))
    return (APLC_UKTYPE);
  if ((node->c.type)->cop != tcnst) {
    fprintf(stderr,"[rtype] typeknown, (node->c.type)->cop [%s] != tcnst\n",
	    str_coptype((node->c.type)->cop)); 
    gcant_happen("rtype", 10);
  }
  return ((node->c.type)->c0.cindex);
}
#endif

/* rankvalue - return the constant known rank of a node */
int
rankvalue(struct node * node)
{
  if (!(node->n.info & RANKKNOWN)) {
    fprintf(stderr,"[rankvalue] nodetype %d %s", 
	    node->nodetype, prtoken(node->nodetype));
    if ( (node->nodetype == IDENT) ||
	 (node->nodetype == FIDENT) ||
	 (node->nodetype == OPIDENT) )
      fprintf(stderr," (%s)\n", node->namep);
    else
      fprintf(stderr,"\n");
    print_info(stderr, &(node->n));
    gcant_happen("rankvalue", 111);
  }
  if (! node->c.rank )
    gcant_happen("rankvalue", 112);
  if ((node->c.rank)->cop != icnst) {
    fprintf(stderr,"[rankvalue] nodetype %d %s", 
	    node->nodetype, prtoken(node->nodetype));
    if ( (node->nodetype == IDENT) ||
	 (node->nodetype == FIDENT) ||
	 (node->nodetype == OPIDENT) )
      fprintf(stderr," (%s)\n", node->namep);
    else
      fprintf(stderr,"\n");
    print_info(stderr, &(node->n));
    gcant_happen("rankvalue", 10);
  }
  return ((node->c.rank)->c0.cindex);
}

/* shapevalue - return the constant known shape of a node */
/* sws   return value position is start location in iconsts */
int
shapevalue(struct node * node)
{
  struct codetree *child;

  if (!(node->n.info & SHAPEKNOWN))
    gcant_happen("shapevalue", 112);
  if ((node->c.shape)->cop != coconst)
    gcant_happen("shapevalue", 10);
  child = (node->c.shape)->c0.cleft;
  if (child->cop != icnst)
    gcant_happen("shapevalue", 1112);
  return (child->c0.cindex);
}

/* valvalue - return the constant offset of a known value */
int
valvalue(struct node * node)
{
  struct codetree *child;

  if (!(node->n.info & VALUESKNOWN))
    gcant_happen("valvalue", 113);
  if ((node->c.values)->cop != coconst)
    gcant_happen("valvalue", 10);
  child = (node->c.values)->c0.cleft;/* jbww UKC 6/87 */
  /* child = (node->c.shape)->c0.cleft;                   */
  if (child->cop != icnst)
    gcant_happen("valvalue", 1112);
  return (child->c0.cindex);
}

/* sws */
/* is_zilde - return true if a node is a known zilde ( .iota 0 or '') */
int
is_zilde(struct node * node)
{
  if ((node->n.info & RANKKNOWN) && (rankvalue(node) == 1)) {
    if (node->n.info & SHAPEKNOWN) {
      if (0 == iconsts[shapevalue(node)])
	return (1);
    }
  }
  return (0);
}

/* is_scalar - return true if a node is a known scalar */
int
is_scalar(struct node * node)
{
  if ((node->n.info & RANKKNOWN) && (rankvalue(node) == 0))
    return (1);
  return (0);
}

/* isnot_scalar - return true if a node is known not to be a scalar */
int
isnot_scalar(struct node * node)
{
  if ((node->n.info & RANKKNOWN) && (rankvalue(node) != 0))
    return (1);
  return (0);
}

/* is_singleton - return true if a node is a known scalar or vector of
                  length 1 
*/ 
int 
is_singleton(struct node * node) 
{ 
  if (is_scalar(node)) 
    return (1); 
  if ((node->n.info & RANKKNOWN) && (rankvalue(node) == 1)) 
    if (node->n.info & SHAPEKNOWN) 
      if (1 == iconsts[shapevalue(node)]) 
	return (1); 
  return (0); 
}

/* isnot_singleton - return true if a node is 
   known to be not a singleton (scalar or vector of length 1) 
*/ 
int 
isnot_singleton(struct node * node) 
{ 
  if (node->n.info & RANKKNOWN) {
    if (rankvalue(node) == 0 ) 
      return (0); 
    if (rankvalue(node) == 1 ) {
      if (node->n.info & SHAPEKNOWN) 
	if (1 < iconsts[shapevalue(node)]) 
	  return (1); 
      return (0); 
    }
    if (rankvalue(node) > 1 ) 
      return (1); 
  }
  return (0); 
}

/* is_vector - return true is a node is a known vector */
int
is_vector(struct node * node)
{
  if ((node->n.info & RANKKNOWN) && (rankvalue(node) == 1))
    return (1);
  return (0);
}

/* adjdcls - adjust declarations to tree form */
void
adjdcls(struct node * node)
{
  if (node->n.info & TYPEKNOWN) {
    if (APLC_ANY == node->n.type) {
      /* APLC_ANY case - type not really known */
      node->n.info ^= TYPEKNOWN;
      node->n.type = APLC_UKTYPE;
    } else
      node->c.type = gicn(tcnst, node->n.type, APLC_INT);
  }
  if (node->n.info & RANKKNOWN) {
    if (ANYRANK == node->n.rank) {
      /* ANYRANK case - rank not really known */
      node->n.info ^= RANKKNOWN;
      if (node->n.info & RANKDECL)
	node->n.info ^= RANKDECL;
      node->n.rank = NORANK;
      if (node->n.info & SHAPEKNOWN)
	node->n.info ^= SHAPEKNOWN;    /* remove possible shape info */
    } else
      node->c.rank = gicn(icnst, node->n.rank, APLC_INT);
  }
  if (node->n.info & SHAPEKNOWN) {
    node->c.shape = gcast(coconst, 
			  gicn(icnst, node->n.shape, APLC_INT), APLC_INT);
  }
  if (node->n.info & VALUESKNOWN) {
    switch(node->n.type) {
    case APLC_FNP:
      /* setup value = fn name */
      node->c.values = gstring( fnconsts[ node->n.values ]  );
      break;
    case APLC_LABEL:
      /* here we have actual values, but not a list l_main[k] */
      node->c.values = gicn(icnst, lconsts[node->n.values].label_num, 0);
      break;
    default:
      /* setup an index into the values
	 e.g. i_main[k] */
      node->c.values = gcast(coconst, 
			     gicn(icnst, node->n.values, APLC_INT), rtype(node));
      break;
    }
  }
  return;
}

/* resinreg - make sure a value is in a register, putting it there if
              necessary.  Return the number of the register it is in 
*/

int
resinreg(struct node * node, int regval)
{
  struct codetree *tree;

  tree = node->c.values;
  if (tree->cop == resptr)
    return (tree->c0.cindex);
  else { 
    /* put into register */
    ctgen(gbin(coasgn,
	    gicn(resptr, regval, rtype(node)),
	    node->c.values));
    seminl();
    node->c.values = gicn(resptr, regval, rtype(node));
  }
  return (regval);
}

/* ksize - return the size of a known shape node 
   - assumes rank and shape are known
 */
int
ksize(struct node * node)
{
  int rank, pos, size, j;

  rank = rankvalue(node);
  pos = shapevalue(node);
  size = 1;
  for (j = rank - 1; j >= 0; j--)
    size *= iconsts[pos + j];
  return (size);
}

/* getsize - generate code to 
   get the size of the node and put it into ptr i*/
void
getsize(int i, struct node * node)
{
  int rank;

  if ((node->n.info & RANKKNOWN) &&
      ((node->c.rank)->cop == icnst)) {
    rank = (node->c.rank)->c0.cindex;
    if (rank == 0) {
      seticon(i, 1);
      return;
    }
    if (node->n.info & SHAPEKNOWN) {
      seticon(i, ksize(node));
      return;
    }
    if (rank == 1) {
      ieq(i);
      ctgen(gmon(deref, node->c.shape));
      seminl();
      return;
    }
  }
  printf("i%d = aplc_vsize(", i);
  rns(node);
  rpseminl();
}

/* getsizeval - generate code to 
   just get the size of the node */
void
getsizeval(struct node * node)
{
  int rank;

  if ((node->n.info & RANKKNOWN) && ((node->c.rank)->cop == icnst)) {
    rank = (node->c.rank)->c0.cindex;
    if (rank == 0) {
      printf("1");
      return;
    }
    if (node->n.info & SHAPEKNOWN) {
      printf("%d", ksize(node));
      return;
    }
    if (rank == 1) {
      ctgen(gmon(deref, node->c.shape));
      return;
    }
  }
  printf("aplc_vsize(");
  rns(node);
  rp();
}

/* fixzero - make an uninitialized zero node */
void
fixzero(void)
{
  zeronode->nodetype = ICON;
  zeronode->n.info = (TYPEKNOWN | RANKKNOWN | SHAPEKNOWN | VALUESKNOWN);
  zeronode->n.type = APLC_INT;
  zeronode->n.rank = 0;  
  zeronode->n.shape = 0; 
  zeronode->c.type = gicn(tcnst, APLC_INT, APLC_INT);
  zeronode->c.rank = gicn(icnst, 0, APLC_INT);
  zeronode->c.shape = gcast(coconst, gicn(icnst, 1, APLC_INT), APLC_INT);
  zeronode->c.values = gicn(icnst, 0, APLC_INT);
}

/* cpshape - copy a shape vector into a new vector */

extern void
cpshape(int memval, struct node * node)
{
  if (is_vector(node)) {
    printf("*mp%d.ip = ", memval);
    ctgen(gmon(deref, node->c.shape));
    seminl();
  } else {
    /* sws  add runtime check to make sure we don't have a singleton */
    /*- want
	"if ( singleton )"
          if ( rank = 0 or (rank=1 and shape=1) ) {
 	     mp = 1;
	     }
	  else {
	   cpvec
	  }
	  */
    printf("if ");
    singleton(node);
    printf("\n*mp%d.ip = 1;\n", memval);
    elsebr();
    /* else */
    printf("aplc_cpvec(mp%d.ip, ", memval);
    rns(node);
    rpseminl();
    printf("}\n");
  }
}

/* mktmatch - make sure a given type matches another node type */
void
mktmatch(struct node * want, struct node * have, int reg)
{
  if (want->n.info & TYPEKNOWN)
    mkrktype(have, rtype(want), reg);
  else {
    reg = resinreg(have, reg);
    if (!cteq(want->c.type, have->c.type)) {
      printf(" /* mkmatch type check */\n");
      printf("aplc_cktype(&res%d, ", reg);
      ctgen(want->c.type);
      commasp();
      ctgen(have->c.type);
      rpseminl();
    }
    have->c.values = gicn(resptr, reg, APLC_UKTYPE);
  }
}

/* end of cutil.c */






