/*
	APL compiler
		parser symbol table routines
		timothy a. budd

	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include <stdio.h>
#include "parse.h"
#include "psym.h"
#include "y_tab.h"

/* set to 1 for debuging prints */
#define DEBUG 1

/***********************
	SYMBOL TABLES
************************/

/* externs */
/* local table -- different for different fns 
   may need to have several at once */
struct symnode **lsymtab;
/* globals - doesn't change */
struct symnode **gsymtab;

/* from y_tab.h */
extern void yyerror(char *c);

extern void 
print_all_symtab(void)
{
  int i;
  fprintf(stderr,"------\n");
  fprintf(stderr,"[symtab] current depth %d\n", prog_depth);
  for (i=0; i<MAX_PROG_DEPTH; i++) {
    fprintf(stderr,"--- symbol table depth(%d):\n", i);
    print_symtab(stderr, progs[i].symtabs);
    fprintf(stderr,"------\n");
  }
  return;
}  

/* init:
   depth 0 or 1  g = 0,    l = 1 
   depth 2       g = 0,    l = 2 
   depth 3       g = 0,    l = 3 

*/
extern void
init_symtabs(void) 
{
  int i;

  for (i=1; i<MAX_PROG_DEPTH; i++)
    progs[i].symtabs = NILSYM;
  gsymtab = &(progs[0].symtabs);
  lsymtab = &(progs[1].symtabs);
#if DEBUG
  fprintf(stderr,"[init_symtab]\n");
#endif
  return;
}

/* 
   only do something if 1->2 or 2->3, 
   in which case we set and init the local symbol table

   - note that when depth = 0, the parser may enter params into 
     the local symbol table, as headpar comes after params 
   - this may need FIXING someday...
*/
extern void
push_lsymtab(void)
{
  if (prog_depth > 1) {
    lsymtab = &(progs[prog_depth].symtabs);
    /**lsymtab  = NILSYM;*/
  }
#if DEBUG
  fprintf(stderr,"[push_lsymtab] prog_depth == %d\n", prog_depth);
  print_all_symtab();
#endif  
  return;
}

/* drop down a level of the local table
   only change ltable level if 3->2 or 2->1 */
extern void
pop_lsymtab(void)
{
  if (prog_depth > 0) {
    /* drop down the local table */
    lsymtab = &(progs[prog_depth].symtabs);
  }
    
#if DEBUG
  fprintf(stderr,"[pop_lsymtab] prog_depth == %d\n", prog_depth);
  print_symtab(stderr, *lsymtab);
#endif  
  return;
}


/* initialize local symbol tables */
extern void 
reinit_local_symtab(void)
{
  *lsymtab = 0;
  return;
}

/* lookup a name in the current symbol tables, 
   return the type of symbol, and table entry */
extern class_t
idclass(char *name, struct symnode ** symptr)
{
  struct symnode *p;
  int i;
  int looking = 1;

  i = prog_depth;
  while ( (i >= 0) && (looking) ) {
    p = lookup_name(name, progs[i].symtabs);
    if (p != NILSYM) {
      looking = 0;
      p->depth = i;
      *symptr = p;
#if DEBUG 
      fprintf(stderr,"[idclass] found (%s) at depth %d (current %d)\n", name, i, prog_depth);
#endif
      return p->class;
    }
    i--;
  }
  /* not found */
  *symptr = NILSYM;
#if DEBUG 
  fprintf(stderr,"[idclass] (%s) not found, current depth %d\n", 
          name, prog_depth);
#endif
  return (NOCLASS);
}

#if 0
/* old version - 2 level scope */
extern class_t
idclass_old(char *name, struct symnode ** symptr)
{
  struct symnode *p;

  p = lookup_name(name, *lsymtab);
  if (p != NILSYM) {
      p->depth = prog_depth;
    *symptr = p;
#if DEBUG 
    fprintf(stderr,"[idclass] found (%s) local\n", name);
#endif
    return p->class;
  }
  p = lookup_name(name, *gsymtab);
  if (p != NILSYM) {
    p->depth = 0;
    *symptr = p;
#if DEBUG 
    fprintf(stderr,"[idclass] found (%s) global\n", name);
#endif
    return p->class;
  }
  *symptr = NILSYM;
#if DEBUG 
  fprintf(stderr,"[idclass] (%s) not found\n", name);
#endif
  return (NOCLASS);
}
#endif

extern struct symnode *
id_lookup_fn(char *file, int line, struct node *x)
{
  struct symnode *s;

#if FILE_LINE_DEBUG
  fprintf(stderr, "[id_lookup]  file %s, line %d ", file, line);
#endif
  if (!x)
    yyerror("bad zero node in id_lookup\n");
  if (x->nodetype == FNCON)
    idclass(  fnconsts[ x->n.values ], &s);
  else {
    fprintf(stderr, "lookup node %s ", prtoken(x->nodetype));
    yyerror("bad node in id_lookup\n");
  }
  return s;
}

#if 0
/* rmglob - remove a global identifier from local symbol table */
static void 
rmglob(char *name, struct symnode * newp)
{
  struct symnode *oldp;

  oldp = lookup_name(name, *lsymtab);
  if (oldp != NILSYM) {
    oldp->name = '\0';
    if (oldp->s.type != APLC_UKTYPE)
      newp->s.type = oldp->s.type;
    if (oldp->s.rank != NORANK)
      newp->s.rank = oldp->s.rank;
  }
}
#endif

/* enterid - enter a new id into the current symbol tables 
   - also sometimes add info to stream output */
extern struct symnode *
enterid_fn(char *file, int line, 
           char *name, class_t class, int type, int rank, int valence) 
{
  struct symnode *x = NILSYM;

#if DEBUG 
  fprintf(stderr,"[enterid] (%s %d)", file, line);

  switch (class) {
  case LABCLASS:
  case PARAM:
  case APARAM:
  case LOCAL:
  case LFUNCTION:
    fprintf(stderr," (%s) %s, %s, type %s, rank %s, valence %d\n", 
	    funname,
	    name, str_class(class), str_type_name(type), str_rank(rank),
            valence);
    break;
  default:
  case FUNCTION:
  case OPERATOR:
  case GLOBAL:
    fprintf(stderr," (main) %s, %s, type %s, rank %s, valence %s, optype %s\n", 
	    name, str_class(class), str_type_name(type), str_rank(rank),
            str_valence(valence),str_optype(valence));
    break;
  }
#endif
  switch (class) {
  case LABCLASS:
    /* add lable to local symbol table */
    /* not used
       x = add_sym(name,lsymtab, NILCHAR,lsymtab, class, APLC_LABEL, 0);*/
    yyerror("labclass enterid\n");
    break;
  case PARAM:
  case LOCAL:
  case LFUNCTION:
    /* add a param or local variable (or local fn?) to local table */
    x = add_sym(name,lsymtab, NILCHAR,lsymtab, class, type, rank, valence);
    break;
  case APARAM:
    /* add an assigned param to local table 
       - also lookup the current function name attributes */
    x = add_sym(name,lsymtab, funname,gsymtab, class, type, rank, NOVALENCE);
    break;
  case FUNCTION:
  case OPERATOR:
    /* add a fn or op to the global table */
    x = add_sym(name,gsymtab, NILCHAR,gsymtab, class, type, rank, valence);
    break;
  case GLOBAL:
    /* add a name to the global table */
    x = lookup_name(name, *gsymtab);
    if (x == NILSYM)
      putcharn(GLSYM);
    printf("%s\n", name);
    /* sws  */
    x = add_sym(name,gsymtab, NILCHAR,lsymtab, class, type, rank,valence);
    /*rmglob(name, x);*/
    break;
  default:
    yyerror("unknown case in enterid\n");
  }
#if DEBUG
  fprintf(stderr," [enterid] done, final g table:\n");
  print_symtab(stderr, *gsymtab);
  fprintf(stderr," [enterid] done, final l table:\n");
  print_symtab(stderr, *lsymtab);
  print_all_symtab();
#endif
  return x;
}

/* get the fn/operator valence, given the header */
extern int 
get_fop_valence(headnode_t *head)
{
  return get_fop_valence_comp(head->parm1, head->rfname);
}

/* check a few parts of the header to determine the defined valence of
   an operator 
   left (lf op rf) right 
   - assume right is present (monadic)
   - assume lf (left function) is present (monadic) 
*/
extern int 
get_fop_valence_comp(char *left, char*rf)
{
  int val = 0;

  /* if we have a left value argument, it is used dyadicly */ 
  if (left)
    val |= O_V_AMBIVALENT;
  /* if we have a right function argument, it is used dyadicly */ 
  if (rf)
    val |= O_F_DYADIC;
  val |= O_VALENCE;
  return val;
}


/* end of psym.c */

