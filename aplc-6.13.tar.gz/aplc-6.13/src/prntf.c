/* sws 


   prints out a description of the tree to stdout (vs stderr)
   expect to call this with -n 


 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

/* can recall the old behavior by changing this to stderr */
/* define PRTFILE stderr */
#define PRTFILE stdout

#include "parse.h"
#include "y_tab.h"
#include <stdio.h>


/* declarations */

void prnttrs(struct node * node);
void prntaxis(struct node * node, int indent_level);
void prntnode(struct node * node, int indent_level);
void prnodetype(struct node * node, int level);
void prsfuns(struct node * node);
void prsysvar(struct node * node);

/* extern int fprintf(FILE *, const char *,...);*/

/* passinit - initialize this pass (do nothing) */
void
passinit(int verbose)
{
  passname = "prntf";
  return;
}

/* glbvar - process a global variable name */
void
glbvar(char *name)
{
  return;
}

/* main program */
void
doprog(int type, struct headnode *head, struct symnode *syms,
       struct statenode *code)
{
  /*struct symnode *s;*/
  struct statenode *c;
  int i;

  switch(type) {
  default:
    /* should complain */
    fprintf(PRTFILE, "Unknown prog type %d\n", type);
    break;

  case MNPROG:
  case PROG:
    fprintf(PRTFILE, "\n\nFunction ");
    if (head == NILHEAD || head->opname == NILCHAR) {
      fprintf(PRTFILE, "main\n");
    } else {
      if (head->asvar != NILCHAR)
	fprintf(PRTFILE, "%s <- ", head->asvar);
      if (head->parm1 != NILCHAR)
	fprintf(PRTFILE, "%s ", head->parm1);
      fprintf(PRTFILE, "%s ", head->opname);
      if (head->parm2 != NILCHAR)
	fprintf(PRTFILE, "%s ", head->parm2);
      fprintf(PRTFILE, "\n");
    }
    break;
  case OPPROG:
    fprintf(PRTFILE, "\n\nOperator ");
    if (head->asvar != NILCHAR)
      fprintf(PRTFILE, "%s <- ", head->asvar);
    if (head->parm1 != NILCHAR)
      fprintf(PRTFILE, "%s ", head->parm1);
    fprintf(PRTFILE, "( ");    
    if (head->lfname != NILCHAR)
      fprintf(PRTFILE, "%s ", head->lfname);
    fprintf(PRTFILE, "%s ", head->opname);
    if (head->rfname != NILCHAR)
      fprintf(PRTFILE, "%s ", head->rfname);
    fprintf(PRTFILE, ") ");    
    if (head->parm2 != NILCHAR)
      fprintf(PRTFILE, "%s ", head->parm2);
    fprintf(PRTFILE, "\n");
    break;
  }
  /* symbol table */
  print_symtab(PRTFILE, syms);
  /* list resources */
  fprintf(PRTFILE,
	  "Counts: maxtrs = %d maxmp = %d maxres = %d maxi = %d\n",
	  head->maxtrs, head->maxmp, head->maxres, head->maxi);
#if 0
  /* list constants (ignore z, q for now) */
  fprintf(PRTFILE, "Constants: i[%d], r[%d], c[%d]\n", 
	  ictop, rctop, sctop);
#else
  fprintf(PRTFILE, "Constants: i[%d], r[%d], c[%d], z[%d], q[%d], o[%d] fn[%d]\n", 
	  ictop, rctop, sctop, zctop, qctop, octop, fnctop);
#endif
  fprintf(PRTFILE, "Label Constants: [%d]\n", lctop);

#if 1
  /* list */
  fprintf(PRTFILE, "int {"); 
  for (i=0; i<ictop; i++)
    fprintf(PRTFILE, "%d ", iconsts[i]);
  fprintf(PRTFILE, "}\n"); 

  fprintf(PRTFILE, "real {"); 
  for (i=0; i<rctop; i++)
    fprintf(PRTFILE, "%g ", rconsts[i]);
  fprintf(PRTFILE, "}\n"); 

  fprintf(PRTFILE, "complex {"); 
  for (i=0; i<zctop; i++)
    fprintf(PRTFILE, "(%g, %g) ", zconsts[0][i], zconsts[1][i]);
  fprintf(PRTFILE, "}\n"); 

  fprintf(PRTFILE, "quat {"); 
  for (i=0; i<qctop; i++)
    fprintf(PRTFILE, "(%g,%g,%g,%g) ", 
	    qconsts[0][i], qconsts[1][i], qconsts[2][i], qconsts[3][i]);
  fprintf(PRTFILE, "}\n"); 

  fprintf(PRTFILE, "oct {"); 
  for (i=0; i<octop; i++)
    fprintf(PRTFILE, "(%g,%g,%g,%g, %g,%g,%g,%g) ", 
	    oconsts[0][i], oconsts[1][i], oconsts[2][i], oconsts[3][i],
	    oconsts[4][i],oconsts[5][i],oconsts[6][i],oconsts[7][i]);
  fprintf(PRTFILE, "}\n"); 

  fprintf(PRTFILE, "fn {"); 
  for (i=0; i<fnctop; i++)
    fprintf(PRTFILE, "(%s)", fnconsts[i]); 
  fprintf(PRTFILE, "}\n"); 
#endif

  /* list labels */
  fprintf(PRTFILE, "labels:\n"); 
  for (i=0; i<lctop; i++) {
    if (lconsts[i].valid)
      fprintf(PRTFILE, "  [%d] %s: %d\n", i, lconsts[i].label_name, lconsts[i].label_num);
  }
  /* now march through the statements */
  stmtno = 0;
  for (c = code; c != NILSTATE; c = c->nextstate) {
    fprintf(PRTFILE, "\nStatement %d\n", ++stmtno);
    if (c->label != NILCHAR) {
      for (i=0; (i<lctop) && (stmtno != lconsts[i].label_num); i++)
	;
      if (i<lctop)
	fprintf(PRTFILE, "Labeled {%s:}\n", lconsts[i].label_name);
    }
    prntnode(c->code, 0);
  }

}

/* print trs header information for a node 
   not all of this will print sensible values due to unions
*/
void
prnttrs(struct node * node)
{
  fprintf(PRTFILE, " [node->n.info %o, node->n.oinfo %o] ", 
          node->n.info, node->n.oinfo);

  if (node->n.info & TYPEKNOWN)
    fprintf(PRTFILE, " TYPEKNOWN (%s)", str_type_name(node->n.type));
  /* fprintf(PRTFILE, " TYPEKNOWN (%s)", types[node->n.type]);*/
  if (node->n.info & RANKKNOWN) {
    fprintf(PRTFILE, " RANKKNOWN (");
    prnrank(PRTFILE, node->n.rank);
    fprintf(PRTFILE, ")");
  }
  if (node->n.info)
    fprintf(PRTFILE, "\n   ");
  if (node->n.info & TYPEDECL)
    fprintf(PRTFILE, " TYPEDECL ");
  if (node->n.info & RANKDECL)
    fprintf(PRTFILE, " RANKDECL ");
  if (node->n.info & SHAPEKNOWN) {
    /* fprintf(PRTFILE," SHAPEKNOWN %d", node->n.shape); */
    fprintf(PRTFILE, " SHAPEKNOWN (");
    print_shape(PRTFILE, &(node->n));
    fprintf(PRTFILE, ")");
  }
  if (node->n.info & VALUESKNOWN) {
    fprintf(PRTFILE, " VALUESKNOWN [%d]", node->n.values);
    fprintf(PRTFILE, " = ("); print_values(PRTFILE, &(node->n)); fprintf(PRTFILE, ")"); 
  }

  if (node->n.info & SEQUENTIAL)
    fprintf(PRTFILE, " SEQUENTIAL");
  if (node->n.info & HAVEVALUE)
    fprintf(PRTFILE, " HAVEVALUE");
  if (node->n.info & NOINDEX)
    fprintf(PRTFILE, " NOINDEX");
  if (node->n.info & MERGED)
    fprintf(PRTFILE, "\n    MERGED");
  if (node->n.info & ASSIGNP)
    fprintf(PRTFILE, "\n    ASSIGNP");
  if (node->n.info & EARLYBIND)
    fprintf(PRTFILE, "\n    EARLYBIND");
  if (node->n.info & HAVETRS)
    fprintf(PRTFILE, "\n    HAVETRS");
  if (node->n.info & SHAPEARB)
    fprintf(PRTFILE, "\n    SHAPEARB");
  if (node->n.info & ASSNAMEREF)
    fprintf(PRTFILE, "\n    ASSNAMEREF");
  if (node->n.info & ASSNAMEOK)
    fprintf(PRTFILE, "\n    ASSNAMEOK");

  fprintf(PRTFILE, "\n");
  /* note ptr0 is shared in a union, and may be junk */
  fprintf(PRTFILE, "\tindex= %d ptr0= %d tptr=  %d\nptr1= %d ptr2= %d ptr3= %d",
 node->index, node->ptr0, node->tptr, node->ptr1, node->ptr2, node->ptr3);
  fprintf(PRTFILE, " ptr4= %d ptr5= %d\n",
      node->ptr4, node->ptr5);
  fprintf(PRTFILE, "\tptr6= %d ptr7= %d ptr8= %d ptr9= %d",
      node->ptr6, node->ptr7, node->ptr8, node->ptr9);
  fprintf(PRTFILE, " ptr10= %d ptr11= %d ptr12= %d ptr13= %d\n",
      node->ptr10, node->ptr11, node->ptr12, node->ptr13);
  /* fprintf(PRTFILE, "\n node end \n"); */

}

void
prntaxis(struct node * node, int indent_level)
{
  if (node->axis != NILP)
    prntnode(node->axis, indent_level);
  else if (node->n.info & FIRSTAXIS)
    fprintf(PRTFILE, "\taxis along first position\n");
  else if (node->n.info & LASTAXIS)
    fprintf(PRTFILE, "\taxis along last position\n");
}


/* indent_level is
   indenting level, for prnodetype, adjusted in prntnode
 */
void
prntnode(struct node * node, int indent_level)
{
  if (node == NILP)
    error("node error");

  prnodetype(node, indent_level);
  /* next node will be indented one */
  indent_level++;

  switch (node->nodetype) {
  default:
    fprintf(PRTFILE, "[prntf] node type %d\n", node->nodetype);
    /* sws, type 0 gets used in SM axis... */
    /* error("illegal node type printed"); */
    break;

  case ASSIGN:
    fprintf(PRTFILE, " Assignment to %s", node->left->namep);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case BCON:
  case ICON:
  case FNCON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case SCON:
    fprintf(PRTFILE, " Constant ");
    prnttrs(node);
    break;

  case LCON:
    fprintf(PRTFILE, " Label Constant ");
    /* fprintf(PRTFILE, "(%d)\n", node->n.values);*/
    fprintf(PRTFILE, "(%s %d)\n", lconsts[node->n.values].label_name,
	    lconsts[node->n.values].label_num);
    prnttrs(node);
    break;

  case QUAD:
  case QQUAD:
    fprintf(PRTFILE, " Input quad ");
    prnttrs(node);
    break;

  case COMMENT:
  case EMPTSEMI:
    fprintf(PRTFILE, " Emptsemi or Comment ");
    prnttrs(node);
    break;

  case COLLECT:
  case CCOLLECT:
  case CIVEC:
  case CVEC:
  case CISCALAR:
  case CSCALAR:
    fprintf(PRTFILE, " Collect type %d ", node->nodetype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case COMPRESS:
  case EXPAND:
  case CAT:
  case LAM:
    fprintf(PRTFILE, " Compress expand cat or lam");
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case CATCH:
    fprintf(PRTFILE, " Catch");
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case DECODE:
    fprintf(PRTFILE, " Dyadic operator decode %d ",
	node->nodetype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "store\n");
    prntnode(node->store, indent_level);
    break;

  case APPLY:
    fprintf(PRTFILE, " Function Pointer call "); 
    /*if (node->namea != 0)
      fprintf(PRTFILE, " {%s}<- ", node->namea);*/
    if (LEFT != NILP) 
      fprintf(PRTFILE, "%s", prtoken(LEFT->nodetype)); 
    if (STORE != NILP) 
      fprintf(PRTFILE, " (%s", prtoken(STORE->nodetype)); 
    fprintf(PRTFILE, " {%s}) ", node->namep);
    if (RIGHT != NILP) 
      fprintf(PRTFILE, "%s", prtoken(RIGHT->nodetype)); 
    prnttrs(node);
    if (LEFT != NILP) {
      fprintf(PRTFILE, "[APPLY left]\n");
      prntnode(LEFT, indent_level);
    }
    if (RIGHT != NILP) {
      fprintf(PRTFILE, "[APPLY right]\n");
      prntnode(RIGHT, indent_level);
    }
    if (STORE != NILP) {
      fprintf(PRTFILE, "[APPLY store]\n");
      prntnode(STORE, indent_level);
    }
    break;

  case COND:
    fprintf(PRTFILE, " Conditional "); 
    fprintf(PRTFILE, " {%s} ", node->namep);
    if (LEFT != NILP) 
      fprintf(PRTFILE, "%s", prtoken(LEFT->nodetype)); 
    if (STORE != NILP) 
      fprintf(PRTFILE, " (%s)", prtoken(STORE->nodetype)); 
    if (RIGHT != NILP) 
      fprintf(PRTFILE, "%s", prtoken(RIGHT->nodetype)); 
    fprintf(PRTFILE, "\n");
    prnttrs(node);
    if (STORE != NILP) {
      fprintf(PRTFILE, "[COND store]\n");
      prntnode(STORE, indent_level);
    }
    if (LEFT != NILP) {
      fprintf(PRTFILE, "[COND left]\n");
      prntnode(LEFT, indent_level);
    }
    if (RIGHT != NILP) {
      fprintf(PRTFILE, "[COND right]\n");
      prntnode(RIGHT, indent_level);
    }
    break;

  case FIDENT:
    fprintf(PRTFILE, " Function call "); 
    if (node->namea != 0)
      fprintf(PRTFILE, " {%s}<- ", node->namea);
    if (LEFT != NILP) 
      fprintf(PRTFILE, "{alpha}");	    
    fprintf(PRTFILE, " {%s} ", node->namep);
    if (RIGHT != NILP) 
      fprintf(PRTFILE, "{omega}"); 
    else
      fprintf(PRTFILE, "[warning FIDENT w no right]"); 
    fprintf(PRTFILE, "; valence %s", str_valence(node->n.oinfo));
    prnttrs(node);
    if (LEFT != NILP) {
      fprintf(PRTFILE, "[FIDENT left]\n");
      prntnode(node->left, indent_level);
    }
    if (RIGHT != NILP) {
      fprintf(PRTFILE, "[FIDENT right]\n");
      prntnode(node->right, indent_level);
    }
    break;

  case OPIDENT:
    fprintf(PRTFILE, " Operator ");
    if (node->namea != 0)
      fprintf(PRTFILE, " {%s}<- ", node->namea);
    if (LEFT != NILP) 
      fprintf(PRTFILE, "{alpha}");	    
    if (node->funleft != NILP) {
      if ( node->n.oinfo & O_LF ) 
        fprintf(PRTFILE, "{f}");
      else
        fprintf(PRTFILE, "{beta}");
    }
    fprintf(PRTFILE, " {%s} ", node->namep);
    if (node->funright != NILP) {
      if ( node->n.oinfo & O_RF ) 
        fprintf(PRTFILE, "{g}");
      else
        fprintf(PRTFILE, "{psi}");
    }
    if (RIGHT != NILP) 
      fprintf(PRTFILE, "{omega}"); 
    fprintf(PRTFILE, "; type %s", str_optype(node->n.oinfo)); 
    fprintf(PRTFILE, "; valence %s", str_valence(node->n.oinfo));
#if 1
    printf("{valence %d, fdyadic %d, optype %d, LF %d, RF %d, vambiv %d}",
           node->n.oinfo & O_VALENCE,
           node->n.oinfo & O_F_DYADIC,
           node->n.oinfo & O_OPTYPE,
           node->n.oinfo & O_LF,
           node->n.oinfo & O_RF,
           node->n.oinfo & O_V_AMBIVALENT
           );
#endif
    prnttrs(node);
    if (node->funleft != NILP) {
      fprintf(PRTFILE, "[OPIDENT funleft]\n");
      prntnode(node->funleft, indent_level);
    }
    if (node->funright != NILP) {
      fprintf(PRTFILE, "[OPIDENT funright]\n");
      prntnode(node->funright, indent_level);
    }
    if (LEFT != NILP) {
      fprintf(PRTFILE, "[OPIDENT left]\n");
      prntnode(node->left, indent_level);
    }
    if (RIGHT != NILP) {
      fprintf(PRTFILE, "[OPIDENT right]\n");
      prntnode(node->right, indent_level);
    }
    break;

  case IDENT:
    fprintf(PRTFILE, " Identifier ");
    /* check to see if just a storage node ...use sm now */
    if (node->namep != NILCHAR)
      fprintf(PRTFILE, "%s", node->namep);
    else
      fprintf(PRTFILE, "(storage)");
    prnttrs(node);
    break;

  case INNER:
    fprintf(PRTFILE, " Inner, op %d", node->optype);
    prsfuns(node);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case INNERCHILD:
    fprintf(PRTFILE, " Dyadic operator Innerchild %d, optype %d",
	    node->nodetype, node->optype);
    prsfuns(node);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "store\n");
    prntnode(node->store, indent_level);
    break;

  case IOTA:
    fprintf(PRTFILE, " Iota ");
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case MSFUN:
    fprintf(PRTFILE, " MSFUN %d ", node->optype);
    prsfuns(node);
    prnttrs(node);
    prnodetype(node, indent_level);
    prsfuns(node);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case REVERSE:
    fprintf(PRTFILE, " Reverse");
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case REDUCE:
  case SCAN:
    fprintf(PRTFILE, " Reduce or Scan");
    prsfuns(node);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case ROTATE:
    fprintf(PRTFILE, " Rotate %d ", node->nodetype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    break;

  case SM:
    fprintf(PRTFILE, " Sm [;]\n");
    prnttrs(node);
    if (LEFT != NILP) {
      prnodetype(node, indent_level);
      fprintf(PRTFILE, "left\n");
      prntnode(node->left, indent_level);
    }
    if (RIGHT != NILP) {
      prnodetype(node, indent_level);
      fprintf(PRTFILE, "right\n");
      prntnode(node->right, indent_level);
    }
    if (node->axis != NILP) {
      prnodetype(node, indent_level);
      fprintf(PRTFILE, "axis\n");
      prntnode(node->axis, indent_level);
    }
    break;

  case SUBASSIGN:
    fprintf(PRTFILE, " Sub assignment to %s", node->left->namep);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "store\n");
    prntnode(node->store, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntnode(node->axis, indent_level);
    break;

  case AVEC:
    fprintf(PRTFILE, " Atomic vector ");
    prnttrs(node);
    break;

  case ASYSVAR:
    fprintf(PRTFILE, " system variable %d ", node->nodetype);
    prsysvar(node);
    fprintf(PRTFILE, " {%d} ", node->optype);
    prnttrs(node);
    if (node->right != NILP) {
      prnodetype(node, indent_level);
      fprintf(PRTFILE, "right\n");
      prntnode(node->right, indent_level);
    }
    break;

  case SYSVAR:
    if (node->left != NILP) {
      /* dyadic function */
      fprintf(PRTFILE, " Dyadic system function %d ", node->optype);
      prnttrs(node);
      prnodetype(node, indent_level);
      fprintf(PRTFILE, "left\n");
      prntnode(node->left, indent_level);
      if (node->right != NILP) {
	prnodetype(node, indent_level);
	fprintf(PRTFILE, "right\n");
	prntnode(node->right, indent_level);
      } else
	fprintf(PRTFILE, "[error: SYSVAR right missing] ");
    } else if (node->right != NILP) {
      /* monadic function */
      fprintf(PRTFILE, " Monadic system function %d",
	  node->optype);
      prnttrs(node);
      prntnode(node->right, indent_level);
    } else {
      /* niladic, must be a system variable */
      fprintf(PRTFILE, " Sysvar %d ", node->optype);
      prsysvar(node);
      prnttrs(node);
    }
    break;

  case TCAV:
    fprintf(PRTFILE, " Sysvar %d ", node->optype);
    prsysvar(node);
    prnttrs(node);
    break;

  case TYPECON:
    fprintf(PRTFILE, " Typecon %d ", node->optype);
    prsysvar(node);
    prnttrs(node);
    break;

  case QUADASSIGN:
  case DQQUAD:
  case DQUAD:
  case DOMINO:
  case BOX:
  case UNBOX:
  case EXECUTE:
  case FORMAT:
  case GO:
  case QQUADASSIGN:
  case RAVEL:
  case RHO:
  case RHORHO:
  case ROLL:
  case SORT:
  case TRANS:
    fprintf(PRTFILE, " Monadic operator %d ", node->nodetype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case MSYSFUN:
    fprintf(PRTFILE, " Monadic operator %d ", node->nodetype);
    prsysvar(node);
    fprintf(PRTFILE, " {%d} ", node->optype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case DSFUN:
    fprintf(PRTFILE, " DSFUN %d ", node->optype);
    prsfuns(node);
    prnttrs(node);
    prnodetype(node, indent_level);
    prsfuns(node);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    prsfuns(node);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case RESHAPEX:
  case DQUADASSIGN:
  case DQQUADASSIGN:
  case DEAL:
  case DFORMAT:
  case DROP:
  case DTRANS:
  case ENCODE:
  case EPSILON:
  case INDEXFN:
  case INDEXOF:
  case LINK:
  case MATCH:
  case MSOLVE:
  case OUTER:
  case RESHAPE:
  case SUB:
  case TAKE:
  case GWTAKE:
  case GWDROP:
    fprintf(PRTFILE, " Dyadic operator %d ", node->nodetype);
    prnttrs(node);
    if (node->namea != 0)
      fprintf(PRTFILE, " {%s}<- ", node->namea);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case DSYSFUN:
    /* esysfun currently unused */
  case ESYSFUN:
    fprintf(PRTFILE, " Dyadic operator %d ", node->nodetype);
    prsysvar(node);
    fprintf(PRTFILE, " {%d} ", node->optype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;
  }
}

/* sws
   print out node type */
void
prnodetype(struct node * node, int level)
{
  int i;

  if (node == NILP)
    error("prnodetype node error");
  for (i = 0; i < level; i++)
    fprintf(PRTFILE, "-");
  fprintf(PRTFILE, "%s", prtoken(node->nodetype));
}

/* sws
   print out sfuns type
   enum sfuns in aplc.h
*/
void
prsfuns(struct node * node)
{
  fprintf(PRTFILE, "{%s}", str_sfun(node->optype));
  return;
}

/* sws
   print out sysvar or function name
   enum sysvars in aplc.h
*/
void
prsysvar(struct node * node)
{
  switch (node->optype) {
  default:
    fprintf(PRTFILE, "[prsysvars] unknown type ");
    break;

  case SYS_ARG:
    fprintf(PRTFILE, "{ARG}");
    break;
  case SYS_IO:
    fprintf(PRTFILE, "{IO}");
    break;
  case SYS_PP:
    fprintf(PRTFILE, "{SYS_PP}");
    break;
  case SYS_PRNG:
    fprintf(PRTFILE, "{PRNG}");
    break;
  case SYS_PW:
    fprintf(PRTFILE, "{PW}");
    break;
  case SYS_RL:
    fprintf(PRTFILE, "{RL}");
    break;
  case SYS_OMAP:
    fprintf(PRTFILE, "{OMAP}");
    break;
  case SYS_TS:
    fprintf(PRTFILE, "{TS}");
    break;
  case SYS_JTS:
    fprintf(PRTFILE, "{JTS}");
    break;
  case TCBEL:
    fprintf(PRTFILE, "{TCBEL}");
    break;
  case TCBS:
    fprintf(PRTFILE, "{TCBS}");
    break;
  case TCCR:
    fprintf(PRTFILE, "{TCCR}");
    break;
  case TCDEL:
    fprintf(PRTFILE, "{TCDEL}");
    break;
  case TCESC:
    fprintf(PRTFILE, "{TCESC}");
    break;
  case TCFF:
    fprintf(PRTFILE, "{TCFF}");
    break;
  case TCHT:
    fprintf(PRTFILE, "{TCHT}");
    break;
  case TCLF:
    fprintf(PRTFILE, "{TCLF}");
    break;
  case TCNUL:
    fprintf(PRTFILE, "{TCNUL}");
    break;
  case SYS_AZ:
    fprintf(PRTFILE, "{AZ}");
    break;
  case SYS_ZA:
    fprintf(PRTFILE, "{ZA}");
    break;
  case SYS_CL:
    fprintf(PRTFILE, "{CL}");
    break;
  case SYS_DL:
    fprintf(PRTFILE, "{DL}");
    break;
  case SYS_FREE:
    fprintf(PRTFILE, "{FREE}");
    break;
  case SYS_FREAD:
    fprintf(PRTFILE, "{SYS_FREAD}");
    break;
  case SYS_PIPE:
    fprintf(PRTFILE, "{PIPE}");
    break;
  case SYS_SPAWN:
    fprintf(PRTFILE, "{SPAWN}");
    break;
  case SYS_SYS:
    fprintf(PRTFILE, "{SYS}");
    break;
  case SYS_FI:
    fprintf(PRTFILE, "{FI}");
    break;
  case SYS_VI:
    fprintf(PRTFILE, "{VI}");
    break;
  case SYS_VTYPE:
    fprintf(PRTFILE, "{VTYPE}");
    break;
  case SYS_FM:
    fprintf(PRTFILE, "{FM}");
    break;
  case SYS_OP:
    fprintf(PRTFILE, "{OP}");
    break;
  case SYS_FWRITE:
    fprintf(PRTFILE, "{SYS_FWRITE}");
    break;
  case SYS_FAPPEND:
    fprintf(PRTFILE, "{SYS_FAPPEND}");
    break;
  case SYS_LSEEK:
    fprintf(PRTFILE, "{LSEEK}");
    break;
  case SYS_FCNTL:
    fprintf(PRTFILE, "{FCNTL}");
    break;
  }
}

/* end of prntf.c */

