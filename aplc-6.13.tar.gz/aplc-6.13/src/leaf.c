/*
	APL Compiler

	code generation for leaves

	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/
#include <stdio.h>
#include <string.h>
#include "parse.h"
#include "y_tab.h"
#include "gen.h"

struct codetree *looprank = 0;	     /* rank of current loop */
char *lastvar = "";		     /* see genident */

/* system variables/functions 
   - must match aplc.h */
static char *sysnames[] = {
  "SYS_ARG", "SYS_IO", "SYS_PP", "SYS_PRNG", "SYS_PW", "SYS_RL", "SYS_OMAP", "SYS_TS", "SYS_JTS", 
   "TCBEL", "TCBS", "TCCR", "TCDEL", "TCESC", "TCFF", "TCHT", "TCLF", "TCNUL", 
  "SYS_AZ", "SYS_ZA", "SYS_CL", "SYS_DL", "SYS_FFLUSH", "SYS_FREE", "SYS_READLINE", "SYS_SYS", 
   "SYS_FI", "SYS_VI", "SYS_VTYPE", 
  "SYS_FM", "SYS_OP", "SYS_FREAD", "SYS_FWRITE", "SYS_FAPPEND", "SYS_LSEEK", 
   "SYS_PIPE", "SYS_SPAWN", "SYS_FCNTL", "SYS_SS"};

#define LDEBUG 0



/* leafshape 
   - do common shape phase operations for leafs 
   - set a mp to the value of the node
*/
extern void
leafshape(struct node * node, int mpval)
{
#if LDEBUG
  fprintf(stderr,"[leafshape]\n");
#endif
#if 0
  if (rtype(node) == APLC_UKTYPE) {
    printf("mp%d = ", mpval);
  } else {
    printf("mp%d.%s = ", mpval, mp_type_str(rtype(node)));
  }
#endif

  switch ( rtype(node) ) { 
  default:
    printf("mp%d.%s = ", mpval, mp_type_str(rtype(node)));
    break;
  case APLC_UKTYPE:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    printf("mp%d = ", mpval);
    break;
  }
  ctgen(node->c.values);
  seminl();
  node->c.values = gicn(memptr, mpval, rtype(node));
  return;
}

/* leafvalue - do common value phase operations for leaves 
   - note that here the node.value becomes a value
   - note that sequential 
     typeknown, rankknown case maintains it's own pointer    */
void
leafvalue(struct node * node, int mpval, int mptype, int resval)
{
#if LDEBUG
  fprintf(stderr,"[leafvalue]\n");
#endif

  /*  if (mptype == APLC_UKTYPE) */
  /* unknown type or multiple type */
  if ( (mptype == APLC_UKTYPE) ||
       (mptype == APLC_COMPLEX) ||
       (mptype == APLC_QUAT) ||
       (mptype == APLC_OCT) ) {
    printf("aplc_mp2res(&res%d, &mp%d, ", resval, mpval);
    /* if (is_scalar(node))*/
    if (is_singleton(node)) {
      printf("0");
    /* 
       else if ((node->n.info & RANKKNOWN) || cteq(node->c.rank, looprank))
       */
    } else if (isnot_singleton(node))
      printf("i%d", node->index);
    else {
      /* sws 
	 don't know rank, could be scalar or length 1 vector (singleton)
	 */
      /* old code only catches scalars
      printf("((");
      ctgen(node->c.rank);
      printf(") ? i%d : 0)", node->index);
      */
      printf("\n(");
      /*testscalar(node->c.rank, node->c.shape);*/
      singleton(node);
      printf(" ? 0: i%d )\n", node->index);
    }
    commasp();
    ctgen(node->c.type);
    rpseminl();
    node->c.values = gicn(resptr, resval, APLC_UKTYPE);
  } else {
    /* type known, can generate better code */
    /*if (is_scalar(node))  or is singleton?? */
    if (is_singleton(node)) 
      node->c.values = gmon(deref, node->c.values);
    else if (isnot_singleton(node)) {
      /* if rank is known but not scalar, must be nonscalar */
      if (node->n.info & SEQUENTIAL)
	node->c.values = gmon(deref,
			      gmon(postinc, node->c.values));
      else
	node->c.values = gmon(deref,
			      gsfun(APLC_PLUS, node->c.values,
				   gicn(coiptr, node->index, 0)));
      /* sws note type arg of gicn is unused */
    } else {
      /* not a known scalar or singleton; 
	 not known to not be a singleton
	 still need run-time check 

	 want something like:

      *(mp4.ip + (apl_getsize(nb.rank,nb.shape) > 1 ? i2 : 0))

	or, if sequential, then we maintain our own count:
      *( apl_getsize(nb.rank,nb.shape) > 1 ? mp4.ip++ : mp4.ip ))
      */

      if ( node->n.info & SEQUENTIAL ) {
	/* maintain our own index */
	node->c.values = gmon(deref,
         gcond( gsfun(APLC_GT, gbin(cofun, 
              gname("aplc_getsize"), gbin(cofunarg, node->c.rank,
                                          gbin(cofunarg, node->c.shape, 
                                             NILTREE))),  
                        gicn(icnst,1,0)),   
		       gmon(postinc, node->c.values),
		       node->c.values) ); 
      } else {
	/* need to use node index */
       node->c.values = gmon(deref,
        gsfun(APLC_PLUS, node->c.values,
               gcond( gsfun(APLC_GT, gbin(cofun, 
                           gname("aplc_getsize"), gbin(cofunarg, node->c.rank,
		               gbin(cofunarg, node->c.shape, 
				    NILTREE))),  
                       gicn(icnst,1,0)),   
		  gicn(coiptr, node->index, 0),
		  gicn(icnst, 0, 0))));
      }
    }
  }
  return;
}

/* 
   leafvalue_const (sws)
   - just for genconst
   - know type, rank, shape
   
   - do common value phase operations for leaves 
   - note that here the node.value becomes a value
   - note that sequential 
   typeknown, rankknown case maintains it's own pointer
   */
void
leafvalue_const(struct node * node, int mpval, int mptype, int resval)
{

  /* type known, can generate better code */
  if ( (is_scalar(node)) || (is_singleton(node)) )
    node->c.values = gmon(deref, node->c.values);
  else {
    /* if rank is known but not scalar, must be nonscalar */
    if (node->n.info & SEQUENTIAL)
      node->c.values = gmon(deref, gmon(postinc, node->c.values));
    else
      node->c.values = gmon(deref,
			    gsfun(APLC_PLUS, node->c.values,
				 gicn(coiptr, node->index, 0)));
    /* sws note type arg of gicn is unused */
  }
  return;
}

/*

genconst - generate code for constant nodes 

	ptr1 = memory pointer
	ptr2 = result register
	ptr3 = constant type
  sws changed this
	ptr4 = scalar integer constant value
  to this
        ptr0 = scalar integer constant value
  as ptr0 is an int vs short for other ptrs
*/
void
genconst(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
  case SHAPE:
    node->ptr3 = node->n.type;
    node->ptr0 = node->n.values;
    adjdcls(node);
    if (node->nodetype == LCON)
      (node->c.values)->c2.ctype = APLC_LABEL;
    if (is_scalar(node) && is_icon(node))
      node->ptr0 = iconsts[node->ptr0];
    else if ( (node->nodetype == ZCON) ||
	      (node->nodetype == QCON) ||
	      (node->nodetype == OCON) ) {
      /* mp doesn't work */
    } else {
      /* only put it into a mp if we have to */
      if ( !is_zilde(node) ) {
	/* should never have uktype here */
	if ( rtype(node) == APLC_UKTYPE )
	  leafshape(node, node->ptr1);
	else if ( (node->n.info & SEQUENTIAL) &&
		  !is_scalar(node))
	  leafshape(node, node->ptr1);
	/* otherwise might as well use given value */
      }
    }
    break;

  case COMBINE:
    break;

  case VALUE:
#if 0
    printf("/* [genconst] values = ");
    ctgen(node->c.values);
    printf(" */");
#endif
    if ( is_zilde(node) ) {
      /* value for zilde... why not 0? */
      node->c.values = gicn(icnst, 0, 0); 
    } else {
      if (is_scalar(node) && is_icon(node))
	node->c.values = gicn(icnst, node->ptr0, 0);
      else if ( (node->nodetype == ZCON) ||
		(node->nodetype == QCON) ||
		(node->nodetype == OCON) ) {
	/* just deref here */
	node->c.values = gmon(deref, node->c.values);
      } else {
	/* leafvalue(node, node->ptr1, node->ptr3, node->ptr2);*/
	leafvalue_const(node, node->ptr1, node->ptr3, node->ptr2);
      }
    }
#if 0
    printf("/* [genconst] values = ");
    ctgen(node->c.values);
    printf(" */");
#endif
    break;

  case FINISH:
    /* the mp, if used, is a static reference and doesn't need to be
       freed */
    break;
  }
  return;
}

/*
  genconst_trs - generate code for constant nodes 
               - used for complex types

	ptr1 - mp for values
	ptr2 - result register
	ptr3 - trs for result
	ptr4 - constant type
	ptr5 - size
	ptr6 - save node->n.values

*/
void
genconst_trs(struct node * node, enum pmodes mode, int top)
{
  int i;

  switch (mode) {
  case SHAPE:
    node->ptr4 = node->n.type;
    node->ptr6 = node->n.values;
    adjdcls(node);
#if 0
    /* make this part for using available name on left */
    if ( node->n.info &  ASSNAMEOK ) {
      node->n.info |= HAVENAME; 
      /* ensure shape, value space allocation */
      /* copy values */
      break;
    }
#endif
    node->c.values = gmon(deref, node->c.values);

    /* build the trs */
    settrs(node->ptr3, node);/* need a trs */
#if 0
    ieq(node->ptr5);
    printf("aplc_talloc(&trs%d);\n", node->ptr3);
    /* collect values */
    colloop(node, node->index, node->ptr5);
    /*printf("trs%d.value.zp[0][0] = ", node->ptr3, );*/
    printf("trs%d.value.zp[0][i%d] = ", node->ptr3, node->index);
    /*ctgen(node->c.values);*/
    printf("%s_%s[0][%d+i%d]", res_type_str(rtype(node)), funname, 
	   node->ptr6, node->index); 
    seminl();
    /*printf("trs%d.value.zp[1][0] = ", node->ptr3);*/
    printf("trs%d.value.zp[1][i%d] = ", node->ptr3, node->index);
    printf("%s_%s[1][%d+i%d]", res_type_str(rtype(node)), funname, 
	   node->ptr6, node->index); 
    seminl();
    rbr();
#else
    /* use the value vectors already existant */
    if (rtype(node) == APLC_COMPLEX) {
      for (i=0; i<2; i++) {
	printf("trs%d.value.zp[%d] = ", node->ptr3, i);
	printf("%s_%s%d[%d]", res_type_str(rtype(node)), funname, 
	       node->ptr6, i); 
	seminl();
      }
    } else if (rtype(node) == APLC_QUAT) {
      for (i=0; i<4; i++) {
	printf("trs%d.value.qp[%d] = ", node->ptr3, i);
	printf("%s_%s%d[%d]", res_type_str(rtype(node)), funname, 
	       node->ptr6, i); 
	seminl();
      }
    } else if (rtype(node) == APLC_OCT) {
      for (i=0; i<8; i++) {
	printf("trs%d.value.op[%d] = ", node->ptr3, i);
	printf("%s_%s%d[%d]", res_type_str(rtype(node)), funname, 
	       node->ptr6, i); 
	seminl();
      }
    }
    
#endif
    node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));
    leafshape(node, node->ptr1);
#if 0
    printf("/* genconst_trs, value{");
    ctgen(node->c.values);
    printf("} */\n");
#endif
    break;

  case COMBINE:
    break;

  case VALUE:
#if 0
    printf("/* ");
    ctgen(node->c.values);
    printf(" */");
#endif
    leafvalue(node, node->ptr1, rtype(node), node->ptr2);
    break;

  case FINISH:
    if ( !(node->n.info & ASSIGNP) ) {
#ifdef DEBUGFREE
      printf("/* -- genconst_trs [zqo]con finish */\n");
#endif
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
  return;
}


/* genident - generate code for identifier nodes 
    ptr1 = memory pointer
    ptr2 = result register */
void
genident(struct node * node, enum pmodes mode, int top)
{
#if LDEBUG
  fprintf(stderr,"[genident] %s %d\n", node->namep, mode);
#endif
  switch (mode) {
    case SHAPE:
    adjdcls(node);

    if (strcmp(node->namep, lastvar)) {
      /* by remembering the name we prevent
	 two checks immediately adjacent */
      char emsg[50];

      lastvar = node->namep;
      printf("if (%s%stype == APLC_UKTYPE) ",
	  lastvar, (is_pointer(lastvar) ? "->" : "."));
      /* prerror("undefined value used");*/
      sprintf(emsg, "undefined value (%s) used", lastvar);
      prerror(emsg);
    }
    if (!(node->n.info & TYPEKNOWN)) {
      node->c.type = gident(node->namep, ctypefield, APLC_UKTYPE);
    }
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gident(node->namep, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gident(node->namep, cshapefield, APLC_UKTYPE);

    node->c.values = gident(node->namep, cvalfield, rtype(node));

    /* only put it into a mp if we have to */
    if ( (rtype(node) == APLC_UKTYPE) ||
	 (rtype(node) == APLC_COMPLEX) ||
	 (rtype(node) == APLC_QUAT) ||
	 (rtype(node) == APLC_OCT) ||
	 ((node->n.info & SEQUENTIAL) && !is_scalar(node)) )
      leafshape(node, node->ptr1);
    /* otherwise might as well use given value */
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr1, rtype(node), node->ptr2);
    break;

  case FINISH:
    break;
  }
  /*fprintf(stderr,"[genident] done.\n");*/
  return;
}

/* genfun - generate code for function calls
	- could be niladic, monadic, or dyadic

	ptr1 - left trs
	ptr2 - right trs
	ptr3 - result trs
	ptr4 - mp for values
	ptr5 - result values
*/
void
genfun(struct node * node, enum pmodes mode, int top)
{
#if LDEBUG
  fprintf(stderr,"[genfun] %s %d\n", node->namep, mode);
#endif
  switch (mode) {
    case SHAPE:
    adjdcls(node);

#if 0
    if (! (node->n.info & ASSNAMEOK) ) {
      if ( (!(node->n.info & TYPEKNOWN)) ||
	   (!(node->n.info & RANKKNOWN)) ||
	   (!(node->n.info & SHAPEKNOWN)) ) {
	/* now use the name */
	inittrsn(node->namea);
      }
    }
#endif
    if (! (node->n.info & ASSNAMEOK) ) {
      if ( (!TypeIsKnown(node)) ||
	   (!RankIsKnown(node)) ||
	   (!(node->n.info & SHAPEKNOWN)) ) {
	/* now use the name */
	inittrsn(node->namea);
      }
    }
    /* now expect that arguments are ccollect and are in a trs
       already that will be freed later 
       - node->ptr3
       - be sure that we use the same trs */
    if (LEFT != NILP) {
      switchbox(LEFT, SHAPE, 0);
      node->ptr1 = LEFT->ptr3;
    }
    if (RIGHT != NILP) {
      switchbox(RIGHT, SHAPE, 0);
      node->ptr2 = RIGHT->ptr3;
    }

    /* fident only */
    printf("%s(", node->namep);
    /* the assigned variable */
    /*printf("&%s, ", node->namea);*/
    printf("%c%s, ", (is_pointer(node->namea) ? ' ' : '&'), node->namea);
    /* rest of function call
       - not all these cases can happen     */
    if (LEFT != NILP) {
      if (RIGHT != NILP) {
	printf("&trs%d, &trs%d);\n", node->ptr1, node->ptr2);
      } else {
	printf("&trs%d, &aplc_nulltrs);\n", node->ptr1);
      }
    } else {
      if (RIGHT != NILP) {
	printf("&aplc_nulltrs, &trs%d);\n", node->ptr2);
      } else {
	printf("&aplc_nulltrs, &aplc_nulltrs);\n" );
      }
    }
    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gident(node->namea, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gident(node->namea, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gident(node->namea, cshapefield, APLC_UKTYPE);
    node->c.values = gident(node->namea, cvalfield, rtype(node));

    if ( (rtype(node) == APLC_UKTYPE) ||
	 (rtype(node) == APLC_COMPLEX) ||
	 (rtype(node) == APLC_QUAT) ||
	 (rtype(node) == APLC_OCT) ||
	 ((node->n.info & SEQUENTIAL) && !is_scalar(node)) )
      leafshape(node, node->ptr4);
    /* otherwise might as well use given value */
    /* quit now */
    break; 

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
    if (LEFT != NILP)
      switchbox(LEFT, FINISH, 0);
    if (RIGHT != NILP)
      switchbox(RIGHT, FINISH, 0);
    /* sws   may want to free the result trs
       - should free the trs for the result, except if the previous
       node is assign, which will use the trs directly */
    if ( !(node->n.info & ASSIGNP) ) {
      /* certain scalars don't need to be freed */
      /*if (! declscalar(node) ) */
      if ( (!(node->n.info & TYPEKNOWN)) ||
	   (!(node->n.info & RANKKNOWN)) ||
	   (!(node->n.info & SHAPEKNOWN)) ) {
#ifdef DEBUGFREE
	printf("/* -- fident finish */\n");
#endif
	/*printf("aplc_detalloc(&trs%d);\n", node->ptr3);*/
	/* need correct name */ 
	printf("aplc_detalloc(%c%s);\n", 
	       (is_pointer(node->namea) ? ' ' : '&'), node->namea);
#ifdef DEBUGFREE
	printf("/* -- */\n");
#endif
      }
    }
    break;
  }
  return;
}

/* genapplyfun - generate code for function calls
	- could be niladic, monadic, or dyadic

	ptr1 - left trs
	ptr2 - right trs
	ptr3 - result trs
	ptr4 - mp for values
	ptr5 - result values
*/
void
genapplyfun(struct node * node, enum pmodes mode, int top)
{

#if LDEBUG
  fprintf(stderr,"[genapplyfun] %s %d\n", node->namep, mode);
#endif
  switch (mode) {
    case SHAPE:
    adjdcls(node);

    /* need a trs setup for the assign value */
    /*node->namea = xx;*/

#if 0
    if (! (node->n.info & ASSNAMEOK) ) {
      if ( (!(node->n.info & TYPEKNOWN)) ||
	   (!(node->n.info & RANKKNOWN)) ||
	   (!(node->n.info & SHAPEKNOWN)) ) {
	/* now use the name */
	inittrsn(node->namea);
      }
    }
#endif
    if (! (node->n.info & ASSNAMEOK) ) {
      if ( (!TypeIsKnown(node)) ||
	   (!RankIsKnown(node)) ||
	   (!(node->n.info & SHAPEKNOWN)) ) {
	/* now use the name */
	inittrsn(node->namea);
      }
    }
    /* now expect that arguments are ccollect and are in a trs
       already that will be freed later 
       - node->ptr3
       - be sure that we use the same trs */
    if (LEFT != NILP) {
      switchbox(LEFT, SHAPE, 0);
      node->ptr1 = LEFT->ptr3;
    }
    if (RIGHT != NILP) {
      switchbox(RIGHT, SHAPE, 0);
      node->ptr2 = RIGHT->ptr3;
    }

    /* get function name */
    if (STORE->nodetype == IDENT) {
      if (is_pointer(STORE->namep))
	printf("(*%s->value.fnp)(", STORE->namep);
      else
	printf("(*%s.value.fnp)(", STORE->namep);
    } else if (STORE->nodetype == FNCON) {
      printf("%s(", fnconsts[STORE->n.values]);
    } else 
      prerror("bad apply store"); 

    /* the assigned variable */
    printf("%c%s, ", (is_pointer(node->namea) ? ' ' : '&'), node->namea);
    /* rest of function call
       - not all these cases can happen     */
    if (LEFT != NILP) {
      if (RIGHT != NILP) {
	printf("&trs%d, &trs%d);\n", node->ptr1, node->ptr2);
      } else {
	printf("&trs%d, &aplc_nulltrs);\n", node->ptr1);
      }
    } else {
      if (RIGHT != NILP) {
	printf("&aplc_nulltrs, &trs%d);\n", node->ptr2);
      } else {
	printf("&aplc_nulltrs, &aplc_nulltrs);\n" );
      }
    }
    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gident(node->namea, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gident(node->namea, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gident(node->namea, cshapefield, APLC_UKTYPE);
    node->c.values = gident(node->namea, cvalfield, rtype(node));

    if ( (rtype(node) == APLC_UKTYPE) ||
	 (rtype(node) == APLC_COMPLEX) ||
	 (rtype(node) == APLC_QUAT) ||
	 (rtype(node) == APLC_OCT) ||
	 ((node->n.info & SEQUENTIAL) && !is_scalar(node)) )
      leafshape(node, node->ptr4);
    /* otherwise might as well use given value */
    /* quit now */
    break; 

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
    if (LEFT != NILP)
      switchbox(LEFT, FINISH, 0);
    if (RIGHT != NILP)
      switchbox(RIGHT, FINISH, 0);
    /* sws   may want to free the result trs
       - should free the trs for the result, except if the previous
       node is assign, which will use the trs directly */
    if ( !(node->n.info & ASSIGNP) ) {
      /* certain scalars don't need to be freed */
      /*if (! declscalar(node) ) */
      if ( (!(node->n.info & TYPEKNOWN)) ||
	   (!(node->n.info & RANKKNOWN)) ||
	   (!(node->n.info & SHAPEKNOWN)) ) {
#ifdef DEBUGFREE
	printf("/* -- fident finish */\n");
#endif
	/*printf("aplc_detalloc(&trs%d);\n", node->ptr3);*/
	/* need correct name */ 
	printf("aplc_detalloc(%c%s);\n", 
	       (is_pointer(node->namea) ? ' ' : '&'), node->namea);
#ifdef DEBUGFREE
	printf("/* -- */\n");
#endif
      }
    }
    break;
  }
  return;
}


/*
	gensysvar - generate code for system variable calls

	we only want the result, so no need for arguments  

        sysvars:
          .bxarg, .bxts, .bxjts


	ptr1 - left trs  nu
	ptr2 - right trs nu
	ptr3 - result trs 
	ptr4 - mp for values
	ptr5 - result values
*/
void
gensysvar(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);

    /* sws  initialize result type to APLC_UKTYPE */
    inittrs(node->ptr3);
    /* now 
       if used, put left/right in trs - just set a pointer to the value
       if unused initialize type to APLC_UKTYPE
       */
#if 0
    if (LEFT != NILP) {
      switchbox(LEFT, SHAPE, 0);
      filtrs(node->ptr1, LEFT);
    }
    if (RIGHT != NILP) {
      switchbox(RIGHT, SHAPE, 0);
      filtrs(node->ptr2, RIGHT);
    }
    printf("aplc_sysvar(%s, ", sysnames[(int) node->optype]);
    /* rest of function call */
    printf("&trs%d, &trs%d, &trs%d);\n", 
	   node->ptr3, node->ptr1, node->ptr2);
#endif
    printf("aplc_sysvar(%s, ", sysnames[(int) node->optype]);
    /* rest of function call */
    printf("&trs%d);\n", node->ptr3);

    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);

    node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));

    if (!top) {
      /* only put it into a mp if we have to */
      if (rtype(node) == APLC_UKTYPE)
	leafshape(node, node->ptr4);
      else if ((node->n.info & SEQUENTIAL) && !is_scalar(node))
	leafshape(node, node->ptr4);
    }
    /* otherwise might as well use given value */
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
#if 0
    if (LEFT != NILP) {
      switchbox(LEFT, FINISH, 0);
      trs_shape_free(node->ptr1);
    }
    if (RIGHT != NILP) {
      switchbox(RIGHT, FINISH, 0);
      trs_shape_free(node->ptr2);
    }
#endif
    /* sws may want to free the result trs, but these use static
       allocation which should not be freed 
       
       sys_arg actually uses dynamic memory, but only once
    */

    /* this should be ok now 
      - trouble, as it may be re-used 
      - should only be freed at end of main */
#if 0 
#ifdef DEBUGFREE
    printf("/* -- gensysvar finish */\n");
#endif
    printf("aplc_detalloc(&trs%d);\n", node->ptr3); 
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
#endif
    break;
  }
}

/*
	genasysvar - generate code for system variable calls
	these calls are assigning new values
 
        asysvars:
          .bxpp, .bxpw, .bxrl, .bxio, .bxomap

	ptr1 - left trs  nu
	ptr2 - right trs 
	ptr3 - result trs 
	ptr4 - mp for values
	ptr5 - result values
*/
void
genasysvar(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);

    /* sws  initialize result type to APLC_UKTYPE */
    inittrs(node->ptr3);
    /* now 
       if used, put left/right in trs - just set a pointer to the value
       if unused initialize type to APLC_UKTYPE
       */
#if 0
    if (LEFT != NILP) {
      switchbox(LEFT, SHAPE, 0);
      filtrs(node->ptr1, LEFT);
    }
#endif
    switchbox(RIGHT, SHAPE, 0);
    filtrs(node->ptr2, RIGHT);
    printf("aplc_asysvar(%s, ", sysnames[(int) node->optype]);
    /* rest of function call */
    printf("&trs%d, &trs%d);\n", node->ptr3, node->ptr2);

    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);

    node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));

    if (!top) {
      /* only put it into a mp if we have to */
      if (rtype(node) == APLC_UKTYPE)
	leafshape(node, node->ptr4);
      else if ((node->n.info & SEQUENTIAL) && !is_scalar(node))
	leafshape(node, node->ptr4);
    }
    /* otherwise might as well use given value */
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
#if 0
    if (LEFT != NILP) {
      switchbox(LEFT, FINISH, 0);
      trs_shape_free(node->ptr1);
    }
    if (RIGHT != NILP) {
      switchbox(RIGHT, FINISH, 0);
      trs_shape_free(node->ptr2);
    }
#endif
    /* sws may want to free the result trs, but these use static
       allocation which should not be freed */
    break;
  }
}

/*
	gensysfun - generate code for system function calls

	ptr1 - left trs
	ptr2 - right trs
	ptr3 - result trs
	ptr4 - mp for values
	ptr5 - result values
*/
void
gensysfun(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);

    /* sws  initialize result type to APLC_UKTYPE */
    inittrs(node->ptr3);
    /* now 
       if used, put left/right in trs - just set a pointer to the value
       if unused initialize type to APLC_UKTYPE
       */
    if (LEFT != NILP) {
      switchbox(LEFT, SHAPE, 0);
      filtrs(node->ptr1, LEFT);
    }
    if (RIGHT != NILP) {
      switchbox(RIGHT, SHAPE, 0);
      filtrs(node->ptr2, RIGHT);
    }

    printf("aplc_sysfun(%s, ", sysnames[(int) node->optype]);
    /* rest of function call */
    printf("&trs%d, &trs%d, &trs%d);\n", 
	   node->ptr3, node->ptr1, node->ptr2);

    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);

    node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));

    if (!top) {
      /* only put it into a mp if we have to */
      if (rtype(node) == APLC_UKTYPE)
	leafshape(node, node->ptr4);
      else if ((node->n.info & SEQUENTIAL) && !is_scalar(node))
	leafshape(node, node->ptr4);
    }
    /* otherwise might as well use given value */
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
    if (LEFT != NILP) {
      switchbox(LEFT, FINISH, 0);
      trs_shape_free(node->ptr1);
    }
    if (RIGHT != NILP) {
      switchbox(RIGHT, FINISH, 0);
      trs_shape_free(node->ptr2);
    }
    /* sws may want to free the result trs, but these use static
       allocation which should not be freed */
    break;
  }
}

/*
	genmfun - generate code for monadic function calls
                   domino, execute, format, unbox
                  monadic system functions: 
                    close, delay, read, system

	ptr1 - (none)
	ptr2 - right trs
	ptr3 - result trs
	ptr4 - mp for values
	ptr5 - result values
*/
void
genmfun(struct node * node, enum pmodes mode, int top)
{
  enum sysvars optype;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    filtrs(node->ptr2, RIGHT);

    switch (node->nodetype) {
    default:
      break;

    case DOMINO:
      /* make sure we have a matrix */
      if (!(RIGHT->n.info & RANKKNOWN))
	testmxrank(RIGHT->c.rank, 2);
      /* aplc_domino(res, right); */
      /* fall through for code */
    case EXECUTE:
    case FORMAT:
    case UNBOX:
      /* aplc_execute(res, right); */
      printf("%s(&trs%d, &trs%d", str_msysfun(node->nodetype), node->ptr3, node->ptr2);
      rpseminl();
      break;
 
    case ESYSFUN:
    case MSYSFUN:
    case SYSVAR:
      optype = (enum sysvars) node->optype;
      switch (optype) {

      default:
	break;

      case SYS_FREAD:
      case SYS_READLINE:
	/* aplc_read(res, (), right); */
	/* aplc_readline(res, (), right); */
	if (!(RIGHT->n.info & RANKKNOWN))
	  testmxrank(RIGHT->c.rank, 1);
	/* fread is only files, read can handle files or fd's */
	printf("%s(&trs%d, &aplc_nulltrs, &trs%d", str_msysfun(optype), 
	       node->ptr3, node->ptr2);
	rpseminl();
	break;

      case SYS_SPAWN:
	/* aplc_spawn_mon(res, right); */
	if (!(RIGHT->n.info & TYPEKNOWN))
	  testtype(RIGHT->c.type, APLC_CHAR);
	if (!(RIGHT->n.info & RANKKNOWN))
	  testmxrank(RIGHT->c.rank, 1);
	printf("%s(&trs%d, &aplc_nulltrs, &trs%d", str_msysfun(optype), 
	       node->ptr3, node->ptr2);
	rpseminl();
	break;

      case SYS_DL:
      case SYS_OP:
      case SYS_AZ:
      case SYS_ZA:
      case SYS_SYS:
      case SYS_FI:
      case SYS_VI:
      case SYS_VTYPE:
	printf("%s(&trs%d, &aplc_nulltrs, &trs%d);\n", 
	       str_msysfun(optype), node->ptr3, node->ptr2);
	break;

      case SYS_CL:
	/* aplc_close(res, right); */
      case SYS_FFLUSH:
	if (!(RIGHT->n.info & TYPEKNOWN))
	  testtype(RIGHT->c.type, APLC_INT);
	if (!(RIGHT->n.info & RANKKNOWN))
	  testmxrank(RIGHT->c.rank, 1);
	printf("%s(&trs%d, &aplc_nulltrs, &trs%d",str_msysfun(optype), 
	    node->ptr3, node->ptr2);
	rpseminl();
	break;
      }
      break;
    }

    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);

    node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));

    if (!top) {
      /* only put it into a mp if we have to */
      if (rtype(node) == APLC_UKTYPE)
	leafshape(node, node->ptr4);
      else if ((node->n.info & SEQUENTIAL) &&
	  !is_scalar(node))
	leafshape(node, node->ptr4);
    }
    /* otherwise might as well use given value */
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    /* deallocate the shapes of the trs's created 
       - this will be careful of scalars */
    trs_shape_free(node->ptr2);
    if ( !(node->n.info & ASSIGNP) )  {
      /* should free the trs for the result, except if the previous
	 node is assign, which will use the trs directly */
#ifdef DEBUGFREE
      printf("/* -- genmfun finish */\n");
#endif
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/*
	genmfun_type_ident - special case of msysfun
                             want the type of an ident 

   only ptr3 is used
	ptr1 - (none)   
	ptr2 - right trs
	ptr3 - result trs
	ptr4 - mp for values
	ptr5 - result values
*/
void
genmfun_type_ident(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
  case SHAPE:
    adjdcls(node);
    /* known to be integer scalar */ 
    settrs(node->ptr3, node);
    printf("aplc_talloc(&trs%d);\n", node->ptr3);
    /* *trs3.value.ip = name->type */
    printf("*trs%d.value.ip = %s%stype", node->ptr3, 
	   RIGHT->namep, (is_pointer(RIGHT->namep) ? "->" : "."));
    seminl();
    node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    if ( !(node->n.info & ASSIGNP) )  {
      /* should free the trs for the result, except if the previous
	 node is assign, which will use the trs directly */
#ifdef DEBUGFREE
      printf("/* -- genmfun_type_ident finish */\n");
#endif
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/*
	genmfun_free_ident - special case of msysfun
                             free an ident 
                             return value is 1 now

   only ptr3 is used
	ptr1 - (none)   
	ptr2 - right trs
	ptr3 - result trs
	ptr4 - mp for values
	ptr5 - result values
*/
void
genmfun_free_ident(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
  case SHAPE:
    adjdcls(node);
    /* known to be integer scalar */ 
    settrs(node->ptr3, node);
    printf("aplc_talloc(&trs%d);\n", node->ptr3);
    printf("aplc_detalloc(%c%s);\n", 
	(is_pointer(RIGHT->namep) ? ' ' : '&'), RIGHT->namep);
    /* set the value 1 */
    printf("*trs%d.value.ip = 1;\n", node->ptr3); 
    node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    if ( !(node->n.info & ASSIGNP) )  {
      /* should free the trs for the result, except if the previous
	 node is assign, which will use the trs directly */
#ifdef DEBUGFREE
      printf("/* -- genmfun_free_ident finish */\n");
#endif
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}


/*
	gendfun - generate code for dyadic function calls
	          dformat, msolve,
                  dyadic system funtions:
		    (fm), open fwrite, fappend, ss
                    pipe, lseek, open 

	ptr1 - left trs
	ptr2 - right trs
	ptr3 - result trs
	ptr4 - mp for values
	ptr5 - result values
*/
void
gendfun(struct node * node, enum pmodes mode, int top)
{
  enum sysvars optype;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    filtrs(node->ptr1, LEFT);
    filtrs(node->ptr2, RIGHT);

    switch (node->nodetype) {
    default:
        fprintf(stderr,"[gendfun] warning: unhandled nodetype %s\n",
                prtoken(node->nodetype));
      break;

    case DFORMAT:
      /* aplc_dformat(res, left, right); */
      printf("aplc_dformat(");
      printf("&trs%d, &trs%d, ", node->ptr3, node->ptr1);
      printf("&trs%d", node->ptr2);
      rpseminl();
      break;

    case INDEXFN:
      /* aplc_indexfn(res, left, right); */
      printf("aplc_index(");
      printf("&trs%d, &trs%d, ", node->ptr3, node->ptr1);
      printf("&trs%d", node->ptr2);
      rpseminl();
      break;

    case MATCH:
      /* aplc_match(res, left, right); */
      printf("aplc_match(");
      printf("&trs%d, &trs%d, ", node->ptr3, node->ptr1);
      printf("&trs%d", node->ptr2);
      rpseminl();
      break;

    case MSOLVE:
      /* make sure we have a matrix */
      if (!(LEFT->n.info & RANKKNOWN))
	testmxrank(LEFT->c.rank, 2);
      /* make sure we have a matrix */
      if (!(RIGHT->n.info & RANKKNOWN))
	testmxrank(RIGHT->c.rank, 2);

      /* aplc_msolve(res, left, right); */
      printf("aplc_msolve(");
      printf("&trs%d, &trs%d, ", node->ptr3, node->ptr1);
      printf("&trs%d", node->ptr2);
      rpseminl();
      break;
    case DSYSFUN:
    case ESYSFUN:
    case SYSVAR:
      optype = (enum sysvars) node->optype;
      switch (optype) {
      default:
	break;
      case SYS_AZ:
	if (!(LEFT->n.info & RANKKNOWN))
	  testmxrank(LEFT->c.rank, 1);
	printf("aplc_daz(");
	printf("&trs%d, &trs%d, &trs%d);\n", 
	       node->ptr3, node->ptr1, node->ptr2);
	break;
      case SYS_ZA:
	if (!(LEFT->n.info & RANKKNOWN))
	  testmxrank(LEFT->c.rank, 1);
	printf("aplc_dza(");
	printf("&trs%d, &trs%d, &trs%d);\n", 
	       node->ptr3, node->ptr1, node->ptr2);
	break;
      case SYS_FREAD:
	/* aplc_readn(res, left, right); */
	if (!(LEFT->n.info & RANKKNOWN))
	  testmxrank(LEFT->c.rank, 1);
#if 0
	/* now could also be an fp (int or bit) */
	if (!(RIGHT->n.info & TYPEKNOWN))
	  testtype(RIGHT->c.type, APLC_CHAR);
#endif
	if (!(RIGHT->n.info & RANKKNOWN))
	  testmxrank(RIGHT->c.rank, 1);
	printf("aplc_readn(");
	printf("&trs%d, &trs%d, &trs%d",
	    node->ptr3, node->ptr1, node->ptr2);
	rpseminl();
	break;
      case SYS_FWRITE:
	/* aplc_write(res, left, right); */
	if (!(LEFT->n.info & RANKKNOWN))
	  testmxrank(LEFT->c.rank, 1);
#if 0
	if (!(RIGHT->n.info & TYPEKNOWN))
	  testtype(RIGHT->c.type, APLC_CHAR);
#endif
	if (!(RIGHT->n.info & RANKKNOWN))
	  testmxrank(RIGHT->c.rank, 1);
	printf("aplc_write(");
	printf("&trs%d, &trs%d, &trs%d",
	    node->ptr3, node->ptr1, node->ptr2);
	rpseminl();
	break;
      case SYS_FAPPEND:
	/* aplc_fappend(res, left, right); */
	printf("aplc_fappend(");
	printf("&trs%d, &trs%d, &trs%d",
	    node->ptr3, node->ptr1, node->ptr2);
	rpseminl();
	break;

      case SYS_PIPE:
	/* aplc_pipe(res, left, right); */
	if (!(LEFT->n.info & TYPEKNOWN))
	  testtype(LEFT->c.type, APLC_CHAR);
	if (!(LEFT->n.info & RANKKNOWN))
	  testmxrank(LEFT->c.rank, 1);
	if (!(RIGHT->n.info & TYPEKNOWN))
	  testtype(RIGHT->c.type, APLC_CHAR);
	if (!(RIGHT->n.info & RANKKNOWN))
	  testmxrank(RIGHT->c.rank, 1);
	printf("aplc_pipe(");
	printf("&trs%d, &trs%d, &trs%d",
	    node->ptr3, node->ptr1, node->ptr2);
	rpseminl();
	break;

      case SYS_SPAWN:
	/* aplc_spawn(res, left, right); */
	/* LEFT may be scalar INT or vector or array CHAR */
	if (!(RIGHT->n.info & TYPEKNOWN))
	  testtype(RIGHT->c.type, APLC_CHAR);
	if (!(RIGHT->n.info & RANKKNOWN))
	  testmxrank(RIGHT->c.rank, 1);
	printf("aplc_spawn(");
	printf("&trs%d, &trs%d, &trs%d",
	    node->ptr3, node->ptr1, node->ptr2);
	rpseminl();
	break;

      case SYS_FCNTL:
	/* aplc_fcntl(res, left, right); */
	if (!(LEFT->n.info & TYPEKNOWN))
	  testtype(LEFT->c.type, APLC_CHAR);
	if (!(LEFT->n.info & RANKKNOWN))
	  testmxrank(LEFT->c.rank, 1);
	if (!(RIGHT->n.info & TYPEKNOWN))
	  testtype(RIGHT->c.type, APLC_INT);
	if (!(RIGHT->n.info & RANKKNOWN))
	  testmxrank(RIGHT->c.rank, 1);
	printf("aplc_fcntl(");
	printf("&trs%d, &trs%d, &trs%d",
	    node->ptr3, node->ptr1, node->ptr2);
	rpseminl();
	break;

      case SYS_OP:
	/* aplc_open(res, left, right); */
	if (!(LEFT->n.info & TYPEKNOWN))
	  testtype(LEFT->c.type, APLC_CHAR);
	if (!(LEFT->n.info & RANKKNOWN))
	  testmxrank(LEFT->c.rank, 1);
/*
	if (!(RIGHT->n.info & TYPEKNOWN))
	  testtype(RIGHT->c.type, APLC_CHAR);
 */
	if (!(RIGHT->n.info & RANKKNOWN))
	  testmxrank(RIGHT->c.rank, 1);
	printf("aplc_open(");
	printf("&trs%d, &trs%d, &trs%d",
	    node->ptr3, node->ptr1, node->ptr2);
	rpseminl();
	break;

      case SYS_LSEEK:
	/* aplc_lseek(res, left, right); */
	if (!(LEFT->n.info & TYPEKNOWN))
	  testtype(LEFT->c.type, APLC_CHAR);
	if (!(LEFT->n.info & RANKKNOWN))
	  testmxrank(LEFT->c.rank, 1);
	if (!(RIGHT->n.info & TYPEKNOWN))
	  testtype(RIGHT->c.type, APLC_INT);
	if (!(RIGHT->n.info & RANKKNOWN))
	  testmxrank(RIGHT->c.rank, 1);
	printf("aplc_lseek(");
	printf("&trs%d, &trs%d, &trs%d",
	    node->ptr3, node->ptr1, node->ptr2);
	rpseminl();
	break;

      case SYS_SS:
	if (!(LEFT->n.info & TYPEKNOWN))
	  testtype(LEFT->c.type, APLC_CHAR);
	if (!(LEFT->n.info & RANKKNOWN))
	  testmxrank(LEFT->c.rank, 1);
	if (!(RIGHT->n.info & TYPEKNOWN))
	  testtype(RIGHT->c.type, APLC_CHAR);
	if (!(RIGHT->n.info & RANKKNOWN))
	  testmxrank(RIGHT->c.rank, 1);
	/* aplc_strsrch(res, left, right); */
	printf("aplc_strsrch(");
	printf("&trs%d, &trs%d, &trs%d",
	    node->ptr3, node->ptr1, node->ptr2);
	rpseminl();
	break;
      }
      break;
    }
    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);
    node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));

    if (rtype(node) == APLC_UKTYPE)
      leafshape(node, node->ptr4);
    else if ((node->n.info & SEQUENTIAL) && !is_scalar(node))
      leafshape(node, node->ptr4);
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node),
	node->ptr5);
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);

    /* deallocate the shapes of the trs's created 
     - this may need rethinking later ... */
    trs_shape_free(node->ptr1);
    trs_shape_free(node->ptr2);

    if ( !(node->n.info & ASSIGNP) )  {
      /* should free the trs for the result, except if the previous
	 node is assign, which will use the trs directly */
#ifdef DEBUGFREE
      printf("/* -- gendfun finish */\n");
#endif
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/*
	genquad - generate code for input quad

	ptr1 - trs for result
	ptr2 - mp for values
	ptr3 - result register */
void
genquad(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
  case SHAPE:
    adjdcls(node);/* sws to fix anyrank troubles */
    printf("aplc_quad(stdin, &trs%d);\n", node->ptr1);
    node->c.type = gtrs(node->ptr1, ctypefield, APLC_UKTYPE);
    node->c.rank = gtrs(node->ptr1, crankfield, APLC_UKTYPE);
    node->c.shape = gtrs(node->ptr1, cshapefield, APLC_UKTYPE);
    node->c.values = gtrs(node->ptr1, cvalfield, APLC_UKTYPE);
    leafshape(node, node->ptr2);
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr2, APLC_UKTYPE, node->ptr3);
    break;

  case FINISH:
    /* need to check this */
#ifdef DEBUGFREE
    printf("/* -- genquad finish */\n");
#endif
    printf("aplc_detalloc(&trs%d);\n", node->ptr1);
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;

  default:
    break;
  }
}

/*
sws
	genqquad - generate code for input quote quad

	ptr1 - trs for result
	ptr2 - mp for values
	ptr3 - result register
*/
void
genqquad(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);

    printf("aplc_qquad(stdin, &trs%d);\n", node->ptr1);

    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gtrs(node->ptr1, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gtrs(node->ptr1, cshapefield, APLC_UKTYPE);
    node->c.values = gtrs(node->ptr1, cvalfield, APLC_CHAR);
    leafshape(node, node->ptr2);
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr2, APLC_CHAR, node->ptr3);
    break;

  case FINISH:
    /* need to check this */
#ifdef DEBUGFREE
    printf("/* -- genqquad finish */\n");
#endif
    printf("aplc_detalloc(&trs%d);\n", node->ptr1);
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;

  default:
    break;
  }
}


/*
	genrho - generate code for monadic rho (shape) function

	ptr1 - memory pointer for shape
	ptr2 = memory pointer for values
*/
void
genrho(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    if (!(node->n.info & SHAPEKNOWN)) {
      smpalloc(node->ptr1);
      smpieqt(node->ptr1, RIGHT->c.rank);
      node->c.shape = gicn(memptr, node->ptr1, APLC_INT);
    }
    node->c.values = RIGHT->c.shape;
    leafshape(node, node->ptr2);
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr2, APLC_INT, 0);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    if (!(node->n.info & SHAPEKNOWN)) {
#ifdef DEBUGFREE
      printf("/* -- rho finish */\n");
#endif
      mpfree(node->ptr1);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
  }
}

/*
 genrrho - generate code for rho rho instruction (rank)

 ptr1 - value of result
*/
#if 1
/* new version */
void
genrrho(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    if (!(node->n.info & VALUESKNOWN)) {
      switchbox(RIGHT, SHAPE, 0);
      ieqtree(node->ptr1, RIGHT->c.rank);
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    if (node->n.info & VALUESKNOWN)
      node->c.values = gmon(deref, node->c.values);
    else
      node->c.values = gicn(coiptr, node->ptr1, APLC_INT);
    break;

  case FINISH:
    if (!(node->n.info & VALUESKNOWN))
      switchbox(RIGHT, FINISH, 0);
    break;
  }
}
#else
void
genrrho(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    /* sws may not be right if right rank is arbitrary
    if (RIGHT->n.info & RANKKNOWN) { */
    if (node->n.info & VALUESKNOWN) {
      /* seticon(node->ptr1, RIGHT->n.rank);*/
      seticon(node->ptr1, node->n.values);
    } else {
      switchbox(RIGHT, SHAPE, 0);
      ieqtree(node->ptr1, RIGHT->c.rank);
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    node->c.values = gicn(coiptr, node->ptr1, APLC_INT);
    break;

  case FINISH:
    /* if (!(RIGHT->n.info & RANKKNOWN))*/
    if (!(node->n.info & VALUESKNOWN))
      switchbox(RIGHT, FINISH, 0);
    break;
  }
}
#endif

/*
	gensort - generate code for the sort operator

	ptr1 - res for result values
	ptr2 - mp for node values
	ptr3 - mp for right hand side
	ptr4 - mp for node values, save for free later
*/

void
gensort(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 0, 0, 1);
    node->ptr3 = smpval(RIGHT, node->ptr3);
    printf("aplsort(&mp%d, &mp%d, ", node->ptr2, node->ptr3);
    ctgen(gmon(deref, RIGHT->c.shape));
    commasp();
    ctgen(RIGHT->c.type);
    printf(", %d);\n", node->ptr0);
    mpeqmp(node->ptr4, node->ptr2);
    node->c.values = gicn(memptr, node->ptr2, APLC_INT);
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr2, APLC_INT, node->ptr1);
    node->c.values = gsfun(APLC_PLUS, node->c.values,	gixorg());
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
#ifdef DEBUGFREE
    printf("/* -- sort finish */\n");
#endif
    mpfree(node->ptr4);
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
  }
}

/*
	genmember - generate code for the membership
				(dyadic epsilon) function

	ptr1 - result value
	ptr2 - values of right hand side
	ptr3 - left result value (sws)
*/
void
genmember(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, LEFT, 0, 1, 1);
    node->ptr2 = smpval(RIGHT->right, node->ptr2);
    break;

  case COMBINE:
    break;

  case VALUE:
    switchbox(LEFT, VALUE, 0);
/* sws
   this makes left type match right
 	mktmatch(RIGHT->right, LEFT, node->ptr1);
*/
    node->ptr3 = resinreg(LEFT, node->ptr3);
/*
result= aplsearch(index, values, element, values type, element type, size)
*/
    printf("res%d.i = aplsearch(", node->ptr1);
    ctgen(RIGHT->c.values);
    printf(", &mp%d, &res%d, ", node->ptr2, node->ptr3);
    ctgen((RIGHT->right)->c.type);
    commasp();
    ctgen(LEFT->c.type);
    commasp();
    ctgen(gmon(deref, RIGHT->c.shape));
    printf(") < ");
    ctgen(gmon(deref, RIGHT->c.shape));
    seminl();
    node->c.values = gicn(resptr, node->ptr1, APLC_BOOL);
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
  }
}

/*
	genindexof - generate code for index-of (dyadic iota)
			function
*/
void
genindexof(struct node * node, enum pmodes mode, int top)
{
/*
	ptr1 - result register
	ptr2 - register for right value
	ptr3 - mp for right hand values
*/
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 0, 1, 1);
    node->ptr3 = smpval(LEFT->right, node->ptr3);
    break;

  case COMBINE:
    break;

  case VALUE:
    switchbox(RIGHT, VALUE, 0);
/* sws
   this would make right type match left
	mktmatch((LEFT->right), RIGHT, node->ptr2);
*/
    node->ptr2 = resinreg(RIGHT, node->ptr2);
/*
result= aplsearch(index, values, element, values type, element type, size)
*/
    printf("res%d.i = aplsearch(", node->ptr1);
    ctgen(LEFT->c.values);
    printf(", &mp%d, &res%d, ", node->ptr3, node->ptr2);
    ctgen((LEFT->right)->c.type);
    commasp();
    ctgen(RIGHT->c.type);
    commasp();
    ctgen(gmon(deref, LEFT->c.shape));
    rpseminl();
    node->c.values =
	gsfun(APLC_PLUS,
	gicn(resptr, node->ptr1, APLC_INT),
	gixorg());
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    break;

  }
}

/*
	genavec -
		generate code for atomic vector
                this is a leaf 
*/
void
genavec(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    break;

  case COMBINE:
    break;

  case VALUE:
    node->c.values = gicn(coiptr, node->index, APLC_INT);
    break;

  case FINISH:
    break;

  }
}

/* end of leaf.c */


