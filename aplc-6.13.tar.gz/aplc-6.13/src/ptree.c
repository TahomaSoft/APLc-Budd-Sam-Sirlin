/*
	apl compiler
		build new parse tree nodes
			timothy a. budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include <stdio.h>
#include <string.h>

#include "parse.h"
#include "ptree.h"
#include "y_tab.h"

#define PTDEBUG 0

/* externals from yacc */
extern void prog(struct headnode * head, struct statenode * code);
extern void yyerror(char *c);

/* slen - string length without escape characters 
   - sws; don't use c escapes...
*/
extern int
slen(char *c)
{
  int i;
  char *p;

  i = 0;
  for (p = c; *p; p++)
/*	if (*p != '\\')*/
    i++;
  return i;
}

/* newhead - make a new function header node */
struct headnode *
newhead(char *name, char *parm1, char *parm2)
{
  struct headnode *x;
  struct symnode *h = NILSYM;

#if PTDEBUG
  if (name) {
    /*fprintf(stderr,"[newhead] fn name %s\n", name);*/
    if (parm1) {
      if (!parm2)
        yyerror("newhead with parm1, no parm2");
      else
        fprintf(stderr,"[newhead] (%s %s %s)\n", parm1,name,parm2);
    } else {
      if (parm2)
        fprintf(stderr,"[newhead] (nil %s %s)\n", name,parm2);
      else
        fprintf(stderr,"[newhead] (nil %s nil)\n", name);
    }
  } else
    fprintf(stderr,"[newhead] fn name null\n");
#endif
  x = structalloc(headnode);
  if (x == NILHEAD)
    yyerror("out of space");
  if (name != NILCHAR) {
    h = enterid(name, FUNCTION, APLC_UKTYPE, NORANK,
                get_fop_valence_comp(parm1, NILCHAR));
    funname = h->name;/* setup current function name */
  }
  x->lfname = NILCHAR;
  x->opname = name;
  x->rfname = NILCHAR;
  x->asvar = NILCHAR;
  x->parm1 = parm1;
  x->parm2 = parm2;
  if (parm1 != NILCHAR) {
    /*enterid(parm1, PARAM, APLC_UKTYPE, NORANK);*/
    enterid(parm1, PARAM, APLC_ANY, ANYRANK, NOVALENCE);
  }
  if (parm2 != NILCHAR) {
    /*enterid(parm2, PARAM, APLC_UKTYPE, NORANK);*/
    enterid(parm2, PARAM, APLC_ANY, ANYRANK, NOVALENCE);
  }
  /* initialize counters */
  x->maxtrs = 0;
  x->maxmp = 0;
  x->maxres = 0;
  x->maxi = 0;
  return x;
}

/* direct - direct defintion declaration 
   - label is the fn name */
void 
direct(char *label, struct node * expr)
{
  struct node *x; 
  struct symnode *s;
  struct headnode *h;

  /* should have been done at the (:) setlocalcons();*/
  /* see if we have a left */
  idclass("_alpha", &s);
  if (s == NILSYM)
    h = newhead(label, NILCHAR, "_omega");
  else
    h = newhead(label, "_alpha", "_omega");
  h->asvar = "_zeta";
  /* get symnode for return var, setup assignment */
  idclass("_zeta", &s);
  x = pt2(ASSIGN, ptvar(s), expr);
  prog(h, newstate(NILCHAR, x));
  resetconsts();/* switch to global; */
  return;
}

/* newstate - produce a new statement node */
struct statenode *
newstate(char *label, struct node * code)
{
  struct statenode *x;

  if (code->nodetype == COMMENT && label == NILCHAR)
    return (NILSTATE);
  x = structalloc(statenode);
  if (x == NILSTATE)
    yyerror("out of space");
  x->label = label;
  x->code = code;
  x->nextstate = NILSTATE;
  x->list = NILSYM;

#if PTDEBUG
 {
   enum classes ic;
   struct symnode *lbn;  /* node for lable name */

   if (label) {
     /* look up the name, should be class label */
     fprintf(stderr,"[newstate] lookup label   %s\n",label);
     ic = idclass(label, &lbn);
     if (ic == NOCLASS) {
       fprintf(stderr," label not found, adding\n");
       /*enterid(label,LABCLASS,APLC_INT,0);*/
     } else {
       fprintf(stderr,"label  %s class %d, type %d, rank %d\n", 
	       label, (int)ic, lbn->s.type, lbn->s.rank);
       print_info(stderr, &lbn->s);fprintf(stderr,"\n");
     }
   }
 }
#endif
  return x;
}

/* addstmt - add a statement to statement list */
struct statenode *
addstmt(struct statenode * first, struct statenode * new)
{
  struct statenode *i;

  if (new == NILSTATE)
    return (first);
  else if (first == NILSTATE)
    return new;
  else {
    for (i = first; i->nextstate != NILSTATE; i = i->nextstate);
    i->nextstate = new;
    return first;
  }
}

/* newnode - produce a new parse tree node 
   - moved to symutil.c, for use in other stages */

/* pt1 - simple 1 child node */
struct node *
pt1(int type, struct node * child)
{
  struct node *x;

  x = newnode(type);
  x->right = child;
  return x;
}

/* ptaxis - process an (integer) axis specifier */
void 
ptaxis(struct node * x, struct node * axis, int ainfo)
{
  if (axis != NILP) {
    x->axis = pt1(CISCALAR, axis);
  } else {
    x->axis = NILP;
    x->n.info |= ainfo;
  }
}

/* ptgaxis - process a general axis specifier 
   - could be fractional (laminate) */
void 
ptgaxis(struct node * x, struct node * axis, int ainfo)
{
  if (axis != NILP) {
    x->axis = pt1(CSCALAR, axis);
  } else {
    x->axis = NILP;
    x->n.info |= ainfo;
  }
}

/* pt1a - 1 child node with axis */
struct node *
pt1a(int type, struct node * axis, int ainfo, struct node * child)
{
  struct node *x;

  x = pt1(type, child);
  ptaxis(x, axis, ainfo);
  return x;
}

/* pt1o - 1 child node with operator */
struct node *
pt1o(int type, enum sfuns op, struct node * child)
{
  struct node *x;

  x = pt1(type, child);
  x->optype = op;
  return x;
}

/* pt1ao - one child node with both axis and operator */
struct node *
pt1ao(int type, enum sfuns op, struct node * axis, struct node * child, int ainfo)
{
  struct node *x;

  x = pt1a(type, axis, ainfo, child);
  x->optype = op;
  return x;
}

/* pt2 - simple 2 child node */
struct node *
pt2(int type, struct node * child1, struct node * child2)
{
  struct node *x;

  x = newnode(type);
  x->left = child1;
  x->right = child2;
  return x;
}

/* pt2a - 2 child node with axis */
struct node *
pt2a(int type, struct node *axis, int ainfo, 
     struct node *child1, struct node * child2)
{
  struct node *x;

  x = pt2(type, child1, child2);
  /* sws  allow for real axis for cat - possible laminate */
  if (type != CAT)
    ptaxis(x, axis, ainfo);
  else
    ptgaxis(x, axis, ainfo);
  return x;
}

/* pt2o - two child node with operator */
struct node *
pt2o(int type, enum sfuns op, struct node * child1, struct node * child2)
{
  struct node *x;

  x = pt2(type, child1, child2);
  x->optype = op;
  return x;
}

/* pt2ao - two child node with both operator and axis */
struct node *
pt2ao(int type, enum sfuns op, struct node * axis, int ainfo, 
  struct node * child1, struct node * child2)
{
  struct node *x;

  x = pt2a(type, axis, ainfo, child1, child2);
  x->optype = op;
  return x;
}

/* pt2aos - two child node with both operator and axis and store 
            sws  used for decode for an intermediate result */
struct node *
pt2aos(int type, enum sfuns op, struct node * axis, int ainfo, 
  struct node * child1, struct node * child2)
{
  struct node *x;

  x = pt2a(type, axis, ainfo, child1, child2);
  x->optype = op;
  x->store = pt1(SM, NILP);
  return x;
}

/* pt2s - three child node -- 
   two chile node with store 
   sws */
struct node *
pt2s(int type, struct node *lt, struct node *st, struct node *rt)
{
  struct node *x;

  x = pt2(type, lt,rt);
  x->store = st;
  return x;
}

/* ptsort - sort function */
struct node *
ptsort(int direction, struct node * child)
{
  struct node *x;

  x = pt1(SORT, child);
  x->ptr0 = direction;
  return x;
}

/* ptsvec - string constant (vector) */
struct node *
ptsvec(char *chars)
{
  struct node *x;
  int len;

  x = newnode(SCON);
  x->n.type = (int) APLC_CHAR;
  len = slen(chars);
  x->n.shape = addicon_scalar(len);
  x->n.size = len;
  if (len == 1)
    x->n.rank = 0; /* sws  scalar */
  else
    x->n.rank = 1; /* vector */
  x->n.values = slen(sconsts);
  x->n.info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN |
      SHAPEKNOWN | VALUESKNOWN);
  if (strlen(chars) + strlen(sconsts) >= MAXCONSTS) {
    fprintf(stderr,"[ptsvec] MAXCONSTS = %d\n", MAXCONSTS);
    yyerror("too many string constants(0)");
  }
  strcat(sconsts, chars);
#if 0
  fprintf(stderr,"[ptsvec] len %d, [%s]\n",len, chars);
#endif
#if 0
  free(chars);/* was built with strdup */ 
#endif
  return x;
}

/* ptval - scalar value */
struct node *
ptval(int type, int val)
{
  struct node *x;

  x = newnode(type);
  x->n.rank = 0;
  x->n.shape = 1;
  x->n.size = 1;
  x->n.values = val;
  x->n.info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN |
      SHAPEKNOWN | VALUESKNOWN);
  return (x);
}

/* aptval - add a scalar value, forming an array */
struct node *
aptval(struct node * node)
{
  node->n.rank = 1;
  node->n.shape++;
  return (node);
}

/* ptvec - constant vector */
struct node *
ptvec(struct node * x, int type, int rtype)
{

  x->nodetype = type;
  x->n.type = rtype;
  x->n.info |= (TYPEDECL | TYPEKNOWN);
  x->n.size = x->n.shape;
  if (x->n.rank)
    x->n.shape = addicon(x->n.shape);
#if 0
  fprintf(stderr, "[ptvec] rank %d, shape %d, size %d\n",
	  x->n.rank, x->n.shape, x->n.size);
#endif  
  return (x);
}

/* sws; used for direct defn, anon fns 
   -- expect that name is one of {"_alpha" "_omega" "_zeta"} */
struct node *
sysparm(char *name)
{
  struct symnode *x; 

  idclass(name, &x);/* get info about name */
  /* could be found at lower depth... if (x == NILSYM) */
  if ( (x == NILSYM) || (x->depth < prog_depth) ) {
    /* declare the name 
       _zeta is special -- the return value */
    if (0 == strcmp(name, "_zeta"))
      enterid(name_strcpy("_zeta"),  APARAM, APLC_UKTYPE, NORANK, NOVALENCE);
    else
      enterid(name_strcpy(name), PARAM, APLC_UKTYPE, NORANK, NOVALENCE);
    /* try it again */
    idclass(name, &x);/* get info about name */
    if (x == NILSYM)
      yyerror("sysparm error");
  }
  return (ptvar(x));
}

/* ptvar - variable node */
struct node *
ptvar(struct symnode * var)
{
  struct node *x;

  x = newnode(IDENT);
  x->namep = var->name;
  if ((var->s.type != APLC_UKTYPE) && (var->s.type != APLC_ANY))
    x->n.info |= (TYPEDECL | TYPEKNOWN);
  x->n.type = var->s.type;
  /* if (var->s.rank != NORANK)*/
  if (var->s.rank == ANYRANK) {
    x->n.info |= RANKKNOWN;
    x->n.rank = ANYRANK;
  } else if ( var->s.rank != NORANK )
    x->n.info |= (RANKDECL | RANKKNOWN);
  x->n.rank = var->s.rank;
  return (x);
}

/* ptfun - functions
           used for dyadic or monadic user fns 
 */
struct node *
ptfun(struct symnode *fun, struct node *child1, struct node *child2)
{
  struct node *x;

  /* sws  old version used collects in apl.y */
  /* x = pt2(FIDENT, child1, child2); */

#ifdef  BYREF
  /* sws   this version will pass idents by reference */
  if (child1 != NILP)
    x = pt2(FIDENT, pt1(COLLECT, child1), pt1(COLLECT, child2));
  else
    x = pt2(FIDENT, child1, pt1(COLLECT, child2));
#else
  /*- sws   this version will always loop to collect idents,
            pass by value */
  if (child1 != NILP)
    x = pt2(FIDENT, pt1(CCOLLECT, child1), pt1(CCOLLECT, child2));
  else
    x = pt2(FIDENT, child1, pt1(CCOLLECT, child2));
#endif

  x->namep = fun->name;
  x->namea = fun->name;
  x->n.type = fun->s.type;
  x->n.info = fun->s.info;
  x->n.oinfo = fun->s.oinfo;
  if ((fun->s.type != APLC_UKTYPE) && (fun->s.type != APLC_ANY))
    x->n.info |= (TYPEDECL | TYPEKNOWN);
  x->n.rank = fun->s.rank;
  if ( (fun->s.rank != NORANK) && (fun->s.rank != ANYRANK) )
    x->n.info |= (RANKDECL | RANKKNOWN);
#if 0
  fprintf(stderr,"[ptfun] %s, %s ", x->namep, x->namea);
  print_info(stderr, &x->n);fprintf(stderr,"\n");    
#endif
  return (x);
}

/* ptmrho - monadic rho (shape)
   - could also be rho rho, or rank
 */
struct node *
ptmrho(struct node * child)
{
  struct node *x;

  if (child->nodetype == RHO) {
    /* rank case */
    x = child;
    x->nodetype = RHORHO;
  } else {
    x = newnode(RHO);
    x->right = child;
  }
  return (x);
}

/* ptmsys - msysfun
 */
struct node *
ptmsys(int type, enum sfuns op, struct node * child)
{
  struct node *x;

  if (child->nodetype == IDENT) {
    x = pt1(type, child);
  } else {
    /* add a collect */
    x = pt1(type, pt1(COLLECT, child));
  }
  x->optype = op;
  return (x);
}


/* ptsub - subscripted assignment 

   SUB SUBASSIGN expression :     SUBASSIGN(SUB, expression)  

   sub is
   subid LB sublist RB : SUB(subid, sublist) 

   becomes
   SUBASSIGN
    left   subid
    right  expression
    axis   sublist (SM)
    store  SM
 */
struct node *
ptsub(struct node * child1, struct node * child2)
{
  child1->axis = child1->right;
  /* child1->left = child1->left */
  child1->right = child2;
  child1->store = pt1(SM, NILP);
  /* child1->store = NILP; */
  child1->nodetype = SUBASSIGN;
  return (child1);
}


/* pttop - top of expression 

   note that this controls the addition of a QUADASSIGN (printing of
   results)

*/
struct node *
pttop(struct node * child)
{
  struct node *x;
  int type;

  type = child->nodetype;
  /* if not assignment, print out expression */
  if (type == ASSIGN || type == QUADASSIGN || 
      type == DQUADASSIGN || type == QQUADASSIGN || type == DQQUADASSIGN ||
      type == SUBASSIGN)
    x = child;
  else if (type == ASYSVAR && child->right != NILP)
    x = child;
  else if (type == CATCH)
    x = child;
  else
    x = ptqass(child);
  /*x = pt1(QUADASSIGN, child);*/
  return (x);
}

/* ptsemi - semicolon */
struct node *
ptsemi(struct node * child1, struct node * child2)
{
  struct node *x;

  x = pt2(SM, child1, child2);
  if (child1 == NILP)
    x->ptr1 = 0;
  else
    x->ptr1 = child1->ptr1 + 1;
  return (x);
}

/* end of ptree.c */
