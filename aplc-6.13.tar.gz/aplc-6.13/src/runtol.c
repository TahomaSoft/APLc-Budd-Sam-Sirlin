/* runtol.c

	APL Compiler

	Run time system
	routines having to do with generating near integers

	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.
*/

#include "aplc.h"
#include <stdio.h>
#include <math.h>

/* declarations */
static double dabs(double r);
static int sign(double a);

/* sws   double abs function */
static double
dabs(double r)
{
  return ((r < 0.0) ? -r : r);
}

/* sws  near-integer type utility functions */
/* these come from the (proposed) ISO standard definitions */

/* get nearest integer, as double */
extern double
aplc_nearestint(double a)
{
  double c;

  if (a > 0) {
    c = floor(a);
    if (0.5 > a - (double) c)
      return (c);
    else
      return (1 + c);
  } else if (a < 0) {
    c = floor(a);
    if (0.5 >= a - (double) c)
      return (c);
    else
      return (1 + c);
  } else
    return (0);
}

/* get nearint, floor of rval within quad ct */
extern double
aplc_nearint(double rval)
{
  double c;

  c = aplc_nearestint(rval);
  if ((double) c < rval)
    return (c);
  else {
    if (c != 0) {
      if (aplc_toleq(rval, (double) c))
	return (c);
      else
	return (c - 1);
    } else {
      /* c == 0 */
      if (rval < -DBL_EPSILON)
	return (-1.0);
      else
	return (0.0);
    }
  }
}

/* sign function */
static int
sign(double a)
{
  if (a < 0.0)
    return (-1);
  else if (a > 0.0)
    return (1);
  else
    return (0);
}

/* tolerant equality */
/* a == b within quadct */
extern int
aplc_toleq(double a, double b)
{
  double aa, ab;

  if (a == b)
    return (1);
  else if (sign(a) != sign(b))
    return (0);
  else {
    aa = dabs(a);
    ab = dabs(b);
    if (aa < ab) {
      if (aa > ab - ab * DBL_EPSILON)
	return (1);
      else
	return (0);
    } else
      /* ab < aa */
    if (ab > aa - aa * DBL_EPSILON)
      return (1);
    else
      return (0);
  }
}

/*
check to determine if rval is a near integer
   return 1 or 0,
   *ival = pointer to nearint value
*/
extern int
aplc_isnearint(double rval, int *ival)
{
  int mval;

  *ival = (int) aplc_nearint(rval);
  mval =  - (int)aplc_nearint(-rval);
  if (*ival == mval)
    return (1);
  else
    return (0);
}

extern int
aplc_isnearintd(double rval, double *ival)
{
  double mval;

  *ival = aplc_nearint(rval);
  mval = -aplc_nearint(-rval);
  if (*ival == mval)
    return (1);
  else
    return (0);
}

/* end */

