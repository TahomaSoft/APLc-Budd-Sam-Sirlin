/*
	APL Compiler

	New leaf generation code
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include <stdio.h>
#include <string.h>
#include "parse.h"
#include "y_tab.h"
#include "gen.h"

/* gencond sws
   - a conditional node
   left :cond store right

   if (0==store) then 
     value = left
   else
     value = right

     store:  integer scalar
     left, right -- need to be collected into the same trs
  
*/   
extern void
gencond(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
  case SHAPE:
    adjdcls(node);

#if 0
    /* force left, right to use the same trs */
    RIGHT->ptr2 = LEFT->ptr2;
    RIGHT->ptr3 = LEFT->ptr3;
    RIGHT->ptr4 = LEFT->ptr4;
    RIGHT->ptr5 = LEFT->ptr5;
    RIGHT->index = LEFT->index;
#endif
    switchbox(STORE, SHAPE, 0);
    switchbox(STORE, VALUE, 0);
    /* ensure everything for store is done here */
    switchbox(STORE, FINISH, 0);
    /* if (0 == store->value.ip) {     */
    printf("if ( 0 == ");
    ctgen(STORE->c.values);
    printf(") {\n");

    switchbox(LEFT, SHAPE, 0);
    /*switchbox(LEFT, VALUE, 0);*/
    switchbox(LEFT, FINISH, 0);

    /* } else { */
    printf("}\nelse {\n");
    switchbox(RIGHT, SHAPE, 0);
    /*switchbox(RIGHT, VALUE, 0);*/
    switchbox(RIGHT, FINISH, 0);
    /* } */
    printf("}\n");

    /* copied from genident */
    if (!(node->n.info & TYPEKNOWN)) {
      node->c.type = gident(node->namep, ctypefield, APLC_UKTYPE);
    }
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gident(node->namep, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gident(node->namep, cshapefield, APLC_UKTYPE);
    node->c.values = gident(node->namep, cvalfield, rtype(node));
    /* only put it into a mp if we have to */
    if ( (rtype(node) == APLC_UKTYPE) ||
	 (rtype(node) == APLC_COMPLEX) ||
	 (rtype(node) == APLC_QUAT) ||
	 (rtype(node) == APLC_OCT) ||
	 ((node->n.info & SEQUENTIAL) && !is_scalar(node)) )
      leafshape(node, node->ptr1);
    /* otherwise might as well use given value */
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr1, rtype(node), node->ptr2);
    break;

  case FINISH:
    break;
  }

  return;
}


/*
  sws
  genlabel - generate code for label nodes 

  - Budd just used the same method as for other constants
    o build a vector of values l_fn[]
    o node value indexes into the vector 
    o code looks something like 
	stmtno = (l_epslon[0] * i5++);

  - these are known to be scalars, so we can generate better code

	ptr1 = memory pointer
	ptr2 = result register
	ptr3 = constant type
sws changed this
	ptr4 = scalar integer constant value
to this
        ptr0 = scalar integer constant value
as ptr0 is an int vs short for other ptrs
*/

extern void
genlabel(struct node * node, enum pmodes mode, int top)
{
  int lptr;

  switch (mode) {
  case SHAPE:
    node->ptr3 = node->n.type;
    lptr = node->n.values;/* save pointer into lconsts */
    adjdcls(node);
    node->ptr0 = lconsts[lptr].label_num;
    node->c.values = gicn(icnst, node->ptr0, 0);
    break;

  case COMBINE:
    break;

  case VALUE:
    /*node->c.values = gicn(icnst, node->ptr0, 0);*/
    break;

  case FINISH:
    break;
  }
  return;
}

/* genop - generate code for operator calls
   new code (sws)
	- could be niladic, monadic, or dyadic
	- could be function monadic, or dyadic

	- first just handle
	r .is a (f op) b
	r .is   (f op) b
	r .is a (f op g) b
	r .is   (f op g) b

	- and cases that don't return a value

	ptr1 - left trs
	ptr2 - right trs
	ptr3 - result trs
	ptr4 - mp for values
	ptr5 - result values
*/
extern void
genop(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);

    /* sws  initialize result type to APLC_UKTYPE */
    /* trsuk(node->ptr3);*/
    /* better: initialize result; slower though */
    /*inittrs(node->ptr3);*/
    inittrsn(node->namea);

    /* now expect that arguments are ccollect and are in a trs
       already that will be freed later 
       - node->ptr3
       - be sure that we use the same trs */
    if (LEFT != NILP) {
      switchbox(LEFT, SHAPE, 0);
      node->ptr1 = LEFT->ptr3;
    }
    if (RIGHT != NILP) {
      switchbox(RIGHT, SHAPE, 0);
      node->ptr2 = RIGHT->ptr3;
    }
    if ( (!(node->n.oinfo & O_LF)) && (node->funleft != NILP) )
      switchbox(node->funleft, SHAPE, 0);
    if ( (!(node->n.oinfo & O_RF)) && (node->funright != NILP) )
      switchbox(node->funright, SHAPE, 0);

    /* opident only */
#if 0
    printf("/* genop: %s */\n",str_optype(node->n.oinfo));
#else
    printf("/* genop: %s ",str_optype(node->n.oinfo));
    printf("valence %d, fdyadic %d, optype %d, LF %d, RF %d, vambiv %d */\n",
           node->n.oinfo & O_VALENCE,
           node->n.oinfo & O_F_DYADIC,
           node->n.oinfo & O_OPTYPE,
           node->n.oinfo & O_LF,
           node->n.oinfo & O_RF,
           node->n.oinfo & O_V_AMBIVALENT
           );
#endif
    printf("%s(", node->namep);
    /* the assigned variable */
    printf("%c%s, ", (is_pointer(node->namea) ? ' ' : '&'), node->namea);
    /* rest of operator call
       - not all these cases can happen */
    /* go through the list */
    if (LEFT == NILP) 
      printf("&aplc_nulltrs, ");
    else 
      printf("&trs%d, ", node->ptr1);
    /*   if ( (node->ptr0 == APLC_OP_FOF) || (node->ptr0==APLC_OP_FOV) ) {*/
    if ( node->n.oinfo & O_LF ) {
      if (node->funleft == NILP)
        printf("aplc_nullf, "); 
      else 
        printf("%s, ", node->funleft->namep);
    } else {
      /* var */
      if (node->funleft == NILP)
        printf("&aplc_nulltrs, "); 
      else 
        printf("&trs%d, ", node->funleft->ptr3);
    }
    if ( node->n.oinfo & O_RF ) {
      if (node->funright == NILP)
        printf("aplc_nullf, "); 
      else 
        printf("%s, ", node->funright->namep);
    } else {
      /* var */
      if (node->funright == NILP)
        printf("&aplc_nulltrs, "); 
      else 
        printf("&trs%d, ", node->funright->ptr3);
    }
    if (RIGHT == NILP) {
      /* no right - can't happen */
      printf("&aplc_nulltrs");
      prerror("[genop] op with no right value"); 
    } else 
      printf("&trs%d", node->ptr2);
    printf(");\n");

    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gident(node->namea, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gident(node->namea, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gident(node->namea, cshapefield, APLC_UKTYPE);
    node->c.values = gident(node->namea, cvalfield, rtype(node));

    if (!top) {
      /* only put it into a mp if we have to */
      if (rtype(node) == APLC_UKTYPE)
	leafshape(node, node->ptr4);
      else if ((node->n.info & SEQUENTIAL) && !is_scalar(node))
	leafshape(node, node->ptr4);
    }
    /* otherwise might as well use given value */
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
    if (LEFT != NILP)
      switchbox(LEFT, FINISH, 0);
    if (RIGHT != NILP)
      switchbox(RIGHT, FINISH, 0);
    /* sws   may want to free the result trs
       - should free the trs for the result, except if the previous
       node is assign, which will use the trs directly */
    if ( !(node->n.info & ASSIGNP) ) {
      /* certain scalars don't need to be freed */
      if (! declscalar(node) ) {

#ifdef DEBUGFREE
	printf("/* -- opident finish */\n");
#endif
	/*printf("aplc_detalloc(&trs%d);\n", node->ptr3);*/
#ifdef DEBUGFREE
	printf("/* -- */\n");
#endif
      }
    }
    break;
  }
  return;
}

#if 0
/* old verbose version */
extern void
genop(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);

    /* sws  initialize result type to APLC_UKTYPE */
    /* trsuk(node->ptr3);*/
    /* better: initialize result; slower though */
    /*inittrs(node->ptr3);*/
    inittrsn(node->namea);

    /* now expect that arguments are ccollect and are in a trs
       already that will be freed later 
       - node->ptr3
       - be sure that we use the same trs */
    if (LEFT != NILP) {
      switchbox(LEFT, SHAPE, 0);
      node->ptr1 = LEFT->ptr3;
    }
    if (RIGHT != NILP) {
      switchbox(RIGHT, SHAPE, 0);
      node->ptr2 = RIGHT->ptr3;
    }

    /* opident only */
    printf("%s(", node->namep);
    /* the assigned variable */
    printf("%c%s, ", (is_pointer(node->namea) ? ' ' : '&'), node->namea);
    /* rest of operator call
       - not all these cases can happen */
    if (RIGHT != NILP) {
      if (LEFT != NILP) {
        /* right and left values */
	if (node->funleft != NILP) {
          /* all but outer has fnleft */
          if (node->funright != NILP) {
            /* everything */
            printf("&trs%d, %s, %s, &trs%d);\n", 
                   node->ptr1, 
                   node->funleft->namep,
                   node->funright->namep,
                   node->ptr2);
          } else {
            /* no right function */
            printf("&trs%d, %s, aplc_nullf, &trs%d);\n", 
                   node->ptr1, 
                   node->funleft->namep,
                   node->ptr2);
          }
        } else {
          /* no left fn */
          if (node->funright != NILP) {
            /* all but left fn */
            printf("&trs%d, aplc_nullf, %s, &trs%d);\n", 
                   node->ptr1, 
                   node->funright->namep,
                   node->ptr2);
          } else {
            /* no right function either ?! */
            printf("&trs%d, aplc_nullf, aplc_nullf, &trs%d);\n", 
                   node->ptr1, node->ptr2);
          }
	}
      } else {
        /* no left value */
        if (node->funleft != NILP) {
          if (node->funright != NILP) {
            /* all have fnleft? */
            /* everything but left value */
            printf("&aplc_nulltrs, %s, %s, &trs%d);\n", 
                   node->funleft->namep,
                   node->funright->namep,
                   node->ptr2);
          } else {
            /* no left value or right function */
            printf("&aplc_nulltrs, %s, aplc_nullf, &trs%d);\n", 
                   node->funleft->namep,
                   node->ptr2);
          }
        } else {
          /* no funleft ?! */
          if (node->funright != NILP) {
            /* all right stuff */
            printf("&aplc_nulltrs, aplc_nullf, %s, &trs%d);\n", 
                   node->funright->namep,
                   node->ptr2);
          } else {
            /* no left value, fn, or right function */
            printf("&aplc_nulltrs, aplc_nullf, aplc_nullf, &trs%d);\n", 
                   node->ptr2);
          }
        }
      }
    } else {
      /* no right - can't happen */
      prerror("[genop] op with no right value"); 
    }

    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gident(node->namea, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gident(node->namea, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gident(node->namea, cshapefield, APLC_UKTYPE);
    node->c.values = gident(node->namea, cvalfield, rtype(node));

    if (!top) {
      /* only put it into a mp if we have to */
      if (rtype(node) == APLC_UKTYPE)
	leafshape(node, node->ptr4);
      else if ((node->n.info & SEQUENTIAL) && !is_scalar(node))
	leafshape(node, node->ptr4);
    }
    /* otherwise might as well use given value */
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
    if (LEFT != NILP)
      switchbox(LEFT, FINISH, 0);
    if (RIGHT != NILP)
      switchbox(RIGHT, FINISH, 0);
    /* sws   may want to free the result trs
       - should free the trs for the result, except if the previous
       node is assign, which will use the trs directly */
    if ( !(node->n.info & ASSIGNP) ) {
      /* certain scalars don't need to be freed */
      if (! declscalar(node) ) {

#ifdef DEBUGFREE
	printf("/* -- opident finish */\n");
#endif
	/*printf("aplc_detalloc(&trs%d);\n", node->ptr3);*/
#ifdef DEBUGFREE
	printf("/* -- */\n");
#endif
      }
    }
    break;
  }
  return;
}
#endif

/*
 genqquad_assign - generate code for input quote quad assignment 
	ptr1 - (none)
	ptr2 - right trs
	ptr3 - result trs
	ptr4 - mp for values
	ptr5 - result register */
extern void
genqquad_assign(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);

    /* collect right in a trs */
    filtrs(node->ptr2, RIGHT);

    printf("aplc_qquad_assign(&trs%d);\n", node->ptr2);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);

    if (!top) {
      /* note that this doesn't copy valuesknown.  the valuesknown
	 stuff doesn't seem to work or to be useful, so maybe should
	 be dropped...  */

      copychild(node, RIGHT, 1, 1, 1);
      node->c.values = RIGHT->c.values;
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    /*leafvalue(node, node->ptr4, rtype(node), node->ptr5);*/
    ieqi( RIGHT->index, node->index);
    switchbox(RIGHT, VALUE, 0);
    node->c.values = RIGHT->c.values;
    printf("/* qq rv: "); ctgen(RIGHT->c.values); printf("*/\n");
    break;

  case FINISH:
    /* need to check this */
    switchbox(RIGHT, FINISH, 0);
    break;
  }
  return;
}


/*
	gentcav -
		generate code for atomic vector tc components
                (terminal control)
                this is a leaf 
*/
extern void
gentcav(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
#if 0
    printf("/* value = %d*/\n", node->n.values);
#endif
    /* node->c.values = gicn(icnst, node->n.values, APLC_INT);*/
    node->c.values =
      gcast(castop, gicn(icnst, node->n.values, APLC_INT), rtype(node));
    break;

  case COMBINE:
    break;

  case VALUE:
    break;

  case FINISH:
    break;

  }
  return;
}

/* gentypecon -
   generate code for type constants
   this is a leaf */
extern void
gentypecon(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
#if 0
    printf("/* value = %d*/\n", node->n.values);
#endif
    /* node->c.values = gicn(icnst, node->n.values, APLC_INT);*/
    node->c.values = gicn(tcnst, node->n.values, APLC_INT);
    break;

  case COMBINE:
    break;

  case VALUE:
    break;

  case FINISH:
    break;
  }
  return;
}

/* end */


