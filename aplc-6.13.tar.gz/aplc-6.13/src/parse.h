/* 
 APL Compiler parse stage definitions

 structures and definitions used by the APL compiler 

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_PARSE_H
#define _APLC_PARSE_H

#define APLC_PARSER

/* sws */
#if HAVE_MALLOC
#include <malloc.h>
#endif
#include <string.h>

#include "aplc.h"
#include "ctree.h"


#ifdef SUNOS4
#ifndef TRADITIONAL
/* sws  sun4 declarations */
extern int fputs(const char *, FILE *);
extern void free(void *);
extern int puts(const char *);
#endif
#endif


/* -------------------------------------------------------- */
/* define some limits */

/* maximum lines in a fn 
   - currently used in intra.c */
#define MAXSTMTS 500

/* max number of each type real, int, char, ... */
/*#define MAXCONSTS 5000*/
#define MAXCONSTS 50000

/* maximum length of a name, variable, fn, or label (actually 1 less
   than this) */
#define MAX_NAME_LEN 120

/* -------------------------------------------------------- */

/* structalloc - malloc a structure */
#define structalloc(type) (struct type *) malloc(sizeof(struct type ))

/* allocate (size) ints */
#define Imalloc(size) (int *)malloc((size_t)(size)*sizeof(int))

/* parse tree i/o constants */
#define GLSYM  01
#define MNPROG 02
#define PROG   03
#define OPPROG 04
#define CONSTS 05
#define STMT   06
#define ESTMT  07
#define SYMS  011
#define ESYMS 012
/*#define GLFN  013
  #define GLOP  014*/

/* rank types */
#define NORANK  -1 /* a rank of -1 means rank is not known */
#define ANYRANK -2 /* arbitrary rank  sws */

/* information bits

   VALUESKNOWN assumes values known at compile time, and put into a 
   static vector [irc]_fnname

   these are stored in an int, probably 32bits
   we're using 24 bits

 */
#define TYPEDECL	01   /* type was declared by user 
				or node is known constant */
#define TYPEKNOWN	02   /* type is known (may have been inferred) */
#define RANKDECL	04   /* rank was declared by user 
				or node is known constant */
#define RANKKNOWN      010   /* rank is known at compile time */
#define SHAPEKNOWN     020
#define VALUESKNOWN    040
#define FIRSTAXIS     0100   /* for functions with axis */
#define LASTAXIS      0200
/* 0400 */
#define SEQUENTIAL   01000   /* will access in sequential order */
#define HAVEVALUE    02000   /* will have value at end of shape phase */
#define NOINDEX      04000   /* no index register is needed for expr */
#define MERGED      010000   /* node has been merged with one higher up */
#define ASSIGNP     020000   /* previous node is assign */
/* 040000 */
#define EARLYBIND    0100000   /* assign needs to bind to ident in shape phase */
#define HAVETRS      0200000   /* have a trs at the end of shape phase */


#define SHAPEARB    02000000   /* shape known to be arbitrary */
/*#define VALUESARB   04000000*/   /* values arbitrary */
#define ASSNAMEREF 010000000   /* assignment name is used on right */
#define ASSNAMEOK  020000000   /* ok to use name in assignment */
#define HAVENAME   040000000   /* set values to namep, in shape phase */

/* rank is really known */
#define RankIsKnown(node) ((node->n.info & RANKKNOWN) && (ANYRANK != node->n.rank))
#define sRankIsKnown(sym) ((sym->s.info & RANKKNOWN) && (ANYRANK != sym->s.rank))


#define LEFT     (node->left)
#define RIGHT    (node->right)
#define AXIS     (node->axis)
#define STORE    (node->store)
#define FUNLEFT  (node->funleft)
#define FUNRIGHT (node->funright)

#define NILP (struct node *) 0

#define NILCHAR (char *) 0
#define DEFAULTINDEX 999


/* identifier class types for the symbol tables */
typedef enum classes {
  NOCLASS, 
  GLOBAL,        /* variable */
  LOCAL,         /* local variable */
  PARAM,         /* variable - local, passed in to fn/op header */
  APARAM,        /* variable - local, passed out of fn/op header */
  LABCLASS,      /* label - local var; used?? */
  LFUNCTION,     /* local function */
  FUNCTION,      /* global fn */
  OPERATOR,      /* global op */
  GLOCAL,        /* global variable, locally declared */
  GLOCALCOPY,    /* global variable, already declared */
  GLFUNCTION,    /* global function, locally declared */
  GLFUNCTIONCOPY /* global function, already declared */
} class_t;

/* information structure, used in node and symbol table entry */
typedef struct {
  int info; /* information bits */
  int type;
  int rank;
  int shape;
  int size;
  int values;
  int oinfo;/* information bits for operators; type, valence */
} info_t;

/* symbol table entry (node) */
typedef struct symnode {    
  char *name;
  char *glbname;/* an alternate for passing values  */
  class_t class;
  int depth;
  info_t s;
  struct symnode *next;
} symnode_t;
#define NILSYM (struct symnode *) 0

/* int and tree - int (if known at compile time) or 
   a code tree (if generated at run time) node */
typedef struct {
  int n;
  struct codetree *c;
} int_tree_t;

/* node - a parse tree node 
   note that optype can be sfuns or sysvars 
   - these are initialized by newnode in ptree.c */
typedef struct node {
  int nodetype;                    /* node type */
  struct node *right, *left;       /* right and left children nodes */
  struct node *funright, *funleft; /* right and left fun nodes */
  struct node *store;              /* extra child node (subassign) */
  struct node *axis;               /* axis node */
  info_t n;                        /* information bits */
  char   *namep; /* name pointer, for vars and funs */
  char   *namea; /* extra name pointer, for fun asgn */
  int *ip; /* integer pointer, for exp arrays */
  struct {
    codetree_t *type;
    codetree_t *rank;
    codetree_t *shape;
    codetree_t *size;
    codetree_t *values;
  } c; /* code */
#if 0
  int_tree_t trs;    /* value as trs; tbd */
#endif
  enum sfuns optype;           /* operator (for reduce, outer, etc) */
  symnode_t *symnode;/* symnode, for parsing */
  int index;                   /* index pointer number */
  short tptr;		       /* pointers for trs */
  int   ptr0;   	       /* an extra useful pointer */
  short ptr1;		       /* pointers with various meanings */
  short ptr2;
  short ptr3;
  short ptr4;
  short ptr5;
  short ptr6;
  short ptr7;
  short ptr8;
  short ptr9;
  short ptr10;
  short ptr11;
  short ptr12;
  short ptr13;
} node_t;


#define axisgiven(n) (n != NILP)


/* function header information 
   operator header information */
typedef struct headnode {   
  char *opname; 	/* function/operator name */
  char *lfname; 	/* left function name */
  char *rfname; 	/* right function name */
  char *asvar;		/* name of assigned to variable */
  char *parm1;		/* name of left (first) parameter */
  char *parm2;		/* name of right (second) parameter */
  int  maxtrs;		/* number of trs registers used */
  int  maxmp;		/* number of mp registers used */
  int  maxres;		/* number of res registers used */
  int  maxi;		/* number of index registers used */
} headnode_t;

#define NILHEAD (struct headnode *) 0

typedef struct statenode {      /* statement node */
  char *label;
  struct node *code;
  struct statenode *nextstate;
  struct symnode *list;
} statenode_t;

#define NILSTATE (struct statenode *) 0

/* sws new version is a struct, not a union, 
   to keep both name and line number */
struct label_struct {
  char *label_name;
  int label_num;
  int valid;    
};

/* 
  may want to define a temp parsing structure
*/
typedef struct {
  node_t *gk;   /* current node */
  node_t *gp;   /* current pointer in line */
  node_t *gend; /* current end value */
} gparse_t;


/* kind of a node
   just for parsing */
enum parse_node_kind {PNK_NONE, PNK_VAL, PNK_FN, PNK_OP};

/* bits for the valence part of info, which is composed of two parts

   1 function/operator valence (number of function/variable arguments)

   2 operator operand types
   - operators have 4 arguments, 2 inner and 2 outer
     inner argument (operands) can be function or variable
     making 4 possible types

   - not all bit combinations valid 
   
*/

/* these have to do strictly with the valence, inner and outer */
#define NOVALENCE          0 /* default valence for symbol table entry */
#define O_VALENCE         01 /* valence valid */
#define O_F_MONADIC        0
#define O_F_DYADIC        04 /* inner dyadic (f o f); else monadic (f o) */
#define O_V_MONADIC        0
#define O_V_AMBIVALENT   020 /* outer ambivalent v() v or () v; else monadic */
/* these have to do with the type of the 2 inner arguments */
#define O_OPTYPE        0100 /* operand types defined */
#define O_LF            0200 /* left is fn (f o x); else var (v o x) */
#define O_RF            0400 /* right is fn (x o v); else var (x o v) */

/* some extra defines, for clarity */
#define O_LV               0 /* left is var (v o) x */
#define O_RV               0 /* right is var (x o v) x */
#define O_NON (0)
#define O_MONADIC_MONADIC (O_F_MONADIC|O_V_MONADIC)


#include "const.h"
#include "pass.h"

#include "symutil.h"
#include "putil.h"

#endif /* PARSE_H */
