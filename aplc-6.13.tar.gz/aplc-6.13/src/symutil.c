/*
	APL Compiler

	general symbol table utilities for parse stage
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.
*/

#include <stdio.h>

#include "parse.h"
#include "y_tab.h"

/* turn on some prints for debugging */ 
#define DEBUG 1

/* ----------------------------------------------- */

/* initialize an info structure 
   - part of a symbol table entry or node */
extern void
init_info(info_t *x)
{
  x->info = x->type = x->rank = x->shape = x->values = 0;
  x->size = -1;
  x->oinfo = 0;
  return;
}

/* initialize a codetree, as defined in ctree.h */
extern void
init_codetree(codetree_t *x)
{
  x->cop = 0;
  x->c0.cindex = 0;
  x->c1.ctfield = 0;
  x->c2.ctype = 0;
  return;
}

/* newnode - produce a new parse tree node */
extern struct node *
newnode(int type)
{
  struct node *x;

  x = structalloc(node);
  if (x == (struct node *) 0)
    error("out of space");
  x->nodetype = type;
  x->left = x->right = x->axis = x->store = NILP;
  x->funleft = x->funright = NILP;
  x->namep = NILCHAR;
  x->namea = NILCHAR;
  init_info(&(x->n));
  x->namep = NULL;
  x->namea = NULL;
  x->ip = NULL;
  x->c.type = NULL;
  x->c.rank = NULL;
  x->c.shape = NULL;
  x->c.size = NULL;
  x->c.values = NULL;
  x->optype = APLC_NOT;
  x->symnode = NILSYM;
  x->index = 0;
  x->tptr = 0;
  x->ptr0 = 0;
  x->ptr1 = 0;
  x->ptr2 = 0;
  x->ptr3 = 0;
  x->ptr4 = 0;
  x->ptr5 = 0;
  x->ptr6 = 0;
  x->ptr7 = 0;
  x->ptr8 = 0;
  x->ptr9 = 0;
  x->ptr10 = 0;
  x->ptr11 = 0;
  x->ptr12 = 0;
  x->ptr13 = 0;
  return x;
}

/*  addcollect - add a collect node into the tree to avoid
    repeated calls on a costly operation */
extern struct node *
addcollect(struct node * node)
{
  struct node *x;
  
  x = newnode(COLLECT);
  x->right = node;
  /* sws  add information if available */
  if (node->n.info & TYPEKNOWN) {
    x->n.type = node->n.type;
    x->n.info |= TYPEKNOWN;
  }
  if (node->n.info & RANKKNOWN) {
    x->n.info |= RANKKNOWN;
    x->n.rank = node->n.rank;
  }
  if (node->n.info & SHAPEKNOWN) {
    x->n.info |= SHAPEKNOWN;
    x->n.shape = node->n.shape;
  }
  return x;
}

/* lookup_name - see if a name is in a symbol table
   return pointer to it in the table if found */
extern struct symnode *
lookup_name(char *name, struct symnode *table)
{
  if (name == '\0') {
    error("[lookup_name] name is void ");
    return NILSYM;
  }
  for (; table != 0; table = table->next) {
    if (strcmp(name, table->name) == 0) {
      return table;
    }
  }
  return NILSYM;
}

extern int
sym_class_match( class_t c1, class_t c2)
{
  int r = 0;

  switch(c1) {
  case PARAM:
  case APARAM:
  case LOCAL:
    switch(c2) {
    case PARAM:
    case APARAM:
    case LOCAL:
      r = 1;
      break;
    default:
      r = 0;
      break;
    }
    break;
  case GLOCAL:
  case GLOCALCOPY:
    switch(c2) {
    case GLOCAL:
    case GLOCALCOPY:
      r = 1;
      break;
    default:
      r = 0;
      break;
    }
    break;
  case GLFUNCTION:
  case GLFUNCTIONCOPY:
    switch(c2) {
    case GLFUNCTION:
    case GLFUNCTIONCOPY:
      r = 1;
      break;
    default:
      r = 0;
      break;
    }
    break;
  default:
    if (c1 == c2)
      r = 1;
    else
      r = 0;
    break;
  }
  return r;
}

/* return 1 if two strings match */
extern int
name_strmatch(char *n1, char *n2)
{
  int i, n;

  if (!n1) {
    if (n2)
      return 0;
    else
      return 1;
  }
  if (!n2)
    return 0;
  n = strlen(n1);
  if (n != strlen(n2))
    return 0;
  for (i=0; i<n; i++)
    if (n1[i] != n2[i])
      return 0;
  return 1;
}

/* return a pointer to a copy of string name 
   - space for the name will be malloc'ed  */
extern char *
name_strcpy(char *name)
{
  char *x;

  if ( (x = (char *) malloc( (size_t) strlen(name)+1)) )
    strcpy(x, name);
  else {
    fprintf(stderr,"[name_strcpy] no space for [%s]\n", name);
    error("no space left");
  }
  return x;
}

/* add_sym - place a new symbol into a symbol table 
   lookup name in table, if not present, add it into table
   also, if alias not nill,  lookup alias in atable, update table attributes
*/
extern symnode_t *
add_sym(char *name,   struct symnode **table, 
	char *alias,  struct symnode **atable, 
	class_t class, int type, int rank, int valence)
{
  symnode_t *x, *y, *xa;

#if DEBUG
  fprintf(stderr,"[add_sym] name %s, %s, type %s, rank %s, valence %d (%s,%s)\n", 
	  name, str_class(class), str_type_name(type), str_rank(rank),
          valence, str_valence(valence), str_optype(valence));
#endif
  x = lookup_name(name, *table);

  if (x != NILSYM) {
    /* already in table, update attributes 
       - could already be set to uktype/norank (locals)
       or any/anyrank  (params) */
#if DEBUG
    fprintf(stderr, "[add_sym] (found) symbol table %s: %s ",
	    name, str_class(x->class) );
    print_info(stderr, &(x->s));
    fprintf(stderr,"\n");
#endif
    if (! sym_class_match(class, x->class) ) {
      fprintf(stderr,"[add_sym] %s new class %s, existing class %s\n",
	      name, str_class(class), str_class(x->class));
      print_sym(stderr,x);
      print_symtab(stderr, *table);
      error("conflicting class declaractions");
    }
    if (type != APLC_UKTYPE) {
      if ( (x->s.type != APLC_UKTYPE) && (x->s.type != APLC_ANY) && 
	   (x->s.type != type) ) {
	fprintf(stderr,"[add_sym] %s t,r %d %d, existing t,r %d %d\n",
		name,type,rank, x->s.type, x->s.rank);
	error("conflicting type declaractions");
      } else {
	x->s.type = type;
	x->s.info |= TYPEKNOWN; 
	if (type != APLC_UKTYPE)
	  x->s.info |= TYPEDECL; 
      }
    }
    if (rank != NORANK) {
      if (rank != ANYRANK) {
	if (x->s.rank != NORANK && x->s.rank != ANYRANK && 
	    x->s.rank != rank)
	  error("conflicting rank declaractions");
	else {
	  x->s.rank = rank;
	  x->s.info |= RANKKNOWN;
	  x->s.info |= RANKDECL; 
	}
      } else { /* ANYRANK */
	x->s.rank = ANYRANK;
	x->s.info |= RANKKNOWN;
      }
    }
    if (valence & O_VALENCE) {
      if ( (x->s.oinfo & O_VALENCE) && 
           (extract_valence(x->s.oinfo) != extract_valence(valence) ) ) {
        fprintf(stderr,"valence %d (%d), existing: %d (%d)\n", 
                valence, extract_valence(valence),
                x->s.oinfo, extract_valence(x->s.oinfo));
        fprintf(stderr,"valence %s, existing: %s\n", 
                str_valence(valence),
                str_valence(x->s.oinfo));
        error("conflicting valence declaractions");
      } else
        x->s.oinfo |= extract_valence(valence);
    }
    if (valence & O_OPTYPE) {
      if ( (x->s.oinfo & O_OPTYPE) && 
           (extract_optype(x->s.oinfo) != extract_optype(valence) ) ) {
        fprintf(stderr,"optype %d, existing: %d\n", 
                valence, x->s.oinfo);
        fprintf(stderr,"optype %s, existing: %s\n", 
                str_valence(valence),
                str_valence(x->s.oinfo));
        error("conflicting optype declaractions");
      } else
        x->s.oinfo |= extract_optype(valence);
    }
    valence = x->s.oinfo;
    /* check for operator definition 
       - given a header we may need to set default op types */
    if ( (class == OPERATOR) && (valence & O_VALENCE) ) {
      if (! (valence & O_OPTYPE)) {
        /* default to fn types for whatever we have */
        valence |= O_OPTYPE;
        valence |= O_LF;
        if (valence & O_F_DYADIC)
          valence |= O_RF;
      }            
    }
    x->s.oinfo = valence;
  } else {
    /* not already in the table - add it */
    x = structalloc(symnode);
    if (x == NILSYM)
      error("[add_sym] out of room");
    /*x->name = name;*/
    x->name = name_strcpy(name);
    x->glbname = NILCHAR;
    if (x->name == 0)
      error("[add_sym] out of room for name");
    x->class = class; 
    init_info(&(x->s));
    x->s.type = type;
    x->s.rank = rank;
    /* check for operator definition 
       - given a header we may need to set default op types */
    if ( (class == OPERATOR) && (valence & O_VALENCE) ) {
      if (! (valence & O_OPTYPE)) {
        /* default to fn types for whatever we have */
        valence |= O_OPTYPE;
        valence |= O_LF;
        if (valence & O_F_DYADIC)
          valence |= O_RF;
      }            
    }
    x->s.oinfo = valence;
    if (type != APLC_UKTYPE) {
      x->s.info |= TYPEKNOWN; 
      if (type != APLC_ANY)
	x->s.info |= TYPEDECL; 
    }
    if (rank != NORANK) {
      if (rank != ANYRANK) {
	x->s.info |=  RANKKNOWN;
	x->s.info |= RANKDECL; 
	if (rank == 0) {
	  x->s.info |=  SHAPEKNOWN; 
	  x->s.size = 1;
	}
      } else {
	x->s.info |=  RANKKNOWN;
	x->s.rank = ANYRANK;
      }
    }
#if 1
    /* this adds to the end of the symbol table 
       - makes it easier to pass */
    x->next = 0;
    if (*table == 0)
      *table = x;/* the only entry */
    else {
      /* go to the last element */
      y = *table; 
      while (y->next != 0)
	y = y->next;
      y->next = x;
    }
#else
    /* this adds the new entry to the beginning */
    x->next = *table;
    *table = x;
#endif
  }

  /* now check alias */
  if (alias) {
    xa = lookup_name(alias, *atable);
    if (xa != NILSYM) {
      /* found the given alias in table, update attributes */
#if DEBUG
      fprintf(stderr, "[add_sym] found symbol table alias %s: %s ",
	      alias, str_class(xa->class) );
      print_info(stderr, &(xa->s));
      fprintf(stderr,"\n");
#endif

#if 0
      /* expect different classes */
      if (! sym_class_match(x->class, xa->class) ) {
	fprintf(stderr,"[add_sym] %s class %s, alias %s, class %s\n",
		name, str_class(x->class), 
		alias, str_class(xa->class));
	error("conflicting class declaractions");
      }
#endif
      x->glbname = xa->glbname;
      if (xa->s.type != APLC_UKTYPE) {
	if ( (x->s.type != APLC_UKTYPE) && (x->s.type != APLC_ANY) && 
	     (x->s.type != xa->s.type) ) {
	  fprintf(stderr,"[add_sym] %s t,r %d %d, alias %s t,r %d %d\n",
		  name,x->s.type,x->s.rank, 
		  alias, xa->s.type, xa->s.rank);
	  error("conflicting type declaractions");
	} else {
	  x->s.type = xa->s.type;
	  x->s.info |= TYPEKNOWN; 
	  if (type != APLC_ANY)
	    x->s.info |= TYPEDECL; 
	}
      }
      if (xa->s.rank != NORANK) {
	if (xa->s.rank != ANYRANK) {
	  if (x->s.rank != NORANK && x->s.rank != ANYRANK && 
	      x->s.rank != xa->s.rank)
	    error("conflicting rank declaractions");
	  else {
	    x->s.rank = xa->s.rank;
	    x->s.info |= RANKKNOWN;
	    x->s.info |= RANKDECL; 
	  }
	} else { /* ANYRANK */
	  x->s.rank = ANYRANK;
	  x->s.info |= RANKKNOWN;
	  x->s.info |= RANKDECL; 
	}
      }
    }
  } /* end of alias update */

  /* scalar check - if rank is 0, then we know the shape, size */ 
  if ( (x->s.info & RANKKNOWN) && (x->s.rank != ANYRANK) ) {
    if (x->s.rank == 0) {
      x->s.info |= SHAPEKNOWN;
      x->s.size = 1;
    }
  }


#if DEBUG
  /*fprintf(stderr, "[add_sym+] %s, ",name);
    print_info(stderr, &(x->s));*/
  fprintf(stderr, "[add_sym+] ");
  print_sym(stderr, x);
  /*fprintf(stderr,"\n");*/
  fprintf(stderr,"\nCurrent symbol table:\n");
  print_symtab(stderr, *table);
#endif
  return x;
}

/* extract valence info from .oinfo */
extern int 
extract_valence(int o)
{
  int r = 0;
  
  if (o & O_VALENCE) {
    r |= O_VALENCE;
    if (o&O_F_MONADIC)
      r |=O_F_MONADIC;
    if (o&O_F_DYADIC)
      r |=O_F_DYADIC;
    if (o&O_V_MONADIC)
      r |=O_V_MONADIC;
    if (o&O_V_AMBIVALENT)
      r |=O_V_AMBIVALENT;
  }
  return r;
}

extern int 
extract_optype(int o)
{
  int r = 0;

  if (o & O_OPTYPE) {
    r = O_OPTYPE; 
    if (o & O_LF)
      r |= O_LF;
    if (o & O_RF)
      r |= O_RF;
  }
  return r;
}

/* return the valence of a function / operator 
   - this is the outer or variable valence for an operator, not the
     inner or function valence

   0 niladic
   1 mondaic only
   2 dyadic  only
   3 ambivalent
*/
extern int
get_valence(int type)
{
  int val;

  switch (type) {
  default:
    val = 3;
    break;

    /* list of all tokens */

  case CLASS:
  case TYPE:
  case RANK:
  case DEL:
  case GO:
  case COMMENT:
  case COLLECT:
  case CVEC:
  case CIVEC:
  case CSCALAR:
  case CISCALAR:
  case CCOLLECT:
  case ASSIGN:
  case SUBASSIGN:
  case QUAD:
  case QQUAD:
  case QQUADASSIGN:
  case QUADLZ:
  case IDENT:
  case LCON:
  case SCON:
  case BCON:
  case ICON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case NL:
  case LP:
  case RP:
  case LB:
  case RB:
  case BQT:
  case SM:
  case COLON:
  case DOLLAR:
  case INNERCHILD:
  case EMPTSEMI:
  case BOX:
  case AVEC:
  case TCAV:
  case TYPECON:
  case ASYSVAR:
  case SYSVAR:
  case ALPHA:
  case OMEGA:
  case CATCH:
  case ATERM:
  case TERM:
    val = 0;
    break;

    /* monadic */
  case QUADASSIGN:

    /* ops */
  case SLASH:
  case COMPRESS:
  case REDUCE:
  case BSLASH:
  case EXPAND:
  case SCAN:

  case SORT:
  case GRADEUP:
  case GRADEDOWN:
  case RAVEL:
  case EXECUTE:
  case UNBOX:
  case MSYSFUN:
  case CGOTO:
    val = 1;
    break;

    /* dyadic */
    /* nya */
  case DQUAD:
  case DQQUAD:
  case DQUADASSIGN:
  case DQQUADASSIGN:

#if 0
  case SLASH:/* these should probably be monadic ops ... */
  case BSLASH:
  case COMPRESS:
#endif

  case APPLY:
  case COND:
  case DOT:
  case OUTER:
  case INNER:
  case DECODE:

  case EPSILON:
  case INDEXOF:
  case DTRANS:
  case ROTATE:
  case TAKE:
  case DROP:
  case GWTAKE:
  case GWDROP:
  case RESHAPE:
  case SUB:
  case CAT:
  case RESHAPEX:
  case LAM:
  case DEAL:
  case ENCODE:
  case DFORMAT:
  case LINK:
  case MATCH:
  case MSOLVE:
  case DSYSFUN:
  case AXISO:
    val = 2;
    break;

    /* ambivalent */
  case LCARET:
  case RCARET:
  case DOMINO:
  case FIDENT:
  case FORMAT:
  case IOTA:
  case MSFUN:
  case OPIDENT:
  case UIDENT:
  case FNCON:
  case CM:
  case DSFUN:
  case REVERSE:
  case RHO:
  case RHORHO:
  case ROLL:
  case TRANS:
  case ANON:
  case ESYSFUN:
  case EACH:
    val = 3;
    break;
  }
  return val;
}

/* function to generate a name 
   use main_funname_name */
extern char *
fid_gen_global(char *name)
{
  int nf,nn,nt;
  char *s;
  char mn[] = "main";
  
  nf = strlen(funname);
  nn = strlen(name);
  nt = 1 + 4+2+ nf + nn;
  s = (char *) malloc((size_t) nt);
  if (! s) {
    fprintf(stderr,"[fid_gen_global] no space for [%s]\n", name);
    error("no space left");
  }
  strcpy(s,mn);
  s[4] = '_';
  strcpy(&s[5],funname);
  s[5+nf] = '_';
  strcpy(&s[6+nf],name);
#if 1 /* FIXME ... */
  fprintf(stderr,"[fid_gen_global] local fun name %s\n",s); 
#endif  
  return s;
}


/* end */

