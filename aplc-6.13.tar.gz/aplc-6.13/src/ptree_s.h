/*
	APL Compiler

	more parse tree function declarations
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_PTREE_S_H
#define _APLC_PTREE_S_H

struct node *ptanon(struct node * child);
struct node *ptfncon_name(char *fname);

extern int addanoncon(struct node *child);

struct node *ptapplyfun(struct node *fun, struct node *child1, struct node *child2);
struct node *ptcond(int type, struct node *lt, struct node *st, 
		    struct node *rt);
struct node *ptstore(int);
struct node *ptqass(struct node * child);
struct node *ptqlzass(struct node * child);

struct node *pttcav(int type, enum sysvars var);
struct node *pttycon(int type, int var);

struct node *ptnilfun(struct symnode * fun);

struct headnode *newophead(char *parm1, char *fname, char *name, 
			   char *rfname, char *parm2);


symnode_t *pt_msys2fn(enum sfuns op);
symnode_t *pt_dsys2fn(enum sfuns op);
struct node *symnode2node(struct symnode *fun);

struct node *
ptop(node_t *child1, node_t*lfun, struct symnode *op, 
     node_t *rfun, struct node *child2,     int valence);
/*
struct node *ptop(struct node *child1, struct symnode *fun, 
		  struct symnode *op, 
		  struct symnode *rfun, struct node *child2,
		  int oinfo);
*/

struct node *ptsmtolink(struct node *child);
struct node *ptgobj(int type, enum sfuns sfun, enum sysvars sysfun, 
		    struct symnode * fun);
struct node *cat_gobj(struct node *node, struct node *right);

/* from ptree_array.c */

/* for string arrays */
struct node *ptsta(char *chars);
struct node *addsta(struct node *x, char *chars);
struct node *addstanl(struct node * x);
struct node *finsta(struct node * x);

/* for numeric arrays */
extern struct node *pt_na(struct node *x);
extern struct node *add_na(struct node *x, struct node *new);
extern struct node *add_nanl(struct node * x);
extern struct node *fin_na(struct node * x);

/* for expression arrays */
extern struct node *pt_expa(struct node *x);
extern struct node *add_expa(struct node *x, struct node *new);
extern struct node *add_expanl(struct node * x);
extern struct node *fin_expa(struct node * x);

#endif /* _APLC_PTREE_S_H */
