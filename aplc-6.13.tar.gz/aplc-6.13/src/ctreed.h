/*
	APL compiler

	declarations for code trees.
        sws
*/

#ifndef _APLC_CTREED_H
#define _APLC_CTREED_H

#endif

