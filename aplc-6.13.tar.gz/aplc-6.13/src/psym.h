/*  psym.h 

        parser symbol table declarations
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_PSYM_H
#define _APLC_PSYM_H

#include "parse.h"

extern void print_all_symtab(void);
extern struct symnode **lsymtab;
/*extern struct symnode *lfsymtab;*/
/* global */
/*extern struct symnode *gsymtab, *gfsymtab, *gopsymtab;*/
extern struct symnode **gsymtab;

extern void init_symtabs(void);
extern void push_lsymtab(void);
extern void pop_lsymtab(void);

extern void reinit_local_symtab(void);
extern class_t idclass(char *name, struct symnode ** symptr);


#if FILE_LINE_DEBUG
#define id_lookup(x) id_lookup_fn(__FILE__, __LINE__, x) 
#define enterid(name,class,type,rank,valence)  enterid_fn(__FILE__, __LINE__, name,class,type,rank,valence) 
#else
#define id_lookup(x) id_lookup_fn("", 0, x) 
#define enterid(name,class,type,rank,valence)  enterid_fn("", 0, name,class,type,rank,valence) 
#endif
extern struct symnode *id_lookup_fn(char *file, int line, struct node *x);
extern struct symnode *enterid_fn(char *file, int line,
				  char *name, enum classes class, 
				  int type, int rank, int valence);
extern int get_fop_valence(headnode_t *head);
extern int get_fop_valence_comp(char *left, char*lf);

#endif /* _APLC_PSYM_H */
/* end of psym.h */
