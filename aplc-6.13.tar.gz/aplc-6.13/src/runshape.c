/*
	APL Compiler

	Run time system
	routines having to do with type and shape computations
	tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include <stdio.h>
#include "aplc.h"
#include "memalloc.h"

/* ---------------------------------------------------------------- */
/* sws   tests for aplc_dsfuns */
/*       this includes length 1 vectors */
#define issingleton(r,s)  ( (r == 0) || ((r == 1) && (*s == 1)) )
#define isscalar(r,s)     (r == 0)

/* for debugging; 0,1,2 */
#define SDEBUG 0

/* ---------------------------------------------------------------- */
/* local declarations */
static int *addaxis(int *shape, int rank, int k);
static int findaxis(int k, int start, int rank, int *shape );


/* ---------------------------------------------------------------- */
/* mergetype - return the result type of joining two types via catenate
               or subassign
	       sws
	       */
int
aplc_mergetype(int lefttype, int righttype)
{
  return (lefttype > righttype) ? lefttype : righttype ;
}

/* aplc_dsfunt - return the type of a dyadic scalar function */
int
aplc_dsfunt(enum sfuns op, int lefttype, int righttype)
{
  int maxtype;

  maxtype = (lefttype > righttype) ? lefttype : righttype;

  switch (op) {
  case APLC_AND:
  case APLC_OR:
  case APLC_NAND:
  case APLC_NOR:
  case APLC_LT:
  case APLC_LE:
  case APLC_EQ:
  case APLC_NE:
  case APLC_GE:
  case APLC_GT:
    return (APLC_BOOL);

  case APLC_ABS:
  case APLC_CEIL:
  case APLC_FACT:
  case APLC_FLOOR:
  case APLC_MINUS:
  case APLC_PLUS:
  case APLC_TIMES:
    return (maxtype);

  case APLC_CIRCLE:
  case APLC_DIVIDE:
  case APLC_EXP:
  case APLC_LOG:
    return max(APLC_REAL, maxtype);

  default:
    fprintf(aplcerr, "operator %d\n", op);
    aplc_error("unimplemented operator in aplc_dsfunt used");
    return (APLC_UKTYPE); /* lint stuffing */
  }
}

/* aplc_msfunt - return the type of a monadic scalar function */
int
aplc_msfunt(enum sfuns op, int type)
{
  switch (op) {
  case APLC_ABS:
    /* type of z or q is r */ 
    return min(APLC_REAL, type);
    break;

  case APLC_FACT:
  case APLC_MINUS:
  case APLC_NOT:
  case APLC_PLUS:
    return (type);
    break;

  case APLC_CEIL:
  case APLC_FLOOR:
  case APLC_TIMES:
    /*return (APLC_INT);*/
    switch(type) {
    default:
      /*break;*/
    case APLC_BOOL:
    case APLC_INT:
    case APLC_REAL:
      return APLC_INT;
      break;
    case APLC_COMPLEX:
      return APLC_COMPLEX;
      break;
    case APLC_QUAT:
      return APLC_QUAT;
      break;
    case APLC_OCT:
      return APLC_OCT;
      break;
    }
    break;

  case APLC_DIVIDE:
  case APLC_EXP:
  case APLC_LOG:
  case APLC_CIRCLE:
    /*return (APLC_REAL);*/
    return max(APLC_REAL, type);
    break;

  default:
    fprintf(aplcerr, "operator %d\n", (int) op);
    aplc_error("unimplemented operator in aplc_msfunt used");
    return (APLC_UKTYPE); 
    break;
  }
}


/* aplc_dsfuns - compute rank and shape of dyadic scalar function 
           shape is put into mp_struct
           rank is the return value
*/
int
aplc_dsfuns(union mp_struct * shape, int leftrank, int *leftshape,
    int rightrank, int *rightshape)
{
  int i;

  /* for debugging  
  fprintf(aplcerr, "\n[aplc_dsfuns] leftrank %d, rightrank %d\n",
	  leftrank, rightrank);
  i=0;
  fprintf(aplcerr,
	  "  i = %d, leftshape[i] = %d, rightshape[i] = %d\n",
	  i, leftshape[i], rightshape[i]); */

  /* check for left scalar */
  if (isscalar(leftrank, leftshape)) {
    /* check for both scalars */
    if (isscalar(rightrank, rightshape)) {
      /* result is scalar, make shape static */
      /* aplc_vectalloc(shape, 1, APLC_INT); shape->ip[0] = 1;*/
      shape->ip = aplc_ivone;
      return (0);
    } else {
      /* right isn't scalar; result is rank, shape of right */
      aplc_vectalloc(shape, rightrank, APLC_INT);
      aplc_cpvec(shape->ip, rightrank, rightshape);
      return (rightrank);
    }
  }
  /* check for left singleton, if so must be rank 1 */
  if (issingleton(leftrank, leftshape)) {
    /* check for both scalars */
    if (isscalar(rightrank, rightshape)) {
      /* result is rank, shape of left - singleton */
      aplc_vectalloc(shape, leftrank, APLC_INT);
      aplc_cpvec(shape->ip, leftrank, leftshape);
      return (leftrank);
    } else {
      /* result is rank, shape of right */
      aplc_vectalloc(shape, rightrank, APLC_INT);
      aplc_cpvec(shape->ip, rightrank, rightshape);
      return (rightrank);
    }
  }
  /* left is not a singleton */
  /* check for right singleton */
  if (issingleton(rightrank, rightshape)) {
    aplc_vectalloc(shape, leftrank, APLC_INT);
    aplc_cpvec(shape->ip, leftrank, leftshape);
    return (leftrank);
  }
  if (leftrank != rightrank) {
    fprintf(aplcerr, "\n leftrank %d, rightrank %d\n",
	leftrank, rightrank);
    aplc_error("[aplc_dsfuns] dyadic scalar rank comformability error");
  }
  for (i = 0; i < rightrank; i++)
    if (leftshape[i] != rightshape[i]) {
      fprintf(aplcerr,
	  "\n[aplc_dsfuns] i = %d, leftshape[i] = %d, rightshape[i] = %d\n",
	  i, leftshape[i], rightshape[i]);
      aplc_error("[aplc_dsfuns] dyadic scalar shape conformability error");
    }
  aplc_vectalloc(shape, rightrank, APLC_INT);
  aplc_cpvec(shape->ip, rightrank, rightshape);
  return (rightrank);
}

/* aplc_outershape - compute rank and shape of outer product */
int
aplc_outershape(union mp_struct * shape, int leftrank, int *leftshape,
		int rightrank, int *rightshape)
{
  int rank;

  rank = leftrank + rightrank;
  if (0 == rank) {
    /* must be both scalars */
    shape->ip = aplc_ivone;
    return(rank);
  }
  aplc_vectalloc(shape, rank, APLC_INT);
  aplc_cpvec(shape->ip, leftrank, leftshape);
  aplc_cpvec(shape->ip + leftrank, rightrank, rightshape);
  return (rank);
}

/* aplc_innershape- compute rank and shape of inner product */
int
aplc_innershape(union mp_struct * shape, int leftrank, int *leftshape,
		int rightrank, int *rightshape)
{
  int rank, start;

  rank = 0;
  if (leftrank > 0)
    rank += leftrank - 1;
  if (rightrank > 0)
    rank += rightrank - 1;
  if (0 == rank) {
    /* must be both scalars */
    shape->ip = aplc_ivone;
    return(rank);
  }
  aplc_vectalloc(shape, rank, APLC_INT);
  if (leftrank > 0) {
    start = leftrank - 1;
    aplc_cpvec(shape->ip, start, leftshape);
  } else
    start = 0;
  if (rightrank > 0)
    aplc_cpvec(shape->ip + start, rightrank - 1, rightshape + 1);
  return (rank);
}

/* sws 
   print an integer vector with a name, for debugging
   later move this to runio?  */
extern void
aplc_fprintf_ivec(FILE *p, char *s, int *v, int n)
{
  int k;

  fprintf(p,"%s = {", s);
  for (k=0; k<n; k++)
    fprintf(p," %d", v[k]);
  fprintf(p,"}\n");
  return;
}

/* aplc_catshape - compute shape for catenate
                   return result shape, rank, e, sl, sr

  taxis is the type of axis (real for laminate)
*/
int
aplc_catshape(union mp_struct * shape, 
	      int leftrank, int *leftshape,
	      int rightrank, int *rightshape, 
	      int axis, int axisind, int taxis, 
	      int *e, int *sl, int *sr)
{
  int i, j, maxrank;
  int rank = 0;  /* initialize, for lint */

#if SDEBUG
  /* sws test */
  printf("\n [aplc_catshape] axis %d, taxis %d, lrank %d, rrank %d\n",
	 axis,taxis, leftrank,rightrank); 
  aplc_fprintf_ivec(aplcerr," leftshape",leftshape,leftrank); 
  aplc_fprintf_ivec(aplcerr," rightshape",rightshape,rightrank); 
#endif
  /* check for lastaxis */
  if (axisind == 2) {
    maxrank = (leftrank > rightrank) ? leftrank : rightrank;
    if (maxrank == 0)
      axis = 0;
    else
      axis = maxrank - 1;
  }  else if (taxis != APLC_INT) {
    /* laminate; we will change the local copies of argument rank/shape */
    /* need to change rank */
    if (leftrank == 0) {
      rightshape = aplc_lamshape(axis, leftrank, leftshape, rightrank, rightshape);
      rightrank++;
    } else {
      leftshape = aplc_lamshape(axis, leftrank, leftshape, rightrank, rightshape);
      leftrank++;
    }
    maxrank = (leftrank > rightrank) ? leftrank : rightrank;
  } else {
    /* default case */
    maxrank = (leftrank > rightrank) ? leftrank : rightrank;
  }
#if SDEBUG >2
  printf("\n aplc_catshape, axis %d, taxis %d, lrank %d, rrank %d\n",
	 axis,taxis, leftrank,rightrank); 
  printf("axis %d\n",axis); printf("left rank %d, ",leftrank); 
  aplc_fprintf_ivec(aplcerr," leftshape",leftshape,leftrank); 
  aplc_fprintf_ivec(aplcerr," rightshape",rightshape,rightrank); 
#endif

  if ((axis < 0) | ((maxrank != 0) & (axis > (maxrank - 1)))) {
    fprintf(aplcerr,"\naxis %d, maxrank %d\n", axis, maxrank);
    aplc_error("[catenate] axis error");
  } else if (leftrank == 0) {
    /* scalar left */
    *sl = 1;
    if (rightrank == 0) {
      rank = 1;
      aplc_vectalloc(shape, 1, APLC_INT);
      *(shape->ip) = 2;
      *sr = 1;
      *e = 1;
    } else {
      rank = rightrank;
      aplc_vectalloc(shape, rightrank, APLC_INT);
      aplc_cpvec(shape->ip, rank, rightshape);
      shape->ip[axis]++;
      *sr = rightshape[axis];
      *e = 1;
      for (i = rank - 1; i > axis; i--) {
	*e = *e * rightshape[i];
      }

    }
  } else if (rightrank == 0) {
    /* scalar right, not scalar left */
    rank = leftrank;
    aplc_vectalloc(shape, rank, APLC_INT);
    aplc_cpvec(shape->ip, rank, leftshape);
    shape->ip[axis]++;
    *sr = 1;
    *sl = leftshape[axis];
    *e = 1;
    for (i = rank - 1; i > axis; i--) {
      *e = *e * leftshape[i];
    }
  } else if (leftrank == rightrank) {
#if SDEBUG >1
    printf("  equal ranks %d\n",leftrank);
#endif
    rank = leftrank;
    aplc_vectalloc(shape, rank, APLC_INT);
    aplc_cpvec(shape->ip, rank, leftshape);

#if SDEBUG >1
    printf("sl %d\n",*leftshape);
    printf("sl[axis] %d\n",leftshape[axis]);
#endif
    *sl = leftshape[axis];
    *sr = rightshape[axis];
    *e = 1;
    for (i = rank - 1; i >= 0; i--) {
#if SDEBUG >1
      printf("i %d, e %d\n",i, *e );
#endif
      if (i > axis)
	*e = (*e) * rightshape[i];
      if (axis == i)
	shape->ip[i] += rightshape[axis];
      else if (leftshape[i] != rightshape[i]) {
	fprintf(aplcerr,"[catenate] length error(1): rank=%d, axis= %d; ", 
		rank, i+aplc_ixorg);
	fprintf(aplcerr,"leftshape=%d, rightshape=%d\n",
		leftshape[i], rightshape[i]);
	aplc_error("[catenate] length error");
      }
    }
  } else if (leftrank == (rightrank - 1)) {
    *sl = 1;
    *sr = rightshape[axis];
    rank = rightrank;
    aplc_vectalloc(shape, rank, APLC_INT);
    aplc_cpvec(shape->ip, rank, rightshape);
    *e = 1;
    j = leftrank - 1;
    for (i = rightrank - 1; i >= 0; i--) {
      if (i > axis)
	*e = (*e) * rightshape[i];
      if (axis == i)
	shape->ip[i] += 1;
      else {
	if (leftshape[j] != rightshape[i]) {
	  fprintf(aplcerr,
		  "[catenate] length error(2): ranks=(%d, %d), axis=%d; ",
		  leftrank,rightrank, i+aplc_ixorg);
	  fprintf(aplcerr,"leftshape[%d]=%d, rightshape[%d]=%d\n",
	      j+aplc_ixorg,leftshape[j], i+aplc_ixorg,rightshape[i]);
	  aplc_fprintf_ivec(aplcerr,"  leftshape",leftshape,leftrank); 
	  aplc_fprintf_ivec(aplcerr,"  rightshape",rightshape,rightrank); 
	  aplc_error("[catenate] length error");
	}
	j--;
      }
    }
  } else if ((leftrank - 1) == rightrank) {
    *sr = 1;
    *sl = leftshape[axis];
    rank = leftrank;
    aplc_vectalloc(shape, rank, APLC_INT);
    aplc_cpvec(shape->ip, rank, leftshape);
    *e = 1;
    j = rightrank - 1;
    for (i = leftrank - 1; i >= 0; i--) {
      if (i > axis)
	*e = (*e) * leftshape[i];
      if (axis == i)
	shape->ip[axis] += 1;
      else {
	if (leftshape[i] != rightshape[j]) {
	  fprintf(aplcerr, "[catenate] length error(3): ranks=(%d, %d), axis=%d; ",
		  leftrank,rightrank, i+aplc_ixorg);
	  fprintf(aplcerr,"leftshape[%d]=%d, rightshape[%d]=%d\n",
	      i+aplc_ixorg,leftshape[i], j+aplc_ixorg,rightshape[j]);
	  aplc_error("[catenate] length error");
	}
	j--;
      }
    }
  }  else   /* else consider laminate */
    aplc_error("[catenate] rank error");

  /* now check for laminate again - if so we need to free the new
     shape built in lamshape/addaxis */
  if (taxis != APLC_INT) {
    if (leftrank == 0) 
      aplc_free(rightshape);
    else
      aplc_free(leftshape);
  }
  return (rank);
}

/* aplc_dtshape - compute shape of dyadic transpose */
int
aplc_dtshape(union mp_struct * shape, int *lvalues, int rrank, int *rshape)
{
  int rank, i, j, s;

  rank = 0;
  for (i = 0; i < rrank; i++)
    if (lvalues[i] > rank)
      rank = lvalues[i];
  if (0 == rank) {
    /* must be scalar */
    shape->ip = aplc_ivone;
    return(rank);
  }
  aplc_vectalloc(shape, rank, APLC_INT);
  for (i = 1; i <= rank; i++) {
    s = 9999;
    for (j = 0; j < rrank; j++)
      if (lvalues[j] == i)
	if (rshape[j] < s)
	  s = rshape[j];
    shape->ip[i - 1] = s;
  }
  return (rank);
}

/* sws
   check axis value at runtime to see if we need laminate

   inputs: type, res
     type is the axis type
     res is the axis value
   outputs: (type), axis
     the value axis is the ceiling of the actual value
     the type may change (to int)
*/
void
aplc_lamcheck(int *type, union res_struct *res, int *axis)
{
  switch (*type) {
  default:
    aplc_error("[aplc_lamcheck] unknown axis type");
    break;
  case APLC_INT:
    *axis = res->i;
    break;
  case APLC_REAL:
    if (aplc_isnearint(res->r, axis)) {
      *type = APLC_INT;/* change the type */
    } else {
      *type = APLC_REAL;/* no change */
      *axis = (int) ceil(res->r);
    }
    break;
  }
  return;
}

/* sws

   lamshape - compute shape changes for laminate, 
   called in catshape

   derive final rank. note we will have to change the ranks in
   catshape as well to check for axis errors. can't do it here as we
   may have values in ranks
*/
int *
aplc_lamshape(int axis, 
	      int leftrank, int *leftshape, 
	      int rightrank, int *rightshape)
{
  int rank = 0;  /* initialize, for lint */

  if (leftrank == 0)
    rank = rightrank + 1;
  else if (rightrank == 0)
    rank = leftrank + 1;
  else {
    if (leftrank != rightrank) {
      fprintf(aplcerr,
 "[aplc_lamshape] rank error, leftrank = %d, rightrank = %d\n", 
	      leftrank, rightrank);
      aplc_error("[aplc_lamshape] rank error");
    } else
      rank = leftrank + 1;
  }
  if ((axis < 0) || (axis > rank))
    aplc_error("axis error");

  /* now modify shapes */
  if (leftrank == 0) {
    rightshape = addaxis(rightshape, rank, axis);
    return (rightshape);
  } else {
    leftshape = addaxis(leftshape, rank, axis);
    /* printf("...left rank %d, shape ",rank); for (i=0; i < rank; i++) {
       printf("%d ",leftshape[i]); } printf("\n"); */

    return (leftshape);
  }
}

/* for sub assignment
   check if right matches left
   - ignore singleton axes */
extern int
aplc_suba_check(int leftrank, int *leftshape, 
		int rightrank, int *rightshape)
{
  int ls, rs; 
  int i,j,k, n;
  int ok;

  /* scalar right is ok */
  if (0 == rightrank) {
    return 1;
  }
  ls = aplc_vsize(leftrank, leftshape);
  rs = aplc_vsize(rightrank, rightshape);
  if (ls != rs) {
    fprintf(aplcerr,"[aplc_suba_check] ls %d != rs %d\n", ls,rs); 
    return 0;
  }
  /* singleton then is ok */
  if (1 == ls)
    return 1;
  n = max(leftrank, rightrank);
  j = 0;
  ok = 1;
  for (i=0; i<leftrank; i++){
    if (ok && (leftshape[i] != 1)) {
      k = findaxis(leftshape[i], j, rightrank, rightshape);
      if (k<0) {
	aplc_fprintf_ivec(aplcerr, "lshape", leftshape, leftrank);
	aplc_fprintf_ivec(aplcerr, "rshape", rightshape, rightrank);
	fprintf(aplcerr,"[aplc_suba_check] lshape[%d] %d != rs\n", 
		i, leftshape[i]); 
	ok = 0;
      } else {
	/* fprintf(aplcerr, "[%d] %d %d\n", i,j,k);*/
	j = k+1;
      }
    }
  } 
  return ok;
}

/* given a vector shape
   find the first axis >= start that matches k
   else return -1 */
static int
findaxis(int k, int start, int rank, int *shape )
{
  int i;
  int ret = -1;

  i = start;
  while ( (i<rank) && (ret < 0) ) {
    if (k == shape[i])
      ret = i;
    i++;
  }
  return ret;
}

/* sws
   compute a new shape vector,
   with an extra axis (shape 1) and new rank given
*/
static int *
addaxis(int *shape, int rank, int k)
{
  int *newshape;
  int i, j;
  union mp_struct mptmp;

  aplc_vectalloc(&mptmp, rank, APLC_INT);
  newshape = mptmp.ip;
  for (i = 0, j = 0; i < rank; i++) {
    if (i != k)
      newshape[i] = shape[j++];
    else
      newshape[i] = 1;
  }
  /* need to free this?  
     - no, this is just a local copy of an outside mp 
     - we will need to free newshape internal to catshape though
     */
  /*  aplc_free(shape);*/

  /*
  printf("...... rank %d, shape ",rank); 
  for (i=0; i < rank; i++) {
    printf("%d ",newshape[i]); 
  } printf("\n"); */

  return (newshape);
}

/* sws
   get size given rank, shape pointer */
extern int
aplc_getsize(int rank, int *shape)
{
  int s = 1;

  /*fprintf(stderr,"[aplc_getsize] r %d s[0] %d\n", rank, shape[0]);*/
  if (rank <1) {
    /*fprintf(stderr,"- s1\n");*/
    return s;
  }
  for (; rank >0; )
    s *= shape[--rank];
  /*fprintf(stderr,"- s %d\n", s);*/
  return s;
}


/* end of runshape.c */
