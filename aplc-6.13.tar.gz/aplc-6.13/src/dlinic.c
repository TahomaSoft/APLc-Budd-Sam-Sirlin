/* dlini.f -- translated by f2c (version of 30 January 1990  16:02:04).
   You must link the resulting object file with the libraries:
	-lF77 -lI77 -lm -lc   (in that order)
*/

#include "f2c.h"

/* Table of constant values */

static integer c__1 = 1;

/* subset of linpack for solving linear equations, getting inverse */
/*dasum daxpy ddot dscal dgeco dgedi dgefa dgesl dscal dswap idamax isamax*/
doublereal dasum_(n, dx, incx)
integer *n;
doublereal *dx;
integer *incx;
{
    /* System generated locals */
    integer i_1, i_2;
    doublereal ret_val, d_1, d_2, d_3, d_4, d_5, d_6;

    /* Local variables */
    static integer i, m, ns, mp1;

    /* Parameter adjustments */
    --dx;

    /* Function Body */

/*     RETURNS SUM OF MAGNITUDES OF DOUBLE PRECISION DX. */
/*     DASUM = SUM FROM 0 TO N-1 OF DABS(DX(1+I*INCX)) */

    ret_val = 0.;
    if (*n <= 0) {
	return ret_val;
    }
    if (*incx == 1) {
	goto L20;
    }

/*        CODE FOR INCREMENTS NOT EQUAL TO 1. */

    ns = *n * *incx;
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) {
	ret_val += (d_1 = dx[i], abs(d_1));
/* L10: */
    }
    return ret_val;

/*        CODE FOR INCREMENTS EQUAL TO 1. */


/*        CLEAN-UP LOOP SO REMAINING VECTOR LENGTH IS A MULTIPLE OF 6. */

L20:
    m = *n % 6;
    if (m == 0) {
	goto L40;
    }
    i_2 = m;
    for (i = 1; i <= i_2; ++i) {
	ret_val += (d_1 = dx[i], abs(d_1));
/* L30: */
    }
    if (*n < 6) {
	return ret_val;
    }
L40:
    mp1 = m + 1;
    i_2 = *n;
    for (i = mp1; i <= i_2; i += 6) {
	ret_val = ret_val + (d_1 = dx[i], abs(d_1)) + (d_2 = dx[i + 1], abs(
		d_2)) + (d_3 = dx[i + 2], abs(d_3)) + (d_4 = dx[i + 3], abs(
		d_4)) + (d_5 = dx[i + 4], abs(d_5)) + (d_6 = dx[i + 5], abs(
		d_6));
/* L50: */
    }
    return ret_val;
} /* dasum_ */

/* Subroutine */ int daxpy_(n, da, dx, incx, dy, incy)
integer *n;
doublereal *da, *dx;
integer *incx;
doublereal *dy;
integer *incy;
{
    /* System generated locals */
    integer i_1, i_2;

    /* Local variables */
    static integer i, m, ix, iy, ns, mp1;

    /* Parameter adjustments */
    --dx;
    --dy;

    /* Function Body */

/*     OVERWRITE DOUBLE PRECISION DY WITH DOUBLE PRECISION DA*DX + DY. */
/*     FOR I = 0 TO N-1, REPLACE  DY(LY+I*INCY) WITH DA*DX(LX+I*INCX) + */

/*       DY(LY+I*INCY), WHERE LX = 1 IF INCX .GE. 0, ELSE LX = (-INCX)*N, 
*/
/*       AND LY IS DEFINED IN A SIMILAR WAY USING INCY. */

    if (*n <= 0 || *da == 0.) {
	return 0;
    }
    if (*incx == *incy) {
	if ((i_1 = *incx - 1) < 0) {
	    goto L5;
	} else if (i_1 == 0) {
	    goto L20;
	} else {
	    goto L60;
	}
    }
L5:

/*        CODE FOR NONEQUAL OR NONPOSITIVE INCREMENTS. */

    ix = 1;
    iy = 1;
    if (*incx < 0) {
	ix = (-(*n) + 1) * *incx + 1;
    }
    if (*incy < 0) {
	iy = (-(*n) + 1) * *incy + 1;
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
	dy[iy] += *da * dx[ix];
	ix += *incx;
	iy += *incy;
/* L10: */
    }
    return 0;

/*        CODE FOR BOTH INCREMENTS EQUAL TO 1 */


/*        CLEAN-UP LOOP SO REMAINING VECTOR LENGTH IS A MULTIPLE OF 4. */

L20:
    m = *n % 4;
    if (m == 0) {
	goto L40;
    }
    i_1 = m;
    for (i = 1; i <= i_1; ++i) {
	dy[i] += *da * dx[i];
/* L30: */
    }
    if (*n < 4) {
	return 0;
    }
L40:
    mp1 = m + 1;
    i_1 = *n;
    for (i = mp1; i <= i_1; i += 4) {
	dy[i] += *da * dx[i];
	dy[i + 1] += *da * dx[i + 1];
	dy[i + 2] += *da * dx[i + 2];
	dy[i + 3] += *da * dx[i + 3];
/* L50: */
    }
    return 0;

/*        CODE FOR EQUAL, POSITIVE, NONUNIT INCREMENTS. */

L60:
    ns = *n * *incx;
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) {
	dy[i] = *da * dx[i] + dy[i];
/* L70: */
    }
    return 0;
} /* daxpy_ */

doublereal ddot_(n, dx, incx, dy, incy)
integer *n;
doublereal *dx;
integer *incx;
doublereal *dy;
integer *incy;
{
    /* System generated locals */
    integer i_1, i_2;
    doublereal ret_val;

    /* Local variables */
    static integer i, m, ix, iy, ns, mp1;

    /* Parameter adjustments */
    --dx;
    --dy;

    /* Function Body */

/*     RETURNS THE DOT PRODUCT OF DOUBLE PRECISION DX AND DY. */
/*     DDOT = SUM FOR I = 0 TO N-1 OF  DX(LX+I*INCX) * DY(LY+I*INCY) */
/*     WHERE LX = 1 IF INCX .GE. 0, ELSE LX = (-INCX)*N, AND LY IS */
/*     DEFINED IN A SIMILAR WAY USING INCY. */

    ret_val = 0.;
    if (*n <= 0) {
	return ret_val;
    }
    if (*incx == *incy) {
	if ((i_1 = *incx - 1) < 0) {
	    goto L5;
	} else if (i_1 == 0) {
	    goto L20;
	} else {
	    goto L60;
	}
    }
L5:

/*         CODE FOR UNEQUAL OR NONPOSITIVE INCREMENTS. */

    ix = 1;
    iy = 1;
    if (*incx < 0) {
	ix = (-(*n) + 1) * *incx + 1;
    }
    if (*incy < 0) {
	iy = (-(*n) + 1) * *incy + 1;
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
	ret_val += dx[ix] * dy[iy];
	ix += *incx;
	iy += *incy;
/* L10: */
    }
    return ret_val;

/*        CODE FOR BOTH INCREMENTS EQUAL TO 1. */


/*        CLEAN-UP LOOP SO REMAINING VECTOR LENGTH IS A MULTIPLE OF 5. */

L20:
    m = *n % 5;
    if (m == 0) {
	goto L40;
    }
    i_1 = m;
    for (i = 1; i <= i_1; ++i) {
	ret_val += dx[i] * dy[i];
/* L30: */
    }
    if (*n < 5) {
	return ret_val;
    }
L40:
    mp1 = m + 1;
    i_1 = *n;
    for (i = mp1; i <= i_1; i += 5) {
	ret_val = ret_val + dx[i] * dy[i] + dx[i + 1] * dy[i + 1] + dx[i + 2] 
		* dy[i + 2] + dx[i + 3] * dy[i + 3] + dx[i + 4] * dy[i + 4];
/* L50: */
    }
    return ret_val;

/*         CODE FOR POSITIVE EQUAL INCREMENTS .NE.1. */

L60:
    ns = *n * *incx;
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) {
	ret_val += dx[i] * dy[i];
/* L70: */
    }
    return ret_val;
} /* ddot_ */

/* Subroutine */ int dgeco_(a, lda, n, ipvt, rcond, z)
doublereal *a;
integer *lda, *n, *ipvt;
doublereal *rcond, *z;
{
    /* System generated locals */
    integer a_dim1, a_offset, i_1, i_2;
    doublereal d_1, d_2;

    /* Builtin functions */
    double d_sign();

    /* Local variables */
    extern doublereal ddot_();
    static integer info;
    extern /* Subroutine */ int dgefa_();
    static integer j, k, l;
    static doublereal s, t;
    extern /* Subroutine */ int dscal_();
    extern doublereal dasum_();
    static doublereal anorm;
    extern /* Subroutine */ int daxpy_();
    static doublereal ynorm;
    static integer kb;
    static doublereal ek, sm, wk;
    static integer kp1;
    static doublereal wkm;

    /* Parameter adjustments */
    a_dim1 = *lda;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    --ipvt;
    --z;

    /* Function Body */
/*                                                                      
00000050*/
/*    DGECO FACTORS A DOUBLE PRECISION MATRIX BY GAUSSIAN ELIMINATION   
00000060*/
/*    AND ESTIMATES THE CONDITION OF THE MATRIX.                        
00000070*/
/*                                                                      
00000080*/
/*    IF  RCOND  IS NOT NEEDED, DGEFA IS SLIGHTLY FASTER.               
00000090*/
/*    TO SOLVE  A*X = B , FOLLOW DGECO BY DGESL.                        
00000100*/
/*    TO COMPUTE  INVERSE(A)*C , FOLLOW DGECO BY DGESL.                 
00000110*/
/*    TO COMPUTE  DETERMINANT(A) , FOLLOW DGECO BY DGEDI.               
00000120*/
/*    TO COMPUTE  INVERSE(A) , FOLLOW DGECO BY DGEDI.                   
00000130*/
/*                                                                      
00000140*/
/*    ON ENTRY                                                          
00000150*/
/*                                                                      
00000160*/
/*       A       DOUBLE PRECISION(LDA, N)                               
00000170*/
/*               THE MATRIX TO BE FACTORED.                             
00000180*/
/*                                                                      
00000190*/
/*       LDA     INTEGER                                                
00000200*/
/*               THE LEADING DIMENSION OF THE ARRAY  A .                
00000210*/
/*                                                                      
00000220*/
/*       N       INTEGER                                                
00000230*/
/*               THE ORDER OF THE MATRIX  A .                           
00000240*/
/*                                                                      
00000250*/
/*    ON RETURN                                                         
00000260*/
/*                                                                      
00000270*/
/*       A       AN UPPER TRIANGULAR MATRIX AND THE MULTIPLIERS         
00000280*/
/*               WHICH WERE USED TO OBTAIN IT.                          
00000290*/
/*               THE FACTORIZATION CAN BE WRITTEN  A = L*U  WHERE       
00000300*/
/*               L  IS A PRODUCT OF PERMUTATION AND UNIT LOWER          
00000310*/
/*               TRIANGULAR MATRICES AND  U  IS UPPER TRIANGULAR.       
00000320*/
/*                                                                      
00000330*/
/*       IPVT    INTEGER(N)                                             
00000340*/
/*               AN INTEGER VECTOR OF PIVOT INDICES.                    
00000350*/
/*                                                                      
00000360*/
/*       RCOND   DOUBLE PRECISION                                       
00000370*/
/*               AN ESTIMATE OF THE RECIPROCAL CONDITION OF  A .        
00000380*/
/*               FOR THE SYSTEM  A*X = B , RELATIVE PERTURBATIONS       
00000390*/
/*               IN  A  AND  B  OF SIZE  EPSILON  MAY CAUSE             
00000400*/
/*               RELATIVE PERTURBATIONS IN  X  OF SIZE  EPSILON/RCOND . 
00000410*/
/*               IF  RCOND  IS SO SMALL THAT THE LOGICAL EXPRESSION     
00000420*/
/*                          1.0 + RCOND .EQ. 1.0                        
00000430*/
/*               IS TRUE, THEN  A  MAY BE SINGULAR TO WORKING           
00000440*/
/*               PRECISION.  IN PARTICULAR,  RCOND  IS ZERO  IF         
00000450*/
/*               EXACT SINGULARITY IS DETECTED OR THE ESTIMATE          
00000460*/
/*               UNDERFLOWS.                                            
00000470*/
/*                                                                      
00000480*/
/*       Z       DOUBLE PRECISION(N)                                    
00000490*/
/*               A WORK VECTOR WHOSE CONTENTS ARE USUALLY UNIMPORTANT.  
00000500*/
/*               IF  A  IS CLOSE TO A SINGULAR MATRIX, THEN  Z  IS      
00000510*/
/*               AN APPROXIMATE NULL VECTOR IN THE SENSE THAT           
00000520*/
/*               NORM(A*Z) = RCOND*NORM(A)*NORM(Z) .                    
00000530*/
/*                                                                      
00000540*/
/*    LINPACK. THIS VERSION DATED 08/14/78 .                            
00000550*/
/*    CLEVE MOLER, UNIVERSITY OF NEW MEXICO, ARGONNE NATIONAL LAB.      
00000560*/
/*                                                                      
00000570*/
/*    SUBROUTINES AND FUNCTIONS                                         
00000580*/
/*                                                                      
00000590*/
/*    LINPACK DGEFA                                                     
00000600*/
/*    BLAS DAXPY,DDOT,DSCAL,DASUM                                       
00000610*/
/*    FORTRAN DABS,DMAX1,DSIGN                                          
00000620*/
/*                                                                      
00000630*/
/*    INTERNAL VARIABLES                                                
00000640*/
/*                                                                      
00000650*/
/*                                                                      
00000690*/
/*                                                                      
00000700*/
/*    COMPUTE 1-NORM OF A                                               
00000710*/
/*                                                                      
00000720*/
    anorm = 0.;
    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
/* Computing MAX */
	d_1 = anorm, d_2 = dasum_(n, &a[j * a_dim1 + 1], &c__1);
	anorm = max(d_2,d_1);
/* L10: */
    }
/*                                                                      
00000770*/
/*    FACTOR                                                            
00000780*/
/*                                                                      
00000790*/
    dgefa_(&a[a_offset], lda, n, &ipvt[1], &info);
/*                                                                      
00000810*/
/*    RCOND = 1/(NORM(A)*(ESTIMATE OF NORM(INVERSE(A)))) .              
00000820*/
/*    ESTIMATE = NORM(Z)/NORM(Y) WHERE  A*Z = Y  AND  TRANS(A)*Y = E .  
00000830*/
/*    TRANS(A)  IS THE TRANSPOSE OF A .  THE COMPONENTS OF  E  ARE      
00000840*/
/*    CHOSEN TO CAUSE MAXIMUM LOCAL GROWTH IN THE ELEMENTS OF W  WHERE  
00000850*/
/*    TRANS(U)*W = E .  THE VECTORS ARE FREQUENTLY RESCALED TO AVOID    
00000860*/
/*    OVERFLOW.                                                         
00000870*/
/*                                                                      
00000880*/
/*    SOLVE TRANS(U)*W = E                                              
00000890*/
/*                                                                      
00000900*/
    ek = 1.;
    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
	z[j] = 0.;
/* L20: */
    }
    i_1 = *n;
    for (k = 1; k <= i_1; ++k) {
	if (z[k] != 0.) {
	    d_1 = -z[k];
	    ek = d_sign(&ek, &d_1);
	}
	if ((d_1 = ek - z[k], abs(d_1)) <= (d_2 = a[k + k * a_dim1], abs(d_2))
		) {
	    goto L30;
	}
	s = (d_1 = a[k + k * a_dim1], abs(d_1)) / (d_2 = ek - z[k], abs(d_2));

	dscal_(n, &s, &z[1], &c__1);
	ek = s * ek;
L30:
	wk = ek - z[k];
	wkm = -ek - z[k];
	s = abs(wk);
	sm = abs(wkm);
	if (a[k + k * a_dim1] == 0.) {
	    goto L40;
	}
	wk /= a[k + k * a_dim1];
	wkm /= a[k + k * a_dim1];
	goto L50;
L40:
	wk = 1.;
	wkm = 1.;
L50:
	kp1 = k + 1;
	if (kp1 > *n) {
	    goto L90;
	}
	i_2 = *n;
	for (j = kp1; j <= i_2; ++j) {
	    sm += (d_1 = z[j] + wkm * a[k + j * a_dim1], abs(d_1));
	    z[j] += wk * a[k + j * a_dim1];
	    s += (d_1 = z[j], abs(d_1));
/* L60: */
	}
	if (s >= sm) {
	    goto L80;
	}
	t = wkm - wk;
	wk = wkm;
	i_2 = *n;
	for (j = kp1; j <= i_2; ++j) {
	    z[j] += t * a[k + j * a_dim1];
/* L70: */
	}
L80:
L90:
	z[k] = wk;
/* L100: */
    }
    s = 1. / dasum_(n, &z[1], &c__1);
    dscal_(n, &s, &z[1], &c__1);
/*                                                                      
00001330*/
/*    SOLVE TRANS(L)*Y = W                                              
00001340*/
/*                                                                      
00001350*/
    i_1 = *n;
    for (kb = 1; kb <= i_1; ++kb) {
	k = *n + 1 - kb;
	if (k < *n) {
	    i_2 = *n - k;
	    z[k] += ddot_(&i_2, &a[k + 1 + k * a_dim1], &c__1, &z[k + 1], &
		    c__1);
	}
	if ((d_1 = z[k], abs(d_1)) <= 1.) {
	    goto L110;
	}
	s = 1. / (d_1 = z[k], abs(d_1));
	dscal_(n, &s, &z[1], &c__1);
L110:
	l = ipvt[k];
	t = z[l];
	z[l] = z[k];
	z[k] = t;
/* L120: */
    }
    s = 1. / dasum_(n, &z[1], &c__1);
    dscal_(n, &s, &z[1], &c__1);
/*                                                                      
00001500*/
    ynorm = 1.;
/*                                                                      
00001520*/
/*    SOLVE L*V = Y                                                     
00001530*/
/*                                                                      
00001540*/
    i_1 = *n;
    for (k = 1; k <= i_1; ++k) {
	l = ipvt[k];
	t = z[l];
	z[l] = z[k];
	z[k] = t;
	if (k < *n) {
	    i_2 = *n - k;
	    daxpy_(&i_2, &t, &a[k + 1 + k * a_dim1], &c__1, &z[k + 1], &c__1);

	}
	if ((d_1 = z[k], abs(d_1)) <= 1.) {
	    goto L130;
	}
	s = 1. / (d_1 = z[k], abs(d_1));
	dscal_(n, &s, &z[1], &c__1);
	ynorm = s * ynorm;
L130:
/* L140: */
    ;}
    s = 1. / dasum_(n, &z[1], &c__1);
    dscal_(n, &s, &z[1], &c__1);
    ynorm = s * ynorm;
/*                                                                      
00001700*/
/*    SOLVE  U*Z = V                                                    
00001710*/
/*                                                                      
00001720*/
    i_1 = *n;
    for (kb = 1; kb <= i_1; ++kb) {
	k = *n + 1 - kb;
	if ((d_1 = z[k], abs(d_1)) <= (d_2 = a[k + k * a_dim1], abs(d_2))) {
	    goto L150;
	}
	s = (d_1 = a[k + k * a_dim1], abs(d_1)) / (d_2 = z[k], abs(d_2));
	dscal_(n, &s, &z[1], &c__1);
	ynorm = s * ynorm;
L150:
	if (a[k + k * a_dim1] != 0.) {
	    z[k] /= a[k + k * a_dim1];
	}
	if (a[k + k * a_dim1] == 0.) {
	    z[k] = 1.;
	}
	t = -z[k];
	i_2 = k - 1;
	daxpy_(&i_2, &t, &a[k * a_dim1 + 1], &c__1, &z[1], &c__1);
/* L160: */
    }
/*    MAKE ZNORM = 1.0                                                  
00001850*/
    s = 1. / dasum_(n, &z[1], &c__1);
    dscal_(n, &s, &z[1], &c__1);
    ynorm = s * ynorm;
/*                                                                      
00001890*/
    if (anorm != 0.) {
	*rcond = ynorm / anorm;
    }
    if (anorm == 0.) {
	*rcond = 0.;
    }
    return 0;
} /* dgeco_ */

/* Subroutine */ int dgedi_(a, lda, n, ipvt, det, work, job)
doublereal *a;
integer *lda, *n, *ipvt;
doublereal *det, *work;
integer *job;
{
    /* System generated locals */
    integer a_dim1, a_offset, i_1, i_2;

    /* Local variables */
    static integer i, j, k, l;
    static doublereal t;
    extern /* Subroutine */ int dscal_(), dswap_(), daxpy_();
    static integer kb, kp1, nm1;
    static doublereal ten;

    /* Parameter adjustments */
    a_dim1 = *lda;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    --ipvt;
    --det;
    --work;

    /* Function Body */
/*                                                                      
00000040*/
/*    BLAS DAXPY,DSCAL,DSWAP                                            
00000550*/
/*    FORTRAN DABS,MOD                                                  
00000560*/
/*                                                                      
00000570*/
/*    INTERNAL VARIABLES                                                
00000580*/
/*                                                                      
00000590*/
/*                                                                      
00000630*/
/*                                                                      
00000640*/
/*    COMPUTE DETERMINANT                                               
00000650*/
/*                                                                      
00000660*/
    if (*job / 10 == 0) {
	goto L70;
    }
    det[1] = 1.;
    det[2] = 0.;
    ten = 10.;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
	if (ipvt[i] != i) {
	    det[1] = -det[1];
	}
	det[1] = a[i + i * a_dim1] * det[1];
/*       ...EXIT                                                      
  00000740*/
	if (det[1] == 0.) {
	    goto L60;
	}
L10:
	if (abs(det[1]) >= 1.) {
	    goto L20;
	}
	det[1] = ten * det[1];
	det[2] += -1.;
	goto L10;
L20:
L30:
	if (abs(det[1]) < ten) {
	    goto L40;
	}
	det[1] /= ten;
	det[2] += 1.;
	goto L30;
L40:
/* L50: */
    ;}
L60:
L70:
/*                                                                      
00000890*/
/*    COMPUTE INVERSE(U)                                                
00000900*/
/*                                                                      
00000910*/
    if (*job % 10 == 0) {
	goto L150;
    }
    i_1 = *n;
    for (k = 1; k <= i_1; ++k) {
	a[k + k * a_dim1] = 1. / a[k + k * a_dim1];
	t = -a[k + k * a_dim1];
	i_2 = k - 1;
	dscal_(&i_2, &t, &a[k * a_dim1 + 1], &c__1);
	kp1 = k + 1;
	if (*n < kp1) {
	    goto L90;
	}
	i_2 = *n;
	for (j = kp1; j <= i_2; ++j) {
	    t = a[k + j * a_dim1];
	    a[k + j * a_dim1] = 0.;
	    daxpy_(&k, &t, &a[k * a_dim1 + 1], &c__1, &a[j * a_dim1 + 1], &
		    c__1);
/* L80: */
	}
L90:
/* L100: */
    ;}
/*                                                                      
00001060*/
/*       FORM INVERSE(U)*INVERSE(L)                                     
00001070*/
/*                                                                      
00001080*/
    nm1 = *n - 1;
    if (nm1 < 1) {
	goto L140;
    }
    i_1 = nm1;
    for (kb = 1; kb <= i_1; ++kb) {
	k = *n - kb;
	kp1 = k + 1;
	i_2 = *n;
	for (i = kp1; i <= i_2; ++i) {
	    work[i] = a[i + k * a_dim1];
	    a[i + k * a_dim1] = 0.;
/* L110: */
	}
	i_2 = *n;
	for (j = kp1; j <= i_2; ++j) {
	    t = work[j];
	    daxpy_(n, &t, &a[j * a_dim1 + 1], &c__1, &a[k * a_dim1 + 1], &
		    c__1);
/* L120: */
	}
	l = ipvt[k];
	if (l != k) {
	    dswap_(n, &a[k * a_dim1 + 1], &c__1, &a[l * a_dim1 + 1], &c__1);
	}
/* L130: */
    }
L140:
L150:
    return 0;
} /* dgedi_ */

/* Subroutine */ int dgefa_(a, lda, n, ipvt, info)
doublereal *a;
integer *lda, *n, *ipvt, *info;
{
    /* System generated locals */
    integer a_dim1, a_offset, i_1, i_2, i_3;

    /* Local variables */
    static integer j, k, l;
    static doublereal t;
    extern /* Subroutine */ int dscal_(), daxpy_();
    extern integer idamax_();
    static integer kp1, nm1;

    /* Parameter adjustments */
    a_dim1 = *lda;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    --ipvt;

    /* Function Body */
/*                                                                      
00000040*/
/*    DGEFA FACTORS A DOUBLE PRECISION MATRIX BY GAUSSIAN ELIMINATION.  
00000050*/
/*                                                                      
00000060*/
/*    DGEFA IS USUALLY CALLED BY DGECO, BUT IT CAN BE CALLED            
00000070*/
/*    DIRECTLY WITH A SAVING IN TIME IF  RCOND  IS NOT NEEDED.          
00000080*/
/*    (TIME FOR DGECO) = (1 + 9/N)*(TIME FOR DGEFA) .                   
00000090*/
/*                                                                      
00000100*/
/*    ON ENTRY                                                          
00000110*/
/*                                                                      
00000120*/
/*       A       DOUBLE PRECISION(LDA, N)                               
00000130*/
/*               THE MATRIX TO BE FACTORED.                             
00000140*/
/*                                                                      
00000150*/
/*       LDA     INTEGER                                                
00000160*/
/*               THE LEADING DIMENSION OF THE ARRAY  A .                
00000170*/
/*                                                                      
00000180*/
/*       N       INTEGER                                                
00000190*/
/*               THE ORDER OF THE MATRIX  A .                           
00000200*/
/*                                                                      
00000210*/
/*    ON RETURN                                                         
00000220*/
/*                                                                      
00000230*/
/*       A       AN UPPER TRIANGULAR MATRIX AND THE MULTIPLIERS         
00000240*/
/*               WHICH WERE USED TO OBTAIN IT.                          
00000250*/
/*               THE FACTORIZATION CAN BE WRITTEN  A = L*U  WHERE       
00000260*/
/*               L  IS A PRODUCT OF PERMUTATION AND UNIT LOWER          
00000270*/
/*               TRIANGULAR MATRICES AND  U  IS UPPER TRIANGULAR.       
00000280*/
/*                                                                      
00000290*/
/*       IPVT    INTEGER(N)                                             
00000300*/
/*               AN INTEGER VECTOR OF PIVOT INDICES.                    
00000310*/
/*                                                                      
00000320*/
/*       INFO    INTEGER                                                
00000330*/
/*               = 0  NORMAL VALUE.                                     
00000340*/
/*               = K  IF  U(K,K) .EQ. 0.0 .  THIS IS NOT AN ERROR       
00000350*/
/*                    CONDITION FOR THIS SUBROUTINE, BUT IT DOES        
00000360*/
/*                    INDICATE THAT DGESL OR DGEDI WILL DIVIDE BY ZERO  
00000370*/
/*                    IF CALLED.  USE  RCOND  IN DGECO FOR A RELIABLE   
00000380*/
/*                    INDICATION OF SINGULARITY.                        
00000390*/
/*                                                                      
00000400*/
/*    LINPACK. THIS VERSION DATED 08/14/78 .                            
00000410*/
/*    CLEVE MOLER, UNIVERSITY OF NEW MEXICO, ARGONNE NATIONAL LAB.      
00000420*/
/*                                                                      
00000430*/
/*    SUBROUTINES AND FUNCTIONS                                         
00000440*/
/*                                                                      
00000450*/
/*    BLAS DAXPY,DSCAL,IDAMAX                                           
00000460*/
/*                                                                      
00000470*/
/*    INTERNAL VARIABLES                                                
00000480*/
/*                                                                      
00000490*/
/*                                                                      
00000520*/
/*                                                                      
00000530*/
/*    GAUSSIAN ELIMINATION WITH PARTIAL PIVOTING                        
00000540*/
/*                                                                      
00000550*/
    *info = 0;
    nm1 = *n - 1;
    if (nm1 < 1) {
	goto L70;
    }
    i_1 = nm1;
    for (k = 1; k <= i_1; ++k) {
	kp1 = k + 1;
/*                                                                    
  00000610*/
/*       FIND L = PIVOT INDEX                                         
  00000620*/
/*                                                                    
  00000630*/
	i_2 = *n - k + 1;
	l = idamax_(&i_2, &a[k + k * a_dim1], &c__1) + k - 1;
	ipvt[k] = l;
/*                                                                    
  00000660*/
/*       ZERO PIVOT IMPLIES THIS COLUMN ALREADY TRIANGULARIZED        
  00000670*/
/*                                                                    
  00000680*/
	if (a[l + k * a_dim1] == 0.) {
	    goto L40;
	}
/*                                                                    
  00000700*/
/*          INTERCHANGE IF NECESSARY                                  
  00000710*/
/*                                                                    
  00000720*/
	if (l == k) {
	    goto L10;
	}
	t = a[l + k * a_dim1];
	a[l + k * a_dim1] = a[k + k * a_dim1];
	a[k + k * a_dim1] = t;
L10:
/*                                                                    
  00000780*/
/*          COMPUTE MULTIPLIERS                                       
  00000790*/
/*                                                                    
  00000800*/
	t = -1. / a[k + k * a_dim1];
	i_2 = *n - k;
	dscal_(&i_2, &t, &a[k + 1 + k * a_dim1], &c__1);
/*                                                                    
  00000830*/
/*          ROW ELIMINATION WITH COLUMN INDEXING                      
  00000840*/
/*                                                                    
  00000850*/
	i_2 = *n;
	for (j = kp1; j <= i_2; ++j) {
	    t = a[l + j * a_dim1];
	    if (l == k) {
		goto L20;
	    }
	    a[l + j * a_dim1] = a[k + j * a_dim1];
	    a[k + j * a_dim1] = t;
L20:
	    i_3 = *n - k;
	    daxpy_(&i_3, &t, &a[k + 1 + k * a_dim1], &c__1, &a[k + 1 + j * 
		    a_dim1], &c__1);
/* L30: */
	}
	goto L50;
L40:
	*info = k;
L50:
/* L60: */
    ;}
L70:
    ipvt[*n] = *n;
    if (a[*n + *n * a_dim1] == 0.) {
	*info = *n;
    }
    return 0;
} /* dgefa_ */

/* Subroutine */ int dgesl_(a, lda, n, ipvt, b, job)
doublereal *a;
integer *lda, *n, *ipvt;
doublereal *b;
integer *job;
{
    /* System generated locals */
    integer a_dim1, a_offset, i_1, i_2;

    /* Local variables */
    extern doublereal ddot_();
    static integer k, l;
    static doublereal t;
    extern /* Subroutine */ int daxpy_();
    static integer kb, nm1;

    /* Parameter adjustments */
    a_dim1 = *lda;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    --ipvt;
    --b;

    /* Function Body */
/*                                                                      
00000040*/
/*    DGESL SOLVES THE DOUBLE PRECISION SYSTEM                          
00000050*/
/*    A * X = B  OR  TRANS(A) * X = B                                   
00000060*/
/*    SUBROUTINES AND FUNCTIONS                                         
00000550*/
/*                                                                      
00000560*/
/*    BLAS DAXPY,DDOT                                                   
00000570*/
/*                                                                      
00000580*/
/*    INTERNAL VARIABLES                                                
00000590*/
/*                                                                      
00000600*/
/*                                                                      
00000630*/
    nm1 = *n - 1;
    if (*job != 0) {
	goto L50;
    }
/*                                                                      
00000660*/
/*       JOB = 0 , SOLVE  A * X = B                                     
00000670*/
/*       FIRST SOLVE  L*Y = B                                           
00000680*/
/*                                                                      
00000690*/
    if (nm1 < 1) {
	goto L30;
    }
    i_1 = nm1;
    for (k = 1; k <= i_1; ++k) {
	l = ipvt[k];
	t = b[l];
	if (l == k) {
	    goto L10;
	}
	b[l] = b[k];
	b[k] = t;
L10:
	i_2 = *n - k;
	daxpy_(&i_2, &t, &a[k + 1 + k * a_dim1], &c__1, &b[k + 1], &c__1);
/* L20: */
    }
L30:
/*                                                                      
00000810*/
/*       NOW SOLVE  U*X = Y                                             
00000820*/
/*                                                                      
00000830*/
    i_1 = *n;
    for (kb = 1; kb <= i_1; ++kb) {
	k = *n + 1 - kb;
	b[k] /= a[k + k * a_dim1];
	t = -b[k];
	i_2 = k - 1;
	daxpy_(&i_2, &t, &a[k * a_dim1 + 1], &c__1, &b[1], &c__1);
/* L40: */
    }
    goto L100;
L50:
/*                                                                      
00000920*/
/*       JOB = NONZERO, SOLVE  TRANS(A) * X = B                         
00000930*/
/*       FIRST SOLVE  TRANS(U)*Y = B                                    
00000940*/
/*                                                                      
00000950*/
    i_1 = *n;
    for (k = 1; k <= i_1; ++k) {
	i_2 = k - 1;
	t = ddot_(&i_2, &a[k * a_dim1 + 1], &c__1, &b[1], &c__1);
	b[k] = (b[k] - t) / a[k + k * a_dim1];
/* L60: */
    }
/*                                                                      
00001000*/
/*       NOW SOLVE TRANS(L)*X = Y                                       
00001010*/
/*                                                                      
00001020*/
    if (nm1 < 1) {
	goto L90;
    }
    i_1 = nm1;
    for (kb = 1; kb <= i_1; ++kb) {
	k = *n - kb;
	i_2 = *n - k;
	b[k] += ddot_(&i_2, &a[k + 1 + k * a_dim1], &c__1, &b[k + 1], &c__1);
	l = ipvt[k];
	if (l == k) {
	    goto L70;
	}
	t = b[l];
	b[l] = b[k];
	b[k] = t;
L70:
/* L80: */
    ;}
L90:
L100:
    return 0;
} /* dgesl_ */

/* Subroutine */ int dscal_(n, da, dx, incx)
integer *n;
doublereal *da, *dx;
integer *incx;
{
    /* System generated locals */
    integer i_1, i_2;

    /* Local variables */
    static integer i, m, ns, mp1;

    /* Parameter adjustments */
    --dx;

    /* Function Body */

/*     REPLACE DOUBLE PRECISION DX BY DOUBLE PRECISION DA*DX. */
/*     FOR I = 0 TO N-1, REPLACE DX(1+I*INCX) WITH  DA * DX(1+I*INCX) */

    if (*n <= 0) {
	return 0;
    }
    if (*incx == 1) {
	goto L20;
    }

/*        CODE FOR INCREMENTS NOT EQUAL TO 1. */

    ns = *n * *incx;
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) {
	dx[i] = *da * dx[i];
/* L10: */
    }
    return 0;

/*        CODE FOR INCREMENTS EQUAL TO 1. */


/*        CLEAN-UP LOOP SO REMAINING VECTOR LENGTH IS A MULTIPLE OF 5. */

L20:
    m = *n % 5;
    if (m == 0) {
	goto L40;
    }
    i_2 = m;
    for (i = 1; i <= i_2; ++i) {
	dx[i] = *da * dx[i];
/* L30: */
    }
    if (*n < 5) {
	return 0;
    }
L40:
    mp1 = m + 1;
    i_2 = *n;
    for (i = mp1; i <= i_2; i += 5) {
	dx[i] = *da * dx[i];
	dx[i + 1] = *da * dx[i + 1];
	dx[i + 2] = *da * dx[i + 2];
	dx[i + 3] = *da * dx[i + 3];
	dx[i + 4] = *da * dx[i + 4];
/* L50: */
    }
    return 0;
} /* dscal_ */

/* Subroutine */ int dswap_(n, dx, incx, dy, incy)
integer *n;
doublereal *dx;
integer *incx;
doublereal *dy;
integer *incy;
{
    /* System generated locals */
    integer i_1, i_2;

    /* Local variables */
    static integer i, m;
    static doublereal dtemp1, dtemp2, dtemp3;
    static integer ix, iy, ns, mp1;

    /* Parameter adjustments */
    --dx;
    --dy;

    /* Function Body */

/*     INTERCHANGE DOUBLE PRECISION DX AND DOUBLE PRECISION DY. */
/*     FOR I = 0 TO N-1, INTERCHANGE  DX(LX+I*INCX) AND DY(LY+I*INCY), */
/*     WHERE LX = 1 IF INCX .GE. 0, ELSE LX = (-INCX)*N, AND LY IS */
/*     DEFINED IN A SIMILAR WAY USING INCY. */

    if (*n <= 0) {
	return 0;
    }
    if (*incx == *incy) {
	if ((i_1 = *incx - 1) < 0) {
	    goto L5;
	} else if (i_1 == 0) {
	    goto L20;
	} else {
	    goto L60;
	}
    }
L5:

/*       CODE FOR UNEQUAL OR NONPOSITIVE INCREMENTS. */

    ix = 1;
    iy = 1;
    if (*incx < 0) {
	ix = (-(*n) + 1) * *incx + 1;
    }
    if (*incy < 0) {
	iy = (-(*n) + 1) * *incy + 1;
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
	dtemp1 = dx[ix];
	dx[ix] = dy[iy];
	dy[iy] = dtemp1;
	ix += *incx;
	iy += *incy;
/* L10: */
    }
    return 0;

/*       CODE FOR BOTH INCREMENTS EQUAL TO 1 */


/*       CLEAN-UP LOOP SO REMAINING VECTOR LENGTH IS A MULTIPLE OF 3. */

L20:
    m = *n % 3;
    if (m == 0) {
	goto L40;
    }
    i_1 = m;
    for (i = 1; i <= i_1; ++i) {
	dtemp1 = dx[i];
	dx[i] = dy[i];
	dy[i] = dtemp1;
/* L30: */
    }
    if (*n < 3) {
	return 0;
    }
L40:
    mp1 = m + 1;
    i_1 = *n;
    for (i = mp1; i <= i_1; i += 3) {
	dtemp1 = dx[i];
	dtemp2 = dx[i + 1];
	dtemp3 = dx[i + 2];
	dx[i] = dy[i];
	dx[i + 1] = dy[i + 1];
	dx[i + 2] = dy[i + 2];
	dy[i] = dtemp1;
	dy[i + 1] = dtemp2;
	dy[i + 2] = dtemp3;
/* L50: */
    }
    return 0;
L60:

/*     CODE FOR EQUAL, POSITIVE, NONUNIT INCREMENTS. */

    ns = *n * *incx;
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) {
	dtemp1 = dx[i];
	dx[i] = dy[i];
	dy[i] = dtemp1;
/* L70: */
    }
    return 0;
} /* dswap_ */

integer idamax_(n, dx, incx)
integer *n;
doublereal *dx;
integer *incx;
{
    /* System generated locals */
    integer ret_val, i_1, i_2;
    doublereal d_1;

    /* Local variables */
    static doublereal dmax_, xmag;
    static integer i, ii, ns;

    /* Parameter adjustments */
    --dx;

    /* Function Body */

/*     FIND SMALLEST INDEX OF MAXIMUM MAGNITUDE OF DOUBLE PRECISION DX. */

/*     IDAMAX =  FIRST I, I = 1 TO N, TO MINIMIZE  ABS(DX(1-INCX+I*INCX)) 
*/

    ret_val = 0;
    if (*n <= 0) {
	return ret_val;
    }
    ret_val = 1;
    if (*n <= 1) {
	return ret_val;
    }
    if (*incx == 1) {
	goto L20;
    }

/*        CODE FOR INCREMENTS NOT EQUAL TO 1. */

    dmax_ = abs(dx[1]);
    ns = *n * *incx;
    ii = 1;
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) {
	xmag = (d_1 = dx[i], abs(d_1));
	if (xmag <= dmax_) {
	    goto L5;
	}
	ret_val = ii;
	dmax_ = xmag;
L5:
	++ii;
/* L10: */
    }
    return ret_val;

/*        CODE FOR INCREMENTS EQUAL TO 1. */

L20:
    dmax_ = abs(dx[1]);
    i_2 = *n;
    for (i = 2; i <= i_2; ++i) {
	xmag = (d_1 = dx[i], abs(d_1));
	if (xmag <= dmax_) {
	    goto L30;
	}
	ret_val = i;
	dmax_ = xmag;
L30:
    ;}
    return ret_val;
} /* idamax_ */

integer isamax_(n, sx, incx)
integer *n;
real *sx;
integer *incx;
{
    /* System generated locals */
    integer ret_val, i_1, i_2;
    real r_1;

    /* Local variables */
    static real xmag, smax;
    static integer i, ii, ns;

    /* Parameter adjustments */
    --sx;

    /* Function Body */

/*     FIND SMALLEST INDEX OF MAXIMUM MAGNITUDE OF SINGLE PRECISION SX. */

/*     ISAMAX =  FIRST I, I = 1 TO N, TO MINIMIZE  ABS(SX(1-INCX+I*INCX)) 
*/

    ret_val = 0;
    if (*n <= 0) {
	return ret_val;
    }
    ret_val = 1;
    if (*n <= 1) {
	return ret_val;
    }
    if (*incx == 1) {
	goto L20;
    }

/*        CODE FOR INCREMENTS NOT EQUAL TO 1. */

    smax = dabs(sx[1]);
    ns = *n * *incx;
    ii = 1;
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) {
	xmag = (r_1 = sx[i], dabs(r_1));
	if (xmag <= smax) {
	    goto L5;
	}
	ret_val = ii;
	smax = xmag;
L5:
	++ii;
/* L10: */
    }
    return ret_val;

/*        CODE FOR INCREMENTS EQUAL TO 1. */

L20:
    smax = dabs(sx[1]);
    i_2 = *n;
    for (i = 2; i <= i_2; ++i) {
	xmag = (r_1 = sx[i], dabs(r_1));
	if (xmag <= smax) {
	    goto L30;
	}
	ret_val = i;
	smax = xmag;
L30:
    ;}
    return ret_val;
} /* isamax_ */

/* sws   added d_sign(a,b) */

double d_sign(a1,a2)
double *a1, *a2;
{
  if (*a2 < 0.0) 
    return(-dabs(*a1));
  else
    return(dabs(*a1));
}

/* end   */
