/*
	APL Compiler

	code tree manipulations
	tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever


 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/
#include "parse.h"
#include "gen.h"
#include <stdio.h>

/*
	define various strings used to print out code trees
*/

static char *ctstrs[] = {"type", "rank", "shape", "value"};

/* various print strings for types
   - these must correspond to the definitions in aplc.h */
/* sws  
old version without complex and quaternions
static char *tfstrs[] = {
    "uck", "i", "i", "r", "c", "uck", "l"};
static char *caststrs[] = {
    "UCK", "int", "int", "double", "char", "UCK"};
static char *tystrs[] = {
    "APLC_UKTYPE", "APLC_BOOL", "APLC_INT", "APLC_REAL", "APLC_CHAR", "APLC_ANY", "APLC_LABEL"};
*/

/* res_struct indices */
/* shared with frag.c */
static char *tfstrs[] = {
  "uck", 
  "i", "i", "i", "i", 
  "r", "z", "q", "o",
  "c", "trs", 
  "uny" };
/* types for casting */
static char *caststrs[] = {
  "UCK", 
  "int", "int", "UCK", "int", 
  "double", "double", "double", "double",
  "char",  "struct trs_struct", 
  "UNY"  };
static char *tystrs[] = {
  "APLC_UKTYPE", 
  "APLC_BIT", "APLC_BOOL", "APLC_LABEL", "APLC_INT", 
  "APLC_REAL", "APLC_COMPLEX", "APLC_QUAT", "APLC_OCT",
  "APLC_CHAR", "APLC_BOXED", 
  "APLC_ANY"  };

/* memory pointer extensions - these must correspond to the defines 
   in aplc.h, e.g. 
   "rp" = mpfields[APLC_REAL]
*/
/*  sws old version, without complex, quaternions
static char *mpfields[] = {
"unknown", "ip", "ip", "rp", "cp", "any", "label"};
*/
static char *mpfields[] = {
  "unknown", 
  "ip", "ip", "ip", "ip", 
  "rp", "zp", "qp", "op", 
  "cp", "trsp", 
  "any"  };

/* sws
   this must correspond to the enum sfuns in aplc.h 
   - removed extraneous stuff */
/*
static char *ddsfuns[] = {
  "",
  "", "", " + ", " - ", " * ", " % ", " / ", "", "", "", "",
" & ", " | ", " & ", " | ", " < ", " <= ", " == ", " != ", " >= ", " > "};
*/
/* must use bitwise logicals, as else right argument may not be 
   evaluated, and a right index might not increment */
static char *ddsfuns[] = {
  "",

  "", "", " + ", " - ", " * ", " % ", " / ", "", "", "", "",

  " & ", " | ", " & ", " | ", " < ", " <= ", " == ", " != ", " >= ", " > ",
" && ", " || "};

/* function declarations */
static void ctdsfun(enum sfuns, struct codetree *, struct codetree *);
static void ctmsfun(enum sfuns op, struct codetree *);


/* 
   mkrktype - make sure a result register is of a given known type,
   generating code to make it so if necessary 
*/
void
mkrktype(struct node * node, int ktype, int resval)
{
  int sreg, rt;

  rt = rtype(node);
  if ( (node->n.info & TYPEKNOWN) &&
       (ktype != APLC_COMPLEX) && (ktype != APLC_QUAT) && (ktype != APLC_OCT) &&
       (rt != APLC_COMPLEX) && (rt != APLC_QUAT) && (rt != APLC_OCT) ){
    if ((rt == APLC_BOOL) && (ktype == APLC_INT))
      return;
    if (rt != ktype) {
      node->c.values = gcast(castop, node->c.values, ktype);
    }
  } else {
    sreg = resinreg(node, resval);
    if ( !( (node->n.info & TYPEKNOWN) && (rt == ktype) ) ) {
      printf(" /* mkrktype type check */\n");
      printf("aplc_cktype(&res%d, %s, ", sreg, tystrs[ktype]);
      ctgen(node->c.type);
      rpseminl();
    }
    node->c.values = gicn(resptr, sreg, ktype);
  }
}

/*
	test trees for various properties
        generate various run time tests
*/

static struct codetree *lastttest = 0;
static struct codetree *lastrtest = 0;
static struct codetree *lastsvtest = 0;
static struct codetree *lastsingletest = 0;

void
testtype(struct codetree * tree, int type)
{
  if (cteq(tree, lastttest))
    return;
  lastttest = tree;
  iflp();
  if (type == APLC_INT) {
    /* sws -   allow APLC_BOOL as well */
    lp();
    ctgen(tree);
    printf(" != APLC_INT) && (");
    ctgen(tree);
    printf(" != APLC_BOOL) ) ");
  } else {
    ctgen(tree);
    printf(" != %s) ", tystrs[type]);
  }
  prerror("type error");
  return;
}

void
testrank(struct codetree * tree, int rank)
{
  if (cteq(tree, lastrtest))
    return;
  lastrtest = tree;
  iflp();
  ctgen(tree);
  printf(" != %d) ", rank);
  prerror("[testrank] rank error");
}

/* sws  rank test that passes ranks less than given */
void
testmxrank(struct codetree * tree, int rank)
{
  if (cteq(tree, lastsvtest))
    return;
  lastsvtest = tree;
  iflp();
  ctgen(tree);
  printf(" > %d) ", rank);
  prerror("[testmxrank] rank error");
}

/* sws  singleton test (scalar or length 1 vector) */
void
testsingle(struct codetree * rtree, struct codetree * stree)
{
  if (cteq(rtree, lastsingletest))
    return;
  lastsingletest = rtree;

  iflp();
  ctgen(rtree);
  printf(" == 1) {\n");
  iflp();
  ctgen(stree);
  printf("[0] != 1) ");
  prerror("[testsingle] rank error 1");
  rbr();
  printf("else ");
  iflp();
  ctgen(rtree);
  printf(" > 1) ");
  prerror("[testsingle] rank error 2");
}

/*
	cteq - test two trees for equality
*/

int
cteq(struct codetree * t1, struct codetree * t2)
{
  if ((!t1) || (!t2))
    return (0);

  if (t1->cop != t2->cop)
    return (0);

  switch (t1->cop) {
  default:
    break;

  case icnst:
  case coiptr:
  case resptr:
  case tcnst:
    if (t1->c0.cindex == t2->c0.cindex)
      return (1);
    break;

  case idptr:
    if (strcmp(t1->c0.cident, t2->c0.cident) == 0)
      return (1);
    break;

  case trsptr:
    if ((t1->c0.cindex == t2->c0.cindex) &&
	(t1->c1.ctfield == t2->c1.ctfield) &&
	(t1->c2.ctype == t2->c2.ctype))
      return (1);
    break;
  }
  return (0);
}

/* check for implemented ops */
int
ctdsfun_check(enum sfuns op, int type)
{
  switch(type) {
  case APLC_UNDEF:
  case APLC_UKTYPE:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
  case APLC_ANY:
  case APLC_BOXED:
    return 0;
    break;
  default:
    break;
  }
  switch (op) {
  default:
    break;

  case APLC_PLUS:
  case APLC_MINUS:
  case APLC_TIMES:
  case APLC_DIVIDE:
  case APLC_AND:
  case APLC_OR:
  case APLC_LT:
  case APLC_LE:
  case APLC_EQ:
  case APLC_NE:
  case APLC_GE:
  case APLC_GT:
  case APLC_ABS:
  case APLC_NAND:
  case APLC_NOR:
    return 1;
  }
  return 0;
}


/*
ctdsfun - generate code for a dyadic scalar op tree */
static void
ctdsfun(enum sfuns op, struct codetree * lefttree, 
       struct codetree * righttree)
{
  switch (op) {
    case APLC_PLUS:
    if ((righttree->cop == icnst) && (righttree->c0.cindex < 0)) {
      ctgen(lefttree);
      printf(" - %d", -righttree->c0.cindex);
      break;
    }
  case APLC_MINUS:
  case APLC_TIMES:
  case APLC_DIVIDE:
  case APLC_AND:
  case APLC_OR:
  case APLC_LT:
  case APLC_LE:
  case APLC_EQ:
  case APLC_NE:
  case APLC_GE:
  case APLC_GT:
  case APLC_L_AND:
  case APLC_L_OR:
    ctgen(lefttree);
    fputs(ddsfuns[(int) op], stdout);
    ctgen(righttree);
    break;

  case APLC_ABS:
    ctgen(righttree);
    fputs(ddsfuns[(int) op], stdout);
    ctgen(lefttree);
    break;

  case APLC_NAND:
  case APLC_NOR:
    fputs("!(", stdout);
    ctgen(lefttree);
    fputs(ddsfuns[(int) op], stdout);
    ctgen(righttree);
    rp();
    break;

  default:
    error("[ctdsfun] case not implemented");
    break;

  }
}

/*
ctmsfun - generate code for monadic scalar functions */

static char *dmsfuns[] = {
  "! ",
  "(int) floor(", "(int) ceil(", "", "- ", "", "", "(1.0 / ",
"exp(", "log(", "(PI * ", ""};

static void
ctmsfun(enum sfuns op, struct codetree * child)
{
  switch (op) {
    default:
    error("unimplemented ctmsfun");

  case APLC_NOT:
  case APLC_MINUS:
    fputs(dmsfuns[(int) op], stdout);
    ctgen(child);
    break;

  case APLC_FLOOR:
  case APLC_CEIL:
  case APLC_DIVIDE:
  case APLC_EXP:
  case APLC_LOG:
  case APLC_CIRCLE:
    fputs(dmsfuns[(int) op], stdout);
    ctgen(child);
    fputs(")", stdout);
    break;
  }
}

/*
ctgen - generate code for a code tree */

void
ctgen(struct codetree * tree)
{
  if (tree == NILTREE)
    error("[ctgen] tree error (NIL)");

  switch (tree->cop) {
  default:
    fprintf(stderr, "unknown field in ctgen = %d\n",
	tree->cop);
    break;

  case coasgn:
    lp();
    ctgen(tree->c0.cleft);
    printf(" = ");
    ctgen(tree->c1.cright);
    rp();
    break;

  case coconst:
    printf("&%s_%s[", tfstrs[tree->c2.ctype], funname);
    ctgen(tree->c0.cleft);
    printf("]");
    break;

  case castop:
    printf("((%s) ", caststrs[tree->c2.ctype]);
    ctgen(tree->c0.cleft);
    rp();
    break;

  case condop:
    lp();
    ctgen(tree->c0.cleft);
    printf("?");
    ctgen(tree->c2.cmiddle);
    printf(":");
    ctgen(tree->c1.cright);
    rp();
    break;

  case deref:
    if ((tree->c0.cleft)->cop == coref) {
      /* dref coref; undo both */
      /* tree = (tree->c0.cleft)->c0.cleft;*/
      tree = tree->c0.cleft;
    } else {
      if ((tree->c0.cleft)->cop == coconst) {
	tree = tree->c0.cleft;
	printf("%s_%s[", tfstrs[tree->c2.ctype], funname);
	ctgen(tree->c0.cleft);
	printf("]");
	break;
      }
      printf("*");
    }
    ctgen(tree->c0.cleft);
    break;

  case dsfun:
    lp();
    ctdsfun(tree->c2.csfun, tree->c0.cleft, tree->c1.cright);
    rp();
    break;

  case icnst:
    printf("%d", tree->c0.cindex);
    break;

  case idptr:
    printf("%s%s%s", tree->c0.cident,
	(is_parm(tree->c0.cident) ? "->" : "."),
	ctstrs[(int) tree->c1.ctfield]);
    if ((tree->c1.ctfield == cvalfield) &&
	(tree->c2.ctype != APLC_UKTYPE) &&
	(tree->c2.ctype != APLC_COMPLEX) &&
	(tree->c2.ctype != APLC_QUAT) &&
	(tree->c2.ctype != APLC_OCT))
      printf(".%s", mpfields[tree->c2.ctype]);
    break;

  case coindex:
    ctgen(tree->c0.cleft);
    printf("[");
    ctgen(tree->c1.cright);
    printf("]");
    break;

  case coiptr:
    printf("i%d", tree->c0.cindex);
    break;

  case coixorgin:
    printf("aplc_ixorg");
    break;

  case cofun:
    /*printf("%s(", tree->c0.cident);*/
    printf("%s(", tree->c0.cleft->c0.cident);
    if (!(tree->c1.cright == NILTREE))
      ctgen(tree->c1.cright);
    printf(")");
    break;

  case cofunarg:
    ctgen(tree->c0.cleft);
    if (!(tree->c1.cright == NILTREE)) {
      printf(", ");
      ctgen(tree->c1.cright);
    }
    break;

  case memptr:
    /* if (tree->c2.ctype != APLC_UKTYPE)*/
    if ( (tree->c2.ctype != APLC_UKTYPE) &&
	 (tree->c2.ctype != APLC_COMPLEX) &&
	 (tree->c2.ctype != APLC_QUAT) &&
	 (tree->c2.ctype != APLC_OCT) )
      /*printf("mp%d.%sp", tree->c0.cindex, tfstrs[tree->c2.ctype]);*/
      printf("mp%d.%s", tree->c0.cindex,
	     mpfields[tree->c2.ctype]);
    else
      printf("mp%d", tree->c0.cindex);
    break;

  case msfun:
    lp();
    ctmsfun(tree->c2.csfun, tree->c0.cleft);
    rp();
    break;

  case postinc:
    ctgen(tree->c0.cleft);
    printf("++ ");
    break;

  case coref:
    if ((tree->c0.cleft)->cop == deref) {
      /* coref dref; undo both */
      tree = tree->c0.cleft;
    } else {
      printf("&");
    }
    ctgen(tree->c0.cleft);
    break;

  case resptr:
    printf("res%d.%s", tree->c0.cindex,
	tfstrs[tree->c2.ctype]);
    break;

  case tcnst:
    printf("%s", tystrs[tree->c0.cindex]);
    break;

  case trsptr:
    printf("trs%d.%s", tree->c0.cindex,
	ctstrs[(int) tree->c1.ctfield]);
    /*if ((tree->c1.ctfield == cvalfield) &&
	(tree->c2.ctype != APLC_UKTYPE))*/
    if ((tree->c1.ctfield == cvalfield) &&
	(tree->c2.ctype != APLC_UKTYPE) &&
	(tree->c2.ctype != APLC_COMPLEX) &&
	(tree->c2.ctype != APLC_QUAT) &&
	(tree->c2.ctype != APLC_OCT))
      /*printf(".%sp", tfstrs[tree->c2.ctype]);*/
      printf(".%s", mpfields[tree->c2.ctype]);
    break;

  case trsvptr:
    /*printf("trs%d.value.%sp", tree->c0.cindex,
      tfstrs[tree->c2.ctype]);*/
    printf("trs%d.value.%s", tree->c0.cindex,
	mpfields[tree->c2.ctype]);
    break;
  }
  return;
}

/* gcnode - generate a new code tree node */
struct codetree *
gcnode(enum codeops cop)
{
  struct codetree *x;

  x = structalloc(codetree);
  x->cop = cop;
  return (x);
}

/* gicn - generate an integer constant type of node */
struct codetree *
gicn(enum codeops cop, int val, int typ)
{
  struct codetree *x;

  x = gcnode(cop);
  x->c0.cindex = val;
  x->c2.ctype = typ;
  return (x);
}

/* gixorg - generate the index origin */

struct codetree *
gixorg(void)
{
  return gicn(coixorgin, get_indexorg(), APLC_INT);
}

/* gcast - generate a cast-like node */
struct codetree *
gcast(enum codeops cop, struct codetree * cnode, int ctype)
{
  struct codetree *x;

  x = gmon(cop, cnode);
  x->c2.ctype = ctype;
  return (x);
}

/* gbin - generate a node with a codeop and two subtrees */
struct codetree *
gbin(enum codeops cop, struct codetree * cnode1, struct codetree * cnode2)
{
  struct codetree *x;

  x = gcnode(cop);
  x->c0.cleft = cnode1;
  x->c1.cright = cnode2;
  return (x);
}

/* gtrs - generate a trs type node */
struct codetree *
gtrs(int trsval, enum tfields tfield, int ttype)
{
  struct codetree *x;

  x = gcnode(trsptr);
  x->c0.cindex = trsval;
  x->c1.ctfield = tfield;
  x->c2.ctype = ttype;
  return (x);
}

struct codetree *
gident(char *name, enum tfields field, int ttype)
{
  struct codetree *x;

  x = gcnode(idptr);
  x->c0.cident = name;
  x->c1.ctfield = field;
  x->c2.ctype = ttype;
  return (x);
}

/* just a name, in an idptr */
struct codetree *
gname(char *name)
{
  struct codetree *x;
  char *xx;

  xx = (char *) malloc(1+strlen(name));
  strcpy(xx, name);
  x = gcnode(idptr);
  x->c0.cident = xx;
  x->c1.ctfield = 0;
  x->c2.ctype = 0;
  return (x);
}

/* gcond - generate a conditional tree */
struct codetree *
gcond(struct codetree * cond, struct codetree * left, struct codetree * right)
{
  struct codetree *x;
  int val;

  if (cond->cop == icnst) {
    val = cond->c0.cindex;
    if (val)
      return (left);
    else
      return (right);
  }
  x = gcnode(condop);
  x->c0.cleft = cond;
  x->c2.cmiddle = left;
  x->c1.cright = right;
  return (x);
}

struct codetree *
gmop(enum sfuns mop, struct codetree * child)
{
  struct codetree *x;

  x = gmon(msfun, child);
  x->c2.csfun = mop;
  return (x);
}

/*
	gsfun - generate a scalar operator type of node
               dyadic scalar ops
*/
struct codetree *
gsfun(enum sfuns sfun, struct codetree * cnode1, struct codetree * cnode2)
{
  struct codetree *x, *l;
  int i, j;

  if ((cnode1->cop == icnst) && (cnode2->cop == icnst)) {
    i = cnode1->c0.cindex;
    j = cnode2->c0.cindex;
    switch (sfun) {
    case APLC_PLUS:
      return (gicn(icnst, i + j, APLC_INT));
    case APLC_MINUS:
      return (gicn(icnst, i - j, APLC_INT));
    case APLC_TIMES:
      return (gicn(icnst, i * j, APLC_INT));
    case APLC_AND:
    case APLC_L_AND:
      return (gicn(icnst, i && j, APLC_INT));
    case APLC_OR:
    case APLC_L_OR:
      return (gicn(icnst, i || j, APLC_INT));
    case APLC_NAND:
      return (gicn(icnst, !(i && j), APLC_INT));
    case APLC_NOR:
      return (gicn(icnst, !(i || j), APLC_INT));
    case APLC_LT:
      return (gicn(icnst, i < j, APLC_INT));
    case APLC_LE:
      return (gicn(icnst, i <= j, APLC_INT));
    case APLC_EQ:
      return (gicn(icnst, i == j, APLC_INT));
    case APLC_NE:
      return (gicn(icnst, i != j, APLC_INT));
    case APLC_GE:
      return (gicn(icnst, i >= j, APLC_INT));
    case APLC_GT:
      return (gicn(icnst, i > j, APLC_INT));
    default:
      printf("[gsfun] illegal sfun (%d)\n", sfun);
      error("ctree:gsfun: unimplemented sfun");
    }
  }
  if ((sfun == APLC_PLUS) || (sfun == APLC_MINUS)) {
    if ((cnode2->cop == icnst) && (cnode2->c0.cindex == 0))
      return (cnode1);
    if (cnode1->cop == coconst) {
      return (gcast(coconst,
	      gsfun(sfun, cnode1->c0.cleft, cnode2),
	      cnode1->c2.ctype));
    }
  }
  if ((sfun == APLC_MINUS) && (cnode2->cop == icnst))
    return (gsfun(APLC_PLUS, cnode1,
	    gicn(icnst, -cnode2->c0.cindex, APLC_INT)));
  if (sfun == APLC_PLUS) {
    if (cnode1->cop == icnst)
      return (gsfun(APLC_PLUS, cnode2, cnode1));
    if ((cnode1->cop == dsfun) && (cnode1->c2.csfun == APLC_PLUS)) {
      if ((cnode1->c1.cright)->cop == icnst) {
	i = (cnode1->c1.cright)->c0.cindex;
	l = cnode1->c0.cleft;
	if (cnode2->cop == icnst)
	  return (gsfun(APLC_PLUS, l,
		  gicn(icnst,
		      i + cnode2->c0.cindex, APLC_INT)));
	return (gsfun(APLC_PLUS,
		gsfun(APLC_PLUS, l, cnode2),
		gicn(icnst, i, APLC_INT)));
      }
    } else if ((cnode2->cop == dsfun) && (cnode2->c2.csfun == APLC_PLUS))
      return (gsfun(APLC_PLUS, cnode2, cnode1));
  }
  if (sfun == APLC_TIMES) {
    if (cnode1->cop == icnst)
      return (gsfun(APLC_TIMES, cnode2, cnode1));
    if (cnode2->cop == icnst) {
      i = cnode2->c0.cindex;
      if (i == 1)
	return (cnode1);
      if ((cnode1->cop == dsfun) &&
	  (cnode1->c2.csfun == APLC_PLUS) &&
	  ((cnode1->c1.cright)->cop == icnst)) {
	j = (cnode1->c1.cright)->c0.cindex;
	return (gsfun(APLC_PLUS,
		gsfun(APLC_TIMES, cnode1->c0.cleft, cnode2),
		gicn(icnst, j * i, APLC_INT)));
      }
    }
  }
  x = gbin(dsfun, cnode1, cnode2);
  x->c2.csfun = sfun;
  return (x);
}

/*
	gmon - generate a monadic operator type of node */
struct codetree *
gmon(enum codeops cop, struct codetree * cnode)
{
  struct codetree *x;

  if ((cop == deref) && (cnode->cop == coconst))
    if ((cnode->c2.ctype == 1) || (cnode->c2.ctype == 2))
      if ((cnode->c0.cleft)->cop == icnst) {
	return (gicn(icnst, iconsts[(cnode->c0.cleft)->c0.cindex],
		APLC_INT));
      }
  x = gcnode(cop);
  x->c0.cleft = cnode;
  return (x);
}

/* sws 
   for accessing/printing type strings   */
extern char *
type_str(int type)
{
  return tystrs[type];
}

/* sws 
   for accessing/printing mp type fields   */
extern char *
mp_type_str(int type)
{
  return mpfields[type];
}

/* sws 
   for accessing/printing res_struct type fields   */
extern char *
res_type_str(int type)
{
  return tfstrs[type];
}

extern char *
cast_str(int type)
{
  return caststrs[type];
}

/* end of ctree.c */

