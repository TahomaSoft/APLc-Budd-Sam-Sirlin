/*
	APL Compiler -
		Run Time System
		I/O routines
		tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

/* ------------------------------------------------------------ */

#include "aplc.h"
#include "run.h"

/* ------------------------------------------------------------ */

/* sws  for file io */
#include <stdio.h>
#include <stdlib.h>

#if HAVE_STRING_H
/* sws  for trs2str */
#include <string.h>
#endif

#include <sys/types.h>

#if HAVE_FCNTL_H
/* sws for open */
#include <fcntl.h>
#endif


#if TIME_WITH_SYS_TIME 
#include <sys/time.h>
#include <time.h>
#else
#if HAVE_SYS_TIME_H
#include <sys/time.h>
#else
#include <time.h>
#endif 
#endif


#if HAVE_SYS_STAT_H 
/* sws  to get file sizes */
#include <sys/stat.h>
#endif

#if HAVE_UNISTD_H
/* jbww to get dup, pipe, fork; sws to get usleep for fbsd */
#include <unistd.h>
#endif


#if HAVE_SYS_WAIT_H 
/* jbww to get wait */
#include <sys/wait.h>
#endif

#if HAVE_TERMIOS_H 
/* jbww to get file control */
#include <termios.h>
#endif

/* for error traping */
#include <setjmp.h>

/* for error information */
#include <errno.h>

/* ------------------------------------------------------------ */
/* external functions */

/* not needed by freebsd, ... */ 
/*
extern int _flsbuf(unsigned int, FILE *);
extern int system(const char *);
extern double atof(const char *);
extern int atoi(const char *);
*/

#ifdef DJPC
extern void srand(int);
#endif

#ifdef SUNOS
extern int rand(void);
extern int fgetc(FILE *);
extern int ungetc(int, FILE *);

#ifdef SUNOS4
extern unsigned long time(time_t *);
#endif
#ifdef SUNOS5
/* solaris */
extern time_t time(time_t *);
#endif

/* in gcc stdlib */
/* extern void srand(unsigned int); */
#endif /* SUNOS */

/* ------------------------------------------------------------ */

/* switch for printing debug information */ 
#define DEBUGIO 0

#define DEBUGFI 0

/* ------------------------------------------------------------ */
/* global variables */
/* current statement number */
/* int stmtno;*/
#if defined LINUX || defined FREEBSD || defined(CYGWIN) 
/* glibc 2 doesn't allow the above, as stderr, stdout are not
   constants */
/* where output is sent */
FILE *aplcout;
static void aplcout_construct (void) __attribute__((constructor));
static void aplcout_construct (void) { aplcout = stdout; }
/* where errors are printed */
FILE *aplcerr;
static void aplcerr_construct (void) __attribute__((constructor));
static void aplcerr_construct (void) { aplcerr = stderr; }
#else
/* where output is sent */
FILE *aplcout = stdout;
/* where errors are printed */
FILE *aplcerr = stderr;
#endif


jmp_buf aplc_env;
static int trap_set = 0;


/* arbitrary limit of 11 pipes per spawn */
/* (we can only use half the file desciptors */
/* used by .bxspawn in runio.c */
/* if this is upped, SelCvec in .bxspawn in runio.c must be lengthened  */
#define MAXPIPES 11

/* input args */
static int aplcargc;
static char **aplcargv; 
static struct trs_struct arg;
/* command line arguments */
static char arg_avail = 0;

/* output mapping */
int _omapv[2] = {0, 0};


/* ------------------------------------------------------------ */
/* local function declarations */

static double * dsrval(double val);
static void proint(struct trs_struct * trs, int *val);


/* ------------------------------------------------------------ */
/* ------------------------------------------------------------ */

/* error - print an error message and exit 

   - seems hard to get stmtno here... must be local to each fn, yet
   this is called from withing lots of runtime fns
   
   */

/* new version */
extern void
aplc_trap(int n)
{
  trap_set = n;
  return;
}

extern void
aplc_error(char *s)
{
  if (trap_set) {
    longjmp(aplc_env, -1);
  }
  /* fprintf(aplcerr, "statement %d: apl run-time error: \n%s\n", n, s);*/
  fprintf(aplcerr, "apl run-time error: \n%s\n", s);
  exit(1);
}

#if 0
extern void
aplc_error(char *s)
{
  /* fprintf(aplcerr, "statement %d: apl run-time error: \n%s\n", n, s);*/
  fprintf(aplcerr, "apl run-time error: \n%s\n", s);
  exit(1);
}
#endif

/* sws
   perror() should print to stderr
   strerror() should return ptr to string 

   print system error message 
   J.B.W.Webber@ukc.ac.uk  99_3_12  */
extern void
aplc_syserr( char * msg) 
{
  fprintf(aplcerr, "apl system error: %s ", msg);
  exit(1);
}

/* dynamic scalar value - vector for shape/value.ip  */
extern int *
aplc_dsval(int val)
{
  union mp_struct mptemp;

  aplc_vectalloc(&mptemp, 1, APLC_INT);
  *mptemp.ip = val;
  return(mptemp.ip);
}

/* dynamic scalar value - vector, real   */
static double *
dsrval(double val)
{
  union mp_struct mptemp;

  aplc_vectalloc(&mptemp, 1, APLC_REAL);
  *mptemp.rp = val;
  return(mptemp.rp);
}

/* proint
   setup simple result structure for scalar integers 
   used by some sysvars
   changed to not allocate space
*/
static void
proint(struct trs_struct * trs, int *val)
{
  trs->type = APLC_INT;
  trs->rank = 0;
  trs->shape = aplc_ivone;
  trs->value.ip = val;
  trs->alloc_ind = 0;
  trs->size = 1;
}

/* setup a trs for a string */
extern void
aplc_str2trs(struct trs_struct * trs, char * str)
{
  int i, len;

  trs->type = APLC_CHAR;
  trs->rank = 1;
  len = strlen(str);
  trs->shape = aplc_dsval(len);
  trs->alloc_ind = APLC_ALLOC_SHAPE_F;
  aplc_vectalloc(&trs->value, len, APLC_CHAR);
  for (i=0; i<len; i++)
    (trs->value.cp)[i] = *str++;
  trs->alloc_ind |= APLC_ALLOC_VAL_F;
}

/* copy a string from a character trs, possibly dropping extra
   whitespace at the end

   - this may be convient to use when interfacing to aplc code from 
     C code 

   - assume that we have str[csize] declared outside
   - don't overwrite csize
   - return the string length
 */
extern int
aplc_trs2str(char *str, int csize, struct trs_struct *trs)
{
  int rsize;
  int is_zilde;

  /* check type */
  if ( trs->type != APLC_CHAR )
    return 0;
  /* now get length */
  is_zilde = 0; /* assume right is not zilde */
  if (trs->rank == 0)
    rsize = 1; /* scalar */
  else {
    if ((trs->rank == 1) && (trs->shape[0] == 0)) {
      is_zilde = 1; /* zilde */
      if (csize > 0)
	str[0] = '\0';
      return 0;/* quit here */
    }
    else
      rsize = trs->shape[0]; /* just read as a string */
  }
  /* now do the actual copy, at most csize-1 */
  rsize = min(rsize, csize-1);
  strncpy(str,trs->value.cp, (size_t) (rsize));
  str[rsize] = '\0';/* mark the string end */
  return rsize;
}

/* copy a string from a character trs, possibly dropping extra
   whitespace at the end

   - assume that we have str[csize] declared outside
   - if drop_ws == 1, then drop extra whitespace at the end
   - return the string length
   - also return is_zilde == 1 if right is zilde
   - return did_malloc==1 if we needed more space */
extern int
aplc_trs2str_sp(char **str, int csize, int *is_zilde, int *did_malloc, 
	int drop_ws, struct trs_struct *trs)
{
  int rsize, rtsize;

  /* check type */
  if ( trs->type != APLC_CHAR )
    return 0;
  /* now get length */
  *is_zilde = 0; /* assume right is not zilde */
  *did_malloc = 0;
  if (trs->rank == 0)
    rsize = 1; /* scalar */
  else {
    if ((trs->rank == 1) && (trs->shape[0] == 0)) {
      *is_zilde = 1; /* zilde */
      if (csize > 0)
	*str[0] = '\0';
      return 0;/* quit here */
    }
    else
      rsize = trs->shape[0]; /* just read as a string */
  }
  /* now do the actual copy */
  rtsize = rsize+1;/* space for null */
  if ( rsize < csize)
    strncpy(*str,trs->value.cp, (size_t) rsize);
  else {
    /* need to make more room */
    *str = APLC_CMALLOC(rtsize);
    if (!*str) {
      fprintf(aplcerr,"[aplc_trs2str_sp] malloc %d->%d\n", csize,rtsize);
      aplc_error("malloc failed!");
    }
    *did_malloc = 1;
    strncpy(*str, trs->value.cp, (size_t) rsize);
  }
  if (drop_ws) {
    /* delete possible whitespace at the end */
    while ( (rsize>1) && 
	    (( (*str)[rsize-1]==' ') || ( (*str)[rsize-1]=='\t')) ) {
      rsize--;
    }
  }
  (*str)[rsize] = '\0';/* mark the string end */
  return rsize;
}

/* aplc_setargs - make arguments available from main 
(sws)
*/
extern void 
aplc_setargs(int argc, char *argv[])
{
  aplcargc = argc;
  aplcargv = argv;
}

/*
 sysvar - code for system variables
          may also be used for system functions, when available

 all use static storage (must not be freed) except:
 sys (which then must be freed) 
                 
*/

/* static storage for system variables */
static int sys_io_value[1]    = {1};
static int sys_pp_value[1]    = {1};
static int sys_prng_value[1]  = {0};
static int sys_rl_value[1]    = {1};

static int sys_omap_shape[1] = {2};
static int sys_omap_value[2] = {0, 0};

static int sys_ts_shape[1] = {7};
static int sys_ts_value[7] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0} ;

#define ISsingleton(x) (x->rank == 0) || \
                       ( (x->rank ==1) && ((x->shape)[0] == 1) )

/* sws get value of a system variable */
extern void
aplc_sysvar(enum sysvars fun, struct trs_struct * res)
{
  int i;
  union mp_struct mptemp;

  switch (fun) {
  default:
    aplc_error("[sysvar] unimplemented system variable error");
    break;

  case SYS_IO:
    sys_io_value[0] = aplc_ixorg;
    proint(res, sys_io_value);
    break;

  case SYS_PP:
    sys_pp_value[0] = aplc_ppw[0];
    proint(res, sys_pp_value);
    break;

  case SYS_PRNG:
    sys_prng_value[0] = aplc_prng;
    proint(res, sys_prng_value);
    break;

  case SYS_RL:
    switch(aplc_prng) {
    case 0:
      /* standard rand */
      sys_rl_value[0] = rand();
      proint(res, sys_rl_value);
      break;
    default:
    case 1:
      /* Mother */
      sys_rl_value[0] = (int) aplc_seed;
      proint(res, sys_rl_value);
      break;
    }
    break;

  case SYS_OMAP:
    /* setup a result trs in case non-top */
    res->type = APLC_INT;
    res->rank = 1;
    res->shape = sys_omap_shape;
    /* *res->shape = 2;*/
    res->value.ip = sys_omap_value;
    res->value.ip[0] = _omapv[0];
    res->value.ip[1] = _omapv[1];
    res->alloc_ind = 0;
    res->size = 2;
    break;

  case SYS_ARG:
    {
      int j,k, rowsize;
      char *s;

      if (!arg_avail) {
	/* put argv in a local trs */
	arg.type = APLC_CHAR;
	arg.rank = 2;
	aplc_vectalloc(&mptemp, 2, APLC_INT);
	arg.shape = mptemp.ip;
	/* get size */
	rowsize = 0;
	for (i=0; i<aplcargc; i++) {
	  rowsize = max(rowsize, strlen(aplcargv[i]));
	}
	(arg.shape)[0] = aplcargc;
	(arg.shape)[1] = rowsize;
	aplc_vectalloc(&arg.value, (aplcargc)*rowsize, APLC_CHAR);
	k = 0;
	for (i=0; i< aplcargc; i++) {
	  s = aplcargv[i];
	  for (j=0; j<rowsize; j++) {
	    if (*s != '\0')
	      arg.value.cp[k] = *s++;
	    else
	      arg.value.cp[k] = ' ';
	    k++;
	  }
	}
	arg_avail = 1;
      }
      /* now use it */
      res->type = APLC_CHAR;
      res->rank = 2;
      res->shape = arg.shape;
      res->value.cp = arg.value.cp;
      res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
      res->size = aplc_vsize(res->rank, res->shape);
    }
  break;
  case SYS_TS:
    {
      /* time stamp */
#if HAVE_GETTIMEOFDAY 
      /* sun os 4 doesn' seem to support this somehow */
      int *tme;
      /* long tmeres; */
      struct timeval tp;
      struct timezone tzp;

      gettimeofday(&tp, &tzp);
      /* tmeres = time(0);*/
      tme = (int *) localtime(&(tp.tv_sec));
      res->type = APLC_INT;
      res->rank = 1;
      res->shape = sys_ts_shape;
      /* *res->shape = 7;*/
      res->value.ip = sys_ts_value;
      /* result is the struct tm type */
      res->value.ip[0] = tme[5] + 1900;/* year */
      res->value.ip[1] = tme[4] + 1;   /* month, 1 origin */
      res->value.ip[2] = tme[3]; /* day of month, 1-31 */
      res->value.ip[3] = tme[2]; /* hour 0-23 */
      res->value.ip[4] = tme[1]; /* minute 0-59 */
      res->value.ip[5] = tme[0]; /* sec    0-60 */
      res->value.ip[6] = tp.tv_usec/1000;      /* msec */
#else /* no gettimeofday - assume localtime */
      int *tme;
      /* long tmeres; */
      unsigned long tmeres;

      tmeres = time(0);
      tme = (int *) localtime(&tmeres);
      res->type = APLC_INT;
      res->rank = 1;
      res->shape = sys_ts_shape;
      /* *res->shape = 7;*/
      res->value.ip = sys_ts_value;
      /* result is the struct tm type */
      res->value.ip[0] = tme[5] + 1900;/* year */
      res->value.ip[1] = tme[4] + 1;   /* month, 1 origin */
      res->value.ip[2] = tme[3]; /* day of month, 1-31 */
      res->value.ip[3] = tme[2]; /* hour 0-23 */
      res->value.ip[4] = tme[1]; /* minute 0-59 */
      res->value.ip[5] = tme[0]; /* sec    0-60 */
      res->value.ip[6] = 0;      /* no msec available */
#endif /* gettimeofday */
      res->alloc_ind = 0;
      res->size = aplc_vsize(res->rank, res->shape);
    }
  break;
  case SYS_JTS:
    {
      /* Julian time stamp */
#if HAVE_GETTIMEOFDAY 
      struct timezone tzp;
      struct timeval tp;
      double tnow;

      gettimeofday(&tp, &tzp);
      tnow = ((double) tp.tv_sec) + ((double)  tp.tv_usec)/US_per_SEC ;      /* sec */

      res->type = APLC_REAL;
      res->rank = 0;
      res->shape = aplc_dsval(1);
      res->value.rp = dsrval(tnow);
#else /* no gettimeofday */
      res->type = APLC_INT;
      res->rank = 0;
      res->shape = aplc_dsval(1);
      res->value.ip = 0;
#endif /* gettimeofday */
      res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
      res->size = aplc_vsize(res->rank, res->shape);
     }
  break;
  }
}

/* sws  assign value to certain system variables */
extern void
aplc_asysvar(enum sysvars fun, struct trs_struct * res,
	     struct trs_struct * right)
{
  /*int i;*/
  /*union mp_struct mptemp;*/

  if (right->type == APLC_UKTYPE)
    aplc_error("[aplc_asysvar] argument error");    

  switch (fun) {
  default:
    aplc_error("[aplc_asysvar] unimplemented system variable error");
    break;

  case SYS_IO:
    aplc_ixorg = *(right->value.ip);
    sys_io_value[0] = aplc_ixorg;
    proint(res, sys_io_value);
    break;

  case SYS_PP:
    aplc_ppw[0] = *(right->value.ip);
    /* derive other values */
    if (log10((double)INT_MAX) < aplc_ppw[0])
      aplc_ppw[1] = INT_MAX;
    else
      aplc_ppw[1] = pow(10.0, (double) abs(aplc_ppw[0]));
    aplc_ppw[2] = (int) floor( log10((double) aplc_ppw[1] ) );
    aplc_ppw[3] = min(DBL_DIG, abs(aplc_ppw[0])); 
#if 0
    /* for testing */
    fprintf(aplcerr," ppw = [%d %d %d %d]\n",
	    aplc_ppw[0],aplc_ppw[1],aplc_ppw[2],aplc_ppw[3]);
#endif
    sys_pp_value[0] = aplc_ppw[0];
    proint(res, sys_pp_value);
    break;

  case SYS_PRNG:
    aplc_prng = (unsigned) *(right->value.ip);
    sys_prng_value[0] = (int) aplc_prng;
    proint(res, sys_prng_value);
    break;

  case SYS_RL:
    switch(aplc_prng) {
    case 0:
      /* standard rand */
      srand((unsigned)*(right->value.ip));
      sys_rl_value[0] = rand();
      proint(res, sys_rl_value);
      break;
    default:
    case 1:
      /* Mother */
      aplc_seed = (unsigned) *(right->value.ip);
      aplc_rl_init = 1;
      sys_rl_value[0] = (int) aplc_seed;
      proint(res, sys_rl_value);
      break;
    }
    break;

  case SYS_OMAP:
    /* we're changing the values */
    if ( (right->type == APLC_INT) || (right->type == APLC_BOOL) ) {
      if (ISsingleton(right)) {
	_omapv[0] = (right->value.ip)[0];
	_omapv[1] = (right->value.ip)[0];
      } else if (1 == right->rank) {
	if (2 == (right->shape)[0]) {
	  _omapv[0] = (right->value.ip)[0];
	  _omapv[1] = (right->value.ip)[1];
	} else {
	  aplc_error("[OMAP] shape error");
	}
      } else {
	aplc_error("[OMAP] rank error");
      }
      /* now reset pointers */
      if (_omapv[0] == 0)
	aplcout = stdout;
      else
	aplcout = stderr;
      if (_omapv[1] == 0)
	aplcerr = stdout;
      else
	aplcerr = stderr;
    } else {
      /* right is not APLC_INT */
      aplc_error("[OMAP] domain error");
    }
    /* setup a result trs in case non-top */
    res->type = APLC_INT;
    res->rank = 1;
    res->shape = sys_omap_shape;
    /* *res->shape = 2;*/
    res->value.ip = sys_omap_value;
    res->value.ip[0] = _omapv[0];
    res->value.ip[1] = _omapv[1];
    res->alloc_ind = 0;
    res->size = aplc_vsize(res->rank, res->shape);
    break;
  }
}

/* sws call system */
extern void
aplc_sys(struct trs_struct * res,
	 struct trs_struct * left, struct trs_struct * right)
{
  int i;
  char *c;
  /*union mp_struct mptemp;*/

  if ( (c = APLC_CMALLOC(1 + aplc_vsize(right->rank, right->shape))) )
    aplc_cp2str(c, right);
  else
    aplc_error("SYS: malloc error (right)");
  /* fprintf(aplcout,"system(%s)\n", c); */
  i = system(c);
  aplc_free(c);
#if 0
  if (0 != i) 
    aplc_error("SYS: system unavailable");
#endif
  if ((127 == i)||(-1 == i)) {
    fprintf(aplcerr, "[sys] error %d\n", i);
    aplc_syserr("[sys]: system failed");
  } 

  /* static version
      sys_sys_value[0] = i;
      proint(res, sys_sys_value);*/
      /* dynamic (freeable) version */ 
  res->type = APLC_INT;
  res->rank = 0;
  res->shape = aplc_dsval(1);
  res->value.ip = aplc_dsval(i);
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  res->size = 1;
}



/* delay for n sec 
   monadic; only uses right argument 
   can use:
      nanosleep
      usleep
      software loop 
   depending on the machine 
 */

extern void
aplc_dl(struct trs_struct * res, struct trs_struct * right)
{
  double delay;
  double tstart, tnow;

  switch(right->type) {
  default:
    delay = 0;
    aplc_error("[.bxdl] wrong type argument");
    break;
  case APLC_BOOL:
  case APLC_INT:
    delay = *(right->value.ip);
    break;
  case APLC_REAL:
    delay = *(right->value.rp);
    break;
  }
#if HAVE_GETTIMEOFDAY 
#if HAVE_NANOSLEEP
  /* for machines that have nanosleep, timespec, timeval, timezone, gettimeofday	*/
  /* J.B.W.Webber@ukc.ac.uk  99_3_5 */
  /* sws SUNOS5 could be here, but then need to link with posix4 */
  {
    struct timezone tzp;
    struct timeval tp;
    struct timespec treq, trem;
    double tremain;
    long sec, nsec;
    
    gettimeofday(&tp, &tzp);
    tstart = ((double) tp.tv_sec) + (((double)  tp.tv_usec)/US_per_SEC)  ;      /* sec */
    /*  fprintf(aplcerr, "\n[bxdl] time: %f sec. \n", tstart); */
#ifdef LINUX
    treq.tv_sec =  (sec  = (long) floor (delay));
#else
    /* treq.tv_sec = (time_t) sec  = (long) floor (delay);*/
    treq.tv_sec = (time_t) (sec  = (long) floor (delay));
#endif
    treq.tv_nsec = nsec = (long) floor( NS_per_SEC * (delay - sec));
    /*  fprintf(aplcerr, "\n[bxdl] sleeping: %f sec. \n", delay); */
    if ( nanosleep ( &treq , &trem ) <  0 ) {
      tremain = ((double) trem.tv_sec) + ((double)  trem.tv_nsec)/NS_per_SEC  ;      /* sec */
#if DEBUGIO
      fprintf(aplcerr, "\n[bxdl] sleep cut short \n");
      fprintf(aplcerr, "[bxdl] time remaining: %f sec. \n", tremain);
#endif
    }
    gettimeofday(&tp, &tzp);
    tnow = ((double) tp.tv_sec) + ((double)  tp.tv_usec)/US_per_SEC ;      /* sec */
    /*  fprintf(aplcerr, "\n[bxdl] time: %f sec. \n", tnow); */
  }
#elif HAVE_USLEEP /* vs nannosleep */
  /*#elif defined(SUNOS5) || defined(FREEBSD) */
  /* for machines that have usleep, timeval, timezone, gettimeofday in usec */
  /* sws */
  {
    struct timezone tzp;
    struct timeval tp;

    gettimeofday(&tp, &tzp);
    tstart = ((double) tp.tv_sec) 
      + (((double)  tp.tv_usec)/US_per_SEC); /* sec */
    usleep( (u_int) (US_per_SEC*delay) );
    gettimeofday(&tp, &tzp);
    tnow = ((double) tp.tv_sec) + ((double)  tp.tv_usec)/US_per_SEC ;      /* sec */
  }
#else /* neither nannosleep or usleep */ 
  /*#elif defined (ST)*/
  /* for machines that have timeval, timezone, gettimeofday */
  /* J.B.W.Webber@ukc.ac.uk  99_3_5	*/
  {
    struct timezone tzp;
    struct timeval tp;
    int Sleep;
    double tend;

    gettimeofday(&tp, &tzp);
    tstart = ((double) tp.tv_sec) + (((double)  tp.tv_usec)/US_per_SEC)  ;      /* sec */
    tnow = tstart;
    tend = tnow + delay;
#if DEBUGIO
    fprintf(aplcerr, "\n[bxdl] time: %f sec. \n", tnow);
#endif
    Sleep = (int) floor(tend - tnow);
    if (Sleep > 0) {
#if DEBUGIO
      fprintf(aplcerr, "\n[bxdl] sleeping: %d sec. \n", Sleep);
#endif
      sleep (Sleep);
    }
    gettimeofday(&tp, &tzp);
    tnow = ((double) tp.tv_sec) + ((double)  tp.tv_usec)/US_per_SEC ;      /* sec */
    /*   fprintf(aplcerr, "\n[bxdl] time: %f sec. \n", tnow); */
    do {
      gettimeofday(&tp, &tzp);
      tnow = ((double) tp.tv_sec) + ((double)  tp.tv_usec)/US_per_SEC ;      /* sec */
    } while (tend > tnow); 
    /*  fprintf(aplcerr, "\n[bxdl] time: %f sec. \n", tnow); */
  }
#endif /* end of sleep tests */
#else  /* no gettimeofday */
  /* assume machine at least has time */
  {
    double tend;

    tstart = (double) time(0);
    tnow = tstart;
    tend = tnow + delay;
    while (tend > tnow)
      tnow = (double) time(0);
  }
#endif /* different machine options for gettimeofday */
  res->type = APLC_REAL;
  res->rank = 0;
  res->shape = aplc_dsval(1);
  res->value.rp = dsrval(tnow-tstart);
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  res->size = aplc_vsize(res->rank, res->shape);
}


/* ------------------------------------------------------- */
/*
   function to generate numeric zilde (.io 0) in a result
   sws
*/
extern void
aplc_zilde(struct trs_struct * res)
{
  res->type = APLC_INT;
  res->rank = 1;
  res->shape = aplc_ivzero;
  res->size = 0;
  res->alloc_ind = APLC_UNALLOC;
  res->value.ip = (int *) 0;
  return;
}

/* ------------------------------------------------------- */
/*
   function to generate character zilde ('') in a result
   sws
*/
extern void
aplc_czilde(struct trs_struct * res)
{
  res->type = APLC_CHAR;
  res->rank = 1;
  /*  aplc_vectalloc(&mptemp, 1, APLC_INT);
      res->shape = mptemp.ip;
      res->shape[0] = 0;*/
  res->shape = aplc_ivzero;
  res->size = 0;
  res->alloc_ind = APLC_UNALLOC;
  res->value.ip = (int *) 0;
  return;
}

/* ------------------------------------------------------- */
#if 0
/* old monadic definition */
/* pipe */
extern void
aplc_pipe(struct trs_struct * res, struct trs_struct * right)
{
  char *c, *cd;
  char tmp_file[] = "apl_tmp";
  char clean[] = "rm ";
  int i;
  struct trs_struct tmp_trs;

  if ( (c = APLC_CMALLOC((1 + aplc_vsize(right->rank, right->shape)))) )
    aplc_cp2str(c, right);
  else
    aplc_error("pipe: malloc error (right)");
  cd = strcat(c," > ");
  cd = strcat(cd,tmp_file);
  fprintf(aplcout,"[pipe] system('%s')\n", cd); 
  i = system(cd);
  if (0 != i) 
    aplc_error("pipe: system unavailable");
  /* now read */
  aplc_str2trs(&tmp_trs, tmp_file);
  aplc_fread(res, &tmp_trs);
  /* now delete tmp file */
  cd = strcat(clean,tmp_file);
  fprintf(aplcout,"[pipe] system('%s')\n", cd); 
  i = system(cd);
  if (0 != i) 
    aplc_error("pipe: system unavailable");
}
#endif


/* ------------------------------------------------------- */
/* pipe

   Pipe data through unix command, and back in again.
   Also just pipes in, or pipes out.  jbww-UKC-11/82 
   created for Apl/11, updated for apl2c	      

   o left arg is command 
   o right is (char) data input
  
   o returns char data. J.B.W.Webber@ukc.ac.uk 99_31_02 


   behavior:
   0 parent fork 1st child
     1 forks 2nd child  
       2 writes right to pipeout[1] 
       2 close; exit(0)  
     1 close 0, dup(pipeout[0] (onto 0)
     1 close 1; dup(pipeback[1] (onto 1); close all else
     1 system(cmd); stdin is pipeout[0], stdout is pipeback[1]
     1 exit(1)
   0 aplc_rdfd(res, pipeback[0]);
     
*/

/* for debugging output */
#define DPIPE 0

extern void
aplc_pipe(struct trs_struct * res, struct trs_struct * left,
          struct trs_struct * right)
{
  char *cmd;
  int i;
  /* shouldn't vsize return an :  unsigned int or long  ?  */ 
  int rsize;
  int pipeout[2], pipeback[2];
  /* these are in different processes, so 2 are not needed */
  int   fkpidw, fkpidc; 
  char  *block;
  unsigned int size;
  long SizeOfInt;
/*
  int i, j;
  int size, size2;
  long size2;
  unsigned int count, size, buffers;
  char  *block, *block2;
  struct stat stbuf;
 */
  size_t nwritten;

  SizeOfInt = (long) sizeof (int);

  /* check right (data) argument */
  /*  this is handled in trs.c, leaf.c ... but... */
  if (right->type != APLC_CHAR)
    aplc_error("pipe: data: character argument please ");
  if (right->rank == 0)
    rsize = 1;
  else
    rsize = aplc_vsize(right->rank, right->shape);

  /* check left (command)  argument */
  /*  this is handled in trs.c, leaf.c ... but... */
  if (left->type != APLC_CHAR)
    aplc_error("pipe: command: character argument please ");
  /* put left in cmd */
  if ( (cmd = APLC_CMALLOC(1 + aplc_vsize(left->rank, left->shape))) )
    aplc_cp2str(cmd, left);
  else
    aplc_error("pipe: malloc error (cmd)");

  /* create a pipe for communication */ 
  if( pipe(pipeout) < 0) {
    pipeout[0] = pipeout[1] = -1;	
    aplc_error("pipe: pipeout create failed");
  }
  if( pipe(pipeback) < 0) {
    pipeback[0] = pipeback[1] = -1;	
    aplc_error("pipe: pipeback create failed");
  }
  /*  set-up command execution process 
      - try till we succeed */
#if DPIPE
  fprintf(aplcerr,"[pipe] parent; pid %d\n", getpid()); 
  /* fprintf(aplcerr,"[pipe] EAGAIN %d, ENOMEM %d\n", EAGAIN, ENOMEM); */
#endif
  /* could wait here or at the end */
  /* wait(NULL);*/

  while( ( fkpidc =  fork() ) < 0) {
    /* NOT vfork - it closes parent files */
#if DPIPE
    fprintf(aplcout,"[pipe] command forking, status %d, errno %d\n", 
	    fkpidc, errno); 
    /* sleep(1); */
#endif
    ;
  } 
#if DPIPE
  fprintf(aplcerr,"[pipe] parent or 1st child; pid %d\n", getpid()); 
#endif
  if (fkpidc == 0) {
    /* this is the 1st child */
#if DPIPE
    fprintf(aplcerr,"[pipe] 1st child; parent pid %d\n", getppid()); 
    /* fprintf(aplcout,"[pipe] (write) setup \n"); */ 
#endif
    /* spawn writing-to-pipe process	*/
    /* we nest them so wait knows when cmd finishes */
    while ( (fkpidw =  fork()) < 0 ) {
#if DPIPE
      fprintf(aplcout,"[pipe] write forking, status %d, errno %d\n", 
	      fkpidw, errno); 
#endif
      /* sleep(1); */
      ;
    } 
    if (fkpidw == 0) {
      /* this is the 2nd child */
#if DPIPE
      fprintf(aplcerr,"[pipe] 2nd child; parent pid %d\n", getppid()); 
      /* fprintf(aplcout,"[pipe] (write) setup \n"); */ 
#endif
      /* close useless files */
      if ( (  close(pipeout[0]) < 0 )
	   ||(  close(pipeback[0])< 0 )
	   ||(  close(pipeback[1])< 0 )
	   ||(  close(0)< 0 )
	   ||(  close(1)< 0 ) ) 
	aplc_error("pipe: pipe (write) close failed");
      block = right->value.cp;
      size = rsize;
#if 1
      /* new version - take more care */
      while( size > 0 ) {
	i = (size > BUFSIZ) ? BUFSIZ : size;
	/* write is raw: unbuffered, unformated */
	if (( nwritten = write(pipeout[1], block, (size_t) i)) <= 0 ) {
	  if (errno == EINTR)  /* interrupted by sig handler return */
	    nwritten = 0;      /* and call write() again */
	  else {
	    fprintf(aplcerr," write error %d\n", errno);
	    aplc_error("[pipe] write error");  
	  }
	}
	block += nwritten;
	size  -= nwritten;
      }
#else
      /* old version */
      while( size > 0 ) {
	i = (size > BUFSIZ) ? BUFSIZ : size;
	/* write is raw: unbuffered, unformated */
	write(pipeout[1], block, (unsigned) i);
	block += i;
	size  -= i;
      }
#endif /* old version */

      if ( close(pipeout[1]) < 0 )	    {
	aplc_error("pipe: pipe (write end) close failed");
      } 
#if DPIPE
      fprintf(aplcerr,"[pipe] 2nd child exiting\n");
#endif
      exit(0);/* 2nd child exits */
    } else {
      /* the 1st child */
#if DPIPE
      fprintf(aplcerr,"[pipe] 1st child; 2nd child pid %d\n", fkpidw); 
      /*fprintf(aplcerr, "[pipe:write] pid %d\n", fkpidw);*/
#endif
    }
    /* the 1st child */
    /* command process */
    /* fprintf(aplcout,"[pipe] (cmd) setup \n"); */ 

    if ( close(0) < 0 )
      aplc_error("pipe: pipe (cmd in 0) close failed");
    if ( dup(pipeout[0]) < 0 ) 
      aplc_error("pipe: pipeout dup failed");
    /* we may now read 0 and get pipeout[0] */

    if ( close(1) < 0 )
      aplc_error("pipe: pipe (cmd out 1) close failed");
    if ( dup(pipeback[1]) < 0 )
      aplc_error("pipe: pipeback dup failed");
    /* we may now write 1 and go to  pipeback[1] */

    /* close useless files */
    if ( (  close(pipeout[0]) < 0 )
	 ||(  close(pipeout[1]) < 0 )
	 ||(  close(pipeback[0])< 0 )
	 ||(  close(pipeback[1])< 0 ) ) 
      aplc_error("pipe: pipe cmd close failed");
    /* actually execute the cmd */
    i = system(cmd);
    aplc_free(cmd);
#if 0
    execl( "/bin/csh", "aplpipe: csh", "-c", p->datap,   0);
    kill(9);     /* if can't,  shut down pipe  processes  */
    error("\n ...  can't execute shell\n");
    _exit(1);
#endif
#if DPIPE
    fprintf(aplcerr,"[pipe] 1st child exiting\n");
#endif
    exit(1);/* end of 1st child */
  }  else {
    /* original process */
#if DPIPE
    fprintf(aplcerr,"[pipe] parent; 1st child pid %d\n", fkpidc);
    /* fprintf(aplcerr, "[pipe:cmd] pid %d\n", fkpidc); */
#endif
  }
  /* original process */
  /*fprintf(aplcout,"[pipe] main flow ...\n"); */
  /* close useless files */
  if ( (  close(pipeout[0]) < 0 )
       ||(  close(pipeout[1]) < 0 )
       ||(  close(pipeback[1])< 0 ) ) 
    aplc_error("pipe: pipe read close failed");
  /*  now just read it back in  */
  /* fprintf(aplcout,"[pipe] (read) \n"); */ 
  /* aplc_rdfd(res, pipeback[0], 'b'); */
  aplc_rdfd(res, pipeback[0]);
  if (( close(pipeback[0])) < 0)
    aplc_error("[pipe]: pipe read close failed");
#if DPIPE
  fprintf(aplcerr,"[pipe] parent; ending\n"); 
#endif
  /* need to wait here for child to finish before going on */
  wait(NULL);
}
/* end of pipe */ 

/* ------------------------------------------------------- */
/* spawn

 Spawn a unix command, connect to stdin, stdout, etc. of spawned
 process.  Right arg is command pipeline; left arg: controls which fds
 of command command are connected to as input or output; sets
 blocking/non-blocking i/o.  Two modes: Character vector or array; for
 each fd : {NN}{i|o}{b|n} interpreted as {fd of
 command},{input|output},{blocking|non-blocking}.

	Fds .is '00in02on' .bxspawn Cmd  : connects to stdin, stderr of Cmd.	
	Fds .is N .bxspawn Cmd  : for N = 3, connects to stdin, stdout, stderr.	

 Integer N : get fds 0..N-1 :	00ib						
				01ob						
				02ob						
				03ib, with i,o then alternating (to NN=10)	

 returns integer pipe file descriptors for the current process.
 created from pipe : J.B.W.Webber@ukc.ac.uk 99_3_10,13

 note monadic code (#if 0) worked, but was not flexible enough		
 if you are trying to read this code, look at monadic code first
 */

/* for debugging; 0,1,2 */
#define SPAWNDB 0

/* dyadic code */
extern void
aplc_spawn(struct trs_struct * res, struct trs_struct * left, 
	   struct trs_struct *right) 
{
  char *cmd;
  int i;
  int rsize;
  /* shouldn't vsize return an :  unsigned int or long  ?  */ 
  int   fkpidc = 0; 
  int SelVsize, Npipe, PipeN, Flags;
  int Nfd = 0;
  char * SelCvec; 
  char  Cnum[3];
  int Pipes[2 * MAXPIPES];	/* these are the fds returned by pipe(), we only use half */ 
  int Fd[MAXPIPES];   		/* these are the fds as seen by the spawned program */ 

  /* default file descriptor selection control vector; 11 defined, could have more : */ 
  SelCvec = "00ib01ob02ob03ib04ob05ib06ob07ib08ob09ib10ob";

  /* check right (command) argument */
  /*  this is handled in trs.c, leaf.c
      if (right->type != APLC_CHAR)
      aplc_error("[spawn]: command: character argument please ");
 */
  if (right->rank == 0)
    rsize = 1;
  else {
    rsize = aplc_vsize(right->rank, right->shape);
  }
  /* check left (selection) argument */
  switch (left->type) {
  default:
    aplc_error("[spawn]: bad selection type");
    break;
  case APLC_BOOL :
  case APLC_INT :
    if (left->rank != 0) {
      if (! ((left->rank == 1) && (left->shape[0] == 1))  )
	aplc_error("[spawn]: bad selection length");
    }
    else {
      if ( (Nfd = * left->value.ip) > (MAXPIPES) )
	aplc_error("[spawn]: selection: fewer, or use character mode please ");
      /* SelCvec[4*Nfd] = '\0'; */
    }
    break;
  case APLC_CHAR : 
    SelVsize = aplc_vsize(left->rank, left->shape);
    Nfd = SelVsize / 4;
    if ( Nfd > (MAXPIPES) )
      aplc_error("[spawn]: selection: fewer pipes please (or re-compile for more) ");
    if (SelVsize != 4 * Nfd)
      aplc_error("[spawn]: selection: wrong nomber of characters");
    SelCvec = left->value.cp; 
    if ( (SelCvec = APLC_CMALLOC(1 + SelVsize )) )
      aplc_cp2str(SelCvec, left);
    else
      aplc_error("spawn: malloc error (left)");
    break;
  }
#if SPAWNDB > 1
  fprintf(aplcerr, "[spawn] Nfd: %d\n", Nfd);
  fprintf(aplcerr, "[spawn] SelCvec: %s\n", SelCvec);
#endif

  /*  create pipes  */
  Npipe = 0;
  while ( Npipe < Nfd ) {
    if( pipe(& Pipes[2 * Npipe]) < 0) {
      /* we get 2 file descriptors at each call, can only use 1 */ 
      Pipes[2 * Npipe] = Pipes[1 + (2 * Npipe)] = -1;	
      aplc_error("[spawn]: pipe create failed");
    }
#if SPAWNDB > 1
    fprintf(aplcerr, "[spawn:pipe] opening fds: %d %d \n", 
	    Pipes[2 * Npipe], Pipes[1 + (2 * Npipe)] );
#endif
    Npipe++;
  }

  /*  set-up command execution process	*/
  /* fork - create child process */ 
  while( ( fkpidc =  fork() ) < 0) {
    /* NOT vfork - it closes parent files */
#if SPAWNDB > 1
    fprintf(aplcout,"[spawn] command forking \n"); 
#endif
    /* sleep(1); */
  } 
  if( fkpidc == 0) {
    /* command process */
#if SPAWNDB >0
    fprintf(aplcout,"[spawn] (cmd) setup\n");
#endif

    /* dup file descriptors, close useless files */
    Npipe = 0;
    while ( Npipe < Nfd ) {
      /* the fd number, as a string */
      Cnum[0] = SelCvec[4 * Npipe];
      Cnum[1] = SelCvec[1 + (4 * Npipe)];
      Cnum[2] = '\0'; 
      PipeN = atoi(Cnum);
#if SPAWNDB > 1
      fprintf(aplcerr, "[spawn:cmd] for fds: %s \n", Cnum );
      fprintf(aplcerr, "[spawn:cmd] for fds: %d \n", PipeN );
#endif
      if ( SelCvec[2 + (4 * Npipe)] == 'i' ) {
	/* we wish to make this input for the spawned process */
	/* dup pipe file descriptor */
#if SPAWNDB > 1
	fprintf(aplcerr, "[spawn:cmd] making fd %d a duplicate of fd %d for input to cmd \n", PipeN, Pipes[2 * Npipe] );
#endif
	close(PipeN); /* we ignore errors, as some may well be closed already */
	if ( (Fd[Npipe]  = fcntl(Pipes[2 * Npipe], F_DUPFD, PipeN) )  < 0)
	  aplc_syserr("[spawn]: dup (i) failed");
	/* close useless file */
	if ( close(Pipes[1 + (2 * Npipe)]) < 0 )
	  fprintf(aplcerr, "[spawn] close pipe (s:i) failed \n");
      } else {
	/* we wish to make this output for the spawned process */
	/* dup pipe file descriptor */
#if SPAWNDB > 1
	fprintf(aplcerr, "[spawn:cmd] making fd %d a duplicate of fd %d for output from cmd \n", PipeN, Pipes[1 + (2 * Npipe)]);
#endif
	close(PipeN); /* we ignore errors, as some may well be closed already */
	if ( (Fd[Npipe]  = fcntl(Pipes[1 + (2 * Npipe)], F_DUPFD, PipeN) )  < 0)
	  aplc_syserr("[spawn]: dup (o) failed");
	/* close useless file */
	if ( close(Pipes[2 * Npipe]) < 0 )
	  fprintf(aplcerr, "[spawn] close pipe (s:o) failed \n");
      }
      Npipe++;
    }

    if ( (cmd = APLC_CMALLOC(1 + aplc_vsize(right->rank, right->shape))) )
      aplc_cp2str(cmd, right);
    else 
      aplc_error("spawn: malloc error (right)");
    i = system(cmd);
    aplc_free(cmd);
    exit(1);
  }  else {
    /* caller process */
#if SPAWNDB >0
    fprintf(aplcerr, "[spawn:cmd] pid %d\n", fkpidc);
#endif
  }
#if SPAWNDB >0
  fprintf(aplcout,"[spawn] main flow ...\n");
#endif
  /* this works fine for 1 in, 1 out, but we may need more */

  /* set blocking/non-blocking */
  /* close useless files */
  /* return wanted fds */
  aplc_vectalloc(&res->value, Nfd, APLC_INT);
  Npipe = 0;
  while ( Npipe < Nfd ) {
    if ( SelCvec[2 + (4 * Npipe)] == 'i' ) {
      /* we wish to make this input for the spawned process */
      if ( SelCvec[3 + (4 * Npipe)] == 'n' ) {
	/* set non-blocking */
#if SPAWNDB > 1
	fprintf(aplcerr, "[spawn:read] making fd: %d non-blocking \n", Pipes[1 + (2 * Npipe)] );  
#endif
	if (( Flags = fcntl(Pipes[1 + (2 * Npipe)], F_GETFL,0)) < 0)
	  aplc_error("[spawn:read]: fcntl get failed");
	if (( fcntl(Pipes[1 + (2 * Npipe)],F_SETFL, (long) Flags | O_NDELAY)) < 0)
	  aplc_error("[spawn:read]: fcntl set failed");
      } else {
#if SPAWNDB > 1
	fprintf(aplcerr, "[spawn:read] making fd: %d blocking \n", Pipes[1 + (2 * Npipe)] );
#endif
	;
      }
      /* close useless file */
#if SPAWNDB > 1
      fprintf(aplcerr, "[spawn:read] closing fd: %d \n", 
	      Pipes[2 * Npipe] );  
#endif
      if ( close(Pipes[2 * Npipe]) < 0 )
	fprintf(aplcerr, "[spawn] close pipe (c:o) failed \n");
      /* return wanted fd */
      res->value.ip[Npipe] = Pipes[1 + (2 * Npipe)];
    } else {
      /* we wish to make this output for the spawned process */
      if ( SelCvec[3 + (4 * Npipe)] == 'n' ) {
	/* set non-blocking */
#if SPAWNDB > 1
	fprintf(aplcerr, "[spawn:read] making fd: %d non-blocking \n", Pipes[2 * Npipe] );  
#endif
	if (( Flags = fcntl(Pipes[2 * Npipe], F_GETFL,0)) < 0)
	  aplc_error("[spawn:read]: fcntl get failed");
	if (( fcntl(Pipes[2 * Npipe],F_SETFL, (long) Flags | O_NDELAY)) < 0)
	  aplc_error("[spawn:read]: fcntl set failed");
      } else {
#if SPAWNDB > 1
	fprintf(aplcerr, "[spawn:read] making fd: %d blocking \n", 
		Pipes[2 * Npipe] );
#endif
	;
      }
      /* close useless file */
#if SPAWNDB > 1
      fprintf(aplcerr, "[spawn:read] closing fd: %d \n", 
	      Pipes[1 + (2 * Npipe)] );
#endif
      if ( close(Pipes[1 + (2 * Npipe)]) < 0 )
	fprintf(aplcerr, "[spawn] close pipe (c:i) failed \n");
      /* return wanted fd */
      res->value.ip[Npipe] = Pipes[2 * Npipe];
    }
    Npipe++;
  }

  res->type = APLC_INT;
  res->alloc_ind = APLC_ALLOC_VAL_F;
  if (Npipe == 1) {
    res->rank = 0;
    res->shape = aplc_ivone;
  }  else {
    res->rank = 1;
    res->shape =  aplc_dsval(Nfd);
    res->alloc_ind |= APLC_ALLOC_SHAPE_F;
  }
  res->size = aplc_vsize(res->rank, res->shape);
  return;
}

/* ------------------------------------------------------- */
/* spawn monadic code

   return 2 fd's:
   - res[1]: write to  cmd[stdin]  : pipeout[1] 
   - res[2]: read from cmd[stdout] : pipeback[0] 

 */
extern void
aplc_spawn_mon(struct trs_struct * res, struct trs_struct *right) 
{
  char *cmd;
  int i;
  int rsize;
  int   fkpidc = 0; 
  int pipeout[2], pipeback[2];

  /* check of right (command) argument for char 
     is handled in trs.c, leaf.c */
  if (right->rank == 0)
    rsize = 1;
  else
    rsize = aplc_vsize(right->rank, right->shape);

  /*  create pipes  */
  if( pipe(pipeout) < 0) {
    pipeout[0] = pipeout[1] = -1;	
    aplc_error("spawnm: pipeout create failed");
  }
  if( pipe(pipeback) < 0) {
    pipeback[0] = pipeback[1] = -1;	
    aplc_error("spawn: pipeback create failed");
  }

  /*  set-up command execution process	*/
  /* now fork */
  while( ( fkpidc =  fork() ) < 0) {
    /* NOT vfork - it closes parent files */
#if SPAWNDB > 1
    fprintf(aplcout,"[spawnm] command forking \n"); 
#endif
    /* sleep(1); */
  } 
  if( fkpidc == 0) {
    /* command (sub) process */
#if SPAWNDB >0
    fprintf(aplcout,"[spawnm] (cmd) setup\n");
#endif

    /* dup file descriptore */
    if ( close(0) < 0 )
      aplc_error("spawnm: pipe (cmd in 0) close failed");
    if ( dup(pipeout[0]) < 0 ) 
      aplc_error("spawnm: pipeout dup failed");
    /* we may now read 0 and get pipeout[0] */
    if ( close(1) < 0 )
      aplc_error("spawnm: pipe (cmd out 1) close failed");
    if ( dup(pipeback[1]) < 0 )
      aplc_error("spawnm: pipeback dup failed");
    /* we may now write 1 and go to  pipeback[1] */
    /* close useless files */
    if ( (  close(pipeout[0]) < 0 )
	 ||(  close(pipeout[1]) < 0 )
	 ||(  close(pipeback[0])< 0 )
	 ||(  close(pipeback[1])< 0 ) ) 
      aplc_error("spawnm: pipe cmd close failed");
#if SPAWNDB >0
    fprintf(aplcerr, "[spawnm:cmd] executing %s\n", cmd);
#endif
    if ( (cmd = APLC_CMALLOC((1 + aplc_vsize(right->rank, right->shape)))) )
      aplc_cp2str(cmd, right);
    else
      aplc_error("spawnm: malloc error (right)");
    i = system(cmd);
    aplc_free(cmd);
    exit(1);
  }  else {
    /* caller process */
#if SPAWNDB >0
    fprintf(aplcerr, "[spawnm:cmd] pid %d\n", fkpidc);
#endif
  }
#if SPAWNDB >0
  fprintf(aplcout,"[spawnm] main flow ...\n");
#endif
  /* close useless files */
  if ( (  close(pipeout[0]) < 0 ) /* note we now keep pipeout[1] for writing */
       ||(  close(pipeback[1])< 0 ) ) 
    aplc_error("[spawnm]: pipe read close failed");
  /* set blocking/non-blocking 
     can be done with .bxfcntl */

  /* now just return pipe file descriptors :	*/
  /* write to  cmd[stdin]  : pipeout[1]  : res[1]	*/
  /* read from cmd[stdout] : pipeback[0] : res[2]	*/
  res->type = APLC_INT;
  res->rank = 1;
  res->shape =  aplc_dsval(2);
  aplc_vectalloc(&res->value, 2, APLC_INT);
  res->value.ip[0] = pipeout[1];
  res->value.ip[1] = pipeback[0];
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  res->size = aplc_vsize(res->rank, res->shape);
  return;
}


/* ------------------------------------------------------- */
#if 0

/* define this to 
   1 monadic
   2 dyadic */
#define SPAWND 2

/* old version with both dyadic and monadic code */
extern void
aplc_spawn(struct trs_struct * res, struct trs_struct * left, 
	   struct trs_struct *right) 
{
  char *cmd;
  int i;
  int rsize;
  /* shouldn't vsize return an :  unsigned int or long  ?  */ 
  int   fkpidc = 0; 
  /* for monadic version */
  /*  int pipeout[2], pipeback[2]; */
  /* extra for dyadic version */
  int SelVsize, Nfd, Npipe, PipeN, Flags;
  char * SelCvec; 
  char  Cnum[3];
  int Pipes[2 * MAXPIPES];	/* these are the fds returned by pipe(), we only use half */ 
  int Fd[MAXPIPES];   		/* these are the fds as seen by the spawned program */ 


  /* default file descriptor selection control vector; 11 defined, could have more : */
  SelCvec = "00ib01ob02ob03ib04ob05ib06ob07ib08ob09ib10ob";

  /* check right (command) argument */
  /*  this is handled in trs.c, leaf.c
      if (right->type != APLC_CHAR)
      aplc_error("[spawn]: command: character argument please ");
 */
  if (right->rank == 0)
    rsize = 1;
  else {
    rsize = aplc_vsize(right->rank, right->shape);
  }

#if 2==SPAWND /* dyadic */
  /* check left (selection) argument */
  switch (left->type) {
  default:
    aplc_error("[spawn]: bad selection type");
    break;
  case APLC_BOOL :
  case APLC_INT :
    if (left->rank != 0) {
      if (! ((left->rank == 1) && (left->shape[0] == 1))  )
	aplc_error("[spawn]: bad selection length");
    }
    else {
      if ( (Nfd = * left->value.ip) > (MAXPIPES) )
	aplc_error("[spawn]: selection: fewer, or use character mode please ");
      /* SelCvec[4*Nfd] = '\0'; */
    }
    break;
  case APLC_CHAR : 
    SelVsize = aplc_vsize(left->rank, left->shape);
    Nfd = SelVsize / 4;
    if ( Nfd > (MAXPIPES) )
      aplc_error("[spawn]: selection: fewer pipes please (or re-compile for more) ");
    if (SelVsize != 4 * Nfd)
      aplc_error("[spawn]: selection: wrong nomber of characters");
    SelCvec = left->value.cp; 
    if ( SelCvec = APLC_CMALLOC(1 + SelVsize ) )
      aplc_cp2str(SelCvec, left);
    else
      aplc_error("spawn: malloc error (left)");
    break;
  }

  /*V	fprintf(aplcerr, "[spawn] Nfd: %d\n", Nfd);   */
  /*V	fprintf(aplcerr, "[spawn] SelCvec: %s\n", SelCvec);   */

#endif /* dyadic */

  /* this works fine for 1 in, 1 out, but we may need more */
#if 1==SPAWND
  /*  create pipes  */
  if( pipe(pipeout) < 0) {
    pipeout[0] = pipeout[1] = -1;	
    aplc_error("spawn: pipeout create failed");
  }
  if( pipe(pipeback) < 0) {
    pipeback[0] = pipeback[1] = -1;	
    aplc_error("spawn: pipeback create failed");
  }
#endif /* monadic */

#if 2==SPAWND /* dyadic */
  /*  create pipes  */
  Npipe = 0;
  while ( Npipe < Nfd ) {
    if( pipe(& Pipes[2 * Npipe]) < 0) {
      /* we get 2 file descriptors at each call, can only use 1 */ 
      Pipes[2 * Npipe] = Pipes[1 + (2 * Npipe)] = -1;	
      aplc_error("[spawn]: pipe create failed");
    }
    /*V	fprintf(aplcerr, "[spawn:pipe] opening fds: %d %d \n", Pipes[2 * Npipe], Pipes[1 + (2 * Npipe)] );  */
    Npipe++;
  }
#endif /* dyadic */

  /*  set-up command execution process	*/
  cmd = APLC_CMALLOC(1 + aplc_vsize(right->rank, right->shape));
  aplc_cp2str(cmd, right);
#if 0
  while( ( fkpidc =  fork() ) < 0) {
    /* NOT vfork - it closes parent files */
    /* fprintf(aplcout,"[spawn] command forking \n"); 
       sleep(1); */
    ;
  } 
#endif
  if( fkpidc == 0) {
    /* command process */
#if SPAWNDB >0
    fprintf(aplcout,"[spawn] (cmd) setup\n");
#endif

    /* this works fine for 1 in, 1 out, but we may need more */
#if 1==SPAWND
    /* dup file descriptore */
    if ( close(0) < 0 )
      aplc_error("spawn: pipe (cmd in 0) close failed");
    if ( dup(pipeout[0]) < 0 ) 
      aplc_error("spawn: pipeout dup failed");
    /* we may now read 0 and get pipeout[0] */
    if ( close(1) < 0 )
      aplc_error("spawn: pipe (cmd out 1) close failed");
    if ( dup(pipeback[1]) < 0 )
      aplc_error("spawn: pipeback dup failed");
    /* we may now write 1 and go to  pipeback[1] */
    /* close useless files */
    if ( (  close(pipeout[0]) < 0 )
	 ||(  close(pipeout[1]) < 0 )
	 ||(  close(pipeback[0])< 0 )
	 ||(  close(pipeback[1])< 0 ) ) 
      aplc_error("spawn: pipe cmd close failed");
#endif /* monadic */

#if 2==SPAWND /* dyadic */
    /* dup file descriptors, close useless files */
    Npipe = 0;
    while ( Npipe < Nfd ) {
      Cnum[0] = SelCvec[4 * Npipe];
      Cnum[1] = SelCvec[1 + (4 * Npipe)];
      Cnum[2] = '\0'; 
      PipeN = atoi(Cnum);
      /*V fprintf(aplcerr, "[spawn:cmd] for fds: %s \n", Cnum );  */
      /*V fprintf(aplcerr, "[spawn:cmd] for fds: %d \n", PipeN );  */
      if ( SelCvec[2 + (4 * Npipe)] == 'i' ) {
	/* we wish to make this input for the spawned process */
	/* dup pipe file descriptor */
	/*V	fprintf(aplcerr, "[spawn:cmd] making fd %d a duplicate of fd %d for input to cmd \n", PipeN, Pipes[2 * Npipe] );  */
	(void) close(PipeN); /* we ignore errors, as some may well be closed already */
	if ( (Fd[Npipe]  = fcntl(Pipes[2 * Npipe], F_DUPFD, PipeN) )  < 0)
	  aplc_syserr("[spawn]: dup (i) failed");
	/* close useless file */
	if ( close(Pipes[1 + (2 * Npipe)]) < 0 )
	  fprintf(aplcerr, "[spawn] close pipe (s:i) failed \n");
      } else {
	/* we wish to make this output for the spawned process */
	/* dup pipe file descriptor */
	/*V	fprintf(aplcerr, "[spawn:cmd] making fd %d a duplicate of fd %d for output from cmd \n", PipeN, Pipes[1 + (2 * Npipe)]); */
	close(PipeN); /* we ignore errors, as some may well be closed already */
	if ( (Fd[Npipe]  = fcntl(Pipes[1 + (2 * Npipe)], F_DUPFD, PipeN) )  < 0)
	  aplc_syserr("[spawn]: dup (o) failed");
	/* close useless file */
	if ( close(Pipes[2 * Npipe]) < 0 )
	  fprintf(aplcerr, "[spawn] close pipe (s:o) failed \n");
      }
      Npipe++;
    }
#endif /* dyadic */

    i = system(cmd);
    aplc_free(cmd);
#if 0	/* no: we may just have killed it deliberately, die quietly */
    if (0 != i) { 
      aplc_syserr("[spawn:sys]: failed");
      /* fprintf(aplcerr, "[spawn:sys] error %d\n", i) */;
      /* aplc_error("[spawn]: system unavailable"); */
    } 
#endif
    exit(1);
  }  else {
    /* caller process */
#if SPAWNDB >0
    fprintf(aplcerr, "[spawn:cmd] pid %d\n", fkpidc);
#endif
  }
#if SPAWNDB >0
  fprintf(aplcout,"[spawn] main flow ...\n");
#endif
  /* this works fine for 1 in, 1 out, but we may need more */
#if 1==SPAWND
  /* close useless files */
  if ( (  close(pipeout[0]) < 0 )	/* note we now keep pipeout[1] for writing */
       ||(  close(pipeback[1])< 0 ) ) 
    aplc_error("[spawn]: pipe read close failed");
  /* make the useful ones non-blocking, or we just have a poor .bxpipe */
  /* set blocking/non-blocking */
  /* no, more versatile if done with .bxfcntl */
  /*
    if (( Flags = fcntl(pipeout[1], F_GETFL,0)) < 0)
    aplc_error("[spawn:write]: fcntl get failed");
    if (( fcntl(pipeout[1],F_SETFL, (long) Flags | O_NDELAY)) < 0)
    aplc_error("[spawn:write]: fcntl set failed");

    if (( Flags = fcntl(pipeback[0], F_GETFL,0)) < 0)
    aplc_error("[spawn:read]: fcntl get failed");
    if (( fcntl(pipeback[0],F_SETFL, (long) Flags | O_NDELAY))  < 0)
    aplc_error("[spawn:read]: fcntl set failed");
 */

  /* now just return pipe file descriptors :	*/
  /* write to  cmd[stdin]  : pipeout[1]  : res[1]	*/
  /* read from cmd[stdout] : pipeback[0] : res[2]	*/
#endif /* monadic */

#if 2==SPAWND /* dyadic */
  /* set blocking/non-blocking */
  /* close useless files */
  /* return wanted fds */
  aplc_vectalloc(&res->value, Nfd, APLC_INT);
  Npipe = 0;
  while ( Npipe < Nfd ) {
    if ( SelCvec[2 + (4 * Npipe)] == 'i' ) {
      /* we wish to make this input for the spawned process */
      if ( SelCvec[3 + (4 * Npipe)] == 'n' ) {
	/* set non-blocking */
	/*V fprintf(aplcerr, "[spawn:read] making fd: %d non-blocking \n", Pipes[1 + (2 * Npipe)] );  */
	if (( Flags = fcntl(Pipes[1 + (2 * Npipe)], F_GETFL,0)) < 0)
	  aplc_error("[spawn:read]: fcntl get failed");
	if (( fcntl(Pipes[1 + (2 * Npipe)],F_SETFL, (long) Flags | O_NDELAY)) < 0)
	  aplc_error("[spawn:read]: fcntl set failed");
      } else {
	/*V fprintf(aplcerr, "[spawn:read] making fd: %d blocking \n", Pipes[1 + (2 * Npipe)] );  */
	;
      }
      /* close useless file */
      /*V fprintf(aplcerr, "[spawn:read] closing fd: %d \n", Pipes[2 * Npipe] );  */
      if ( close(Pipes[2 * Npipe]) < 0 )
	fprintf(aplcerr, "[spawn] close pipe (c:o) failed \n");
      /* return wanted fd */
      res->value.ip[Npipe] = Pipes[1 + (2 * Npipe)];
    } else {
      /* we wish to make this output for the spawned process */
      if ( SelCvec[3 + (4 * Npipe)] == 'n' ) {
	/* set non-blocking */
	/*V fprintf(aplcerr, "[spawn:read] making fd: %d non-blocking \n", Pipes[2 * Npipe] );  */
	if (( Flags = fcntl(Pipes[2 * Npipe], F_GETFL,0)) < 0)
	  aplc_error("[spawn:read]: fcntl get failed");
	if (( fcntl(Pipes[2 * Npipe],F_SETFL, (long) Flags | O_NDELAY)) < 0)
	  aplc_error("[spawn:read]: fcntl set failed");
      } else {
	/*V fprintf(aplcerr, "[spawn:read] making fd: %d blocking \n", Pipes[2 * Npipe] );  */
	;
      }
      /* close useless file */
      /*V fprintf(aplcerr, "[spawn:read] closing fd: %d \n", Pipes[1 + (2 * Npipe)] );  */
      if ( close(Pipes[1 + (2 * Npipe)]) < 0 )
	fprintf(aplcerr, "[spawn] close pipe (c:i) failed \n");
      /* return wanted fd */
      res->value.ip[Npipe] = Pipes[2 * Npipe];
    }
    Npipe++;
  }
#endif /* dyadic */

  res->type = APLC_INT;
  if (Npipe == 1) {
    res->rank = 0;
    res->shape = aplc_ivone;
  }  else {
    res->rank = 1;
    res->shape =  aplc_dsval(Nfd);
  }
  return;
}
#endif /* #if 0 */

/* ------------------------------------------------------- */
/* string search function -
   find all locations of copies of right string in left
*/
extern void
aplc_strsrch(struct trs_struct * res,
	     struct trs_struct * left, struct trs_struct * right)
{
  union mp_struct mptemp, ltext, rstring;
  int i, j, k, lsize, rsize;

  if (left->rank == 0)
    lsize = 1;
  else
    lsize = left->shape[0];

  if (right->rank == 0)
    rsize = 1;
  else
    rsize = right->shape[0];

  res->type = APLC_INT;
  res->rank = 1;
  res->shape = aplc_dsval(lsize);

  aplc_vectalloc(&mptemp, lsize, APLC_INT);
  res->value.ip = mptemp.ip;

  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  res->size = aplc_vsize(res->rank, res->shape);

  ltext = left->value;
  rstring = right->value;
  for (i = 0; i < lsize; i++) {
    if (ltext.cp[i] == rstring.cp[0]) {
      /* found a possible match */
      if (rsize == 1)
	res->value.ip[i] = 1;	     /* scalar right */
      else {
	/* look for whole right string at point i */
	j = i;
	k = 0;
	while ((j < lsize) && (k < rsize)
	    && (ltext.cp[j] == rstring.cp[k])) {
	  j++;
	  k++;
	}
	/* now see if we found it */
	if (k == rsize)
	  res->value.ip[i] = 1;
	else
	  res->value.ip[i] = 0;
      }
    } else
      res->value.ip[i] = 0;
  }
}

/* ------------------------------------------------------- */
/* type - type of argument
   for now just return a scalar (later nest/vector?)
*/
extern void
aplc_type(struct trs_struct * res, struct trs_struct * right)
{
  proint(res, &(right->type));
}


/* ------------------------------------------------------ */
/* ------------------------------------------------------ */
/* sws
   aplc_print_trs
   - print a trs structure
   - for debugging 
   */
void
aplc_print_trs(struct trs_struct *res) 
{
  int i, s;

  printf("type %d, rank %d, size %d, alloc %d\n", 
	 res->type, res->rank, res->size, res->alloc_ind);
  printf("shape ");
  if (res->rank != 0) {
    for (i=0; i<res->rank; i++)
      printf(" %d", res->shape[i]);
    printf("\n");
  }
  else
    printf("(scalar)\n");
  printf("values {");
  s = aplc_vsize(res->rank, res->shape);
  for (i=0; i<s; i++)
    switch(res->type) {
    default:
      printf(" ?");
      break;
    case APLC_BOOL:
    case APLC_INT:
      printf(" %d", res->value.ip[i]);
      break;
    case APLC_REAL:
      printf(" %g", res->value.rp[i]);
      break;
    case APLC_CHAR:
      printf(" %c", res->value.cp[i]);
      break;
    case APLC_BOXED:
      printf(" {");
      aplc_print_trs( &res->value.trsp[i] );
      printf("} ");
      break;
    }
  printf("}\n");
}

/* end of runio.c */
