/*
	APL Compiler

	Code Generation routines for misc. functions
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever


 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/
#include "parse.h"
#include "y_tab.h"
#include "gen.h"
#include <stdio.h>


#define SDEBUG 0

/* local declarations */
static struct codetree *subgen(struct node *, int);

/*
	geniota - generate code for monadic iota operator

	ptr1 - mp for shape
	ptr2 - value if sequential
	ptr3 - nu

	sws - the right must be an integer scalar, so why allocate
	space for it - just wastes time

*/
void
geniota(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    if (!(node->n.info & SHAPEKNOWN)) {
      switchbox(RIGHT, SHAPE, 0);
      if ((RIGHT->n.info & HAVEVALUE) &&
	  ((RIGHT->c.values)->cop == deref)) {
	/* in this case we may as well just use the value at right */
	/* strip off deref */
	node->c.shape = (RIGHT->c.values)->c0.cleft;
      } else {
	/* here we might have calculations, so it's worth it to
	collect the right in case we need to re use it */
	/* sws use a res struct */
	printf("res%d.i = ", node->ptr1);
	ctgen(RIGHT->c.values);
	seminl();
	node->c.shape = gmon(coref, gicn(resptr, node->ptr1, APLC_INT));
      } 
    } if (node->n.info & SEQUENTIAL) 
      ieqtree(node->ptr2, gixorg());
    break;

  case COMBINE:
    break;

  case VALUE:
    if (node->n.info & SEQUENTIAL)
      node->c.values = gmon(postinc, gicn(coiptr, node->ptr2, 0));
    else
      node->c.values = gsfun(APLC_PLUS, gicn(coiptr, node->index, 0), gixorg());
    break;

  case FINISH:
    if (!(node->n.info & SHAPEKNOWN)) {
      switchbox(RIGHT, FINISH, 0);
    }
    break;
  }
}

/* save old version ... */
#if 0
void
geniota(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    if (!(node->n.info & SHAPEKNOWN)) {
      switchbox(RIGHT, SHAPE, 0);
      if ((RIGHT->n.info & HAVEVALUE) &&
	  ((RIGHT->c.values)->cop == deref)) {
	node->ptr3 = 0;
	/* strip off deref */
	node->c.shape = (RIGHT->c.values)->c0.cleft;
      } else {
	node->ptr3 = 1;
	smpalloc(node->ptr1);
	smpieqt(node->ptr1, RIGHT->c.values);
	node->c.shape = gicn(memptr, node->ptr1, APLC_INT);
      }
    }
    if (node->n.info & SEQUENTIAL)
      ieqtree(node->ptr2, gixorg());
    break;

  case COMBINE:
    break;

  case VALUE:
    if (node->n.info & SEQUENTIAL)
      node->c.values = gmon(postinc, gicn(coiptr, node->ptr2, 0));
    else
      node->c.values = gsfun(APLC_PLUS, gicn(coiptr, node->index, 0), gixorg());
    break;

  case FINISH:
    if (!(node->n.info & SHAPEKNOWN)) {
      switchbox(RIGHT, FINISH, 0);
      if (node->ptr3) {
#ifdef DEBUGFREE
	printf("/* -- iota finish */\n");
#endif
	mpfree(node->ptr1);
#ifdef DEBUGFREE
	printf("/* -- */\n");
#endif
      }
    }
    break;
  }
}
#endif /* old version */

/*
	genravel - generate code for ravel instruction

	ptr1 - memory pointer for shape
	ptr2 - integer value for getsize

*/
void
genravel(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    if (!(node->n.info & TYPEKNOWN))
      node->c.type = RIGHT->c.type;
    if (!(node->n.info & SHAPEKNOWN)) {
      smpalloc(node->ptr1);
      getsize(node->ptr2, RIGHT);
      setmptoi(node->ptr1, node->ptr2);
      node->c.shape = gicn(memptr, node->ptr1,
	  APLC_INT);
    }
    if (RIGHT->n.info & HAVEVALUE)
      node->c.values = RIGHT->c.values;
    break;

  case COMBINE:
    break;

  case VALUE:
    switchbox(RIGHT, VALUE, 0);
    node->c.values = RIGHT->c.values;
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    if (!(node->n.info & SHAPEKNOWN)) {
#ifdef DEBUGFREE
      printf("/* -- ravel finish */\n");
#endif
      mpfree(node->ptr1);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
  }
}

/*
	genroll - generate code for random operation

	ptr1 - result register for left hand side
	ptr2 - i value

*/
void
genroll(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 0, 1, 1);
    break;

  case COMBINE:
    break;

  case VALUE:
    switchbox(RIGHT, VALUE, 0);
    node->ptr1 = resinreg(RIGHT, node->ptr1);
    ieq(node->ptr2);
    printf("aplc_randint(res%d.i);\n", node->ptr1);
    node->c.values = gicn(coiptr, node->ptr2, APLC_INT);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    break;
  }
}

/*
	gendeal -
		generate code for deal operation

	ptr1 - mp for shape
	ptr2 - mp for values of deal
	ptr3 - register for results
	ptr4 - mp for shape (copy)
	ptr5 - mp for values (copy)

*/
void
gendeal(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    if (!(node->n.info & SHAPEKNOWN)) {
      smpalloc(node->ptr1);
      smpieqt(node->ptr1, LEFT->c.values);
      node->c.shape = gicn(memptr, node->ptr1, APLC_INT);
      mpeqmp(node->ptr4, node->ptr1);
    }
    /* allocate the space */
#if VDEBUG
    printf("/* [gendeal] vectalloc */\n");
#endif
    printf("aplc_vectalloc(&mp%d, ", node->ptr2);
    ctgen(LEFT->c.values);
    printf(", APLC_INT);\n");
    /* now generate the values */
    printf("aplc_deal(&mp%d, ", node->ptr2);
    ctgen(LEFT->c.values);
    commasp();
    ctgen(RIGHT->c.values);
    rpseminl();
    node->c.values = gicn(memptr, node->ptr2, APLC_INT);
    mpeqmp(node->ptr5, node->ptr2);
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr2, APLC_INT, node->ptr3);
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
#ifdef DEBUGFREE
    printf("/* -- deal finish */\n");
#endif
    if (!(node->n.info & SHAPEKNOWN)) 
      mpfree(node->ptr4);
    mpfree(node->ptr5);
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;
  }
}

/*
	gensub - generate code for subscripting operations

        LEFT[ RIGHT ]

*/
void
gensub(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    RIGHT->axis = LEFT;
    switchbox(RIGHT, SHAPE, 1);
    copychild(node, LEFT, 1, 0, 0);
    copychild(node, RIGHT, 0, 1, 1);
    break;

  case COMBINE:
    break;

  case VALUE:
    switchbox(RIGHT, VALUE, 1);
    ieqtree(LEFT->index, RIGHT->c.values);
    switchbox(LEFT, VALUE, 0);
    node->c.values = LEFT->c.values;
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    break;
  }
}

/*
  subgen 
  - generate the shape of the current position
*/
static struct codetree *
subgen(struct node * parent, int position)
{
  return(gmon(deref, gsfun(APLC_PLUS, parent->c.shape,
			   gicn(icnst, position, APLC_INT))));
}

/*
  gensemi - generate code for semicolon
            (this should be optimized a little more)

 ptr1 - position (set by parser)
 ptr2 - size of right hand side
 ptr3 - index of top (set by sub)
 ptr4 - rank
 ptr5 - shape
 ptr6 - result of children

*/
void
gensemi(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
  case SHAPE:
#if SDEBUG
    printf("/* [gensemi] shape */\n");
#endif
    adjdcls(node);
    if (LEFT != NILP) {
      LEFT->axis = node->axis;
      switchbox(LEFT, SHAPE, 0);
    }
    if (RIGHT->nodetype == EMPTSEMI)
      RIGHT->axis = node->axis;
    switchbox(RIGHT, SHAPE, 0);
    if (LEFT == NILP)
      copychild(node, RIGHT, 0, 1, 1);
    else if (!(node->n.info & SHAPEKNOWN)) {
#if SDEBUG
      printf("/* [gensemi] get shape */\n");
#endif
      rkeq(node, node->ptr4);
      printf("aplc_outershape(&mp%d, ", node->ptr5);
      lrnsrrns(LEFT, RIGHT);
      rpseminl();
      node->c.shape = gicn(memptr, node->ptr5, APLC_INT);
    }
    if (LEFT != NILP)
      getsize(node->ptr2, RIGHT);
    break;

  case COMBINE:
    break;

  case VALUE:
    if (LEFT == NILP) {
      switchbox(RIGHT, VALUE, 0);
      mkrktype(RIGHT, APLC_INT, node->ptr6);
      if (RIGHT->nodetype == EMPTSEMI)
	node->c.values = RIGHT->c.values;
      else
	node->c.values = gsfun(APLC_MINUS, RIGHT->c.values, gixorg());
    } else {
      if (!(RIGHT->n.info & NOINDEX))
	iopi(RIGHT->index, node->index, "%", node->ptr2);
      switchbox(RIGHT, VALUE, 0);
      mkrktype(RIGHT, APLC_INT, node->ptr6);
      if (!(LEFT->n.info & NOINDEX))
	iopi(LEFT->index, node->index, "/", node->ptr2);
      switchbox(LEFT, VALUE, 0);
      node->c.values = gsfun(APLC_PLUS,
			    gsfun(APLC_TIMES, LEFT->c.values,
				 subgen(node->axis, node->ptr1)),
			    RIGHT->c.values);
      if (RIGHT->nodetype == EMPTSEMI)
	;
      else
	node->c.values = gsfun(APLC_MINUS, node->c.values,
			      gixorg());
    }
    break;

  case FINISH:
    if (LEFT != NILP)
      switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    if (! ((LEFT == NILP) || (node->n.info & SHAPEKNOWN)) ) {
#ifdef DEBUGFREE
      printf("/* -- semi finish */\n");
#endif
      if (!(node->n.info & RANKKNOWN))
        mpfree_nots(node->ptr5, node->ptr4);
      else {
        /* rank is known, can test now */
	if (node->c.rank->c0.cindex)
	  mpfree(node->ptr5);
      }
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
  }
}

/*
	genempt - generate code for the empty semicolon position

	ptr4 - shape
*/
void
genempt(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    if (!(node->n.info & SHAPEKNOWN)) {
      smpalloc(node->ptr4);
      smpieqt(node->ptr4,
	  subgen(node->axis, node->ptr1));
      node->c.shape = gicn(memptr, node->ptr4, APLC_INT);
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    node->c.values = gicn(coiptr, node->index, APLC_INT);
    break;

  case FINISH:
    if (!(node->n.info & SHAPEKNOWN)) {
#ifdef DEBUGFREE
      printf("/* -- empty finish */\n");
#endif
      mpfree(node->ptr4);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/*
	gengo -
		generate code for unconditional goto

	ptr1 - size of right side
	ptr2 = result value
*/
void
gengo(struct node * node, enum pmodes mode, int top)
{
  struct codetree *savetree;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);

    /* sws 
       if right is of known size >0, then we don't need a run time
       check */
    if ( (RIGHT->n.info & RANKKNOWN) &&
	 (RIGHT->n.info & SHAPEKNOWN) &&
	 ksize(RIGHT) ) {
      if (!(RIGHT->n.info & NOINDEX))
	seticon(RIGHT->index, 0);
      switchbox(RIGHT, VALUE, 0);
      mkrktype(RIGHT, APLC_INT, node->ptr2);
      printf("stmtno = ");
      ctgen(RIGHT->c.values);
      seminl();
    } else {
      getsize(node->ptr1, RIGHT);
      printf("stmtno++;\n");	     /* jbww UKC 6/87 */
      printf("if (i%d > 0) {\n", node->ptr1);
      savetree = looprank;
      looprank = RIGHT->c.rank;
      if (!(RIGHT->n.info & NOINDEX))
	seticon(RIGHT->index, 0);
      switchbox(RIGHT, VALUE, 0);
      mkrktype(RIGHT, APLC_INT, node->ptr2);
      printf("stmtno = ");
      ctgen(RIGHT->c.values);
      seminl();
      /* printf("break;\n");            jbww UKC 6/87 */
      rbr();
      looprank = savetree;
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    printf("break;\n");		     /* jbww UKC 6/87 */
    break;
  }
}

/* end of misc.c */

