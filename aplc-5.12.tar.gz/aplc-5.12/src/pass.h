/* sws    pass.h 
          declarations for stuff in the pass group of code
	  Samuel W. Sirlin (sws)

	const.c
	pass.c
	iotree.c


 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_PASS_H
#define _APLC_PASS_H

/* iotree.c */
/*
  Test for flag to pipe intermediate results as integers rather than
  characters. For dos text file mode.

  The functions are used in: iotree.c, pass.c, psym.c

  This file just defines the old method. The new definitions may be 
  found in iotree.c
*/
#ifndef CHARINT
/* original versions of the output functions */
#define  fwriten  fwrite
#define  putcharn  putchar
#define  freadn  fread
#define  getcharn  getchar

#else
/* prototype for modified versions */
extern void fwriten(char *, int, int, FILE *);
extern void freadn(char *, int, int, FILE *);
extern void putcharn(char);
extern int getcharn(void);

#endif

/* iotree.c */ 
extern void error(char *c);
void putname(char *c);
void putheader(struct headnode *head);
char *gets_safe(char *c);
char *getfname(char *c);

extern void gethead(struct headnode * head, 
		    char *opname, char *fname, char *rfname, 
		    char *asvar, char *parm1, char *parm2);

void putsyms(struct symnode *syms);
struct symnode *getsyms(void);
extern void frecode(struct statenode * code);
extern void fresyms(struct symnode * syms);

void put_lcon(void);
void get_lcon(void);

void putconsts(void);
void putcode(struct statenode *code);

struct statenode *rdcode(void);
void putnode(struct node *);
struct node *innode(void);
void frenode(struct node *);
extern void writecode(int top, struct headnode * head, 
		      struct symnode * syms, struct statenode * code);
extern void rdconsts(void);


/* expected in the particular application */
void doprog(int type, struct headnode * head, struct symnode * syms, 
	    struct statenode * code);
void glbvar(char *name);
void passinit(int verbose);


/* some global variables */

/* iotree.c */
extern char *funname;
extern int stmtno;
extern char *passname;/* name of current program */

/* pass.c */
extern int indxorgin;/* may be DEFAULTINDEX */
extern int get_indexorg(void);/* the current origin */


#endif
/* end of pass.h */
