/* runio_f.c

 APL Compiler - Run Time System

 - file routines

	Samuel W.  Sirlin (sws)
        J.B.W.Webber@ukc.ac.uk 

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

/* ------------------------------------------------------------ */
#include "aplc.h"
#include "run.h"

/* sws  for file io */
#include <stdio.h>
#include <stdlib.h>

#if HAVE_STRING_H
/* sws  for trs2str */
#include <string.h>
#endif

#include <sys/types.h>

#if HAVE_FCNTL_H
/* sws for open */
#include <fcntl.h>
#endif

#if TIME_WITH_SYS_TIME 
#include <sys/time.h>
#include <time.h>
#else
#if HAVE_SYS_TIME_H
#include <sys/time.h>
#else
#include <time.h>
#endif 
#endif

#if HAVE_SYS_STAT_H 
/* sws  to get file sizes */
#include <sys/stat.h>
#endif

#if HAVE_UNISTD_H
/* jbww to get dup, pipe, fork; sws to get usleep for fbsd */
#include <unistd.h>
#endif

#if HAVE_TERMIOS_H 
/* jbww to get file control */
#include <termios.h>
#endif

/* switch for printing debug information */ 
#define DEBUGIO 0

/* ------------------------------------------------------------ */
/* special mp_struct for type conversion  */
typedef union {
  double *rp; /* real pointers */
  float  *rfp;
  int	 *ip; /* integer pointers */
  short  *isp;
  long   *ilp;
  unsigned int	 *iup;
  unsigned short *iusp;
  unsigned long  *iulp;
  char	 *cp;	/* character pointers */
} sp_mp_t;


/* ------------------------------------------------------------ */
static void slicewait( long Slices );
static void cpNchars(char *out, int n, char *in, int size);

static void aplc_fmod(struct trs_struct * res,
      struct trs_struct * left, struct trs_struct * right, char *mode);

static int iwidth(int size, int sign);
static int type_iget(int size, int sign, sp_mp_t *in, int k);
static int fwidth(int size);
static double fget(int size, sp_mp_t *in, int k);
static int aplc_type_width(int type);
static long type_iset(int in, int size, int sign );

static void aplc_wrfd_type(struct trs_struct *res, 
			   struct trs_struct *left, 
			   struct trs_struct *right);

extern void aplc_rdfdt(struct trs_struct *res, struct trs_struct * right);
extern void aplc_rdfdt_type(struct trs_struct *res, struct trs_struct *right);

/* ------------------------------------------------------------ */
/* default file name length */
#define FNAMELEN 50

static char name_space[FNAMELEN];
static char *name;

/* define a mask vector to get first 8 bits - the bits in a char */
static int char_mask[]={01, 02, 04, 010, 020, 040, 0100, 0200};

/* ------------------------------------------------------------ */
/* delay for N clock ticks : allow other processes to run for N time slices
                           : ClK_TCK is in time.h, limits.h 			
 J.B.W.Webber@ukc.ac.uk  99_3_5 */  

static void
slicewait( long Slices )
{
#if HAVE_NANOSLEEP
  /* #if defined(DECALPHA) || defined(SGI) || defined(LINUX)*/
  /* for machines that have nanosleep, timespec, CLK_TCK	*/
  /* sun5 could be here, but then have to -lposix4 */ 
  struct timespec treq, trem;
  long sec, nsec;
  double tremain;

#ifdef LINUX
  treq.tv_sec = (sec = Slices / (long) CLK_TCK);
#else
  treq.tv_sec = (time_t) (sec = Slices / (long) CLK_TCK);
#endif /* linux check */
  treq.tv_nsec = nsec = (long) floor( NS_per_SEC * ((double) (Slices - CLK_TCK * sec)) / (double) CLK_TCK);
  /*
    fprintf(aplcerr, "\n[bxdl] sec : %ld \n", sec );
    fprintf(aplcerr, "\n[bxdl] nsec : %ld \n", nsec ); */

  if ( nanosleep( &treq, &trem ) <  0 ) {
    tremain = ((double) trem.tv_sec) + (((double)  trem.tv_nsec)/NS_per_SEC); /* sec */
    fprintf(aplcerr, "\n[bxdl] sleep cut short \n");
    fprintf(aplcerr, "[bxdl] time remaining: %f sec. \n", tremain);
  }
#elif HAVE_USLEEP 
#if HAVE_SYSCONF
  /* for machines that have usleep, sysconf(_SC_CLK_TCK) */
  unsigned int usec;

  usec = (Slices/(long) sysconf(_SC_CLK_TCK))/MS_per_SEC;
  usleep(usec);
#else /* no sysconf */
  /*#elif defined(SUNOS5) */
  /* for machines that have usleep, CLK_TCK */
  unsigned int usec;

  usec = (Slices / (long) CLK_TCK)/MS_per_SEC;
  usleep(usec);
#endif /* sysconf check */
#endif /* machine switch for sleeps */
  return;
}

/* ------------------------------------------------------------ */
/* copy at most n chars into a string
   ignore ws 
   pad with \0
*/
static void
cpNchars(char *out, int n, char *in, int size)
{
  int i, j;

  for (i=0, j=0; (i< size) && (j<n); i++)
    if (in[i] != ' ') {
      out[j++] = in[i];
    }
  while (j<n)
    out[j++] = '\0';
  out[n] = '\0';
  return;
}

/* ------------------------------------------------------------ */
/*
    open a file
	FileDescriptor .is Modes #open File
	(char) Modes, File
	Modes: any reasonable combination of :
		r - read
		c - create (+ write, but don't overwrite)
		w - write (overwrite if exists, create otherwise)
		a - append to end of existing file, create otherwise
	       cw = c
	       ca = a
		n - non-blocking read/write (ttys, pipes),
		    affects all subsequent operations.
	(with none of these it defaults to read only)
   or
        Modes an int, char File
   or
	FileDescriptor .is '' #open N
	(int) N : open N pipes (get 2 fds each pipe)
   returns file descriptor for successfully opened file,
	else -1 if failed.
	J.B.W.Webber@ukc.ac.uk  99_3_9,15
 */
extern void
aplc_open(struct trs_struct * res,
	  struct trs_struct * left, struct trs_struct * right)
{
  char Modes[5];
  int fd, Mode, ModeRW, ModeCare, ModeBlock, Perms;
  int rsize;
  /*char name_space[FNAMELEN];
  char *name;*/
  int izilde;
  int Nfd, Npipe;
  int name_malloc = 0;
  /* struct termios  termios_p;*/

  switch (right->type) {
  default:
    aplc_error("[open]: bad file type");
    break;
  case APLC_BOOL :
  case APLC_INT :
    /* make pipes and return their file decriptors (2 for each pipe) */
    Nfd = * right->value.ip;
    Nfd = 2 * Nfd;
    /*V	fprintf(aplcout,"[open:pipe]: requesting %d file descriptors \n", Nfd );  */
    aplc_vectalloc(&res->value, Nfd, APLC_INT);
    Npipe = 0;
    while ( Npipe < Nfd /2 ) {
      /* make a pipe and return its file decriptors */
      if ( pipe( & res->value.ip[2 * Npipe] ) < 0 ) {
	res->value.ip[2 * Npipe] = -1;
	res->value.ip[1 + (2 * Npipe)] = -1;
	aplc_error("[open:pipe]: open failed");
      }
      Npipe++;
    }
    res->type = APLC_INT;
    res->rank = 1;
    res->shape =  aplc_dsval(Nfd);
    res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
    res->size = aplc_vsize(res->rank, res->shape);
    return;
    break;
  case APLC_CHAR :
    /* open files and return their file descriptors */
    /* we ignore cases of stdin, stdout, as we know their fd */

    name = name_space;/* default size */
    rsize = aplc_trs2str_sp(&name, FNAMELEN, &izilde, &name_malloc, 1, right);
    if (!izilde) {
      Perms = 0664;  /* octal : rw, rw, r */

      switch(left->type) {
      default:
	Mode = 0;
	aplc_error("read: bad file name type");
	break;
      case APLC_CHAR:
	/*    Modes = left->value.cp; */
	/*fprintf(stderr,"[open] size %d\n", left->size);*/
	cpNchars(Modes, 4, left->value.cp, left->size); 
	/*fprintf(stderr,"[open] modes %s\n", Modes);*/
	ModeRW    = O_RDWR;
	ModeCare  = 0;
	ModeBlock = 0;
	if ( ( strchr (Modes , 'r')) == NULL )
	  ModeRW =   O_WRONLY;
	if ( (strchr (Modes, 'w') == NULL) &&
	     (strchr (Modes, 'c') == NULL) &&
	     (strchr (Modes, 'a') == NULL))
	  ModeRW =   O_RDONLY;
	if ( ( strchr (Modes , 'w')) != NULL)
	  ModeCare =   O_CREAT | O_TRUNC ; /* this may be over ridden by : */
	if ( ( strchr (Modes, 'c')) != NULL) 
	  ModeCare =  O_CREAT | O_EXCL ; /* this may be over ridden by : */
	if ( ( strchr (Modes, 'a')) != NULL) 
	  ModeCare =   O_CREAT | O_APPEND ;
	if ( ( strchr (Modes, 'n')) != NULL) 
	  ModeBlock =   O_NDELAY ;
	Mode = ModeRW | ModeCare | ModeBlock ;
	break;
      case APLC_BOOL:
      case APLC_INT:
	if (left->size < 1)
	  aplc_error("open: bad left arg");
	Mode = left->value.ip[0];
	break;
      }
      /*fprintf(stderr,"[open] %s, %o, %o\n", name, Mode, Perms);*/
      fd = open(name, Mode, Perms);
      /* fprintf(stderr,"[open] fd = %d\n", fd);*/
    }  else  {
      /* is stdin/stdout - but these should be open already ! */
      fd = 0;
    }
#if 0
    fprintf(aplcout,"[open file]: open file [%s] with mode O%o and permissions O%o \n",  name, Mode , Perms);
    fprintf(aplcout,"[open file]: file descriptor %d \n", fd );
#endif
    res->type = APLC_INT;
    res->rank = 0;
    res->shape = aplc_dsval(1);
    res->value.ip = aplc_dsval(fd);
    res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
    res->size = aplc_vsize(res->rank, res->shape);
    /* free space */
    if (name_malloc)
      aplc_free(name);
    return;
    break;
  }
}

/* monadic version of open */
extern void
aplc_mopen(struct trs_struct * res, struct trs_struct * right)
{
  struct trs_struct ltmp;
  
  aplc_czilde(&ltmp);
  aplc_open(res, &ltmp, right);
}

/* aplc_rdfd

 Read a file or piped text into an aplc variable, 
 given a file descriptor. Returns char data. 

 set block/nonblock with open now

 J.B.W.Webber@ukc.ac.uk 99_31_04 
 */
extern void
aplc_rdfd(struct trs_struct * res, int fd )
{
  int nask, nread, ij;
  int Stat, Alloc;
  char  *block2;
  unsigned int count;
  struct stat stbuf;
  long size2;
  long GetSize, WaitSize;
  int IsTty, IsFile, IsFifo;
  long StatBlkSize, StatBlks;
  int nlink;
  static long INTSIZE = (long) INT_MAX; /* max that a signed int can hold */

#if DEBUGIO
  fprintf(aplcout,"[read fd] (start) \n");  
#endif

  if ( (IsTty =  isatty(fd)) )
    fprintf(aplcout,"[aplc_rdfd]: fd %d is a tty, %s\n", fd, ttyname(fd));  
  /* use fstat to determine what type of device it is, and how much space to allocate  */
  if ( fstat(fd, &stbuf) < 0 )
    aplc_error("[aplc_rdfd]: read fstat failed");
  /* all is well, get length etc. : */
  nlink = (int) stbuf.st_nlink;
#if DEBUGIO
  fprintf(aplcout,"[read fd] %d links to file \n", nlink);  
#endif
  /* this should give us the number of bytes waiting to be read */
  GetSize = stbuf.st_size;
#if DEBUGIO
  fprintf(aplcout,"[read fd] %ld bytes in file \n", GetSize);  
#endif
  /* this should give us the ideal pipe transfer block size */
  StatBlkSize = stbuf.st_blksize;
#if DEBUGIO
  fprintf(aplcout,"[read fd] blocksize %ld \n", StatBlkSize);  
#endif

  /* note StatBlks are in terms of 512 bytes (usually!) */
#ifdef DJPC 
  /* what should this really be ? */
  StatBlks = 2;
#else
  StatBlks = stbuf.st_blocks;
#endif
#if DEBUGIO
  fprintf(aplcout,"[read fd] %ld blocks \n", StatBlks);  
#endif
  if ( S_ISCHR(stbuf.st_mode) ) {
    GetSize = (long) APLC_IBUFSIZE;/* run.h */
#if DEBUGIO
    fprintf(aplcout,"[read fd] file is a char device \n");  
#endif
  }
  if ( (IsFile = S_ISREG(stbuf.st_mode) ) ) {
    /*	GetSize = GetSize ; file size in 1 go ! */
#if DEBUGIO
    fprintf(aplcout,"[read fd] file is a regular file \n");  
#endif
  }
  if ( S_ISDIR(stbuf.st_mode) ) {
    fprintf(aplcout,"[read fd] file is a directory \n");  
    aplc_error("read fd: read failed");
  }
  if ( ( IsFifo =  S_ISFIFO(stbuf.st_mode) ) ) {
    GetSize = (long) StatBlkSize;	
#if DEBUGIO
    fprintf(aplcout,"[read fd] file is a fifo \n");  
#endif
  }
  nread = 0; /* ensure initialization */
  block2 = 0;
  size2 = 0;
  count = 0;  
  Alloc = 0;
  do {
    slicewait((long)1); 
    /* no point in looping without waiting for other processes */ 
    /* once started, seems to always have 4k data waiting (till the end) */
    switch ( Stat = fstat(fd, &stbuf) ) {
    default:
      fprintf(aplcerr,"[read fd] (default), SHOULD NOT HAPPEN\n" );  
    case -1: 
      /* read fd is closed, tidy up */
#if DEBUGIO
      fprintf(aplcout,"[read fd] fd closed \n"); 
#endif
      break;
    case  0: 
      /* all is well, get length : */
      /* this should give us the number of bytes waiting to be read	     */
      WaitSize = stbuf.st_size;
#if DEBUGIO
      fprintf(aplcout,"[read fd] %ld bytes in file \n", WaitSize);  
#endif

#if 0
      if (block == 'n' && WaitSize == 0)
	;   /* if non-blocking, just return if no data waiting */
      else
#endif
	{
	  /*
	    i = size2 > BUFSIZ ? BUFSIZ : size2;
	    i = size2 > (long)BUFSIZ ? BUFSIZ : (int)size2;
	    i = (int) size2 > INTSIZE ? INTSIZE : size2;
	  */
	  /* if fstat gave 0, we may have to wait, so ask for GetSize anyway 
	     and read will block till data is ready or ends, or there is an error */
	  GetSize = (WaitSize == 0) ? GetSize : WaitSize ;
	  /*GetSize = (WaitSize == 0) ? 1 : WaitSize ;*/

	  /* fstat gives us a long, but vectalloc is only int */
	  nask = (int) GetSize > INTSIZE ? INTSIZE : GetSize;
#if DEBUGIO
	  fprintf(aplcout,"[read fd]  we will ask for %d bytes \n", nask );   
#endif
	  /* allocate space  */ 
	  /* have we allocated any space yet ? */
	  if (count == 0) {
	    /* we have not written anything yet, allocate i bytes */
	    Alloc = nask;
#if DEBUGIO
	    fprintf(aplcout,"[read fd] allocate %d bytes \n", nask);  
#endif
	    aplc_vectalloc(&res->value, Alloc, APLC_CHAR);
	  } else {
	    /* we just added nread bytes, so allocate at least an extra j bytes of space 
	       asked for nask, so allocate for it; else we may have trouble */
	    ij = max(nask, nread);
	    Alloc = count + ij; 
#if DEBUGIO
	    fprintf(aplcout,"[read fd] re-allocate for extra %d bytes; total %d\n", ij,Alloc); 
#endif
	    aplc_vectrealloc(&res->value, Alloc, APLC_CHAR);
	  }
	  /* read data */
	  switch (nread = read(fd, (unsigned int) count + res-> value.cp, 
			       (size_t) nask ) ) {
	  case -1: 
	    /* read failed */
#if DEBUGIO
	    fprintf(aplcout,"[read fd] read failed (-1): (pipe empty)\n");
#endif
	    /* aplc_error("read fd: read failed"); */
	    break;
	  case 0: 
	    /* out of data, tidy up */
#if DEBUGIO
	    fprintf(aplcout,"[read fd] read %d chars: out of data \n", nread);  
#endif
	    break;
	  default: 
	    /* read nread bytes */
#if 0
	    /* no, we may have done an lseek : */
	    if (nread != nask && IsFile)
	      fprintf(aplcout,"[read fd] failed, should have %d chars, have %d \n", nask, nread) ;  
#endif
	    block2 += nread;
	    size2 += nread;
	    count += nread;
#if DEBUGIO
	    fprintf(aplcout,"[read fd] read %d chars, count %d\n", nread, count);  
#endif
	    break;
	  }
	  break;
	}
      break;
    }
  } while ( Stat != -1 && nread > 0 && (! (IsFile || IsTty) ) );
#if DEBUGIO
  fprintf(aplcout,"[read fd] exiting read loop \n");  
#endif
  /* close(fd); */
  if (count >0 ) { 
    /* have we allocated too much space ? */
    if (count <  Alloc) {
      /* yes, re allocate down */
      aplc_vectrealloc(&res->value, (int)count, APLC_CHAR);
#if DEBUGIO
      fprintf(aplcout,"[read fd] final re-allocate for %d bytes total\n", count );  
#endif
    }
  }
#if DEBUGIO
  fprintf(aplcout,"[read fd] read : %d chars total \n", count);  
#endif
  res->type = APLC_CHAR;
  res->alloc_ind = APLC_ALLOC_VAL_F;
  if (count == 1) {
    res->rank = 0;
    res->shape = aplc_ivone;
  } else {
    res->shape = aplc_dsval((int)count);
    res->alloc_ind |= APLC_ALLOC_SHAPE_F;
    res->rank = 1;
  }
  res->size = aplc_vsize(res->rank, res->shape);
  return;
}

/*
  aplc_wrfd - write a file
  N .is FileDescriptor #write Text
  (char) Res, Text
  (int) N, FileDescriptor
  N - no of bytes written : caller can try again or use a different device
  UNIX: 'it is not an error to write fewer bytes than requested'
  J.B.W.Webber@ukc.ac.uk  99_3_10
 */
extern void 
aplc_wrfd(struct trs_struct * res, struct trs_struct *left,
	  struct trs_struct * right) 
{
  int n, rsize;
  int fd;

  if( (left->type != APLC_BOOL) &&
      (left->type != APLC_INT) ) {
    aplc_error("[aplc_wrfd]: non integer left");
  }
  /* check size of left */
  if (left->size<1)
    aplc_error("[aplc_wrfd]: missing file descriptor");
  else if (left->size < 2) {
    /* just fd */
    fd = left->value.ip[0];
    rsize = aplc_vsize(right->rank, right->shape);
    if ( (n = write(fd, right->value.cp, (size_t) rsize)) 
	 != rsize) {
      if( n < 0 ) {
	fprintf(aplcerr, "[write]: write error [%d] \n",  n);
	/* aplc_error("[write]: write error"); */
      } else {
	fprintf(aplcerr, "[write]: no free space, [%d] bytes requested, [%d] bytes written \n", rsize, n);
	/* aplc_error("[write]: no free space"); */
      }
    }
    res->type = APLC_INT;
    res->rank = 0;
    res->shape = aplc_dsval(1);
    res->value.ip = aplc_dsval(n);
    res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
    res->size = 1;
  } else {
    /* more than just fd */
    aplc_wrfd_type(res, left, right);
  }
  return;
}

/* 
   7/2003 sws new fn for binary write

  (fd, count, type, size, sign, startbyte, skip) #append x 
  (fd, count, type, size, sign, startbyte, skip) #write x 
*/
static void 
aplc_wrfd_type(struct trs_struct *res, struct trs_struct *left,
	       struct trs_struct *right) 
{
  float tempf;
  int fd, count, type, size,sign, startbyte;
  int wr, rsize, countc;
  int n, nc, nout;
  char *tempcp;
  long templ;
  int j,k;

  if( (left->type != APLC_BOOL) &&
      (left->type != APLC_INT) ) {
    aplc_error("[aplc_wrfd_type]: non integer left");
  }
  /* check size of left */
  if (left->size < 1) {
    aplc_error("[aplc_wrfd_type]: missing file descriptor");
  } 

  fd = left->value.ip[0];
  /* defaults */
  type = APLC_CHAR;
  count = -1;
  size = 0;
  sign = 1;
  startbyte = 0;
  /* get right size, in chars */
  wr = aplc_type_width(right->type);
  rsize = aplc_vsize(right->rank, right->shape);
  if (left->size > 1)
    count = left->value.ip[1];/* have at least a count */	
  if (left->size > 2)
    type = left->value.ip[2]; /* have at least a type */
  if (left->size > 3)
    size =  left->value.ip[3];
  if (left->size > 4)
    sign =  left->value.ip[4];
  if (count < 0)
    count = rsize; 
  else
    count = min(count, rsize);
  countc = count;
  nout = 0;
  n = 0;
  switch(type) {
  default:
  case APLC_CHAR:
    countc = count;
    nout = write(fd, right->value.cp, (size_t) count);
    break;
  case APLC_BIT: 
  case APLC_BOOL:
    /* need to get each bit
       write into chars
       then write out the chars
    */
    nc = ceil( (double)count/CHAR_BIT);/* number of chars we need */
    tempcp = (char *) APLC_CMALLOC(nc);
    countc = nc;
    /* check for error */
    if (NULL == tempcp)
      aplc_error("[aplc_wrfd_type]: malloc error");
    /* copy data */
    n = 0;
    /* for each char */
    for (k=0; k<nc; k++) {
      tempcp[k] = (char) 0;
      /* for each bit */
      for (j=0; j<CHAR_BIT; j++) {
	if (n<count) {
	  if (right->value.ip[n++])
	    tempcp[k] |= char_mask[j];
	}
      }
    }
    /* now write out the chars */
    nout = write(fd, (void *) tempcp, (size_t) nc);
    break;
  case APLC_INT: 
    /* in this case for each int, write some chars */
    wr = iwidth(size,sign);/* size in chars of each int */
    countc = count*wr;
    for (k=0; k<count; k++) {
      templ = type_iset(right->value.ip[k], size, sign);
      nout += write(fd, (void *)&templ, (size_t) wr);
    }
    break;
  case APLC_REAL:
    /* in this case for each real, write some chars */
    wr = fwidth(size);/* size in chars */
    if (count < 0)
      count = rsize; 
    else
      count = min(count, rsize);
    countc = wr*count;
    for (k=0; k<count; k++) {
      if (size)
	nout += write(fd, (void *) &right->value.rp[k], (size_t) wr);
      else {
	tempf = right->value.rp[k];
	nout += write(fd, (void *) &tempf, (size_t) wr);
      }
    }
    break;
  }
  /* check for bad write ... */
  /*fprintf(aplcerr, " nout %d, countc %d, count %d\n", nout, countc, count);*/
  if (nout <countc) {
    if( nout < 0 ) {
      fprintf(aplcerr, "[wrdfd_type]: write error [%d] \n",  n);
    } else {
      fprintf(aplcerr, "[wrdfd_type]: no free space, [%d] bytes requested, [%d] bytes written \n", countc, nout);
    }
  }
  /* temp... */
  res->type = APLC_INT;
  res->rank = 0;
  res->shape = aplc_dsval(1);
  res->value.ip = aplc_dsval(nout);
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  res->size = 1;
  return;
}

/*   file lseek

  Res .is Whence #lseek FileDescriptorOffset

  int FileDescriptorOffset[2]
  char Whence : 'b' - seek from file beginning
              : 'c' - seek from current position
              : 'e' - seek from file end

  off_t lseek(int fd, off_t offset, int whence)
  J.B.W.Webber@ukc.ac.uk  99_3_9
 */
extern void
aplc_lseek(struct trs_struct *res,
	   struct trs_struct *left, struct trs_struct *right)
{
  int Whence, Posn;
  int * FdOff;


  Whence = 0;/* ensure initialization */

  if (right->type != APLC_INT) 
    aplc_error("[lseek]: non int file descriptor, offset");
  if (right->rank == 0) {
    aplc_error("[lseek]: bad file descriptor, offset");
  }    else {
    if (! ((right->rank == 1) && (right->shape[0] == 2))  )
      aplc_error("[lseek]: bad file descriptor, offset");
  }
  /*  this is handled in trs.c, leaf.c
    if (left->type != APLC_CHAR) 
    	aplc_error("[lseek]: bad Whence character");
    if (left->rank != 0)
	if (! ((left->rank == 1) && (left->shape[0] == 1))  )
		aplc_error("[lseek]: bad Whence character length");
 */

  FdOff =  right->value.ip;
  switch( * left->value.cp ) {
  default:
    fprintf(aplcerr, "[lseek]: Whence : [%s] \n",  left->value.cp );
    aplc_error("[lseek]:  bad Whence character, use [b|c|e]");
    break;
  case 'b':
    Whence = SEEK_SET;
    break;
  case 'c':
    Whence = SEEK_CUR;
    break;
  case 'e':
    Whence = SEEK_END;
    break;
  }
  if (( Posn = (int) lseek( FdOff[0], (off_t) FdOff[1], Whence)) == -1)
    aplc_error("[lseek]: failed");

  fprintf(aplcerr, "[lseek]: lseek fd %d, position %d from %d \n", FdOff[0], FdOff[1], Whence);

  res->type = APLC_INT;
  res->rank = 0;
  res->shape = aplc_dsval(1);
  res->value.ip = aplc_dsval(Posn);
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  res->size = 1;
  return;
}

/*
  fcntl file
  Res .is Modes #fcntl FileDescriptor(s)
  (char) Modes
  (int) FileDescriptor
  change status of existing FileDescriptor(s):
  Modes :
	a - append	  
	n - non-blocking
	+ - turn on	:
	- - turn off	: one at a time only
	J.B.W.Webber@ukc.ac.uk  99_3_9
 */

extern void
aplc_fcntl(struct trs_struct * res, 
		struct trs_struct * left,
		struct trs_struct * right)
{
  int i, Nin, fd, Flags, Mode, Action;
  char Modes[5];

  /*  this is handled in trs.c, leaf.c
    if (right->type != APLC_INT) 
    	aplc_error("close]: bad file descriptor");
    if (right->rank != 0)
	if (! ((right->rank == 1) && (right->shape[0] == 1))  )
		aplc_error("[fcntl]: bad file descriptor");
 */

  Nin = 1;
  if (right->rank != 0)
    Nin = right->shape[0];
  Mode = 0;
  Action = 1;
  if (left->type != APLC_CHAR)
    aplc_error("[fcntl] left type error"); 
  /*    Modes = left->value.cp; */
#if 0
  Modes = APLC_CMALLOC(1 + aplc_vsize(left->rank, left->shape));
  aplc_cp2str(Modes, left);
#endif
  cpNchars(Modes, 4, left->value.cp, left->size); 

  if ( ( strchr (Modes, 'a')) != NULL) 
    Mode =   Mode | O_APPEND ;
  if ( ( strchr (Modes, 'n')) != NULL) 
    Mode =   Mode | O_NDELAY ;
  if ( ( strchr (Modes, '-')) != NULL) 
    Action = 0;
  i = 0;
  while (i <  Nin) {
    fd=  right->value.ip[i++];
    /*V fprintf(aplcerr, "[fcntl]: fcntl fd %d \n", fd);  */
    if (( Flags = fcntl(fd, F_GETFL,0)) < 0)
      aplc_error("[fcntl]: fcntl get failed");
    /*V	fprintf(aplcerr, "[fcntl]: fcntl fd %d, get flags [O%o] \n", fd, Flags );  */  
    if (Action) {
      if (( fcntl(fd, F_SETFL, (long) Flags | Mode)) < 0)
	aplc_error("[fcntl]: fcntl set failed");
      /*V		fprintf(aplcerr, "[fcntl]: fcntl fd %d, set mode [O%o] \n", fd, Flags | Mode);  */  
    } else
      if (( fcntl(fd, F_SETFL, (long) Flags & ~Mode)) < 0)
	aplc_error("[fcntl]: fcntl set failed");
    /*V fprintf(aplcerr, "[fcntl]: fcntl fd [O%o], set mode %d \n", fd, Flags | Mode);  */  
  }

  res->type = APLC_INT;
  res->rank = 0;
  res->shape = aplc_ivone;
  res->value.ip = aplc_dsval(1);
  res->alloc_ind = APLC_ALLOC_VAL_F;
  res->size = 1;
  return;
}


/*
  close a file
  Closed .is #close FileDescriptor(s)
  (int) FileDescriptor
  returns scalar/vector of file descriptors successfully closed.
  J.B.W.Webber@ukc.ac.uk  99_3_9
 */

extern void
aplc_close(struct trs_struct * res, struct trs_struct * right)
{
  int i, Nin, Nout, fd;

  /*  this is handled in trs.c, leaf.c
      if (right->type != APLC_INT) 
        aplc_error("[close]: bad file descriptor");
      if (right->rank != 0)
        if (! ((right->rank == 1) && (right->shape[0] == 1))  )
          aplc_error("[close]: bad file descriptor");
      */

  Nin = 1;
  Nout  = 0;
  if (right->rank != 0)
    Nin = right->shape[0];
  aplc_vectalloc(&res->value, Nin, APLC_INT);
  i = 0;
  while (i <  Nin) {
    fd=  right->value.ip[i++];
    if ( close(fd) == -1) {
      fprintf(aplcerr, "[close]: close fd %d failed \n", fd);
      /* aplc_error("[close]: failed");  no disaster, just continue closing */
    } else {
      /*V fprintf(aplcerr, "[close]: closed fd %d\n", fd);  */
      res->value.ip[Nout++] =  fd;
    }
  }
  /* this is to possibly reduce space a bit 
     - won't work on sunos though, as that calls 
     aplc_irealloc(), which assumes we're increasing space
     in units of APLC_IBUFFSIZE

     aplc_vectrealloc(&res->value, Nout, APLC_INT);*/
  res->type = APLC_INT;
  res->alloc_ind = APLC_ALLOC_VAL_F;
  if (Nout == 1) {
    res->rank = 0;
    res->shape = aplc_ivone;
  } else 	{
    res->rank = 1;
    res->shape =  aplc_dsval(Nout);
    res->alloc_ind |= APLC_ALLOC_SHAPE_F;
  }
  res->size = aplc_vsize(res->rank, res->shape);
  return;
}


/*
  read - read a file - monadic #read
  one of :
    Res .is #read File
    Res .is #read FileDescriptor

  (char) Res, File
  (int) FileDescriptor

  Res .is #read fd, count, type, size, sign, startbyte, skip


  J.B.W.Webber@ukc.ac.uk  99_3_10
  8/2003 sws added count, types...
 */
extern void
aplc_read(struct trs_struct * res, struct trs_struct * right)
{
  /*fprintf(aplcerr, "[aplc_read]: type %d\n", right->type);*/
  if (right->type == APLC_CHAR) {
    aplc_fread(res, right);
    return;
  }
  if ( (right->type == APLC_BOOL) || (right->type == APLC_INT) ) {
    /*fprintf(aplcerr, "[aplc_read]: fd %d\n", *right->value.ip);*/
    /*aplc_fdread(res, right); works, but same as below */
    /*aplc_rdfd(res, *right->value.ip);*/
    aplc_rdfdt(res, right);
    return;
  } else
    aplc_error("[read]: bad file name type");
  return;
}


/*
  write - write to a file
  one of:
    Res .is FileName #write Text
    Res .is FileDescriptor #write Text

  (char) Res, File, Text
  (int) FileDescriptor

or
  (fd, type, count, size, sign, startbyte) #write x

  99_3_10 J.B.W.Webber@ukc.ac.uk  original
 */
extern void
aplc_write(struct trs_struct * res,
	   struct trs_struct * left, struct trs_struct * right)
{
  switch(left->type) {
  case APLC_CHAR:
    aplc_fmod(res, left, right, "w");
    break;
  case APLC_BOOL:
  case APLC_INT:
    /*aplc_fdwrite(res, left, right);*/
    aplc_wrfd(res, left, right);
    break;
  default:
    aplc_error("[aplc_write]: bad file name/descriptor type");
    break;
  }
  return;
}


/*
  fdread - read a file 
  Res .is #read FileDescriptor

  (char) Res
  (int) FileDescriptor

  J.B.W.Webber@ukc.ac.uk  99_3_10
 */
extern void
aplc_fdread(struct trs_struct * res, struct trs_struct * right)
{
  if ( (right->type == APLC_BOOL) || (right->type == APLC_INT) ) {
    /*fprintf(aplcerr, "[aplc_fdread]: fd %d\n", *right->value.ip);*/
    aplc_rdfd(res, *right->value.ip);
  } else
    aplc_error("[read]: bad file descriptor type");
}

/*
  fdwrite - write a file
  Res .is FileDescriptor #write Text

  (char) Res, Text
  (int) FileDescriptor

  J.B.W.Webber@ukc.ac.uk  99_3_10
 */
#if 0
extern void
aplc_fdwrite(struct trs_struct * res,
	     struct trs_struct * left, struct trs_struct * right)
{
  if ( (left->type == APLC_BOOL)  || (left->type == APLC_INT) ) 
    aplc_wrfd(res, left, right);
  else
    aplc_error("[write]: bad file descriptor type");
}
#endif

/* read a file, */
extern void
aplc_fread(struct trs_struct * res, struct trs_struct * right)
{
  int rsize;
  /*char name_space[FNAMELEN];*/
  /*char *name;*/
  struct stat stbuf;
  int izilde;
  int fd;
  int name_malloc = 0;

  name = name_space;/* default size */
  rsize = aplc_trs2str_sp(&name, FNAMELEN, &izilde, &name_malloc, 1, right);
  if (!izilde) {
    if (right->type != APLC_CHAR)
      aplc_error("read: bad file name type");
    /* try to find file information */
    if (stat(name, &stbuf) == -1) {
      /* fprintf(aplcerr, "\nread: can't find %s\n", name);*/
      fprintf(aplcerr, "\nread: can't find [%s] (%d)\n", name, strlen(name));
      /* error("bad file name"); */
      /* instead of breaking, return .io 0 */
      aplc_czilde(res);
    } else {
      fd = open(name, 0);
      aplc_rdfd(res, fd);
      if (( close(fd)) < 0)
	aplc_error("[read]: close failed");
    }
  } else {
    /*      aplc_rdfd(res, 0, Flag );      */
    fd = 0;
    aplc_rdfd(res, fd);
    if (( close(fd)) < 0)
      aplc_error("[read]: close failed");
  }
  /* now free space */
  if (name_malloc)
    aplc_free(name);
  return;
}

/*
    fwrite - write a file
    name fwrite (char data)
*/
extern void
aplc_fwrite(struct trs_struct * res,
    struct trs_struct * left, struct trs_struct * right)
{
  aplc_fmod(res, left, right, "w");
}

/* fappend - append chars to a file */
extern void
aplc_fappend(struct trs_struct * res,
	     struct trs_struct * left, struct trs_struct * right)
{
  switch(left->type) {
  case APLC_CHAR:
    aplc_fmod(res, left, right, "a");
    break;
  case APLC_BOOL:
  case APLC_INT:
    /* assume left is an fd, just write */
    /*aplc_wrfd(res, *left->value.ip, right);*/
    aplc_wrfd(res, left, right);
    break;
  default:
    aplc_error("[aplc_fappend]: bad file name type");
    break;
  }
}

/* used by both append or write 
   name fmod data
*/
static void
aplc_fmod(struct trs_struct * res,
	  struct trs_struct * left, struct trs_struct * right, 
	  char *mode)
{
  int i, lsize, rsize;
  /*char name_space[FNAMELEN];
    char *name;*/
  FILE *file;
  int izilde;
  int name_malloc = 0;

  /* check argument */
  if (right->type != APLC_CHAR)
    aplc_error("fmod: non-character right argument");
  rsize = aplc_vsize(right->rank, right->shape);

  /* get file name */
  name = name_space;/* default size */
  lsize = aplc_trs2str_sp(&name, FNAMELEN, &izilde, &name_malloc, 1, left);
  if (izilde) {
    /* write to stdio and quit */
    i = 0;
    while (i < rsize) {
      /* putc(right->value.cp[i++], stdout);*/
      putc(right->value.cp[i++], aplcout);
    }
    res->type = APLC_INT;
    res->rank = 0;
    res->shape = aplc_dsval(1);
    res->value.ip = aplc_dsval(1);
    res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
    res->size = aplc_vsize(res->rank, res->shape);
    return;
  }

/* #if 1  */ /*  don't overwrite */
#if 0   /*  do overwrite  :  J.B.W.Webber@ukc.ac.uk  98_02_19 */
  
  if ( mode[0]=='w' ) {
    /* don't overwrite an existing file */
    /* try to read */
    file = fopen(name, "r");
    /* file = fopen(name, mode);*/
    if (file != NULL) {
      fprintf(aplcerr, "\nfwrite: file %s exists\n", name);
      /* just return 0 if failed */
      /* aplc_error("bad file name"); */
      fclose(file);
      res->type = APLC_INT;
      res->rank = 0;
      res->shape = aplc_dsval(1);
      res->value.ip = aplc_dsval(0);
      return;
    }
  }
#endif

  /* now write or append */
  file = fopen(name, mode);
  i = 0;
  while (i < rsize) {
    putc(right->value.cp[i++], file);
  }
  fclose(file);
  res->type = APLC_INT;
  res->rank = 0;
  res->shape = aplc_dsval(1);
  res->value.ip = aplc_dsval(1);
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  res->size = aplc_vsize(res->rank, res->shape);
  /* free space */
  if (name_malloc)
    aplc_free(name);
  return;
}

/* ------------------------------------------------------------ */

/* width of int types
   units are bytes (char) */
static int
iwidth(int size, int sign)
{
  int r = sizeof(int);

  switch(sign) {
  case 0:
    switch(size) {
    case 0:
      r = sizeof(unsigned short);
      break;
    default:
    case 1:
      r = sizeof(unsigned int);
      break;
    case 2:
      r = sizeof(unsigned long);
      break;
    }
    break;
  default:
  case 1:
    switch(size) {
    case 0:
      r = sizeof(short);
      break;
    default:
    case 1:
      r = sizeof(int);
      break;
    case 2:
      r = sizeof(long);
      break;
    }
    break;
  }
  return r;
}

/* return value as an int */
static int
type_iget(int size, int sign, sp_mp_t *in, int k)
{
  int r = 0;

  switch(sign) {
  case 0:
    switch(size) {
    case 0:
      r = (int) in->iusp[k];
      break;
    default:
    case 1:
      r = (int) in->iup[k];
      break;
    case 2:
      r = (int) in->iulp[k];
      break;
    }
    break;
  default:
  case 1:
    switch(size) {
    case 0:
      r = (int) in->isp[k];
      break;
    default:
    case 1:
      r = in->ip[k];
      break;
    case 2:
      r = (int) in->ilp[k];
      break;
    }
    break;
  }
  return r;
}

static long
type_iset(int in, int size, int sign )
{
  sp_mp_t mp;
  long il;

  mp.ilp = &il;
  switch(sign) {
  case 0:
    switch(size) {
    case 0:
      *mp.iusp = (unsigned short) in;
      break;
    default:
    case 1:
      *mp.iup = (unsigned int) in;
      break;
    case 2:
      *mp.iulp = (unsigned long) in;
      break;
    }
    break;
  default:
  case 1:
    switch(size) {
    case 0:
      *mp.isp = (short) in;
      break;
    default:
    case 1:
      *mp.ip = in;
      break;
    case 2:
      *mp.ilp = (long) in;
      break;
    }
    break;
  }
  return *mp.ilp;
}


/* width of float types
   units are bytes (char) */
static int
fwidth(int size)
{
  int r = sizeof(double);

  switch(size) {
  case 0:
    r = sizeof(float);
    break;
  default:
  case 1:
    r = sizeof(double);
    break;
  }
  return r;
}

/* return value as a double */
static double
fget(int size, sp_mp_t *in, int k)
{
  double r = 0;

  switch(size) {
  case 0:
    r = (double) in->rfp[k];
    break;
  default:
  case 1:
    r = (double) in->rp[k];
    break;
  }
  return r;
}

/* width of aplc types
   units are bytes (char) */
static int
aplc_type_width(int type)
{
  int r = sizeof(double);

  switch(type) {
  case APLC_BIT:
  case APLC_BOOL:
  case APLC_LABEL:
  case APLC_INT:
    r = sizeof(int);
    break;

  default:
  case APLC_REAL:
    r = sizeof(double);
    break;
  case APLC_COMPLEX:
    r = 2*sizeof(double);
    break;
  case APLC_QUAT:
    r = 4*sizeof(double);
    break;
  case APLC_OCT:
    r = 8*sizeof(double);
    break;
  case APLC_CHAR:
    r = sizeof(char);
    break;
  case APLC_BOXED:
    r = sizeof(void *);
    break;
  }
  return r;
}

/* read from a fd, possibly with other info
   sws
 */
   
extern void
aplc_rdfdt(struct trs_struct *res, struct trs_struct *right)
{
  /* check size of right */
  if (right->size <1)
    aplc_error("[aplc_rdfdt]: missing file descriptor");
  else if (right->size <2) {
    /* just fd */
    aplc_rdfd(res, *right->value.ip);
  } else {
    aplc_rdfdt_type(res, right);
  }
  return;
}

/*
  #read fd  
  #read fd, count type size sign startbyte, skip

  if r is size 1:   read characters 
  else r specifies various options:

  count is the number of results to be read

  type is bit, int, real

  the rest depend on the type
 APLC_CHAR    9 
 (count, 9) reads count chars

 APLC_BIT     1  
 APLC_BOOL    2  
 (count, 1) reads count bits 
 (count, 1,startbyte) reads count bits starting with an offset

 APLC_INT     4
 (count, 4, size,sign, [startbyte]) reads count ints
   size is
   0  short
   1  int
   2  long
   sign is
   0 unsigned
   1 signed

 APLC_REAL    5 
 (count, 5, size, [startbyte]) reads count reals
   size is
   0 float
   1 double
    
  (int) FileDescriptor
  (int) r

  number of bits in a char is   CHAR_BIT (expect 8)

  sws  */
extern void
aplc_rdfdt_type(struct trs_struct * res, struct trs_struct * right)
{
  int fd;
  int count, type, size, sign, startbyte;
  int nread, j,k;
  int width;
  struct trs_struct temp, altleft;
  sp_mp_t sp_mp;
  
  if ( (right->type != APLC_BOOL) &&
       (right->type != APLC_INT) ) {
    /* error - need an int */
    aplc_error("read:rdfdt: non-integer argument");
  }
  /* now check size of right */
  fd = *right->value.ip;
  if (right->size <2) {
    /* right is scalar - read chars */
    aplc_rdfd(res, fd);
    return;
  }
  count = right->value.ip[1];
  if (right->size <3) {
    /* fd, count */
    aplc_rdfdn(res, count, fd);
    return;
  }
  type =  right->value.ip[2];
  /*fprintf(aplcerr, "[aplc_read]: count %d, type %d\n", count, type);*/
  switch(type) {
  default:
  case APLC_CHAR:
    /*res->type = APLC_CHAR;*/
    /*fprintf(aplcerr, "[aplc_read]: char\n");*/
    aplc_rdfdn(res, count, fd);
    break;
  case APLC_BIT: 
  case APLC_BOOL:
    /* res->type = APLC_BOOL;*/
    /*fprintf(aplcerr, "[aplc_read]: bool\n");*/
    /* decide how many chars to read 
       - assume 8 bits per char */
    nread = (int) ceil(count/((double) CHAR_BIT));
    /* read into tmp char array */ 
    aplc_settrs(&altleft, APLC_INT, 0, NULL);
    altleft.scalar.i = nread;
    altleft.value.ip = &altleft.scalar.i;
    aplc_readn_char(&temp, &altleft, right);
    /* determine final count */
    count = min(count, temp.size*CHAR_BIT);
    /* setup return structure */
    aplc_settrs(res, APLC_BOOL, 1, &count);
    aplc_talloc(res);
    /* now convert to bits */
    nread = 0;
    j = 0;
    while (nread<count) {
      for (k=0; k<CHAR_BIT; k++) {
	/* convert bit k of temp.value.cp[j] */
	if (char_mask[k] & temp.value.cp[j])
	  res->value.ip[nread++] = 1;
	else
	  res->value.ip[nread++] = 0;
      }
      j++; 
    }
    /* free temp structures */
    aplc_detalloc(&temp);
    break;

  case APLC_INT: 
    /*res->type = APLC_INT;*/
    /* read other parameters */
    size = 1;
    sign = 1;
    startbyte = 0;
    if (right->size>3)
      size = right->value.ip[3];
    if (right->size>4)
      sign = right->value.ip[4];
    if (right->size>5)
      startbyte = right->value.ip[5];
    /* decide how many chars to read 
       - assume 8 bits per char */
    width = iwidth(size,sign);/* size in chars */
    nread = count*width;
    /* read into tmp char array */ 
    aplc_settrs(&altleft, APLC_INT, 0, NULL);
    altleft.scalar.i = nread;
    altleft.value.ip = &altleft.scalar.i;
    aplc_readn_char(&temp, &altleft, right);
    /* determine final count */
    count = min( count, temp.size/width );
    /*fprintf(aplcerr, "[]: count %d chars %d\n", count, temp.size);*/
    /* setup return structure */
    aplc_settrs(res, APLC_INT, 1, &count);
    aplc_talloc(res);
    /* now convert */
    sp_mp.cp = temp.value.cp;
    for (k=0; k<count; k++)
      res->value.ip[k] = type_iget(size, sign, &sp_mp, k);
    /* free temp structures */
    aplc_detalloc(&temp);
    break;

  case APLC_REAL:
    /*res->type = APLC_REAL;*/
    /*fprintf(aplcerr, "[aplc_read]: real\n");*/
    /* read other parameters */
    size = 1;
    startbyte = 0;
    if (right->size>3)
      size = right->value.ip[3];
    if (right->size>4)
      startbyte = right->value.ip[4];
    /*fprintf(aplcerr, "[]: count %d, type %d size %d startbyte %d\n", 
      count, type,size,startbyte);*/

    /* decide how many chars to read 
       - assume 8 bits per char */
    width = fwidth(size);/* size in chars */
    nread = count*width;
    /*fprintf(aplcerr, "[]: nread %d width %d\n", nread, width);*/

    /* read into tmp char array */ 
    aplc_settrs(&altleft, APLC_INT, 0, NULL);
    altleft.scalar.i = nread;
    altleft.value.ip = &altleft.scalar.i;
    aplc_readn_char(&temp, &altleft, right);
    /* determine final count */
    count = min( count, temp.size/width );
    /*fprintf(aplcerr, "[]: count %d chars %d\n", count, temp.size);*/

    /* setup return structure */
    aplc_settrs(res, APLC_REAL, 1, &count);
    aplc_talloc(res);
    /* now convert */
    sp_mp.cp = temp.value.cp;
    for (k=0; k<count; k++)
      res->value.rp[k] = fget(size, &sp_mp, k);
    /* free temp structures */
    aplc_detalloc(&temp);
    break;
  } 

  return;
}

/*
  r #readn f - dyadic #read

  - read from a file or fp

  if r is size 1:   read r characters 
  else r specifies various options:

  count type size sign startbyte

  count is the number of results to be read

  type is bit, int, real

  the rest depend on the type
 APLC_CHAR    9 
 (count, 9) reads count chars

 APLC_BIT     1  
 APLC_BOOL    2  
 (count, 1) reads count bits 
 (count, 1,startbyte) reads count bits starting with an offset

 APLC_INT     4
 (count, 4, size,sign, [startbyte]) reads count ints
   size is
   0  short
   1  int
   2  long
   sign is
   0 unsigned
   1 signed

 APLC_REAL    5 
 (count, 5, size, [startbyte]) reads count reals
   size is
   0 float
   1 double
    
  (int) FileDescriptor
  (int) r

  number of bits in a char is   CHAR_BIT (expect 8)

  sws  */
extern void
aplc_readn(struct trs_struct * res, struct trs_struct *left,
	   struct trs_struct * right)
{
  int count, type, size, sign, startbyte;
  int nread, j,k;
  int width;
  struct trs_struct temp, altleft;
  sp_mp_t sp_mp;
  
  /*fprintf(aplcerr, "[aplc_read]: lsize %d, rtype %d\n", 
    left->size, right->type);*/
  if ( (left->type != APLC_BOOL) &&
       (left->type != APLC_INT) ) {
    /* error - need left an int */
    aplc_error("readn: non-integer left argument");
  }
  /* now check size of left */
  if (left->size <2) {
    /* left is scalar - nread n chars, or empty */
    aplc_readn_char(res, left, right);
    return;
  }

  count = left->value.ip[0];
  type =  left->value.ip[1];
  /*fprintf(aplcerr, "[aplc_read]: count %d, type %d\n", count, type);*/
  switch(type) {
  default:
  case APLC_CHAR:
    /*res->type = APLC_CHAR;*/
    /*fprintf(aplcerr, "[aplc_read]: char\n");*/
    aplc_readn_char(res, left, right);
    break;
  case APLC_BIT: 
  case APLC_BOOL:
    /* res->type = APLC_BOOL;*/
    /*fprintf(aplcerr, "[aplc_read]: bool\n");*/
    /* decide how many chars to read 
       - assume 8 bits per char */
    nread = (int) ceil(count/((double) CHAR_BIT));
    /* read into tmp char array */ 
    aplc_settrs(&altleft, APLC_INT, 0, NULL);
    altleft.scalar.i = nread;
    altleft.value.ip = &altleft.scalar.i;
    aplc_readn_char(&temp, &altleft, right);
    /* determine final count */
    count = min(count, temp.size*CHAR_BIT);
    /* setup return structure */
    aplc_settrs(res, APLC_BOOL, 1, &count);
    aplc_talloc(res);
    /* now convert to bits */
    nread = 0;
    j = 0;
    while (nread<count) {
      for (k=0; k<CHAR_BIT; k++) {
	/* convert bit k of temp.value.cp[j] */
	if (char_mask[k] & temp.value.cp[j])
	  res->value.ip[nread++] = 1;
	else
	  res->value.ip[nread++] = 0;
      }
      j++; 
    }
    /* free temp structures */
    aplc_detalloc(&temp);
    break;

  case APLC_INT: 
    /*res->type = APLC_INT;*/
    /*fprintf(aplcerr, "[aplc_read]: int\n");*/
    /* read other parameters */
    size = 1;
    sign = 1;
    startbyte = 0;
    if (left->size>2)
      size = left->value.ip[2];
    if (left->size>3)
      sign = left->value.ip[3];
    if (left->size>4)
      startbyte = left->value.ip[4];
    /*fprintf(aplcerr, "[]: count %d, type %d size %d sign %d startbyte %d\n", 
      count, type,size,sign,startbyte);*/

    /* decide how many chars to read 
       - assume 8 bits per char */
    width = iwidth(size,sign);/* size in chars */
    nread = count*width;
    /*fprintf(aplcerr, "[]: nread %d width %d\n", nread, width);*/
	  
    /* read into tmp char array */ 
    aplc_settrs(&altleft, APLC_INT, 0, NULL);
    altleft.scalar.i = nread;
    altleft.value.ip = &altleft.scalar.i;
    aplc_readn_char(&temp, &altleft, right);
    /* determine final count */
    count = min( count, temp.size/width );
    /*fprintf(aplcerr, "[]: count %d chars %d\n", count, temp.size);*/
    /* setup return structure */
    aplc_settrs(res, APLC_INT, 1, &count);
    aplc_talloc(res);
    /* now convert */
    sp_mp.cp = temp.value.cp;
    for (k=0; k<count; k++)
      res->value.ip[k] = type_iget(size, sign, &sp_mp, k);
    /* free temp structures */
    aplc_detalloc(&temp);
    break;

  case APLC_REAL:
    /*res->type = APLC_REAL;*/
    /*fprintf(aplcerr, "[aplc_read]: real\n");*/
    /* read other parameters */
    size = 1;
    startbyte = 0;
    if (left->size>2)
      size = left->value.ip[2];
    if (left->size>3)
      startbyte = left->value.ip[3];
    /*fprintf(aplcerr, "[]: count %d, type %d size %d startbyte %d\n", 
      count, type,size,startbyte);*/

    /* decide how many chars to read 
       - assume 8 bits per char */
    width = fwidth(size);/* size in chars */
    nread = count*width;
    /*fprintf(aplcerr, "[]: nread %d width %d\n", nread, width);*/

    /* read into tmp char array */ 
    aplc_settrs(&altleft, APLC_INT, 0, NULL);
    altleft.scalar.i = nread;
    altleft.value.ip = &altleft.scalar.i;
    aplc_readn_char(&temp, &altleft, right);
    /* determine final count */
    count = min( count, temp.size/width );
    /*fprintf(aplcerr, "[]: count %d chars %d\n", count, temp.size);*/

    /* setup return structure */
    aplc_settrs(res, APLC_REAL, 1, &count);
    aplc_talloc(res);
    /* now convert */
    sp_mp.cp = temp.value.cp;
    for (k=0; k<count; k++)
      res->value.rp[k] = fget(size, &sp_mp, k);
    /* free temp structures */
    aplc_detalloc(&temp);
    break;
  } 

  return;
}

/*
  readn_char - read n characters from a file or fp
  either :
    Res .is n #read File
    Res .is n #read FileDescriptor

  (char) Res, File
  (int) FileDescriptor
  (int) n

  sws based on read
 */
extern void
aplc_readn_char(struct trs_struct * res, struct trs_struct *left,
		struct trs_struct * right)
{
  int cnt;

  if ( ! ( (left->type == APLC_BOOL) || 
	   (left->type == APLC_INT) ) ) {
    /* error - need left an int */
    aplc_error("readn: non-integer left argument");
  }
  if (left->size < 1) 
    cnt = INT_MAX;
  else
    cnt = *left->value.ip;

  if (right->type == APLC_CHAR) {
    aplc_freadn(res, cnt, right);
    return;
  }
  if ( (right->type == APLC_BOOL) || (right->type == APLC_INT) ) {
    /*fprintf(aplcerr, "[aplc_read]: fd %d\n", *right->value.ip);*/
    /* aplc_fdread(res, right); works, but same as below */
    aplc_rdfdn(res, cnt, *right->value.ip);
    return;
  } else
    aplc_error("[read]: bad file name type");
  return;
}

/* read a file, */
extern void
aplc_freadn(struct trs_struct * res, int n,
	    struct trs_struct * right)
{
#if 1
  int rsize;
  /*char name_space[FNAMELEN];
    char *name;*/
  struct stat stbuf;
  int izilde;
  int fd;
#endif
  int name_malloc = 0;

  name = name_space;/* default size */
  rsize = aplc_trs2str_sp(&name, FNAMELEN, &izilde, &name_malloc, 1, right);
  if (!izilde) {
    if (right->type != APLC_CHAR)
      aplc_error("read: bad file name type");
    /* try to find file information */
    if (stat(name, &stbuf) == -1) {
      /* fprintf(aplcerr, "\nread: can't find %s\n", name);*/
      fprintf(aplcerr, "\nread: can't find [%s] (%d)\n", name, strlen(name));
      /* error("bad file name"); */
      /* instead of breaking, return .io 0 */
      aplc_czilde(res);
    } else {
      fd = open(name, 0);
      aplc_rdfdn(res, n, fd);
      if (( close(fd)) < 0)
	aplc_error("[read]: close failed");
    }
  } else {
    /*      aplc_rdfd(res, 0, Flag );      */
    fd = 0;
    aplc_rdfdn(res, n, fd);
    if (( close(fd)) < 0)
      aplc_error("[read]: close failed");
  }
  /* now free space */
  if (name_malloc)
    aplc_free(name);
}

/* aplc_rdfdn

 Read a file or piped text into an aplc variable, 
 given a file descriptor. Returns char data. 

 set block/nonblock with open now

 sws based on rdfd
 */
extern void
aplc_rdfdn(struct trs_struct * res, int n, int fd )
{
  int i, j;
  int Stat, Alloc;
  char  *block2;
  unsigned int count;
  struct stat stbuf;
  long size2;
  long GetSize, WaitSize;
  int IsTty, IsFile, IsFifo;
  long StatBlkSize, StatBlks;
  int nlink;
  /* max that a signed int can hold */
  static long INTSIZE = (long) INT_MAX; 

  j = 0; /* ensure initialization */

  /* fprintf(aplcout,"[read fd] (start) \n"); */ 
  if( (IsTty =  isatty (fd)) ) {
    fprintf(aplcout,"[aplc_rdfdn]: fd %d is a tty, %s\n", 
	    fd, ttyname(fd));  
  }
  /* use fstat to determine what type of device it is, 
     and how much space to allocate  */
  if ( fstat(fd, &stbuf) < 0 ) {
    aplc_error("[aplc_rdfdn]: read fstat failed");
  }
  /* all is well, get length etc. : */
  nlink = (int) stbuf.st_nlink;
#if DEBUGIO
  fprintf(aplcout,"[read fd n] %d links to file \n", nlink);  
#endif
  /* this should give us the number of bytes waiting to be read */
  GetSize = stbuf.st_size;
#if DEBUGIO
  fprintf(aplcout,"[read fd n] %ld bytes in file \n", GetSize);  
#endif
  /* this should give us the ideal pipe transfer block size */
  StatBlkSize = stbuf.st_blksize;
#if DEBUGIO
  fprintf(aplcout,"[read fd] blocksize %ld \n", StatBlkSize);  
#endif
  /*    StatBlkSize = ST_BLKSIZ(stbuf);
    fprintf(aplcout,"[read fd] %ld d blocksize \n", StatBlkSize);      */

  /* note StatBlks are in terms of 512 bytes (usually!) */
#ifdef DJPC 
  /* what should this really be ? */
  StatBlks = 2;
#else
  StatBlks = stbuf.st_blocks;
#endif
#if DEBUGIO
  fprintf(aplcout,"[read fd n] %ld blocks \n", StatBlks);  
#endif
  if( S_ISCHR(stbuf.st_mode) ) {
    GetSize = (long) APLC_IBUFSIZE;	/* run.h */
#if DEBUGIO
    fprintf(aplcout,"[read fd n] file is a char device \n");  
#endif
  }
  if( (IsFile = S_ISREG(stbuf.st_mode) ) ) {
    /*	GetSize = GetSize ;	 file size in 1 go ! */
#if DEBUGIO
    fprintf(aplcout,"[read fd n] file is a regular file \n");  
#endif
  }
  if( S_ISDIR(stbuf.st_mode) ) {
    fprintf(aplcout,"[read fd n] file is a directory \n");  
    aplc_error("read fd n: read failed");
  }
  if ( ( IsFifo =  S_ISFIFO(stbuf.st_mode) ) ) {
    GetSize = (long) StatBlkSize;	
#if DEBUGIO
    fprintf(aplcout,"[read fd] file is a fifo \n");  
#endif
  }
  count =  0;
  Alloc = 0;
  do {
    slicewait((long)1); 
    /* no point in looping without waiting for other processes 
       once started, seems to always have 4k data waiting (till the end) 
    */
    switch ( Stat = fstat(fd, &stbuf) ) {
    default:
      fprintf(aplcerr,"[read fd] (default), SHOULD NOT HAPPEN\n" );  
    case -1: 
      /* read fd is closed, tidy up */
#if DEBUGIO
      fprintf(aplcout,"[read fd] fd closed \n"); 
#endif
      break;
    case  0: 
      /* all is well, get length :
       this should give us the number of bytes waiting to be read
      */
      WaitSize = stbuf.st_size;
#if DEBUGIO
      fprintf(aplcout,"[read fd] %ld bytes in file \n", WaitSize);  
#endif
      /*
	i = size2 > BUFSIZ ? BUFSIZ : size2;
	i = size2 > (long)BUFSIZ ? BUFSIZ : (int)size2;
	i = (int) size2 > INTSIZE ? INTSIZE : size2;

	if fstat gave 0, we may have to wait, so ask for GetSize anyway 
	and read will block till data is ready or ends, 
	or there is an error */
      GetSize = WaitSize == 0 ? GetSize : WaitSize ;

      /* fstat gives us a long, but vectalloc is only int */
      i = (int) GetSize > INTSIZE ? INTSIZE : GetSize;

      /* limit read to input size */
      i = min(i, n-count);

      /* fprintf(aplcout,"[read fd]  we will ask for %d bytes \n", i );   */

	/* allocate space  */ 
	/* have we allocated any space yet ? */
      if (count == 0) 	    {
	/* we have not written anything yet, allocate i bytes */
	Alloc = i;
#if DEBUGIO
	fprintf(aplcout,"[read fd] allocate %d bytes \n", i);  
#endif
	aplc_vectalloc(&res->value, Alloc, APLC_CHAR);
      } else {
	/* we just added j bytes, so allocate an extra j bytes of space */
	Alloc = count + j;
#if DEBUGIO
	fprintf(aplcout,"[read fd] re-allocate for extra %d bytes \n", j );  
#endif
	aplc_vectrealloc(&res->value, Alloc, APLC_CHAR);
      }
      /* read data */
      switch (j =  read(fd, (unsigned int) count + res->value.cp, 
			(size_t) i ) ) {
      case -1: 
	/* read failed */
	fprintf(aplcout,"[read fd] read failed (-1) \n");
	aplc_error("read fd: read failed");
	break;
      case 0: 
	/* out of data, tidy up */
#if DEBUGIO
	fprintf(aplcout,"[read fd] read %d chars: out of data \n", j);  
#endif
	break;
      default: 
	/* read j bytes */
#if 0
	/* no, we may have done an lseek : */
	if (j != i && IsFile)
	  fprintf(aplcout,"[read fd] failed, should have %d chars, have %d \n", i, j) ;  
#endif
	block2 += j;
	size2 += j;
	count += j;
#if DEBUGIO
	fprintf(aplcout,"[read fd] read %d chars \n", j);  
#endif
	break;
      }
      break;
      break;
    }
  } while ( Stat != -1 && j > 0 && (! (IsFile || IsTty) ) )
      ;
  if (count <  Alloc) {
    /* have we allocated too much space ? */
    aplc_vectrealloc(&res->value, (int)count, APLC_CHAR);
#if DEBUGIO
    fprintf(aplcout,"[read fd] re-allocate for %d bytes total \n", 
	    count );  
#endif
  }
#if DEBUGIO
  fprintf(aplcout,"[read fd] read : %d chars total \n", count);  
#endif
  res->type = APLC_CHAR;
  res->alloc_ind = APLC_ALLOC_VAL_F;
  if (count == 1) {
    res->rank = 0;
    res->shape = aplc_ivone;
  } else {
    res->shape = aplc_dsval((int)count);
    res->alloc_ind |= APLC_ALLOC_SHAPE_F;
    res->rank = 1;
  }
  res->size = aplc_vsize(res->rank, res->shape);
  return;
}

/* ------------------------------------------------------------ */
/* conversion routines
   binary (char) to/from aplc types

   #chartype
   #typechar

   #chartype

   apltype .is (type,size,sign) #typechar char
   char .is (type,size,sign) #chartype apltype

?or
   apltype .is (count,type,size,sign) #typechar char
   char .is (count,type,size,sign) #chartype apltype

 */

extern void
aplc_typechar(struct trs_struct * res, struct trs_struct *left,
	      struct trs_struct * right)
{
  int count, type, size, sign;
  int nread, j,k;
  int width;
  sp_mp_t sp_mp;
  
  if ( (left->type != APLC_BOOL) &&
       (left->type != APLC_INT) ) {
    /* error - need left an int */
    aplc_error("[typechar] non-integer left argument");
  }
  if ( right->type != APLC_CHAR ) {
    /* error - need char right */
    aplc_error("[typechar] non-character right argument");
  }
  /* initialize to defaults */
  type = APLC_CHAR;
  size = 1;
  sign = 1;

  /* now check size of left */
  if (left->size >0)
    type =  left->value.ip[0];
  if (left->size >1)
    size =  left->value.ip[1];
  if (left->size >2)
    sign =  left->value.ip[2];

  switch(type) {
  default:
  case APLC_CHAR:
    aplc_copytrs(res, right);
    break;
  case APLC_BIT: 
  case APLC_BOOL:
    /* res->type = APLC_BOOL;*/
    /* determine final count */
    count = right->size*CHAR_BIT;
    /* setup return structure */
    aplc_settrs(res, APLC_BOOL, 1, &count);
    aplc_talloc(res);
    /* now convert to bits */
    nread = 0;
    j = 0;
    while (nread<count) {
      for (k=0; k<CHAR_BIT; k++) {
	/* convert bit k of temp.value.cp[j] */
	if (char_mask[k] & right->value.cp[j])
	  res->value.ip[nread++] = 1;
	else
	  res->value.ip[nread++] = 0;
      }
      j++; 
    }
    break;

  case APLC_INT: 
    /*res->type = APLC_INT;*/
    width = iwidth(size,sign);/* size in chars */
    /* determine final count */
    count = right->size/width;
    /* setup return structure */
    aplc_settrs(res, APLC_INT, 1, &count);
    aplc_talloc(res);
    /* now convert */
    sp_mp.cp = right->value.cp;
    for (k=0; k<count; k++)
      res->value.ip[k] = type_iget(size, sign, &sp_mp, k);
    break;

  case APLC_REAL:
    /*res->type = APLC_REAL;*/
    width = fwidth(size);/* size in chars */
    /* determine final count */
    count = right->size/width;
    /* setup return structure */
    aplc_settrs(res, APLC_REAL, 1, &count);
    aplc_talloc(res);
    /* now convert */
    sp_mp.cp = right->value.cp;
    for (k=0; k<count; k++)
      res->value.rp[k] = fget(size, &sp_mp, k);
    break;
  } 
  return;
}

#if 0
/*
   char .is (type,size,sign) #chartype type

 */
extern void
aplc_chartype(struct trs_struct * res, struct trs_struct *left,
	      struct trs_struct * right)
{
  int count, type, size, sign;
  int nread, j,k;
  int width;
  sp_mp_t sp_mp;
  
  if ( (left->type != APLC_BOOL) &&
       (left->type != APLC_INT) ) {
    /* error - need left an int */
    aplc_error("[chartype] non-integer left argument");
  }

  /* initialize to defaults */
  type = APLC_CHAR;
  size = 1;
  sign = 1;
  /* now check size of left */
  if (left->size >0)
    type =  left->value.ip[0];
  if (left->size >1)
    size =  left->value.ip[1];
  if (left->size >2)
    sign =  left->value.ip[2];

  width = aplc_type_width(right->type);
  /* get result size 
     res.size = right.width/res.width
   */

  sp_mp.cp = right->value.cp;
  switch(type) {
  default:
  case APLC_CHAR:
    aplc_copytrs(res, right);
    break;
  case APLC_BIT: 
  case APLC_BOOL:
    /* res->type = APLC_BOOL;*/
    /* determine final count */
    count = right->size*CHAR_BIT;
    /* setup return structure */
    aplc_settrs(res, APLC_BOOL, 1, &count);
    aplc_talloc(res);
    /* now convert to bits */
    nread = 0;
    j = 0;
    while (nread<count) {
      for (k=0; k<CHAR_BIT; k++) {
	/* convert bit k of temp.value.cp[j] */
	if (char_mask[k] & right->value.cp[j])
	  res->value.ip[nread++] = 1;
	else
	  res->value.ip[nread++] = 0;
      }
      j++; 
    }
    break;

  case APLC_INT: 
    /*res->type = APLC_INT;*/
    width = iwidth(size,sign);/* size in chars */
    /* determine final count */
    count = right->size/width;
    /* setup return structure */
    aplc_settrs(res, APLC_INT, 1, &count);
    aplc_talloc(res);
    /* now convert */
    sp_mp.cp = right->value.cp;
    for (k=0; k<count; k++)
      res->value.ip[k] = type_iget(size, sign, &sp_mp, k);
    break;

  case APLC_REAL:
    /*res->type = APLC_REAL;*/
    width = fwidth(size);/* size in chars */
    /* determine final count */
    count = right->size/width;
    /* setup return structure */
    aplc_settrs(res, APLC_REAL, 1, &count);
    aplc_talloc(res);
    /* now convert */
    sp_mp.cp = right->value.cp;
    for (k=0; k<count; k++)
      res->value.rp[k] = fget(size, &sp_mp, k);
    break;
  } 
  return;
}

#endif

/* end */
/* ------------------------------------------------------------ */
