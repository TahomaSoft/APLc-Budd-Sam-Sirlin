/*
	APL Compiler

	general symbol table utilities for parse stage
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.
*/

#include <stdio.h>

#include "parse.h"
#include "y_tab.h"

/* turn on some prints for debugging */ 
#define DEBUG 0

/* ----------------------------------------------- */

/* initialize an info structure 
   - part of a symbol table entry or node */
extern void
init_info(info_t *x)
{
  x->info = x->type = x->rank = x->shape = x->values = 0;
  x->size = -1;
  return;
}

/* initialize a codetree, as defined in ctree.h */
extern void
init_codetree(codetree_t *x)
{
  x->cop = 0;
  x->c0.cindex = 0;
  x->c1.ctfield = 0;
  x->c2.ctype = 0;
  return;
}


/* lookup_name - see if a name is in a symbol table
   return pointer to it in the table if found */
extern struct symnode *
lookup_name(char *name, struct symnode *table)
{
  if (name == '\0') {
    error("[lookup_name] name is void ");
    return (0);
  }
  for (; table != 0; table = table->next) {
    if (strcmp(name, table->name) == 0) {
      return (table);
    }
  }
  return (0);
}

extern int
sym_class_match( class_t c1, class_t c2)
{
  int r = 0;

  switch(c1) {
  case PARAM:
  case APARAM:
  case LOCAL:
    switch(c2) {
    case PARAM:
    case APARAM:
    case LOCAL:
      r = 1;
      break;
    default:
      r = 0;
      break;
    }
    break;
  default:
    if (c1 == c2)
      r = 1;
    else
      r = 0;
    break;
  }
  return r;
}

extern char *
name_strcpy(char *name)
{
  char *x;

  if ( (x = malloc( (size_t) strlen(name)+1)) )
    strcpy(x, name);
  return x;
}

/* add_sym - place a new symbol into a symbol table */
extern symnode_t *
add_sym(char *name, struct symnode **table, 
	char * alias, struct symnode **atable, 
	class_t class, int type, int rank)
{
  symnode_t *x, *y, *xa;

#if DEBUG
  fprintf(stderr,"[add_sym] name %s, %s, type %s, rank %s\n", 
	  name, str_class(class), str_type_name(type), str_rank(rank));
#endif
  x = lookup_name(name, *table);

  if (x != NILSYM) {
    /* already in table, update attributes 
       - could already be set to uktype/norank (locals)
       or any/anyrank  (params) */
#if DEBUG
    fprintf(stderr, "[add_sym] symbol table %s: %s ",
	    name, str_class(x->class) );
    print_info(stderr, &(x->s));
    fprintf(stderr,"\n");
#endif
    if (! sym_class_match(class, x->class) ) {
      fprintf(stderr,"[add_sym] %s new class %s, existing class %s\n",
	      name, str_class(class), str_class(x->class));
      error("conflicting class declaractions");
    }
    if (type != APLC_UKTYPE) {
      if ( (x->s.type != APLC_UKTYPE) && (x->s.type != APLC_ANY) && 
	   (x->s.type != type) ) {
	fprintf(stderr,"[add_sym] %s t,r %d %d, existing t,r %d %d\n",
		name,type,rank, x->s.type, x->s.rank);
	error("conflicting type declaractions");
      } else {
	x->s.type = type;
	x->s.info |= TYPEKNOWN; 
	if (type != APLC_UKTYPE)
	  x->s.info |= TYPEDECL; 
      }
    }
    if (rank != NORANK) {
      if (rank != ANYRANK) {
	if (x->s.rank != NORANK && x->s.rank != ANYRANK && 
	    x->s.rank != rank)
	  error("conflicting rank declaractions");
	else {
	  x->s.rank = rank;
	  x->s.info |= RANKKNOWN;
	  x->s.info |= RANKDECL; 
	}
      } else { /* ANYRANK */
	x->s.rank = ANYRANK;
	x->s.info |= RANKKNOWN;
      }
    }
  } else {
    /* not already in the table - add it */
    x = structalloc(symnode);
    if (x == NILSYM)
      error("[add_sym] out of room");
    /*x->name = name;*/
    x->name = name_strcpy(name);
    if (x->name == 0)
      error("[add_sym] out of room for name");
    x->class = class; 
    init_info(&(x->s));
    x->s.type = type;
    x->s.rank = rank;
    if (type != APLC_UKTYPE) {
      x->s.info |= TYPEKNOWN; 
      if (type != APLC_ANY)
	x->s.info |= TYPEDECL; 
    }
    if (rank != NORANK) {
      if (rank != ANYRANK) {
	x->s.info |=  RANKKNOWN;
	x->s.info |= RANKDECL; 
	if (rank == 0) {
	  x->s.info |=  SHAPEKNOWN; 
	  x->s.size = 1;
	}
      } else {
	x->s.info |=  RANKKNOWN;
	x->s.rank = ANYRANK;
      }
    }
#if 1
    /* this adds to the end of the symbol table 
       - makes it easier to pass */
    x->next = 0;
    if (*table == 0)
      *table = x;/* the only entry */
    else {
      /* go to the last element */
      y = *table; 
      while (y->next != 0)
	y = y->next;
      y->next = x;
    }
#else
    /* this adds the new entry to the beginning */
    x->next = *table;
    *table = x;
#endif
  }

  /* now check alias */
  if (alias) {
    xa = lookup_name(alias, *atable);
    if (xa != NILSYM) {
      /* alias in table, update attributes */
#if DEBUG
      fprintf(stderr, "[add_sym] symbol table alias %s: %s ",
	      alias, str_class(xa->class) );
      print_info(stderr, &(xa->s));
      fprintf(stderr,"\n");
#endif

#if 0
      /* expect different classes */
      if (! sym_class_match(x->class, xa->class) ) {
	fprintf(stderr,"[add_sym] %s class %s, alias %s, class %s\n",
		name, str_class(x->class), 
		alias, str_class(xa->class));
	error("conflicting class declaractions");
      }
#endif
      if (xa->s.type != APLC_UKTYPE) {
	if ( (x->s.type != APLC_UKTYPE) && (x->s.type != APLC_ANY) && 
	     (x->s.type != xa->s.type) ) {
	  fprintf(stderr,"[add_sym] %s t,r %d %d, alias %s t,r %d %d\n",
		  name,x->s.type,x->s.rank, 
		  alias, xa->s.type, xa->s.rank);
	  error("conflicting type declaractions");
	} else {
	  x->s.type = xa->s.type;
	  x->s.info |= TYPEKNOWN; 
	  if (type != APLC_ANY)
	    x->s.info |= TYPEDECL; 
	}
      }
      if (xa->s.rank != NORANK) {
	if (xa->s.rank != ANYRANK) {
	  if (x->s.rank != NORANK && x->s.rank != ANYRANK && 
	      x->s.rank != xa->s.rank)
	    error("conflicting rank declaractions");
	  else {
	    x->s.rank = xa->s.rank;
	    x->s.info |= RANKKNOWN;
	    x->s.info |= RANKDECL; 
	  }
	} else { /* ANYRANK */
	  x->s.rank = ANYRANK;
	  x->s.info |= RANKKNOWN;
	  x->s.info |= RANKDECL; 
	}
      }
    }
  }

  /* scalar check - if rank is 0, then we know the shape, size */ 
  if ( (x->s.info & RANKKNOWN) && (x->s.rank != ANYRANK) ) {
    if (x->s.rank == 0) {
      x->s.info |= SHAPEKNOWN;
      x->s.size = 1;
    }
  }


#if DEBUG
  fprintf(stderr, "[add_sym+] %s, ",name);
  print_info(stderr, &(x->s));
  /*fprintf(stderr,"\n");*/
  fprintf(stderr,"\nCurrent symbol table:\n");
  print_symtab(stderr, *table);
#endif
  return (x);
}


/* end */

