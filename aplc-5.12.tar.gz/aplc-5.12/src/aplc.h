/* aplc.h

	APL Compiler

	structures and definitions used by the apl compiler,
	both by the compiler and by compiled aplc programs

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_H
#define _APLC_H

/* some important defines, so see what we should include */
#include <aplc_config.h>

#include <stdio.h>
#include <stdlib.h>

/* malloc should be included already, but not on all machines */
#ifdef HAVE_MALLOC
#include <malloc.h>
#endif
#include <math.h>
#include <limits.h>
#ifdef HAVE_FLOAT_H
#include <float.h>
#endif

/* value types - must match: 
   ctree.c, tfstrs[], caststrs[], tystrs[], mpfields[]
   putil.c: types[] */
#define APLC_UNDEF  -1
#define APLC_UKTYPE  0
#define APLC_BIT     1  /* int */
#define APLC_BOOL    2  /* int */
#define APLC_LABEL   3 
#define APLC_INT     4
#define APLC_REAL    5  /* double */
#define APLC_COMPLEX 6
#define APLC_QUAT    7  /* quaternion */
#define APLC_OCT     8  /* octave, octonion */
#define APLC_CHAR    9
#define APLC_BOXED  10  /* boxed, nested */
#define APLC_ANY    11  /* only used for inferencing */

/* scalar functions  
                first line - monadic only          1 
		second line - monadic and dyadic, 11 
		third line - dyadic only          10   
 - must match list in ops.c 		
 - must match strings in ctree.c 
*/
enum sfuns {APLC_NOT,
	   APLC_FLOOR,APLC_CEIL,APLC_PLUS,APLC_MINUS,APLC_TIMES,APLC_ABS,APLC_DIVIDE,APLC_EXP,APLC_LOG,APLC_CIRCLE,APLC_FACT,
           APLC_AND,APLC_OR,APLC_NAND,APLC_NOR,APLC_LT,APLC_LE,APLC_EQ,APLC_NE,APLC_GE,APLC_GT,
	   APLC_L_AND, APLC_L_OR};

/* system variables: 
   constants,        17
   monadic functions, 8
   dyadic/ambivalent functions   8 
   - must match strings in leaf.c 
*/
enum sysvars {
  SYS_ARG, SYS_IO, SYS_PP, SYS_PRNG, SYS_PW, SYS_RL, SYS_OMAP, SYS_TS, SYS_JTS, 
   TCBEL,TCBS,TCCR,TCDEL,TCESC,TCFF,TCHT,TCLF,TCNUL,
  SYS_AZ, SYS_ZA, SYS_CL, SYS_DL, SYS_FREE, SYS_READLINE, SYS_SYS, 
   SYS_FI, SYS_VI, SYS_VTYPE, 
  SYS_FM, SYS_OP, SYS_FREAD, SYS_FWRITE, SYS_FAPPEND, SYS_LSEEK, 
   SYS_PIPE, SYS_SPAWN, SYS_FCNTL, SYS_SS};

 /*  
     SYS_PP -     printing precision 
     SYS_PW -     print width 
     SYS_RL -     random link 
     SYS_IO -     index origin 
     SYS_ARG -    command arguments 
     SYS_OMAP -   output mapping 
     SYS_TS -     time stamp 
     SYS_JTS -    Julian time (seconds) 

       terminal control characters 

     TCBEL -   bell (7) 
     TCBS  -   backspace (8)
     TCCR  -   cariage return (13) 
     TCDEL -   delete (127) 
     TCESC -   escape (27) 
     TCFF  -   form feed (12)
     TCHT  -   horizontal tab (9) 
     TCLF  -   line feed (10)
     TCNUL -   null (0) 

     SYS_CL -     close file 
     SYS_DL -     delay
     SYS_FREE -   (na)
     SYS_FREAD  - file read 
     SYS_SYS -    unix system execute 
     SYS_FI - convert from string to number
     SYS_VI - validate "" (na)
     SYS_VTYPE -  (na) 

     SYS_FM -     format 
     SYS_OP -     open file 
     SYS_FWRITE - file write 
     SYS_FAPPEND - file append
     SYS_LSEEK -  file lseek (fd)
     SYS_PIPE   - pipe data through shell command pipe, and back in
     SYS_SPAWN -  spawn shell command, return I/O file descriptors
     SYS_FCNTL -  file control: append/nonblocking
     SYS_SS     - string search
 */

/* indications of memory allocation */
#define APLC_UNALLOC          0 /* not allocated */
#define APLC_ALLOC_VAL_F     01 /* value allocated, freeable */
#define APLC_ALLOC_VAL_S     02 /* value linked to scalar, not freeable */
#define APLC_ALLOC_SHAPE_F   04 /* shape allocated, freeable */
#define APLC_ALLOC_SHAPE_NF 010 /* shape allocated, not freeable */

/* these are just combinations of the above: */
#define APLC_ALLOC_F         05 /* value and shape freeable */
#define APLC_ALLOC_NF       012 /* value and shape not freeable */

#if defined(SUNOS4) || defined(SUNOS5)
/* either one */
#define SUNOS
#endif


/* define some simple functions as macros, unless they exist already */
#ifndef HAVE_ABS
#define abs(x) ((x) >= 0 ? (x) : -(x))
#endif
#ifndef HAVE_MIN
#define min(a,b) ((a) <= (b) ? (a) : (b))
#endif
#ifndef HAVE_MAX
#define max(a,b) ((a) >= (b) ? (a) : (b))
#endif

#ifdef SUNOS4
/* prototypes for things that should be in system .h's 
   sun4 .h's are useless
   but don't define these when compiling the parser   */
#ifndef TRADITIONAL
extern int fclose (FILE *);
extern int fprintf(FILE *, const char *,...);
extern char *memalign(unsigned, unsigned);
extern int printf(const char *,...);
extern int fprintf(FILE *, const char *,...);
extern int _filbuf(FILE *);
extern int _flsbuf (unsigned int, FILE *);
extern int fwrite(char *, int, int, FILE *);
extern int fread(char *, int, int, FILE *);
#endif

/* end of sun4 specific prototypes */
#endif


/* ----------------------------------------------------------- */
/* ----------------------------------------------------------- */
/* the following code isn't used except for the runtime routines */

#ifndef APLC_PARSER
/*
   the following definitions are used only by the run-time system,
   not by the parser itself
*/

/* default random number generator switch 
   if 0 will use rand, if 1 will use Mother in runop.c 
   rand() is rather variable in it's max value... 
   this is now changeable in a program using #prng */
#define USEMOTHER 1


/* res_struct - structures for results */

typedef union {
  int	 i;
  double r;
  double z[2];
  double q[4];
  double o[8];
  char	 c;
} sscalar_t;

/* mp_struct - pointers to memory */
union mp_struct {
  double *rp;	/* real pointers */
  double *zp[2]; /* complex pointers */
  double *qp[4]; /* quat pointers */
  double *op[8]; /* oct pointers */
  int	 *ip;	/* integer pointers */
  char	 *cp;	/* character pointers */
  struct trs_struct *trsp;/* trs pointers */
};

/* trs - type/rank/shape pointers */
struct trs_struct {
  int	type;	/* type of object */
  int	rank;
  int	*shape;
  int	size;
  int   alloc_ind; /* indication of memory allocation */
  union mp_struct value;
  /* use this to avoid alloc/free */
  sscalar_t scalar;
};

union res_struct {
  int    type;
  int	 i;
  double r;
  double z[2];
  double q[4];
  double o[8];
  char	 c;
  struct trs_struct trs;
};

typedef struct trs_struct trs_t;
typedef union res_struct res_t;
typedef int (*aplfp_t) (trs_t *, trs_t *, trs_t *);

/* declare some variables */
/* index origin */
extern int aplc_ixorg;
/* where output is sent */
extern FILE *aplcout;
/* where errors are printed */
extern FILE *aplcerr;

/* type of pseudo random number generator */
extern int aplc_prng;
/* random seed */
extern unsigned long aplc_seed;
/* flag */
extern int aplc_rl_init;


/* some simple integers, defined in runmem.c */
extern int aplc_ivone[1];
extern int aplc_ivzero[1];
/* declare global trs for null args of fns */
extern trs_t aplc_nulltrs;


/* ----------------------------------------------------------- */
/* function declarations */
/* ansi c prototypes */

/* binomial.c */
extern int    aplc_binomiali(int a, int b);
extern double aplc_binomialr(double a, double b);

/* fact.c */
extern int aplc_fact(int n);

/* gamma.c */
extern double aplc_gamma(double x);

/* laqrc.c */
extern int dgelsx_(long int *m, long int *n, long int *nrhs, double *a, long int *lda,
		   double *b, long int *ldb, long int *jpvt, double *rcond,
		   long int *rank, double *work, long int *info);

/* runfun.c */
/* monadic */
extern void aplc_not_res(union res_struct * res,  
			 union res_struct * resin, int type);
extern void aplc_floor_res(union res_struct * res,  
			 union res_struct * resin, int type);
extern void aplc_ceil_res(union res_struct * res,  
			 union res_struct * resin, int type);
extern void aplc_conj_res(union res_struct * res,  
			 union res_struct * resin, int type);
extern void aplc_neg_res(union res_struct * res,  
			 union res_struct * resin, int type);
extern void aplc_sign_res(union res_struct * res,  
			 union res_struct * resin, int type);
extern void aplc_mag_res(union res_struct * res,  
			 union res_struct * resin, int type);
extern void aplc_recip_res(union res_struct * res,  
			 union res_struct * resin, int type);
extern void aplc_exp_res(union res_struct * res,  
			 union res_struct * resin, int type);
extern void aplc_nlog_res(union res_struct * res,  
			 union res_struct * resin, int type);
extern void aplc_pim_res(union res_struct * res,  
			 union res_struct * resin, int type);
extern void aplc_fact_res(union res_struct * res,  
			 union res_struct * resin, int type);

/* dyadic */
extern void aplc_min_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_max_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_plus_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_minus_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_times_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_residue_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_divide_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_power_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_log_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_circle_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_binomial_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_and_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_or_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_nand_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_nor_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_lt_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_le_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_eq_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_ne_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_ge_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);
extern void aplc_gt_res(union res_struct * res, union res_struct * lval, 
		      int ltype, union res_struct * rval, int rtype);


/* runio.c */
extern int *aplc_dsval(int val);

extern void aplc_trap(int n);
extern void aplc_error(char *s); 
extern void aplc_syserr( char * msg); 


extern void aplc_str2trs(struct trs_struct * trs, char * str);
extern int aplc_trs2str(char *str, int csize, struct trs_struct *trs);
extern int aplc_trs2str_sp(char **str, int csize, int *is_zilde, 
			   int *did_malloc, int drop_ws, 
			   struct trs_struct *trs);
extern void aplc_setargs(int argc, char *argv[]);
extern void aplc_asysvar(enum sysvars fun, struct trs_struct * res, 
			struct trs_struct *right); 
extern void aplc_sysvar(enum sysvars fun, struct trs_struct * res);
extern void aplc_sys(struct trs_struct * res,
		     struct trs_struct * left, struct trs_struct * right);

extern void aplc_dl(struct trs_struct * res,
			struct trs_struct * right);

extern void aplc_zilde(struct trs_struct * res);
extern void aplc_czilde(struct trs_struct * res);

/*extern void aplc_pipe(struct trs_struct * res, struct trs_struct * right);*/
extern void aplc_pipe(struct trs_struct * res, struct trs_struct * left,
		      struct trs_struct * right);
extern void aplc_spawn(struct trs_struct * res,
			struct trs_struct * left, 
			struct trs_struct *right); 

extern void aplc_spawn_mon(struct trs_struct * res,
			struct trs_struct *right); 

extern void aplc_strsrch(struct trs_struct * res,
			 struct trs_struct * left, struct trs_struct * right);
extern void aplc_type(struct trs_struct * res, struct trs_struct * right);


extern void aplc_print_trs(struct trs_struct * res) ;

/* runio_ex.c */
extern void aplc_quad(FILE * file, struct trs_struct * trs);
extern void aplc_execute(struct trs_struct* res, 
			 struct trs_struct *right);
extern void aplc_fi(struct trs_struct* res, 
			 struct trs_struct *right);
extern void aplc_vi(struct trs_struct* res, 
			 struct trs_struct *right);

/* runio_f.c*/
extern void aplc_open(struct trs_struct * res,
		      struct trs_struct * left, 
		      struct trs_struct * right);
extern void aplc_mopen(struct trs_struct * res,
		       struct trs_struct * right);

extern void aplc_rdfd(struct trs_struct * res, int fd );
extern void aplc_wrfd(struct trs_struct *res, struct trs_struct *left, 
		      struct trs_struct *right); 
extern void aplc_lseek(struct trs_struct * res,
			struct trs_struct * left, 
			struct trs_struct * right);
extern void aplc_fcntl(struct trs_struct * res, 
			struct trs_struct * left,
			struct trs_struct * right);
extern void aplc_close(struct trs_struct * res,
			struct trs_struct * right);
extern void aplc_read(struct trs_struct * res,
			struct trs_struct * right);
extern void aplc_write(struct trs_struct * res,
			struct trs_struct * left,
			struct trs_struct * right); 
extern void aplc_fdread(struct trs_struct * res,
			struct trs_struct * right);
extern void aplc_fdwrite(struct trs_struct * res,
			struct trs_struct * left,
			struct trs_struct * right); 

extern void aplc_fread(struct trs_struct * res, 
		       struct trs_struct * right); 
/*
extern void aplc_getchars(struct trs_struct * res, struct trs_struct * right);
*/
extern void aplc_fwrite(struct trs_struct * res, 
			struct trs_struct * left, 
			struct trs_struct * right);
extern void aplc_fappend(struct trs_struct * res, 
			struct trs_struct * left, 
			struct trs_struct * right);

extern void aplc_readn(struct trs_struct * res, struct trs_struct *left,
		       struct trs_struct * right);
extern void aplc_readn_char(struct trs_struct * res, struct 
			    trs_struct *left, struct trs_struct * right);

/* read a file, */
extern void aplc_freadn(struct trs_struct * res, int n,
			struct trs_struct * right);
extern void aplc_rdfdn(struct trs_struct * res, int n, int fd );

extern void aplc_typechar(struct trs_struct *res, struct trs_struct *left,
			  struct trs_struct * right);
extern void aplc_chartype(struct trs_struct *res, struct trs_struct *left,
			  struct trs_struct * right);



/* runio_fmt.c */
extern void aplc_printit(union res_struct * res, int type, int nls); 
extern int  aplc_bmpnl(int iindex, int rank, int *shape); 
extern void aplc_dformat(struct trs_struct * res, 
			 struct trs_struct *left, 
			 struct trs_struct * right); 
extern void aplc_prnim(int *a,int m,int n, char *s);
extern void aplc_format(struct trs_struct * res, 
			struct trs_struct * right); 

/* runio_qq.c */
extern void aplc_qquad(FILE * file, struct trs_struct * trs);
extern void aplc_qquad_assign(struct trs_struct * trs);
extern void aplc_readline(struct trs_struct * res,
			  struct trs_struct * right);

/* runmat.c*/
extern void aplc_domino(struct trs_struct * res, struct trs_struct * right);
extern void aplc_msolve(struct trs_struct * res,
			struct trs_struct * left, struct trs_struct * right);
extern void aplc_drop(struct trs_struct * res,
		      struct trs_struct * left, struct trs_struct * right);
extern void aplc_take(struct trs_struct * res,
		      struct trs_struct * left, struct trs_struct * right);

/*runmati.c*/
/* not used */

/*runmem.c*/
extern int aplc_nullf(struct trs_struct *r, struct trs_struct *a, 
		      struct trs_struct *b);
extern void aplc_assign(struct trs_struct * id, struct trs_struct * trs);
extern void aplc_assign_ind(struct trs_struct * id, int idi, 
			    struct trs_struct * trs, int trsi);
extern void aplc_cpvec(register int *to, int size, register int *from);
extern void aplc_cpwo(register int *to, int wo, int size, register int *from);
extern void aplc_cp2str(char *s, struct trs_struct *trs);
extern void aplc_detalloc(struct trs_struct * trs);
extern void aplc_free_shape(struct trs_struct * trs);
extern int  aplc_esubi(int i, int rank, int *shape);
extern void aplc_mp2res(union res_struct * res, union mp_struct * mp, int i, 
		       int type);
extern void aplc_setmp(union res_struct * res, union mp_struct * mp, int i, 
		       int type);
extern void aplc_link_res(trs_t *t, res_t *res);
extern void aplc_link_scalar(struct trs_struct *res);
extern void aplc_inittrs(struct trs_struct * trs);

extern void aplc_copytrs(struct trs_struct *res, struct trs_struct *in);
extern void aplc_duptrs(struct trs_struct *res, struct trs_struct *in);

extern void aplc_cptrsval(struct trs_struct *res, int i, 
			  struct trs_struct *inp, int j);
extern void aplc_cpres2trs(struct trs_struct *res, int i, 
			   union res_struct *inp);

/*extern void aplc_vectalloc(union mp_struct * mp, int size, int type);*/

#if 1
/* debugging versions */ 
#define aplc_settrs(trs, type, rank, shape)  aplc_settrs_debug(trs, type, rank, shape,  __FILE__, __LINE__) 
#define aplc_talloc(trs)  aplc_talloc_debug(trs, __FILE__, __LINE__) 
#define aplc_vectalloc(mp, size, type) aplc_vectalloc_debug(mp,size,type, __FILE__, __LINE__)
#define aplc_free(x) aplc_free_debug(x, __FILE__, __LINE__)
/*#define aplc_memfree(x) aplc_free_debug(x, __FILE__, __LINE__)*/
#else
#define aplc_settrs(trs, type, rank, shape) aplc_settrs_simple(trs, type, rank, shape)
#define aplc_talloc(trs)  aplc_talloc_simple(trs)
#define aplc_vectalloc(mp, size, type) aplc_vectalloc_simple(mp,size,type)
/*#define aplc_free(x) aplc_free_simple(x)*/
#define aplc_free(x) free(x)
/*#define aplc_memfree(x) free(x)*/
#endif

extern void aplc_settrs_debug(struct trs_struct * trs, int type, int rank, int *shape,
			      char *file, int line);
extern void aplc_settrs_simple(struct trs_struct * trs, int type, int rank, int *shape);
extern int  aplc_talloc_debug(struct trs_struct *trs, char *file, int line);
extern int  aplc_talloc_simple(struct trs_struct *trs); 
extern void aplc_vectalloc_debug(union mp_struct * mp, int size, int type,
				 char *file, int line);
extern void aplc_vectalloc_simple(union mp_struct * mp, int size, int type);
extern void aplc_free_debug(void *x, char *file, int line);
extern void aplc_free_simple(void *x);


extern void aplc_vectrealloc(union mp_struct * mp, int size, int type);
extern int  aplc_vsize(int rank, int *shape); 
extern void aplc_vectpromote(union mp_struct * mp, int size, int type, int newtype );
#ifdef SUNOS
extern void *aplc_drealloc(double *ip, int size);
extern void *aplc_irealloc(int *ip, int size);
#endif

/* run_ops.c */
extern void aplc_az(struct trs_struct * res, struct trs_struct * right);
extern void aplc_za(struct trs_struct * res, struct trs_struct * right);
extern void aplc_az2(struct trs_struct *res, 
		     struct trs_struct *left, struct trs_struct *right);
extern void aplc_za2(struct trs_struct *res, 
		     struct trs_struct *left, struct trs_struct *right);

extern void aplc_encode(union res_struct * res, union res_struct * lval, 
			int ltype, union res_struct * rval, int rtype);

extern int aplc_isnumtype(int type);
extern int aplc_maxtype(int type1, int type2);
extern void aplc_unbox(struct trs_struct *res, struct trs_struct *right);
extern int aplc_each(trs_t *r, trs_t *a, aplfp_t f, aplfp_t g, trs_t *b);
extern int aplc_link(trs_t *r,  trs_t *a, trs_t *b);
extern int aplc_reshapex(trs_t *r,  trs_t *a, trs_t *b);


/* runop.c*/
extern int aplc_iabs(int i);
extern int aplc_conftype(union res_struct * lval, int ltype,
			 union res_struct * rval, int rtype);
extern int aplc_conftype2(union res_struct * lnval, union res_struct * lval,
			  int ltype, union res_struct * rnval, union res_struct * rval, 
			  int rtype);
extern void aplc_cktype2(union res_struct * resn, int type,
			 union res_struct * res, int giventype);
extern void aplc_cktype(union res_struct * res, int type, int giventype);
extern void aplc_genfill(union res_struct * res, int type);
extern void aplc_identity(enum sfuns op, union res_struct * res, int type);
extern void aplc_dsfunv(enum sfuns op, union res_struct * res, union res_struct * lval, 
		       int ltype, union res_struct * rval, int rtype);
/*void msfunv(enum sfuns op, union res_struct * res, int type);*/
extern void aplc_msfunv(union res_struct * res, enum sfuns op, 
		       union res_struct * resin, int type);
extern void aplsort(union mp_struct * result, union mp_struct * values,
		    int size, int type, int direction);
extern int aplsearch(int *iindex, union mp_struct * values,
		     union res_struct * result, int valtype, int restype, int size);
extern int  aplc_randint(int limit);
extern void aplc_deal(union mp_struct * values, int num, int val);
extern void aplc_resfun(union res_struct * res, int type, enum sfuns op, int i);
extern int  aplc_imsfun(enum sfuns op, union res_struct * res, int type);


/* runshape.c*/
/* type of cat/subassign */
extern int aplc_mergetype(int lefttype, int righttype);
/* type of dyadic scalar function */
extern int aplc_dsfunt(enum sfuns op, int lefttype, int righttype);
extern int aplc_msfunt(enum sfuns op, int type); /* type of monadic scalar function */
/* dyadic scalar function shape */
extern int aplc_dsfuns(union mp_struct * shape, int leftrank, int *leftshape,
		      int rightrank, int *rightshape);
extern int aplc_outershape(union mp_struct * shape, int leftrank, int *leftshape,
			   int rightrank, int *rightshape);
/* decode and inner product shape */
extern int aplc_innershape(union mp_struct * shape, int leftrank, int *leftshape,
			   int rightrank, int *rightshape);
extern void aplc_fprintf_ivec(FILE *p, char *s, int *v, int n);
 /* catenate shape */
extern int aplc_catshape(union mp_struct * shape, int leftrank, int *leftshape,
			 int rightrank, int *rightshape, int axis, int axisind,
			 int taxis, int *e, int *sl, int *sr);
extern int aplc_dtshape(union mp_struct * shape, int *lvalues,
			int rrank, int *rshape);
extern void aplc_lamcheck(int *type, union res_struct * res, int *axis);
extern int * aplc_lamshape(int axis, int leftrank, int *leftshape, 
			   int rightrank, int *rightshape);
extern int aplc_suba_check(int leftrank, int *leftshape, 
			   int rightrank, int *rightshape);

extern int aplc_getsize(int rank, int *shape);
 
/* runtol.c */
extern int aplc_isnearint(double rval, int *ival);
extern int aplc_isnearintd(double rval, double *ival);
#if 0 
extern int aplc_nearestint(double a);
extern int aplc_nearint(double rval);
#endif
extern double aplc_nearestint(double a);
extern double aplc_nearint(double rval);

extern int aplc_toleq(double a, double b);

/* runtrans.c*/
extern int aplc_qsdalloc(int rank, union mp_struct *q, union mp_struct *s, 
			 union mp_struct *d);
extern int aplc_accessor(int toprank, int *topshape, int rank, int *shape, 
			 union mp_struct *delta, int *q, int *s, int *d);
extern int aplc_td_accessor(int toprank, int *topshape, 
			    int rank, int *shape, 
			    union mp_struct *delta, int *s);
extern void aplc_trmerge(int rank, int *q, int *s, int *d);
extern void aplc_dtmerge(int *control, int rank, union mp_struct *q, 
			 union mp_struct *s, union mp_struct *d);

/* end of ansi declarations */
/* ----------------------------------------------------------- */

/* macro to free memory */
/*#define aplc_memfree(x) free(x)*/
/* #define aplc_memfree(x) */
/* #define aplc_memfree(x)  printf("memfree x\n")*/


/* macro to print trace information, if enabled */ 
#ifdef TRACE
#define aplc_trace(name,stmt) \
   fprintf(stderr,"trace %s statement %d\n", name, stmt)
#else
#define aplc_trace(name,stmt)
#endif /* #ifdef TRACE */

/* define some numerical constants */
#ifndef PI
#define PI 3.1415926535897932384626434
#endif /* #ifndef PI */


/* ----------------------------------------------------------- */
/* define some machine constants
   these should be in float.h, but ...
 */
#if defined DJPC || defined SUNOS5 || defined ST || defined FREEBSD
/* these are ok for pc or sun  or ST  
   IEEE 32 bit 
 machine epsilon
 #define EPS   2.22045e-16
 smallest and largest integers
 #define IMIN -2147483648 
 #define IMAX  2147483647
 smallest and largest abs reals
 #define XMIN  2.22507e-308
 #define XMAX  1.79769e+308

 #define DBL_DIG number of decimal points of precision
*/

/* switch to  float.h names */
#if 0
#define EPS  DBL_EPSILON
#define IMIN INT_MIN
#define IMAX INT_MAX
/* smallest and largest abs reals */
#define XMIN DBL_MIN
#define XMAX DBL_MAX
#endif

# endif /* DJPC, SUNOS5, ST, FREEBSD */

#if defined SUNOS4
/* at least my old klunky includes for sun os 4 */
/* these are ok for pc or sun  or ST */
/* machine epsilon */
#define DBL_EPSILON   2.22045e-16
/* smallest and largest integers */
#define INT_MIN -2147483648
#define INT_MAX  2147483647
/* smallest and largest abs reals */
#define DBL_MIN  2.22507e-308
#define DBL_MAX  1.79769e+308
#define DBL_DIG 16

# endif /* #if defined SUNOS4 */

#if defined DECALPHA || defined SGI 
/* machine epsilon should exist */
/* smallest and largest integers */
#ifndef INT_MIN
#define INT_MIN -2147483647
#define INT_MAX  2147483647
#endif
/* smallest and largest abs reals should exist */
#ifndef DBL_DIG
#define DBL_DIG 16
#endif

# endif /* #if defined DECALPHA || defined SGI */


#if defined(LINUX) || defined(CYGWIN) 

/* machine epsilon */
#ifndef DBL_EPSILON
#define DBL_EPSILON   2.22045e-16	/* guessing */
#endif /* #ifndef DBL_EPSILON */
/* smallest and largest integers */
#ifndef INT_MIN
/* 32 bit standard */
#define INT_MIN -2147483647
#define INT_MAX  2147483647
#endif /* #ifndef INT_MIN */

/* smallest and largest abs reals */
/* Linux 2.2.10 doesn't have mindouble, does have other */
#ifndef DBL_MIN
#ifdef MINDOUBLE
#define DBL_MIN  MINDOUBLE
#define DBL_MAX  MAXDOUBLE
#else
#define DBL_MIN  2.22507e-308
#define DBL_MAX  1.79769e+308
#endif 
#endif /* #ifndef DBL_MIN */

#ifndef DBL_DIG
#define DBL_DIG 16
#endif

#endif /* #if defined(LINUX) || defined(CYGWIN) */

#ifdef WINI386
#define INT_TMAX  2147483647
#define INT_MIN -2147483648
#define DBL_MIN  2.22507e-308
#define DBL_MAX  1.79769e+308
#define DBL_EPSILON   2.22045e-16	/* guessing */
#ifndef DBL_DIG
#define DBL_DIG 16
#endif
#endif /* #ifdef WINI386 */


/* put something here for other machines */

/* ----------------------------------------------------------- */



#endif /* ifndef APLC_PARSER */


#endif /* ifndef _APLC_H */

/* end of aplc.h */

