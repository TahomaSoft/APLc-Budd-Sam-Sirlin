/*
	APL Compiler

	code generation fragments for the compiler
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.


 11/07/2004 Created sws

*/

#include <stdio.h>

#include "parse.h"
#include "gen.h"

/* ----------------------------------------------- */

/* generate a function call to a library function 

   - can handle case where assign is previous node and has passed in a
     name to set

   - makes assumptions about trs numbers

     aplc_drop(res, left, right); */
extern void
fun_call(char *fn, struct node *node)
{
  /* first the actual funtion call */
  printf("%s(",fn);
  if ( node->n.info & ASSNAMEOK ) {
    /* the assigned variable */
    printf("%c%s, ", (is_parm(node->namea) ? ' ' : '&'), 
	   node->namea);
  } else
    printf("&trs%d, ", node->ptr3);
  printf(" &trs%d, &trs%d", node->ptr1, node->ptr2);
  rpseminl();

  /* now the node info code */
  if ( node->n.info & ASSNAMEOK ) {
    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gident(node->namea, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gident(node->namea, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gident(node->namea, cshapefield, APLC_UKTYPE);
    node->c.values = gident(node->namea, cvalfield, rtype(node));
  } else {
    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);
    node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));
  }
  return;
}


/* memfree(mp.ip) if not scalar 
    i is the mp ptr, r the rank ptr
    sws */
extern void
mpfree_nots(int i, int r)
{
  if (r<0) {
    fprintf(stderr, "[mpfree_nots] bad arg r = %d < 0\n",r);
    error("[mpfree_nots] bad argument");
  }
  /*printf("if(i%d != 0)\n", r);*/
  printf("if (i%d)\n", r);
  /*printf("aplc_memfree(mp%d.ip);\n", i);*/
  printf("aplc_free(mp%d.ip);\n", i);
}

/* sws 
   - builds a test that returns 1 for a singleton
   ( (rank==0) || ((rank==1)&&(shape==1)) ) */
extern void
singleton(struct node * node)
{
  if (node->n.info & RANKKNOWN) {
    if (rankvalue(node) == 0)
      printf("(1)");
    else if (rankvalue(node) == 1) {
      printf("(*");
      ctgen(node->c.shape);
      printf(" ==1) ");
    } else
      printf("(0)");
  } else {
    printf("((");
    ctgen(node->c.rank);
    printf(" == 0) || ((");
    ctgen(node->c.rank);
    printf(" == 1) && (*");
    ctgen(node->c.shape);
    printf(" ==1)) ) ");
  }
}

/* sws */
/*- builds a test that returns 1 for a scalar
  (rank==0) */
extern void
testscalar(struct node * node)
{
  if (node->n.info & RANKKNOWN) {
    if (rankvalue(node) == 0)
      printf("(1)");
    else
      printf("(0)");
  } else {
    printf("(");
    ctgen(node->c.rank);
    printf(" == 0)");
  }
}



/* sws 
   free the shape of trs's, being careful of scalars etc. */
extern void
trs_shape_free(int i)
{
  /* printf("free(trs%d.shape);\n", i);*/
  printf("aplc_free_shape(&trs%d);\n", i);
}

/* options for trs initialization
   0 simple, fast
   1 more complete */
#define INIT_TYPE 0
/* sws
   initialize a trs structure 
   - to zilde */
extern void 
inittrs(int i)
{
#if INIT_TYPE == 0
  printf("trs%d.type = APLC_UKTYPE;\n", i);
  printf("trs%d.alloc_ind = APLC_UNALLOC;\n",i);
#else
  printf("aplc_inittrs(&trs%d);\n", i);
#endif
}

/* sws
   initialize a trs structure; named  */
extern void 
inittrsn(char *s)
{
#if INIT_TYPE == 0
  /*printf("%s.type = APLC_UKTYPE;\n", s);
  printf("%s.alloc_ind = APLC_UNALLOC;\n",s);*/
  printf("%s%stype = APLC_UKTYPE;\n", s, (is_parm(s) ? "->" : "."));
  printf("%s%salloc_ind = APLC_UNALLOC;\n",s, (is_parm(s) ? "->" : "."));
#else
  /*printf("aplc_inittrs(&%s);\n", s);*/
  printf("aplc_inittrs(%s%s);\n", (is_parm(s) ? ' ' : '&'),s);
#endif
}

#if 0
/* sws
   initialize a trs structure; named pointer */
extern void 
inittrsnp(char *s)
{
#if INIT_TYPE == 0
  printf("%s->type = APLC_UKTYPE;\n", s);
  printf("%s->alloc_ind = APLC_UNALLOC;\n",s);
#else
  printf("aplc_inittrs(%s);\n", s);
#endif
}
#endif

/* end */
