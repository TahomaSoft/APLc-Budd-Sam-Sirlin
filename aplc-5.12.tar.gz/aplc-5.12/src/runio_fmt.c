/*
	APL Compiler Run Time System

	Format routines
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/


/* ------------------------------------------------------------ */

/*
  The main routines

  aplc_printit()
  - was used by old version of genqassign() in qasgn.c
  - sprint_ns

  aplc_prinim
  - for debugging (not used)

  aplc_dformat()
  - testwidth
  - sprintf_double
  - sprintf_complex
  - sprintf_quat
  - sprintf_oct

  aplc_format()
  - char_array_to_matrix
  - aplc_take
  - char_box_matrix
  - format_int
  - format_real
  - format_complex
    -sprint_ns
  - format_quat
    -sprint_ns
  - format_oct
    -sprint_ns

*/

/* ------------------------------------------------------------ */


#include "aplc.h"
#include "run.h"

/* ------------------------------------------------------------ */

/* sws  for file io */
#include <stdio.h>
#include <stdlib.h>

#if HAVE_STRING_H
/* sws  for trs2str */
#include <string.h>
#endif

/* can be 0,1,2 */
#define BOXDEBUG 0

/* for dformat */
#define FMTDEBUG 0

/* ------------------------------------------------------------ */
/* local variables */

/* printing precision width:  .bxpp 
   change to: 
   (#pp),(int switch d->g),(int width),(real digits) */
int aplc_ppw[] = {7,1e7,7,7};

/* add this to aplc_ppw to get the field width for reals 
   "-.e+000" with 1 space */
#define REALWIDTHX 8

/* sum of the above + margin */
#define REALWIDTHM 40
/* some char vectors */

/* used by sprintf_double* */
static char stemp[REALWIDTHM];

/* used by dformat */
static char ci[8*REALWIDTHM];
/* used by format */
static char czt[8*REALWIDTHM];
static char cq[8][REALWIDTHM];

static char blanks[]=" ";

/* ------------------------------------------------------------ */
/* local function declarations */

static double round_p(double x, int p);
static double round_pd(double x, int p);

/*static int sprint_ns(char *c, double r);*/
static int sprint_ns(char *c, int w, int p, double r);

static int sprintf_double(char *c, int width, int prec, double r);

static int sprintf_double_count(char *c, int width, int prec, double r);
static int sprintf_complex(char *text, int width, int prec, 
			   double *z[2], int i);
static int sprintf_quat(char *text, int width, int prec, 
			double *q[4], int i);
static int sprintf_oct(char *text, int width, int prec, 
		       double *o[8], int i);

static void format_int(char *text, int w, int x);
static void format_real(char *text, int w, int p, double *x);
static void format_complex(char *text,int wa[2], 
			  int wt, int w[2], int p, double *z[2], int i);
static void format_quat(char *text,int wa[2], 
			int wt, int w[4], int p, double *z[4], int i);
static void format_oct(char *text,int wa[8], 
		       int wt, int w[8], int p, double *z[8], int i);

static int get_act_width(char *c);

static int testwidth(double x, int width, int prec);

static int get_typen(int type);

extern void aplc_prnim(int *a,int m,int n, char *s);

/* ------------------------------------------------------------ */

/* use for left adjustment - not the whole answer... */
#define LAD 0

/* round x to p significant digits 
   used for exponential format  */
static double 
round_p(double x, int p)
{
  double xa, xsc;

  if (x == 0.0)
    return 0.0;

  xa = fabs(x);
  xsc = pow(10.0, floor(log10(xa)) + 1 - p);
  xa = floor(0.5 + xa/xsc)*xsc;
  /*fprintf(aplcerr,"(x %g p %d, xsc %g xa %g)\n", x, p, xsc,xa);*/
  /* now don't change sign if we've removed everything */
  if (xa == 0.0)
    return xa;
  if (x<0.0)
    return -xa;
  else
    return xa;
}

/* round x to p digits past decimal point 
   used for apl "f" style format */
static double 
round_pd(double x, int p)
{
  double xa, xsc;

  if (x == 0.0)
    return 0.0;

  xa = fabs(x);
  xsc = pow(10.0, (double) p);
  xa = floor(0.5 + xa*xsc)/xsc;
  /*fprintf(aplcerr,"(x %g p %d, xsc %g xa %g)\n", x, p, xsc,xa);*/
  /* now don't change sign if we've removed everything */
  if (xa == 0.0)
    return xa;
  if (x<0.0)
    return -xa;
  else
    return xa;
}


/* sws
   sprint_ns - special print for numbers

   - maintain precision (aplc_ppw) by varying total width
   - leave no spaces
   - on some machines (sparc/solaris, intel/linux) 
     0.0 can be signed, prints out as -0; don't allow this 
   - return size
  
   integers  " -nnnnn" (7)
   added fix for the reals, max size assuming " -x.nnnnnE-mmm" (14)
*/

static int
sprint_ns(char *c, int w, int p, double r)
{
  int sg;
  char temp[REALWIDTHM];
  int i,j;

  if (r == 0.0) {
    /* special case */
    j = 1;
    sprintf(c, "%*.0f", j, 0.0); 
    return j;
  }
  if (r < 0)
    sg = 1;
  else
    sg = 0;
  sprintf(temp, "%*.*g", w, p, r);    
  for (i=0,j=0; i<w; i++) {
    if (temp[i] != ' ')
      c[j++] = temp[i];
  }
  c[j] = '\0';
  return j;
}

/* -------------------------------------------- */
/* routines that use format patterns */



/* special sprintf, for doubles 
   c    is output string
   prec is precision
   r    is the number
*/
static int
sprintf_double(char *c, int width, int prec, double r)
{
  int i, w;
  /*char fms[] = "%-*.*f";  */
  char fmse[] = "%*.*e";
  char fmsf[] = "%*.*f";

#if 0
  fprintf(aplcerr,"r %g, width %d, prec %d\n", r, width,prec);
#endif
  /* check for special case 0, to eliminate -0 */
  if (0.0 == r) {
    if (prec >= 0)
      sprintf(stemp, fmsf, width, prec, 0.0);
    else
      sprintf(stemp, fmse, width, -1-prec, 0.0);
  } else if (prec >= 0) {
    /*sprintf(c, fms, width, prec, r);*/
    sprintf(stemp, fmsf, width, prec, round_pd(r, prec));
  } else {
    sprintf(stemp, fmse, width, -1-prec, round_p(r, -prec));
  }
  w = strlen(stemp);
  if (w <= width) {
    for (i=0; i<w; i++)
      c[i] = stemp[i];
  } else {
    fprintf(aplcerr,"[DFormat] width = %d (need %d), p %d, %g -> [%s]", 
	    width, w, prec, r, stemp);
    aplc_error("DFormat domain error, field width too small");
  }
#if 0
  fprintf(aplcerr,"%g -> [%s] w %d\n", r, stemp,w);
#endif
  return w;
}

/* special sprintf, for doubles 
   left adjusted
   return the actual width of a string non-blanks needed, including the \0
 */
static int
sprintf_double_count(char *c, int width, int prec, double r)
{
  /*char fms[] = "%-*.*f"; */
  char fmse[] = "%*.*e";
  char fmsf[] = "%*.*f";
  int i, k;

  /* check for special case 0, to eliminate -0 */
  if (0.0 == r)
    sprintf(stemp, fmsf, width, prec, 0.0);
    /*fprintf(stderr,"{%s}", c);*/
  else if (prec >= 0) {
    /*sprintf(temp, fms, width, prec, r);*/
    sprintf(stemp, fmsf, width, prec, round_p(r, prec));
  } else {
    sprintf(stemp, fmse, width, -1-prec, round_p(r, -prec));
  }
  for (i=0,k=0; stemp[i] != '\0'; i++) {
    if (stemp[i] != ' ') {
      c[k] = stemp[i];
      k++;
    }
  }
  c[k] = '\0';
  /*fprintf(stderr,"{%g %g}\n", r, round_p(r, 1+prec));*/
  /*fprintf(stderr,"{k%d,c%s}\n", k,c);*/
  return k;
}

/* return width needed for the format 
*/
static int
sprintf_complex(char *text, int width, int prec, double *z[2], int i)
{
  int wi[2];
  int wa[2];
  int wc, wta;
  int j,k;

#if 0
  fprintf(stderr,"[sprintf_complex] w%d,p%d z (%g %g) i %d\n", 
	  width,prec, z[0][i],z[1][i],i);
#endif
  /* check for special case 0 */
  if (1.0 == 1.0 + z[1][i]) {
    /* purely real */
    wa[0] = sprintf_double_count(cq[0], width, prec, z[0][i]);
    k = width - wa[0];
    if (k > 0)
      sprintf(text,"%*.0s%s", k,blanks,cq[0]);
    else
      sprintf(text,"%s", cq[0]);
    return wa[0];
  }
  /* really complex case */
  wc = (width-1)/2;
  wta = 1;
  for (j=0; j<2; j++) {
    wi[j] = wc;
    wa[j] = sprintf_double_count(cq[j], wi[j], prec, z[j][i]);
    wta += wa[j];
  }
  k = width - wta;
#if 0
  fprintf(stderr,"{[%s]%d,[%s]%d,%d}", cq[0],wa[0],cq[1],wa[1],k);
#endif
  if (k > 0)
    sprintf(text,"%*.0s%si%s", k,blanks,cq[0],cq[1]);
  else if (k == 0) {
    sprintf(text,"%si%s", cq[0],cq[1]);
  } else {
    /* error */
    fprintf(aplcerr,"[DFormat] complex, width = %d (need %d), [%si%s]", 
	    width,wta, cq[0],cq[1]);
    aplc_error("DFormat domain error, field width too small");
  }
#if 0
  fprintf(stderr,"[%s] %d\n", text, wta);
#endif
  return wta;
}

/* return width needed for the format 
*/
static int
sprintf_quat(char *text, int width, int prec, double *z[4], int i)
{
  int wa[4];
  int wc, wta;
  int j,k;
  char units[] = " ijk";
  char *tmp;

  wc = (width-1)/4;
  k = width;
  for (j=0; j<4; j++) {
    if (j == 0) {
      wa[j] = sprintf_double_count(cq[j], wc, prec, z[j][i]);
      k -= wa[j];
    } else {
      if ( 1.0 == 1.0 + z[j][i] )
	wa[j] = 0;
      else {
	wa[j] = sprintf_double_count(cq[j], wc, prec, z[j][i]);
	k -= 1+wa[j];
      }
    }
  }
  wta = width - k;
  if (k > 0)
    tmp = text + sprintf(text,"%*.0s%s", k,blanks, cq[0]);
  else
    tmp = text + sprintf(text,"%s", cq[0]);
  for (j=1; j<4; j++) {
    if (wa[j] > 0) 
      tmp += sprintf(tmp,"%c%s", units[j], cq[j]);
  }
  if (k < 0) {
    /* error */
    fprintf(aplcerr,"[DFormat] quat, width = %d (need %d), ", 
	    width, wta);
    aplc_error("DFormat domain error, field width too small");
  }
  return wta;
}


/* return width needed for the format 
*/
static int
sprintf_oct(char *text, int width, int prec, double *z[8], int i)
{
  int wa[8];
  int wc, wta;
  int j,k;
  char units[] = " ijkUIJK";
  char *tmp;

  wc = (width-1)/8;
  k = width;
  for (j=0; j<8; j++) {
    if (j == 0) {
      wa[j] = sprintf_double_count(cq[j], wc, prec, z[j][i]);
      k -= wa[j];
    } else {
      if ( 1.0 == 1.0 + z[j][i] )
	wa[j] = 0;
      else {
	wa[j] = sprintf_double_count(cq[j], wc, prec, z[j][i]);
	k -= 1+wa[j];
      }
    }
  }
  wta = width - k;
  if (k > 0)
    tmp = text + sprintf(text,"%*.0s%s", k,blanks, cq[0]);
  else
    tmp = text + sprintf(text,"%s", cq[0]);
  for (j=1; j<8; j++) {
    if (wa[j] > 0) 
      tmp += sprintf(tmp,"%c%s", units[j], cq[j]);
  }
  if (k < 0) {
    /* error */
    fprintf(aplcerr,"[DFormat] oct, width = %d (need %d), ", 
	    width, wta);
    aplc_error("DFormat domain error, field width too small");
  }
  return wta;
}

/* -------------------------------------------- */
/* printit - print a scalar object 
   res: object
   type: type of object
   nls:  number of newlines after 
*/
extern void
aplc_printit(union res_struct * res, int type, int nls)
{
  int realwidth;
  int i, w, nb;

  switch (type) {
  case APLC_CHAR:
    fprintf(aplcout,"%c", res->c);
    break;
  case APLC_BOOL:
  case APLC_INT:
    fprintf(aplcout,"%*d", aplc_ppw[1], res->i);
    break;
  case APLC_REAL:
    /* fprintf(aplcout,"%*g", aplc_ppw[3], res->r); */
    realwidth = aplc_ppw[3] + REALWIDTHX;
    if (0.0 == res->r)
      fprintf(aplcout,"%*.0s0",realwidth-1,blanks);/* don't allow -0 */
    /*fprintf(aplcout," 0"); */
    else      
    fprintf(aplcout,"%*.*g", realwidth, aplc_ppw[3], res->r);
    break;
  case APLC_COMPLEX:
    /* have to remove all spaces around the i */
    realwidth = aplc_ppw[3] + REALWIDTHX;
    w = sprint_ns(cq[0], realwidth, aplc_ppw[3], res->z[0]);
    w += sprint_ns(cq[1], realwidth, aplc_ppw[3], res->z[1]);
    nb = 2*realwidth - 2-w;
    if (nb > 0)
      fprintf(aplcout," %*.0s%si%s", nb,blanks,cq[0],cq[1]);
    else
      fprintf(aplcout," %si%s", cq[0],cq[1]);
    break;
  case APLC_QUAT:
    /* have to remove all spaces around the i */
    realwidth = aplc_ppw[3] + REALWIDTHX;
    for (i=0, w=0; i<4; i++)
      w +=sprint_ns(cq[i], realwidth, aplc_ppw[3], res->q[i]);
    /*fprintf(aplcout," %si%sj%sk%s", cq[0],cq[1],cq[2],cq[3]);*/
    /*fprintf(aplcout," %.*s%si%sj%sk%s", (4*realwidth - 4-w),blanks,
	    cq[0],cq[1],cq[2],cq[3]);*/
    nb = 4*realwidth - 4-w;
    if (nb > 0)
      fprintf(aplcout," %*.0s%si%sj%sk%s", nb,blanks,
	      cq[0],cq[1],cq[2],cq[3]);
    else
      fprintf(aplcout," %si%sj%sk%s", cq[0],cq[1],cq[2],cq[3]);
    break;
  case APLC_OCT:
    /* have to remove all spaces around the i */
    realwidth = aplc_ppw[3] + REALWIDTHX;
    for (i=0, w=0; i<8; i++)
      w +=sprint_ns(cq[i], realwidth, aplc_ppw[3], res->o[i]);
    nb = 8*realwidth - 8 - w;
    if (nb > 0)
      fprintf(aplcout," %*.0s%si%sj%sk%sU%sI%sJ%sK%s", nb,blanks,
	      cq[0],cq[1],cq[2],cq[3],
	      cq[4],cq[5],cq[6],cq[7]);
    else
      fprintf(aplcout," %si%sj%sk%sU%sI%sJ%sK%s", 
	      cq[0],cq[1],cq[2],cq[3],
	      cq[4],cq[5],cq[6],cq[7]);
    break;
  default:
    aplc_error("aplc_printit run-time type error \n");
    break;
  }
  for (; nls > 0; nls--)
    fprintf(aplcout,"\n");
}

/* aplc_bmpnl -
   figure out how many newlines to add,
   after printing a particular index */
extern int
aplc_bmpnl(int iindex, int rank, int *shape)
{
  int temp, i, counter;

  /* sws - added fix for scalar */
  if (rank <= 0)
    return (1);

  i = rank - 1;
  counter = 0;
  temp = 1;
  while (i >= 0) {
    temp *= shape[i];
    if (((iindex + 1) % temp) == 0) {
      counter++;
      i--;
    } else
      break;
  }
  /* sws - end of an array only has one nl */
  if (counter >= rank)
    counter = 1;
  return (counter);
}

/* ------------------------------------------------------------ */

/* sws
   function to test field width of a double

   (width, prec) format x

   return
     1 if ok
     0 if width too small
   

   n 0  precision so far...
*/
static int
testwidth(double x, int width, int prec)
{
  int w;
  double l;

  /* first get minimum field width required */
  /* check precision */
  if (prec >= 0) {
    /* f format */

    /* first get space left of the decimal point */
    if (x > 0) {
      l = log10(x);
      w = ((l > 0) ? ceil(l) : 1);
    } else if (x < 0) {
      l = log10(-x);
      w = 1 + ((l > 0) ? ceil(l) : 1);
    } else
      w = 1;

    /* now check for decimals */
    if (prec > 0)
      w += prec + 1;
  } else {
    /* prec < 0 */
    /* e format */
    /* add space for minus mantissa */
    /* note we will have n.nnne+nn cases */
    w = (x < 0) + 5 - prec;
  }

  /* now test needed width against that supplied */
  if (width >= w)
    return (1);
  else {
    /* error */
    fprintf(aplcerr,"[DFormat] width = %d (need %d), ", width, w);
    if (prec > 0)
      fprintf(aplcerr,"number = [%1.*f]\n", prec, x);
    else if (prec == 0)
      fprintf(aplcerr,"number = [%1.0f]\n", x);
    else
      fprintf(aplcerr,"number = [%1.*e]\n", -prec - 1, x);
    aplc_error("DFormat domain error, field width too small");
    return (0);
  }
}

/* get the number of components in a given number type */
static int
get_typen(int type)
{
  switch(type) {
  default:
    fprintf(aplcerr, "[get_typen] type %d \n", type);
    aplc_error("[get_typen] unknown type");
    break;

  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_LABEL:
    return 1;
    break;
  case APLC_COMPLEX:
    return 2;
    break;
  case APLC_QUAT:
    return 4;
    break;
  case APLC_OCT:
    return 8;
    break;
  }
  return 1;
}

/* ------------------------------------------------------- */
/* dyadic format */
/* left shape cases
   - scalar: same as 0 n (after STSC)
   - vector:
       length 2
       length 2n
*/
extern void
aplc_dformat(struct trs_struct * res,
	     struct trs_struct * left, struct trs_struct * right)
{
  union mp_struct mptemp;
  union mp_struct rtemp;
  int *pattern, *npattern;
  int *ptemp;
  int i, j, rsize, size, coln;
  int realwidth;
  /*int fieldw;*/
  int ltype, lrank;
  int *lshape, lshapet;
  int type, rank;
  int *shape;
  int width = 0;
  int dec = 0;
  /* hope we need less than 20 */
  /*char pad[] = "00000000000000000000";*/
  int wt; 
  int flag_as = 0; /* auto scale */
  int flag_alloc = 0;

#if FMTDEBUG
  fprintf(aplcerr,"[aplc_dformat]\n");
#endif

  type = right->type;
  rank = right->rank;
  shape = right->shape;
  ltype = left->type;
  lrank = left->rank;
  lshape = left->shape;

  if (type == APLC_CHAR) {
    /* just pass it on */
    /*res = right;*/
    aplc_duptrs(res, right);
    return;
  }

  aplc_inittrs(res);
  res->type = APLC_CHAR;
  /* setup new shape vector */
  /* check for scalar right */
  if (rank == 0) {
    res->rank = 1;
    rsize = 1;		     /* size of right */
    res->shape = aplc_dsval(1);
    coln = 1;			     /* number of columns */
  } else {
    res->rank = rank;
    aplc_vectalloc(&mptemp, rank, APLC_INT);
    res->shape = mptemp.ip;
    for (i = 0, rsize = 1; i < rank; i++) {
      res->shape[i] = shape[i];
      rsize *= shape[i];
    }
    coln = shape[rank - 1];	     /* number of columns */
  }
  res->alloc_ind = APLC_ALLOC_SHAPE_F;
  /* sws  for debugging */
#if FMTDEBUG
  printf("\n rank %d, rsize %d, shape[0] %d, res->shape[0] %d\n" ,rank,
	 rsize, shape[0], res->shape[0]);
  printf("\n shape[1] %d, res->shape[1] %d\n", shape[1], res->shape[1]);
  printf("\n coln %d\n", coln);
  printf("\n lrank %d\n", lrank);
#endif
  /* check length of left */
  if ((lrank != 0) && (*lshape > 2) && (*lshape != 2 * coln)) {
    fprintf(aplcerr,"lrank = %d, lshape[0] = %d, coln = %d\n",
	    lrank, *lshape, coln);
    aplc_error("[DFormat] length error");
  }
  pattern = (left->value).ip;  /* shorthand */
  npattern = pattern;/* for lint */

  /* check for 
     scalar : means fw = 0
     fw = 0 : autosize columns

     if any fw are 0, set a flag and build space for  patterns for each column
  */ 
  switch( lrank ) {
  default:
    aplc_error("[DFormat] left rank error, need scalar or vector");
    break;
  case 0:
    /* scalar */
    flag_as = 1;
    break;
  case 1:
    /* vector */
    for (i=0; i<lshape[0]; i+=2) {
      if (pattern[i] == 0)
	flag_as = 1; 
    }
    break;
  }
  if (flag_as) {
    /* build a pattern vector of size shape[rank-1]*2 */
    if (rank > 0) {
      lshapet = 2*shape[rank-1];
    } else { /* right is a scalar */
      lshapet = 2;
    }
    aplc_vectalloc(&mptemp, lshapet, APLC_INT);
    npattern = mptemp.ip;
    flag_alloc = 1;
    /* fill new pattern with initial values */
    for (i = 0, j = 0; i < rsize; i++) {
      if (lrank == 0) {
	npattern[j] = 0;
	npattern[j+1] = *pattern;
      } else if  (lshape[0] == 2) {
	npattern[j] = pattern[0];
	npattern[j+1] = pattern[1];
      } else {	
	npattern[j]   = pattern[j];
	npattern[j+1] = pattern[j + 1];
      }
      j = (j + 2) % (2 * coln);
    } /* pattern fill loop */

#if FMTDEBUG
    aplc_prnim( npattern,1,lshapet,"npattern0");
#endif
    /* now format everything, get real size */
    rtemp = right->value;
    switch(type) {
    default:
      aplc_error("[DFormat] domain error, unknown type");
      break;
    
    case APLC_BOOL:
    case APLC_INT:
      realwidth = REALWIDTHM;
      for (i=0, j=0; i<rsize; i++) {
	sprintf_double(ci, realwidth, npattern[j+1], (double) (*rtemp.ip++));
	npattern[j] = max(npattern[j], 1+get_act_width(ci));
	j = (j + 2) % (2 * coln);
      }
      break;
    case APLC_REAL:
      realwidth = REALWIDTHM;
      for (i=0, j=0; i<rsize; i++) {
	sprintf_double(ci, realwidth, npattern[j+1], (*rtemp.rp++));
	/*fprintf(aplcerr,"ci %s\n",ci);*/
	npattern[j] = max(npattern[j], 1+get_act_width(ci));
	j = (j + 2) % (2 * coln);
      }
      break;
    case APLC_COMPLEX:
      realwidth = 2*REALWIDTHM;
      for (i=0, j=0; i<rsize; i++) {
	sprintf_complex(ci, realwidth, npattern[j+1], rtemp.zp, i);
	npattern[j] = max(npattern[j], 1+get_act_width(ci));
	j = (j + 2) % (2 * coln);
      }
      break;
    case APLC_QUAT:
      realwidth = 4*REALWIDTHM;
      for (i=0, j=0; i<rsize; i++) {
	sprintf_quat(ci, realwidth, npattern[j+1], rtemp.qp, i);
	npattern[j] = max(npattern[j], 1+get_act_width(ci));
	j = (j + 2) % (2 * coln);
      }
      break;
    case APLC_OCT:
      realwidth = 8*REALWIDTHM;
      for (i=0, j=0; i<rsize; i++) {
	sprintf_oct(ci, realwidth, npattern[j+1], rtemp.op, i);
	npattern[j] = max(npattern[j], 1+get_act_width(ci));
	j = (j + 2) % (2 * coln);
      }
      break;
    } /* end of type switch */
#if FMTDEBUG
    aplc_prnim( npattern,1,lshapet,"npattern1");
#endif
    /* check for replication as well */
    if ( ((lrank == 0) || (lshape[0] == 2)) && ((rank>0) && (coln > 1)) ) {
      wt = 0;
      for (i=0; i<coln; i++) {
	wt = max(wt, npattern[2*i]);
      }      
      for (i=0; i<coln; i++) {
	npattern[2*i] = wt;
      }      
    } /* end replication */
#if FMTDEBUG
    aplc_prnim( npattern,1,lshapet,"npattern2");
#endif
    /* now replace */
    pattern = npattern;
    lrank = 1;
    lshape = &lshapet;
  } /* end of auto width */

  i = (res->rank) - 1;
  if (lrank == 0) {
    /* temporary code for autowidth */
    realwidth = aplc_ppw[3] + REALWIDTHX;
    res->shape[i] *= realwidth;
    width = realwidth;
    dec = *pattern;
  } else if (lshape[0] == 2) {
    res->shape[i] *= pattern[0];
    width = pattern[0];
    dec = pattern[1];
  } else {
    ptemp = pattern;
    res->shape[i] = 0;
    for (j = 0; j < coln; j++) {
      res->shape[i] += *ptemp;
      ptemp += 2;
    }
  }
  if (INT_MAX < (rsize * (double) res->shape[i]) + 1) {
    printf("\n size %g, max %g \n", (rsize * (double) res->shape[i]) + 1,
	   (double) INT_MAX);
    aplc_error("[DFormat] limit error: size too big");
  }    

  size = (rsize * res->shape[i]) + 1;
#if FMTDEBUG
  printf("\n size %d, rsize %d, res->shape[%d] %d\n", size, rsize, 
	 i, res->shape[i]); 
#endif
  aplc_vectalloc(&mptemp, size, APLC_CHAR);
  res->value = mptemp;
  rtemp = right->value;


  /* check argument type */
  switch(type) {

  default:
    aplc_error("[DFormat] domain error, unknown type");
    break;

  case APLC_BOOL:
  case APLC_INT:
    if ((lrank == 0) || (lshape[0] == 2)) {
      /* only one width, dec to worry about */
      /*printf("\nwidth %d, dec %d\n", width, dec);*/
      for (i = 0; i < rsize; i++) {
	mptemp.cp += sprintf_double(mptemp.cp, width, dec, (double) (*rtemp.ip++));
      }
    } else {
      /* width, dec change with each column */
      for (i = 0, j = 0; i < rsize; i++) {
	width = pattern[j];
	dec = pattern[j + 1];
	testwidth((double) *rtemp.ip, width, dec);
	mptemp.cp += sprintf_double(mptemp.cp, width, dec, (double) (*rtemp.ip++));
	j = (j + 2) % (2 * coln);
      }
    }
    break;

  case APLC_REAL:
#if FMTDEBUG
    fprintf(aplcerr,"[real]\n");
#endif
    if ((lrank == 0) || (lshape[0] == 2)) {
      /* only one width, dec to worry about */
#if FMTDEBUG
      printf("\nwidth %d, dec %d, rsize %d\n", width, dec, rsize);
#endif
      for (i = 0; i < rsize; i++) {
	/* sws   debugging */
	/* printf("\n[%*.0f]\n", width, (*rtemp.rp++)); */
	sprintf_double(mptemp.cp, width, dec, (*rtemp.rp++));
	mptemp.cp += width;
      }
    } else {
      /* width, dec can change with each column */
      for (i = 0, j = 0; i < rsize; i++) {
	width = pattern[j];
	dec = pattern[j + 1];
	sprintf_double(mptemp.cp, width, dec, (*rtemp.rp++));
	mptemp.cp += width;
	j = (j + 2) % (2 * coln);
      }
    }
    break;

  case APLC_COMPLEX:
    if ((lrank == 0) || (lshape[0] == 2)) {
      /* only one width, dec to worry about */
      /* printf("\nwidth %d, dec %d\n", width, dec); */
      for (i = 0; i < rsize; i++) {
	sprintf_complex(mptemp.cp, width,dec, rtemp.zp, i);
	mptemp.cp += width;
      }
    } else {
      /* width, dec can change with each column */
      for (i = 0, j = 0; i < rsize; i++) {
	width = pattern[j];
	dec = pattern[j + 1];
	sprintf_complex(mptemp.cp, width,dec, rtemp.zp, i);
	mptemp.cp += width;
	j = (j + 2) % (2 * coln);
      }
    }
    break;/* end of complex case */
  case APLC_QUAT:
    if ((lrank == 0) || (lshape[0] == 2)) {
      /* only one width, dec to worry about */
      for (i = 0; i < rsize; i++) {
	/* sws   debugging */
	/* printf("\n[%*.0f]\n", width, (*rtemp.rp++)); */
	/* test to make sure we have enough space */
	sprintf_quat(mptemp.cp, width,dec, rtemp.qp, i);
	mptemp.cp += width;
      }
    } else {
      /* width, dec can change with each column */
      for (i = 0, j = 0; i < rsize; i++) {
	width = pattern[j];
	dec = pattern[j + 1];
	wt = sprintf_quat(mptemp.cp, width,dec, rtemp.qp, i);
	mptemp.cp += width;
	j = (j + 2) % (2 * coln);
      }
    }
    break;/* end of quat case */

  case APLC_OCT:
    if ((lrank == 0) || (lshape[0] == 2)) {
      /* only one width, dec to worry about */
      for (i = 0; i < rsize; i++) {
	/* sws   debugging */
	/* test to make sure we have enough space */
	sprintf_oct(mptemp.cp, width,dec, rtemp.op, i);
	mptemp.cp += width;
      }
    } else {
      /* width, dec can change with each column */
      for (i = 0, j = 0; i < rsize; i++) {
	width = pattern[j];
	dec = pattern[j + 1];
	sprintf_oct(mptemp.cp, width,dec, rtemp.op, i);
	mptemp.cp += width;
	j = (j + 2) % (2 * coln);
      }
    }
    break;/* end of oct case */

  } /* end of right type switch */
  res->alloc_ind |= APLC_ALLOC_VAL_F;
  if (flag_alloc)
    free(npattern);
  return;
}

/* ------------------------------------------------------- */
/* sws 
   split out the format functions */
static void
format_int(char *text, int w, int x)
{
  if ( (abs(x) < aplc_ppw[1]) && (x != INT_MIN) )
    sprintf(text, "%*d", w, x);
  else {
    /*sprintf(text, "%*g", w, (double) x);*/
    /* force exp format */
    /*sprintf(text, "%*e", w, (double) x);*/
    /* force precision */
    sprintf(text, "%*.*e", w, aplc_ppw[2]-1, (double) x);
  }
#if 0
  fprintf(stderr, "o x= %d, abs(x) = %d, -x = %d\n", 
	  (x), (abs(x)), (-x));
  fprintf(stderr, "o aplc_ppw [%d %d %d]\n", 
	  aplc_ppw[0], aplc_ppw[1], aplc_ppw[2]);
  fprintf(stderr, "o text [%s], w %d, x %d\n", text, w,x);
#endif
  return;
}

/* ------------------------------------------------------- */
/* sws
   format reals
   special case, some systems print -0; 
   even though -0 == 0 */
static void
format_real(char *text, int w, int p, double *x)
{
#if LAD
  if (0.0 == *x)
    sprintf(text, "%-*.2g", w, 0.0);
  else
    sprintf(text, "%-*.*g", w, p, *x);
#else
  if (0.0 == *x)
    sprintf(text, "%*.2g", w, 0.0);
  else
    sprintf(text, "%*.*g", w, p, *x);
#endif
  return;
}

/* ------------------------------------------------------- */
/* format a complex number
   input:
    total width wt      require: wt >= w[0]+w[1]+1
    width of each w[2]
    precision p
    complex array z
    index i
   output
    text
    wa[2] actual widths of each component (not counting the i) 
   */
static void
format_complex(char *text,int wa[2], 
	       int wt, int w[2], int p, double *z[2], int i)
{
  int k;

  if (1.0 == 1.0 + z[1][i]) {
    /* purely real */
    wa[0] =  sprint_ns(cq[0], w[0],p, z[0][i]);
    wa[1] = 0;
    k = wt - wa[0];
    if (k > 0)
      sprintf(text,"%*.0s%s", k,blanks,cq[0]);
    else
      sprintf(text,"%s", cq[0]);
    /*fprintf(stderr,"text [%s], wa (%d %d), wt %d, w(%d %d)\n", 
	    text,wa[0],wa[1], wt,w[0],w[1]);*/
    return;
  }
  wa[0] = sprint_ns(cq[0], w[0],p, z[0][i]);
  wa[1] = sprint_ns(cq[1], w[1],p, z[1][i]);
  k = wt - (1 + wa[0]+wa[1]);
  if (k > 0)
    sprintf(text,"%*.0s%si%s", k,blanks,cq[0],cq[1]);
  else
    sprintf(text,"%si%s", cq[0],cq[1]);
  /*fprintf(stderr,"text %s, wa (%d %d)\n", text,wa[0],wa[1]);*/
  /*fprintf(stderr,"text [%s], wa (%d %d), wt %d, w(%d %d)\n", 
	  text,wa[0],wa[1], wt,w[0],w[1]);*/
  return;
}

/* ------------------------------------------------------- */
/* format a quaternion
   input:
    total width wt      require: wt >= 1 + sum w[j]
    width of each w[4]
    precision p
   output
    text
    wa[4] actual widths
   */
static void
format_quat(char *text,int wa[4], 
	    int wt, int w[4], int p, double *z[4], int i)
{
  int j,k;
  char units[] = " ijk";
  char *tmp;

  k = wt;
  for (j=0; j<4; j++) {
    if (j == 0) {
      wa[j] = sprint_ns(cq[j], w[j],p, z[j][i]);
      k -= wa[j];
    } else {
      if ( 1.0 == 1.0 + z[j][i] )
	wa[j] = 0;
      else {
	wa[j] = sprint_ns(cq[j], w[j],p, z[j][i]);
	k -= 1+wa[j];
      }
    }
  }
  if (k > 0)
    tmp = text + sprintf(text,"%*.0s%s", k,blanks, cq[0]);
  else
    tmp = text + sprintf(text,"%s", cq[0]);
  for (j=1; j<4; j++) {
    if (wa[j] > 0) 
      tmp += sprintf(tmp,"%c%s", units[j], cq[j]);
  }
  /*fprintf(stderr,"text [%s], wa (%d %d %d %d), wt %d, w(%d %d %d %d)\n", 
	  text,wa[0],wa[1],wa[2],wa[3], 
	  wt,w[0],w[1],w[2],w[3]);*/
  return;
}

/* ------------------------------------------------------- */
/* format an octonion
   input:
    total width wt      require: wt >= 1 + sum w[j]
    width of each w[8]
    precision p
   output
    text
    wa[8] actual widths
   */

static void
format_oct(char *text,int wa[8], 
	   int wt, int w[8], int p, double *z[8], int i)
{
  int j,k;
  char units[] = " ijkUIJK";
  char *tmp;

  k = wt;
  for (j=0; j<8; j++) {
    if (j == 0) {
      wa[j] = sprint_ns(cq[j], w[j],p, z[j][i]);
      k -= wa[j];
    } else {
      if ( 1.0 == 1.0 + z[j][i] )
	wa[j] = 0;
      else {
	wa[j] = sprint_ns(cq[j], w[j],p, z[j][i]);
	k -= 1+wa[j];
      }
    }
  }
  if (k > 0)
    tmp = text + sprintf(text,"%*.0s%s", k,blanks, cq[0]);
  else
    tmp = text + sprintf(text,"%s", cq[0]);
  for (j=1; j<8; j++) {
    if (wa[j] > 0) 
      tmp += sprintf(tmp,"%c%s", units[j], cq[j]);
  }
  return;
}

/* ------------------------------------------------------- */
/* sws 
   get actual width of string -- only count non blanks */
static int
get_act_width(char *c)
{
  int i, n, w;

  /*fprintf(stderr, "c %s\n", c);*/
  n = strlen(c);
  w = 0;
  for (i=0; i<n; i++)
    if (' ' !=c[i])
      w++;
  /*fprintf(stderr, "w %d\n", w);*/
  return w;
}

/* ------------------------------------------------------- */

/* get dimensions of argument converted to a matrix 
   expect int s[2] */
static void
get_mat_dim(int *s,
	    int rank, int *shape )
{
  int i;
  
  if (rank < 2)
    s[0] = 1;/* scalar or vector */
  else {
    s[0] = shape[rank-2];
    for (i=0; i<rank-2; i++)
      s[0] = (s[0]+1)*shape[rank-3-i];
    s[0] -= rank-2;
  }
  if (rank <1)
    s[1] = 1;/* scalar */
  else 
    s[1] = shape[rank-1];
  return;
}

/* turn a character array into a matrix
   - with appropriate blank lines as would be printed 
   - handle 0 size right */
static void
char_array_to_matrix(struct trs_struct *res, struct trs_struct *right)
{
  union mp_struct mptemp;
  int i,j,k, ic;

  /*aplc_print_trs(right->value.trsp[0]);*/
  res->type = APLC_CHAR;
  res->rank = 2;
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  if (right->rank <2) {
    /* scalar or vector right; result is matrix */
    aplc_vectalloc(&mptemp, res->rank, APLC_INT);
    res->shape = mptemp.ip;
    res->shape[0] = 1;
    if (right->rank <1) 
      res->shape[1] = 1;
    else
      res->shape[1] = right->shape[right->rank-1];
    res->size = aplc_vsize(res->rank, res->shape);
    aplc_vectalloc(&res->value, res->size, APLC_CHAR);
    k = 0;
    for (i=0; i<right->size; i++)
      res->value.cp[k++] = right->value.cp[i];
  } else {
    /* right is matrix or better */
    aplc_vectalloc(&mptemp, res->rank, APLC_INT);
    res->shape = mptemp.ip;
    get_mat_dim(res->shape, right->rank, right->shape);
    res->size = aplc_vsize(res->rank, res->shape);
    aplc_vectalloc(&res->value, res->size, APLC_CHAR);
    k = 0;
    for (j=0; j<right->size; ) {
      for (i=0; i<res->shape[1]; i++)
	res->value.cp[k++] = right->value.cp[j++];
      /* check for extra space */
      ic = aplc_bmpnl(j-1, right->rank, right->shape);
      for (; ic>1; ic--) {
	for (i=0; i<res->shape[1]; i++)
	  res->value.cp[k++] = ' ';
      }
    }
  }
  /* aplc_print_trs(res);*/
  return;
}

/* add box characters to a matrix 
   can be used for a single term or part of a matrix of
   boxed components
   (i1,i2) index
*/
static void
char_box_matrix(struct trs_struct *res, struct trs_struct *right,
		int i1, int i2)
{
  union mp_struct mptemp;
  int i,j,k, p, ic;

  res->type = APLC_CHAR;
  res->rank = 2;
  aplc_vectalloc(&mptemp, res->rank, APLC_INT);
  res->shape = mptemp.ip;
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  if (i1)
    res->shape[0] = right->shape[0]+1; 
  else
    res->shape[0] = right->shape[0]+2; 
  if (i2)
    res->shape[1] = right->shape[1]+1;
  else
    res->shape[1] = right->shape[1]+2;

  res->size = aplc_vsize(res->rank, res->shape);
  aplc_vectalloc(&res->value, res->size, APLC_CHAR);
  /* now the values */
  k = 0;
  /* first row - only do if we're at the top */
  if (i1==0) {
    if (i2==0)
      res->value.cp[k++] = '+';
    for (i=0; i<right->shape[1]; i++)
      res->value.cp[k++] = '-';
    res->value.cp[k++] = '+';
  }
  p = 0; 
  for (i=0; i<right->shape[0]; i++ ) {
    if (i2==0)
      res->value.cp[k++] = '|';
    for (j=0; j<right->shape[1]; j++)
      res->value.cp[k++] = right->value.cp[p++];
    res->value.cp[k++] = '|';
    /* check for extra space */
    if (p>0)
      ic = aplc_bmpnl(p-1, right->rank, right->shape);
    else
      ic = 0; /* nothing in right */
    for (; ic>1; ic--) {
      res->value.cp[k++] = '|';
      for (i=0; i<right->shape[1]; i++)
	res->value.cp[k++] = ' ';
      res->value.cp[k++] = '|';
    }
  }
  /* last row */
  if (i2==0)
    res->value.cp[k++] = '+';
  for (i=0; i<right->shape[1]; i++)
    res->value.cp[k++] = '-';
  res->value.cp[k++] = '+';
  return;
}

/* print an integer matrix to the screen */
/* print an integer matrix to the screen 

  inputs
    a[m,n]  the matrix
    m,n     dimensions
    s       string to print  (an = is added)

  e.g. 
    s = a

note either m or n can be 1 - column or row vector */
extern void
aplc_prnim(int *a,int m,int n, char *s)
{
  int i,j;

  printf("%s = ",s);
  if (m != 1)
    printf("\n");
  for (i=0; i<m; i++){
    for (j=0; j<n; j++){
      printf("%d ",*a++);
    }
    printf("\n");
  }
}

/* monadic format 
   - now each field is just enough to hold the largest element,
     with one space

   - still need to keep columns separate
*/
extern void
aplc_format(struct trs_struct *res, struct trs_struct *right)
{
  union mp_struct mptemp;
  union mp_struct mptemp2;
  union mp_struct mptemp3;
  int *colwidth;
  int ntype, nsize = 1;
  union mp_struct rtemp;
  int i,j,k, ic,rsize, size, coln;
  int realwidth;
  int type, rank;
  int *shape;
  int numsize;
  int wmax;
  int wi[8],wa[8];
  int *wimax;

  /* shorthand */
  type = right->type;
  rank = right->rank;
  shape = right->shape;
  aplc_inittrs(res);
  res->type = APLC_CHAR;
  if (type == APLC_CHAR) {
    /* just pass it on */
    aplc_duptrs(res, right);
    return;
  }

  if (type == APLC_BOXED) {
    struct trs_struct resv, resv2, ress;
    int ss[1];
    int so[3], sfun;
    int *rk, *ck;
    int ioff, p,ip,pr,pc, ix;

    /* loop over structure
       add framing
  b
  +-+-+
  |1|2|
  +-+-+
    $b
  3 5    */

#if BOXDEBUG
    fprintf(stderr, "format box, arg=[\n");
    aplc_print_trs(right);
    fprintf(stderr, "]\n");
#endif    
    /* first build a trs to hold all individual values 
       a boxed type that will be formatted */
    aplc_settrs(&resv, APLC_BOXED, rank, shape);
    aplc_talloc(&resv);
    for (k=0; k<right->size; k++) 
      aplc_format(&resv.value.trsp[k], &right->value.trsp[k]); 

#if BOXDEBUG >1
    fprintf(stderr,"resv (format) =");
    aplc_print_trs(&resv);
#endif
    /* turn each component into a matrix */
    aplc_settrs(&resv2, APLC_BOXED, resv.rank, resv.shape);
    aplc_talloc(&resv2);
    for (k=0; k<right->size; k++) 
      char_array_to_matrix(&resv2.value.trsp[k], &resv.value.trsp[k]); 

#if BOXDEBUG >1
    fprintf(stderr,"resv2 (matrix) =");
    aplc_print_trs(&resv2);
#endif
    /* determine compatible shapes
       setup shape vectors for final print version 
       - up to last 2 dimensions stay the same

       - in a column, with must be constant
       - in a row, height must be constant */ 
    aplc_detalloc(&resv);
    aplc_settrs(&resv, APLC_BOXED, resv2.rank, resv2.shape);
    aplc_talloc(&resv);
    /* outer shape as a rank 3 */ 
    if (resv.rank >1) {
      so[2] = resv.shape[resv.rank-1];
      so[1] = resv.shape[resv.rank-2];
    } else if (resv.rank >0) {
      so[2] = resv.shape[resv.rank-1];
      so[1] = 1;
    } else {
      /* scalar */
      so[2] = 1;
      so[1] = 1;
    }
    sfun = so[1]*so[2];
    if (sfun <1)
      so[0] = 1;
    else
      so[0] = resv.size/sfun;
#if BOXDEBUG >1
    aplc_prnim(resv2.shape,1,resv2.rank,"resv2.shape");
    aplc_prnim(resv.shape,1,resv.rank,"resv.shape");
    aplc_prnim(so,1,3,"so");
#endif
    /* conforming inner shapes */
    aplc_vectalloc(&mptemp, so[1], APLC_INT);
    rk = mptemp.ip;
    for (i=0; i<so[1]; i++)
      rk[i] = 0;
    aplc_vectalloc(&mptemp, so[2], APLC_INT);
    ck = mptemp.ip;
    for (i=0; i<so[2]; i++)
      ck[i] = 0;
    ic = 0;
    for (i=0; i<so[0]; i++) {
      for (j=0; j<so[1]; j++) {
	for (k=0; k<so[2]; k++) {
	  if (rk[j] < resv2.value.trsp[ic].shape[0])
	    rk[j] = resv2.value.trsp[ic].shape[0];
	  if (ck[k] < resv2.value.trsp[ic].shape[1])
	    ck[k] = resv2.value.trsp[ic].shape[1];
	  ic++;
	}      
      }
    }
#if BOXDEBUG >1
    aplc_prnim(rk,1,so[1],"rk");
    aplc_prnim(ck,1,so[2],"ck");
#endif
    /* now have rk, ck 
       - result size is now (rk, ck) 
       - reshape each component using take
       - first built the trs for the shapes */
    ss[0] = 2;
    aplc_settrs(&ress, APLC_INT, 1, ss);
    aplc_vectalloc(&mptemp, 2, APLC_INT);
    ress.value.ip = mptemp.ip;
    ress.alloc_ind |= APLC_ALLOC_VAL_F;
    ic = 0;
    for (i=0; i<so[0]; i++) {
      for (j=0; j<so[1]; j++) {
	ress.value.ip[0] = rk[j];
	for (k=0; k<so[2]; k++) {
	  ress.value.ip[1] = ck[k];
	  aplc_take( &resv.value.trsp[ic], 
		     &ress, &resv2.value.trsp[ic]); 
	  ic++;
	}
      }
    }

    /* box each component 
       - add separator chars */
    aplc_detalloc(&ress);
    aplc_detalloc(&resv2);
    aplc_settrs(&resv2, APLC_BOXED, resv.rank, resv.shape);
    aplc_talloc(&resv2);
    /*    for (k=0; k<resv.size; k++) 
	  char_box_matrix(&resv2.value.trsp[k], &resv.value.trsp[k]); 
    */
    ic = 0;
    for (i=0; i<so[0]; i++) {
      for (j=0; j<so[1]; j++) {
	for (k=0; k<so[2]; k++) {
	  char_box_matrix( &resv2.value.trsp[ic], &resv.value.trsp[ic], j,k); 
	  rk[j] = resv2.value.trsp[ic].shape[0];
	  ck[k] = resv2.value.trsp[ic].shape[1];
	  ic++;
	}
      }
    }

#if 1
    /* join together along last axis */
    aplc_detalloc(&resv);

    res->type = APLC_CHAR;
    /* adjust final result rank */
    res->rank = max(2, resv2.rank);
    aplc_vectalloc(&mptemp, res->rank, APLC_INT);
    res->shape = mptemp.ip;
    res->alloc_ind = APLC_ALLOC_SHAPE_F;
    for (i=0; i<resv2.rank-2; i++)
      res->shape[i] = resv2.shape[i];
    /* adjust last 2 shape components */
    res->shape[ res->rank-1 ] = 0;
    for (i=0; i<so[2]; i++)
      res->shape[ res->rank-1 ] += ck[i];
    res->shape[ res->rank-2 ] = 0;
    for (i=0; i<so[1]; i++)
      res->shape[ res->rank-2 ] += rk[i];
    res->size = aplc_vsize(res->rank, res->shape);
    aplc_talloc(res);
    /* now copy components into result */
    ic = 0;
    ioff = 0;
    ix = 0;
    for (i=0; i<so[0]; i++) {
      for (j=0; j<so[1]; j++) {
	for (k=0; k<so[2]; k++) {
	  /* inner matrix loops */
	  p = 0;
	  ip = 0;
	  for (pr=0; pr<rk[j]; pr++) {
	    for (pc=0; pc<ck[k]; pc++) {
	      /*fprintf(stderr,"ioff= %d, ip=%d, %d\n", ioff,ip,ioff+ip);*/
	      ix = ioff+ip++;
	      res->value.cp[ix] = resv2.value.trsp[ic].value.cp[p++]; 
	    }
	    ip += res->shape[ res->rank-1 ] - ck[k];
	  }
	  /* finished one matrix component */
	  ic++;
	  ioff += ck[k];
	}
	ioff = ix+1; 
      }
    }
    aplc_detalloc(&resv2);
    aplc_free( rk );
    aplc_free( ck );
#if BOXDEBUG
    fprintf(stderr,"res=");
    aplc_print_trs(res);
#endif

#endif

    /* ------------------------------------- */
    /* temporary - grab first component only */
#if 0
    /*aplc_print_trs(resv.value.trsp[0]);*/
    if (resv.value.trsp[0].rank <2) {
      /* scalar or vector right; result is matrix */
      res->rank = 2;
      aplc_vectalloc(&mptemp, res->rank, APLC_INT);
      res->shape = mptemp.ip;
      res->shape[0] = 3;
      if (resv.value.trsp[0].rank <1) 
	res->shape[1] = 3;
      else
	res->shape[1] = 2+resv.value.trsp[0].shape[resv.value.trsp[0].rank-1];
      res->size = aplc_vsize(res->rank, res->shape);
      aplc_vectalloc(&res->value, res->size, APLC_CHAR);
      k = 0;
      res->value.cp[k++] = '+';
      for (i=0; i<resv.value.trsp[0].size; i++)
	res->value.cp[k++] = '-';
      res->value.cp[k++] = '+';
      res->value.cp[k++] = '|';
      for (i=0; i<resv.value.trsp[0].size; i++)
	res->value.cp[k++] = resv.value.trsp[0].value.cp[i];
      res->value.cp[k++] = '|';
      res->value.cp[k++] = '+';
      for (i=0; i<resv.value.trsp[0].size; i++)
	res->value.cp[k++] = '-';
      res->value.cp[k++] = '+';
    } else {
      /* right is matrix or better */
      res->rank = 2;
      aplc_vectalloc(&mptemp, res->rank, APLC_INT);
      res->shape = mptemp.ip;
      get_mat_dim(res->shape, resv.value.trsp[0].rank,
		  resv.value.trsp[0].shape);
      res->shape[0] += 2; 
      res->shape[1] += 2;
      res->size = aplc_vsize(res->rank, res->shape);
      aplc_vectalloc(&res->value, res->size, APLC_CHAR);

      k = 0;
      res->value.cp[k++] = '+';
      for (i=0; i<res->shape[1]-2; i++)
	res->value.cp[k++] = '-';
      res->value.cp[k++] = '+';
      for (j=0; j<resv.value.trsp[0].size; ) {

	res->value.cp[k++] = '|';
	for (i=0; i<res->shape[1]-2; i++)
	  res->value.cp[k++] = resv.value.trsp[0].value.cp[j++];
	res->value.cp[k++] = '|';

	/* check for extra space */
	ic = aplc_bmpnl(j-1, resv.value.trsp[0].rank, 
			resv.value.trsp[0].shape);
	for (; ic>1; ic--) {
	  res->value.cp[k++] = '|';
	  for (i=0; i<res->shape[1]-2; i++)
	    res->value.cp[k++] = ' ';
	  res->value.cp[k++] = '|';
	}
      }
	
      res->value.cp[k++] = '+';
      for (i=0; i<res->shape[1]-2; i++)
	res->value.cp[k++] = '-';
      res->value.cp[k++] = '+';
    }
    /* aplc_print_trs(res);*/
#endif /* #if 0 */
    return;
  }

  /* non boxed case */

#if 0 
  /* maximum width, .bxpp */
  if (aplc_ppw > 70)
    aplc_ppw = 70;
#endif

  /* setup new shape vector */
  /* check for scalar right */
  if (rank == 0) {
    res->rank = 1;
    rsize = 1; /* total size */
    res->shape = aplc_dsval(1);
    coln = 1; /* number of columns */
  } else {
    res->rank = rank;
    aplc_vectalloc(&mptemp, rank, APLC_INT);
    res->shape = mptemp.ip;
    for (i = 0, rsize = 1; i < rank; i++) {
      res->shape[i] = shape[i];
      rsize = rsize * shape[i];
    }
    coln = shape[rank - 1];
  }
  res->alloc_ind |= APLC_ALLOC_SHAPE_F;

  /* check for zilde */
  if (0 == rsize) {
    /* nothing to do; just pass along char zilde */
    aplc_detalloc(res);
    aplc_czilde(res);
    return;
  }
  /* space for column width vector  */
  aplc_vectalloc(&mptemp2, coln, APLC_INT);
  colwidth = mptemp2.ip;
  for (i=0; i<coln; i++)
    colwidth[i] = 0;
  /* space for component width array, for complex types */
  ntype = get_typen(type);
  wimax = NULL;
  if (ntype >1) {
    nsize = coln*ntype;
    aplc_vectalloc(&mptemp3, nsize, APLC_INT);
    wimax = mptemp3.ip;
    for (i=0; i<nsize; i++)
      wimax[i] = 0;
  }
  /* sws  for debugging */
  /*-
    printf("\n rank %d, rsize %d, shape[0] %d,
    reshape[0] %d\n" ,rank, rsize, shape[0], res->shape[0]);
    */

  switch (type) {

  default:
  case APLC_UNDEF:
  case APLC_UKTYPE:
    fprintf(aplcerr, "[Format] type %d \n", type);
    aplc_error("Format domain error, unknown type");
    break;

  case APLC_BOOL:
  case APLC_INT:
  case APLC_LABEL:
    i = (res->rank) - 1;
    /* first get max actual width */
    rtemp = right->value;
    for (j=0,ic=0; j<rsize; j++) {
      format_int(ci, aplc_ppw[2], rtemp.ip[j]);
      /*wmax = max(wmax, get_act_width(ci));*/
      /* increment to get space */
      colwidth[ic] = max(colwidth[ic], 1+get_act_width(ci));
      /*printf("{ic %d, colwidth %d}\n",ic,colwidth[ic]);*/
      ic = (ic+1)%coln;
    }
    /* sum to get total size */
    wmax=0;
    for (ic=0; ic<coln; ic++)
      wmax += colwidth[ic];
    res->shape[i] = wmax;
    /*size = (rsize * wmax)/coln + 1;*/
    size = (((double) rsize)/coln) * wmax + 1;
    /*printf("wmax %d, size %d\n",wmax,size);*/

    aplc_vectalloc(&mptemp, size, APLC_CHAR);
    res->value = mptemp;
    for (j= 0,ic=0; j < rsize; j++) {
      /* printf("{ic %d, colwidth %d}\n",ic,colwidth[ic]);*/
      format_int(mptemp.cp, colwidth[ic], *rtemp.ip++);
      mptemp.cp += colwidth[ic];
      ic = (ic+1)%coln;
    }
    break;

  case APLC_REAL:
    realwidth = aplc_ppw[3] + REALWIDTHX;
    i = (res->rank) - 1;
    /* first get max actual width */
    rtemp = right->value;
    for (j=0,ic=0; j<rsize; j++) {
      format_real(ci, realwidth, aplc_ppw[3], &rtemp.rp[j]);
      /*wmax = max(wmax, get_act_width(ci));*/
      /* increment to get space */
      colwidth[ic] = max(colwidth[ic], 1+get_act_width(ci));
      ic = (ic+1)%coln;
    }	
    wmax=0;
    for (ic=0; ic<coln; ic++)
      wmax += colwidth[ic];
    res->shape[i] = wmax;
    /*size = (rsize * wmax)/coln + 1;*/
    size = (((double) rsize)/coln) * wmax + 1;
    aplc_vectalloc(&mptemp, size, APLC_CHAR);
    res->value = mptemp;
    rtemp = right->value;
    for (j=0,ic=0; j < rsize; j++) {
      /*format_real(mptemp.cp, wmax, aplc_ppw[3], &rtemp.rp[j]);
      mptemp.cp += wmax;*/
      format_real(mptemp.cp, colwidth[ic], aplc_ppw[3], &rtemp.rp[j]);
      mptemp.cp += colwidth[ic];
      ic = (ic+1)%coln;
    }
    break;

  case APLC_COMPLEX:
    realwidth = aplc_ppw[3] + REALWIDTHX;
    i = (res->rank) - 1;
    rtemp = right->value;
    /* first get max actual width */
    numsize = 2*realwidth+1;
    for (k = 0; k < 2; k++) { 
      wi[k] = realwidth;
    }
    for (j = 0,ic=0; j < rsize; j++) {
      format_complex(czt,wa, numsize,wi, aplc_ppw[3], rtemp.zp, j);
      for (k = 0; k < 2; k++) {
	/*wimax[ic++] = max( wimax[ic], wa[k] );*/
	wimax[ic] = max( wimax[ic], wa[k] );
	ic++;
      }
      ic = ic%nsize;
    }
    /* get total size, including space of each column and whole row */
    wmax = 0;
    for (ic=0,j=0; ic < coln; ic++) {
      /* real part + space */
      colwidth[ic] += 1+wimax[j];
      wmax += 1+wimax[j++];
      /* for complex parts, add space for i only if present */
      for (k=1; k<ntype; k++) {
	if (wimax[j]>0) {
	  colwidth[ic] += 1+wimax[j];
	  wmax += 1+wimax[j];
	}
	j++;
      }
    }
    /*fprintf(stderr, "wmax %d\n", wmax);*/
    res->shape[i] = wmax;
    /*size = (rsize*wmax)/coln + 1;*/
    size = (((double) rsize)/coln) * wmax + 1;
    aplc_vectalloc(&mptemp, size, APLC_CHAR);
    res->value = mptemp;
    for (j = 0,ic=0,k=0; j < rsize; j++) {
      /* format_complex(mptemp.cp,wa, wmax,wimax, aplc_ppw[3], rtemp.zp, j);
      mptemp.cp += wmax;*/
      format_complex(mptemp.cp,wa, colwidth[ic],&(wimax[k]), aplc_ppw[3], rtemp.zp, j);
      mptemp.cp += colwidth[ic];
      ic = (ic+1)%coln;
      k = (k+ntype)%nsize;
    }
    break;
  case APLC_QUAT:
    realwidth = aplc_ppw[3] + REALWIDTHX;
    i = (res->rank) - 1;
    rtemp = right->value;
    /* first get max actual width */
    numsize = 4*realwidth;
    for (k = 0; k < 4; k++) { 
      wi[k] = realwidth;
    }
    for (j = 0,ic=0; j < rsize; j++) {
      format_quat(czt,wa, numsize,wi, aplc_ppw[3], rtemp.qp, j);
      for (k = 0; k < 4; k++) {
	/*wimax[ic++] = max( wimax[ic], wa[k] );*/
	wimax[ic] = max( wimax[ic], wa[k] );
	ic++;
      }
      ic = ic%nsize;
    }
    /* get total size, including space of each column and whole row */
    wmax = 0;
    for (ic=0,j=0; ic < coln; ic++) {
      /* real part + space */
      colwidth[ic] += 1+wimax[j];
      wmax += 1+wimax[j++];
      /* for complex parts, add space for ijk only if present */
      for (k=1; k<ntype; k++) {
	if (wimax[j]>0) {
	  colwidth[ic] += 1+wimax[j];
	  wmax += 1+wimax[j];
	}
	j++;
      }
    }
    res->shape[i] = wmax;
    /*size = (rsize*wmax)/coln + 1;*/
    size = (((double) rsize)/coln) * wmax + 1;
    aplc_vectalloc(&mptemp, size, APLC_CHAR);
    res->value = mptemp;
    for (j = 0,ic=0,k=0; j < rsize; j++) {
      /*format_quat(mptemp.cp,wa, wmax,wimax, aplc_ppw[3], rtemp.qp, j);
      mptemp.cp += wmax;*/
      format_quat(mptemp.cp,wa, colwidth[ic],&(wimax[k]), aplc_ppw[3], rtemp.qp, j);
      mptemp.cp += colwidth[ic];
      ic = (ic+1)%coln;
      k = (k+ntype)%nsize;
    }
    break;
  case APLC_OCT:
    realwidth = aplc_ppw[3] + REALWIDTHX;
    i = (res->rank) - 1;
    rtemp = right->value;
    /* first get max actual width */
    numsize = 8*realwidth;
    for (k = 0; k < 8; k++) { 
      wi[k] = realwidth;
    }
    for (j=0,ic=0; j < rsize; j++) {
      format_oct(czt,wa, numsize,wi, aplc_ppw[3], rtemp.op, j);
      for (k = 0; k < 8; k++) {
	/*wimax[ic++] = max( wimax[ic], wa[k] );*/
	wimax[ic] = max( wimax[ic], wa[k] );
	ic++;
      }
      ic = ic%nsize;
    }
    /* get total size, including space of each column and whole row */
    wmax = 0;
    for (ic=0,j=0; ic < coln; ic++) {
      /* real part + space */
      colwidth[ic] += 1+wimax[j];
      wmax += 1+wimax[j++];
      /* for complex parts, add space for ijkUIJK only if present */
      for (k=1; k<ntype; k++) {
	if (wimax[j]>0) {
	  colwidth[ic] += 1+wimax[j];
	  wmax += 1+wimax[j];
	}
	j++;
      }
    }
    res->shape[i] = wmax;
    /*size = (rsize*wmax)/coln + 1;*/
    size = (((double) rsize)/coln) * wmax + 1;
    aplc_vectalloc(&mptemp, size, APLC_CHAR);
    res->value = mptemp;
    for (j=0,ic=0,k=0; j < rsize; j++) {
      format_oct(mptemp.cp,wa, colwidth[ic],&(wimax[k]), aplc_ppw[3], rtemp.op, j);
      mptemp.cp += colwidth[ic];
      ic = (ic+1)%coln;
      k = (k+ntype)%nsize;
    }
    break;
  }
  res->size = aplc_vsize(res->rank, res->shape);
  res->alloc_ind |= APLC_ALLOC_VAL_F;
  aplc_free(mptemp2.ip);/* aplc_free the col widths */ 
  if (ntype >1)
    aplc_free(mptemp3.ip);
  return;
}


/* ------------------------------------------------------------ */
