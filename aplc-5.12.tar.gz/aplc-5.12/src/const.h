/* 
   aplc constant declarations
   sws  1/8/96
   2/21/2004 change #define name to avoid conflicts

   some externals to const.c 

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_CONST_H
#define _APLC_CONST_H

/* functions */
extern void setlocalcons(void);
extern void resetconsts(void);

extern int addicon(int i);
extern int addicon_scalar(int x);

extern int addrcon(double x);

extern int addzcon(double x[2]);
extern int addr2zcon(double x);

extern int addqcon(double x[4]);
extern int addz2qcon(double x[2]);
extern int addr2qcon(double x);

extern int addocon(double x[8]);
extern int addq2ocon(double x[4]);
extern int addz2ocon(double x[2]);
extern int addr2ocon(double x);

extern int addlcon(char *x);
struct node* ivec2rvec(struct node *ivec);
struct node* rvec2zvec(struct node *rvec);
struct node* zvec2qvec(struct node *zvec);
struct node *qvec2ovec(struct node *qvec);

extern void expanivec(struct node *ivec, double r);
extern void expanrvec(struct node *rvec, double z[2]);

/* variables */

extern int ictop, rctop, zctop, qctop, octop, sctop, lctop;
extern int *iconsts; 
extern double *rconsts;
extern double *zconsts[2];
extern double *qconsts[4];
extern double *oconsts[8];
extern char *sconsts;
extern struct label_struct lconsts[];

#endif /* _APLC_CONST_H */
/* end of const.h */ 
