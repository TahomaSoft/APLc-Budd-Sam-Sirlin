/* 
	APL compiler
		utilities common to all passes of compiler
		timothy a. budd

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

# include <stdio.h>
# include "parse.h"
# include "y_tab.h"
# include "util2.h"

extern int *iconsts;
extern int ictop;

/* impossible case error */
extern void
caserr(char *where, int num)
{
 fprintf(stderr,"case error in %s. case = %d\n",where,num);
 fprintf(stderr,"statement number %d\n",stmtno);
 exit(1);
}

/* cant - can't happen */
extern void
cant (char *where)
{
  fprintf(stderr,"can't happen: %s\n",where);
  exit(1);
}

/* mergetop - is node at top of merge tree fragment */
extern int 
mergetop(struct node *node)
{
/*
        if ( !(node->info & MERGE))
		return(1);
	else
		return(0);
*/
  return 0;
}

/* mergebot - is node at bottom of merge tree fragment */
extern int 
mergebot(struct node *node)
{
/*
        if ( !(RIGHT->info & MERGE))
		return(1);
	else
		return(0);
*/
  return 0;
}

/*
	numin - return the number of elements in a structure with
	known shape
*/
extern int 
numin(struct node *node)
{	int i, r, s, size;

 r = node->n.rank;
 s = node->n.shape;

 size = 1;
 for (i = 0; i < r; i++)
   size *= iconsts[s + i];
 return size;
}

/* end of util2.c */

