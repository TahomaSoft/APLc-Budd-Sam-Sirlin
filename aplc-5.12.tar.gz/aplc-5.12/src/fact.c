/* fact.c

	APL Compiler

	Run time system
	routines having to do with scalar functions values
        factorial function

	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.
         
*/


# include <stdio.h>
# include <math.h>

#include "aplc.h" 

/* could use a table here ... */


/* factorial for positive integers */
extern int 
aplc_fact(int n)
{
    int i;
    i=1;
    while (n > 0){
	i *= n--;
    }
    return(i);
}

/* end of fact.c */
