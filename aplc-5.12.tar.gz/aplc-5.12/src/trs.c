/*
	APL compiler
		type / rank / shape inferencer
		timothy a. budd

                sws  this file is used for both trs.c and itrs.c,
                     the difference being the definition of INTRA
                     in the compilation of itrs.c, and adding intra.c

note:
    node->n.rank    is the integer value of the rank
    node->n.shape   is a pointer to the starting point of the shape vector in
                    iconsts

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include <stdio.h>
#include <math.h>

#include "parse.h"
#include "y_tab.h"
#include "util2.h"
#include "nutil.h"
#include "trs.h"

/* ----------------------------------------------------------- */
#define TDEBUG 0
/* for cat/lam */
#define CATDEBUG 0

/* ----------------------------------------------------------- */
/* external functions */

#ifdef INTRA
/* stuff in intra.c */
void doassign(char *name, struct node * node);
void doident(struct node * node);
void dolcon(struct node * node);
struct symnode *getsinfo(char *name);

#endif

/* extern void error(char *);*/
/* now in gen... from nutil.c */
extern int maxtype(int ltype, int mrtype);

/* ----------------------------------------------------------- */
#define is_scalar(node) ((node->n.info & RANKKNOWN) && (node->n.rank == 0))

/* check that type is really known */
#define TYPEisknown(node) ((node->n.info & TYPEKNOWN) && (node->n.type != APLC_ANY))

/* check that rank is really known */
#define RKisknown(node) ((node->n.info & RANKKNOWN) && (node->n.rank != NORANK) && (node->n.rank != ANYRANK))

/* scalar or vector */
#define isnot_vector(node)  (RKisknown(node) && (node->n.rank > 1))
/* scalar */
#define isnot_scalar(node)  (RKisknown(node) && (node->n.rank != 0))

/* axis value is known */
#define Axisval_known  ( (AXIS->n.info & TYPEKNOWN) &&  \
			 ((AXIS->n.type == APLC_INT) || (AXIS->n.type == APLC_BOOL)) &&  \
			 (AXIS->n.info & VALUESKNOWN) ) 

/* known not to be a number */ 
#define isnot_num(type) ( (type != APLC_UKTYPE) && \
			  (type != APLC_BOOL) && \
			  (type != APLC_INT) && \
			  (type != APLC_REAL) && \
			  (type != APLC_COMPLEX) && \
			  (type != APLC_QUAT) && \
			  (type != APLC_OCT) && \
			  (type != APLC_ANY) )

/* known empty */
#define isempty(node)  ( RKisknown(node) && \
                         (node->n.info & SHAPEKNOWN) && \
			 (ksize(node) == 0) )

/* ----------------------------------------------------------- */
/* local fn declarations */
static struct node *addcollect(struct node * node);

static void check_anyrank(struct node *n1, struct node *n2);

static int typemake(int totype, int fromtype);
static int ranktest(struct node * node, int rank);
static int ksize(struct node * node);

/* ----------------------------------------------------------- */
static void dsrtype(enum sfuns op, struct node * node, 
		    struct node * left,	struct node * right);
static void scantype(enum sfuns op, struct node * node, 
		     struct node * right);

static void infaxis(struct node * node);
static void
copychild(struct node * node, struct node * child, int type,
    int rank, int shape, int value);

void doinf(struct node * node, int top);
int cpivec(int start, int size, int pos);
void catshape(struct node * node);
int cpivec2(int start, int size, int pos, int x);
void lamshape(struct node * node);
void dytrans(struct node * node);
void outershape(struct node * node);

/* passinit - initialize this pass (do nothing) */
void
passinit(int verbose)
{
  /* sws */
  if (verbose) {

#ifdef INTRA
    fprintf(stderr, "Starting intra\n");
    passname = "intra";
#else
    fprintf(stderr, "Starting trs\n");
    passname = "trs";
#endif
  }
}

/* glbvar - process a global variable name */
void
glbvar(char *name)
{
  ;
}

#ifndef INTRA
/* doprog - process function used by trs */
void
doprog(int type, struct headnode * head, struct symnode * syms,
       struct statenode * code)
{
  struct statenode *p;

  stmtno = 0;
  for (p = code; p != NILSTATE; p = p->nextstate) {
    stmtno++;
    doinf(p->code, 1);
  }
  return;
}

#endif

/*  addcollect - add a collect node into the tree 
    sws copy of version in access.c */
static struct node *
addcollect(struct node * node)
{
  struct node *x;

  /* fprintf(stderr,"adding a collect over %d\n", node->nodetype); */

  x = structalloc(node);
  if (x == (struct node *) 0)
    error("out of space");
  x->nodetype = COLLECT;
  x->n.info = 0;
  x->left = x->axis = x->store = NILP;
  x->namep = NULL; 
  x->namea = NULL;
  x->right = node;
  x->optype = APLC_NOT;
  x->index = 0;
  return (x);
}

/* sws  check for arbitrary rank inheritance, n1(n2) */
static void
check_anyrank(struct node *n1, struct node *n2)
{
  if ( (n2->n.info & RANKKNOWN) && (n2->n.rank==ANYRANK)) {
    n1->n.info |= RANKKNOWN;
    n1->n.rank = ANYRANK;
    arb_shape_info(&(n1->n));
  }
  return;
} 

extern void
remove_type_info(info_t *s)
{
  if (s->info & TYPEKNOWN)
    s->info ^= TYPEKNOWN;
  return;
}

extern void
remove_rank_info(info_t *s)
{
  if (s->info & RANKKNOWN)
    s->info ^= RANKKNOWN;
  return;
}

extern void
remove_shape_info(info_t *s)
{
  if (s->info & SHAPEKNOWN)
    s->info ^= SHAPEKNOWN;
  return;
}

extern void
remove_value_info(info_t *s)
{
  if (s->info & VALUESKNOWN)
    s->info ^= VALUESKNOWN;
  return;
}

/* shape known arbitrary
   - max shape type */
extern void
arb_shape_info(info_t *s)
{
  remove_shape_info(s);
  s->info |= SHAPEARB;
  return;
}

/*
  typemake
  - can an object of fromtype be made into an object of totype?
*/
static int
typemake(int totype, int fromtype) 
{
  if ( (totype == APLC_UKTYPE) || (totype == APLC_ANY) )
    return (1);
  if ( (fromtype == APLC_UKTYPE) || (fromtype == APLC_ANY) )
    return (1);
  if (totype == fromtype)
    return (1);

  switch (totype) {
  case APLC_BOOL:
    break;
  case APLC_INT:
    if (fromtype == APLC_BOOL || 
	fromtype == APLC_LABEL)
      return (1);
    break;
  case APLC_REAL:
    if (fromtype == APLC_BOOL || 
	fromtype == APLC_INT || 
	fromtype == APLC_LABEL)
      return (1);
    break;
  case APLC_COMPLEX:
    if (fromtype == APLC_BOOL || 
	fromtype == APLC_INT ||
	fromtype == APLC_LABEL ||
	fromtype == APLC_REAL)
      return (1);
    break;
  case APLC_QUAT:
    if (fromtype == APLC_BOOL || 
	fromtype == APLC_INT ||
	fromtype == APLC_LABEL ||
	fromtype == APLC_REAL ||
	fromtype == APLC_COMPLEX)
      return (1);
    break;
  case APLC_OCT:
    if (fromtype == APLC_BOOL || 
	fromtype == APLC_INT ||
	fromtype == APLC_LABEL ||
	fromtype == APLC_REAL ||
	fromtype == APLC_COMPLEX ||
	fromtype == APLC_QUAT)
      return (1);
    break;
  case APLC_CHAR:
    break;
  case APLC_ANY:
    return (1);
  case APLC_UKTYPE:
    return (1);
  case APLC_LABEL:
    break;
  }
  return (0);
}

/* ranktest - see if a node is a given rank */
static int
ranktest(struct node * node, int rank)
{
  if ((node->n.info & RANKKNOWN) && (node->n.rank == rank))
    return (1);
  return (0);
}

/* return the size of a node - number of elements 
   - assumes rank and shape are known
   - mostly a copy of the routine in cutil.c
*/
static int
ksize(struct node * node)
{
  int rank, pos, size, j;

  rank = node->n.rank;
  pos = node->n.shape;
  size = 1;
  for (j = rank - 1; j >= 0; j--)
    size *= iconsts[pos + j];
  return (size);
}


/* mergetype
   (sws) moved here from dsrtype(APLC_NOT case) 
   type checking for catenate and sub assign   */
static void
mergetype(struct node * node, struct node * left, struct node * right)
{
  int ltype, mrtype;

  if (left->n.info & TYPEKNOWN)
    ltype = left->n.type;
  else
    ltype = APLC_UKTYPE;
  if (right->n.info & TYPEKNOWN)
    mrtype = right->n.type;
  else
    mrtype = APLC_UKTYPE;

  if (isempty(right)) {
    if (ltype != APLC_UKTYPE) {
      node->n.type = ltype;
      node->n.info |= TYPEKNOWN;
    }
    return;
  }
  if (isempty(left)) {
    if (mrtype != APLC_UKTYPE) {
      node->n.type = mrtype;
      node->n.info |= TYPEKNOWN;
    }
    return;
  }

  if ((!typemake(ltype, mrtype)) && (!typemake(mrtype, ltype))) {
    fprintf(stderr, "[mergetype] types %d %d, nodetype %d\n", 
	    ltype, mrtype,node->nodetype);
    if (node->nodetype==CAT)
      error("illegal types for catenation");
    else if (node->nodetype==SUBASSIGN)
      error("illegal types for subassign");
    else
      error("illegal types for ???");
  }
  if ((ltype != APLC_UKTYPE) && (mrtype != APLC_UKTYPE)) {
    node->n.type = maxtype(ltype, mrtype);
    node->n.info |= TYPEKNOWN;
  }
}


/*  dsrtype
    type checking for dyadic scalar ops */
static void
dsrtype(enum sfuns op, struct node * node, struct node * left, 
	struct node * right)
{
  int ltype, mrtype;

  if (left->n.info & TYPEKNOWN)
    ltype = left->n.type;
  else
    ltype = APLC_UKTYPE;
  if (right->n.info & TYPEKNOWN)
    mrtype = right->n.type;
  else
    mrtype = APLC_UKTYPE;

  switch (op) {
  case APLC_AND:
  case APLC_NAND:
  case APLC_NOR:
  case APLC_OR:
    if ((!typemake(APLC_BOOL, ltype)) && (!typemake(APLC_BOOL, mrtype)))
      error("illegal types for logical operator");
    node->n.info |= TYPEKNOWN;
    node->n.type = APLC_BOOL;
    break;

  case APLC_EQ:
    /* if types not equal, result should be 0  */
    node->n.info |= TYPEKNOWN;
    node->n.type = APLC_BOOL;
    break;

  case APLC_NE:
    /* if types not equal, result should be 1 */
    node->n.info |= TYPEKNOWN;
    node->n.type = APLC_BOOL;
    break;

  case APLC_LT:
  case APLC_LE:
  case APLC_GE:
  case APLC_GT:
    if ((!typemake(ltype, mrtype)) && (!typemake(mrtype, ltype))) {
      error("illegal types for comparison operator");
    }
    node->n.info |= TYPEKNOWN;
    node->n.type = APLC_BOOL;
    break;

  case APLC_ABS:
  case APLC_CEIL:
  case APLC_FACT:
  case APLC_FLOOR:
  case APLC_MINUS:
  case APLC_PLUS:
  case APLC_TIMES:
    if ((!typemake(ltype, mrtype)) && 	(!typemake(mrtype, ltype))) {
      fprintf(stderr, "types %d %d\n", ltype, mrtype);
      error("illegal types for arithmetic operator");
    }
    if ((ltype != APLC_UKTYPE) && (mrtype != APLC_UKTYPE)) {
      node->n.type = maxtype(ltype, mrtype);
      node->n.info |= TYPEKNOWN;
      /* promote bit to int - is this really necessary? 
         probably for +, - only */
      if (node->n.type == APLC_BOOL)
	node->n.type = APLC_INT;
    }
    break;

  case APLC_CIRCLE:
  case APLC_DIVIDE:
  case APLC_EXP:
  case APLC_LOG:
#if 0
    if ((!typemake(APLC_REAL, ltype)) && (!typemake(APLC_REAL, mrtype)))
      error("illegal types for real operator");
    node->n.info |= TYPEKNOWN;
    node->n.type = APLC_REAL;
#endif
    if ( isnot_num(ltype) || isnot_num(mrtype) )
      error("illegal types for real operator");
    if ((ltype != APLC_UKTYPE) && (mrtype != APLC_UKTYPE)) {
      node->n.type = max(APLC_REAL, maxtype(ltype, mrtype));
      node->n.info |= TYPEKNOWN;
    }
    break;

  case APLC_NOT:
    /* not used currently */
    fprintf(stderr, "(not) is not a dyadic scalar operator\n");
    exit(1);
    break;

  default:
    fprintf(stderr, "dyadic scalar operator %d not done\n", op);
    exit(1);
  }
}

/*  scantype
    sws type checking for scan; modified dsrtype */
static void
scantype(enum sfuns op, struct node * node, struct node * right)
{
  int mrtype;

  if (right->n.info & TYPEKNOWN)
    mrtype = right->n.type;
  else
    mrtype = APLC_UKTYPE;

  switch (op) {
  case APLC_AND:
  case APLC_NAND:
  case APLC_NOR:
  case APLC_OR:
    if (!typemake(APLC_BOOL, mrtype))
      error("illegal types for logical operator");
    node->n.info |= TYPEKNOWN;
    node->n.type = APLC_BOOL;
    break;

  case APLC_EQ:
  case APLC_NE:
  case APLC_LT:
  case APLC_LE:
  case APLC_GE:
  case APLC_GT:
    if (mrtype == APLC_BOOL) {
      /* result is only bool if right is bool */
      node->n.info |= TYPEKNOWN;
      node->n.type = APLC_BOOL;
    }
    break;

  case APLC_ABS:
  case APLC_CEIL:
  case APLC_FACT:
  case APLC_FLOOR:
  case APLC_MINUS:
  case APLC_PLUS:
  case APLC_TIMES:
    if (mrtype != APLC_UKTYPE) {
      node->n.type = mrtype;
      node->n.info |= TYPEKNOWN;
      /* promote bool to int - is this really necessary? 
         probably for +, - only */
      if (node->n.type == APLC_BOOL)
	node->n.type = APLC_INT;
    }
    break;

  case APLC_CIRCLE:
  case APLC_DIVIDE:
  case APLC_EXP:
  case APLC_LOG:
    if ( isnot_num(mrtype) )
      error("illegal types for real operator");
    if (mrtype != APLC_UKTYPE) {
      node->n.type = max(APLC_REAL, mrtype);
      node->n.info |= TYPEKNOWN;
    }
    break;

  case APLC_NOT:
    /* not used currently */
  default:
    fprintf(stderr, "dyadic scalar operator %d not done\n", op);
    exit(1);
  }
}

/*
  infaxis - initialize axis node
  */
static void
infaxis(struct node * node)
{
  struct node *axis;
  int val;

  if ((node->n.info & FIRSTAXIS) || (node->n.info & LASTAXIS))
    ;/* nothing to do here */
  else {
    axis = node->axis;
    /* the fact that it is a cscalar will fix things */
    doinf(axis, 0);
    /* if we know the axis, perhaps we can do thing better */
    if ( Axisval_known ) {
      val = iconsts[axis->n.values] - get_indexorg();
      if ( RKisknown(node) && (val == node->n.rank))
	node->n.info |= LASTAXIS;
      else if (val == 0)
	node->n.info |= FIRSTAXIS;
    }
  }
}

/*
  copychild - copy selected attributes from another node
*/
static void
copychild(struct node * node, struct node * child, int type,
    int rank, int shape, int value)
{
  if (type)
    remove_type_info(&node->n);
  if (rank)
    remove_rank_info(&node->n);
  if (shape)
    remove_shape_info(&node->n);
  if (value)
    remove_value_info(&node->n);
  
  if (type && (child->n.info & TYPEKNOWN)) {
    node->n.info |= TYPEKNOWN;
    node->n.type = child->n.type;
  }
  if (rank && (child->n.info & RANKKNOWN)) {
    node->n.info |= RANKKNOWN;
    node->n.rank = child->n.rank;
  }
  if (rank)
    check_anyrank(node, child);
  if (shape && (child->n.info & SHAPEKNOWN)) {
    node->n.info |= SHAPEKNOWN;
    node->n.shape = child->n.shape;
    update_info_size(&(node->n));
  }
  if (value && (child->n.info & VALUESKNOWN)) {
    node->n.info |= VALUESKNOWN;
    node->n.values = child->n.values;
  }
  return;
}

/* make a general node, if is known
   sws */
extern void
init_arb(struct node * node)
{
  if (! (node->n.info & TYPEKNOWN) ) {
    node->n.type = APLC_ANY;
    node->n.info |= TYPEKNOWN;
  }
  if (! (node->n.info & RANKKNOWN) ) {
    node->n.rank = ANYRANK;
    node->n.info |= RANKKNOWN;
    if (node->n.info & SHAPEKNOWN)
      node->n.info ^= SHAPEKNOWN;
  } 
#if 0
  fprintf(stderr, "\n[init_arb] %s", node->namep);
  print_info(stderr, &(node->n)); 
  fprintf(stderr, "\n");
#endif
  return;
}

/* doinf - node inferencer 

   called on the to node in a line, it proceeds down the tree to to
   the end (leaves) */
extern void
doinf(struct node * node, int top)
{
  enum sysvars optype;
  int i=0;
  int j=0;
  int sh, rk, rt, c, rkl;
  int sp, rp, vp;

  if (0 == node) {
    error("[doinf] null pointer");
  }
    
#if TDEBUG 
    /* info for debugging */ 
    fprintf(stderr, "[trs] node %d %s\n", 
	    node->nodetype, prtoken(node->nodetype));
#endif

  switch (node->nodetype) {
  default:
    caserr("doinf", node->nodetype);
    break;

  case ASSIGN:
    doinf(RIGHT, 0);
    /*doinf(LEFT, 0);*/
    if (LEFT->n.info & TYPEDECL) {
      node->n.type = LEFT->n.type;
      node->n.info |= TYPEKNOWN;
      if (!typemake(node->n.type, RIGHT->n.type)) {
	print_info(stderr, &(node->n));fprintf(stderr,"\n"); 
	print_info(stderr, &(RIGHT->n));
	/*fprintf(stderr, "\n node type %d, right type %d\n",
	  node->n.type, RIGHT->n.type);*/
	error("assignment type error");
      }
    } else if (RIGHT->n.info & TYPEKNOWN) {
      node->n.type = RIGHT->n.type;
      node->n.info |= TYPEKNOWN;
    }
    if (LEFT->n.info & RANKDECL) {
      node->n.rank = LEFT->n.rank;
      node->n.info |= RANKKNOWN;
#if 0
      /* not sure about this */
      if ((RIGHT->n.info & RANKKNOWN) && (RIGHT->n.rank != node->n.rank))
	error("[trs] assignment rank error");
#endif
      /*if (RKisknown(RIGHT) && (RIGHT->n.rank != node->n.rank)) */
      if (RKisknown(node) && RKisknown(RIGHT) && 
	  (RIGHT->n.rank != node->n.rank)) {
	fprintf(stderr, "[trs] node->n.rank %d, right->n.rank %d, %s\n",
		node->n.rank, RIGHT->n.rank, 
		prtoken(RIGHT->nodetype));
	error("[trs] assignment rank error");
      }
    } else if (RIGHT->n.info & RANKKNOWN) {
      node->n.rank = RIGHT->n.rank;
      node->n.info |= RANKKNOWN;
    }
    check_anyrank(node, RIGHT);
    if (RIGHT->n.info & SHAPEKNOWN) {
      /* since ranks agree, this must be ok */
      node->n.shape = RIGHT->n.shape;
      node->n.size = RIGHT->n.size;
      node->n.info |= SHAPEKNOWN;
    }
#if 0
    /* now ensure that left is the same */
    LEFT->n.info = node->n.info;
    LEFT->n.type = node->n.type;
    LEFT->n.rank = node->n.rank;
    LEFT->n.shape = node->n.shape;     
#endif
    check_anyrank(LEFT,node);

#if 0 
    /* if some node information isn't known ensure the most 
       general form. This is required for assign and intra 
       - handled in intra currently...
    */ 
    if (! node->n.info & TYPEKNOWN) {
      node->n.info |= TYPEKNOWN;
      node->n.type = APLC_ANY; 
    }
    if (! node->n.info & RANKKNOWN) {
      node->n.info |= RANKKNOWN;
      node->n.rank = ANYRANK;
    }
    if (! node->n.info & SHAPEKNOWN) {
      node->n.info |= SHAPEKNOWN;
      arb_shape_info(&(node->n));
    }
#endif

#ifdef INTRA
    doassign(LEFT->namep, node);
#endif
    doinf(LEFT, 0);
    break;

  case AVEC:
    node->n.type = APLC_CHAR;
    node->n.rank = 1;
    node->n.shape = addicon_scalar(256);
    node->n.size = 256;
    node->n.info |= (TYPEKNOWN | RANKKNOWN | SHAPEKNOWN);
    break;

  case BCON:
  case ICON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case SCON:
    break;

  case QUAD:
  case DQUAD:
  case DQQUAD:
    if (RIGHT != NILP) {
      doinf(RIGHT, 0);
    }
    node->n.type = APLC_ANY; 
    node->n.info |= TYPEKNOWN;
    node->n.rank = ANYRANK;
    node->n.info |= RANKKNOWN;
    break;

  case QQUAD:
    node->n.type = APLC_CHAR;
    node->n.info |= TYPEKNOWN;
    node->n.rank = ANYRANK;
    node->n.info |= RANKKNOWN;
    break;

  case QQUADASSIGN:
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1,1,1,1);
    node->n.info = RIGHT->n.info;
    node->n.type = APLC_CHAR;
    node->n.info |= TYPEKNOWN;
    if ( TYPEisknown(RIGHT) ) {
      if (RIGHT->n.type != APLC_CHAR) {
	fprintf(stderr, "[trs] qq assign domain error, type [%d]\n", 
		RIGHT->n.type);
	error("qq assign domain error ");
      }
    }
    break;

  case QUADASSIGN:
    doinf(RIGHT, 0);
    /* value of node is exactly right */
    copychild(node, RIGHT, 1,1,1,1);
    node->n.info = RIGHT->n.info;
    break;

  case DQUADASSIGN:
  case DQQUADASSIGN:
    doinf(RIGHT, 0);
    if (LEFT != NILP) { /* file name */
      doinf(LEFT, 0);
    }
    if (RIGHT->n.info & TYPEKNOWN) {
      node->n.type = RIGHT->n.type;
      node->n.info |= TYPEKNOWN;
    }
    if (RIGHT->n.info & RANKKNOWN) {
      node->n.rank = RIGHT->n.rank;
      node->n.info |= RANKKNOWN;
    }
    if (RIGHT->n.info & SHAPEKNOWN) {
      /* since ranks agree, this must be ok */
      node->n.shape = RIGHT->n.shape;
      node->n.size = RIGHT->n.size;
      node->n.info |= SHAPEKNOWN;
    }
    if (node->nodetype == QQUADASSIGN || node->nodetype == DQQUADASSIGN)
      node->ptr2 = 0;
    else
      node->ptr2 = 1;
    break;

  case BOX:
    doinf(RIGHT, 1);
    node->n.type = APLC_BOXED;
    node->n.rank = 0;
    node->n.shape = 1;
    node->n.size = 1;
    node->n.info |= (TYPEKNOWN | RANKKNOWN | SHAPEKNOWN);
    break;

  case UNBOX:
    doinf(RIGHT, 1);
    break;

  case CAT:
    doinf(RIGHT, 0);
    infaxis(node);
    doinf(LEFT, 0);
    mergetype(node, LEFT, RIGHT);
    /*- sws  be careful of possible laminate */
#if CATDEBUG
    print_rkshape(stderr, "cat node-", &(node->n));
    PRINT_NINFO(stderr, "   left ", &(LEFT->n));
    PRINT_NINFO(stderr, "   right", &(RIGHT->n));
#endif
    if ((node->n.info & FIRSTAXIS) || (node->n.info & LASTAXIS))
      catshape(node);
    else if ( TYPEisknown(AXIS) ) {
      if ( (AXIS->n.type == APLC_INT) || (AXIS->n.type == APLC_BOOL) )
	catshape(node);/* normal cat */
      else if (AXIS->n.type == APLC_REAL)
	lamshape(node);/* laminate ? */
      else {
	fprintf(stderr, "[trs] cat illegal type [%d]\n", AXIS->n.type);
	error("catenate axis type error ");
      }
    }
#if CATDEBUG
    print_rkshape(stderr, "cat node", &(node->n));
    fprintf(stderr, "[trs] cat done ----------\n");
#endif
    /* now ensure propagation of anyrank */
    check_anyrank(node, LEFT);
    check_anyrank(node, RIGHT);
    break;

  case RESHAPEX:
    doinf(LEFT, 0);
    doinf(RIGHT, 0);
    if (RIGHT->n.info & TYPEKNOWN) {
      node->n.type = RIGHT->n.type;
      node->n.info |= TYPEKNOWN;
    }
    /* have some information already in left values: shape
       - shape in final axis is 0 */
    if ( (LEFT->n.info & VALUESKNOWN) &&
	 (RIGHT->n.info & SHAPEKNOWN) ) {
      /* know everything... 
	 left is a shape vector; */
      rk = iconsts[LEFT->n.shape];
      vp = LEFT->n.values;
      node->n.rank = rk;
      node->n.shape = vp;
#if TDEBUG 
      fprintf(stderr,"[trs] reshapex rk %d, rrank %d\n", 
	      rk, RIGHT->n.rank);
#endif
      if (RIGHT->n.rank == rk) {
	/* just use right shape */
	node->n.shape = RIGHT->n.shape;
	iconsts[LEFT->n.shape] = node->n.rank;
	LEFT->n.values = node->n.shape;
      } else if (RIGHT->n.rank < rk) { 
	/* need to combine 
	   1. node: s1,0
	   right: r1
	   -- s1, r1/s1
	   2. node: s1,s2,0
	   right: r1
	   -- s1,s2 r1/(s1*s2)
	   3. node: s1,s2,0
	   right: r1,r2
	   -- s1, (r1*r2)/(s1*r2), r2 = s1, r1/s1, r2
	   4. node: s1,s2,...,sn,0
	   right: r1,r2,...rk
	   -- s1,...,s(n-k), (r1)/sp, r2,...,rk
	*/
	/* get partial size */
	for (i=0, sp=1; i< node->n.rank - RIGHT->n.rank; i++)
	  sp *= iconsts[vp + i];
	/* get remainder */
	rp = iconsts[ RIGHT->n.shape ]/sp;
#if TDEBUG 
	fprintf(stderr," sp %d\n", sp);
	fprintf(stderr," rp %d\n", rp);
#endif
	iconsts[ vp + node->n.rank - RIGHT->n.rank ] = rp;
	for (i=1; i< RIGHT->n.rank; i++)
	  iconsts[ vp + node->n.rank - RIGHT->n.rank + i ] =  
				      iconsts[ RIGHT->n.shape + i ];
      } else {
	/* right > node 
	   rank is (left-1)+right */
	node->n.rank = rk-1 + RIGHT->n.rank;
	/* start shape with left; a vector */
	node->n.shape = cpivec(LEFT->n.values, 
			       iconsts[LEFT->n.shape]-1, -1);
	for (i=0, sp=1; i< iconsts[LEFT->n.shape]-1; i++)
	  sp *= iconsts[node->n.shape + i];
	/* get remainder */
	rp = iconsts[ RIGHT->n.shape ]/sp;
#if TDEBUG 
	fprintf(stderr," sp %d\n", sp);
	fprintf(stderr," rp %d\n", rp);
#endif
	addicon(rp);
	cpivec(RIGHT->n.shape+1, RIGHT->n.rank-1, -1);
	/* now reset left */
	iconsts[LEFT->n.shape] = node->n.rank;
	LEFT->n.values = node->n.shape;
      }
      node->n.info |= RANKKNOWN;
      node->n.info |= SHAPEKNOWN;
      /* LEFT is civec->icon
	 - need to change icon */
      if (LEFT->right != NILP) {
	LEFT->right->n.shape = LEFT->n.shape;
	LEFT->right->n.values = LEFT->n.values;
      }
#if TDEBUG 
      fprintf(stderr," new rank %d\n", node->n.rank);
      fprintf(stderr," left:");
      print_info(stderr, &LEFT->n);
      fprintf(stderr,"\n node:");
      print_info(stderr, &node->n);
      fprintf(stderr,"\n");
#endif
      /* change to ordinary reshape node */
      node->nodetype = RESHAPE;
    } else {
      /* else shape not known; add a collect to get a trs */
      if (RIGHT->nodetype != COLLECT)
	node->right = addcollect(RIGHT);
    }
    break;

  case LINK:
    doinf(RIGHT, 0);
    infaxis(node);
    doinf(LEFT, 0);
    node->n.type = APLC_BOXED;
    node->n.info |= TYPEKNOWN;

    /* if right is boxed, then (<a),b
       else  (<a),<b  */
    if ( TYPEisknown(LEFT) && TYPEisknown(RIGHT) ) {
      if (RIGHT->n.type != APLC_BOXED) {
	/* right is unboxed; result is (<R), <L; vector, length 2 */
	node->n.rank = 1;
	node->n.shape = addicon_scalar(2);
	node->n.info |= RANKKNOWN;
	node->n.info |= SHAPEKNOWN;
      } else {
	/* right is boxed; result is (<R), L;  */
	if ( RKisknown(RIGHT) ) {
	  if (RIGHT->n.rank < 1) {
	    /* right is scalar */
	    node->n.rank = 1;
	    node->n.shape = addicon_scalar(2);
	    node->n.info |= RANKKNOWN;
	    node->n.info |= SHAPEKNOWN;
	  } else {
	    /* rank is rank of right */
	    node->n.rank = RIGHT->n.rank;
	    node->n.info |= RANKKNOWN;
	    if (RIGHT->n.info & SHAPEKNOWN) {
	      node->n.shape = cpivec(RIGHT->n.shape, RIGHT->n.rank, -1);
	      iconsts[node->n.shape + node->n.rank - 1] += 1;
	      node->n.info |= SHAPEKNOWN;
	    }
	  }
	}	
      }
    }

#if 0
    /*- sws  be careful of laminate...
      later add some more intelligence to this */
    if ((node->n.info & FIRSTAXIS) || (node->n.info & LASTAXIS))
      catshape(node);
    else if ( TYPEisknown(AXIS) ) {
      if ( (AXIS->n.type == APLC_INT) || (AXIS->n.type == APLC_BOOL) )
	catshape(node);/* normal cat */
      else if (AXIS->n.type == APLC_REAL)
	lamshape(node);/* laminate ? */
      else {
	fprintf(stderr, "[trs] link illegal type [%d]\n", AXIS->n.type);
	error("link axis type error ");
      }
    }
#endif
    break;

  case CATCH:
    doinf(RIGHT, 1);
    doinf(LEFT, 1);
    break;

  case CCOLLECT:
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1, 1, 1, 0);/* don't collect values */
    break;

  case COLLECT:
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1, 1, 1, 1);
    break;

  case COMMENT:
    break;

  case COMPRESS:
    doinf(RIGHT, 0);
    infaxis(node);
    doinf(LEFT, 0);
    /* first some error checks */ 
    if ((LEFT->n.info & TYPEKNOWN) && !typemake(LEFT->n.type, APLC_BOOL))
      error("bit type required for compression");
    /* if ((LEFT->n.info & RANKKNOWN) && (LEFT->n.rank > 1))*/
    if (isnot_vector(LEFT))
      error("vector required for compression");
    /* now put the right info into the current node */
    if (RIGHT->n.info & TYPEKNOWN) {
      node->n.type = RIGHT->n.type;
      node->n.info |= TYPEKNOWN;
    }
    if (RIGHT->n.info & RANKKNOWN) {
      node->n.rank = RIGHT->n.rank;
      if (node->n.rank == 0)
	node->n.rank = 1;
      node->n.info |= RANKKNOWN;
    }
    /* now refine */
    if ( (LEFT->n.info & VALUESKNOWN) && 
	 (RIGHT->n.info & SHAPEKNOWN) &&
	 ( (node->n.info & FIRSTAXIS) || (node->n.info & LASTAXIS) ||
	   Axisval_known ) ) {
      node->n.info |= SHAPEKNOWN;
      /* in this case we know just what right values will be used */ 
      i = LEFT->n.values;
      /* determine size, in c, by counting nonzero entries of left */
      rkl = iconsts[LEFT->n.rank];
      if (rkl == 0) {
	/* left is a scalar */
	c = iconsts[i];
	sh = 1;
      } else {
	/* left is not a scalar */
	c = 0;
	sh = iconsts[LEFT->n.shape];
	for (j = sh - 1; j >= 0; j--)
	  if (iconsts[i + j])
	    c++;
      }
      rk = RIGHT->n.rank;
      if (rk == 0) {
	/* right is a scalar; we need to add a new vector for shape, as 
	 right may not (won't?) have one */
	node->n.shape = addicon(1);
      } else {
	/* right is not a scalar, so we can copy it's shape to start */
	node->n.shape = cpivec(RIGHT->n.shape, rk, -1);
      }
      if (rk == 0) {
	/* scalar right, always matches any left, result is a vector */
	iconsts[node->n.shape] = c;
      } else if (rkl == 0) {
	/* scalar left, always matches any right, result is shape of
	     right. sws: unless left is 0, in which case we have zilde */
	if (c == 0)
	  iconsts[node->n.shape] = c;
      } else {
	/* neither right nor left is scalar */
	if (node->n.info & FIRSTAXIS) {
	  if (sh != iconsts[node->n.shape]) {
	    fprintf(stderr, "compress, firstaxis");
	    fprintf(stderr, ", left rank(%d), right rank(%d)",
		    rkl,rk);
	    fprintf(stderr, ", left shape(%d), right shape(%d)\n",
		    sh, iconsts[node->n.shape]);
	    error("length error");
	  }
	  iconsts[node->n.shape] = c;
	} else if (node->n.info & LASTAXIS) {
	  if (sh != iconsts[node->n.shape + rk - 1]) {
	    fprintf(stderr, "compress, lastaxis");
	    fprintf(stderr, ", left rank(%d), right rank(%d)",
		    rkl,rk);
	    fprintf(stderr, ", left shape(%d), right shape(%d)\n",
		    sh, iconsts[node->n.shape + rk - 1]);
	    error("length error");
	  }
	  iconsts[node->n.shape + rk - 1] = c;
	} else {
	  /* neither first or last axis, but must be known */
	  j = iconsts[AXIS->n.values] - get_indexorg();
	  if (sh != iconsts[node->n.shape + j]) {
	    fprintf(stderr, "compress, axis %d", j);
	    fprintf(stderr, ", left rank(%d), right rank(%d)",
		    rkl,rk);
	    fprintf(stderr, ", left shape(%d), right shape(%d)\n",
		    sh, iconsts[node->n.shape + j]);
	    error("length error");
	  }
	  iconsts[node->n.shape + j] = c;
	}
      }
    }
    break;

  case EXPAND:
    doinf(RIGHT, 0);
    infaxis(node);
    doinf(LEFT, 0);
    /* first some error checks */ 
    if ((LEFT->n.info & TYPEKNOWN) && !typemake(LEFT->n.type, APLC_BOOL))
      error("bit type required for expansion");
    /* if ((LEFT->n.info & RANKKNOWN) && (LEFT->n.rank > 1))*/
    if (isnot_vector(LEFT))
      error("vector required for expansion");
    /* now put the right info into the current node */
    if (RIGHT->n.info & TYPEKNOWN) {
      node->n.type = RIGHT->n.type;
      node->n.info |= TYPEKNOWN;
    }
    if (RIGHT->n.info & RANKKNOWN) {
      node->n.rank = RIGHT->n.rank;
      if (node->n.rank == 0)
	node->n.rank = 1;
      node->n.info |= RANKKNOWN;
    }
    /* now refine */
    if ( (LEFT->n.info & VALUESKNOWN) && 
	 (RIGHT->n.info & SHAPEKNOWN) &&
	 ( (node->n.info & FIRSTAXIS) || (node->n.info & LASTAXIS) ||
	   Axisval_known ) ) {
      node->n.info |= SHAPEKNOWN;
      i = LEFT->n.values;
      /* determine size, in c, by counting nonzero entries */
      rkl = iconsts[LEFT->n.rank];
      if (rkl == 0) {
	/* left is a scalar */
	c = iconsts[i];
	sh = 1;
      } else {
	/* left is not a scalar */
	c = 0;
	sh = iconsts[LEFT->n.shape];
	for (j = sh - 1; j >= 0; j--)
	  if (iconsts[i + j])
	    c++;
      }
      rk = RIGHT->n.rank;
      if (rk == 0) {
	/* right is a scalar */
	node->n.shape = addicon(1);
      } else {
	/* right is not a scalar */
	node->n.shape = cpivec(RIGHT->n.shape, rk, -1);
      }
      /* fprintf(stderr,"rkl = %d, rk = %d\n",rkl,rk);
      fprintf(stderr,"c = %d, sh = %d\n",c,sh); */
      if (rk == 0) {
	/* scalar right, matches any left count, result is vector */
	iconsts[node->n.shape] = sh;
      } else {
	if (node->n.info & FIRSTAXIS) {
	  if (c != iconsts[node->n.shape]) {
	    fprintf(stderr,
	    "expand, firstaxis, left count(%d), right shape(%d)\n",
		    c, iconsts[node->n.shape]);
	    error("length error");
	  }
	  iconsts[node->n.shape] = sh;
	} else if (node->n.info & LASTAXIS) {
	  if (c != iconsts[node->n.shape + rk - 1]) {
	    fprintf(stderr,
		    "expand, lastaxis, left count(%d), right shape(%d)\n",
		    c, iconsts[node->n.shape + rk - 1]);
	    error("length error");
	  }
	  iconsts[node->n.shape + rk - 1] = sh;
	} else {
	  /* neither first nor last axis, but known */
	  j = iconsts[AXIS->n.values] - get_indexorg();
	  if (c != iconsts[node->n.shape + j]) {
	    fprintf(stderr,
		    "expand, axis %d, left count(%d), right shape(%d)\n",
		    j, c, iconsts[node->n.shape + j]);
	    error("length error");
	  }
	  iconsts[node->n.shape + j] = sh;
	}
      }
    }
    break;

   case CIVEC:
    doinf(RIGHT, 0);
    if ((RIGHT->n.info & TYPEKNOWN) && 
	(!typemake(APLC_INT, RIGHT->n.type))) {
      /* allow known zilde */
      if ( (RIGHT->n.info & RANKKNOWN) &&
	   (RIGHT->n.info & SHAPEKNOWN) &&
	   (ksize(RIGHT) == 0) ) {
	;/* ok */
      } else 
	error("integer vector required (1)");
    }
    /*    if ((RIGHT->n.info & RANKKNOWN) &&
	(!(ranktest(RIGHT, 0) || ranktest(RIGHT, 1))))*/
    if (isnot_vector(RIGHT))
      error("integer vector required (2)");
    node->n.type = APLC_INT;
    node->n.rank = 1;
    node->n.info |= (TYPEKNOWN | RANKKNOWN);
    copychild(node, RIGHT, 0, 0, 1, 1);
    break;

  case CVEC:
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1, 0, 1, 1);
    if (isnot_vector(RIGHT))
      error("vector required");
    node->n.rank = 1;
    node->n.info |= RANKKNOWN;
    break;

    /* sws  used in iota, roll, some axis */
    /* so vector of length 1 is ok */
  case CISCALAR:
    doinf(RIGHT, 0);
    if ((RIGHT->n.info & TYPEKNOWN) &&
	(!typemake(APLC_INT, RIGHT->n.type)))
      error("integer scalar required (1)");
    /* sws   allow rank 1 objects to get through */
    if (RKisknown(RIGHT)) {
      if (ranktest(RIGHT, 0));	     /* ok */
      else if (ranktest(RIGHT, 1)) {
	if (RIGHT->n.info & SHAPEKNOWN) {
	  if (!(1 == iconsts[RIGHT->n.shape]))
	    error("integer scalar required (2)");
	}
      } else
	error("integer scalar required (2)");
    }
    node->n.type = APLC_INT;
    node->n.rank = 0;
    /*node->n.shape = addicon(1);*/
    /*node->n.shape = 1; this works since 1 isalways item 1 */
    node->n.shape = addicon_scalar(1);
    node->n.info |= (TYPEKNOWN | RANKKNOWN | SHAPEKNOWN);
    copychild(node, RIGHT, 0, 0, 0, 1);
    break;

    /* sws  only used in axis, where a vector with shape 1 will do */
  case CSCALAR:
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1, 0, 0, 1);
    /* sws   allow rank 1 objects to get through */
    if (RKisknown(RIGHT)) {
      if (ranktest(RIGHT, 0));	     /* ok */
      else if (ranktest(RIGHT, 1)) {
	if (RIGHT->n.info & SHAPEKNOWN) {
	  if (!(1 == iconsts[RIGHT->n.shape]))
	    error("scalar required");
	}
      } else
	error("scalar required");
    }
    node->n.rank = 0;
    /*node->n.shape = addicon(1);*/
    /*node->n.shape = 1;*/
    node->n.shape = addicon_scalar(1);
    node->n.info |= (RANKKNOWN | SHAPEKNOWN);
    break;

  case DEAL:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    node->n.type = APLC_INT;
    node->n.rank = 1;
    node->n.info |= (TYPEKNOWN | RANKKNOWN);
    if (LEFT->n.info & VALUESKNOWN) {
      node->n.shape = LEFT->n.values;
      node->n.info |= SHAPEKNOWN;
    }
    break;

  case DECODE:
  case INNERCHILD:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    dsrtype(node->optype, node, LEFT, RIGHT);
    check_anyrank(node, RIGHT);
    if (RKisknown(RIGHT) && RKisknown(LEFT)) {
      i = LEFT->n.rank;
      j = RIGHT->n.rank;
      node->n.rank = (i ? i - 1 : 0) + (j ? j - 1 : 0);
      node->n.info |= RANKKNOWN;
    }
    if ((RIGHT->n.info & SHAPEKNOWN) && (LEFT->n.info & SHAPEKNOWN)) {
      if ((i > 0) && (j > 0)) {
	if (iconsts[LEFT->n.shape + i - 1]
	    != iconsts[RIGHT->n.shape]) {
	  fprintf(stderr,"Error:\n");
	  fprintf(stderr,"  Left rank %d, Right rank %d, ", i,j);
	  fprintf(stderr,"  Left shape[%d] %d, Right shape[1] %d\n", 
		  i, iconsts[LEFT->n.shape + i - 1],
		  iconsts[RIGHT->n.shape]);
	  error("inner product shape conformability");
	}
      }
      node->n.shape = cpivec(LEFT->n.shape, (i ? i - 1 : 0), -1);
      cpivec(RIGHT->n.shape + 1, (j ? j - 1 : 0), -1);
      node->n.info |= SHAPEKNOWN;
    }
    /* sws now store */
    copychild(STORE, LEFT, 1, 0, 0, 0);

    break;

  case DFORMAT:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    node->n.type = APLC_CHAR;
    node->n.info |= TYPEKNOWN;
    if (RIGHT->n.info & RANKKNOWN) {
      if (RIGHT->n.rank == 0)
	node->n.rank = 1;
      else
	node->n.rank = RIGHT->n.rank;
      node->n.info |= RANKKNOWN;
    }
    /* can try to generate shape as well, from left */
    break;

    /* matrix inverse - or someday perhaps pseudo inverse */
    /* based on monadic transpose */
  case DOMINO:
    doinf(RIGHT, 0);
    node->n.type = APLC_REAL;
    node->n.info |= TYPEKNOWN;
    copychild(node, RIGHT, 0, 1, 0, 0);
    if (RIGHT->n.info & SHAPEKNOWN) {
      sh = RIGHT->n.shape;
      rk = RIGHT->n.rank;
      node->n.shape = ictop;
      for (i = 1; i <= node->n.rank; i++)
	addicon(iconsts[sh + rk - i]);
      node->n.info |= SHAPEKNOWN;
    }
    break;

  case DROP:
  case GWDROP:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    if (is_scalar(RIGHT)) {
      copychild(node, RIGHT, 1, 0, 0, 0);
      /*fprintf(stderr, "scalar right\n");*/
      if ( (LEFT->n.info & VALUESKNOWN) && (LEFT->n.info & SHAPEKNOWN) ) { 
	if (is_scalar(LEFT)) {	
	  /*fprintf(stderr, "scalar left\n");*/
	  if (iconsts[LEFT->n.values]) {
	    /* result is .iota 0 */
	    node->n.info |= SHAPEKNOWN;
	    node->n.info |= RANKKNOWN;
	    node->n.rank = 1;
	    /*node->n.shape = addicon(0);*/
	    node->n.shape = addicon_scalar(0);
	  } else {
	    /* left is 0, result is vector right */
	    node->n.info |= SHAPEKNOWN;
	    node->n.info |= RANKKNOWN;
	    node->n.rank = 1;
	    node->n.shape = addicon_scalar(1);
	    copychild(node, RIGHT, 0,0,0,1);
	  }
	} else {
	  /*fprintf(stderr, "non-scalar left\n");*/
	  /* non-scalar left, scalar right */
	  /* not done */
	}
      }
    } else { 
      copychild(node, RIGHT, 1, 1, 0, 0);
      if ((RIGHT->n.info & SHAPEKNOWN) && (LEFT->n.info & VALUESKNOWN)) {
	if (RIGHT->n.rank != iconsts[LEFT->n.shape])
	  error("conformability - drop");
	sh = RIGHT->n.shape;
	rt = LEFT->n.values;
	node->n.shape = ictop;
	for (i = 0; i < node->n.rank; i++) {
	  j = iconsts[sh + i] - abs(iconsts[rt + i]);
	  /* make sure we don't drop too much */
	  j = (j < 0) ? 0 : j;
	  addicon(j);
	}
	node->n.info |= SHAPEKNOWN;
      }
    }
    break;

  case DSFUN:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    dsrtype(node->optype, node, LEFT, RIGHT);
    if (is_scalar(LEFT))
      copychild(node, RIGHT, 0, 1, 1, 0);
    else if (is_scalar(RIGHT))
      copychild(node, LEFT, 0, 1, 1, 0);
    else if (RKisknown(RIGHT) && RKisknown(LEFT)) {
      i = LEFT->n.rank;
      j = RIGHT->n.rank;
      if (i != j) {
	fprintf(stderr, "left rank= %d, right rank = %d\n",i,j);	
	error("[trs] dsfun rank error");
      }
      node->n.rank = RIGHT->n.rank;
      node->n.info |= RANKKNOWN;
      if ((LEFT->n.info & SHAPEKNOWN)
	  && (RIGHT->n.info & SHAPEKNOWN)) {
	for (i--; i > -0; i--)
	  if (iconsts[LEFT->n.shape + i] !=
	      iconsts[RIGHT->n.shape + i])
	    error("dsfun shape error");
	node->n.shape = RIGHT->n.shape;
	node->n.info |= SHAPEKNOWN;
      }
    }
    check_anyrank(node, LEFT);
    check_anyrank(node, RIGHT);
    break;

  case DTRANS:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    copychild(node, RIGHT, 1, 0, 0, 0);
#if 0
    /* right can be scalar if left is zilde */
    if (is_scalar(RIGHT))
      error("conformability - dyadic transpose");
#endif
    if (LEFT->n.info & VALUESKNOWN)
      dytrans(node);
    break;

  case EMPTSEMI:
    node->n.type = APLC_INT;
    node->n.rank = 1;
    node->n.info |= (TYPEKNOWN | RANKKNOWN);
    if ((node->axis)->n.info & SHAPEKNOWN) {
      node->n.shape = (node->axis)->n.shape + node->ptr1;
      node->n.info |= SHAPEKNOWN;
    }
    break;

  case ENCODE:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    if (RKisknown(RIGHT) && RKisknown(LEFT)) {
      node->n.rank = LEFT->n.rank + RIGHT->n.rank;
      node->n.info |= RANKKNOWN;
    }
    check_anyrank(node, LEFT);
    check_anyrank(node, RIGHT);
    if ((RIGHT->n.info & SHAPEKNOWN) && (LEFT->n.info & SHAPEKNOWN)) {
      /* copy shapes, one after the other into icon list */
      /* point to start */
      node->n.shape = cpivec(LEFT->n.shape, LEFT->n.rank, -1);
      cpivec(RIGHT->n.shape, RIGHT->n.rank, -1);
      node->n.info |= SHAPEKNOWN;
    }
    break;

  case EPSILON:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    node->n.type = APLC_BOOL;
    node->n.info |= TYPEKNOWN;
    copychild(node, LEFT, 0, 1, 1, 0);
    break;

  case EXECUTE:
    doinf(RIGHT, 0);
    break;

  case FIDENT:
    init_arb(node);
    if (RIGHT != NILP)
      doinf(RIGHT, 0);
    if (LEFT != NILP)
      doinf(LEFT, 0);
    break;

  case OPIDENT:
    init_arb(node);
    if (RIGHT != NILP)
      doinf(RIGHT, 0);
    if (LEFT != NILP)
      doinf(LEFT, 0);
    break;

  case FORMAT:
    doinf(RIGHT, 0);
    node->n.type = APLC_CHAR;
    node->n.info |= TYPEKNOWN;
    if (RIGHT->n.info & TYPEKNOWN) {
      if (RIGHT->n.type == APLC_CHAR) {
	if (RIGHT->n.info & RANKKNOWN) {
	  node->n.rank = RIGHT->n.rank;
	  node->n.info |= RANKKNOWN;
	}
	if (RIGHT->n.info & SHAPEKNOWN) {
	  node->n.shape = RIGHT->n.shape;
	  node->n.info |= SHAPEKNOWN;
	}
      }	else if (RIGHT->n.type == APLC_BOXED) {
	if (RIGHT->n.info & RANKKNOWN) {
	  node->n.rank = max(2, RIGHT->n.rank);
	  node->n.info |= RANKKNOWN;
	}
      } else {
	if (RIGHT->n.info & RANKKNOWN) {
	  if (RIGHT->n.rank == 0)
	    node->n.rank = 1;
	  else
	    node->n.rank = RIGHT->n.rank;
	  node->n.info |= RANKKNOWN;
	}
      }
    }
    break;

  case GO:
    if (!top)
      cant("non-top level branch");
    doinf(RIGHT, 0);
    if (RIGHT->n.rank > 1)
      error("scalar required");
    if (RIGHT->nodetype == LCON) {
      node->n.values = RIGHT->n.values;
    }
    break;

  case IDENT:
#ifdef INTRA
    doident(node);
#else
    init_arb(node);
#endif
    break;

  case INDEX:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    node->n.type = APLC_INT;
    node->n.info |= TYPEKNOWN;
    copychild(node, RIGHT, 0, 1, 1, 0);
    break;

  case INNER:
    doinf(RIGHT, 0);
    dsrtype(node->optype, node, RIGHT, RIGHT);
    copychild(node, RIGHT, 0, 1, 1, 0);
    break;

  case IOTA:
    doinf(RIGHT, 0);
    if ((RIGHT->n.info & TYPEKNOWN) && (!typemake(APLC_INT, RIGHT->n.type)))
      error("iota on non-integer");
      /*    if ((RIGHT->n.info & RANKKNOWN) && (RIGHT->n.rank > 0))*/
    if (isnot_scalar(RIGHT))
      error("iota on non-scalar");
    if (RIGHT->n.info & VALUESKNOWN) {
      if (iconsts[RIGHT->n.values] < 0)
	error("iota on negative value");
      node->n.shape = RIGHT->n.values;
      node->n.info |= SHAPEKNOWN;
    }
    node->n.type = APLC_INT;
    node->n.rank = 1;
    node->n.info |= (TYPEKNOWN | RANKKNOWN);
    break;

  case LCON:
#ifdef INTRA
    /*-- sws  label;      write down jump targets */
    dolcon(node);
#endif
    break;

  case LAM:
    error("laminate not implemented yet");
    /* sws   it is actually, in cat... */
    break;

    /* sws  solution to linear equations */
    /* based on decode */
  case MSOLVE:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    node->n.type = APLC_REAL;
    node->n.info |= TYPEKNOWN;
    if (RKisknown(RIGHT) && RKisknown(LEFT)) {
      i = LEFT->n.rank;
      j = RIGHT->n.rank;
      node->n.rank = (i ? i - 1 : 0) + (j ? j - 1 : 0);
      node->n.info |= RANKKNOWN;
      if (i > 2)
	error("[trs] rank error: msolve left argument");
      if (j > 2)
	error("[trs] rank error: msolve right argument");
    }
    if ((RIGHT->n.info & SHAPEKNOWN) && (LEFT->n.info & SHAPEKNOWN)) {
      if ((i > 0) && (j > 0)) {
	if (iconsts[LEFT->n.shape]
	    != iconsts[RIGHT->n.shape])
	  error("length error: msolve argument compatibility");
      }
    }
    if (RIGHT->n.info & SHAPEKNOWN) {
      if (j > 0) {
	if (iconsts[RIGHT->n.shape]
	    < iconsts[RIGHT->n.shape + j - 1])
	  error("length error: msolve right argument");
      }
      node->n.shape = cpivec(RIGHT->n.shape + 1, (j ? j - 1 : 0), -1);
      cpivec(LEFT->n.shape + 1, (i ? i - 1 : 0), -1);
      node->n.info |= SHAPEKNOWN;
    }
    break;

  case MSFUN:
    doinf(RIGHT, 0);
    rt = APLC_UKTYPE;
    switch(node->optype) {
    default:
      caserr("doinf", node->nodetype);
      break;
    case APLC_NOT:
      rt = APLC_BOOL;
      break;
    case APLC_ABS:
      /* if (RIGHT->n.info & TYPEKNOWN)*/
      /* could be any - don't force real in that case */
      if ( TYPEisknown(RIGHT) )
	rt = min(APLC_REAL, RIGHT->n.type);
      /* type for z, q, is real */
      break;
    case APLC_PLUS:
    case APLC_MINUS:
    case APLC_FACT:
      if (RIGHT->n.info & TYPEKNOWN)
	rt = RIGHT->n.type;
      break;
    case APLC_TIMES:
    case APLC_FLOOR:
    case APLC_CEIL:
      /* rt = APLC_INT;*/
      if ( TYPEisknown(RIGHT) ) {
	switch(RIGHT->n.type) {
	default:
	  break;
	case APLC_BOOL:
	case APLC_INT:
	case APLC_REAL:
	  rt = APLC_INT;
	  break;
	case APLC_COMPLEX:
	  rt = APLC_COMPLEX;
	  break;
	case APLC_QUAT:
	  rt = APLC_QUAT;
	  break;
	case APLC_OCT:
	  rt = APLC_OCT;
	  break;
	}
      }
      break;
    case APLC_DIVIDE:
    case APLC_EXP:
    case APLC_LOG:
    case APLC_CIRCLE:
      /* rt = APLC_REAL;*/
      if ( TYPEisknown(RIGHT) )
	rt = max(APLC_REAL, RIGHT->n.type);
      break;
    }
    if (rt != APLC_UKTYPE) {
      node->n.type = rt;
      node->n.info |= TYPEKNOWN;
    }
    copychild(node, RIGHT, 0, 1, 1, 0);
    break;

  case OUTER:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    dsrtype(node->optype, node, LEFT, RIGHT);
    outershape(node);
    break;

  case RAVEL:
    doinf(RIGHT, 0);
    if (RIGHT->n.info & TYPEKNOWN) {
      node->n.type = RIGHT->n.type;
      node->n.info |= TYPEKNOWN;
    }
    node->n.rank = 1;
    node->n.info |= RANKKNOWN;
    if (RIGHT->n.info & SHAPEKNOWN) {
      node->n.shape = addicon_scalar(numin(RIGHT));
      node->n.info |= SHAPEKNOWN;
    }
    if (RIGHT->n.info & VALUESKNOWN) {
      node->n.values = RIGHT->n.values;
      node->n.info |= VALUESKNOWN;
    }
    break;

  case REDUCE:
    infaxis(node);
    doinf(RIGHT, 0);
    if (RKisknown(RIGHT)) {
      if (RIGHT->n.rank == 0) {
	/* right is a scalar, result is right */
	node->n.rank = 0;
      } else {
	node->n.rank = RIGHT->n.rank - 1;
      }
      node->n.info |= RANKKNOWN;
      if (node->n.rank == 0) {
	/* vector or scalar right, scalar result */
	node->n.shape = addicon_scalar(1);
	/*node->n.shape = 1;*/
	node->n.info |= SHAPEKNOWN;
      }
      if (RIGHT->n.info & SHAPEKNOWN) {
	if (RIGHT->n.rank == 1)
	  ; /* scalar result, already did it above */
	else if (node->n.info & FIRSTAXIS) {
	  node->n.shape = RIGHT->n.shape + 1;
	  node->n.info |= SHAPEKNOWN;
	} else if (node->n.info & LASTAXIS) {
	  node->n.shape = RIGHT->n.shape;
	  node->n.info |= SHAPEKNOWN;
	}
	/* only do type inferencing if right isn't a singleton */
	if (RIGHT->n.size > 1)
	  dsrtype(node->optype, node, RIGHT, RIGHT);
	else 
	  copychild(node, RIGHT, 1,0,0,0);
      }
    }
    check_anyrank(node, RIGHT);
    break;

  case REVERSE:
    infaxis(node);
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1, 1, 1, 0);
    break;

  case RESHAPE:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    if (RIGHT->n.info & TYPEKNOWN) {
      node->n.type = RIGHT->n.type;
      node->n.info |= TYPEKNOWN;
    }
    if (LEFT->n.info & SHAPEKNOWN) {
      node->n.rank = iconsts[LEFT->n.shape];
      node->n.info |= RANKKNOWN;
    }
    if (LEFT->n.info & VALUESKNOWN) {
      node->n.shape = LEFT->n.values;
      node->n.info |= SHAPEKNOWN;
      if (RIGHT->n.info & SHAPEKNOWN)
	if ((numin(RIGHT) >= numin(node)) &&
	    (RIGHT->n.info & VALUESKNOWN)) {
	  node->n.values = RIGHT->n.values;
	  node->n.info |= VALUESKNOWN;
	}
    }
    break;

  case RHO:
    node->n.type = APLC_INT;
    node->n.rank = 1;
    node->n.info |= (TYPEKNOWN | RANKKNOWN);
    doinf(RIGHT, 0);
    if (RKisknown(RIGHT)){
      node->n.shape = addicon_scalar(RIGHT->n.rank);
      node->n.info |= SHAPEKNOWN;
      if (RIGHT->n.info & SHAPEKNOWN) {
	node->n.values = RIGHT->n.shape;
	node->n.info |= VALUESKNOWN;
      }
    }
    break;

    /* rank */
  case RHORHO:
    node->n.type = APLC_INT;
    node->n.rank = 0;
    node->n.shape = addicon_scalar(1);
    node->n.info |= (TYPEKNOWN | RANKKNOWN | SHAPEKNOWN);
    doinf(RIGHT, 0);
    if (RKisknown(RIGHT)){
      node->n.values = addicon_scalar(RIGHT->n.rank);
      node->n.info |= VALUESKNOWN;
    }
    break;

  case ROLL:
    doinf(RIGHT, 0);
    if ( (RIGHT->n.info & TYPEKNOWN) && (!typemake(APLC_INT, RIGHT->n.type)) )
      error("integer value required");
    node->n.type = APLC_INT;
    node->n.info |= TYPEKNOWN;
    copychild(node, RIGHT, 0, 1, 1, 0);
    break;

  case ROTATE:
    doinf(RIGHT, 0);
    infaxis(node);
    doinf(LEFT, 0);
    copychild(node, RIGHT, 1, 1, 1, 0);
    break;

  case SCAN:
    doinf(RIGHT, 0);
    infaxis(node);
    scantype(node->optype, node, RIGHT);
    copychild(node, RIGHT, 0, 1, 1, 0);
    break;

  case SM:
    if (RIGHT->nodetype == EMPTSEMI) {
      RIGHT->axis = node->axis;/* warning!! causes trouble when freeing */
      RIGHT->ptr1 = node->ptr1;
    }
    doinf(RIGHT, 0);
    if (LEFT != NILP) {
      /* another SM */
      LEFT->axis = node->axis;/* warning!! causes trouble when freeing */
      doinf(LEFT, 0);
    }
    if (LEFT == NILP)
      copychild(node, RIGHT, 0, 1, 1, 0);
    else
      outershape(node);
    break;

  case SORT:
    doinf(RIGHT, 0);
    node->n.type = APLC_INT;
    node->n.rank = 1;
    node->n.info |= (TYPEKNOWN | RANKKNOWN);
    copychild(node, RIGHT, 0, 0, 1, 0);
    break;

  case SUB:
    /* LR order is ok here. left is id, right is [list] 
       left:IDENT, right: SM */ 
    doinf(LEFT, 0);
    RIGHT->axis = LEFT;/* warning!! causes trouble when freeing */
    doinf(RIGHT, 0);
    copychild(node, LEFT, 1, 0, 0, 0);
    copychild(node, RIGHT, 0, 1, 1, 0);
    break;

  case SUBASSIGN:
    doinf(RIGHT, 0);
    /* ordering of L A is ok here; subid, sublist */ 
    doinf(LEFT, 0);
    AXIS->axis = LEFT;/* warning!! causes trouble when freeing */
    /* type of node itself is changed to right */
    /* mergetype(node, LEFT, RIGHT);*/
    if (RIGHT->n.info & TYPEKNOWN) {
      node->n.type = RIGHT->n.type;
      node->n.info |= TYPEKNOWN;
    }      
    doinf(AXIS, 1);
    mergetype(STORE, LEFT, RIGHT);
    /* sws  now get rank and shape, if available from left (ident) */
    /* probably not a good idea... */
    /* copychild(STORE, LEFT, 0, 1, 1, 0);*/
    /* sws  now deal with node itself 
       - the node shape comes from the right
       - if the right is a scalar, and axis is not, the assignment works
       - this can be extended to singletons also
       - hence to do error checking need all shapes 
     */
    if ( RKisknown(RIGHT) ){
      node->n.rank = RIGHT->n.rank;
      node->n.info |= RANKKNOWN;
      if ( RIGHT->n.info & SHAPEKNOWN ) {
	node->n.shape = RIGHT->n.shape;
	node->n.info |= SHAPEKNOWN;
	/* we can perhaps do some error checking */
	if ( RKisknown(AXIS) && (AXIS->n.info & SHAPEKNOWN) ) {
	  /* know everything, so check */
	  /* singleton right matches anything */
	  if ( 1 !=ksize(RIGHT) ) {
	    /* not a singleton - normal rank/shape checks 
	       note singleton shapes don't count in rank test */
	    if ( check_nsrank(&(RIGHT->n), &(AXIS->n)) ) {
	      print_rkshape(stderr, "axis", &(AXIS->n));
	      print_rkshape(stderr, "right", &(RIGHT->n));
	      error("[trs] sub assignment rank error");	      
	    }
	  }
	}
      }
    } else if ( RKisknown(AXIS) ) {
      /* ok, right rank isn't known 
	 - so only use axis if we're sure we don't have a singleton */
      if (AXIS->n.info & SHAPEKNOWN) {
	/* know all axis shape */
	if (1 != ksize(AXIS) ) {
	  /* not a singleton */
	  node->n.rank = AXIS->n.rank;
	  node->n.info |= RANKKNOWN;
	  node->n.shape = AXIS->n.shape;
	  node->n.info |= SHAPEKNOWN;
	}
      }
    }
    /* sws why isn't this in SUB as well? requires known left rank ? */
    if ( (LEFT->n.rank != NORANK) && (LEFT->n.rank != ANYRANK) &&
	(LEFT->n.rank != AXIS->ptr1 + 1) ) {
      fprintf(stderr, "left rank= %d, subscripts: %d\n",
	  LEFT->n.rank, AXIS->ptr3 + 1);
      error("[trs] sub assignment rank error");
    }
    check_anyrank(node, RIGHT);
#ifdef INTRA
    /* note that type can change in sub assignment,
       for example int to real */
    doassign(LEFT->namep, STORE);
#endif
    break;

  case DSYSFUN:
  case ESYSFUN:
  case MSYSFUN:
    if (RIGHT != NILP)
      doinf(RIGHT, 0);
    if (LEFT != NILP)
      doinf(LEFT, 0);
    optype = (enum sysvars) node->optype;
    switch(optype) {
    default:
      node->n.type = APLC_ANY;
      break;
    case SYS_AZ:
      /* output is a real array */
      node->n.type = APLC_REAL;
      node->n.info |= TYPEKNOWN;
      if (LEFT != NILP) {
	/* ... */
      } else {
	/* if right type and shape are known 
	 - then shape is known */
	if ( TYPEisknown(RIGHT) && (RIGHT->n.info & SHAPEKNOWN) ) {
	  switch (RIGHT->n.type) {
	  default:
	    break;
	  case APLC_BOOL:
	  case APLC_INT:
	  case APLC_REAL:
	  case APLC_CHAR:
	    /* no change */
	    node->n.rank = RIGHT->n.rank;
	    node->n.info |= RANKKNOWN;
	    node->n.shape = RIGHT->n.shape;
	    node->n.info |= SHAPEKNOWN;
	    break;
	  case APLC_COMPLEX:
	    node->n.info |= RANKKNOWN;
	    node->n.info |= SHAPEKNOWN;
	    rk = RIGHT->n.rank;
	    if (rk == 0) {
	      /* right is scalar, so vector, length 2 */
	      node->n.rank = 1;
	      node->n.shape = addicon_scalar(2);
	    } else {
	      node->n.rank = rk+1;
	      node->n.shape = ictop;
	      addicon(2);
	      for (i=0; i<rk; i++) {
		addicon( iconsts[RIGHT->n.shape +i] );
	      }
	    }
	    break;
	  case APLC_QUAT:
	    break;
	  case APLC_OCT:
	    break;
	  }
	}
      }
      break;
    case SYS_ZA:
      /* if right shape is known, 
	 - then type and shape are known */
      break;
    case SYS_FCNTL:
      if ( TYPEisknown(LEFT) && (LEFT->n.type != APLC_CHAR) )
	error("character left argument required");
      if (isnot_vector(LEFT))
	error("scalar/vector left argument required");
      if ( (RIGHT->n.info & TYPEKNOWN) && (!typemake(APLC_INT, RIGHT->n.type)) )
	error("integer right argument required");
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->n.rank = 1;
      node->n.type = APLC_INT;
      node->n.info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_LSEEK:
      if ( TYPEisknown(LEFT) && (LEFT->n.type != APLC_CHAR) )
	error("character left argument required");
      if (isnot_scalar(LEFT))
	error("scalar left argument required");
    case SYS_CL:
      if ( TYPEisknown(RIGHT) && (!typemake(APLC_INT, RIGHT->n.type)) )
	error("integer right argument required");
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->n.rank = 1;
      node->n.type = APLC_INT;
      node->n.info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_OP: 
      if (LEFT != NILP) {
#if 0
	if ( TYPEisknown(LEFT) && (LEFT->n.type != APLC_CHAR) )
	  error("character left argument required");
#endif
	if (isnot_vector(LEFT))
	  error("vector left argument required");
      }
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->n.rank = 1;
      node->n.type = APLC_INT;
      node->n.info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_SYS:
    case SYS_FREE:
    case SYS_VTYPE:
      node->n.rank = 0;
      node->n.type = APLC_INT;
      node->n.info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_FI:
      break;
    case SYS_VI:
      node->n.type = APLC_BOOL;
      break;
    case SYS_DL:
      node->n.rank = 0;
      node->n.type = APLC_REAL;
      node->n.info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_FREAD:
      if (isnot_vector(RIGHT))
	error("scalar/vector right argument required");
      node->n.rank = 1;
      node->n.info |= RANKKNOWN;
      if (LEFT != NILP) {
	if (is_scalar(LEFT)) {
	  node->n.type = APLC_CHAR;
	  node->n.info |= TYPEKNOWN;
	}
      }
      break;
    case SYS_FWRITE:
    case SYS_FAPPEND:
      /* 7/2003 allow non-char right 
      if ( TYPEisknown(RIGHT) && (RIGHT->n.type != APLC_CHAR) )
      error("character right argument required");*/
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->n.rank = 0;
      node->n.type = APLC_INT;
      node->n.info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_READLINE:
      if (isnot_vector(RIGHT))
	error("scalar/vector right argument required");
      node->n.rank = 1;
      node->n.type = APLC_CHAR;
      node->n.info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_SPAWN:
      /* LEFT may be scalar INT or vector or array CHAR */
      if ( TYPEisknown(RIGHT) && (RIGHT->n.type != APLC_CHAR) )
	error("character right argument required");
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->n.rank = 1;
      node->n.type = APLC_INT;
      node->n.info |= (TYPEKNOWN | RANKKNOWN);
      break;

    case SYS_PIPE:
      if ( TYPEisknown(LEFT) && (LEFT->n.type != APLC_CHAR) ) {
	fprintf(stderr," pipe LEFT: ");
	print_info(stderr, &(LEFT->n));
	fprintf(stderr,"\n");
	error("character left argument required");
      }
	/*      if ((LEFT->n.info & RANKKNOWN) && (LEFT->n.rank > 1))*/
      if (isnot_vector(LEFT))
	error("vector left argument required");
      if ( TYPEisknown(RIGHT) && (RIGHT->n.type != APLC_CHAR)) { 
	fprintf(stderr," pipe RIGHT: ");
	print_info(stderr, &(RIGHT->n));
	fprintf(stderr,"\n");
	error("character right argument required");
      }
      /*      if ((RIGHT->n.info & RANKKNOWN) && (RIGHT->n.rank > 1))*/
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->n.rank = 1;
      node->n.type = APLC_CHAR;
      node->n.info |= (TYPEKNOWN | RANKKNOWN);
      break;

    case SYS_SS:
      if ( TYPEisknown(LEFT) && (LEFT->n.type != APLC_CHAR) )
	error("character left argument required");
	/*      if ((LEFT->n.info & RANKKNOWN) && (LEFT->n.rank > 1))*/
      if (isnot_vector(LEFT))
	error("vector left argument required");
      if ( TYPEisknown(RIGHT) && (RIGHT->n.type != APLC_CHAR) )
	error("character right argument required");
      /*      if ((RIGHT->n.info & RANKKNOWN) && (RIGHT->n.rank > 1))*/
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->n.rank = 1;
      node->n.type = APLC_BOOL;
      node->n.info |= (TYPEKNOWN | RANKKNOWN);
      break;
    }
    break;

  case ASYSVAR:
  case SYSVAR:
    if (RIGHT != NILP)
      doinf(RIGHT, 0);
    optype = (enum sysvars) node->optype;
    switch(optype) {
    case SYS_PP:
    case SYS_PRNG:
    case SYS_PW:
    case SYS_RL:
    case SYS_IO:
      node->n.type = APLC_INT;
      node->n.rank = 0;
      node->n.shape = addicon_scalar(1);
      node->n.info |= TYPEKNOWN;
      node->n.info |= RANKKNOWN;
      node->n.info |= SHAPEKNOWN;
      break;
    case SYS_OMAP:
      node->n.type = APLC_INT;
      node->n.rank = 1;
      node->n.shape = addicon_scalar(2);
      node->n.info |= TYPEKNOWN;
      node->n.info |= RANKKNOWN;
      node->n.info |= SHAPEKNOWN;
      break;
    case SYS_ARG:
      node->n.type = APLC_CHAR;
      node->n.rank = 2;
      node->n.info |= TYPEKNOWN;
      node->n.info |= RANKKNOWN;
      break;
    case SYS_TS:
      node->n.type = APLC_INT;
      node->n.rank = 1;
      node->n.shape = addicon_scalar(7);
      node->n.info |= TYPEKNOWN;
      node->n.info |= RANKKNOWN;
      node->n.info |= SHAPEKNOWN;
      break;
    default:
      node->n.type = APLC_ANY;
      break;
    }
    break;

  case TAKE:
  case GWTAKE:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    /* get - type from right
           - rank from right if not scalar */
    if ( isnot_scalar(RIGHT) )
      copychild(node, RIGHT, 1, 1, 0, 0);
    else
      copychild(node, RIGHT, 1, 0, 0, 0);
    check_anyrank(node, RIGHT);
    /* if rank still not known, may get it from left shape */
    if ( ( ! (node->n.info & RANKKNOWN) )  
	 && (LEFT->n.info & RANKKNOWN) 
	 && (LEFT->n.info & SHAPEKNOWN) ) {
      /* get rank from left size */
      if (LEFT->n.rank == 0)
	node->n.rank = 1;
      else 
	node->n.rank = iconsts[LEFT->n.shape];
      node->n.info |= RANKKNOWN;
    }
    if (LEFT->n.info & VALUESKNOWN) {
      node->n.shape = ictop;
      rt = LEFT->n.values;
      for (i = 0; i < node->n.rank; i++) {
	if (iconsts[rt + i] < 0)
	  addicon(-iconsts[rt + i]);
	else
	  addicon(iconsts[rt + i]);
      }
      node->n.info |= SHAPEKNOWN;
    }
    break;

  case TCAV:
  case TYPECON:
    break;

  case TRANS:
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1, 1, 0, 0);
    if (RIGHT->n.info & SHAPEKNOWN) {
      node->n.shape = ictop;
      sh = RIGHT->n.shape;
      rk = RIGHT->n.rank;
      for (i = 1; i <= node->n.rank; i++)
	addicon(iconsts[sh + rk - i]);
      node->n.info |= SHAPEKNOWN;
    }
    break;
  } /* end of nodetype switch */

  /* just in case we haven't caught it already, catch scalars here 
     - this shouldn't be necessary, but some code does refer to
       n.shape for scalars */
  if (is_scalar(node)) {
#if TDEBUG
    /* info for debugging */ 
    fprintf(stderr, "scalar n.shape = %d, shapeknown %d, node %d %s\n", 
	    node->n.shape, node->n.info & SHAPEKNOWN, 
	    node->nodetype, prtoken(node->nodetype));
    /* cause a crash for debugging:
    if (node->n.shape <0) {
      *(char *) node->n.shape = 0;
      } */
#endif
    if (0 == node->n.shape)
      node->n.shape = addicon_scalar(1);
    node->n.info |= SHAPEKNOWN;
  }
  /* ensure that the size is set if it is known */
  if (node->n.info & SHAPEKNOWN)
    node->n.size = ksize(node);
  return;
}


/* cpivec - copy an integer vector, skipping a position */
int
cpivec(int start, int size, int pos)
{
  int i, k;

  k = ictop;
  for (i = 0; i < size; i++)
    if (i + 1 != pos)
      addicon(iconsts[start + i]);
  return k;
}


/* catshape - determine shape and rank information for catenate 
              only knows about last axis currently - can improve this

	      doesn't know about laminate... handled in lamshape */
void
catshape(struct node * node)
{
  int i, j, ls, rs;

#if CATDEBUG
  fprintf(stderr, "\n[catshape] %s start", node->namep);
  print_info(stderr, &(node->n)); 
  fprintf(stderr, "\n");
#endif

  /* ensure we start fresh */
  remove_shape_info(&(node->n));
  if ( RKisknown(LEFT) && RKisknown(RIGHT) ) {
    i = LEFT->n.rank;
    j = RIGHT->n.rank;
    if (i == 0)
      if (j == 0) {
	node->n.rank = 1;
	node->n.shape = addicon_scalar(2);
	node->n.info |= SHAPEKNOWN;
      } else
	node->n.rank = RIGHT->n.rank;
    else if ((j == 0) || (i == j) || (i == j + 1))
      node->n.rank = LEFT->n.rank;
    else if (i + 1 == j)
      node->n.rank = RIGHT->n.rank;
    else {
      fprintf(stderr, "\n[catshape] ");
      fprintf(stderr, "left rank= %d, right rank= %d\n", i, j);
      error("[trs] catenate rank error");
    }
    node->n.info |= RANKKNOWN;
    /* now we have rank, try shape */
    if ((LEFT->n.info & SHAPEKNOWN) && (RIGHT->n.info & SHAPEKNOWN)) {
      ls = LEFT->n.shape;
      rs = RIGHT->n.shape;
      if (node->n.info & LASTAXIS) {
#if CATDEBUG
	fprintf(stderr, "catshape lastaxis\n");
#endif
	if (i == 0) { /* i and j are still valid */
	  /* left scalar */
	  if (j == 0)
	    ; /* both scalars; did it already above */
	  else {
	    node->n.shape = cpivec(rs, j, -1);
	    iconsts[node->n.shape + j - 1]++;
	    node->n.info |= SHAPEKNOWN;
	  }
	} else if (j == 0) {
	  /* right scalar */
	  node->n.shape = cpivec(ls, i, -1);
	  iconsts[node->n.shape + i - 1]++;
	  node->n.info |= SHAPEKNOWN;
	} else if (i == j) {
	  /* equal ranks; not scalar */
	  node->n.shape = cpivec(ls, i, -1);
	  iconsts[node->n.shape + i - 1] += iconsts[rs + i - 1];
	  node->n.info |= SHAPEKNOWN;
	  /* warning, last axis assumed */
	  for (i -= 2; i >= 0; i--)
	    if (iconsts[ls + i] != iconsts[rs + i])
	      error("catenate conformability (1)");
	} else if (i + 1 == j) {
	  node->n.shape = cpivec(ls, i, -1);
	  addicon( iconsts[rs + j-1]+1 );
	  node->n.info |= SHAPEKNOWN;
	  for (j -= 2; j >= 0; j--)
	    if (iconsts[ls + j] != iconsts[rs + j])
	      error("catenate conformability (2)");
	} else if (i == j + 1) {
	  node->n.shape = cpivec(rs, j, -1);
	  addicon( iconsts[ls + i-1]+1 );
	  node->n.info |= SHAPEKNOWN;
	  for (i -= 2; i >= 0; i--)
	    if (iconsts[ls + i] != iconsts[rs + i])
	      error("catenate conformability (3)");
	} else
	  error("catenate conformability (4)");
	/* end of lastaxis */
      } else if (node->n.info & FIRSTAXIS) {
#if CATDEBUG
	fprintf(stderr, "catshape firstaxis\n");
#endif
	if (i == 0) { /* i and j are still valid */
	  /* left scalar */
	  if (j == 0)
	    ; /* both scalars; did it already above */
	  else {
	    node->n.shape = cpivec(rs, j, -1);
	    iconsts[node->n.shape]++;
	    node->n.info |= SHAPEKNOWN;
	  }
	} else if (j == 0) {
	  /* right scalar */
	  node->n.shape = cpivec(ls, i, -1);
	  iconsts[node->n.shape]++;
	  node->n.info |= SHAPEKNOWN;
	} else if (i == j) {
	  /* equal ranks; not scalar */
	  node->n.shape = cpivec(ls, i, -1);
	  iconsts[node->n.shape] += iconsts[rs];
	  node->n.info |= SHAPEKNOWN;
	  /* warning, first axis assumed */
	  for (i -= 1; i > 0; i--)
	    if (iconsts[ls + i] != iconsts[rs + i])
	      error("catenate conformability (11)");
	} else if (i + 1 == j) {
	  node->n.shape = cpivec(rs, j, -1);
	  iconsts[node->n.shape] += 1; 
	  node->n.info |= SHAPEKNOWN;
	  for (j -= 1; j > 0; j--)
	    if (iconsts[ls + j-1] != iconsts[rs + j]) {
	      fprintf(stderr, " (%d vs %d)\n", iconsts[ls + j-1], iconsts[rs + j]);
	      error("catenate conformability (12)");
	    }
	} else if (i == j + 1) {
	  node->n.shape = cpivec(ls, i, -1);
	  iconsts[node->n.shape] += 1; 
	  node->n.info |= SHAPEKNOWN;
	  for (i -= 1; i > 0; i--)
	    if (iconsts[ls + i] != iconsts[rs + i-1]) {
	      fprintf(stderr, " (%d vs %d)\n", iconsts[ls+i], iconsts[rs+i-1]);
	      error("catenate conformability (13)");
	    }
	} else
	  error("catenate conformability (14)");
	/* end of firstaxis */
      } /* else axis value */
    }
  } 
  return;
}

/* copy vector into iconsts, except for x at pos */
int
cpivec2(int start, int size, int pos, int x)
{
  int i, k;

  k = ictop;
  for (i = 0; i < size; i++) {
    if (i + 1 == pos)
      addicon(x);
    addicon(iconsts[start + i]);
  }
  /* may not have added x yet */
  if (i + 1 == pos)
    addicon(x);
  return k;
}


/* lamshape - determine shape and rank information for catenate 
              with known non-integer axis - laminate 
 */
void
lamshape(struct node *node)
{
  double ax;
  int maxrk;
  int iax;
  int i;

  if (!(AXIS->n.info & VALUESKNOWN) )
    return;/* don't know enough to infer anything */
  /* assume scalar for now - later should check 
     (anything else is error) */
  if (AXIS->n.rank != 0)
    fprintf(stderr,"[lamshape] require scalar axis, got rank %d\n", AXIS->n.rank);
  ax = rconsts[AXIS->n.values];/* the axis value */
  iax = ceil(ax);/* the result axis */

#if CATDEBUG
  fprintf(stderr,"\n[trs] lamshape, axis = %f %d;", ax, iax);
#endif
  if (iax < 1) {
    fprintf(stderr,"[lamshape] axis %g, left rank %d, right rank %d\n", 
	    ax, LEFT->n.rank, RIGHT->n.rank);
    error("catenate/laminate axis error (axis<=0) ");
  }
  if ( ! (RKisknown(LEFT) && RKisknown(RIGHT) ) )
    return;
  maxrk = max(LEFT->n.rank, RIGHT->n.rank);
#if CATDEBUG
  fprintf(stderr," Lrk %d, Rrk %d, max %d;", 
	  LEFT->n.rank, RIGHT->n.rank, maxrk);
#endif
  if ( iax > 1.0 + maxrk ) {
    fprintf(stderr,"[lamshape] axis %g, left rank %d, right rank %d\n", 
	    ax, LEFT->n.rank, RIGHT->n.rank);
    error("catenate/laminate axis error (axis > maxrank+1)");
  }

  if (maxrk == 0) {
    /* both left and right are scalars */
    node->n.rank = 1;
    node->n.shape = addicon_scalar(2);
    node->n.info |= SHAPEKNOWN;
    node->n.info |= RANKKNOWN;
    return;
  }
  node->n.rank = maxrk + 1;
  node->n.info |= RANKKNOWN;

#if CATDEBUG
  fprintf(stderr," Nrk %d;", node->n.rank);
  fprintf(stderr," Shkn (%d,%d);", LEFT->n.info & SHAPEKNOWN,
	  RIGHT->n.info & SHAPEKNOWN);
#endif
  /* check that we know left and right shapes; if not just quit */
  if (! ((LEFT->n.info & SHAPEKNOWN) && (RIGHT->n.info & SHAPEKNOWN))) {
    /*node->n.info ^= RANKKNOWN;*/
    return;
  }

  /* shape ...
     - create copies of left,right shapes with an extra axis, shape 1
     - combine to get the node shape   */
  if (LEFT->n.rank == 0) {
    /* left is scalar; right is not */
    node->n.shape = cpivec2(RIGHT->n.shape, RIGHT->n.rank, iax, 2);
  } else if (RIGHT->n.rank == 0) {
    /* right is scalar; left is not */
    node->n.shape = cpivec2(LEFT->n.shape, LEFT->n.rank, iax, 2);
  } else {
    /* neither is scalar; should check 
     - ranks must match 
     - shapes must match */
    if (LEFT->n.rank != RIGHT->n.rank) {
      fprintf(stderr,"[lamshape] axis %g, left rank %d, right rank %d\n", 
	      ax, LEFT->n.rank, RIGHT->n.rank);
      error("laminate rank error (ranks not equal)");
    }    
    for (i=0; i<LEFT->n.rank; i++)
      if ( iconsts[LEFT->n.shape+i] != iconsts[RIGHT->n.shape+i] ) {
	fprintf(stderr,"[lamshape] left shape");
	print_shape(stderr, &LEFT->n);
	fprintf(stderr,"[lamshape] right shape");
	print_shape(stderr, &RIGHT->n);
	error("laminate shape error (shapes not equal)");
      }
    /* either will do */
    node->n.shape = cpivec2(LEFT->n.shape, LEFT->n.rank, iax, 2);
    /*node->n.shape = cpivec2(RIGHT->n.shape, RIGHT->n.rank, iax, 2);*/
  }
  node->n.info |= SHAPEKNOWN;
#if CATDEBUG
  fprintf(stderr," new shape");
  print_shape(stderr, &node->n);
#endif
  return;
}

/* dytrans - compute rank and shape for dyadic transpose */
void
dytrans(struct node * node)
{
  int size, c, s, k, i, j, *vec, *shape;

  size = iconsts[LEFT->n.shape];
  vec = &iconsts[LEFT->n.values];
  c = 0;
  s = 1;
  for (i = 1; i <= size && s == 1; i++) {
    s = 0;
    for (j = 0; j < size; j++)
      if (vec[j] == i) {
	node->n.rank = i;
	c++;
	s = 1;
      }
  }
  node->n.info |= RANKKNOWN;
  if (c != size)
    error("dyadic transpose value error");
  if (!(RIGHT->n.info & SHAPEKNOWN))
    return;
  shape = &iconsts[RIGHT->n.shape];
  node->n.shape = ictop;
  for (i = 0; i < node->n.rank; i++) {
    k = 15000;
    for (j = 0; j < size; j++)
      if (vec[j] == i + 1 && shape[j] < k)
	k = shape[j];
    addicon(k);
  }
  node->n.info |= SHAPEKNOWN;
}

/* outershape - generate shape information for outer product and for
                semicolons
*/
void
outershape(struct node * node)
{
  if ( RankIsKnown(LEFT) && RankIsKnown(RIGHT) ) {
    node->n.rank = LEFT->n.rank + RIGHT->n.rank;
    node->n.info |= RANKKNOWN;
    if ((LEFT->n.info & SHAPEKNOWN) && (RIGHT->n.info & SHAPEKNOWN)) {
      node->n.shape = cpivec(LEFT->n.shape, LEFT->n.rank, -1);
      cpivec(RIGHT->n.shape, RIGHT->n.rank, -1);
      node->n.info |= SHAPEKNOWN;
    }
  }
  check_anyrank(node, LEFT);
  check_anyrank(node, RIGHT);
  return;
}

/* end of trs.c */

