/*
	APL Compiler

	definitions for malloc used at runtime are concentrated here 
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

/*
	Define 5 functions:

	APLC_CMALLOC(size)  allocate space for chars
	APLC_IMALLOC(size)  allocate space for ints
	APLC_DMALLOC(size)  allocate space for doubles

	APLC_IREALLOC(size) reallocate space for ints
	APLC_DREALLOC(size) reallocate space for doubles

History:
created by sws
8/21/2006 added cmalloc

*/

#ifndef _APLC_MEMALLOC_H
#define _APLC_MEMALLOC_H

/* turn this on for printing */
#define MEMDEBUG 0

/* for debugging */
#if 0
#include <dmalloc.h>
#endif

/* doesn't seem necessary anymore #ifdef SUNOS */
#if 0
/* malloc doesn't guarantee proper alignment on sparcs */

#define APLC_MALLOC(size)  malloc((size_t) size)
#define APLC_CMALLOC(size) malloc((unsigned) (size) * sizeof(char))

/* special test case */
void *aplc_imalloc(int size);
#define APLC_IMALLOC(size)  ((int *) aplc_imalloc(size))

/* this seems to work too...?
  define APLC_IMALLOC(size)  memalign(4, (unsigned) size*sizeof(double))
  malloc((unsigned) size*sizeof(double)));

these don't work  (only sometimes - ulam 21 or ulam 12):
 #define APLC_IMALLOC(size)   malloc((unsigned) size*sizeof(int))
 #define APLC_IMALLOC(size)  memalign(16, (unsigned) size*sizeof(int))
 #define APLC_IMALLOC(size)  memalign(8, (unsigned) size*sizeof(int))
                        memalign(4, (unsigned) size * sizeof(int))
  malloc((unsigned) size*sizeof(int))
*/

/* haven't noticed problems with this yet... */
#define APLC_DMALLOC(size)  (double *)memalign(8, (unsigned) (size) * sizeof(double))

#define APLC_IREALLOC(size)  aplc_irealloc(mp->ip, size)
#define APLC_DREALLOC(size)  aplc_drealloc(mp->rp, size)

#if 0
/* use matt's mem test routines */
#define APLC_IMALLOC(size)  mdb_malloc((unsigned) (size)*sizeof(int))
#define APLC_DMALLOC(size)  mdb_malloc((unsigned) (size)*sizeof(double))

#define APLC_IREALLOC(size) realloc(mp->ip, (unsigned) (size)*sizeof(int))
#define APLC_DREALLOC(size) realloc(mp->rp, (unsigned) (size)*sizeof(double))
#endif /* if 0 */

#elif defined(DJPC)|defined(ST)
/*|defined(LINUX)*/
/* these work for DJ's port of gcc to the 386 */

#define APLC_MALLOC(size)    malloc((unsigned) size)
#define APLC_CMALLOC(size)   malloc((unsigned) (size)*sizeof(char))
#define APLC_IMALLOC(size)   malloc((unsigned) (size)*sizeof(int))
#define APLC_DMALLOC(size)   malloc((unsigned) (size)*sizeof(double))

#define APLC_IREALLOC(size) realloc(mp->ip,(unsigned)(size)*sizeof(int))
#define APLC_DREALLOC(size) realloc(mp->rp,(unsigned)(size)*sizeof(double))

#else
/* general case for most unix; freebsd */

#define APLC_MTC 0
#if APLC_MTC==0
/* general malloc */
#define APLC_MALLOC(size)   malloc((size_t) size)
/* special cases */
#define APLC_CMALLOC(size)  malloc((size_t) (size)*sizeof(char))
#define APLC_IMALLOC(size)  malloc((size_t) (size)*sizeof(int))
#define APLC_DMALLOC(size)  malloc((size_t) (size)*sizeof(double))
#define APLC_IREALLOC(size) realloc(mp->ip,(size_t) (size)*sizeof(int))
#define APLC_DREALLOC(size) realloc(mp->rp,(size_t) (size)*sizeof(double))
#else
/* special test case */
void *aplc_malloc(size_t size, char *fn, int ln);
void *aplc_realloc(void *ptr, size_t size, char *fn, int ln);

#define APLC_MALLOC(size)   aplc_malloc((size_t) size,  __FILE__, __LINE__)
#define APLC_CMALLOC(size)  aplc_malloc((size_t) (size)*sizeof(char),  __FILE__, __LINE__)
#define APLC_IMALLOC(size)  aplc_malloc((size_t) (size)*sizeof(int),  __FILE__, __LINE__)
#define APLC_DMALLOC(size)  aplc_malloc((size_t) (size)*sizeof(double),  __FILE__, __LINE__)
#define APLC_IREALLOC(size) aplc_realloc(mp->ip,(size_t) (size)*sizeof(int),  __FILE__, __LINE__)
#define APLC_DREALLOC(size) aplc_realloc(mp->rp,(size_t) (size)*sizeof(double),  __FILE__, __LINE__)
#endif

#endif

#endif /* _APLC_MEMALLOC_H */
/* end of memalloc.h */
