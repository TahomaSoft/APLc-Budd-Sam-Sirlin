/* muser.c 
gateway program from matlab to aplc

monadic apl function 
    r .is user a

sws 3/95
*/

#include <math.h>
#include "mex.h"

#include "aplc.h"

int user(struct trs_struct *c, struct trs_struct *a, 
	 struct trs_struct *b);

void
mexFunction(int nlhs, Matrix *plhs[], int nrhs, Matrix *prhs[]) 
{
  static struct trs_struct c, a, b;
  int rb[2];
  int rank, *rc;
  int i;
  double *cp;

  /* put inputs in trs_struct */
  /* note that apl gets the transpose */
  rb[0] = mxGetN( prhs[0] );
  rb[1] = mxGetM( prhs[0] );
  aplc_settrs(&b, APLC_REAL, 2, rb);
  (b.value).rp = mxGetPr( prhs[0]);

  /* do apl function */
  user(&c, &a,&b);

  /* put results in outout to matlab */
  /* note matlab gets the transpose of the apl result */
  rank = c.rank;
  rc = c.shape;

/*
  printf("rank = %d\n", rank);
  printf("value[0] = %g\n", (c.value.rp)[0]);
*/

  if (rank == 0) {
    plhs[0] = mxCreateFull(1,1, 0);
    cp = mxGetPr( plhs[0]);
    cp[0] = (c.value.rp)[0];
  }
  else if (rank == 1) {
    plhs[0] = mxCreateFull(1,rc[0], 0);
    cp = mxGetPr( plhs[0]);
    for (i=0; i< rc[0]; i++)
      cp[i] = (c.value.rp)[i];
  }
  else if (rank == 2) {
    plhs[0] = mxCreateFull(rc[1],rc[0], 0);
    cp = mxGetPr( plhs[0]);
    for (i=0; i< rc[0]*rc[1]; i++)
      cp[i] = (c.value.rp)[i];
  }
  else {
    /* error */
  }
}

