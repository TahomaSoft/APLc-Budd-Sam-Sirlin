#include <stdio.h>

/* solaris 8/gcc output:

-0: -0.000000e+00 -0.000000 -0
 0 = 0 1, 0 = -0 1

freebsd:

-0: 0.000000e+00 0.000000 0
 0 = 0 1, 0 = -0 1

*/

int
main(void)
{
  double a=0.0;
  double b; 
  int i;

  b = -a;
  printf("-0: %e %f %g\n", b,b,b);
  printf(" 0 = 0 %d, 0 = -0 %d\n", 0==a, 0==b);
  for (i=2; i<20; i++)
    printf("%2d %*.*f\n", i,i+2,i,0.0);
  return 0;
}

