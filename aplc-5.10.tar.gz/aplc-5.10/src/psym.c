/*
	APL compiler
		parser symbol table routines
		timothy a. budd

	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include <stdio.h>
#include "parse.h"
#include "psym.h"

#define DEBUG 0

/***********************
	SYMBOL TABLES
************************/
/* locals */
struct symnode *lsymtab  = NILSYM;
/* globals */
struct symnode *gsymtab   = NILSYM;

/* from y_tab.h */
extern void yyerror(char *c);

/*static void rmglob(char *name, struct symnode * newp);*/
 

/* initialize local symbol tables */
extern void 
reinit_local_symtab(void)
{
  lsymtab = 0;
}

/* lookup a name in the current bsymbol tables, 
   return the type of symbol, and table entry */
extern class_t
idclass(char *name, struct symnode ** symptr)
{
  struct symnode *p;

  p = lookup_name(name, lsymtab);
  if (p) {
    *symptr = p;
    return p->class;
  }
  p = lookup_name(name, gsymtab);
  if (p) {
    *symptr = p;
    return p->class;
  }
  *symptr = NILSYM;
  return (NOCLASS);
}

#if 0
/* rmglob - remove a global identifier from local symbol table */
static void 
rmglob(char *name, struct symnode * newp)
{
  struct symnode *oldp;

  oldp = lookup_name(name, lsymtab);
  if (oldp != NILSYM) {
    oldp->name = '\0';
    if (oldp->s.type != APLC_UKTYPE)
      newp->s.type = oldp->s.type;
    if (oldp->s.rank != NORANK)
      newp->s.rank = oldp->s.rank;
  }
}
#endif

/* enterid - enter a new id into the current symbol tables */
extern struct symnode *
enterid(char *name, class_t class, int type, int rank)
{
  struct symnode *x = NILSYM;

#if DEBUG 
  switch (class) {
  case LABCLASS:
  case PARAM:
  case APARAM:
  case LOCAL:
  case LFUNCTION:
    fprintf(stderr,"[enterid] (%s) %s, %s, type %s, rank %s\n", 
	    funname,
	    name, str_class(class), str_type_name(type), str_rank(rank));
    break;
  default:
  case FUNCTION:
  case OPERATOR:
  case GLOBAL:
    fprintf(stderr,"[enterid] (main) %s, %s, type %s, rank %s\n", 
	    name, str_class(class), str_type_name(type), str_rank(rank));
    break;
  }
#endif
  switch (class) {
  case LABCLASS:
    x = add_sym(name,&lsymtab, NILCHAR,&lsymtab, class, APLC_LABEL, 0);
    break;
  case PARAM:
  case LOCAL:
  case LFUNCTION:
    x = add_sym(name,&lsymtab, NILCHAR,&lsymtab, class, type, rank);
    break;
  case APARAM:
    /* lookup the current function name */
    x = add_sym(name,&lsymtab, funname,&gsymtab, class, type, rank);
    break;
  case FUNCTION:
  case OPERATOR:
    x = add_sym(name,&gsymtab, NILCHAR,&gsymtab, class, type, rank);
    /*rmglob(name, x);*/
    break;
  case GLOBAL:
    x = lookup_name(name, gsymtab);
    if (x == NILSYM)
      putcharn(GLSYM);
    printf("%s\n", name);
    /* sws  */
    x = add_sym(name,&gsymtab, NILCHAR,&lsymtab, class, type, rank);
    /*rmglob(name, x);*/
    break;
  default:
    yyerror("unknown case in enterid\n");
  }
  return (x);
}

/* end of psym.c */

