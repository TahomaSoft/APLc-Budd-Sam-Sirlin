/*
	apl compiler
		access format inferencer
		timothy a. budd

	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

	This pass is in charge of setting two bits appropriately in the
	info field for each node - these bits are as follows

	SEQUENTIAL - access will be in ravel order, once through the 
	             entire structure

	HAVEVALUE - at the end of the shape phase the value field will 
                    have the pointer to all of memory for the node

	NOINDEX - set if the expression in the node does not need an index
		register (i.e., it is a scalar and always the same value,
		or access is sequential and it maintains its own counter).

	MERGED - set if the function of the node can be merged with its
		parent node to form a single accessor.

(sws)
        ASSIGNP - previous node is assign, and types match,
                  so a given trs may be used directly 
                  - only saves effort with certain nodes

        EARLYBIND - early binding needed for assign, 
                    finish in shape phase
                    set if a non assignment is made to a variable 
                    already referenced 

	HAVETRS - at the end of the shape phase tptr(ny) will be a trs 
	          with the value of the node

        ASSNAMEREF - for asgn node, name is used on the right

        ASSNAMEOK - it's ok to use the name directly in an assignment, 
                    rather than first using a numbered trs, then binding
                    to the name later 
    		  
 
------------------------------------------   
   lookout for cases like 
      a + a .is ...
   where we need to bind the assign early, and hence need to collect 
   a at once
   versus
      x + a .is ...
      a .is a + ...
   where we don't, and can 

*/

#include <stdio.h>

#include "parse.h"
#include "y_tab.h"
#include "nutil.h"

/* for more prints */
#define ADEBUG 0
#define SYDEBUG 0

/* external declarations */

/* sws  do we need singleton here ? */
#define is_scalar(node) ((node->n.info & RANKKNOWN) && (node->n.rank == 0))
#define is_vector(node) ((node->n.info & RANKKNOWN) && (node->n.rank == 1))
#define is_icon(node) ((node->nodetype == BCON) || (node->nodetype == ICON))


/* ------------------------------------------------ */

struct idnode {    /* id list node */
  char *name;
  struct idnode *next;
};
struct idnode *id_list;

static struct symnode *csyms;

/* ------------------------------------------------ */
/* local declarations */
void add_unique_sym(struct node *node, char *base );

static void setaxis(struct node * node);
static struct node *addcollect(struct node * node);

static int doaccess(struct node * node, int top);

#if ADEBUG
static void prt_id_list(void);
#endif
static void prt_idnode(struct idnode *node);
static void add_idnode(struct node *node);
static int match_idnode(char *name);
static void free_idnode(struct idnode *node);

static void init_id_list(void);
static void reinit_id_list(void);

int check_assign_ref(struct node * node, char *name );
int check_assign_ff(struct node * node, char *name, int seq);

/* ------------------------------------------------ */


/* ----------------------------------------- */
/* ----------------------------------------- */
/* This code is to lookout for cases like 
      a + a .is ...
   where we need to bind the assign early, and hence need to collect 
   a at once
   versus
      x + a .is ...
      a .is a + ...
   where we don't, and can 

  proceed down a statement
  - save ident names not used in assignments
  - at assign, check assign ident against current ident list
  - if a match then need early binding
*/
/* ----------------------------------------- */

#if ADEBUG
static void
prt_id_list(void)
{
  fprintf(stderr,"[access] current list:\n");
  prt_idnode(id_list);
  fprintf(stderr,". \n");
}
#endif

static void
prt_idnode(struct idnode *node)
{
  if ( node != NULL ) {
    if ( node->name != NULL ) {
      /*
      fprintf(stderr,"name %s\n", node->name); 
      fprintf(stderr,"next [%d]\n", (int) node->next); 
      */
      /*fprintf(stderr,"(%s, [%d])\n", node->name, (int) node->next); */
      /* this may not be available in non-iso C; just use above */
      fprintf(stderr,"(%s, [%p])\n", node->name, (void *) node->next); 
    }
    prt_idnode(node->next);
  }
}

static void
add_idnode(struct node *node)
{
  struct idnode *new;
  int n; 

#if ADEBUG
  fprintf(stderr,"[access] adding %s\n", node->namep);
#endif
  new = structalloc(idnode);
  n = strlen(node->namep);
  /* if size_t is not defined will need simpler call 
     - this should be handed in aplc_config.h */
  /* new->name = (char *) malloc( n);*/
  new->name = (char *) malloc( (size_t) n);
  /*new->name = (char *) malloc( (unsigned) n+1);*/
  strcpy(new->name, node->namep);
  new->next = id_list;
  id_list = new;

#if ADEBUG
  /* prt_id_list();*/
#endif
}

/* search list for a name
   return 1 if found */
static int
match_idnode(char *name)
{
  struct idnode *p;

#if ADEBUG
  fprintf(stderr,"[access] match; looking for %s\n", name);
  prt_id_list();
#endif
  for (p=id_list; p != NULL; p = p->next) {
#if ADEBUG
    fprintf(stderr,"[access] at %s\n", p->name);
#endif
    if (strcmp(p->name, name) == 0) {
#if ADEBUG
      fprintf(stderr,"[access] (found match)\n");
#endif
      return 1;
    }
#if ADEBUG
    fprintf(stderr,"[access] not a match [%p]\n", (void *)p->next);
#endif
  }

#if ADEBUG
  fprintf(stderr,"[access] no match found\n");
#endif
  return 0;
}

static void
free_idnode(struct idnode *node)
{
#if ADEBUG
  /*  fprintf(stderr,"[access] free\n");*/
#endif
  if ( node != NULL ) {
    /*fprintf(stderr,"[access] deeper [%d]\n", (int) node);*/
    if ( node->next != NULL ) {
      free_idnode(node->next);
      free(node->next);      
    }
    if ( node->name != NULL )
      free(node->name);      
  }
}

static void
init_id_list(void)
{
  /* free_idnode(id_list);*/
  id_list = NULL;
}

static void
reinit_id_list(void)
{
  free_idnode(id_list);
  free(id_list); 
  id_list = NULL;
}

/* ----------------------------------------- */
/* 1/17/2004 
   for assignment, check to see if the name is used on the left */
int
check_assign_ref(struct node * node, char *name )
{
  int used = 0;

  switch (node->nodetype) {
  default:
    if (LEFT != NILP)
      used = check_assign_ref(LEFT, name);
    if ((!used) && RIGHT != NILP)
      used = check_assign_ref(RIGHT, name);
    if ((!used) && AXIS != NILP)
      used = check_assign_ref(AXIS, name);
    break;

  case IDENT:
    if (strcmp(node->namep, name) == 0) 
      used = 1; /* found a match */
    break;
  }
  return used;
}


/* 1/1/2004 sws add a fun to check nodes following assign

   a .is a + ...    is ok
   a .is 2 + .rv a  is not: requires late assignment binding

*/
int
check_assign_ff(struct node * node, char *name, int seq)
{
  int ok = 1;

  /*
  fprintf( stderr, "[check_assign_ff] %s, [%d] node %s\n", funname, stmtno,
  prtoken(node->nodetype));*/

  switch (node->nodetype) {

  default:
    if (!(node->n.info & SEQUENTIAL))
      seq = 0;
    if (LEFT != NILP)
      ok &= check_assign_ff(LEFT, name, seq);
    if (RIGHT != NILP)
      ok &= check_assign_ff(RIGHT, name, seq);
    if (AXIS != NILP)
      ok &= check_assign_ff(AXIS, name, seq);
    break;

  case IDENT:
    if (!(node->n.info & SEQUENTIAL))
      seq = 0;
    if (strcmp(node->namep, name) == 0) {
      /* found a match; barf if not sequential */
      if (!seq)
	ok = 0;
    }
    break;
  }
  return ok;
}
 


/* ----------------------------------------- */
/* ----------------------------------------- */

/* passinit - initialize this pass (do nothing) */
void
passinit(int verbose)
{
  /* sws */
  if (verbose)
    fprintf(stderr, "Starting access\n");
  passname = "access";
}

/* glbvar - process a global variable name */
void
glbvar(char *name)
{
  ;
}

/* create a new symbol as a repository for node
   make sure it's unique - not in global table */
void
add_unique_sym(struct node *node, char *base )
{
  int i,k,n;
  int tp, rk;
  struct symnode *loc = 0;
  char *new;
  
  /* create a new symbol
     look it up to make sure it's unique 
     add it to symbol table */
  n = strlen(base);
  /*new = malloc( (unsigned)(n + 7));*/
  new = malloc( (size_t)(n + 7));
  node->namea = new;
  /* error check */
  if (new == 0)
    error("[access] out of space for name");
  for (i=0; i<n; i++)
    sprintf(new+i,"%c",base[i]);
  sprintf(new+i,"_av%d%c",0,'\0');
  i += 3;
  k = 1;
  while( (k<10) && (loc=lookup_name(new, csyms)) ) {
    sprintf(new+i,"%d%c",k++,'\0');
  }
  if (0==loc) {
    tp = APLC_UKTYPE;
    rk = NORANK;
    if (node->n.info & TYPEKNOWN)
      tp = node->n.type;
    if (node->n.info & RANKKNOWN)
      rk = node->n.rank;
#if SYDEBUG
    fprintf(stderr,"[access] adding {%s}\n",new); 
#endif
    add_sym( new,&csyms, NILCHAR,&csyms, LOCAL, tp,rk);
#if SYDEBUG
    fprintf(stderr,"New symbol table:\n");
    print_symtab(stderr, csyms);
#endif
  }
  return;
}

/* doprog - process function */
void
doprog(int type, struct headnode *head, struct symnode *syms,
       struct statenode *code)
{
  struct statenode *p;

  /* sws ...debugging 
     fprintf(stderr,"access before\n"); 
     prstatenode(code);
     fprintf(stderr,"access after\n"); */
  /* idlist_init();*/

  /* make symbol table global */
  csyms = syms;

  init_id_list();
  stmtno = 0;
  for (p = code; p != NILSTATE; p = p->nextstate) {
#if ADEBUG || SYDEBUG
    fprintf(stderr,"[access] %s [%d]\n", funname, 1+stmtno);
#endif
    stmtno++;
    doaccess(p->code, 1);
    /* possibly update symbol table */
    syms = csyms;
#if ADEBUG
    /* prt_id_list();*/
#endif
#if SYDEBUG
    fprintf(stderr,"[access] current symbol table:\n");
    /*print_symtab(stderr, csyms);*/
    print_symtab(stderr, syms);
#endif
    reinit_id_list();
  }
  /* sws prstatenode(code); */
  return;
}

/* 
   setaxis - set sequential mode in axis 
   and doaccess on axis if possible
   */
static void
setaxis(struct node * node)
{
  if (0 == node)
    error("setaxis; impossible condition");

  if ((node->n.info & FIRSTAXIS) || (node->n.info & LASTAXIS))
    ;	/* nothing to do */
  else {
    if (0 == node->axis) {
      fprintf(stderr,"[access] setaxis node %d %s\n", node->nodetype,
	      prtoken(node->nodetype) );
      error("setaxis; no axis");
    }
    (node->axis)->n.info |= SEQUENTIAL;
    doaccess(node->axis, 0);
  }
}

/*  addcollect - add a collect node into the tree to avoid
    repeated calls on a costly operation */
static struct node *
addcollect(struct node * node)
{
  struct node *x;

  /* fprintf(stderr,"adding a collect over %d\n", node->nodetype); */

  x = structalloc(node);
  if (x == (struct node *) 0)
    error("out of space");
  x->nodetype = COLLECT;
  x->n.info = 0;
  x->left = x->axis = x->store = NILP;
  x->namep = NULL; 
  x->namea = NULL;
  x->right = node;
  x->optype = APLC_NOT;
  x->index = 0;
  /* sws  add information if available */
  if (node->n.info & TYPEKNOWN) {
    x->n.type = node->n.type;
    x->n.info |= TYPEKNOWN;
  }
  if (node->n.info & RANKKNOWN) {
    x->n.info |= RANKKNOWN;
    x->n.rank = node->n.rank;
  }
  if (node->n.info & SHAPEKNOWN) {
    x->n.info |= SHAPEKNOWN;
    x->n.shape = node->n.shape;
  }
  return (x);
}


/* sws
   indication that this is a complex node - it must have its own loop
*/
#define CMPLEX 5

/*
 doaccess - propigate accessing information 
*/
static int
doaccess(struct node * node, int top)
{
  int lcomp, rcomp, cmplx;
  int seq;

#if ADEBUG
  fprintf(stderr,"[access] node %d %s\n", node->nodetype,
	  prtoken(node->nodetype) );
#endif
  cmplx = 0;

  switch (node->nodetype) {

  default:
    /* caserr("doaccess",node->nodetype); */
    fprintf(stderr, "[doaccess] unknown node ");
    exit(1);
    break;

  case ASSIGN:
    /* sws check for ident used above */
    if (match_idnode(LEFT->namep))
      node->n.info |= EARLYBIND;
    /* set ASSIGNP bit - watch out for possible type missmatch */
    if (!(node->n.info & TYPEKNOWN))
      /* will take type from right, so must match */
      RIGHT->n.info |= ASSIGNP;
    else {
      /* type is known, must then match right */
      if ( (RIGHT->n.info & TYPEKNOWN) && 
	   (types_match(node->n.type, RIGHT->n.type) ) ) 
	RIGHT->n.info |= ASSIGNP;
    }
    /*    fprintf(stderr,"[access] assign right is fn %d, left name %s\n",
	  RIGHT->nodetype==FIDENT, LEFT->namep );*/
    /* check if name is used on right */
    if (check_assign_ref(RIGHT, LEFT->namep) )
      node->n.info |= ASSNAMEREF;
    /* do this for any right, not all will use it */
    if (RIGHT->n.info & ASSIGNP) {
      if ( !(node->n.info & ASSNAMEREF) ) {
	RIGHT->namea = LEFT->namep;/* use our name */
	RIGHT->n.info |= ASSNAMEOK;
	/* else remove this bit, so right will create a new name */
	/*RIGHT->n.info ^= ASSIGNP;*/
      } 
    }
    seq = 0;
    if (top)
      node->n.info |= SEQUENTIAL;
    if (node->n.info & SEQUENTIAL) {
      seq = 1;
      RIGHT->n.info |= SEQUENTIAL;
    }
    rcomp = doaccess(RIGHT, 0);
    if (!(node->n.info & SEQUENTIAL))
      node->n.info |= HAVEVALUE;
    cmplx = 0;
    /* now check for direct name assignment */
    if (check_assign_ff(RIGHT, LEFT->namep, seq) )
      node->n.info |= ASSNAMEOK;
    break;

  case AVEC:
  case TCAV:
  case TYPECON:
    cmplx = 0;
    break;

  case BCON:
  case ICON:
  case RCON:
  case SCON:
    if (is_scalar(node) && is_icon(node))
      ;
    else
      node->n.info |= HAVEVALUE;
    if (is_scalar(node))
      node->n.info |= NOINDEX;
    if (node->n.info & SEQUENTIAL)
      node->n.info |= NOINDEX;
    cmplx = 0;
    break;

  case ZCON:
  case QCON:
  case OCON:
    node->n.info |= HAVEVALUE;
    cmplx = 0;
    break;

  case LCON:
    node->n.info |= HAVEVALUE;
    node->n.info |= NOINDEX;
    cmplx = 0;
    break;

  case IDENT:
    node->n.info |= HAVEVALUE;
    node->n.info |= HAVETRS;
    if (is_scalar(node))
      node->n.info |= NOINDEX;
    /* sws  exclude APLC_ANY/ANYRANK case from NOINDEX 
       - also complex types
     */
    if ((node->n.info & TYPEKNOWN) &&
	(node->n.type != APLC_ANY) &&
	(node->n.type != APLC_COMPLEX) &&
	(node->n.type != APLC_QUAT) &&
	(node->n.type != APLC_OCT) &&
	(node->n.info & RANKKNOWN) &&
	(node->n.rank != ANYRANK) &&
	(node->n.info & SEQUENTIAL))
      node->n.info |= NOINDEX;
    cmplx = 0;
    /* add name to list */
    add_idnode(node);
    break;

  case QUAD:
  case QQUAD:
    if (RIGHT != NILP) {
      RIGHT->n.info |= SEQUENTIAL;
      rcomp = doaccess(RIGHT, 0);
    }
    node->n.info |= HAVEVALUE;
    node->n.info |= HAVETRS;
    cmplx = 0;
    break;

  case DQUAD:
  case DQQUAD:
    fprintf(stderr, "[doaccess] dquad, dqquad not implemented");
    exit(1);

  case QQUADASSIGN:
    if (!(RIGHT->n.info & HAVEVALUE)) {
      node->right = addcollect(RIGHT);
    }
    break;

  case QUADASSIGN:
    if (top) {
      RIGHT->n.info |= SEQUENTIAL;
    } 
    cmplx = doaccess(RIGHT, 0);
    if (!top){
      /* want to pass on the right to the left;
	 make sure we don't do calculations twice */
      if (!(RIGHT->n.info & HAVEVALUE)) {
	node->right = addcollect(RIGHT);
      }
      node->n.info = RIGHT->n.info;
    }
    break;

  case DQUADASSIGN:
  case DQQUADASSIGN:
    RIGHT->n.info |= SEQUENTIAL;
    if (LEFT != NILP) {		     /* file name */
      LEFT->n.info |= SEQUENTIAL;
      lcomp = doaccess(LEFT, 0);
    }
    rcomp = doaccess(RIGHT, 0);
    node->n.info |= HAVEVALUE;	     /* sws */
    if (RIGHT->n.info & NOINDEX)
      node->n.info |= NOINDEX;
    cmplx = 0;
    break;

  case BOX:
  case UNBOX:
    rcomp = doaccess(RIGHT, 0);
    node->n.info |= HAVEVALUE;
    node->n.info |= HAVETRS;
    cmplx = 0;
    break;

  case CAT:
  /* sws
   not always a good idea, given possible replication
  */
/*
	if (node->n.info & SEQUENTIAL) {
	    LEFT->n.info  |= SEQUENTIAL;
	    RIGHT->n.info |= SEQUENTIAL;
	}
*/
    /* if (axisgiven(AXIS)) { if ((! icons(AXIS)) && AXIS->nodetype != RCON)
       { AXIS->n.info |= SEQUENTIAL; ...doaccess(AXIS, 0); } } */
    lcomp = doaccess(LEFT, 0);
    setaxis(node);
    rcomp = doaccess(RIGHT, 0);
    cmplx = lcomp + rcomp;
    break;

  case LINK:
    lcomp = doaccess(LEFT, 0);
    /*setaxis(node);*/
    rcomp = doaccess(RIGHT, 0);
    node->n.info |= HAVEVALUE;
    cmplx = lcomp + rcomp;
    break;

  case CATCH:
    /* treat both left and right as top */
    lcomp = doaccess(LEFT, 1);
    rcomp = doaccess(RIGHT, 1);
    cmplx = 0;
    break;

  case CISCALAR:
  case CIVEC:
  case COLLECT:
  case CSCALAR:
  case CVEC:
  case CCOLLECT:
    /*- sws
      if RIGHT is an assignment, don't set it to sequential
      so it will set HAVEVALUE  and collect
    */
    if (!(RIGHT->nodetype == ASSIGN))
      RIGHT->n.info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    node->n.info |= HAVEVALUE; /* sws */
    cmplx = 0;
#if 0
    /* old way */
    if (node->nodetype == CCOLLECT) {
      /* sws  special collect that always copies */
      RIGHT->n.info &= ~HAVEVALUE;
      /* this nodetype is not used after this stage */
      node->nodetype = COLLECT;
    }
#endif
    break;


  case COMMENT:
    cmplx = 0;
    break;

  case COMPRESS:
    LEFT->n.info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);
    setaxis(node);
    rcomp = doaccess(RIGHT, 0);
    cmplx = rcomp;
    break;

  case DEAL:
    LEFT->n.info |= SEQUENTIAL;
    RIGHT->n.info |= SEQUENTIAL;
    node->n.info |= HAVEVALUE;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case DECODE:
  case INNERCHILD:
    lcomp = doaccess(LEFT, 0);
    if (lcomp > 0) {
      node->left = addcollect(LEFT);
      lcomp = doaccess(LEFT, 0);
    }
    rcomp = doaccess(RIGHT, 0);
    if (rcomp > 0) {
      node->right = addcollect(RIGHT);
      rcomp = doaccess(RIGHT, 0);
    }
    cmplx = CMPLEX;
    break;

  case DFORMAT:
    LEFT->n.info |= SEQUENTIAL;
    RIGHT->n.info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    node->n.info |= HAVEVALUE;
    node->n.info |= HAVETRS;
    cmplx = 0;
    break;

    /* sws  based on inner */
  case DOMINO:
    rcomp = doaccess(RIGHT, 0);
    if (is_scalar(node))
      node->n.info |= NOINDEX;
    node->n.info |= HAVEVALUE;
    node->n.info |= HAVETRS;
    cmplx = 0;
    break;

  case DSFUN:
    if (node->n.info & SEQUENTIAL) {
      RIGHT->n.info |= SEQUENTIAL;
      LEFT->n.info |= SEQUENTIAL;
    }
    lcomp = doaccess(LEFT, 0);
    if (lcomp > 0) {
      node->left = addcollect(LEFT);
      lcomp = doaccess(LEFT, 0);
    }
    rcomp = doaccess(RIGHT, 0);
    if (rcomp > 0) {
      node->right = addcollect(RIGHT);
      rcomp = doaccess(RIGHT, 0);
    }
    /*
	if ((RIGHT->n.info & NOINDEX) && (LEFT->n.info & NOINDEX))
	    node->n.info |= NOINDEX;
	    */
    cmplx = lcomp + rcomp;
    break;

  case DSYSFUN:
  case ESYSFUN:
  case MSYSFUN:
    if (LEFT != NILP)
      lcomp = doaccess(LEFT, 0);
    if (RIGHT != NILP)
      rcomp = doaccess(RIGHT, 0);
#if 0
    if (node->nodetype == MSYSFUN)
      rcomp = doaccess(RIGHT, 0);
    else {
      lcomp = doaccess(LEFT, 0);
      rcomp = doaccess(RIGHT, 0);
    }
#endif
    node->n.info |= HAVEVALUE;
    cmplx = 0;
    break;

  case DTRANS:
    if (is_mergeable(RIGHT))
      RIGHT->n.info |= MERGED;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    if (RIGHT->n.info & NOINDEX)
      node->n.info |= NOINDEX;
    cmplx = rcomp;
    break;

  case EMPTSEMI:
    cmplx = 0;
    break;

  case ENCODE:
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    /* sws */
    /* cmplx = lcomp + rcomp; */
    /* since stuff is calculated in the shape phase */
    node->n.info |= HAVEVALUE;
    cmplx = 0;
    break;

  case EXPAND:
    if (node->n.info & SEQUENTIAL)
      RIGHT->n.info |= SEQUENTIAL;
    LEFT->n.info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);
    setaxis(node);
    rcomp = doaccess(RIGHT, 0);
    cmplx = rcomp;
    break;

  case EPSILON:
    if (node->n.info & SEQUENTIAL)
      LEFT->n.info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    cmplx = lcomp;
    break;

  case EXECUTE:
    rcomp = doaccess(RIGHT, 0);
    cmplx = rcomp;
    break;

  case FIDENT:
    node->n.info |= HAVEVALUE;
    node->n.info |= HAVETRS;
    if (! (node->n.info & ASSNAMEOK) )
      add_unique_sym(node, node->namep);
    if (LEFT != NILP)
      lcomp = doaccess(LEFT, 0);
    if (RIGHT != NILP)
      rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case OPIDENT:
    node->n.info |= HAVEVALUE;
    node->n.info |= HAVETRS;
    if (! (node->n.info & ASSNAMEOK) )
      add_unique_sym(node, node->namep);
    if (LEFT != NILP)
      lcomp = doaccess(LEFT, 0);
    if (RIGHT != NILP)
      rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case FORMAT:
    RIGHT->n.info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    node->n.info |= HAVEVALUE;
    node->n.info |= HAVETRS;
    cmplx = 0;
    break;

  case GO:
    RIGHT->n.info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case INDEX:
    if (node->n.info & SEQUENTIAL)
      RIGHT->n.info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    cmplx = rcomp;
    break;

  case INNER:
    rcomp = doaccess(RIGHT, 0);
    if (is_scalar(node))
      node->n.info |= NOINDEX;
    cmplx = rcomp;
    break;

  case IOTA:
    rcomp = doaccess(RIGHT, 0);
    if (node->n.info & SEQUENTIAL)
      node->n.info |= NOINDEX;
    cmplx = 0;
    break;

  case LAM:
    /* laminate is part of cat, shouldn't get here */
    error("laminate not implemented can't get here");
    cmplx = 0;
    break;

  case MSOLVE:
    rcomp = doaccess(RIGHT, 0);
    lcomp = doaccess(LEFT, 0);
    if (is_scalar(node))
      node->n.info |= NOINDEX;
    node->n.info |= HAVEVALUE;
    node->n.info |= HAVETRS;
    cmplx = 0;
    break;

  case MSFUN:
    if (node->n.info & SEQUENTIAL)
      RIGHT->n.info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    if (RIGHT->n.info & NOINDEX)
      node->n.info |= NOINDEX;
    cmplx = rcomp;
    break;

  case OUTER:
    if (node->n.info & SEQUENTIAL)
      LEFT->n.info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    if (rcomp > 0) {
      node->right = addcollect(RIGHT);
      rcomp = doaccess(RIGHT, 0);
    }
    lcomp = doaccess(LEFT, 0);
    if (!(node->n.info & SEQUENTIAL))
      if (lcomp > 0) {
	node->left = addcollect(LEFT);
	lcomp = doaccess(LEFT, 0);
      }
    cmplx = rcomp + lcomp;
    break;

  case RAVEL:
    if (node->n.info & SEQUENTIAL)
      RIGHT->n.info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    if (RIGHT->n.info & HAVEVALUE)
      node->n.info |= HAVEVALUE;
    if (RIGHT->n.info & NOINDEX)
      node->n.info |= NOINDEX;
    cmplx = rcomp;
    break;

  case REDUCE:
    setaxis(node);
    if ((node->n.info & SEQUENTIAL) &&
	(node->n.info & LASTAXIS) &&
	(is_commute(node)) && is_assoc(node) )
      RIGHT->n.info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    if (is_vector(RIGHT) && is_commute(node) && is_assoc(node) )
      node->n.info |= NOINDEX;
    /* sws still need a loop... */
    /*	if (RIGHT->n.info & SEQUENTIAL)
	    cmplx = 0; */
    else {
      if (rcomp > 0) {
	node->right = addcollect(RIGHT);
	rcomp = doaccess(RIGHT, 0);
      }
      /* sws cmplx = CMPLEX; */
    }
    cmplx = CMPLEX;
    break;

  case REVERSE:
    setaxis(node);
    if (is_mergeable(RIGHT))
      RIGHT->n.info |= MERGED;
    rcomp = doaccess(RIGHT, 0);
    if (RIGHT->n.info & NOINDEX)
      node->n.info |= NOINDEX;
    cmplx = rcomp;
    break;

  case RESHAPEX:
  case RESHAPE:
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    cmplx = rcomp;
    break;

  case RHO:
    node->n.info |= HAVEVALUE;
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case RHORHO:
    /* node->n.info |= HAVEVALUE;*/
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case ROLL:
    if (node->n.info & SEQUENTIAL)
      RIGHT->n.info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case ROTATE:
    lcomp = doaccess(LEFT, 0);
    setaxis(node);
    rcomp = doaccess(RIGHT, 0);
    cmplx = lcomp + rcomp;
    break;

  case SCAN:
    setaxis(node);
    if ((node->n.info & SEQUENTIAL) &&
	(node->n.info & LASTAXIS) &&
	is_commute(node) && is_assoc(node) )
      RIGHT->n.info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);

    if (RIGHT->n.info & SEQUENTIAL) {
      /* sws cmplx = 0; */
      if (RIGHT->n.info & NOINDEX)
	node->n.info |= NOINDEX;
    } else {
      if (rcomp > 0) {
	node->right = addcollect(RIGHT);
	rcomp = doaccess(RIGHT, 0);
      }
      /* cmplx = CMPLEX; */
    }
    cmplx = CMPLEX;
    break;

  case SM:
    if ((node->n.info & SEQUENTIAL) && (LEFT == NILP))
      RIGHT->n.info |= SEQUENTIAL;
    if (LEFT != NILP)
      lcomp = doaccess(LEFT, 0);
    else
      lcomp = 0;
    /* tell axis it's top to force it to collect? */
    if (AXIS != NILP)
      lcomp = doaccess(AXIS, 1);
    rcomp = doaccess(RIGHT, 0);
    if (LEFT == NILP) {
      if (RIGHT->n.info & NOINDEX)
	node->n.info |= NOINDEX;
    } else if ((LEFT->n.info & NOINDEX) && (RIGHT->n.info & NOINDEX))
      node->n.info |= NOINDEX;
    cmplx = lcomp + rcomp;
    break;

  case SORT:
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case SUB:
    if (node->n.info & SEQUENTIAL)
      RIGHT->n.info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 1);
    cmplx = lcomp + rcomp;
    break;

  case SUBASSIGN:
#if 0
    /* subassign can also use the right */ 
    if ( ! ( (LEFT->n.info & TYPEKNOWN) && (RIGHT->n.info & TYPEKNOWN) 
	 && (LEFT->n.type == RIGHT->n.type) ) ) {
      if (RIGHT->nodetype == FIDENT) 
	RIGHT->n.info |= ASSIGNP; 
    }
#endif
    RIGHT->n.info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);/* just an ident */
    /* sws why top ??? */
    /* tell axis it's top to force it to collect? */
    lcomp = doaccess(AXIS, 1);
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case ASYSVAR:
  case SYSVAR:
    if (LEFT != NILP)
      doaccess(LEFT, 0);
    if (RIGHT != NILP)
      doaccess(RIGHT, 0);
    node->n.info |= HAVEVALUE;
    cmplx = 0;
    break;

    /* non mergeable (standard) versions of take/drop */ 
  case TAKE:
  case DROP:
    node->n.info |= HAVEVALUE;
    node->n.info |= HAVETRS;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    cmplx = rcomp;
    break;

    /* mergeable versions of take/drop */ 
  case GWTAKE:
  case GWDROP:
    if (is_mergeable(RIGHT))
      RIGHT->n.info |= MERGED;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    if (RIGHT->n.info & NOINDEX)
      node->n.info |= NOINDEX;
    cmplx = rcomp;
    break;

  case TRANS:
    if (is_mergeable(RIGHT))
      RIGHT->n.info |= MERGED;
    rcomp = doaccess(RIGHT, 0);
    if (RIGHT->n.info & NOINDEX)
      node->n.info |= NOINDEX;
    cmplx = rcomp;
    break;
  }
  return (cmplx);
}

/* end of access.c */


