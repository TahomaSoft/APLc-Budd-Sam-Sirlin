/* A Bison parser, made from apl.y, by GNU bison 1.75.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON	1

/* Pure parsers.  */
#define YYPURE	0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     CLASS = 258,
     TYPE = 259,
     RANK = 260,
     DEL = 261,
     GO = 262,
     COMMENT = 263,
     COLLECT = 264,
     CVEC = 265,
     CIVEC = 266,
     CSCALAR = 267,
     CISCALAR = 268,
     CCOLLECT = 269,
     ASSIGN = 270,
     QUADASSIGN = 271,
     SUBASSIGN = 272,
     QUAD = 273,
     QQUAD = 274,
     QQUADASSIGN = 275,
     DQUAD = 276,
     DQQUAD = 277,
     DQUADASSIGN = 278,
     DQQUADASSIGN = 279,
     QUADLZ = 280,
     IDENT = 281,
     FIDENT = 282,
     OPIDENT = 283,
     UIDENT = 284,
     LCON = 285,
     SCON = 286,
     BCON = 287,
     ICON = 288,
     RCON = 289,
     ZCON = 290,
     QCON = 291,
     OCON = 292,
     NL = 293,
     LP = 294,
     RP = 295,
     LB = 296,
     RB = 297,
     LCB = 298,
     RCB = 299,
     CM = 300,
     SM = 301,
     COLON = 302,
     DOT = 303,
     MSFUN = 304,
     DSFUN = 305,
     OUTER = 306,
     INNER = 307,
     INNERCHILD = 308,
     DECODE = 309,
     SLASH = 310,
     BSLASH = 311,
     REDUCE = 312,
     EXPAND = 313,
     COMPRESS = 314,
     SCAN = 315,
     SORT = 316,
     GRADEUP = 317,
     GRADEDOWN = 318,
     EPSILON = 319,
     INDEX = 320,
     TRANS = 321,
     DTRANS = 322,
     REVERSE = 323,
     ROTATE = 324,
     TAKE = 325,
     DROP = 326,
     GWTAKE = 327,
     GWDROP = 328,
     RHO = 329,
     RHORHO = 330,
     RESHAPE = 331,
     SUB = 332,
     EMPTSEMI = 333,
     IOTA = 334,
     RAVEL = 335,
     CAT = 336,
     LAM = 337,
     ROLL = 338,
     DEAL = 339,
     ENCODE = 340,
     FORMAT = 341,
     DFORMAT = 342,
     EXECUTE = 343,
     LCARET = 344,
     RCARET = 345,
     BOX = 346,
     UNBOX = 347,
     LINK = 348,
     RESHAPEX = 349,
     MSOLVE = 350,
     DOMINO = 351,
     AVEC = 352,
     TCAV = 353,
     TYPECON = 354,
     ASYSVAR = 355,
     SYSVAR = 356,
     DSYSFUN = 357,
     ESYSFUN = 358,
     MSYSFUN = 359,
     ALPHA = 360,
     OMEGA = 361,
     CATCH = 362,
     EACH = 363,
     CGOTO = 364
   };
#endif
#define CLASS 258
#define TYPE 259
#define RANK 260
#define DEL 261
#define GO 262
#define COMMENT 263
#define COLLECT 264
#define CVEC 265
#define CIVEC 266
#define CSCALAR 267
#define CISCALAR 268
#define CCOLLECT 269
#define ASSIGN 270
#define QUADASSIGN 271
#define SUBASSIGN 272
#define QUAD 273
#define QQUAD 274
#define QQUADASSIGN 275
#define DQUAD 276
#define DQQUAD 277
#define DQUADASSIGN 278
#define DQQUADASSIGN 279
#define QUADLZ 280
#define IDENT 281
#define FIDENT 282
#define OPIDENT 283
#define UIDENT 284
#define LCON 285
#define SCON 286
#define BCON 287
#define ICON 288
#define RCON 289
#define ZCON 290
#define QCON 291
#define OCON 292
#define NL 293
#define LP 294
#define RP 295
#define LB 296
#define RB 297
#define LCB 298
#define RCB 299
#define CM 300
#define SM 301
#define COLON 302
#define DOT 303
#define MSFUN 304
#define DSFUN 305
#define OUTER 306
#define INNER 307
#define INNERCHILD 308
#define DECODE 309
#define SLASH 310
#define BSLASH 311
#define REDUCE 312
#define EXPAND 313
#define COMPRESS 314
#define SCAN 315
#define SORT 316
#define GRADEUP 317
#define GRADEDOWN 318
#define EPSILON 319
#define INDEX 320
#define TRANS 321
#define DTRANS 322
#define REVERSE 323
#define ROTATE 324
#define TAKE 325
#define DROP 326
#define GWTAKE 327
#define GWDROP 328
#define RHO 329
#define RHORHO 330
#define RESHAPE 331
#define SUB 332
#define EMPTSEMI 333
#define IOTA 334
#define RAVEL 335
#define CAT 336
#define LAM 337
#define ROLL 338
#define DEAL 339
#define ENCODE 340
#define FORMAT 341
#define DFORMAT 342
#define EXECUTE 343
#define LCARET 344
#define RCARET 345
#define BOX 346
#define UNBOX 347
#define LINK 348
#define RESHAPEX 349
#define MSOLVE 350
#define DOMINO 351
#define AVEC 352
#define TCAV 353
#define TYPECON 354
#define ASYSVAR 355
#define SYSVAR 356
#define DSYSFUN 357
#define ESYSFUN 358
#define MSYSFUN 359
#define ALPHA 360
#define OMEGA 361
#define CATCH 362
#define EACH 363
#define CGOTO 364




/* Copy the first part of user declarations.  */

  /* c code */
  /* since (on Sun) yacc produces old code */
#define TRADITIONAL

#include "ptree.h"

/* ansi c declararions */
/* sws  function declartions */
int main(int argc, char **argv);
void yyret_debug(void);
void yylistf(void);
void yylist_debug(char *s);
void yylist_print(char *s);
void yylistfn(void);
void yycopy2nl(void);

void yyerror(char *c);
void mnbody(struct statenode *code);
void prog( struct headnode *head, struct statenode *code);
void opprog( struct headnode *head, struct statenode *code);
void resolvelabels_main(struct statenode *code);
void check_label(struct statenode *code, int i, char *name);
void fixlabel( struct node *node, int i, char *name, 
	       int ntype, struct symnode *var);

void resolvelabels(struct statenode *code, struct label_struct lar[]);
void expect(char *str);
int yywrap(void);


#define NIL 0

#define SETATTRIBUTES {dclclass = lexscope; dcltype = APLC_UKTYPE; dclrank = NORANK;}

#if defined(SUNOS) || defined(DJPC) || defined(ST) || defined(LINUX) || defined(CYGWIN) 
/* somehow this breaks the alpha and conflicts for freebsd */
extern char yytext[];/* from lex */
#endif
#ifdef DECALPHA
#endif
#ifdef FREEBSD
extern char yytext[];/* use %array to force flex to make an array */
#endif

/*#ifdef HAVE_FLEX*/
#if 1
int yylex();
#endif

int dolist; /* flag to print listing */
int linenum; /* line number of line being parsed */
int mainlnum; /* line number in main function */
int funlnum;  /* line number in user function */
int funmode; /* 0,1,2, for null, main, user fun */
int linemode; /* 0, 1, 2 for (blank, comment), unnumbered, or real line */
int line_off = 0; /* line offset for listing */
static enum classes lexscope;   /* current lexical scope */
static struct statenode *gstmts; /* global statements */
static int errflag;             /* error indicatation flag */

static enum classes dclclass;   /* attributes given in declaration header */
static int dcltype;
static int dclrank;

 /* symbol table structures */
/*extern struct symnode *gsymtab, *symtab;*/
 /* label list */
extern struct label_struct lconsts[];
 /* lable index */
extern int lctop;

/* list file name */
static FILE *listfile;



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#ifndef YYSTYPE
#line 203 "apl.y"
typedef union {
	char *c;
	double d;
	double z[2];
	double q[4];
	double oct[8];
	struct headnode *h;
	struct headnode *oh;
	int  i;
	enum classes l;
	struct node *n;
	enum sfuns o;
	struct symnode *s;
	struct statenode *t;
	enum sysvars v;
	} yystype;
/* Line 193 of /usr/local/share/bison/yacc.c.  */
#line 384 "y.tab.c"
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif

#ifndef YYLTYPE
typedef struct yyltype
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} yyltype;
# define YYLTYPE yyltype
# define YYLTYPE_IS_TRIVIAL 1
#endif

/* Copy the second part of user declarations.  */


/* Line 213 of /usr/local/share/bison/yacc.c.  */
#line 405 "y.tab.c"

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYLTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAX (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAX)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];	\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAX;	\
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  4
#define YYLAST   2200

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  111
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  58
/* YYNRULES -- Number of rules. */
#define YYNRULES  239
/* YYNRULES -- Number of states. */
#define YYNSTATES  380

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   364

#define YYTRANSLATE(X) \
  ((unsigned)(X) <= YYMAXUTOK ? yytranslate[X] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     110,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short yyprhs[] =
{
       0,     0,     3,     5,     7,    10,    11,    13,    15,    17,
      19,    24,    29,    35,    41,    45,    49,    52,    55,    59,
      63,    66,    69,    72,    76,    79,    83,    87,    89,    93,
      95,    97,    99,   101,   103,   105,   109,   113,   116,   119,
     121,   123,   130,   137,   143,   149,   157,   165,   172,   179,
     181,   182,   185,   189,   191,   194,   196,   198,   200,   202,
     204,   206,   210,   214,   216,   219,   222,   226,   228,   232,
     237,   239,   242,   246,   249,   251,   254,   257,   260,   263,
     266,   270,   273,   276,   279,   282,   285,   288,   291,   295,
     299,   303,   308,   313,   317,   323,   329,   333,   337,   341,
     346,   351,   356,   361,   366,   370,   374,   378,   382,   386,
     390,   394,   398,   403,   407,   411,   416,   420,   424,   428,
     432,   436,   440,   443,   446,   452,   457,   462,   466,   470,
     473,   475,   477,   479,   480,   484,   486,   488,   490,   492,
     494,   496,   498,   500,   502,   507,   509,   511,   513,   515,
     520,   522,   525,   527,   530,   534,   536,   538,   540,   542,
     544,   546,   548,   550,   552,   554,   557,   561,   562,   568,
     571,   574,   577,   581,   582,   588,   591,   594,   597,   601,
     602,   608,   611,   614,   616,   618,   620,   622,   624,   626,
     628,   630,   633,   635,   638,   641,   644,   646,   649,   652,
     655,   658,   661,   663,   666,   669,   672,   675,   678,   681,
     684,   686,   689,   692,   695,   698,   701,   704,   707,   710,
     713,   715,   718,   721,   724,   727,   730,   733,   736,   739,
     742,   745,   748,   750,   753,   755,   757,   759,   763,   764
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short yyrhs[] =
{
     112,     0,    -1,   113,    -1,   114,    -1,   113,   115,    -1,
      -1,   139,    -1,   132,    -1,   116,    -1,   117,    -1,   126,
      47,   140,    38,    -1,   125,    47,   140,    38,    -1,   118,
     130,   136,     6,    38,    -1,   119,   130,   136,     6,    38,
      -1,   120,    46,   124,    -1,   118,    46,   124,    -1,   120,
      38,    -1,   118,    38,    -1,   121,    46,   124,    -1,   119,
      46,   124,    -1,   121,    38,    -1,   119,    38,    -1,     6,
     122,    -1,     6,    38,   122,    -1,     6,   123,    -1,     6,
      38,   123,    -1,   124,    15,   128,    -1,   128,    -1,   124,
      15,   129,    -1,   129,    -1,    26,    -1,   125,    -1,    29,
      -1,    27,    -1,    28,    -1,   124,   124,   124,    -1,   124,
     126,   124,    -1,   124,   124,    -1,   126,   124,    -1,   124,
      -1,   126,    -1,   124,    39,   124,   124,    40,   124,    -1,
     124,    39,   124,   127,    40,   124,    -1,    39,   124,   124,
      40,   124,    -1,    39,   124,   127,    40,   124,    -1,   124,
      39,   124,   124,   124,    40,   124,    -1,   124,    39,   124,
     127,   124,    40,   124,    -1,    39,   124,   124,   124,    40,
     124,    -1,    39,   124,   127,   124,    40,   124,    -1,   131,
      -1,    -1,   131,   132,    -1,   133,   135,    38,    -1,   134,
      -1,   133,   134,    -1,     3,    -1,     4,    -1,     5,    -1,
     124,    -1,   126,    -1,   127,    -1,   135,    45,   124,    -1,
     135,    45,   126,    -1,   137,    -1,   136,   137,    -1,     1,
     110,    -1,   166,    47,   138,    -1,   138,    -1,     7,   140,
      38,    -1,     7,   140,     8,    38,    -1,   139,    -1,   140,
      38,    -1,   140,     8,    38,    -1,     8,    38,    -1,    38,
      -1,    49,   140,    -1,    45,   140,    -1,    96,   140,    -1,
      86,   140,    -1,    79,   140,    -1,    68,   141,   140,    -1,
      74,   140,    -1,    83,   140,    -1,    61,   140,    -1,    66,
     140,    -1,    88,   140,    -1,    89,   140,    -1,    90,   140,
      -1,    18,    15,   140,    -1,    25,    15,   140,    -1,    19,
      15,   140,    -1,   142,    56,   141,   140,    -1,   142,    55,
     141,   140,    -1,   147,   142,   140,    -1,   147,   142,    48,
     142,   140,    -1,   147,    51,    48,   142,   140,    -1,   143,
      15,   140,    -1,   145,    15,   140,    -1,   100,    15,   140,
      -1,   147,    18,    15,   140,    -1,   147,    19,    15,   140,
      -1,   147,    56,   141,   140,    -1,   147,    45,   141,   140,
      -1,   147,    93,   141,   140,    -1,   147,    54,   140,    -1,
     147,    96,   140,    -1,   147,    71,   140,    -1,   147,    73,
     140,    -1,   147,    85,   140,    -1,   147,    64,   140,    -1,
     147,    86,   140,    -1,   147,    79,   140,    -1,   147,    68,
     141,   140,    -1,   147,    74,   140,    -1,   147,    83,   140,
      -1,   147,    55,   141,   140,    -1,   147,    70,   140,    -1,
     147,    72,   140,    -1,   147,    66,   140,    -1,   147,   102,
     140,    -1,   147,   103,   140,    -1,   147,   107,   140,    -1,
     104,   140,    -1,   103,   140,    -1,   147,    27,    28,    27,
     140,    -1,    27,    28,    27,   140,    -1,   147,    27,    28,
     140,    -1,    27,    28,   140,    -1,   147,    27,   140,    -1,
      27,   140,    -1,    27,    -1,   147,    -1,     1,    -1,    -1,
      41,   140,    42,    -1,    49,    -1,    50,    -1,    89,    -1,
      90,    -1,   144,    -1,   125,    -1,    26,    -1,   105,    -1,
     106,    -1,   146,    41,   167,    42,    -1,   144,    -1,   144,
      -1,   148,    -1,   145,    -1,   148,    41,   167,    42,    -1,
      18,    -1,   147,    18,    -1,    19,    -1,   147,    19,    -1,
      39,   140,    40,    -1,   100,    -1,   101,    -1,    97,    -1,
      98,    -1,    99,    -1,    31,    -1,   149,    -1,   158,    -1,
     152,    -1,   155,    -1,   150,    40,    -1,    39,    31,    38,
      -1,    -1,    39,    38,   151,    31,    38,    -1,   150,    38,
      -1,   150,    31,    -1,   153,    40,    -1,    39,   158,    38,
      -1,    -1,    39,    38,   154,   158,    38,    -1,   153,    38,
      -1,   153,   158,    -1,   156,    40,    -1,    39,   140,    38,
      -1,    -1,    39,    38,   157,   140,    38,    -1,   156,    38,
      -1,   156,   140,    -1,   159,    -1,   160,    -1,   161,    -1,
     162,    -1,   163,    -1,   164,    -1,   165,    -1,    32,    -1,
     159,    32,    -1,    33,    -1,   159,    33,    -1,   160,    33,
      -1,   160,    32,    -1,    34,    -1,   159,    34,    -1,   160,
      34,    -1,   161,    34,    -1,   161,    33,    -1,   161,    32,
      -1,    35,    -1,   159,    35,    -1,   160,    35,    -1,   161,
      35,    -1,   162,    35,    -1,   162,    34,    -1,   162,    33,
      -1,   162,    32,    -1,    36,    -1,   159,    36,    -1,   160,
      36,    -1,   161,    36,    -1,   162,    36,    -1,   163,    36,
      -1,   163,    35,    -1,   163,    34,    -1,   163,    33,    -1,
     163,    32,    -1,    37,    -1,   159,    37,    -1,   160,    37,
      -1,   161,    37,    -1,   162,    37,    -1,   163,    37,    -1,
     164,    37,    -1,   164,    36,    -1,   164,    35,    -1,   164,
      34,    -1,   164,    33,    -1,   164,    32,    -1,   166,    -1,
     165,   166,    -1,    30,    -1,   125,    -1,   168,    -1,   167,
      46,   168,    -1,    -1,   140,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short yyrline[] =
{
       0,   244,   244,   248,   249,   253,   268,   271,   272,   273,
     274,   276,   280,   288,   296,   297,   298,   300,   304,   305,
     306,   308,   312,   313,   316,   317,   320,   323,   326,   329,
     332,   333,   336,   339,   342,   345,   346,   347,   348,   349,
     350,   353,   354,   355,   356,   357,   358,   359,   360,   365,
     370,   371,   374,   377,   378,   381,   382,   383,   386,   387,
     388,   389,   390,   393,   394,   398,   399,   401,   405,   406,
     407,   411,   412,   413,   415,   420,   421,   422,   423,   424,
     425,   426,   427,   428,   429,   430,   431,   432,   433,   434,
     435,   436,   437,   438,   439,   442,   443,   444,   445,   446,
     448,   450,   452,   453,   455,   458,   460,   462,   463,   464,
     467,   470,   473,   475,   476,   478,   480,   482,   483,   485,
     487,   490,   491,   492,   493,   494,   495,   496,   497,   498,
     499,   500,   501,   504,   505,   508,   509,   510,   511,   514,
     515,   518,   519,   520,   523,   526,   529,   530,   531,   534,
     535,   536,   537,   538,   539,   540,   541,   542,   543,   544,
     545,   546,   547,   548,   549,   552,   555,   556,   556,   558,
     559,   563,   566,   567,   567,   569,   570,   573,   576,   577,
     577,   579,   580,   584,   585,   586,   587,   588,   589,   590,
     593,   594,   597,   598,   599,   600,   603,   604,   605,   606,
     607,   608,   611,   612,   613,   614,   615,   616,   617,   618,
     621,   622,   623,   624,   625,   626,   627,   628,   629,   630,
     633,   634,   635,   636,   637,   638,   639,   640,   641,   642,
     643,   644,   647,   648,   651,   652,   655,   656,   659,   660
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "CLASS", "TYPE", "RANK", "DEL", "GO", 
  "COMMENT", "COLLECT", "CVEC", "CIVEC", "CSCALAR", "CISCALAR", 
  "CCOLLECT", "ASSIGN", "QUADASSIGN", "SUBASSIGN", "QUAD", "QQUAD", 
  "QQUADASSIGN", "DQUAD", "DQQUAD", "DQUADASSIGN", "DQQUADASSIGN", 
  "QUADLZ", "IDENT", "FIDENT", "OPIDENT", "UIDENT", "LCON", "SCON", 
  "BCON", "ICON", "RCON", "ZCON", "QCON", "OCON", "NL", "LP", "RP", "LB", 
  "RB", "LCB", "RCB", "CM", "SM", "COLON", "DOT", "MSFUN", "DSFUN", 
  "OUTER", "INNER", "INNERCHILD", "DECODE", "SLASH", "BSLASH", "REDUCE", 
  "EXPAND", "COMPRESS", "SCAN", "SORT", "GRADEUP", "GRADEDOWN", "EPSILON", 
  "INDEX", "TRANS", "DTRANS", "REVERSE", "ROTATE", "TAKE", "DROP", 
  "GWTAKE", "GWDROP", "RHO", "RHORHO", "RESHAPE", "SUB", "EMPTSEMI", 
  "IOTA", "RAVEL", "CAT", "LAM", "ROLL", "DEAL", "ENCODE", "FORMAT", 
  "DFORMAT", "EXECUTE", "LCARET", "RCARET", "BOX", "UNBOX", "LINK", 
  "RESHAPEX", "MSOLVE", "DOMINO", "AVEC", "TCAV", "TYPECON", "ASYSVAR", 
  "SYSVAR", "DSYSFUN", "ESYSFUN", "MSYSFUN", "ALPHA", "OMEGA", "CATCH", 
  "EACH", "CGOTO", "'\\n'", "$accept", "file", "globals", "initialize", 
  "object", "function", "operator", "heading", "opheading", "headpar", 
  "opheadpar", "params", "opparams", "ident", "uident", "fident", 
  "opident", "parampart", "opparampart", "dcls", "dcllist", "dclstmt", 
  "attributes", "anattribute", "namelist", "statelist", "lstatement", 
  "ulstatement", "simplestatement", "expression", "axis", "sfun", "aterm", 
  "progid", "sub", "subid", "term", "sterm", "starray", "starrayst", "@1", 
  "narray", "narrayst", "@2", "exparray", "exparrayst", "@3", "nvec", 
  "bvec", "ivec", "rvec", "zvec", "qvec", "ovec", "lvec", "lterm", 
  "sublist", "subele", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
      10
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,   111,   112,   113,   113,   114,   115,   115,   115,   115,
     115,   115,   116,   117,   118,   118,   118,   118,   119,   119,
     119,   119,   120,   120,   121,   121,   122,   122,   123,   123,
     124,   124,   125,   126,   127,   128,   128,   128,   128,   128,
     128,   129,   129,   129,   129,   129,   129,   129,   129,   130,
     131,   131,   132,   133,   133,   134,   134,   134,   135,   135,
     135,   135,   135,   136,   136,   137,   137,   137,   138,   138,
     138,   139,   139,   139,   139,   140,   140,   140,   140,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   140,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   140,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   140,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   140,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   140,   140,
     140,   140,   140,   141,   141,   142,   142,   142,   142,   143,
     143,   144,   144,   144,   145,   146,   147,   147,   147,   148,
     148,   148,   148,   148,   148,   148,   148,   148,   148,   148,
     148,   148,   148,   148,   148,   149,   150,   151,   150,   150,
     150,   152,   153,   154,   153,   153,   153,   155,   156,   157,
     156,   156,   156,   158,   158,   158,   158,   158,   158,   158,
     159,   159,   160,   160,   160,   160,   161,   161,   161,   161,
     161,   161,   162,   162,   162,   162,   162,   162,   162,   162,
     163,   163,   163,   163,   163,   163,   163,   163,   163,   163,
     164,   164,   164,   164,   164,   164,   164,   164,   164,   164,
     164,   164,   165,   165,   166,   166,   167,   167,   168,   168
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     1,     2,     0,     1,     1,     1,     1,
       4,     4,     5,     5,     3,     3,     2,     2,     3,     3,
       2,     2,     2,     3,     2,     3,     3,     1,     3,     1,
       1,     1,     1,     1,     1,     3,     3,     2,     2,     1,
       1,     6,     6,     5,     5,     7,     7,     6,     6,     1,
       0,     2,     3,     1,     2,     1,     1,     1,     1,     1,
       1,     3,     3,     1,     2,     2,     3,     1,     3,     4,
       1,     2,     3,     2,     1,     2,     2,     2,     2,     2,
       3,     2,     2,     2,     2,     2,     2,     2,     3,     3,
       3,     4,     4,     3,     5,     5,     3,     3,     3,     4,
       4,     4,     4,     4,     3,     3,     3,     3,     3,     3,
       3,     3,     4,     3,     3,     4,     3,     3,     3,     3,
       3,     3,     2,     2,     5,     4,     4,     3,     3,     2,
       1,     1,     1,     0,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     4,     1,     1,     1,     1,     4,
       1,     2,     1,     2,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     2,     3,     0,     5,     2,
       2,     2,     3,     0,     5,     2,     2,     2,     3,     0,
       5,     2,     2,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     1,     2,     2,     2,     1,     2,     2,     2,
       2,     2,     1,     2,     2,     2,     2,     2,     2,     2,
       1,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       1,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     1,     2,     1,     1,     1,     3,     0,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       5,     0,     0,     3,     1,   132,    55,    56,    57,     0,
       0,   150,   152,     0,   141,     0,    32,   234,   160,   190,
     192,   196,   202,   210,   220,    74,     0,     0,     0,   136,
       0,     0,   133,     0,     0,     0,     0,     0,     0,     0,
       0,   157,   158,   159,   155,   156,     0,     0,   142,   143,
       4,     8,     9,    50,    50,     0,     0,   235,     0,     7,
       0,    53,     6,     0,     0,     0,   146,   148,     0,   131,
     147,   161,     0,   163,     0,   164,     0,   162,   183,   184,
     185,   186,   187,   188,   189,   232,    30,    33,     0,     0,
      22,    24,    39,    31,    40,    27,    29,    73,     0,     0,
       0,     0,     0,   235,   129,   160,   179,     0,   162,    76,
      75,    83,    84,     0,     0,    81,    79,    82,    78,    85,
      86,    87,    77,     0,   123,   122,    17,     0,     0,    49,
      21,     0,     0,    16,     0,    20,     0,     0,     0,    34,
      58,    59,    60,    54,     0,     0,    71,   133,   133,     0,
       0,     0,   151,   153,     0,   133,   135,     0,     0,   133,
     133,     0,     0,   133,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   137,   138,   133,     0,     0,     0,     0,
       0,     0,   170,   169,   165,   175,   171,   235,   176,   181,
     177,   182,   191,   193,   197,   203,   211,   221,   195,   194,
     198,   204,   212,   222,   201,   200,   199,   205,   213,   223,
     209,   208,   207,   206,   214,   224,   219,   218,   217,   216,
     215,   225,   231,   230,   229,   228,   227,   226,   233,    23,
      25,     0,     0,     0,    37,     0,    38,    88,    90,    89,
       0,   127,   166,     0,     0,     0,   178,   154,   172,     0,
      80,    98,    15,   132,     0,     0,    63,    67,    70,   232,
      51,    19,     0,    14,    18,     0,     0,    52,     0,    72,
       0,     0,    96,    97,   239,     0,   236,     0,     0,     0,
     128,     0,     0,   104,     0,     0,   109,   118,     0,   116,
     106,   117,   107,   113,   111,   114,   108,   110,     0,   105,
     119,   120,   121,     0,    93,     0,     0,     0,    39,    26,
      28,     0,    35,    36,   125,     0,     0,     0,   134,    65,
       0,     0,    64,     0,     0,    11,    10,    61,    62,    92,
      91,   144,     0,    99,   100,     0,   126,   102,     0,   115,
     101,   112,   103,     0,   149,     0,     0,     0,     0,     0,
       0,   168,   174,   180,     0,    68,    12,    66,    13,   237,
     124,    95,    94,    43,     0,    44,     0,     0,     0,     0,
       0,    69,    47,    48,    41,     0,    42,     0,    45,    46
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short yydefgoto[] =
{
      -1,     1,     2,     3,    50,    51,    52,    53,    54,    55,
      56,    90,    91,    92,   103,    94,   142,    95,    96,   128,
     129,    59,    60,    61,   144,   255,   256,   257,   258,    63,
     114,    64,    65,    66,    67,    68,    69,    70,    71,    72,
     243,    73,    74,   244,    75,    76,   245,    77,    78,    79,
      80,    81,    82,    83,    84,    85,   275,   276
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -229
static const short yypact[] =
{
    -229,    40,   445,  -229,  -229,  -229,  -229,  -229,  -229,   104,
     -32,    41,    51,    62,  -229,   633,  -229,  -229,  -229,  -229,
    -229,  -229,  -229,  -229,  -229,  -229,  1577,  1847,  1127,  -229,
    1847,  1847,    53,  1847,  1847,  1847,  1847,  1847,  1217,  1307,
    1847,  -229,  -229,  -229,    88,  -229,  1847,  1847,  -229,  -229,
    -229,  -229,  -229,   -34,   -22,   -18,    16,    -5,    57,  -229,
     112,  -229,  -229,     5,   -33,    99,     0,   120,   105,  2093,
     114,  -229,    71,  -229,   169,  -229,  1397,  -229,   159,   213,
     266,   280,   317,   344,    59,  -229,  -229,  -229,    -8,   125,
    -229,  -229,    52,  -229,   125,  -229,  -229,  -229,  1847,  1847,
    1847,   539,  1937,   141,  -229,   121,   225,    80,   124,  -229,
    -229,  -229,  -229,  1847,  1847,  -229,  -229,  -229,  -229,  -229,
    -229,  -229,  -229,  1847,  -229,  -229,  -229,   125,   936,   123,
    -229,   125,   936,  -229,   125,  -229,   125,  1847,  1847,  -229,
    -229,  -229,  -229,  -229,     6,   134,  -229,    53,    53,  1847,
    1847,  1487,   143,   158,  1667,    53,  -229,   126,  1847,    53,
      53,  1847,  1847,    53,  1847,  1847,  1847,  1847,  1847,  1847,
    1847,  1847,  1847,  -229,  -229,    53,  1847,  1847,  1847,  1847,
    1757,  1487,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,
    -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,
    -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,
    -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,
    -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,
    -229,    95,    -8,   125,   125,   125,  -229,  -229,  -229,  -229,
     539,  -229,  -229,   152,   256,  1847,  -229,  -229,  -229,   155,
    -229,  -229,  -229,    75,  1847,   734,  -229,  -229,  -229,   163,
    -229,  -229,   835,  -229,  -229,   170,   173,  -229,   118,  -229,
    1847,  1847,  -229,  -229,  -229,    15,  -229,  1847,  1847,  2027,
    -229,  1847,   -41,  -229,  1847,  1847,  -229,  -229,  1847,  -229,
    -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  1847,  -229,
    -229,  -229,  -229,   -41,  -229,    64,    44,    45,   161,  -229,
    -229,    95,  -229,  -229,  -229,   174,   175,   177,  -229,  -229,
       9,   178,  -229,  1037,   179,  -229,  -229,  -229,  -229,  -229,
    -229,  -229,  1487,  -229,  -229,   539,  -229,  -229,  1847,  -229,
    -229,  -229,  -229,  1847,  -229,   125,   181,   125,   182,    67,
      79,  -229,  -229,  -229,   180,  -229,  -229,  -229,  -229,  -229,
    -229,  -229,  -229,  -229,   125,  -229,   125,   125,   184,   125,
     185,  -229,  -229,  -229,  -229,   125,  -229,   125,  -229,  -229
};

/* YYPGOTO[NTERM-NUM].  */
static const short yypgoto[] =
{
    -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,
    -229,   139,   146,    92,    -2,     3,  -228,     4,     8,   183,
    -229,   109,  -229,   191,  -229,   111,  -186,   -82,   250,    -1,
     -95,   -68,  -229,  -229,  -229,  -229,  -229,  -229,  -229,  -229,
    -229,  -229,  -229,  -229,  -229,  -229,  -229,   -24,  -229,  -229,
    -229,  -229,  -229,  -229,  -229,   -73,    82,   -67
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, parse error.  */
#define YYTABLE_NINF -239
static const short yytable[] =
{
      57,   180,   108,   307,   126,    58,    97,    93,   156,    29,
    -140,   228,   127,   145,   104,  -139,   130,   354,    86,    87,
     133,    16,   147,   148,   131,   107,   109,   110,   134,   111,
     112,    89,   115,   116,   117,   118,   119,   120,   121,   122,
       4,  -145,   137,   146,   267,   124,   125,   355,   173,   174,
     188,   268,   270,   271,   135,   259,    98,   331,    93,   259,
     281,   332,   136,   141,   284,   285,    99,   232,   288,   322,
      86,    86,   187,    16,    16,   191,   322,   100,    86,    87,
     298,    16,   187,   350,   345,   347,    93,    93,    16,    17,
      93,   233,    93,    86,   113,   235,    16,   237,   238,   239,
     104,   241,   182,   123,   138,    86,   344,   367,    16,   183,
     332,   184,   249,   250,   149,     6,     7,     8,   246,   369,
     247,    86,   251,   139,    16,    93,     6,     7,     8,    93,
      86,    87,    93,    16,    93,   150,   265,   266,    86,    87,
     139,    16,    88,    89,    86,    87,   151,    16,   272,   273,
     274,    86,   140,   280,    16,   181,  -140,   283,   277,   242,
     286,   287,   248,   289,   290,   291,   292,   293,   294,   295,
     296,   297,   269,   278,   282,   299,   300,   301,   302,   304,
     274,   231,   259,   315,   234,   319,   236,    86,    87,   259,
      16,   192,   193,   194,   195,   196,   197,   318,    16,    17,
     233,    19,    20,    21,    22,    23,    24,   185,   325,   186,
     323,   326,   351,   352,   338,   353,   356,   358,   371,   252,
     316,   364,   366,   261,   375,   377,   263,   229,   264,    93,
      93,    93,    93,    93,   230,   343,   309,   132,   260,   314,
     310,   357,   187,   262,   317,   198,   199,   200,   201,   202,
     203,   143,    62,   320,  -173,  -173,  -167,  -173,  -173,  -173,
    -173,  -173,  -173,   305,     0,   359,    93,     0,     0,   329,
     330,   328,     0,     0,     0,     0,   333,   334,   336,     0,
     337,     0,     0,   339,   340,    16,    17,   341,    19,    20,
      21,    22,    23,    24,     0,     0,     0,   342,   204,   205,
     206,   207,   208,   209,    93,    93,    93,     0,     0,    93,
       0,   235,   210,   211,   212,   213,   214,   215,     0,     0,
       0,     0,     0,   306,   308,   311,   312,   313,     0,     0,
       0,   274,     0,     0,   360,     0,     0,   361,     0,     0,
       0,     0,   362,    93,     0,    93,     0,    93,    93,   216,
     217,   218,   219,   220,   221,     0,     0,     0,     0,     0,
     327,     0,    93,     0,    93,    93,     0,    93,     0,     0,
       0,     0,     0,    93,     0,    93,   222,   223,   224,   225,
     226,   227,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   346,   348,
     234,     0,     0,   349,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   363,     0,   365,
       0,   368,   370,     0,     0,    -2,     5,     0,     6,     7,
       8,     9,     0,    10,     0,     0,   372,     0,   373,   374,
       0,   376,     0,    11,    12,     0,     0,   378,     0,   379,
      13,    14,    15,     0,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,     0,     0,     0,     0,     0,
      27,     0,     0,     0,    28,    29,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    30,     0,     0,     0,
       0,    31,     0,    32,     0,     0,     0,     0,     0,    33,
       0,     0,     0,     0,    34,     0,     0,     0,    35,     0,
       0,    36,     0,    37,    38,    39,     0,     0,     0,     0,
       5,    40,    41,    42,    43,    44,    45,  -130,    46,    47,
      48,    49,     0,     0,     0,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,   101,   102,    16,    17,
      18,    19,    20,    21,    22,    23,    24,  -130,    26,  -130,
       0,  -130,     0,     0,    27,  -130,     0,     0,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       0,     0,     0,     0,     5,    40,    41,    42,    43,    44,
      45,  -130,    46,    47,    48,    49,     0,     0,     0,     0,
       0,    11,    12,     0,     0,     0,     0,     0,    13,    14,
     101,   102,    16,    17,    18,    19,    20,    21,    22,    23,
      24,  -130,    26,     0,     0,     0,     0,     0,    27,     0,
     -33,     0,    28,    29,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    30,     0,     0,     0,     0,    31,
       0,    32,     0,     0,     0,     0,     0,    33,     0,     0,
       0,     0,    34,     0,     0,     0,    35,     0,     0,    36,
       0,    37,    38,    39,     0,     0,     0,     0,     0,    40,
      41,    42,    43,    44,    45,   253,    46,    47,    48,    49,
     321,   254,    10,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    11,    12,     0,     0,     0,     0,     0,    13,
      14,   101,     0,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,     0,     0,     0,     0,     0,    27,
       0,     0,     0,    28,    29,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    30,     0,     0,     0,     0,
      31,     0,    32,     0,     0,     0,     0,     0,    33,     0,
       0,     0,     0,    34,     0,     0,     0,    35,     0,     0,
      36,     0,    37,    38,    39,     0,     0,     0,     0,     0,
      40,    41,    42,    43,    44,    45,   253,    46,    47,    48,
      49,   324,   254,    10,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    11,    12,     0,     0,     0,     0,     0,
      13,    14,   101,     0,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,     0,     0,     0,     0,     0,
      27,     0,     0,     0,    28,    29,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    30,     0,     0,     0,
       0,    31,     0,    32,     0,     0,     0,     0,     0,    33,
       0,     0,     0,     0,    34,     0,     0,     0,    35,     0,
       0,    36,     0,    37,    38,    39,     0,     0,     0,     0,
       0,    40,    41,    42,    43,    44,    45,   253,    46,    47,
      48,    49,     0,   254,    10,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    11,    12,     0,     0,     0,     0,
       0,    13,    14,   101,     0,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,     0,     0,     0,     0,
       0,    27,     0,     0,     0,    28,    29,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    30,     0,     0,
       0,     0,    31,     0,    32,     0,     0,     0,     0,     0,
      33,     0,     0,     0,     0,    34,     0,     0,     0,    35,
       0,     0,    36,     0,    37,    38,    39,     0,     0,     0,
       0,     0,    40,    41,    42,    43,    44,    45,     5,    46,
      47,    48,    49,     0,   254,    10,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    11,    12,     0,     0,     0,
       0,     0,    13,    14,   101,     0,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,     0,     0,     0,
       0,     0,    27,     0,     0,     0,    28,    29,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    30,     0,
       0,     0,     0,    31,     0,    32,     0,     0,     0,     0,
       0,    33,     0,     0,     0,     0,    34,     0,     0,     0,
      35,     0,     0,    36,     0,    37,    38,    39,     5,     0,
       0,     0,     0,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,     0,    11,    12,     0,     0,     0,
       0,     0,    13,    14,   101,     0,    16,    17,    18,    19,
      20,    21,    22,    23,    24,     0,    26,     0,     0,     0,
       0,     0,    27,     0,     0,     0,    28,    29,     0,     0,
       0,     0,  -135,  -135,     0,     0,     0,     0,    30,     0,
       0,     0,     0,    31,     0,    32,     0,     0,     0,     0,
       0,    33,     0,     0,     0,     0,    34,     0,     0,     0,
      35,     0,     0,    36,     0,    37,    38,    39,     5,     0,
       0,     0,     0,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,     0,    11,    12,     0,     0,     0,
       0,     0,    13,    14,   101,     0,    16,    17,    18,    19,
      20,    21,    22,    23,    24,     0,    26,     0,     0,     0,
       0,     0,    27,     0,     0,     0,    28,    29,     0,     0,
       0,     0,  -137,  -137,     0,     0,     0,     0,    30,     0,
       0,     0,     0,    31,     0,    32,     0,     0,     0,     0,
       0,    33,     0,     0,     0,     0,    34,     0,     0,     0,
      35,     0,     0,    36,     0,    37,    38,    39,     5,     0,
       0,     0,     0,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,     0,    11,    12,     0,     0,     0,
       0,     0,    13,    14,   101,     0,    16,    17,    18,    19,
      20,    21,    22,    23,    24,     0,    26,     0,     0,     0,
       0,     0,    27,     0,     0,     0,    28,    29,     0,     0,
       0,     0,  -138,  -138,     0,     0,     0,     0,    30,     0,
       0,     0,     0,    31,     0,    32,     0,     0,     0,     0,
       0,    33,     0,     0,     0,     0,    34,     0,     0,     0,
      35,     0,     0,    36,     0,    37,    38,    39,     5,     0,
       0,     0,     0,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,     0,    11,    12,     0,     0,     0,
       0,     0,    13,    14,   101,     0,    16,    17,    18,    19,
      20,    21,    22,    23,    24,   189,    26,   190,     0,     0,
       0,     0,    27,     0,     0,     0,    28,    29,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    30,     0,
       0,     0,     0,    31,     0,    32,     0,     0,     0,     0,
       0,    33,     0,     0,     0,     0,    34,     0,     0,     0,
      35,     0,     0,    36,     0,    37,    38,    39,     5,     0,
       0,     0,     0,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,     0,    11,    12,     0,     0,     0,
       0,     0,    13,    14,   101,     0,    16,    17,    18,    19,
      20,    21,    22,    23,    24,     0,    26,     0,     0,  -238,
       0,     0,    27,  -238,     0,     0,    28,    29,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    30,     0,
       0,     0,     0,    31,     0,    32,     0,     0,     0,     0,
       0,    33,     0,     0,     0,     0,    34,     0,     0,     0,
      35,     0,     0,    36,     0,    37,    38,    39,     5,     0,
       0,     0,     0,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,     0,    11,    12,     0,     0,     0,
       0,     0,    13,    14,   101,     0,    16,    17,   105,    19,
      20,    21,    22,    23,    24,   106,    26,     0,     0,     0,
       0,     0,    27,     0,     0,     0,    28,    29,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    30,     0,
       0,     0,     0,    31,     0,    32,     0,     0,     0,     0,
       0,    33,     0,     0,     0,     0,    34,     0,     0,     0,
      35,     0,     0,    36,     0,    37,    38,    39,     5,     0,
       0,     0,     0,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,     0,    11,    12,     0,     0,     0,
       0,     0,    13,    14,   101,   279,    16,    17,    18,    19,
      20,    21,    22,    23,    24,     0,    26,     0,     0,     0,
       0,     0,    27,     0,     0,     0,    28,    29,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    30,     0,
       0,     0,     0,    31,     0,    32,     0,     0,     0,     0,
       0,    33,     0,     0,     0,     0,    34,     0,     0,     0,
      35,     0,     0,    36,     0,    37,    38,    39,     5,     0,
       0,     0,     0,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,     0,    11,    12,     0,     0,     0,
       0,     0,    13,    14,   101,     0,    16,    17,    18,    19,
      20,    21,    22,    23,    24,     0,    26,     0,     0,     0,
       0,     0,    27,     0,     0,   303,    28,    29,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    30,     0,
       0,     0,     0,    31,     0,    32,     0,     0,     0,     0,
       0,    33,     0,     0,     0,     0,    34,     0,     0,     0,
      35,     0,     0,    36,     0,    37,    38,    39,     5,     0,
       0,     0,     0,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,     0,    11,    12,     0,     0,     0,
       0,     0,    13,    14,   101,     0,    16,    17,    18,    19,
      20,    21,    22,    23,    24,     0,    26,     0,     0,     0,
       0,     0,    27,     0,     0,     0,    28,    29,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    30,     0,
       0,     0,     0,    31,     0,    32,     0,     0,     0,     0,
       0,    33,     0,     0,     0,     0,    34,     0,     0,     0,
      35,     0,     0,    36,     0,    37,    38,    39,     5,     0,
       0,     0,     0,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,     0,    11,    12,     0,     0,     0,
       0,     0,    13,    14,   240,     0,    16,    17,    18,    19,
      20,    21,    22,    23,    24,     0,    26,     0,     0,     0,
       0,     0,    27,     0,     0,     0,    28,    29,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    30,     0,
       0,     0,     0,    31,     0,    32,     0,     0,     0,     0,
       0,    33,     0,     0,     0,     0,    34,     0,     0,     0,
      35,     0,     0,    36,     0,    37,    38,    39,     5,     0,
       0,     0,     0,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,     0,    11,    12,     0,     0,     0,
       0,     0,    13,    14,   335,     0,    16,    17,    18,    19,
      20,    21,    22,    23,    24,     0,    26,     0,     0,     0,
       0,     0,    27,     0,     0,     0,    28,    29,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    30,     0,
       0,     0,     0,    31,     0,    32,     0,     0,     0,     0,
       0,    33,     0,     0,     0,     0,    34,     0,     0,     0,
      35,   152,   153,    36,     0,    37,    38,    39,     0,     0,
     154,     0,     0,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,     0,     0,     0,     0,   155,     0,
       0,     0,   156,    29,   157,     0,     0,   158,   159,   160,
       0,     0,     0,     0,     0,     0,     0,   161,     0,   162,
       0,   163,     0,   164,   165,   166,   167,   168,     0,     0,
       0,     0,   169,     0,     0,     0,   170,     0,   171,   172,
       0,     0,   173,   174,     0,     0,   175,     0,     0,   176,
       0,     0,     0,     0,     0,   177,   178,     0,     0,     0,
     179
};

static const short yycheck[] =
{
       2,    69,    26,   231,    38,     2,    38,     9,    49,    50,
      15,    84,    46,     8,    15,    15,    38,     8,    26,    27,
      38,    29,    55,    56,    46,    26,    27,    28,    46,    30,
      31,    39,    33,    34,    35,    36,    37,    38,    39,    40,
       0,    41,    47,    38,    38,    46,    47,    38,    89,    90,
      74,    45,   147,   148,    38,   128,    15,    42,    60,   132,
     155,    46,    46,    60,   159,   160,    15,    15,   163,   255,
      26,    26,    74,    29,    29,    76,   262,    15,    26,    27,
     175,    29,    84,   311,    40,    40,    88,    89,    29,    30,
      92,    39,    94,    26,    41,    92,    29,    98,    99,   100,
     101,   102,    31,    15,    47,    26,    42,    40,    29,    38,
      46,    40,   113,   114,    15,     3,     4,     5,    38,    40,
      40,    26,   123,    28,    29,   127,     3,     4,     5,   131,
      26,    27,   134,    29,   136,    15,   137,   138,    26,    27,
      28,    29,    38,    39,    26,    27,    41,    29,   149,   150,
     151,    26,    60,   154,    29,    41,    15,   158,    15,    38,
     161,   162,    38,   164,   165,   166,   167,   168,   169,   170,
     171,   172,    38,    15,    48,   176,   177,   178,   179,   180,
     181,    89,   255,    31,    92,   110,    94,    26,    27,   262,
      29,    32,    33,    34,    35,    36,    37,    42,    29,    30,
      39,    32,    33,    34,    35,    36,    37,    38,    38,    40,
      47,    38,    38,    38,   282,    38,    38,    38,    38,   127,
     244,    40,    40,   131,    40,    40,   134,    88,   136,   231,
     232,   233,   234,   235,    88,   303,   232,    54,   129,   240,
     232,   323,   244,   132,   245,    32,    33,    34,    35,    36,
      37,    60,     2,   254,    29,    30,    31,    32,    33,    34,
      35,    36,    37,   181,    -1,   332,   268,    -1,    -1,   270,
     271,   268,    -1,    -1,    -1,    -1,   277,   278,   279,    -1,
     281,    -1,    -1,   284,   285,    29,    30,   288,    32,    33,
      34,    35,    36,    37,    -1,    -1,    -1,   298,    32,    33,
      34,    35,    36,    37,   306,   307,   308,    -1,    -1,   311,
      -1,   308,    32,    33,    34,    35,    36,    37,    -1,    -1,
      -1,    -1,    -1,   231,   232,   233,   234,   235,    -1,    -1,
      -1,   332,    -1,    -1,   335,    -1,    -1,   338,    -1,    -1,
      -1,    -1,   343,   345,    -1,   347,    -1,   349,   350,    32,
      33,    34,    35,    36,    37,    -1,    -1,    -1,    -1,    -1,
     268,    -1,   364,    -1,   366,   367,    -1,   369,    -1,    -1,
      -1,    -1,    -1,   375,    -1,   377,    32,    33,    34,    35,
      36,    37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   306,   307,
     308,    -1,    -1,   311,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   345,    -1,   347,
      -1,   349,   350,    -1,    -1,     0,     1,    -1,     3,     4,
       5,     6,    -1,     8,    -1,    -1,   364,    -1,   366,   367,
      -1,   369,    -1,    18,    19,    -1,    -1,   375,    -1,   377,
      25,    26,    27,    -1,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    -1,    -1,    -1,    -1,    -1,
      45,    -1,    -1,    -1,    49,    50,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,    -1,    -1,
      -1,    66,    -1,    68,    -1,    -1,    -1,    -1,    -1,    74,
      -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,    83,    -1,
      -1,    86,    -1,    88,    89,    90,    -1,    -1,    -1,    -1,
       1,    96,    97,    98,    99,   100,   101,     8,   103,   104,
     105,   106,    -1,    -1,    -1,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      -1,    42,    -1,    -1,    45,    46,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
      -1,    -1,    -1,    -1,     1,    96,    97,    98,    99,   100,
     101,     8,   103,   104,   105,   106,    -1,    -1,    -1,    -1,
      -1,    18,    19,    -1,    -1,    -1,    -1,    -1,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    -1,    -1,    -1,    -1,    -1,    45,    -1,
      47,    -1,    49,    50,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    61,    -1,    -1,    -1,    -1,    66,
      -1,    68,    -1,    -1,    -1,    -1,    -1,    74,    -1,    -1,
      -1,    -1,    79,    -1,    -1,    -1,    83,    -1,    -1,    86,
      -1,    88,    89,    90,    -1,    -1,    -1,    -1,    -1,    96,
      97,    98,    99,   100,   101,     1,   103,   104,   105,   106,
       6,     7,     8,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    18,    19,    -1,    -1,    -1,    -1,    -1,    25,
      26,    27,    -1,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    -1,    -1,    -1,    -1,    -1,    45,
      -1,    -1,    -1,    49,    50,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    61,    -1,    -1,    -1,    -1,
      66,    -1,    68,    -1,    -1,    -1,    -1,    -1,    74,    -1,
      -1,    -1,    -1,    79,    -1,    -1,    -1,    83,    -1,    -1,
      86,    -1,    88,    89,    90,    -1,    -1,    -1,    -1,    -1,
      96,    97,    98,    99,   100,   101,     1,   103,   104,   105,
     106,     6,     7,     8,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    18,    19,    -1,    -1,    -1,    -1,    -1,
      25,    26,    27,    -1,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    -1,    -1,    -1,    -1,    -1,
      45,    -1,    -1,    -1,    49,    50,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,    -1,    -1,
      -1,    66,    -1,    68,    -1,    -1,    -1,    -1,    -1,    74,
      -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,    83,    -1,
      -1,    86,    -1,    88,    89,    90,    -1,    -1,    -1,    -1,
      -1,    96,    97,    98,    99,   100,   101,     1,   103,   104,
     105,   106,    -1,     7,     8,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    18,    19,    -1,    -1,    -1,    -1,
      -1,    25,    26,    27,    -1,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    -1,    -1,    -1,    -1,
      -1,    45,    -1,    -1,    -1,    49,    50,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,    -1,
      -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,    -1,
      74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,    83,
      -1,    -1,    86,    -1,    88,    89,    90,    -1,    -1,    -1,
      -1,    -1,    96,    97,    98,    99,   100,   101,     1,   103,
     104,   105,   106,    -1,     7,     8,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    18,    19,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    -1,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    -1,    -1,    -1,
      -1,    -1,    45,    -1,    -1,    -1,    49,    50,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,
      83,    -1,    -1,    86,    -1,    88,    89,    90,     1,    -1,
      -1,    -1,    -1,    96,    97,    98,    99,   100,   101,    -1,
     103,   104,   105,   106,    -1,    18,    19,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    -1,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    -1,    39,    -1,    -1,    -1,
      -1,    -1,    45,    -1,    -1,    -1,    49,    50,    -1,    -1,
      -1,    -1,    55,    56,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,
      83,    -1,    -1,    86,    -1,    88,    89,    90,     1,    -1,
      -1,    -1,    -1,    96,    97,    98,    99,   100,   101,    -1,
     103,   104,   105,   106,    -1,    18,    19,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    -1,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    -1,    39,    -1,    -1,    -1,
      -1,    -1,    45,    -1,    -1,    -1,    49,    50,    -1,    -1,
      -1,    -1,    55,    56,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,
      83,    -1,    -1,    86,    -1,    88,    89,    90,     1,    -1,
      -1,    -1,    -1,    96,    97,    98,    99,   100,   101,    -1,
     103,   104,   105,   106,    -1,    18,    19,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    -1,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    -1,    39,    -1,    -1,    -1,
      -1,    -1,    45,    -1,    -1,    -1,    49,    50,    -1,    -1,
      -1,    -1,    55,    56,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,
      83,    -1,    -1,    86,    -1,    88,    89,    90,     1,    -1,
      -1,    -1,    -1,    96,    97,    98,    99,   100,   101,    -1,
     103,   104,   105,   106,    -1,    18,    19,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    -1,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    -1,    -1,
      -1,    -1,    45,    -1,    -1,    -1,    49,    50,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,
      83,    -1,    -1,    86,    -1,    88,    89,    90,     1,    -1,
      -1,    -1,    -1,    96,    97,    98,    99,   100,   101,    -1,
     103,   104,   105,   106,    -1,    18,    19,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    -1,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    -1,    39,    -1,    -1,    42,
      -1,    -1,    45,    46,    -1,    -1,    49,    50,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,
      83,    -1,    -1,    86,    -1,    88,    89,    90,     1,    -1,
      -1,    -1,    -1,    96,    97,    98,    99,   100,   101,    -1,
     103,   104,   105,   106,    -1,    18,    19,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    -1,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    -1,    -1,    -1,
      -1,    -1,    45,    -1,    -1,    -1,    49,    50,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,
      83,    -1,    -1,    86,    -1,    88,    89,    90,     1,    -1,
      -1,    -1,    -1,    96,    97,    98,    99,   100,   101,    -1,
     103,   104,   105,   106,    -1,    18,    19,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    -1,    39,    -1,    -1,    -1,
      -1,    -1,    45,    -1,    -1,    -1,    49,    50,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,
      83,    -1,    -1,    86,    -1,    88,    89,    90,     1,    -1,
      -1,    -1,    -1,    96,    97,    98,    99,   100,   101,    -1,
     103,   104,   105,   106,    -1,    18,    19,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    -1,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    -1,    39,    -1,    -1,    -1,
      -1,    -1,    45,    -1,    -1,    48,    49,    50,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,
      83,    -1,    -1,    86,    -1,    88,    89,    90,     1,    -1,
      -1,    -1,    -1,    96,    97,    98,    99,   100,   101,    -1,
     103,   104,   105,   106,    -1,    18,    19,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    -1,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    -1,    39,    -1,    -1,    -1,
      -1,    -1,    45,    -1,    -1,    -1,    49,    50,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,
      83,    -1,    -1,    86,    -1,    88,    89,    90,     1,    -1,
      -1,    -1,    -1,    96,    97,    98,    99,   100,   101,    -1,
     103,   104,   105,   106,    -1,    18,    19,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    -1,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    -1,    39,    -1,    -1,    -1,
      -1,    -1,    45,    -1,    -1,    -1,    49,    50,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,
      83,    -1,    -1,    86,    -1,    88,    89,    90,     1,    -1,
      -1,    -1,    -1,    96,    97,    98,    99,   100,   101,    -1,
     103,   104,   105,   106,    -1,    18,    19,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    -1,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    -1,    39,    -1,    -1,    -1,
      -1,    -1,    45,    -1,    -1,    -1,    49,    50,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,
      83,    18,    19,    86,    -1,    88,    89,    90,    -1,    -1,
      27,    -1,    -1,    96,    97,    98,    99,   100,   101,    -1,
     103,   104,   105,   106,    -1,    -1,    -1,    -1,    45,    -1,
      -1,    -1,    49,    50,    51,    -1,    -1,    54,    55,    56,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    64,    -1,    66,
      -1,    68,    -1,    70,    71,    72,    73,    74,    -1,    -1,
      -1,    -1,    79,    -1,    -1,    -1,    83,    -1,    85,    86,
      -1,    -1,    89,    90,    -1,    -1,    93,    -1,    -1,    96,
      -1,    -1,    -1,    -1,    -1,   102,   103,    -1,    -1,    -1,
     107
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,   112,   113,   114,     0,     1,     3,     4,     5,     6,
       8,    18,    19,    25,    26,    27,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    45,    49,    50,
      61,    66,    68,    74,    79,    83,    86,    88,    89,    90,
      96,    97,    98,    99,   100,   101,   103,   104,   105,   106,
     115,   116,   117,   118,   119,   120,   121,   125,   126,   132,
     133,   134,   139,   140,   142,   143,   144,   145,   146,   147,
     148,   149,   150,   152,   153,   155,   156,   158,   159,   160,
     161,   162,   163,   164,   165,   166,    26,    27,    38,    39,
     122,   123,   124,   125,   126,   128,   129,    38,    15,    15,
      15,    27,    28,   125,   140,    31,    38,   140,   158,   140,
     140,   140,   140,    41,   141,   140,   140,   140,   140,   140,
     140,   140,   140,    15,   140,   140,    38,    46,   130,   131,
      38,    46,   130,    38,    46,    38,    46,    47,    47,    28,
     124,   126,   127,   134,   135,     8,    38,    55,    56,    15,
      15,    41,    18,    19,    27,    45,    49,    51,    54,    55,
      56,    64,    66,    68,    70,    71,    72,    73,    74,    79,
      83,    85,    86,    89,    90,    93,    96,   102,   103,   107,
     142,    41,    31,    38,    40,    38,    40,   125,   158,    38,
      40,   140,    32,    33,    34,    35,    36,    37,    32,    33,
      34,    35,    36,    37,    32,    33,    34,    35,    36,    37,
      32,    33,    34,    35,    36,    37,    32,    33,    34,    35,
      36,    37,    32,    33,    34,    35,    36,    37,   166,   122,
     123,   124,    15,    39,   124,   126,   124,   140,   140,   140,
      27,   140,    38,   151,   154,   157,    38,    40,    38,   140,
     140,   140,   124,     1,     7,   136,   137,   138,   139,   166,
     132,   124,   136,   124,   124,   140,   140,    38,    45,    38,
     141,   141,   140,   140,   140,   167,   168,    15,    15,    28,
     140,   141,    48,   140,   141,   141,   140,   140,   141,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   141,   140,
     140,   140,   140,    48,   140,   167,   124,   127,   124,   128,
     129,   124,   124,   124,   140,    31,   158,   140,    42,   110,
     140,     6,   137,    47,     6,    38,    38,   124,   126,   140,
     140,    42,    46,   140,   140,    27,   140,   140,   142,   140,
     140,   140,   140,   142,    42,    40,   124,    40,   124,   124,
     127,    38,    38,    38,     8,    38,    38,   138,    38,   168,
     140,   140,   140,   124,    40,   124,    40,    40,   124,    40,
     124,    38,   124,   124,   124,    40,   124,    40,   124,   124
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrlab1

/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");			\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)           \
  Current.first_line   = Rhs[1].first_line;      \
  Current.first_column = Rhs[1].first_column;    \
  Current.last_line    = Rhs[N].last_line;       \
  Current.last_column  = Rhs[N].last_column;
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#define YYLEX	yylex ()

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)
# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)
/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
#endif /* !YYDEBUG */

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*-----------------------------.
| Print this symbol on YYOUT.  |
`-----------------------------*/

static void
#if defined (__STDC__) || defined (__cplusplus)
yysymprint (FILE* yyout, int yytype, YYSTYPE yyvalue)
#else
yysymprint (yyout, yytype, yyvalue)
    FILE* yyout;
    int yytype;
    YYSTYPE yyvalue;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvalue;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyout, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyout, yytoknum[yytype], yyvalue);
# endif
    }
  else
    YYFPRINTF (yyout, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyout, ")");
}
#endif /* YYDEBUG. */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
#if defined (__STDC__) || defined (__cplusplus)
yydestruct (int yytype, YYSTYPE yyvalue)
#else
yydestruct (yytype, yyvalue)
    int yytype;
    YYSTYPE yyvalue;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvalue;

  switch (yytype)
    {
      default:
        break;
    }
}



/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
#  define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL
# else
#  define YYPARSE_PARAM_ARG YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
# endif
#else /* !YYPARSE_PARAM */
# define YYPARSE_PARAM_ARG
# define YYPARSE_PARAM_DECL
#endif /* !YYPARSE_PARAM */

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
# ifdef YYPARSE_PARAM
int yyparse (void *);
# else
int yyparse (void);
# endif
#endif


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of parse errors so far.  */
int yynerrs;


int
yyparse (YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  
  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yychar1 = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with.  */

  if (yychar <= 0)		/* This means end of input.  */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more.  */

      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yychar1 = YYTRANSLATE (yychar);

      /* We have to keep this `#if YYDEBUG', since we use variables
	 which are defined only if `YYDEBUG' is set.  */
      YYDPRINTF ((stderr, "Next token is "));
      YYDSYMPRINT ((stderr, yychar1, yylval));
      YYDPRINTF ((stderr, "\n"));
    }

  /* If the proper action on seeing token YYCHAR1 is to reduce or to
     detect an error, take that action.  */
  yyn += yychar1;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yychar1)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %d (%s), ",
	      yychar, yytname[yychar1]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];



#if YYDEBUG
  /* We have to keep this `#if YYDEBUG', since we use variables which
     are defined only if `YYDEBUG' is set.  */
  if (yydebug)
    {
      int yyi;

      YYFPRINTF (stderr, "Reducing via rule %d (line %d), ",
		 yyn - 1, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (yyi = yyprhs[yyn]; yyrhs[yyi] >= 0; yyi++)
	YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
      YYFPRINTF (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif
  switch (yyn)
    {
        case 2:
    {if (gstmts != NILSTATE && ! errflag) 
	 	 mnbody(gstmts);}
    break;

  case 4:
    {lexscope = GLOBAL; SETATTRIBUTES;
			  funmode=1;funlnum=0;}
    break;

  case 5:
    {lexscope = GLOBAL;
                         SETATTRIBUTES;
                         linenum = 1;
                         mainlnum = 0;
                         funlnum = 0;
			 funmode = 1;
			 linemode = 2;
                         gstmts = NILSTATE;
			 resetconsts();
                         addicon(0);/* ensure 0 */
                         addicon(1);/* ensure 1 */
                         errflag = 0; }
    break;

  case 6:
    {gstmts = addstmt(gstmts, newstate(NILCHAR, yyvsp[0].n)); 
             funmode=1;yylistfn();}
    break;

  case 10:
    {direct(yyvsp[-3].c, yyvsp[-1].n);
                                     funmode=0;yylistfn();}
    break;

  case 11:
    {direct(yyvsp[-3].c, yyvsp[-1].n);
                                     funmode=0;yylistfn();}
    break;

  case 12:
    {if (! errflag)
                                            prog(yyvsp[-4].h, yyvsp[-2].t);
					 resetconsts();
					 reinit_local_symtab();
                                         linemode=1;yylistfn();}
    break;

  case 13:
    {if (! errflag)
                                            opprog(yyvsp[-4].oh, yyvsp[-2].t);
					 resetconsts();
					 reinit_local_symtab();
                                         linemode=1;yylistfn();}
    break;

  case 14:
    {enterid(yyvsp[0].c, lexscope, APLC_UKTYPE, NORANK);yyval.h = yyvsp[-2].h;}
    break;

  case 15:
    {enterid(yyvsp[0].c, lexscope, APLC_UKTYPE, NORANK);yyval.h = yyvsp[-2].h;}
    break;

  case 16:
    {yyval.h = yyvsp[-1].h;
		                      funmode=2;linemode=1;yylistfn();}
    break;

  case 17:
    {yyval.h = yyvsp[-1].h;
		                      funmode=2;linemode=1;yylistfn();}
    break;

  case 18:
    {enterid(yyvsp[0].c, lexscope, APLC_UKTYPE, NORANK);yyval.oh = yyvsp[-2].oh;}
    break;

  case 19:
    {enterid(yyvsp[0].c, lexscope, APLC_UKTYPE, NORANK);yyval.oh = yyvsp[-2].oh;}
    break;

  case 20:
    {yyval.oh = yyvsp[-1].oh;
		                        funmode=2;linemode=1;yylistfn();}
    break;

  case 21:
    {yyval.oh = yyvsp[-1].oh;
		                        funmode=2;linemode=1;yylistfn();}
    break;

  case 22:
    {lexscope = LOCAL; yyval.h = yyvsp[0].h;}
    break;

  case 23:
    {lexscope = LOCAL; yyval.h = yyvsp[0].h;}
    break;

  case 24:
    {lexscope = LOCAL; yyval.oh = yyvsp[0].oh;}
    break;

  case 25:
    {lexscope = LOCAL; yyval.oh = yyvsp[0].oh;}
    break;

  case 26:
    {yyvsp[0].h->asvar = yyvsp[-2].c;
                                enterid(yyvsp[-2].c, APARAM, APLC_UKTYPE, NORANK);
                                yyval.h = yyvsp[0].h;}
    break;

  case 27:
    {yyval.h = yyvsp[0].h;}
    break;

  case 28:
    {yyvsp[0].oh->asvar = yyvsp[-2].c;
                                enterid(yyvsp[-2].c, APARAM, APLC_UKTYPE, NORANK);
                                yyval.oh = yyvsp[0].oh;}
    break;

  case 29:
    {yyval.oh = yyvsp[0].oh;}
    break;

  case 30:
    {yyval.c = yyvsp[0].s->name;}
    break;

  case 32:
    {yyval.c = newid(yytext);}
    break;

  case 33:
    {yyval.c = yyvsp[0].s->name;}
    break;

  case 34:
    {yyval.c = yyvsp[0].s->name;}
    break;

  case 35:
    {yyval.h = newhead(yyvsp[-1].c, yyvsp[-2].c, yyvsp[0].c);}
    break;

  case 36:
    {yyval.h = newhead(yyvsp[-1].c, yyvsp[-2].c, yyvsp[0].c);}
    break;

  case 37:
    {yyval.h = newhead(yyvsp[-1].c, NILCHAR, yyvsp[0].c);}
    break;

  case 38:
    {yyval.h = newhead(yyvsp[-1].c, NILCHAR, yyvsp[0].c);}
    break;

  case 39:
    {yyval.h = newhead(yyvsp[0].c, NILCHAR, NILCHAR);}
    break;

  case 40:
    {yyval.h = newhead(yyvsp[0].c, NILCHAR, NILCHAR);}
    break;

  case 41:
    {yyval.oh = newophead(yyvsp[-5].c, yyvsp[-3].c, yyvsp[-2].c, NILCHAR, yyvsp[0].c);}
    break;

  case 42:
    {yyval.oh = newophead(yyvsp[-5].c, yyvsp[-3].c, yyvsp[-2].c, NILCHAR, yyvsp[0].c);}
    break;

  case 43:
    {yyval.oh = newophead(NILCHAR, yyvsp[-3].c, yyvsp[-2].c, NILCHAR, yyvsp[0].c);}
    break;

  case 44:
    {yyval.oh = newophead(NILCHAR, yyvsp[-3].c, yyvsp[-2].c, NILCHAR, yyvsp[0].c);}
    break;

  case 45:
    {yyval.oh = newophead(yyvsp[-6].c, yyvsp[-4].c, yyvsp[-3].c, yyvsp[-2].c, yyvsp[0].c);}
    break;

  case 46:
    {yyval.oh = newophead(yyvsp[-6].c, yyvsp[-4].c, yyvsp[-3].c, yyvsp[-2].c, yyvsp[0].c);}
    break;

  case 47:
    {yyval.oh = newophead(NILCHAR, yyvsp[-4].c, yyvsp[-3].c, yyvsp[-2].c, yyvsp[0].c);}
    break;

  case 48:
    {yyval.oh = newophead(NILCHAR, yyvsp[-4].c, yyvsp[-3].c, yyvsp[-2].c, yyvsp[0].c);}
    break;

  case 49:
    {setlocalcons();
               addicon(0);
               addicon(1);}
    break;

  case 50:
    {SETATTRIBUTES;}
    break;

  case 51:
    {SETATTRIBUTES;}
    break;

  case 52:
    {linemode=1;yylistfn();}
    break;

  case 55:
    {dclclass = yyvsp[0].l;}
    break;

  case 56:
    {dcltype  = yyvsp[0].i;}
    break;

  case 57:
    {dclrank  = yyvsp[0].i;}
    break;

  case 58:
    {enterid(yyvsp[0].c, dclclass, dcltype, dclrank);}
    break;

  case 59:
    {enterid(yyvsp[0].c, FUNCTION, dcltype, dclrank);}
    break;

  case 60:
    {enterid(yyvsp[0].c, OPERATOR, dcltype, dclrank);}
    break;

  case 61:
    {enterid(yyvsp[0].c, dclclass, dcltype, dclrank);}
    break;

  case 62:
    {enterid(yyvsp[0].c, FUNCTION, dcltype, dclrank);}
    break;

  case 63:
    {yyval.t = yyvsp[0].t;yylistfn();}
    break;

  case 64:
    {yyval.t = addstmt(yyvsp[-1].t, yyvsp[0].t);yylistfn();}
    break;

  case 65:
    {yyerrok;}
    break;

  case 66:
    {yyval.t = newstate(yyvsp[-2].c, yyvsp[0].n);
                                            linemode=2;/* make sure */}
    break;

  case 67:
    {yyval.t = newstate(NILCHAR, yyvsp[0].n);}
    break;

  case 68:
    {yyval.n = pt1(GO, yyvsp[-1].n);}
    break;

  case 69:
    {yyval.n = pt1(GO, yyvsp[-2].n);}
    break;

  case 70:
    {yyval.n = yyvsp[0].n;}
    break;

  case 71:
    {yyval.n = pttop(yyvsp[-1].n);}
    break;

  case 72:
    {yyval.n = pttop(yyvsp[-2].n);}
    break;

  case 73:
    {yyval.n = pt1(COMMENT, (struct node *) 0);
                                   linemode=1;}
    break;

  case 74:
    {yyval.n = pt1(COMMENT, (struct node *) 0);
                                   linemode=0;}
    break;

  case 75:
    {yyval.n = pt1o(MSFUN, yyvsp[-1].o, yyvsp[0].n);}
    break;

  case 76:
    {yyval.n = pt1(RAVEL, yyvsp[0].n);}
    break;

  case 77:
    {yyval.n = pt1(DOMINO, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 78:
    {yyval.n = pt1(FORMAT, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 79:
    {yyval.n = pt1(IOTA, pt1(CISCALAR, yyvsp[0].n));}
    break;

  case 80:
    {yyval.n = pt1a(REVERSE, yyvsp[-1].n, yyvsp[-2].i, yyvsp[0].n);}
    break;

  case 81:
    {yyval.n = ptmrho(yyvsp[0].n);}
    break;

  case 82:
    {yyval.n = pt1(COLLECT, pt1(ROLL, yyvsp[0].n));}
    break;

  case 83:
    {yyval.n = ptsort(yyvsp[-1].i, pt1(CVEC, yyvsp[0].n));}
    break;

  case 84:
    {yyval.n = pt1(TRANS, yyvsp[0].n);}
    break;

  case 85:
    {yyval.n = pt1(EXECUTE, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 86:
    {yyval.n = pt1(BOX, pt1(CCOLLECT, yyvsp[0].n));}
    break;

  case 87:
    {yyval.n = pt1(UNBOX, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 88:
    {yyval.n = ptqass(yyvsp[0].n);}
    break;

  case 89:
    {yyval.n = ptqlzass(yyvsp[0].n);}
    break;

  case 90:
    {yyval.n = pt1(QQUADASSIGN, yyvsp[0].n);}
    break;

  case 91:
    {yyval.n = pt1ao(SCAN,   yyvsp[-3].o, yyvsp[-1].n, yyvsp[0].n, yyvsp[-2].i);}
    break;

  case 92:
    {yyval.n = pt1ao(REDUCE, yyvsp[-3].o, yyvsp[-1].n, yyvsp[0].n, yyvsp[-2].i);}
    break;

  case 93:
    {yyval.n = pt2o(DSFUN, yyvsp[-1].o, yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 94:
    {yyval.n = pt1ao(INNER, yyvsp[-3].o, NILP,
               pt2aos(INNERCHILD, yyvsp[-1].o, NILP, FIRSTAXIS, yyvsp[-4].n, yyvsp[0].n), LASTAXIS);}
    break;

  case 95:
    {yyval.n = pt2o(OUTER, yyvsp[-1].o, yyvsp[-4].n, yyvsp[0].n);}
    break;

  case 96:
    {yyval.n = pt2(ASSIGN, yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 97:
    {yyval.n = ptsub(yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 98:
    {yyval.n = pt1o(ASYSVAR, yyvsp[-2].v, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 99:
    {yyval.n = pt2(DQUADASSIGN, yyvsp[-3].n, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 100:
    {yyval.n = pt2(DQQUADASSIGN, yyvsp[-3].n, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 101:
    {yyval.n = pt2a(EXPAND, yyvsp[-1].n, yyvsp[-2].i, yyvsp[-3].n, yyvsp[0].n);}
    break;

  case 102:
    {yyval.n = pt2a(CAT,yyvsp[-1].n, LASTAXIS, yyvsp[-3].n, yyvsp[0].n);}
    break;

  case 103:
    {yyval.n = pt2a(LINK, yyvsp[-1].n, LASTAXIS, 
						 pt1(COLLECT,yyvsp[-3].n), pt1(COLLECT,yyvsp[0].n));}
    break;

  case 104:
    {yyval.n = pt1ao(INNER, APLC_PLUS, NILP,
               pt2aos(DECODE, APLC_TIMES, NILP, FIRSTAXIS, yyvsp[-2].n, yyvsp[0].n), LASTAXIS);}
    break;

  case 105:
    {yyval.n = pt2(MSOLVE, pt1(COLLECT, yyvsp[-2].n), pt1(COLLECT, yyvsp[0].n));}
    break;

  case 106:
    {yyval.n = pt2(DROP, pt1(CIVEC, yyvsp[-2].n), 
					      pt1(COLLECT, yyvsp[0].n));}
    break;

  case 107:
    {yyval.n = pt2(GWDROP, pt1(CIVEC, yyvsp[-2].n), yyvsp[0].n);}
    break;

  case 108:
    {yyval.n = pt2(ENCODE, yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 109:
    {yyval.n = pt2(EPSILON, yyvsp[-2].n, 
                                          ptsort(1, pt1(CVEC, pt1(RAVEL, yyvsp[0].n))));}
    break;

  case 110:
    {yyval.n = pt2(DFORMAT, 
                                          pt1(COLLECT, yyvsp[-2].n), pt1(COLLECT, yyvsp[0].n));}
    break;

  case 111:
    {yyval.n = pt2(INDEX, 
				          ptsort(1, pt1(CVEC, yyvsp[-2].n)), yyvsp[0].n);}
    break;

  case 112:
    {yyval.n = pt2a(ROTATE, yyvsp[-1].n, yyvsp[-2].i, yyvsp[-3].n, yyvsp[0].n);}
    break;

  case 113:
    {yyval.n = pt2(RESHAPE, pt1(CIVEC, yyvsp[-2].n), yyvsp[0].n);}
    break;

  case 114:
    {yyval.n = pt2(DEAL, pt1(CISCALAR, yyvsp[-2].n), pt1(CISCALAR, yyvsp[0].n));}
    break;

  case 115:
    {yyval.n = pt2a(COMPRESS, yyvsp[-1].n, yyvsp[-2].i, yyvsp[-3].n, yyvsp[0].n);}
    break;

  case 116:
    {yyval.n = pt2(TAKE, pt1(CIVEC, yyvsp[-2].n), 
					      pt1(COLLECT, yyvsp[0].n));}
    break;

  case 117:
    {yyval.n = pt2(GWTAKE, pt1(CIVEC, yyvsp[-2].n), yyvsp[0].n);}
    break;

  case 118:
    {yyval.n = pt2(DTRANS, pt1(CIVEC, yyvsp[-2].n), yyvsp[0].n);}
    break;

  case 119:
    {yyval.n = pt2o(DSYSFUN, yyvsp[-1].v, pt1(COLLECT, yyvsp[-2].n), 
                                              pt1(COLLECT, yyvsp[0].n));}
    break;

  case 120:
    {yyval.n = pt2o(DSYSFUN, yyvsp[-1].v, pt1(COLLECT, yyvsp[-2].n), 
                         pt1(COLLECT, yyvsp[0].n));}
    break;

  case 121:
    {yyval.n = pt2(CATCH,  yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 122:
    {yyval.n = ptmsys(MSYSFUN, yyvsp[-1].v, yyvsp[0].n);}
    break;

  case 123:
    {yyval.n = pt1o(MSYSFUN, yyvsp[-1].v, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 124:
    {yyval.n = ptop(yyvsp[-4].n, yyvsp[-3].s,  yyvsp[-2].s, yyvsp[-1].s, yyvsp[0].n);}
    break;

  case 125:
    {yyval.n = ptop(NILP, yyvsp[-3].s,  yyvsp[-2].s, yyvsp[-1].s, yyvsp[0].n);}
    break;

  case 126:
    {yyval.n = ptop(yyvsp[-3].n, yyvsp[-2].s,  yyvsp[-1].s, NILSYM, yyvsp[0].n);}
    break;

  case 127:
    {yyval.n = ptop(NILP, yyvsp[-2].s,  yyvsp[-1].s, NILSYM, yyvsp[0].n);}
    break;

  case 128:
    {yyval.n = ptfun(yyvsp[-1].s,  yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 129:
    {yyval.n = ptfun(yyvsp[-1].s, NILP, yyvsp[0].n);}
    break;

  case 130:
    {yyval.n = ptnilfun(yyvsp[0].s);}
    break;

  case 131:
    {yyval.n = yyvsp[0].n;}
    break;

  case 132:
    {expect("expression");}
    break;

  case 133:
    {yyval.n = 0;}
    break;

  case 134:
    {yyval.n = yyvsp[-1].n;}
    break;

  case 135:
    {yyval.o = yyvsp[0].o;}
    break;

  case 136:
    {yyval.o = yyvsp[0].o;}
    break;

  case 137:
    {yyval.o = APLC_LT;}
    break;

  case 138:
    {yyval.o = APLC_GT;}
    break;

  case 139:
    {yyval.n = yyvsp[0].n;}
    break;

  case 140:
    {yyval.n = ptvar(enterid(yyvsp[0].c, dclclass, APLC_UKTYPE, NORANK));}
    break;

  case 141:
    {yyval.n = ptvar(yyvsp[0].s);}
    break;

  case 142:
    {yyval.n = sysparm("_alpha");}
    break;

  case 143:
    {yyval.n = sysparm("_omega");}
    break;

  case 144:
    {yyval.n = pt2(SUB, yyvsp[-3].n, yyvsp[-1].n);}
    break;

  case 145:
    {yyval.n = yyvsp[0].n;}
    break;

  case 146:
    {yyval.n = yyvsp[0].n;}
    break;

  case 147:
    {yyval.n = yyvsp[0].n;}
    break;

  case 148:
    {yyval.n = yyvsp[0].n;}
    break;

  case 149:
    {yyval.n = pt2(SUB, yyvsp[-3].n, yyvsp[-1].n);}
    break;

  case 150:
    {yyval.n = newnode(QUAD);}
    break;

  case 151:
    {yyval.n = pt1(DQUAD, yyvsp[-1].n);}
    break;

  case 152:
    {yyval.n = newnode(QQUAD);}
    break;

  case 153:
    {yyval.n = pt1(DQQUAD, yyvsp[-1].n);}
    break;

  case 154:
    {yyval.n = yyvsp[-1].n;}
    break;

  case 155:
    {yyval.n = pt1o(SYSVAR, yyvsp[0].v, NILP);}
    break;

  case 156:
    {yyval.n = pt1o(SYSVAR, yyvsp[0].v, NILP);}
    break;

  case 157:
    {yyval.n = newnode(AVEC);}
    break;

  case 158:
    {yyval.n = pttcav(TCAV, yyvsp[0].v);}
    break;

  case 159:
    {yyval.n = pttycon(TYPECON, yyvsp[0].v);}
    break;

  case 160:
    {yyval.n = ptsvec(yyvsp[0].c);}
    break;

  case 161:
    {yyval.n = yyvsp[0].n;}
    break;

  case 162:
    {yyval.n = yyvsp[0].n;}
    break;

  case 163:
    {yyval.n = yyvsp[0].n;}
    break;

  case 164:
    {yyval.n = yyvsp[0].n;}
    break;

  case 165:
    {yyval.n = finsta(yyvsp[-1].n);line_off *= -1;}
    break;

  case 166:
    {yyval.n = ptsta(yyvsp[-1].c);yylistfn();line_off++;}
    break;

  case 167:
    {yylistfn();}
    break;

  case 168:
    {yyval.n = ptsta(yyvsp[-1].c);
                                                 line_off++;yylistfn();}
    break;

  case 169:
    {yyval.n = addstanl(yyvsp[-1].n);yylistfn();}
    break;

  case 170:
    {yyval.n = addsta(yyvsp[-1].n, yyvsp[0].c);}
    break;

  case 171:
    {yyval.n = fin_na(yyvsp[-1].n);line_off *= -1;}
    break;

  case 172:
    {yyval.n = pt_na(yyvsp[-1].n);yylistfn();line_off++;}
    break;

  case 173:
    {yylistfn();}
    break;

  case 174:
    {yyval.n = pt_na(yyvsp[-1].n); 
                                                        line_off++;yylistfn();}
    break;

  case 175:
    {yyval.n = add_nanl(yyvsp[-1].n);yylistfn();}
    break;

  case 176:
    {yyval.n = add_na(yyvsp[-1].n, yyvsp[0].n);}
    break;

  case 177:
    {yyval.n = fin_expa(yyvsp[-1].n);line_off *= -1;}
    break;

  case 178:
    {yyval.n = pt_expa(yyvsp[-1].n);yylistfn();line_off++;}
    break;

  case 179:
    {yylistfn();}
    break;

  case 180:
    {yyval.n = pt_expa(yyvsp[-1].n); 
                                                     line_off++;yylistfn();}
    break;

  case 181:
    {yyval.n = add_expanl(yyvsp[-1].n);yylistfn();}
    break;

  case 182:
    {yyval.n = add_expa(yyvsp[-1].n, yyvsp[0].n);}
    break;

  case 183:
    {yyval.n = ptvec(yyvsp[0].n, BCON, APLC_BOOL);}
    break;

  case 184:
    {yyval.n = ptvec(yyvsp[0].n, ICON, APLC_INT);}
    break;

  case 185:
    {yyval.n = ptvec(yyvsp[0].n, RCON, APLC_REAL);}
    break;

  case 186:
    {yyval.n = ptvec(yyvsp[0].n, ZCON, APLC_COMPLEX);}
    break;

  case 187:
    {yyval.n = ptvec(yyvsp[0].n, QCON, APLC_QUAT);}
    break;

  case 188:
    {yyval.n = ptvec(yyvsp[0].n, OCON, APLC_OCT);}
    break;

  case 189:
    {yyval.n = ptvec(yyvsp[0].n, LCON, APLC_INT);}
    break;

  case 190:
    {yyval.n = ptval(BCON, addicon(yyvsp[0].i));}
    break;

  case 191:
    {addicon(yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 192:
    {yyval.n = ptval(ICON, addicon(yyvsp[0].i));}
    break;

  case 193:
    {addicon(yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 194:
    {addicon(yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 195:
    {addicon(yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 196:
    {yyval.n = ptval(RCON, addrcon(yyvsp[0].d));}
    break;

  case 197:
    {expanivec(yyvsp[-1].n, yyvsp[0].d); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 198:
    {expanivec(yyvsp[-1].n, yyvsp[0].d); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 199:
    {addrcon(yyvsp[0].d); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 200:
    {addrcon((double) yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 201:
    {addrcon((double) yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 202:
    {yyval.n = ptval(ZCON, addzcon(yyvsp[0].z));}
    break;

  case 203:
    {ivec2rvec(yyvsp[-1].n);expanrvec(yyvsp[-1].n, yyvsp[0].z); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 204:
    {ivec2rvec(yyvsp[-1].n);expanrvec(yyvsp[-1].n, yyvsp[0].z); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 205:
    {expanrvec(yyvsp[-1].n, yyvsp[0].z); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 206:
    {addzcon(yyvsp[0].z); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 207:
    {addr2zcon(yyvsp[0].d); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 208:
    {addr2zcon((double) yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 209:
    {addr2zcon((double) yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 210:
    {yyval.n = ptval(QCON, addqcon(yyvsp[0].q));}
    break;

  case 211:
    {zvec2qvec(rvec2zvec(ivec2rvec(yyvsp[-1].n))); addqcon(yyvsp[0].q); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 212:
    {zvec2qvec(rvec2zvec(ivec2rvec(yyvsp[-1].n))); addqcon(yyvsp[0].q); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 213:
    {zvec2qvec(rvec2zvec(yyvsp[-1].n)); addqcon(yyvsp[0].q); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 214:
    {zvec2qvec(yyvsp[-1].n); addqcon(yyvsp[0].q); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 215:
    {addqcon(yyvsp[0].q); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 216:
    {addz2qcon(yyvsp[0].z); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 217:
    {addr2qcon(yyvsp[0].d); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 218:
    {addr2qcon((double)yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 219:
    {addr2qcon((double)yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 220:
    {yyval.n = ptval(OCON, addocon(yyvsp[0].oct));}
    break;

  case 221:
    {qvec2ovec(zvec2qvec(rvec2zvec(ivec2rvec(yyvsp[-1].n)))); addocon(yyvsp[0].oct); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 222:
    {qvec2ovec(zvec2qvec(rvec2zvec(ivec2rvec(yyvsp[-1].n)))); addocon(yyvsp[0].oct); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 223:
    {qvec2ovec(zvec2qvec(rvec2zvec(yyvsp[-1].n))); addocon(yyvsp[0].oct); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 224:
    {qvec2ovec(zvec2qvec(yyvsp[-1].n)); addocon(yyvsp[0].oct); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 225:
    {qvec2ovec(yyvsp[-1].n); addocon(yyvsp[0].oct); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 226:
    {addocon(yyvsp[0].oct); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 227:
    {addq2ocon(yyvsp[0].q); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 228:
    {addz2ocon(yyvsp[0].z); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 229:
    {addr2ocon(yyvsp[0].d); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 230:
    {addr2ocon((double)yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 231:
    {addr2ocon((double)yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 232:
    {yyval.n = ptval(LCON, addlcon(yyvsp[0].c));}
    break;

  case 233:
    {addlcon(yyvsp[0].c); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 234:
    {yyval.c = ((struct symnode *) yyval.c)->name;}
    break;

  case 235:
    {yyval.c = yyvsp[0].c;}
    break;

  case 236:
    {yyval.n = ptsemi(NILP, yyvsp[0].n);}
    break;

  case 237:
    {yyval.n = ptsemi(yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 238:
    {yyval.n = newnode(EMPTSEMI);}
    break;

  case 239:
    {yyval.n = yyvsp[0].n;}
    break;


    }

/* Line 1016 of /usr/local/share/bison/yacc.c.  */
#line 2953 "y.tab.c"

  yyvsp -= yylen;
  yyssp -= yylen;


#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("parse error, unexpected ") + 1;
	  yysize += yystrlen (yytname[yytype]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "parse error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("parse error");
    }
  goto yyerrlab1;


/*----------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action.  |
`----------------------------------------------------*/
yyerrlab1:
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* Return failure if at end of input.  */
      if (yychar == YYEOF)
        {
	  /* Pop the error token.  */
          YYPOPSTACK;
	  /* Pop the rest of the stack.  */
	  while (yyssp > yyss)
	    {
	      YYDPRINTF ((stderr, "Error: popping "));
	      YYDSYMPRINT ((stderr,
			    yystos[*yyssp],
			    *yyvsp));
	      YYDPRINTF ((stderr, "\n"));
	      yydestruct (yystos[*yyssp], *yyvsp);
	      YYPOPSTACK;
	    }
	  YYABORT;
        }

      YYDPRINTF ((stderr, "Discarding token %d (%s).\n",
		  yychar, yytname[yychar1]));
      yydestruct (yychar1, yylval);
      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */

  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDPRINTF ((stderr, "Error: popping "));
      YYDSYMPRINT ((stderr,
		    yystos[*yyssp], *yyvsp));
      YYDPRINTF ((stderr, "\n"));

      yydestruct (yystos[yystate], *yyvsp);
      yyvsp--;
      yystate = *--yyssp;


#if YYDEBUG
      if (yydebug)
	{
	  short *yyssp1 = yyss - 1;
	  YYFPRINTF (stderr, "Error: state stack now");
	  while (yyssp1 != yyssp)
	    YYFPRINTF (stderr, " %d", *++yyssp1);
	  YYFPRINTF (stderr, "\n");
	}
#endif
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;


  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}




 /*


    |  sublist          {$$ = ptsmtolink();}

    |  term SM axis expression  {$$ = pt2a(LINK, , LASTAXIS, 
				 pt1(COLLECT,), pt1(COLLECT,));}

		*/
/* --------------------------------- */
/* included code from apl.y */

/* sws  changed to allow use under msdos file name restrictions
 include "lex.yy.c"
*/
#include "lex_yy.c"

#include "aplparse.c"

/* --------------------------------- */
/* end of apl.y */

