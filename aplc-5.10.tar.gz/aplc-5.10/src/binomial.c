/* binomial.c

   extra run time functions for binomial 
   binomial function, including various negative integer cases 
   Samuel W.  Sirlin (sws)


 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include "aplc.h"

/* local functions */
static int absi(int y);
static double absr(double y);
static int negint(double y);
static int even(double x);

/* integer case */
extern int
aplc_binomiali(int a, int b)
{
  double x;
  int c, r;

  c = b - a;
  if (a < 0) {
    if (b < 0) {
      if (c < 0)
	return (0);
      else {
	r = aplc_binomiali(absi(1 + b), absi(1 + a));
	if (0 == c % 2)
	  return (r);
	else
	  return (-r);
      }
    }
    /* b > 0 */
    else {
      if (c < 0)
	return (0);		     /* can't happen */
      else
	return (0);
    }
  }
  /* a > 0 */
  else {
    if (b < 0) {
      if (c < 0) {
	r = aplc_binomiali(a, absi(a - b - 1));
	if (0 == a % 2)
	  return (r);
	else
	  return (-r);
      } else
	aplc_error("[aplc_binomial] domain error");
      return (0);		     /* lint stuffing */
    }
    /* b > 0 */
    else {
      if (c < 0)
	return (0);
      else {
	for (x = 1; c > 0; c--, b--) {
	  x = b * (x / c);
	}
	return ((int) (x + 0.5));
      }
    }
  }
}

static int 
absi(int y)
{
  if (y < 0)
    return (-y);
  else
    return (y);
}

/* real case */
extern double
aplc_binomialr(double a, double b)
{
  double c, r;

  c = b - a;
/* printf("\na %g, b %g, c %g\n",a,b,c);*/

  if (negint(a)) {
    if (negint(b)) {
      if (negint(c))
	return (0.0);
      else {
	r = aplc_binomialr(absr(1 + b), absr(1 + a));
	if (even(c))
	  return (r);
	else
	  return (-r);
      }
    }
    /* b > 0 */
    else {
      if (negint(c))
	return (0.0);		     /* can't happen */
      else
	return (0.0);
    }
  }
  /* a > 0 */
  else {
    if (negint(b)) {
      if (negint(c)) {
	r = aplc_binomialr(a, absr(a - b - 1));
	if (even(a))
	  return (r);
	else
	  return (-r);
      } else
	aplc_error("[aplc_binomial] domain error");
      return (0.0);		     /* lint stuffing */
    }
    /* b > 0 */
    else {
      if (negint(c))
	return (0.0);
      else {
	return (aplc_gamma(1.0 + b) / (aplc_gamma(1.0 + c) * aplc_gamma(1.0 + a)));
      }
    }
  }
}


static double 
absr(double y)
{
  if (y < 0)
    return (-y);
  else
    return (y);
}

/* check if y is a negative integer */
static int 
negint(double y)
{
  double eps = 2.22e-16;
  double x;

  if (y > -0.5)
    return (0);
  else {
    x = ((int) y) - y;
    if (absr(x) < eps)
      return (1);
    else
      return (0);
  }
}

static int 
even(double x)
{
  double eps = 2.22e-16;
  double r;

  r = x - 2.0 * ((int) (x / 2));
  if (eps > absr(r))
    return (1);
  else
    return (0);
}

/* end of binomial.c */ 
