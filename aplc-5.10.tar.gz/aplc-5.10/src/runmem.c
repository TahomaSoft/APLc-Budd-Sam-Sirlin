/*
	APL Compiler
	
	Run time routines - Memory Allocation / TRS manipulation
	tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

/* to get buffersize: */
#include "run.h"

#define NILTRS  (struct trs_struct *) 0

/* turn on for vectalloc prints */
#define VDEBUG 0

/* some globals */
/*  integer vector 1, scalar one shape */
int aplc_ivone[1] = {1};
/* integer zero - vector for shape */
int aplc_ivzero[1] = {0};

/* declare global trs for null args of fns */
trs_t aplc_nulltrs = {0,0,(int *)0,0,0};

/* local function declarations */
/*static void aplc_link_scalar(struct trs_struct *res);*/

#if VDEBUG 
/* type strings    - must match type list in aplc.h */
static char *types[] = { "unknown type", 
			 "bit", "bool", "label", "int",
			 "real", "complex", "quaternion", "octonion",
			 "char", "boxed",
			 "any" };
/* sws  string representation of type */
extern char *str_type_name(int type);

extern char *
str_type_name(int type)
{
  return(types[type]);
}
#endif /* #if VDEBUG  */

/* null fn for dummy operator arguments */
extern int 
aplc_nullf(struct trs_struct *r, struct trs_struct *a, 
	   struct trs_struct *b)
{ return 0;}


/* assign - assign a trs structure to an identifier 
            note this 
	    copies type, rank
	    does not copy shape or value, but just assigns pointers  */
extern void
aplc_assign(struct trs_struct * id, struct trs_struct * trs)
{
  id->type = trs->type;
  id->rank = trs->rank;
  id->shape = trs->shape;
  id->size = trs->size;
  id->alloc_ind = trs->alloc_ind;
  id->scalar = trs->scalar;
  if (id->alloc_ind & APLC_ALLOC_NF) {
    /* scalar */
    aplc_link_scalar(id);
  } else
    id->value = trs->value;

  /* now we don't want 2 freeable trs 
     - turn original off */
  if (trs->alloc_ind & APLC_ALLOC_SHAPE_F)
    trs->alloc_ind ^= APLC_ALLOC_SHAPE_F;
  if (trs->alloc_ind & APLC_ALLOC_VAL_F) 
    trs->alloc_ind ^= APLC_ALLOC_VAL_F;

  return;
}

/*  equate values, with some type checking and changing.
    can't just increase storage of id here - this
    must be done more carefully
*/
/* sws ...
   assign_ind - assign part of a trs structure to part of an identifier
                id[idi]= trs[trsi]
*/
extern void
aplc_assign_ind(struct trs_struct * id, int idi, 
		struct trs_struct * trs, int trsi)
{
  int itype, ttype;

  /* assume id is of rank >0 check rank of trs, treat scalar
     seperately check types
  */
  itype = id->type;
  ttype = trs->type;

  if (trs->rank == 0) {
    /* scalar right term - ignore index */
    switch (itype) {
    case APLC_CHAR:
      if (ttype != APLC_CHAR) {
	aplc_error("[aplc_assign_ind] impossible conversion to APLC_CHAR");
	break;
      } else {
	id->value.cp[idi] = *(trs->value.cp);
	break;
      }
    case APLC_BOOL:
    case APLC_INT:
      if (ttype != APLC_INT) {
	aplc_error("[aplc_assign_ind] impossible conversion to APLC_INT");
	break;
      } else {
	id->value.ip[idi] = *(trs->value.ip);
	break;
      }
    case APLC_REAL:
      if (ttype == APLC_INT) {
	id->value.rp[idi] = *(trs->value.ip);
	break;
      } else if (ttype == APLC_REAL) {
	id->value.rp[idi] = *(trs->value.rp);
	break;
      } else {
	aplc_error("[aplc_assign_ind] impossible conversion to REAL");
	break;
      }
    default:
      fprintf(aplcerr, "type %d\n", itype);
      aplc_error("[aplc_assign_ind] impossible type");
    }
  } else {
    /* expected case, right index necessary */
    switch (itype) {
    case APLC_CHAR:
      if (ttype != APLC_CHAR) {
	aplc_error("[aplc_assign_ind] impossible conversion to APLC_CHAR");
	break;
      } else {
	id->value.cp[idi] = trs->value.cp[trsi];
	break;
      }
    case APLC_BOOL:
    case APLC_INT:
      if (ttype != APLC_INT) {
	aplc_error("[aplc_assign_ind] impossible conversion to APLC_INT");
	break;
      } else {
	id->value.ip[idi] = trs->value.ip[trsi];
	break;
      }
    case APLC_REAL:
      if (ttype == APLC_INT) {
	id->value.rp[idi] = trs->value.ip[trsi];
	break;
      } else if (ttype == APLC_REAL) {
	id->value.rp[idi] = trs->value.rp[trsi];
	break;
      } else {
	aplc_error("[aplc_assign_ind] impossible conversion to REAL");
	break;
      }
    default:
      fprintf(aplcerr, "type %d\n", itype);
      aplc_error("[aplc_assign_ind] impossible type");
    }
  }
}

/* sws
   initialize a trs structure - to zilde
   */
extern void
aplc_inittrs(struct trs_struct * trs)
{
  trs->type = APLC_UKTYPE;
  /* scalar 
     trs->rank = 0;
     trs->shape = (int *) 0;*/
  trs->rank = 1;
  trs->shape = aplc_ivzero;
  trs->size = 0; 
  trs->alloc_ind = APLC_UNALLOC;
  trs->value.ip = (int *) 0;
}

/* aplc_mp2res - get a value from storage for a variable 
   - take it from a mp_struct and put it in a res_struct */
extern void
aplc_mp2res(union res_struct * res, union mp_struct * mp, int i, int type)
{
  int j;

  switch (type) {
    case APLC_CHAR:
    res->c = *(mp->cp + i);
    break;
  case APLC_BOOL:
  case APLC_INT:
    res->i = *(mp->ip + i);
    break;
  case APLC_REAL:
    res->r = *(mp->rp + i);
    break;
  case APLC_COMPLEX:
    res->z[0] = mp->zp[0][i];
    res->z[1] = mp->zp[1][i];
    break;
  case APLC_QUAT:
    res->q[0] = mp->qp[0][i];
    res->q[1] = mp->qp[1][i];
    res->q[2] = mp->qp[2][i];
    res->q[3] = mp->qp[3][i];
    break;
  case APLC_OCT:
    for (j=0; j<8; j++)
      res->o[j] = mp->qp[j][i];
    break;
  case APLC_BOXED:
    res->trs = mp->trsp[i];
    break;
  default:
    fprintf(aplcerr, "type %d\n", type);
    aplc_error("[aplc_mp2res] impossible condition");
  }
}

/* setmp - get a value into storage for a variable 
   - take it from a res_struct and put it in a mp_struct 
   - presumably the mp_struct is from a trs */
extern void
aplc_setmp(union res_struct *res, union mp_struct *mp, int i, int type)
{
  int j;

  switch (type) {
    case APLC_CHAR:
    *(mp->cp + i) = res->c;
    break;
  case APLC_BOOL:
  case APLC_INT:
    mp->ip[i] = res->i;
    break;
  case APLC_REAL:
    mp->rp[i] = res->r;
    break;
  case APLC_COMPLEX:
    mp->zp[0][i] = res->z[0];
    mp->zp[1][i] = res->z[1];
    break;
  case APLC_QUAT:
    mp->qp[0][i] = res->q[0];
    mp->qp[1][i] = res->q[1];
    mp->qp[2][i] = res->q[2];
    mp->qp[3][i] = res->q[3];
    break;
  case APLC_OCT:
    for (j=0; j<8; j++)
      mp->op[j][i] = res->o[j];
    break;
  case APLC_BOXED:
    /*mp->trsp[i] = res->trs;*/
    aplc_copytrs(&mp->trsp[i], &res->trs);
    break;
  default:
    fprintf(aplcerr, "type %d\n", type);
    aplc_error("[aplc_setmp] impossible condition");
  }
}

/* setup the value of a trs by linking to a res struct */
extern void
aplc_link_res(trs_t *t, res_t *res)
{
  int i;

  switch(t->type) {
  case APLC_BOOL:
  case APLC_INT:
    t->value.ip = &res->i;
    break;
  case APLC_REAL:
    t->value.rp = &res->r;
    break;
  case APLC_CHAR:
    t->value.cp = &res->c;
    break;
  case APLC_COMPLEX:
    t->value.zp[0] = &res->z[0];
    t->value.zp[1] = &res->z[1];
    break;
  case APLC_QUAT:
    for (i=0; i<4; i++) 
      t->value.qp[i] = &res->q[i];
    break;
  case APLC_OCT:
    for (i=0; i<8; i++) 
      t->value.op[i] = &res->o[i];
    break;
  default:
    aplc_error("[aplc_link_res] scalar error");
    break;
  }
  t->alloc_ind |= APLC_ALLOC_NF;
  return;
}

/* setup the value of a trs by linking to it's scalar part */
extern void
aplc_link_scalar(struct trs_struct *res)
{
  switch(res->type) {
  case APLC_BOOL:
  case APLC_INT:
    res->value.ip = &res->scalar.i;
    break;
  case APLC_REAL:
    res->value.rp = &res->scalar.r;
    break;
  case APLC_CHAR:
    res->value.cp = &res->scalar.c;
    break;
  default:
    aplc_error("[aplc_link_scalar] scalar error");
    break;
  }
  res->alloc_ind |= APLC_ALLOC_NF;
  return;
}

/* sws
   copy an entire trs to another */
extern void
aplc_copytrs(struct trs_struct *res, struct trs_struct *in)
{
  int i,k;

  /* type, rank, shape */
  aplc_settrs(res, in->type, in->rank, in->shape);

  /* values */
  if (in->alloc_ind & APLC_ALLOC_VAL_S) {
    /* scalar, linked to the values */ 
    res->scalar = in->scalar;
    aplc_link_scalar(res);
    return;
  }

  if (in->size >0) {
    aplc_vectalloc(&res->value, in->size, in->type);
    res->alloc_ind |=  APLC_ALLOC_VAL_F;
  }
  switch (in->type) {
  case APLC_BOXED:
    /* the value is boxed - need to recurse */
    for (i=0; i<in->size; i++)
      aplc_copytrs( &res->value.trsp[i], &in->value.trsp[i] );
    break;
  default: /* flat */
    switch(in->type) {
    default:
    case APLC_UNDEF:
    case APLC_UKTYPE:
    case APLC_BOXED:
      fprintf(stderr,"(type %d)\n", in->type);
      in->type = 1; 
      aplc_error("[aplc_copytrs] impossible case");
      break;
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<in->size; i++)
	res->value.ip[i] = in->value.ip[i];  
      break;
    case APLC_REAL:
      for (i=0; i<in->size; i++)
	res->value.rp[i] = in->value.rp[i];  
      break;
    case APLC_COMPLEX:
      for (i=0; i<in->size; i++)
	for (k=0; k<2; k++)
	  res->value.zp[k][i] = in->value.zp[k][i];
      break;
    case APLC_QUAT:
      for (i=0; i<in->size; i++)
	for (k=0; k<4; k++)
	  res->value.qp[k][i] = in->value.qp[k][i];
      break;
    case APLC_OCT:
      for (i=0; i<in->size; i++)
	for (k=0; k<8; k++)
	  res->value.op[k][i] = in->value.op[k][i];
      break;
    case APLC_CHAR:
      for (i=0; i<in->size; i++)
	res->value.cp[i] = in->value.cp[i];  
      break;
    }
    break;
  }
  return;
}

/* sws
   copy an entire trs to another
   - value still points to the original */
extern void
aplc_duptrs(struct trs_struct *res, struct trs_struct *in)
{
  /* type, rank, shape */
  aplc_settrs(res, in->type, in->rank, in->shape);

  if (in->alloc_ind & APLC_ALLOC_VAL_S) {
    res->scalar = in->scalar;
    aplc_link_scalar(res);
  }
  res->value = in->value;
  return;
}

/* copy a (single) trs value to another trs 
   res(i) = inp(j) */
extern void
aplc_cptrsval(struct trs_struct *res, int i, 
	      struct trs_struct *inp, int j) 
{
  int k;

  /* assume the same type for now... */
  switch(res->type) {
  case APLC_CHAR:
    if (inp->type == APLC_CHAR)
      res->value.cp[i] = inp->value.cp[j];
    else {
      fprintf(aplcerr," char vs %d\n", inp->type);
      aplc_error("[aplc_cptrsval] char type error");
    }
    break;

  case APLC_BOOL:
  case APLC_INT:
    if ( (inp->type == APLC_INT) ||
	 (inp->type == APLC_BOOL) )
      res->value.ip[i] = inp->value.ip[j];
    else
      aplc_error("[aplc_cptrsval] int type error");
    break;

  case APLC_REAL:
    if ( (inp->type == APLC_INT) ||
	 (inp->type == APLC_BOOL) )
      res->value.rp[i] = (double) inp->value.ip[j];
    else if (inp->type == APLC_REAL)
      res->value.rp[i] = inp->value.rp[j];
    else {
      aplc_error("[aplc_cptrsval] real type error");
    }
    break;

  case APLC_COMPLEX:
    switch(inp->type) {
    default:
      aplc_error("[aplc_cptrsval] complex type error");
      break;
    case APLC_BOOL:
    case APLC_INT:
      res->value.zp[0][i] = (double) inp->value.ip[j];
      res->value.zp[1][i] = 0;
      break;
    case APLC_REAL:
      res->value.zp[0][i] = inp->value.rp[j];
      res->value.zp[1][i] = 0;
      break;
    case APLC_COMPLEX:
      for (k=0; k<2; k++)
	res->value.zp[k][i] = inp->value.zp[k][j];
      break;
    }
    break;

  case APLC_QUAT:
    switch(inp->type) {
    default:
      aplc_error("[aplc_cptrsval] quat type error");
      break;
    case APLC_BOOL:
    case APLC_INT:
      res->value.qp[0][i] = (double) inp->value.ip[j];
      for (k=1; k<4; k++)
	res->value.qp[k][i] = 0;
      break;
    case APLC_REAL:
      res->value.qp[0][i] = inp->value.rp[j];
      for (k=1; k<4; k++)
	res->value.qp[k][i] = 0;
      break;
    case APLC_COMPLEX:
      for (k=0; k<2; k++)
	res->value.qp[k][i] = inp->value.qp[k][j];
      for (k=2; k<4; k++)
	res->value.qp[k][i] = 0;
      break;
    case APLC_QUAT:
      for (k=0; k<4; k++)
	res->value.qp[k][i] = inp->value.qp[k][j];
      break;
    }
    break;

  case APLC_OCT:
    switch(inp->type) {
    default:
      aplc_error("[aplc_cptrsval] oct type error");
      break;
    case APLC_BOOL:
    case APLC_INT:
      res->value.op[0][i] = (double) inp->value.ip[j];
      for (k=1; k<8; k++)
	res->value.op[k][i] = 0;
      break;
    case APLC_REAL:
      res->value.op[0][i] = inp->value.rp[j];
      for (k=1; k<8; k++)
	res->value.op[k][i] = 0;
      break;
    case APLC_COMPLEX:
      for (k=0; k<2; k++)
	res->value.op[k][i] = inp->value.qp[k][j];
      for (k=2; k<8; k++)
	res->value.op[k][i] = 0;
      break;
    case APLC_QUAT:
      for (k=0; k<4; k++)
	res->value.op[k][i] = inp->value.qp[k][j];
      for (k=4; k<8; k++)
	res->value.op[k][i] = 0;
      break;
    case APLC_OCT:
      for (k=0; k<8; k++)
	res->value.op[k][i] = inp->value.op[k][j];
      break;
    }
    break;

  case APLC_BOXED:
    if (inp->type == APLC_BOXED)
      aplc_copytrs(&res->value.trsp[i], &inp->value.trsp[j]);
    else
      aplc_error("[aplc_cptrsval] boxed type error");
    break;

  default:
    fprintf(aplcerr, "res type %d\n", res->type);
    aplc_error("[aplc_cptrsval] unknown res type");
  }
  return;
}

/* 
   copy a res value to a trs 
   trs(i) = res
*/
extern void
aplc_cpres2trs(struct trs_struct *res, int i, union res_struct *inp)
{
  int k;

  /* assume the same type for now... */
  switch(res->type) {
  case APLC_CHAR:
    res->value.cp[i] = inp->c;
    break;
  case APLC_BOOL:
  case APLC_INT:
    res->value.ip[i] = inp->i;
    break;
  case APLC_REAL:
    res->value.rp[i] = inp->r;
    break;
  case APLC_COMPLEX:
    for (k=0; k<2; k++)
      res->value.zp[k][i] = inp->z[k];
    break;
  case APLC_QUAT:
    for (k=0; k<4; k++)
      res->value.qp[k][i] = inp->q[k];
    break;
  case APLC_OCT:
    for (k=0; k<8; k++)
      res->value.op[k][i] = inp->o[k];
    break;
  case APLC_BOXED:
    aplc_copytrs(&res->value.trsp[i], &inp->trs);
    break;
  default:
    fprintf(aplcerr, "type %d\n", res->type);
    aplc_error("[aplc_cpres2trs] impossible condition");
  }
}


/* sws 
   aplc_settrs - set type, rank, and shape values into a trs structure 

   - note that shape is now copied (sws) rather than setting a pointer 
     so we can memfree (or not) the original source and can later 
     free the trs
   - calculate size  
   - assume this is followed by something like talloc, which allocates
     space for values */
extern void
aplc_settrs_debug(struct trs_struct *trs, 
		  int type, int rank, int *shape,
		  char *file, int line)
{
#if VDEBUG
  printf("[settrs] %s, line %d, type %d, rank %d\n", 
	 file, line, type, rank);
#endif
  aplc_settrs_simple(trs, type, rank, shape);
  return;
}

extern void
aplc_settrs_simple(struct trs_struct * trs, 
		   int type, int rank, int *shape)
{
  int i;
  union mp_struct mptmp;

  trs->type = type;
  trs->alloc_ind = APLC_UNALLOC;
  if ( (type == APLC_UNDEF) || 
       (type == APLC_UKTYPE) ) {
    /* ignore request if type doesn't make sense */
    trs->rank = 1;
    trs->shape = aplc_ivzero;
    trs->size = 0;
    return;
  }
  trs->rank = rank;
  if (rank > 0) {
    if ( (rank == 1) && (shape[0] == 0) ) {
      /* zilde - don't allocate, use static 0 */
      trs->shape = aplc_ivzero;
    } else {
      aplc_vectalloc(&mptmp, rank, APLC_INT);
      trs->shape = mptmp.ip;
      for (i=0; i<rank; i++)
	trs->shape[i] = shape[i];
      trs->alloc_ind |= APLC_ALLOC_SHAPE_F;
    }
  } else {
    /* rank is zero, must be scalar, put shape=1 anyway */
    trs->shape = aplc_ivone;
  }
  /* compute the size */
  trs->size = aplc_vsize(trs->rank, trs->shape);
  return;
}

/* 
   aplc_talloc - allocate storage for values in a trs structure 

   - assume that the rank and shape have been set already
   - assume the size has been determined already
   - return the size 
*/
extern int
aplc_talloc_debug(struct trs_struct *trs, char *file, int line)
{
#if VDEBUG
  printf("[talloc] %s, line %d, type %d, size %d\n", 
	 file, line, trs->type, trs->size);
#endif
  aplc_talloc_simple(trs);
  return (trs->size);
}

extern int
aplc_talloc_simple(struct trs_struct *trs)
{
  /* ignores 0 size requests */
  if (trs->size <1)
    return 0;
  aplc_vectalloc(&trs->value, trs->size, trs->type);
  trs->alloc_ind |= APLC_ALLOC_VAL_F;
  return (trs->size);
}

extern void
aplc_free_debug(void *x, char *file, int line)
{
#if VDEBUG
  /*fprintf(stderr, "[free] %s, line %d, %p\n", file, line, x);*/
  printf("[free] %s, line %d, %p\n", file, line, x);
#endif
#if APLC_MTC
  fprintf(stderr, "[aplc_free_debug] %s, line %d, %p\n", file, line, x);
#endif
  free(x);
  return;
}

#if 1
/* probably don't need */
extern void
aplc_free_simple(void *x)
{
#if VDEBUG
  /*fprintf(stderr, "[free] %p\n", x);*/
  printf("[free simple] %p\n", x);
#endif
  free(x);
  return;
}
#endif /* 1 */

/* sws 
   vectalloc - allocate a vector - main memory allocation interface 

   complex: stored as [r i], so 
   zp[0] points to the whole, 
   zp[1] points to the second half
*/
extern void
aplc_vectalloc_debug(union mp_struct * mp, int size, int type,
		     char *file, int line)
{
  void *c = NULL;
  int j; 
  int tsize = 0;

#if VDEBUG
  /*fprintf(stderr,
    "[vallocd] %16s, line %5d, request for size %4d, type %d, ", 
    file, line, size,type);*/
  /*printf("[vallocd] %16s, line %5d, request for size %4d, type %d, ", 
    file, line, size,type);*/
  printf("[vallocd] %16s, line %5d, request for size %4d, type %s, ", 
	 file, line, size, str_type_name(type));
#endif

  /*aplc_vectalloc_simple(mp, size, type);*/

  /* quietly ignore requests for no space! */
  /* sws  changed to always give space for 1 */
  if (size <= 0) {
    if (size < 0) {
      fprintf(aplcerr,"size < 0, forcing crash\n");
      fprintf(NULL,"x");/* force crash so we can stop */
    }
    size = 1;
  }

  switch (type) {
  case APLC_BOXED:
    /* allocate all the pointers */
    tsize = size*sizeof(struct trs_struct);
    c = (void *) APLC_MALLOC(tsize);
    mp->trsp = (struct trs_struct *)c;
    break;

  case APLC_CHAR:
    tsize = size*sizeof(char);
    c = APLC_MALLOC(tsize);
    mp->cp = (char *) c;
    break;

  case APLC_BOOL:
  case APLC_INT:
    /* c = (void *)(mp->ip = APLC_IMALLOC(size));*/
    tsize = size*sizeof(int);
    c = APLC_MALLOC(tsize);
    mp->ip = (int *) c;
    break;

  case APLC_REAL:
    /* c = (void *) (mp->rp = APLC_DMALLOC(size));*/
    tsize = size*sizeof(double);
    c = APLC_MALLOC(tsize);
    mp->rp = (double *) c;
    break;

  case APLC_COMPLEX:
    /* c = (void *) (mp->zp[0] = APLC_DMALLOC(2*size));
       mp->zp[1] = mp->zp[0] + size; */
    tsize = 2*size*sizeof(double);
    c = APLC_MALLOC(tsize);
    mp->zp[0] = (double *) c;
    mp->zp[1] = mp->zp[0]+size;
    break;

  case APLC_QUAT:
    /* c = (void *) (mp->qp[0] = APLC_DMALLOC(4*size));
    mp->qp[1] = mp->qp[0] + size;
    mp->qp[2] = mp->qp[1] + size;
    mp->qp[3] = mp->qp[2] + size;*/
    tsize = 4*size*sizeof(double);
    c = APLC_MALLOC(tsize);
    mp->qp[0] = (double *) c;
    for (j=1; j<4; j++)
      mp->qp[j] = mp->qp[j-1]+size;
    break;

  case APLC_OCT:
    /*c = (void *) (mp->op[0] = APLC_DMALLOC(8*size));*/
    tsize = 8*size*sizeof(double);
    c = APLC_MALLOC(tsize);
    mp->op[0] = (double *) c;
    for (j=1; j<8; j++)
      mp->op[j] = mp->op[j-1] + size;
    break;

  default:
    fprintf(aplcerr, "type %d\n", type);
    aplc_error("[aplc_vectallocd] impossible case");
    break;
  }
  if (c == (void *) 0) {
    fprintf(aplcerr, "request for type %d, size %d\n", type, size);
    aplc_error("[aplc_vectallocd] out of memory allocation space");
  }
#if VDEBUG
  /*fprintf(stderr, " total size %d, %p\n", tsize, c);*/
  printf(" total size %d, %p\n", tsize, c);
#endif
  return;
}

extern void
aplc_vectalloc_simple(union mp_struct * mp, int size, int type)
{
  void *c = (void *) 0;
  int j;

#if VDEBUG
  /*fprintf(stderr,"[vectalloc] request for size %d, type %d\n", size,type);*/
  printf("[vectalloc] request for size %d, type %d\n", size,type);
#endif

  /* error on request for negative space */
  if (size < 0) {
    fprintf(aplcerr, "[vectalloc] request for size %d, type %d\n", size,type);
    aplc_error("[aplc_vectalloc] impossible case");
  }

  /* quietly ignore requests for no space! */
  /* sws  changed to always give space for 1 */
  if (size <= 0) {
#if VDEBUG
    if (size < 0)
      fprintf(NULL,"x");
#endif
    size = 1;
  }

  switch (type) {
  case APLC_BOXED:
    /* allocate all the pointers */
    c = (void *) APLC_MALLOC((size_t) size*sizeof(struct trs_struct));
    mp->trsp = (struct trs_struct *)c;
    break;

  case APLC_CHAR:
    c = APLC_MALLOC(size);
    mp->cp = (char *) c;
    break;

  case APLC_BOOL:
  case APLC_INT:
    c = (void *)(mp->ip = APLC_IMALLOC(size));
    break;

  case APLC_REAL:
    c = (void *) (mp->rp = APLC_DMALLOC(size));
    break;

  case APLC_COMPLEX:
    c = (void *) (mp->zp[0] = APLC_DMALLOC(2*size));
    mp->zp[1] = mp->zp[0] + size;
    break;

  case APLC_QUAT:
    c = (void *) (mp->qp[0] = APLC_DMALLOC(4*size));
    mp->qp[1] = mp->qp[0] + size;
    mp->qp[2] = mp->qp[1] + size;
    mp->qp[3] = mp->qp[2] + size;
    break;

  case APLC_OCT:
    c = (void *) (mp->op[0] = APLC_DMALLOC(8*size));
    for (j=1; j<8; j++)
      mp->op[j] = mp->op[j-1] + size;
    break;

  default:
    fprintf(aplcerr, "type %d\n", type);
    aplc_error("[aplc_vectalloc] impossible case");
    break;
  }
  if (c == (void *) 0) {
    fprintf(aplcerr, "request for type %d, size %d\n", type, size);
    aplc_error("[aplc_vectalloc] out of memory allocation space");
  }
}

/* 
   promote types in a numeric vector 
   - currently only int->real
*/
extern void
aplc_vectpromote(union mp_struct * mp, int size, int type, int newtype )
{
  int i;
  union mp_struct mptemp;

  switch(newtype) {
  default:
  case APLC_CHAR:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    /* error */
    aplc_error("[aplc_vectpromote] illegal types");
    break;
  case APLC_BOOL:
  case APLC_INT:
    /* nothing to do */ 
    break;
  case APLC_REAL:
    switch(type) {
    default:
      /* error */
      aplc_error("[aplc_vectpromote] illegal types");
      break;
    case APLC_BOOL:
    case APLC_INT:
      /* save old stuff */
      mptemp.ip = mp->ip;
      /* re allocate space */
      aplc_vectalloc(mp, size, APLC_REAL);
      /* copy */
      for (i = size - 1; i >= 0; i--)
	mp->rp[i] = (double) mptemp.ip[i];
      /* free */
      aplc_free(mptemp.ip); 
      break;
    }
    break;
  }
  return;
}

#ifdef SUNOS
/* some special alloc routines to meet sparc alignment requirements 
   - assume this is needed for all sunos machines
   - I don't have any experience with, say, sunos on x86 machines
   - assume this won't hurt
*/

void *
aplc_imalloc(int size)
{
  void *i;
  int nsize;
#if MEMDEBUG
  int in;
  double id;
#endif

  /* adjust size - want size*4 divisible by 8 */
  /* nsize = (8/4)*ceil(size*4/8.0);*/
  /* adjust size - want size*4 divisible by 16 */
  nsize = (16/4)*ceil(size*4/16.0);
#if MEMDEBUG
  printf("[aplc_imalloc] size = %d, nsize = %d\n", size, nsize);  
#endif
  /*i = memalign(8, (unsigned) nsize*sizeof(int));*/
  i = memalign(8, (size_t) nsize*sizeof(int));
#if MEMDEBUG
  in = (int) i;
  id = in/8.0;
  printf("[aplc_imalloc] i = %d, i/8 = %g\n", in, id);  
#endif
  return(i);  
}


/* realloc routines that use memalign, to ensure correct allignment 

   - these assume that allocations come in chunks of APLC_IBUFSIZE
     so if the request is for size, the old size was
     size - APLC_IBUFSIZE
     and both old and new are the same type
*/
extern void *
aplc_drealloc(double *ip, int size)
{
  double *newip, *nipt, *ipt;
  char *c;
  int i, oldsize;

  /* create new storage */
  c = (char *) (newip = (double *) APLC_DMALLOC(size));
  if (c == (char *) 0) {
    fprintf(aplcerr, "request for size %d\n", size);
    aplc_error("[aplc_drealloc] out of memory allocation space");
  }
  /* copy old to new */
  oldsize = size - APLC_IBUFSIZE;
  for (i = 0, ipt = ip, nipt = newip; i < oldsize; i++) {
    *nipt++ = *ipt++;
  }

  /* free old stuff */
  aplc_free(ip);

  return (newip);
}

extern void *
aplc_irealloc(int *ip, int size)
{
  int *newip, *nipt, *ipt;
  char *c;
  int i, oldsize;

  /* create new storage */
  c = (char *) (newip = (int *) APLC_IMALLOC(size));
  if (c == (char *) 0) {
    fprintf(aplcerr, "request for size %d\n", size);
    aplc_error("[aplc_irealloc] out of memory allocation space");
  }
  /* copy old to new */
  oldsize = size - APLC_IBUFSIZE;
  for (i = 0, nipt = newip, ipt = ip; i < oldsize; i++) {
    *nipt++ = *ipt++;
  }

  /* free old stuff */
  aplc_free(ip);

  return (newip);
}

#endif /* #ifdef SUNOS */

/* sws
   vectrealloc - reallocate a vector 
   - main memory allocation interface */
extern void
aplc_vectrealloc(union mp_struct * mp, int size, int type)
{
  void *c = (void *) 0;

  switch (type) {
  case APLC_CHAR:
    /*mp->cp = c = realloc(mp->cp, (unsigned) size);*/
    mp->cp = c = realloc(mp->cp, (size_t) size);
    break;

  case APLC_BOOL:
  case APLC_INT:
    /* mp->ip = (int *) (c = APLC_IREALLOC(size));*/
    c = (char *) (mp->ip = (int *) APLC_IREALLOC(size));
    break;

  case APLC_REAL:
    /* mp->rp = (double *) (c = APLC_DREALLOC(size));*/
    c = (char *) (mp->rp = (double *) APLC_DREALLOC(size));
    break;

  default:
    fprintf(aplcerr, "type %d\n", type);
    aplc_error("[aplc_vectrealloc] impossible case");
    break;
  }
  if (c == (char *) 0) {
    fprintf(aplcerr, "request for type %d, size %d\n", type, size);
    aplc_error("[aplc_vectrealloc] out of memory allocation space");
  }
}

/* vsize - compute the size of an object
   - product of the shapes, minimum of 1
 */
extern int
aplc_vsize(int rank, int *shape)
{
  register int size;

  size = 1;
  for (rank--; rank >= 0; rank--)
    size *= *(shape + rank);
  return (size);
}


/* sws */
/* detalloc - unallocate storage in a trs structure
              now free both the value and the shape
              also set the pointer values to 0 so no more freeing 
              can happen  */
extern void
aplc_detalloc(struct trs_struct *trs)
{
  int i,n;

  /* ignore requests to free 
     - nill pointers
     - un allocated 
     - not freeable */
  if ( trs == NILTRS) {
#if VDEBUG 
    printf("[aplc_detalloc] arg is nill\n");
#endif
    return;
  }
#if VDEBUG 
  printf("[aplc_detalloc] type %d, rank %d, size %d, alloc %d\n",
	 trs->type, trs->rank, trs->size, trs->alloc_ind);
  if (trs->alloc_ind < 0) {
    fprintf(aplcerr,"trs->alloc_ind < 0, forcing crash\n");
    fprintf(NULL,"x");/* force crash so we can stop */
  }
#endif

#if 0
  /* test case - do nothing */
  return;
#endif

  /* free the shape */
  if ( trs->shape != NULL) {
    if ( !(trs->alloc_ind & APLC_ALLOC_SHAPE_F) ) {
#if VDEBUG 
      printf("[aplc_detalloc] shape is not freeable %d\n", 
	     trs->alloc_ind);
#endif
    } else {
      /* normal vector or array case */
      aplc_free(trs->shape);
      trs->rank = 0;
      trs->shape = (int *) 0;
      trs->alloc_ind ^= APLC_ALLOC_SHAPE_F;
    }
  }

  /* now free the values */
  if ( !(trs->alloc_ind & APLC_ALLOC_VAL_F) ) { 
#if VDEBUG 
    printf("[aplc_detalloc] value is  not freeable %d\n", trs->alloc_ind);
#endif
    return;
  }
  /* watch out for 0 size entities */
  /* get size */
  n = trs->size;
  /*if ( n < 1 )
    return; */
  /* printf("\ntype %d\n", trs->type); */
  switch (trs->type) {
  default:
  case APLC_UNDEF:
  case APLC_UKTYPE:
    fprintf(aplcerr, "[aplc_detalloc] unknown type %d\n", trs->type);
    aplc_error("[aplc_detalloc] impossible case");
    break;
  case APLC_BOOL:
  case APLC_INT:
    aplc_free ( trs->value.ip );
    break;
  case APLC_REAL:
    aplc_free ( trs->value.rp );
    break;
  case APLC_COMPLEX:
    aplc_free ( trs->value.zp[0] ); 
    break;
  case APLC_QUAT:
    aplc_free ( trs->value.qp[0] ); 
    break;
  case APLC_OCT:
    aplc_free ( trs->value.op[0] ); 
    break;
  case APLC_CHAR:
    aplc_free( trs->value.cp );
    break;
  case APLC_BOXED:
    /* recursive */
    for (i=0; i<n; i++)
      aplc_detalloc( &trs->value.trsp[i] );
    aplc_free( trs->value.trsp ); 
    /*fprintf(aplcerr, "[aplc_detalloc] free boxed values?\n");*/
    break;
  }
  /* now re-initialize */
  trs->type = APLC_UKTYPE;
  trs->value.ip = (int *) 0;
  trs->alloc_ind ^= APLC_ALLOC_VAL_F;
  return;
}

/* just free the shape of a trs
   - be careful of stuff */
extern void
aplc_free_shape(struct trs_struct * trs)
{
  if (trs == NILTRS) {
    /* printf("[aplc_free_shape] trs is nill\n"); */
    return;
  }
  if (!(trs->alloc_ind & APLC_ALLOC_SHAPE_F)) {
    /* printf("[aplc_detalloc] arg is not freeable\n"); */
    return;
  }
  /* free the shape */
  aplc_free(trs->shape);
  trs->rank = 0;
  trs->shape = (int *) 0;
  return;
}

/* cpvec - copy an integer vector */
extern void
aplc_cpvec(register int *to, int size, register int *from)
{
  for (; size; size--)
    *to++ = *from++;
}

/* cpwo - copy an integer vector without a specific element */
extern void
aplc_cpwo(register int *to, int wo, int size, register int *from)
{
  int i;

  /* fix due to jbww UKC 6/87 */
  for (i = 0; i < size; i++) {
    if (i != wo)
      *to++ = *from;
    from++;
  }
}

/* sws
   cp2str - copy a char vector to a string */
extern void
aplc_cp2str(char *s, struct trs_struct *trs) 
{
  int i, n;
  char *v;

  switch (trs->type) {
  case APLC_CHAR:
    /* n = aplc_vsize(trs->rank, trs->shape);*/
    n = trs->size;
    /*printf("size %d", n);*/
    v = (trs->value).cp;
    for (i=0; i<n; i++)
      s[i] = *v++;
    s[i] = '\0';
    /*printf(" [%s]\n", s);*/
    break;

  default:
    /* error */
    aplc_error("[aplc_cp2str] input not character data");
    break;
  }
}

/* esubi - return the i'th element in the expansion vector */
extern int
aplc_esubi(int i, int rank, int *shape)
{
  register int val;

  val = 1;
  for (rank--; rank > i; rank--)
    val *= *(shape + rank);
  return (val);
}

#if APLC_MTC
/* sws
   malloc test cases */
void *
aplc_malloc(size_t size, char *fn, int ln)
{
  fprintf(stderr,"[aplc_malloc] %s, line %d,  %ld\n",fn,ln,size);
  return malloc(size);
}

void *
aplc_realloc(void *ptr, size_t size, char *fn, int ln)
{
  fprintf(stderr,"[aplc_realloc] %s, line %d,  %ld\n",fn,ln,size);
  return realloc(ptr,size);
}

#endif /* #if APLC_MTC */

/* end of runmem.c */
