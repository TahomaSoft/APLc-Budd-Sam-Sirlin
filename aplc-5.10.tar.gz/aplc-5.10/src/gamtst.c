# include <stdio.h>
# include <math.h>


double aplc_gamma();

void main()
{
double r, x;

x= 2.0;
r= aplc_gamma(x);
printf("gamma(%g) = %g\n",x,r);

x= -1.4;
r= aplc_gamma(x);
printf("gamma(%g) = %g\n",x,r);

x= -1.0;
r= aplc_gamma(x);
printf("gamma(%g) = %g\n",x,r);

x= 0.0;
r= aplc_gamma(x);
printf("gamma(%g) = %g\n",x,r);

x= 1e-30;
r= aplc_gamma(x);
printf("gamma(%g) = %g\n",x,r);

x= 2.0;
r= aplc_gamma(x);
printf("gamma(%g) = %g\n",x,r);

x= 2.2;
r= aplc_gamma(x);
printf("gamma(%g) = %g\n",x,r);

x= 4.0;
r= aplc_gamma(x);
printf("gamma(%g) = %g\n",x,r);

x= 2.0;
r= aplc_gamma(x);
printf("gamma(%g) = %g\n",x,r);
x= 9.6;
r= aplc_gamma(x);
printf("gamma(%g) = %g\n",x,r);
x= 8.6;
r= aplc_gamma(x);
printf("gamma(%g) = %g\n",x,r);


}
