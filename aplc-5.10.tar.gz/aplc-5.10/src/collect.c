/*
	APL Compiler

	Code generation routines having to do with collecting values
	tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.
*/

#include "parse.h"
#include "y_tab.h"
#include "gen.h"
#include <stdio.h>

/* colloop - make a simple collection loop */
void 
colloop(struct node * node, int indexval, int maxval)
{
  if (is_scalar(node)) {
    if (!(node->n.info & NOINDEX))
      setizero(indexval);
    printf("{\n");
  } else {
    /* loop indexval from 0 to maxval */
    iiloop(indexval, maxval);
  }
  return;
}

/*
	genciscalar - generate code for collecting an integer scalar
                      used in index generation
                              deal
                      tollerates vectors of length 1 also

	ptr1 - register for result, if needed
*/
void 
genciscalar(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    if (node->n.info & VALUESKNOWN) {
      node->c.values =
	  gicn(icnst,
	  iconsts[valvalue(node)], APLC_INT);
      return;
    }
    switchbox(RIGHT, SHAPE, 0);
    if (!(RIGHT->n.info & TYPEKNOWN))
      testtype(RIGHT->c.type, APLC_INT);
    if (!(RIGHT->n.info & RANKKNOWN))
      testsingle(RIGHT->c.rank, RIGHT->c.shape);
    if (RIGHT->n.info & HAVEVALUE) {
      /* we're guaranteed a pointer to memory, sort of 
	 - the type may not be known
       */
      if ((RIGHT->n.info & TYPEKNOWN))
	node->c.values = gmon(deref, RIGHT->c.values);
      else {
	/* type is not known - force it */
	if ( ((RIGHT->c.values)->cop == memptr) ||
	     ((RIGHT->c.values)->cop == trsptr) ) {
	  RIGHT->c.values->c2.ctype = APLC_INT;
	  node->c.values = gmon(deref, RIGHT->c.values);
	} else {
	  /* what to do here? can we get here? */
	  fprintf(stderr,"[genciscalar] unexpected condition - continuing\n"); 
	  /* resort to non-havevalue code */
	  if (!(RIGHT->n.info & NOINDEX))
	    setizero(RIGHT->index);
	  switchbox(RIGHT, VALUE, 0);
	  mkrktype(RIGHT, APLC_INT, node->ptr1);
	  node->c.values = RIGHT->c.values;
 	}
      }
    } else {
      if (!(RIGHT->n.info & NOINDEX))
	setizero(RIGHT->index);
      switchbox(RIGHT, VALUE, 0);
      mkrktype(RIGHT, APLC_INT, node->ptr1);
      node->c.values = RIGHT->c.values;
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    /* shouldn't get here */
    break;

  case FINISH:
    if (!(node->n.info & VALUESKNOWN))
      switchbox(RIGHT, FINISH, 0);
    break;
  }
}

/*
	gencscalar - generate code for collecting a scalar

	ptr1 - register for result, if needed
*/
void 
gencscalar(struct node * node, enum pmodes mode, int top)
{
  int type;

  switch (mode) {
  case SHAPE:
    if ( (node->n.info & TYPEKNOWN) && (node->n.type != APLC_ANY) ) {
      type = node->n.type;
      adjdcls(node);
      if (node->n.info & VALUESKNOWN) {
	if ((type == APLC_INT) || (type == APLC_BOOL)) {
	  /* sws  why do this? */
	  node->c.values = gicn(icnst,
				iconsts[valvalue(node)], APLC_INT);
	  return;
	} else {
	  /* value must be something else besides int */
	  node->c.values = gmon(deref, node->c.values);
	  return;
	}
      } else {
	/* values not known - so we must calculate */
	switchbox(RIGHT, SHAPE, 0);
	switchbox(RIGHT, VALUE, 0);
	node->c.values = RIGHT->c.values;
	return;
      }
    }
    /* type not known */ 
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 0, 0);
    if (!(RIGHT->n.info & RANKKNOWN))
      testrank(RIGHT->c.rank, 0);

    if (RIGHT->n.info & HAVEVALUE) {
      /*
	    if ((RIGHT->c.values)->cop == memptr)
		RIGHT->c.values->c2.ctype = APLC_INT;
      */
      node->c.values = 	  gmon(deref, RIGHT->c.values);
    } else {
      if (!(RIGHT->n.info & NOINDEX))
	setizero(RIGHT->index);
      switchbox(RIGHT, VALUE, 0);
      /*
	    mkrktype(RIGHT, APLC_INT, node->ptr1);
      */
      if (!node->n.info & TYPEKNOWN)
	node->ptr1 = resinreg(node, node->ptr1);
      node->c.values = RIGHT->c.values;
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    /* shouldn't get here */
    break;

  case FINISH:
    if (!(node->n.info & VALUESKNOWN))
      switchbox(RIGHT, FINISH, 0);
    break;
  }
}

/*
	gencivec - generate code for collecting values
		used by
		civec - collect integer vector

	ptr1 - size of right
	ptr3 - mp for values (used in loop & changed)
	ptr4 - mp for results (set to same as ptr3 originally)
	ptr5 - result register
	ptr6 - mp for shape
*/
void 
gencivec(struct node * node, enum pmodes mode, int top)
{
  int save;
  struct codetree *savetree;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);

    /* sws redone to accommodate scalar as well as scalar right */
    if (!(node->n.info & SHAPEKNOWN)) {
      if (RIGHT->n.info & RANKKNOWN) {
	if (is_scalar(RIGHT))
	  node->c.shape = gcast(coconst, gicn(icnst, 1, APLC_INT), APLC_INT);
	else
	  copychild(node, RIGHT, 0, 0, 1);
      }else {
	/* use size of right as shape */
	getsize(node->ptr1, RIGHT);
	smpalloc(node->ptr6);
	setmptoi(node->ptr6, node->ptr1);
	node->c.shape = gicn(memptr, node->ptr6, APLC_INT);
	/* below doesn't work since later things expect pointers */
	/* node->c.shape = gicn(coiptr, node->ptr1, APLC_INT); */
      }
    }

    if (!(RIGHT->n.info & TYPEKNOWN))
      testtype(RIGHT->c.type, APLC_INT);

    /* test that rank is less than 2 */
    if (!(RIGHT->n.info & RANKKNOWN)) {
      testmxrank(RIGHT->c.rank, 1);

    }
    if (node->n.info & VALUESKNOWN)
      return;

    /* for a singleton, we can make things easier */
    if ( (is_singleton(RIGHT)) && 
	 (RIGHT->n.info & TYPEKNOWN) &&
	 ( (APLC_INT == rtype(RIGHT)) || (APLC_BOOL == rtype(RIGHT)) ) ) {
      switchbox(RIGHT, VALUE, 0);
      /* can do better if right is already in a res... */ 
      printf("res%d.i = ",node->ptr5);
      ctgen(RIGHT->c.values);
      seminl();
      /* since this node is havevalue, expect 
	 a pointer to the value here */
      /* node->c.values = gicn(resptr, node->ptr5, APLC_INT);*/
      node->c.values = gmon(coref, gicn(resptr, node->ptr5, APLC_INT));
      return;
    }
    /* not known singleton */

    if ((RIGHT->n.info & HAVEVALUE) && (RIGHT->n.info & TYPEKNOWN)) {
      node->c.values = RIGHT->c.values;
    } else {

      if (RIGHT->n.info & RANKKNOWN) {
	/* else this was setup above */
	getsize(node->ptr1, RIGHT);
      }
      savetree = looprank;
      looprank = RIGHT->c.rank;
      /* integers only */
#if VDEBUG
      printf("/* [gencivec] impalloc */\n");
#endif
      impalloc(node->ptr3, node->ptr1);
      mpeqmp(node->ptr4, node->ptr3);
      colloop(RIGHT, RIGHT->index, node->ptr1);
      switchbox(RIGHT, VALUE, 0);
      save = node->index;
      node->index = RIGHT->index;
      node->ptr5 = asntchk(1, node, RIGHT,
			   rtype(node), node->ptr5, node->ptr3);
      node->index = save;
      rbr();
      node->c.values = gicn(memptr, node->ptr4, rtype(node));
      looprank = savetree;
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    if ( (is_singleton(RIGHT)) && 
	 (RIGHT->n.info & TYPEKNOWN) &&
	 ( (APLC_INT == rtype(RIGHT)) || (APLC_BOOL == rtype(RIGHT)) ) ) {
      node->c.values = gmon(deref, node->c.values);
    } else
      leafvalue(node, node->ptr4, APLC_INT, node->ptr5);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    if (node->n.info & VALUESKNOWN)
      break;
    if ( (is_singleton(RIGHT)) && 
	 (RIGHT->n.info & TYPEKNOWN) &&
	 ( (APLC_INT == rtype(RIGHT)) || (APLC_BOOL == rtype(RIGHT)) ) ) 
      break;
#ifdef DEBUGFREE
    printf("/* -- civec finish */\n");
#endif
    if (!( (RIGHT->n.info & HAVEVALUE) && (RIGHT->n.info & TYPEKNOWN)) ) 
      mpfree(node->ptr4);
    if (!(node->n.info & SHAPEKNOWN)) {
      if (!(RIGHT->n.info & RANKKNOWN))
	mpfree(node->ptr6);
    }
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;
  }
}

/*
	gencollect - generate code for collecting values
		used by
		cvec - collect vectors
		collect - collect arbitrary objects

sws   changed to include a trs, to account for collection of unknown types

	ptr2 = size of right hand size
	ptr3 = trs pointer
	ptr4 = result register
	ptr5 = memory pointer for values/results (used in internal loop)
	ptr6 = memory pointer for values/results ( as return value )
*/
void 
gencollect(struct node * node, enum pmodes mode, int top)
{
  int save;
  struct codetree *savetree;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 1, 1);
    if (node->nodetype == CVEC)
      /* test that rank is less than 2 */
      if (!(RIGHT->n.info & RANKKNOWN)) {
	testmxrank(RIGHT->c.rank, 1);
      }
    if (node->n.info & VALUESKNOWN) {
      if ( (rtype(node) == APLC_COMPLEX) ||
	   (rtype(node) == APLC_QUAT) ||
	   (rtype(node) == APLC_OCT) ) {
	node->c.values = RIGHT->c.values;
      } 
#if 0
      printf("/* collect, valuesknown{ ");
      ctgen(node->c.values);
      printf("} right {");
      ctgen(RIGHT->c.values);
      printf("}*/\n");
#endif
      return;
    } else if (RIGHT->n.info & HAVEVALUE)
      node->c.values = RIGHT->c.values;
    else {
      /* general case, need to build a trs  and collect values */
      settrs(node->ptr3, node);

      if (!(node->n.info & TYPEKNOWN))
	node->c.type = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
      if (!(node->n.info & RANKKNOWN))
	node->c.rank = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
      if (!(node->n.info & SHAPEKNOWN))
	node->c.shape = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);

      savetree = looprank;
      looprank = RIGHT->c.rank;

      ieq(node->ptr2);
      printf("aplc_talloc(&trs%d);\n", node->ptr3);
      node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));
      leafshape(node, node->ptr5);
      /* sws  setup possible pointer for return values */
      mpeqmp(node->ptr6, node->ptr5); 

      if (!is_scalar(RIGHT)) {
	getsize(node->ptr2, RIGHT);
      }
      /* setup loop */
      colloop(RIGHT, RIGHT->index, node->ptr2);
      switchbox(RIGHT, VALUE, 0);
      save = node->index;
      node->index = RIGHT->index;
      /* do the assignment in the loop */
      node->ptr4 = asntchk(1, node, RIGHT, rtype(node),
			   node->ptr4, node->ptr5);
      node->index = save;
      /* end the loop */
      rbr();

      /* don't use a trs as value, as it could be changed, and then
         free won't work */
      /* mp to trs is value of node */
      node->c.values = gicn(memptr, node->ptr6, rtype(node));
      looprank = savetree;
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    /* sws   ptr5 is corrupted in collect loop, don't use it */ 
    /* leafvalue(node, node->ptr5, rtype(node), node->ptr4); */
    leafvalue(node, node->ptr6, rtype(node), node->ptr4);
    break;

  case FINISH:
    if (node->n.info & VALUESKNOWN)
      break;
    switchbox(RIGHT, FINISH, 0);
    if (!(RIGHT->n.info & HAVEVALUE)) {
#ifdef DEBUGFREE
      printf("/* -- collect finish */\n");
#endif
      /* sws can't free ptr5, as it's corupted */
      /* mpfree(node->ptr5);*/
      /* assume any stuff needed has been copied out already */
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/*
	genccollect - generate code for collecting values
		      always collects right for localization in fns
sws   

	ptr2 = size of right hand size
	ptr3 = trs pointer
	ptr4 = result register
	ptr5 = memory pointer for values/results (used in internal loop)
	ptr6 = memory pointer for values/results ( as return value )
*/
void 
genccollect(struct node * node, enum pmodes mode, int top)
{
  int save;
  struct codetree *savetree;
  int ntype;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 1, 1);

    /*if ( is_scalar(node) && (node->n.info & TYPEKNOWN) ) {*/
    ntype = rtype(node);
    if ( is_scalar(node) && (node->n.info & TYPEKNOWN) 
	 && (ntype != APLC_BOXED)
	 && (ntype != APLC_COMPLEX)
	 && (ntype != APLC_QUAT) 
	 && (ntype != APLC_OCT) ) {
      /* known scalar case */
      /* trs%d.scalar.x = right value */
      switchbox(RIGHT, VALUE, 0);
      printf("trs%d.type = ", node->ptr3);
      ctgen(node->c.type);
      seminl();
      printf("trs%d.rank = 0;\n", node->ptr3);
      printf("trs%d.size = 1;\n", node->ptr3);
      printf("trs%d.scalar.%s = ", node->ptr3, res_type_str(rtype(node)));
      ctgen(RIGHT->c.values);
      seminl();
      /* for compatibility */
      printf("trs%d.value.%s = &trs%d.scalar.%s;\n", 
	     node->ptr3, mp_type_str(rtype(node)),
	     node->ptr3, res_type_str(rtype(node)) );
      printf("trs%d.alloc_ind = APLC_ALLOC_NF;\n", node->ptr3);
    } else {
      /* general case, need to build a trs  and collect values */
      settrs(node->ptr3, node);

      if (!(node->n.info & TYPEKNOWN))
	node->c.type = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
      if (!(node->n.info & RANKKNOWN))
	node->c.rank = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
      if (!(node->n.info & SHAPEKNOWN))
	node->c.shape = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);

      savetree = looprank;
      looprank = RIGHT->c.rank;

      ieq(node->ptr2);
      printf("aplc_talloc(&trs%d);\n", node->ptr3);
      node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));
      leafshape(node, node->ptr5);
      /* sws  setup possible pointer for return values */
      mpeqmp(node->ptr6, node->ptr5); 

      if (!is_scalar(RIGHT)) {
	getsize(node->ptr2, RIGHT);
      }
      colloop(RIGHT, RIGHT->index, node->ptr2);
      switchbox(RIGHT, VALUE, 0);
      save = node->index;
      node->index = RIGHT->index;
      node->ptr4 = asntchk(1, node, RIGHT, rtype(node),
			   node->ptr4, node->ptr5);
      node->index = save;
      rbr();
      looprank = savetree;
    }
    node->c.values = gicn(memptr, node->ptr6, rtype(node));
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr6, rtype(node), node->ptr4);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    /* don't need to free if scalar - never allocated */
    ntype = rtype(node);
    if ( ! ( is_scalar(node) && (node->n.info & TYPEKNOWN) 
	     && (ntype != APLC_BOXED)
	     && (ntype != APLC_COMPLEX)
	     && (ntype != APLC_QUAT) 
	     && (ntype != APLC_OCT) ) ) {
#ifdef DEBUGFREE
      printf("/* -- ccollect finish */\n");
#endif
      /* assume any stuff needed has been copied out already */
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/*
  genreshape - generate code for reshape (dyadic rho) operator

  ptr1 - size of right hand side
*/
void 
genreshape(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    /* need this always, as left might do something besides get shape,
       e.g. assign */
    switchbox(LEFT, SHAPE, 0);
    if (!(node->n.info & SHAPEKNOWN)) {
      if (!(node->n.info & RANKKNOWN))
	node->c.rank = gmon(deref, LEFT->c.shape);
      node->c.shape = LEFT->c.values;
    }
    switchbox(RIGHT, SHAPE, 0);
    if (!(node->n.info & TYPEKNOWN))
      node->c.type = RIGHT->c.type;
    if ((node->index != RIGHT->index) &&
	(!(RIGHT->n.info & NOINDEX)))
      getsize(node->ptr1, RIGHT);
    break;

  case COMBINE:
    break;

  case VALUE:
    if ((node->index != RIGHT->index) &&
	(!(RIGHT->n.info & NOINDEX)))
      iopi(RIGHT->index, node->index, "%", node->ptr1);
    switchbox(RIGHT, VALUE, 0);
    node->c.values = RIGHT->c.values;
    break;

  case FINISH:
    /* if (!(node->n.info & SHAPEKNOWN))*/
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    break;
  }
}

/* end of collect.c */


