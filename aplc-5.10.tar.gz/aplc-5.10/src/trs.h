/* 
 APL Compiler 

 some inferenceing utilities from trs.c

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _TRS_H
#define _TRS_H

extern void doinf(struct node * node, int top);

extern void init_arb(struct node * node);

extern void remove_type_info(info_t *s);
extern void remove_rank_info(info_t *s);
extern void remove_shape_info(info_t *s);
extern void remove_value_info(info_t *s);
extern void arb_shape_info(info_t *s);

#endif /* _TRS_H */
