/*
	APL Compiler

	Code Generation routines for quad assign
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include <stdio.h>
#include "parse.h"
#include "y_tab.h"
#include "gen.h"


/*
  genqassign - quad assignment (quad output)

  handles:
    case QQUADASSIGN: (not used now)
    case QUADASSIGN:


    This function is used in these cases:
    - top code like 
         # .is ...
    - non-top code like
         a .is # .is ...     
    - normal line echoing, added automatcally, such as
         fn a
	 1+a
	 
    - note that we want to allow for the possibility that 
      a fn won't return a value

    - right can only be:
       fident  - right->ptr3 is result trs
       collect - right->ptr3 is result trs

       format  - right->ptr3 is result trs
       scon

	ptr1 = size of right
	ptr2 = result register
	ptr3 = result trs
	ptr4 = counter for nl's
	ptr5 = right trs

	ptr6 = memory pointer for values/results (used in internal loop)
	ptr7 = trs pointer


*/

#define VER 1


/* working
   trouble with free */
#if 1==VER
void
genqassign(struct node * node, enum pmodes mode, int top)
{
  int save;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    if (!top) {
      /* note that this doesn't copy valuesknown.  the valuesknown
	 stuff doesn't seem to work or to be useful, so maybe should
	 be dropped...  */
      copychild(node, RIGHT, 1, 1, 1);
      node->c.values = RIGHT->c.values;
    }

    /* - we might have a fn with no return value
       - so if its type isn't known, check here */
    if ( (RIGHT->nodetype == FIDENT) &&
	 (!(RIGHT->n.info & TYPEKNOWN)) ) {
      iflp(); printf("APLC_UKTYPE != ");
      ctgen(RIGHT->c.type);rp();
      printf(" {\n");
    }

    /* put in a format if right isn't already a char */
    if ( !(RIGHT->n.info & TYPEKNOWN) ||
	 (rtype(RIGHT) != APLC_CHAR) ) { 
      /* should be fident or collect */
      /* aplc_format(res, right); */
      filtrs(node->ptr5, RIGHT);
      printf("aplc_format(");
      printf("&trs%d, &trs%d", node->ptr3, node->ptr5);
      rpseminl();
    } else {
      filtrs(node->ptr3, RIGHT);      
    }
    /* now for sure node->ptr3 is a string trs to print 
       just need to loop through and print */
    /* now add the print */
    save = node->index;
    node->index = RIGHT->index;

    /* loop over result size */
    ieq(node->ptr1); printf("trs%d.size;\n", node->ptr3);
    iiloop(node->index, node->ptr1);
    printf("fprintf(aplcout,\"%%c\",trs%d.value.cp[i%d]", 
	   node->ptr3, node->index);
    rpseminl();
    printf("for (i%d=aplc_bmpnl(i%d, trs%d.rank, trs%d.shape)", 
	   node->ptr4, node->index, node->ptr3, node->ptr3);
    printf("; i%d>0; i%d--)\n", node->ptr4, node->ptr4);
    printf("fprintf(aplcout,\"\\n\");\n");
    rbr();
    if ( (RIGHT->nodetype == FIDENT) &&
	 (!(RIGHT->n.info & TYPEKNOWN)) ) {
      rbr(); elsebr();
      /* make sure trs to be freed is initialized */
      inittrs(node->ptr3); 
      rbr();
    }
    node->index = save;
    break;

  case COMBINE:
    break;

  case VALUE:
    ieqi( RIGHT->index, node->index);
    switchbox(RIGHT, VALUE, 0);
    node->c.values = RIGHT->c.values;
    printf("/* rv: "); ctgen(RIGHT->c.values); printf("*/\n");
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
#ifdef DEBUGFREE
    printf("/* -- quad assign finish */\n");
#endif
#if 1
    /* needs debugging ... */
    if ( !(RIGHT->n.info & TYPEKNOWN) ||
	 (rtype(RIGHT) != APLC_CHAR) ) { 
      printf("aplc_detalloc(&trs%d);\n", node->ptr5);
    }
    if ( !(node->n.info & ASSIGNP) ) {
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
    }
#endif
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;
  }
  return;
}
#endif

/* old version
   - lazy evaluation printing; not very good 

	ptr2 = result register
	ptr3 = size of right hand size
	ptr4 = result register
	ptr5 = memory pointer for values/results
	ptr6 = memory pointer for values/results (used in internal loop)
	ptr7 = trs pointer

*/
#if 0 == VER
void
genqassign(struct node * node, enum pmodes mode, int top)
{
  int save;
  struct codetree *savetree;
  struct codetree *saveright;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);

    if (!top) {

      /* note that this doesn't copy valuesknown.  the valuesknown
	 stuff doesn't seem to work or to be useful, so maybe should
	 be dropped...  */

      copychild(node, RIGHT, 1, 1, 1);
      node->c.values = RIGHT->c.values;
    }
    save = node->index;
    /* now both */
      /* top case
	 - here we might have a fn with no return value
	 - so if its type isn't known, check here
	 */
      if ( (RIGHT->nodetype == FIDENT) &&
	   (!(RIGHT->n.info & TYPEKNOWN)) ) {
	iflp(); printf("APLC_UKTYPE != ");
	ctgen(RIGHT->c.type);rp();
	printf("{\n");
      }
      
      if (!is_scalar(RIGHT)) {
	getsize(node->ptr3, RIGHT);
      }
      savetree = looprank;
      looprank = RIGHT->c.rank;
      /* start loop for collecting values */ 
      colloop(RIGHT, RIGHT->index, node->ptr3);
      switchbox(RIGHT, VALUE, 0);
      saveright = RIGHT->c.values;
      node->ptr2 = resinreg(RIGHT, node->ptr4);
      printf("aplc_printit(&res%d, ", node->ptr2);
      ctgen(RIGHT->c.type);
      if (is_scalar(RIGHT))
	printf(", 1");
      else {
	printf(", aplc_bmpnl(i%d, ", RIGHT->index);
	rns(RIGHT);
	rp();
      }
      rpseminl();
      rbr();
      if ( (RIGHT->nodetype == FIDENT) &&
	   (!(RIGHT->n.info & TYPEKNOWN)) )
	rbr();
      looprank = savetree;
      /* end of top case */

      RIGHT->c.values = saveright;
      node->index = save;
      node->c.values = RIGHT->c.values;
    break;

  case COMBINE:
    break;

  case VALUE:
    /* this needs debugging once non-top sub assigns allowed */
    /*switchbox(RIGHT, VALUE, 0);*/
    /* RIGHT->index = node->index;*/
    ieqi( RIGHT->index, node->index);
    node->c.values = RIGHT->c.values;
    printf("/* rv: "); ctgen(RIGHT->c.values); printf("*/\n");
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    break;
  }
  return;
}

#endif

/* end */

