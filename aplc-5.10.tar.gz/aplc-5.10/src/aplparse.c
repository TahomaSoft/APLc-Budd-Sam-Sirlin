/*
	APL Compiler

	some routines for the parse stage
	included by apl.y

	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.
*/

#define AYDEBUG 0
#define LISTDEBUG 0

extern void update_info(struct symnode *b,  struct symnode *a);


/* main routine for lexical parsing 
   sws: allow for some command line inputs
  -l  produce a listing aplc.list
  -l name  put listing in file name
*/
int
main(int argc, char **argv) 
{
  int i;
  char *fname;
  char *defname = "aplc.list";

  /* sws */
  fprintf(stderr,"APLc version 5.10  August, 2006 (sws)\n");
  fprintf(stderr,"Starting parse\n");

  fname = defname;
  dolist = 0;
  for (i=0; i<argc; i++) {
    /* fprintf(stderr,"argv[%d] = %s\n", i, argv[i]);*/
    if (argv[i][0] == '-')
      switch (argv[i][1]) {
      default:
	fprintf(stderr,"usage  parse -l or parse -l fname\n");
      case 'l':
	dolist = 1;
	if (argc>++i)
	  fname = argv[i];
	break;
      }
  }
  if (dolist)
    listfile = fopen(fname,"w");
  yyparse();
  if (dolist)
    fclose(listfile);
  if (! errflag)
    exit(0);
  else
    exit(1);
}

/* called on return from lexer */
void
yyret_debug(void)
{
#if AYDEBUG
  fprintf(stderr, "[lex return] ");
  fprintf(stderr, "last tokens: 0:%s, 1:%s, ", 
	  prtoken(last_token[0]), prtoken(last_token[1]));
  yylist_print("RET");  
  fprintf(stderr, "[lret]\n");
#endif
#if LISTDEBUG
  fprintf(listfile, "[lex return] ");
  fprintf(listfile, "last tokens: 0:%s, 1:%s, ", 
	  prtoken(last_token[0]), prtoken(last_token[1]));
  fprintf(listfile, "[lret]\n");
#endif
  return;
}


/* eventually remove this - it prints the lines the lexer sees */
void 
yylistf()
{
  /*
  if (!dolist)
    return;
  fprintf(listfile,"[%3d] %s\n", linenum, linebuf);*/
  ;
  return;
}

void
yylist_debug(char *s)
{
#if LISTDEBUG
  /*fprintf(listfile,"{%s:yytext[%s]}",s, yytext);  */
  fprintf(listfile,"{%s:yytext[%s] %d",s, yytext, yyleng);  
  fprintf(listfile,"(%3d)fm:%d lm:%d, oldbuf{%s}, linebuf{%s} ", 
	  linenum-1, funmode,linemode, oldbuf, linebuf);
  fprintf(listfile,", linesofar{%s}, linepos %d, string_count %d}\n", 
	  linesofar, linepos, string_count);
#if LISTDEBUG > 1
  fprintf(stderr,"{%s:yytext[%s]",s, yytext);  
  fprintf(stderr,"linepos %d,",linepos);  
  fprintf(stderr,"linebuf {%s},",linebuf);  
  fprintf(stderr,"linesofar {%s},",linesofar);  
  fprintf(stderr,"(%3d)fm:%d lm:%d oldbuf{%s} }", 
	  linenum-1, funmode,linemode, oldbuf);
#endif
#endif
  return;
}

void
yylist_print(char *s)
{
#if LISTDEBUG
  fprintf(listfile,"{%s}",s);  
#if LISTDEBUG > 1
  fprintf(stderr,"{%s}",s);  
#endif
#endif
  return;
}


/*

  funmode [0,1,2], for null, main, user fun 
  linemode [0, 1, 2] for (blank, comment), unnumbered, or normal line 

*/
void 
yylistfn(void)
{
  int ln, off;

  if (!dolist)
    return;

  /* the parser is behind the lexer */
  ln = linenum-1;
  /* reset if larger than 1 */
  if (line_off <0) {
    off = - line_off;
    line_off = 0;
  } else
    off = line_off;
#if LISTDEBUG
  /* for debugging */
  fprintf(listfile,"(%3d)fm:%d lm:%d oldbuf{%s}\n", ln, funmode,linemode, oldbuf);
#endif
#if LISTDEBUG > 1
  /* for debugging */
  fprintf(stderr,"(%3d)fm:%d lm:%d oldbuf{%s}\n", ln, funmode,linemode, oldbuf);
#endif
  switch(funmode) {
  default:
    break;
  case 0:
    /* not in main or a fn */
    fprintf(listfile,"%3d.       %s\n", ln, oldbuf);
    break;
  case 1:
    /* in main */
    if (linemode==0) 
      fprintf(listfile,"%3d.\n", ln);
    if (linemode==1) 
      fprintf(listfile,"%3d.       %s\n", ln, oldbuf);
    if (linemode==2) {
      mainlnum++;
      mainlnum -= off;
      fprintf(listfile,"%3d. [%3d] %s\n", ln, mainlnum, oldbuf);
    }
    break;
  case 2:
    /* in a user defined function */
    if (linemode==0) 
      fprintf(listfile,"%3d.\n", ln);
    if (linemode==1) 
      fprintf(listfile,"%3d.       %s\n", ln, oldbuf);
    if (linemode==2) {
      funlnum++;
      funlnum -= off;
      fprintf(listfile,"%3d. [%3d] %s\n", ln, funlnum, oldbuf);
    }
    break;
  }
  linemode=2;
  return;
}

/* copy from yytext up to nl into linesofar */
void
yycopy2nl(void)
{
  char *cyytext, *clinebuf;

  /*fprintf(stderr,"\nyytext {%s}\n", yytext);
    fprintf(stderr,"linebuf {%s}\n", linebuf);*/
  clinebuf = linebuf;
  while (*clinebuf != 0) {
    /*fprintf(stderr,"+");*/
    clinebuf++;
  }
  cyytext = yytext;
  while (*cyytext != '\n') {
    /*fprintf(stderr,"=");*/
    *clinebuf++ = *cyytext++;
  }
  *clinebuf = 0;
  /*fprintf(stderr,"linebuf(+) %s\n", linebuf);*/
  return;
}

/* yyerror - print error messages
   sws  this now includes positioning the ^ at the error  */
void
yyerror(char *c)
{ 
  char lnum[20];

  if (linenum==1)
    strcpy(linebuf,linesofar);
  /* fprintf(stderr,"[yyerror] line %d, next token ",linenum);*/
  /*  fprintf(stderr, "%s\n", prtoken(yychar));*/
  fprintf(stderr,"[yyerror] line %d\n",linenum);
  fprintf(stderr,"[%d] %s\n",linenum, linebuf);
  sprintf(lnum,"[%d]",linenum);
  fprintf(stderr,"%*s\n", (int) (strlen(lnum) + linepos), "^");
  fprintf(stderr, "last tokens: %s, %s, ", 
	  prtoken(last_token[0]), prtoken(last_token[1]));
  fprintf(stderr, "yytext= {%s}\n", yytext);
  error(c);
  return;
}

/* mnbody - output code for the main routine 
   called at the end of the file if we have main code */
void
mnbody(struct statenode *code)
{ 
  struct headnode *mnhead;

  resolvelabels_main(code);

#if AYDEBUG
  fprintf(stderr, "[mnbody] global symtab\n");
  print_symtab(stderr, gsymtab);
#endif
  mnhead = newhead(NILCHAR, NILCHAR, NILCHAR);
  /* sws collect the code writing functions */
  writecode(MNPROG,mnhead,gsymtab,code);
  fresyms(gsymtab);
  frecode(code);
}

/* update symnode b based on a */
extern void
update_info(struct symnode *b,  struct symnode *a)
{
  if (a->s.type != APLC_UKTYPE) {
    if (b->s.type != a->s.type) {
      if (b->s.type == APLC_UKTYPE) {
	b->s.type = a->s.type;
	b->s.info |= TYPEKNOWN | TYPEDECL;
      } else {
	fprintf(stderr,"[parse] Warning: type missmatch %s, type (%s) ",
		b->name, str_type_name(b->s.type));
	fprintf(stderr,"doesn't match declaration of %s, type (%s)\n", 	
		a->name, str_type_name(a->s.type));
      }	
    }
  }
  if (a->s.rank != NORANK) {
    if (b->s.rank != a->s.rank) {
      if (b->s.rank == NORANK) {
	b->s.rank = a->s.rank;
	b->s.info |= RANKKNOWN | RANKDECL;
      } else {
	fprintf(stderr,"[parse] Warning: type missmatch %s, rank (%d) ",
		b->name, b->s.rank);
	fprintf(stderr,"doesn't match declaration of %s, rank (%d)\n", 	
		a->name, a->s.rank);
      }	
    }
  }
  if (a->s.info & SHAPEKNOWN) {
    if ( !(b->s.info & SHAPEKNOWN) ) {
      b->s.shape = a->s.shape;
      b->s.info |= SHAPEKNOWN;
      b->s.size = a->s.size;
    }
  }
  return;    
}


/* prog - output code for functions (programs), 
   called when we have a function above */
void 
prog( struct headnode *head, struct statenode *code)
{
  enum classes ic;
  struct symnode *fn;  /* node for fn name (global) */
  struct symnode *var; /* node for asvar name (local) */ 

#if AYDEBUG
  fprintf(stderr,"[prog] %s <- %s %s %s\n", 
	  head->asvar, head->parm1, head->fname, head->parm2 ); 
#endif
#if AYDEBUG
  fprintf(stderr, " %s local symtab\n", head->fname);
  print_symtab(stderr, lsymtab);
  fprintf(stderr, " global symtab\n");
  print_symtab(stderr, gsymtab);
#endif

  /* check on external function definition vs internal definition
     - promote one or the other if possible 
     - this is probably already done?! 
  */
  if (NILCHAR != head->asvar) {
    /* look up the name, should be class FUNCTION */
    ic = idclass(head->fname, &fn);
#if AYDEBUG
    fprintf(stderr,"fun   %s class %d, type %d, rank %d\n", 
	    head->fname, (int)ic, fn->s.type, fn->s.rank);
    print_info(stderr, &fn->s);fprintf(stderr,"\n");
#endif
    /* if type is known, declare type of asvar */ 
    ic = idclass(head->asvar, &var);
#if AYDEBUG
    fprintf(stderr,"asvar %s class %d, type %d, rank %d\n", 
	    head->asvar, (int)ic, var->s.type, var->s.rank);
    print_info(stderr, &var->s);fprintf(stderr,"\n");
#endif
    update_info(fn, var);
    update_info(var, fn);

#if AYDEBUG
    fprintf(stderr,"fun   %s class %d, type %s, rank %s\n", 
	    head->fname, (int)ic, str_type_name(fn->s.type), 
	    str_rank(fn->s.rank));
    fprintf(stderr,"asvar %s class %d, type %s, rank %s\n", 
	    head->asvar, (int)ic, str_type_name(var->s.type), 
	    str_rank(var->s.rank));
    fprintf(stderr, "[prog] %s final local symtab\n", head->fname);
    print_symtab(stderr, lsymtab);
    fprintf(stderr, " final global symtab\n");
    print_symtab(stderr, gsymtab);
#endif
  }

  resolvelabels(code, lconsts);
  /* sws collect the code writing functions */
  writecode(PROG,head,lsymtab,code);
  fresyms(lsymtab);
  frecode(code);
  return;
}

/* opprog - output code for operators (programs), 
   called when we have a function above */
void 
opprog( struct headnode *head, struct statenode *code)
{
  enum classes ic;
  struct symnode *fn; 
  struct symnode *var; 

#if AYDEBUG
  fprintf(stderr,"[opprog] %s <- %s (%s %s %s) %s\n", 
	  head->asvar, head->parm1, 
	  head->fname, head->opname, head->rfname, head->parm2 ); 
#endif

  /* check on external function definition vs internal definition
     - promote one or the other if possible 
     - this is probably already done?! 
  */
  if (NILCHAR != head->asvar) {
    /* look up the name, should be class OP  */
    ic = idclass(head->opname, &fn);
#if AYDEBUG
    fprintf(stderr,"op    %s class %d, type %d, rank %d\n", 
	    head->fname, (int)ic, fn->s.type, fn->s.rank);
    print_info(stderr, &fn->s);fprintf(stderr,"\n");
#endif

    /* if type is known, declare type of asvar */ 
    ic = idclass(head->asvar, &var);
#if AYDEBUG
    fprintf(stderr,"asvar %s class %d, type %d, rank %d\n", 
	    head->asvar, (int)ic, var->s.type, var->s.rank);
    print_info(stderr, &var->s);fprintf(stderr,"\n");
#endif
    update_info(fn, var);
    update_info(var, fn);

#if AYDEBUG
    fprintf(stderr,"op    %s class %d, type %s, rank %s\n", 
	    head->fname, (int)ic, str_type_name(fn->s.type), 
	    str_rank(fn->s.rank));
    fprintf(stderr,"asvar %s class %d, type %s, rank %s\n", 
	    head->asvar, (int)ic, str_type_name(var->s.type), 
	    str_rank(var->s.rank));
    fprintf(stderr, "[oprog] %s final local symtab\n", head->fname);
    print_symtab(stderr, lsymtab);
    fprintf(stderr, " final global symtab\n");
    print_symtab(stderr, gsymtab);
#endif
  }

  resolvelabels(code, lconsts);
  /* sws collect the code writing functions */
  writecode(OPPROG,head,lsymtab,code);
  fresyms(lsymtab);
  frecode(code);
  return;
}

/* resolve line labels */
/* for more debugging information, set this to 1 */ 
#define DEBL 0

/* main shouldn't have any */
void
resolvelabels_main(struct statenode *code)
{
  int i;

#if DEBL
  /* print all labels */
  fprintf(stderr,"[rlm] labels (%d): ", lctop);
  for (i = 0; i < lctop; i++) {
    fprintf(stderr,"{%s},", lconsts[i].label_name);
  }
  fprintf(stderr,"\n");
#endif
  if (!lctop) 
    return;
  /* have to fix these */
  for (i = 0; i < lctop; i++) {
    /* look through the code for this name */
    /* statement list */
    check_label(code, i, lconsts[i].label_name);
  }
  /* remove all from the list */
  lctop = 0;
  return;
}


void 
check_label(struct statenode *code, int i, char *name)
{
  enum classes ic;
  struct symnode *var; 
  int ntype;
  struct statenode *y;

  /* look up the name */
  ic = idclass(name, &var);
#if DEBL
  fprintf(stderr,"[cl] class %d\n", (int)ic);
#endif
  if (ic == NOCLASS) {
    fprintf(stderr,"[check_label] name: [%s], class: %s (%d)\n", 
	    name, str_class(ic), (int)ic);
    fprintf(stderr,"(unreloved symbol)\n");
    yyerror("unresolved label"); 
  }
  /* get node type 
     - can't really have a fn here; would be a parse error
     - param ought to be impossible; should have been caught already
     - labclass appears unused
   */
  switch(ic) {
  case GLOBAL: 
    if (var->s.type == APLC_LABEL) {
      fprintf(stderr,"[check_label] name: [%s], class: %s (%d)\n", 
	      name, str_class(ic), (int)ic);
      yyerror("cannot have global label");
    }
    ntype = IDENT;
    break;
  case PARAM: 
    ntype = IDENT;
    break;
  case LOCAL:
    if (var->s.type == APLC_LABEL)
      ntype = LCON;
    else 
      ntype = IDENT;
    break;
  case FUNCTION: 
    ntype = FIDENT;
    break;
  case OPERATOR:
    ntype = OPIDENT;
    break;
  case LABCLASS:  
  case NOCLASS:
  default:
    ntype = UIDENT;
    break;
  }
#if 0
  fprintf(stderr,"[cl] class %d, type %d\n", 
	  (int)ic, (int) var->s.type);
#endif
#if DEBL
  /* print all labels */
  fprintf(stderr,"[cl] changing to node type %d\n",
	  ntype);
#endif
  for (y = code; y != NILSTATE; y = y->nextstate) {
    fixlabel(y->code, i, lconsts[i].label_name, ntype, var);
  }
  return;
}

/* possibly change a label to an ident */
void
fixlabel( struct node *node, int i, char *name, 
	  int ntype, struct symnode *var)
{
  /* search through nodes */
  switch (node->nodetype) {
  default:
    if (LEFT != NILP)
      fixlabel(LEFT,i, name, ntype, var);
    if (RIGHT != NILP)
      fixlabel(RIGHT,i, name, ntype, var);
      break;
  case LCON:
    /* see if it matches */
    if (node->n.values == i) {
#if DEBL
      /* print all labels */
      fprintf(stderr,"[fl] match (%d) %s\n", i, name);
#endif
      /* change the node from a label to an ident */
      node->nodetype = ntype;
      switch(ntype) {
      default:
	fprintf(stderr,"[fl] node type %d not handled\n", ntype); 
	yyerror("unresolved label");
	break;
      case IDENT:
	node->n.info = 0;
	node->namep = var->name;
	if ((var->s.type != APLC_UKTYPE) & (var->s.type != APLC_ANY))
	  node->n.info |= (TYPEDECL | TYPEKNOWN);
	node->n.type = var->s.type;
	if (var->s.rank != NORANK)
	  node->n.info |= (RANKDECL | RANKKNOWN);
	node->n.rank = var->s.rank;
	break;
      }
    }
    break;
  }
  return;
}

void
resolvelabels(struct statenode *code, struct label_struct lar[])
{ 
  int i, j;
  struct statenode *y;

#if DEBL
  /* print all labels */
  fprintf(stderr,"[rl] labels (%d): ", lctop);
  for (i = 0; i < lctop; i++) {
    fprintf(stderr,"{%s},", lar[i].label_name);
  }
  fprintf(stderr,"\n");
#endif
  for (i = 0; i < lctop; i++) {
    j = 0;
#if DEBL
    fprintf(stderr,"[rl] %d label %s", i, lar[i].label_name);
#endif
    for (y = code; y != NILSTATE; y = y->nextstate) {
      j++;
      if ((y->label != NILCHAR) && 
	  (strcmp(lar[i].label_name, y->label)) == 0) {
	lar[i].label_num = j;
#if DEBL
	fprintf(stderr," = %d\n", j );
#endif
	break;
      }
    }
    if (y == NILSTATE) {
#if 0
      fprintf(stderr,"[resolvelabels] label (%s);\n",lar[i].label_name);
      fprintf(stderr," unresolved label or undeclared variable\n"); 
      yyerror("unresolved label");
#endif
      /* couldn't resolve label - assume it's not a label then */
      fprintf(stderr,"\n[rl] unresolved label or undeclared variable\n"); 
      fprintf(stderr," label (%s);\n",lar[i].label_name);
      fprintf(stderr," attempting to determine type\n"); 
      check_label(code, i, lconsts[i].label_name);
    }
  }
  return;
}

/* error message for missplaced string */
void
expect(char *str)
{ 
  char buffer[100];

  sprintf(buffer, "expected %s found %s", str, yytext);
  yyerror(buffer);
  return;
}

/* end */
