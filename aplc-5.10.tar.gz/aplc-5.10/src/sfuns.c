/*
	APL Compiler

	Code Generation routines having to do with scalar functions
	tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include "parse.h"
#include "y_tab.h"
#include "gen.h"

/* strings for scalar function names 
   - note that this must match the list of sfuns in aplc.h
*/
static char *dostrs[] = {
  "APLC_NOT",
  "APLC_FLOOR", "APLC_CEIL", "APLC_PLUS", "APLC_MINUS", "APLC_TIMES", "APLC_ABS", "APLC_DIVIDE", "APLC_EXP",
  "APLC_LOG", "APLC_CIRCLE", "APLC_FACT",
  "APLC_AND", "APLC_OR", "APLC_NAND", "APLC_NOR", "APLC_LT", "APLC_LE", "APLC_EQ", "APLC_NE", "APLC_GE", "APLC_GT",
  "APLC_L_AND", "APLC_L_OR"};

/* sws  strings for scalar functions 
   operations on res */

/* monadic */
static char *mofn_strs[] = {
  "aplc_not_res",
  "aplc_floor_res", "aplc_ceil_res", 
  "aplc_conj_res", "aplc_neg_res", "aplc_sign_res", 
  "aplc_mag_res", "aplc_recip_res", "aplc_exp_res",
  "aplc_nlog_res", "aplc_pim_res", "aplc_fact_res",
  "ukn", "ukn", "ukn", "ukn", 
  "ukn", "ukn", "ukn", "ukn", "ukn", "ukn"};

/* dyadic */
static char *dofn_strs[] = {
  "ukn",
  "aplc_min_res", "aplc_max_res", 
  "aplc_plus_res", "aplc_minus_res", "aplc_times_res", 
  "aplc_residue_res", "aplc_divide_res", "aplc_power_res",
  "aplc_log_res", "aplc_circle_res", "aplc_binomial_res",
  "aplc_and_res", "aplc_or_res", "aplc_nand_res", "aplc_nor_res", 
  "aplc_lt_res", "aplc_le_res", "aplc_eq_res", "aplc_ne_res", "aplc_ge_res", "aplc_gt_res"};


#define SFUNSDEBUG 0

void dsfunvr(enum sfuns op, int res, int r1, int r2, struct node *node);

void genred_nom(struct node * node, enum pmodes mode, int top);
void genred_vart(struct node * node, enum pmodes mode, int top);


/*
	dsfunt - generate type information for dyadic scalar functions
*/
void
dsfunt(enum sfuns op, struct node * node,
       struct node * left, struct node * right, int ival)
{
  if (cteq(left->c.type, right->c.type)) {
    if ( (op == APLC_PLUS) || (op == APLC_MINUS) || (op == APLC_TIMES)) {
      node->c.type = left->c.type;
      return;
    }
  }
  ieq(ival);
  printf("aplc_dsfunt(%s, ", dostrs[(int) op]);
  ctgen(left->c.type);
  commasp();
  ctgen(right->c.type);
  rpseminl();
  node->c.type = gicn(coiptr, ival, 0);
}


/*
  dsfunv - generate values for dyadic scalar functions

  node code:
  node = left op right
 
*/
void
dsfunv(enum sfuns op, struct node * node,
      struct node * left, struct node * right,
      int resval, int lresval, int rresval)
{
  int rt;

#if SFUNSDEBUG
  printf("/* [dsfunv] op %d, nodetti %d, leftti %d, righttti %d */\n",
	 op, node->n.info & TYPEKNOWN, right->n.info & TYPEKNOWN, 
	 left->n.info & TYPEKNOWN);
#endif
  rt = APLC_UKTYPE;
  /* if we know node type, may generate simpler code */
    if ( isNotGcomplex(node) &&
	 isNotGcomplex(left) &&
	 isNotGcomplex(right) ) {
      switch (op) {
      case APLC_PLUS:
      case APLC_MINUS:
      case APLC_TIMES:
	mkrktype(left, rtype(node), lresval);
	mkrktype(right, rtype(node), rresval);
	node->c.values = gsfun(op, left->c.values, 	right->c.values);
	return;

      case APLC_DIVIDE:
	mkrktype(left, APLC_REAL, lresval);
	mkrktype(right, APLC_REAL, rresval);
	node->c.values = gsfun(op, left->c.values, 	right->c.values);
	return;

      case APLC_ABS:
	/* sws  
	   this ain't right for negative arguments 
	   should probably take the
	   % generation stuff out of ctree as well
    
	   if (! (left->n.info & TYPEKNOWN)) break; if (! (right->n.info & TYPEKNOWN))
	   break; rt = maxtype(rtype(left), rtype(right)); if (rt != APLC_INT) break;
	   mkrktype(left, rt, lresval); mkrktype(right, rt, rresval);
	   node->c.values = gsfun(op, left->c.values, right->c.values); return; */
	break;

      case APLC_AND:
      case APLC_OR:
	mkrktype(left, APLC_BOOL, lresval);
	mkrktype(right, APLC_BOOL, rresval);
	node->c.values = gsfun(op, left->c.values,	right->c.values);
	return;

      case APLC_EQ:
	rt = APLC_BOOL;
	/* check for ridiculous comparisons */
	if ( ((rtype(left) == APLC_CHAR) && (rtype(right) != APLC_CHAR)) ||
	     ((rtype(left) != APLC_CHAR) && (rtype(right) == APLC_CHAR)) ) {
	  node->c.values = gicn(icnst, 0, APLC_INT);
	  return;
	}
	rt = maxtype(rtype(left), rtype(right));
	mkrktype(left, rt, lresval);
	mkrktype(right, rt, rresval);
	node->c.values = gsfun(op, left->c.values, right->c.values);
	return;

      case APLC_LT:
      case APLC_LE:
      case APLC_NE:
      case APLC_GT:
      case APLC_GE:
	rt = APLC_BOOL;
	rt = maxtype(rtype(left), rtype(right));
	mkrktype(left, rt, lresval);
	mkrktype(right, rt, rresval);
	node->c.values = gsfun(op, left->c.values, right->c.values);
	return;

      default:
	/* general case, just continue to below */
	break;
      }
  }

  rresval = resinreg(right, rresval);
  lresval = resinreg(left, lresval);
  /*printf("aplc_dsfunv(%s, ", dostrs[(int) op]);*/
  printf("%s(", dofn_strs[(int) op]);
  printf("&res%d, &res%d, ", resval, lresval);
  ctgen(left->c.type);
  printf(", &res%d, ", rresval);
  ctgen(right->c.type);
  rpseminl();

  /* sws  be careful of result type - for compression calls */
  if (rt == APLC_UKTYPE)
    node->c.values = gicn(resptr, resval, rtype(node));
  else
    node->c.values = gicn(resptr, resval, rt);
  return;
}

/* sws dsfun for regs 
   res = r1 op r2  */
void
dsfunvr(enum sfuns op, int res, int r1, int r2, struct node *node)
{
  int type = rtype(node);

  switch (op) {

  default:
    break;

  case APLC_PLUS:
    if (type == APLC_INT) {
      printf("res%d.i = res%d.i+res%d.i;\n", res, r1,r2);
      return;
    }
    break;

  case APLC_TIMES:
    if (type == APLC_INT) {
      printf("res%d.i = res%d.i*res%d.i;\n", res, r1,r2);
      return;
    }
    break;
  }
  if (ctdsfun_check(op,type)) {
    ctgen( gbin(coasgn, gicn(resptr, res, type),
		gsfun(op, gicn(resptr, r1, type), gicn(resptr, r2, type))) );
    seminl();
  } else {
    printf("%s(", dofn_strs[(int) op]);
    printf("&res%d, &res%d, ", res, r1);
    ctgen(node->c.type);
    printf(", &res%d, ", r2);
    ctgen(node->c.type);
    rpseminl();
  } 
  return;
}

/*
  adsfun - append a value to an existing register

  node code:
  resval = resval op child

  - sws  could be made local - not used outside of sfuns.c
*/
void
adsfun(enum sfuns op, struct node * node, struct node * child, int resval)
{
  int r;

  r = rtype(node);

  switch (op) {

  default:
    break;

  case APLC_PLUS:
    if (r == APLC_INT) {
      printf("res%d.i += ", resval);
      ctgen(child->c.values);
      seminl();
      node->c.values = gicn(resptr, resval, APLC_INT);
      return;
    }
    break;

  case APLC_TIMES:
    if (r == APLC_INT) {
      printf("res%d.i *= ", resval);
      ctgen(child->c.values);
      seminl();
      node->c.values = gicn(resptr, resval, APLC_INT);
      return;
    }
    break;
  }
#if SFUNSDEBUG
  printf("/* adsfun */");
#endif
  dsfunv(op, node, child, node, resval, 0, resval);
  r = resinreg(node, resval);
  if (r != resval)
    printf("res%d = res%d;\n", resval, r);
}

/*
	msfunv - generate values for monadic scalar operators
*/

#if 0
/* replaced with call to res_type_str() */
static char *tfields[] = {
  "i", 
  "i", "i", "i", 
  "r", "z", "q", "o", 
  "c", "i", "i"};
#endif

void
msfunv(int resval, enum sfuns op, struct node * node, struct node * child, 
      int inval)
{
  int rt;
  char *s;

  rt = APLC_UKTYPE;
  if ( isNotGcomplex(node) &&
       isNotGcomplex(child) ) {
    switch (op) {

    default:
      break;

    case APLC_NOT:
      mkrktype(child, APLC_BOOL, inval);
      node->c.values = gmop(op, child->c.values);
      return;

    case APLC_FLOOR:
    case APLC_CEIL:
    case APLC_DIVIDE:
    case APLC_EXP:
    case APLC_LOG:
    case APLC_CIRCLE:
      mkrktype(child, APLC_REAL, inval);
      node->c.values = gmop(op, child->c.values);
      return;

    case APLC_PLUS:
      node->c.values = child->c.values;
      return;

    case APLC_MINUS:
      node->c.values = gmop(op, child->c.values);
      return;

    case APLC_ABS:
      inval = resinreg(child, inval);
      /*s = tfields[rtype(node)];*/
      s = res_type_str(rtype(node));
      printf("if (res%d.%s < 0)\n", inval, s);
      printf("res%d.%s = - res%d.%s;\n",
	     inval, s, inval, s);
      /*node->c.values = gicn(resptr, resval, rtype(node));*/
      node->c.values = gicn(resptr, inval, rtype(node));
      return;
    }
  }
  /* have to do at runtime */
  inval = resinreg(child, inval);
  /* printf("aplc_msfunv(&res%d, %s, &res%d, ", resval, dostrs[(int) op], inval);*/
  printf("%s(&res%d, &res%d, ", mofn_strs[(int) op], resval, inval);
  ctgen(child->c.type);
  rpseminl();
  node->c.values = gicn(resptr, resval, rtype(node));
  return;
}

/*
  identity 
  - generate a right (left) identity for an op
*/
void
identity(enum sfuns op, int resval, struct node * node)
{
  int t;

  t = rtype(node);
  node->c.values = gicn(resptr, resval, t);

  switch (op) {

  default:
    break;

  case APLC_PLUS:
  case APLC_MINUS:
  case APLC_OR:
  case APLC_LT:
  case APLC_NE:
    if ((t == APLC_BOOL) || (t == APLC_INT)) {
      printf("res%d.i = 0;\n", resval);
      return;
    }
    if (t == APLC_REAL) {
      printf("res%d.r = 0;\n", resval);
      return;
    }
    break;

  case APLC_TIMES:
  case APLC_DIVIDE:
  case APLC_EXP:
  case APLC_AND:
  case APLC_FACT:
  case APLC_LE:
  case APLC_EQ:
    if ((t == APLC_BOOL) || (t == APLC_INT)) {
      printf("res%d.i = 1;\n", resval);
      return;
    }
    if (t == APLC_REAL) {
      printf("res%d.r = 1.0;\n", resval);
      return;
    }
    break;

    /* smallest number */
  case APLC_CEIL:
    if ((t == APLC_BOOL) || (t == APLC_INT)) {
      printf("res%d.i = INT_MIN;\n", resval);
      return;
    }
    if (t == APLC_REAL) {
      printf("res%d.r = -DBL_MAX;\n", resval);
      return;
    }
    break;

    /* largest number */
  case APLC_FLOOR:
    if ((t == APLC_BOOL) || (t == APLC_INT)) {
      printf("res%d.i = INT_MAX;\n", resval);
      return;
    }
    if (t == APLC_REAL) {
      printf("res%d.r = DBL_MAX;\n", resval);
      return;
    }
    break;

  }
  printf("aplc_identity(%s, &res%d, ", dostrs[(int) op], resval);
  ctgen(node->c.type);
  rpseminl();
}

/*
  gendsfun - generate code for dyadic scalar functions

	ptr1 - result register for left side
	ptr2 - result register for right side
	ptr3 - i register for type
	ptr4 - i register for rank
	ptr5 - mp for shape
*/
void
gendsfun(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:

    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);

    if (!(node->n.info & TYPEKNOWN))
      dsfunt(node->optype, node, LEFT, RIGHT, node->ptr3);
    if (!(node->n.info & SHAPEKNOWN)) {
      if (is_scalar(LEFT))
	copychild(node, RIGHT, 0, 1, 1);
      else if (is_scalar(RIGHT) ||
	    (cteq(LEFT->c.rank, RIGHT->c.rank) &&
		cteq(LEFT->c.shape, RIGHT->c.shape)))
	copychild(node, LEFT, 0, 1, 1);
      else {
	rkeq(node, node->ptr4);
	printf("aplc_dsfuns(&mp%d, ", node->ptr5);
	lrnsrrns(LEFT, RIGHT);
	rpseminl();
	node->c.shape = gicn(memptr, node->ptr5, APLC_INT);
      }
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    switchbox(LEFT, mode, 0);
    switchbox(RIGHT, mode, 0);
#if SFUNSDEBUG
    printf("/* gendsfun */");
#endif
    dsfunv(node->optype, node, LEFT, RIGHT, node->ptr1,
	node->ptr1, node->ptr2);
    break;

  case FINISH:
    switchbox(LEFT, mode, 0);
    switchbox(RIGHT, mode, 0);
    if ( (!(node->n.info & SHAPEKNOWN)) 
	 && (!is_scalar(LEFT)) && 
	 (! (is_scalar(RIGHT)  ||
	     (cteq(LEFT->c.rank, RIGHT->c.rank) &&
	      cteq(LEFT->c.shape, RIGHT->c.shape))) ) ) {
#ifdef DEBUGFREE
      printf("/* -- dsfun finish */\n");
#endif
      /* free the shape */
      /*not sure why this is here...

	- if aplc_dsfuns() is called, mp may not be freeable...
      */
	mpfree_nots(node->ptr5, node->ptr4);
      /*mpfree(node->ptr5);*/
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;

  }
}

/*
	genmsfun - generate code for monadic scalar operators */
/*
	ptr1 - type
	ptr2 - right
	ptr3 - result
*/
void
genmsfun(struct node * node, enum pmodes mode, int top)
{
  enum sfuns op;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    op = node->optype;
    if (!(node->n.info & TYPEKNOWN)) {
      if ((op == APLC_NOT) ||
	  (op == APLC_PLUS) ||
	  (op == APLC_MINUS)) 
	node->c.type = RIGHT->c.type;
      else {
	ieq(node->ptr1);
	printf("aplc_msfunt(%s, ", dostrs[(int) op]);
	ctgen(RIGHT->c.type);
	rpseminl();
	node->c.type =
	    gicn(coiptr, node->ptr1, APLC_INT);
      }
    }
    copychild(node, RIGHT, 0, 1, 1);
    break;

  case COMBINE:
    break;

  case VALUE:
    switchbox(RIGHT, VALUE, 0);
    msfunv(node->ptr3, node->optype, node, RIGHT, node->ptr2);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    break;
  }
}

/*
     genouter - generate code for outer product
*/
void
genouter(struct node * node, enum pmodes mode, int top)
{
/*
	ptr1 = mp for shape
	ptr2 = size of right hand side
	ptr4 = res register for left hand side
	ptr5 = res register for right hand side
	ptr6 = rank of result
*/
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    if (!(node->n.info & TYPEKNOWN))
      dsfunt(node->optype, node, LEFT, RIGHT, node->ptr0);
    if (!(node->n.info & SHAPEKNOWN)) {
      rkeq(node, node->ptr6);
      printf("aplc_outershape(&mp%d, ", node->ptr1);
      lrnsrrns(LEFT, RIGHT);
      rpseminl();
      node->c.shape = gicn(memptr, node->ptr1, APLC_INT);
    }
    getsize(node->ptr2, RIGHT);

    /* sws   
       sequential case: 
        initialize offset indices left to -1, right to max 
    */
    if (node->n.info & SEQUENTIAL) {
      ieqi(RIGHT->index, node->ptr2);
      if (!(LEFT->n.info & NOINDEX))
	seticon(LEFT->index, -1);
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    if (node->n.info & SEQUENTIAL) {
      /* sws  
       moved right increment here, embedded in check of right offset */
      printf("if ( ++i%d >= i%d) {\n", RIGHT->index, node->ptr2);
      /* increment left, reset right offsets */
      if (!(LEFT->n.info & NOINDEX))
	iincr(LEFT->index);
      seticon(RIGHT->index, 0);
    } else
      divmod(node->index, node->ptr2, LEFT->index, RIGHT->index);

    /* get left value */
    switchbox(LEFT, VALUE, 0);

    if (node->n.info & SEQUENTIAL) {
      resinreg(LEFT, node->ptr4);
      rbr();
    }
    /* get right value */
    switchbox(RIGHT, VALUE, 0);

    /* get result */
#if SFUNSDEBUG
    printf("/* genouter */");
#endif
    dsfunv(node->optype, node, LEFT, RIGHT, node->ptr5,
	node->ptr4, node->ptr5);
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    if (!(node->n.info & SHAPEKNOWN)) {
#ifdef DEBUGFREE
      printf("/* -- outer finish */\n");
#endif
      mpfree_nots(node->ptr1,node->ptr6);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/*
	genred - generate code for reduction function
	- fixed to work in general, even for operators 
	  without right identities  

	ptr1 - memory pointer for shape
	ptr2 - e sub i
	ptr3 - s sub i
	ptr4 - axis, also loop counter
	ptr5 - result register
	ptr6 - type
	ptr7 - rank
	ptr8 - e sub i * s sub i
	ptr9 - offset div e sub i
	ptr10 - flag (sws; for funs with no right identity)
	ptr11 - temp register
	ptr12 - flag (sws; for variable type)
*/
void
genred(struct node * node, enum pmodes mode, int top)
{
  switch(node->optype) {
  case APLC_FLOOR:
  case APLC_CEIL: 
  case APLC_PLUS:
  case APLC_MINUS:
  case APLC_TIMES:
  case APLC_ABS:
  case APLC_DIVIDE:
  case APLC_EXP:
  case APLC_LOG:
  case APLC_CIRCLE:
  case APLC_FACT:
  case APLC_AND:
  case APLC_OR:
  case APLC_NAND:
  case APLC_NOR:
    genred_nom(node, mode, top); 
    break;

  case APLC_LT:
  case APLC_LE:
  case APLC_EQ:
  case APLC_NE:
  case APLC_GE:
  case APLC_GT:
    genred_vart(node, mode, top); 
    break;

  default:
    error("illegal op for reduce");
    break;
  }
  return;
}

/* nominal - type is fixed */
void
genred_nom(struct node * node, enum pmodes mode, int top)
{
  int idflag = 0;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);

    if (is_scalar(RIGHT)) {
      /* result is right */
      copychild(node, RIGHT, 1, 1, 0);
      break;
    }

    if (!(node->n.info & TYPEKNOWN))
      dsfunt(node->optype, node, RIGHT, RIGHT, node->ptr6);

    redshape(node, node->axis, node->ptr4, node->ptr2, node->ptr3,
	     node->ptr1, node->ptr7);

    /* if sequential initialize right index */
    if (! (RIGHT->n.info & NOINDEX)) 
      if ((RIGHT->n.info & SEQUENTIAL) && ! is_vector(RIGHT))
	setizero(RIGHT->index);

    /* if we need it, compute temporary e sub i * s sub i */
    if (!(RIGHT->n.info & SEQUENTIAL)) {
      if (node->n.info & FIRSTAXIS) {
	printf("i%d = (i%d - 1) * i%d;\n",
	       node->ptr8, node->ptr3, node->ptr2);
      } else if (!(node->n.info & LASTAXIS)) {
	iopi(node->ptr8, node->ptr2, "*", node->ptr3);
      }
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    if (is_scalar(RIGHT)) {
      switchbox(RIGHT, VALUE, 0);
      node->c.values = RIGHT->c.values;
      break;
    }

    idflag = has_Ridentity(node->optype, RIGHT);
    if (idflag)
      identity(node->optype, node->ptr5, node);
    else {
      /* no identity for this op */ 
      seticon(node->ptr10, 1);/* flag to true */
      node->c.values = gicn(resptr, node->ptr5, rtype(node));
    }

    /* offset' computation */
    /* if not sequential and not vector we need to compute base */
    if (!((RIGHT->n.info & SEQUENTIAL) || is_vector(RIGHT))) {
      if (!(RIGHT->n.info & NOINDEX)) {
	if (node->n.info & FIRSTAXIS)
	  printf("i%d = i%d + i%d;\n",
	      RIGHT->index, node->ptr8, node->index);
	else if (node->n.info & LASTAXIS)
	  printf("i%d = (i%d + 1) * i%d - 1;\n",
	      RIGHT->index, node->index, node->ptr3);
	else {
	  /*   jbww ukc 6/87 */
	  divmod(node->index, node->ptr2, node->ptr9, RIGHT->index);
	  /* divmod(node->index, node->ptr2, RIGHT->index, node->ptr9); */
	  /* div, mod were swapped.     jbww ukc 6/87 */
	  printf("i%d += (i%d + 1) * i%d - i%d;\n",
	      RIGHT->index, node->ptr9,
	      node->ptr8, node->ptr2);
	}
      }
    }

    if (is_vector(RIGHT)) {
      if (is_commute(node) && is_assoc(node)) {
	/* commutative, associative case, can reverse order ++ */
	iiloop(RIGHT->index, node->ptr3);
      } else {
	/* non commutative or associative case, -- */
	izloop(RIGHT->index, node->ptr3);
      }
    } else
      izloop(node->ptr4, node->ptr3);

    switchbox(RIGHT, VALUE, 0);
    if (!idflag) {
      /* setup temp */
      resinreg2(RIGHT, node->ptr11);
      /* check flag */
      iflp(); printf("i%d){\n", node->ptr10);
      setizero(node->ptr10);
      /* res = temp */
      reqr(node->ptr5, node->ptr11);
      printf("} else {\n");
      /* res = temp op res */
      dsfunvr(node->optype, node->ptr5, node->ptr11, node->ptr5, RIGHT);
      rbr();
    } else {
#if SFUNSDEBUG
      printf("/* adsfun here */");
#endif
      /* res = value op res */
      adsfun(node->optype, node, RIGHT, node->ptr5);
    }

    if (is_vector(RIGHT));	     /* do nothing, updated in loop */
    else if (!(RIGHT->n.info & NOINDEX)) {
      if (RIGHT->n.info & SEQUENTIAL)
	iincr(RIGHT->index);
      else
	esubtract(node, RIGHT->index, node->ptr2);
    }
    rbr();

    if (!idflag) {
      /* check for empty right */
      /* check flag */
      iflp(); printf("i%d){\n", node->ptr10);
      printf("aplc_identity(%s, &res%d, ", 
	     dostrs[(int) node->optype], node->ptr5);
      ctgen(node->c.type);
      rpseminl();
      rbr();
    }
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    if ( is_scalar(RIGHT) )
      break;
    if (!((node->n.info & FIRSTAXIS) || (node->n.info & LASTAXIS))) {
#ifdef DEBUGFREE
      printf("/* -- reduction finish */\n");
#endif
      mpfree(node->ptr1);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}


/* type is variable as we compute */
void
genred_vart(struct node * node, enum pmodes mode, int top)
{
  int idflag = 0;
  int saveinfo;
  struct codetree *savetype;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);

    if (is_scalar(RIGHT)) {
      /* result is right */
      copychild(node, RIGHT, 1, 1, 0);
      break;
    }

    if (!(node->n.info & TYPEKNOWN))
      dsfunt(node->optype, node, RIGHT, RIGHT, node->ptr6);

    redshape(node, node->axis, node->ptr4, node->ptr2, node->ptr3,
	     node->ptr1, node->ptr7);

    /* if sequential initialize right index */
    if (! (RIGHT->n.info & NOINDEX)) 
      if ((RIGHT->n.info & SEQUENTIAL) && ! is_vector(RIGHT))
	setizero(RIGHT->index);

    /* if we need it, compute temporary e sub i * s sub i */
    if (!(RIGHT->n.info & SEQUENTIAL)) {
      if (node->n.info & FIRSTAXIS) {
	printf("i%d = (i%d - 1) * i%d;\n",
	       node->ptr8, node->ptr3, node->ptr2);
      } else if (!(node->n.info & LASTAXIS)) {
	iopi(node->ptr8, node->ptr2, "*", node->ptr3);
      }
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    if (is_scalar(RIGHT)) {
      switchbox(RIGHT, VALUE, 0);
      node->c.values = RIGHT->c.values;
      break;
    }

    savetype = node->c.type;
    saveinfo = node->n.info;

    /* turn any known type off */
    if (node->n.info & TYPEKNOWN)
      node->n.info ^= TYPEKNOWN;
    node->c.type = gicn(coiptr, node->ptr6, 0);
    /* start with right */
    ieqtree(node->ptr6, RIGHT->c.type);

    idflag = has_Ridentity(node->optype, RIGHT);
    if (idflag)
      identity(node->optype, node->ptr5, node);
    else {
      /* no identity for this op */ 
      seticon(node->ptr10, 1);/* flag to true */
      node->c.values = gicn(resptr, node->ptr5, rtype(node));
    }

    /* offset' computation */
    /* if not sequential and not vector we need to compute base */
    if (!((RIGHT->n.info & SEQUENTIAL) || is_vector(RIGHT))) {
      if (!(RIGHT->n.info & NOINDEX)) {
	if (node->n.info & FIRSTAXIS)
	  printf("i%d = i%d + i%d;\n",
	      RIGHT->index, node->ptr8, node->index);
	else if (node->n.info & LASTAXIS)
	  printf("i%d = (i%d + 1) * i%d - 1;\n",
	      RIGHT->index, node->index, node->ptr3);
	else {
	  /*   jbww ukc 6/87 */
	  divmod(node->index, node->ptr2, node->ptr9, RIGHT->index);
	  /* divmod(node->index, node->ptr2, RIGHT->index, node->ptr9); */
	  /* div, mod were swapped.     jbww ukc 6/87 */
	  printf("i%d += (i%d + 1) * i%d - i%d;\n",
	      RIGHT->index, node->ptr9,
	      node->ptr8, node->ptr2);
	}
      }
    }

    if (is_vector(RIGHT)) {
      if (is_commute(node) && is_assoc(node)) {
	/* commutative case, ++ */
	iiloop(RIGHT->index, node->ptr3);
      } else {
	/* non commutative case, -- */
	izloop(RIGHT->index, node->ptr3);
      }
    } else
      izloop(node->ptr4, node->ptr3);

    switchbox(RIGHT, VALUE, 0);
    if (!idflag) {
      /* setup temp */
      resinreg2(RIGHT, node->ptr11);
      /* check flag */
      iflp(); printf("i%d){\n", node->ptr10);
      setizero(node->ptr10);
      /* res = temp */
      reqr(node->ptr5, node->ptr11);
      printf("} else {\n");
      /* res = temp op res */
      /*
	dsfunvr(node->optype, node->ptr5, node->ptr11, node->ptr5, RIGHT);
      */
      printf("%s(", dofn_strs[(int) node->optype]);
      printf("&res%d, &res%d, ", node->ptr5, node->ptr11);
      ctgen(RIGHT->c.type);
      printf(", &res%d, ", node->ptr5);
      ctgen(node->c.type);
      rpseminl();
      /* now force node type to bool */
      ieq(node->ptr6);
      printf("APLC_BOOL;\n");
      rbr();
    } else {
#if SFUNSDEBUG
      printf("/* adsfun here */");
#endif
      /* res = value op res */
      adsfun(node->optype, node, RIGHT, node->ptr5);
    }
    /* restore any type knowedge */
    node->c.type = savetype; 
    node->n.info = saveinfo;
    node->c.values = gicn(resptr, node->ptr5, rtype(node));

    if (is_vector(RIGHT));	     /* do nothing, updated in loop */
    else if (!(RIGHT->n.info & NOINDEX)) {
      if (RIGHT->n.info & SEQUENTIAL)
	iincr(RIGHT->index);
      else
	esubtract(node, RIGHT->index, node->ptr2);
    }
    rbr();

    printf("/* red_vart final value phase */\n");
    if (!idflag) {
      /* check for empty right */
      /* check flag */
      iflp(); printf("i%d){\n", node->ptr10);
      printf("aplc_identity(%s, &res%d, ", 
	     dostrs[(int) node->optype], node->ptr5);
      ctgen(node->c.type);
      rpseminl();
      rbr();
    }
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    if ( is_scalar(RIGHT) )
      break;
    if (!((node->n.info & FIRSTAXIS) || (node->n.info & LASTAXIS))) {
#ifdef DEBUGFREE
      printf("/* -- reduction finish */\n");
#endif
      mpfree(node->ptr1);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/*
	genscan - generate code for scan function

	ptr1 - axis position
	ptr2 - e sub i
	ptr3 = s sub i

	ptr5 - counter for loop
	ptr6  - result register
	ptr7 - type
	ptr8 - flag (sws; for funs with no right identity)
	ptr9 - temp register

	right should only be marked sequential if the op is
	commutative and associative
*/
void
genscan(struct node * node, enum pmodes mode, int top)
{
  int idflag = 0;

  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);

    if (is_scalar(RIGHT)) {
      /* result is right */
      copychild(node, RIGHT, 1, 1, 0);
      break;
    }

    if (!(node->n.info & TYPEKNOWN))
      dsfunt(node->optype, node, RIGHT, RIGHT, node->ptr7);

    copychild(node, RIGHT, 0, 1, 1);

    idflag = has_Ridentity(node->optype, RIGHT);
    if (idflag) {
      /* identity exists for this op */
      if (RIGHT->n.info & SEQUENTIAL) {
	axies(node, node->axis, RIGHT, 0, 0, node->ptr3);
      if (is_vector(RIGHT)) {
	  identity(node->optype, node->ptr6, node);
      } else if (!(RIGHT->n.info & NOINDEX))
	ieqi(node->ptr5, node->ptr3);/* counter = s sub i */
      } else {
	axies(node, node->axis, RIGHT, 0, node->ptr2, node->ptr3);
      }
    } else {
      /* no identity exists for this op */
      axies(node, node->axis, RIGHT, 0, node->ptr2, node->ptr3);
      if (RIGHT->n.info & SEQUENTIAL) {
	seticon(node->ptr8, 1);/* flag to true */
      }
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    if (is_scalar(RIGHT)) {
      switchbox(RIGHT, VALUE, 0);
      node->c.values = RIGHT->c.values;
      break;
    }

    idflag = has_Ridentity(node->optype, RIGHT);
    if (idflag) {
      /* there is an identity */
      if (RIGHT->n.info & SEQUENTIAL) {
	if (!is_vector(RIGHT)) {
	  printf("if (i%d >= i%d) {\n", node->ptr5, node->ptr3);
	  identity(node->optype, node->ptr6, node);
	  seticon(node->ptr5, 0);
	  rbr();
	}
	/* sws ?? 
	   if (! RIGHT->n.info & HAVEVALUE) ieqi(RIGHT->index, node->index);
	*/
      } else {
	identity(node->optype, node->ptr6, node);
	if (!is_vector(RIGHT))
	  ieqi(RIGHT->index, node->index);
	printf("for (i%d = ", node->ptr5);
	asubi(node, RIGHT, node->index, node->ptr2, node->ptr3);
	printf("; i%d >= 0; i%d--) {\n", node->ptr5, node->ptr5);
      }

      switchbox(RIGHT, VALUE, 0);
      /* this defines the node code values */
      adsfun(node->optype, node, RIGHT, node->ptr6);

      if (RIGHT->n.info & SEQUENTIAL) {
	if (!is_vector(RIGHT))
	  iincr(node->ptr5);
      } else {
	if (!is_vector(RIGHT))
	  esubtract(node, RIGHT->index, node->ptr2);
	rbr();
      }
    } else {
      /* no identity for this op */ 
      node->c.values = gicn(resptr, node->ptr6, rtype(node));
      if (RIGHT->n.info & SEQUENTIAL) {
	/* flag initialized in shape phase */
	if (!is_vector(RIGHT)) {
	  printf("if (i%d >= i%d) {\n", node->ptr5, node->ptr3);
	  seticon(node->ptr5, 0);/* init counter */
	  rbr();
	}
      } else {
	seticon(node->ptr8, 1);/* flag to true */
	if (!is_vector(RIGHT))
	  ieqi(RIGHT->index, node->index);
	printf("for (i%d = ", node->ptr5);
	asubi(node, RIGHT, node->index, node->ptr2, node->ptr3);
	printf("; i%d >= 0; i%d--) {\n", node->ptr5, node->ptr5);
      }

      switchbox(RIGHT, VALUE, 0);
      /* setup temp for right value */
      resinreg2(RIGHT, node->ptr9);
      /* check flag */
      iflp(); printf("i%d){\n", node->ptr8);
      setizero(node->ptr8);/* reset flag */
      /* res = temp */
      reqr(node->ptr6, node->ptr9);
      printf("} else {\n");
      /* res = temp op res */
     /*dsfunvr(node->optype, node->ptr6, node->ptr9, node->ptr6, RIGHT);*/
      /* res = res op temp */
      dsfunvr(node->optype, node->ptr6, node->ptr6, node->ptr9, RIGHT);
      rbr();

      if (RIGHT->n.info & SEQUENTIAL) {
	if (!is_vector(RIGHT))
	  iincr(node->ptr5);
      } else {
	if (!is_vector(RIGHT))
	  esubtract(node, RIGHT->index, node->ptr2);
	rbr();
      }
    }
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    break;
  }
}

/*
	gendecode -
		code generation routines for both the inner portion of
		inner product and for decode
		with decode the op is APLC_TIMES
*/
void
gendecode(struct node * node, enum pmodes mode, int top)
{
  struct codetree *savetree;

/*
	ptr1 - type
	ptr2 - rank
	ptr3 - shape
	ptr6 - decode intermediate result register
	ptr7 - result
	ptr8 - left result register
	ptr9 - right result register
*/
  switch (mode) {
  case SHAPE:
    adjdcls(node);
    adjdcls(STORE); /* sws */
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);

    /* sws */
    if (node->nodetype == DECODE) 
      copychild(STORE, LEFT, 1, 0, 0);

    if (!(node->n.info & TYPEKNOWN))
      dsfunt(node->optype, node, LEFT, RIGHT, node->ptr1);

    if (!(node->n.info & SHAPEKNOWN)) {
      rkeq(node, node->ptr2);
      printf("aplc_innershape(&mp%d, ", node->ptr3);
      lrnsrrns(LEFT, RIGHT);
      rpseminl();
      node->c.shape = gicn(memptr, node->ptr3, APLC_INT);
    }
    break;

  case COMBINE:
    /* sws  initialize ptr6, decode only */
    /*    identity(node->optype, node->ptr6, node); */
/*
    savetree = LEFT->c.values;
    identity(node->optype, node->ptr6, LEFT); 
    LEFT->c.values = savetree;
*/
    identity(node->optype, node->ptr6, STORE); 
    break;

  case VALUE:
    /* compute the two values */
    if (node->nodetype == DECODE) {

      /*---
        do:
           node = ptr7 = ptr6  * right
        to do this we put ptr6 in node
        */
      /* note ptr6 is initialized to 1 in inner above */
      savetree = LEFT->c.values;
      if (LEFT->n.info & TYPEKNOWN) {
	/* LEFT->c.values = gicn(resptr, node->ptr6, rtype(node)); */
	LEFT->c.values = gicn(resptr, node->ptr6, rtype(LEFT));
      }
      else {
	/* sws  use dummy type */
	LEFT->c.values = gicn(resptr, node->ptr6, APLC_REAL);
      }
      switchbox(RIGHT, VALUE, 0);
#if SFUNSDEBUG
      printf("/* gendecode */");
#endif
      dsfunv(node->optype, node, LEFT, RIGHT,
	  node->ptr7, node->ptr8, node->ptr9);
      LEFT->c.values = savetree;
      resinreg(node, node->ptr7);

      /*--
        now we do:
          ptr6 = ptr6 * left
         note this means again putting ptr6 in node
	 note this should keep the type of left, so use store
         */
/*
      savetree = node->c.values;
*/
     /* if (node->n.info & TYPEKNOWN) { */
      if (LEFT->n.info & TYPEKNOWN) {
	/* node->c.values = gicn(resptr, node->ptr6, rtype(node)); */
/*	node->c.values = gicn(resptr, node->ptr6, rtype(LEFT)); */
	STORE->c.values = gicn(resptr, node->ptr6, rtype(LEFT));
      }
      else {
	/* sws  use dummy type */
/*	node->c.values = gicn(resptr, node->ptr6, APLC_REAL);*/
	STORE->c.values = gicn(resptr, node->ptr6, APLC_REAL);
      }
      switchbox(LEFT, VALUE, 0);
/*
      adsfun(node->optype, node, LEFT, node->ptr6);
      node->c.values = savetree;
*/
      adsfun(node->optype, STORE, LEFT, node->ptr6);
/*      node->c.values = savetree;*/


    } else {
      /* node = left op right */
      switchbox(LEFT, VALUE, 0);
      switchbox(RIGHT, VALUE, 0);
#if SFUNSDEBUG
      printf("/* gendecode2 */");
#endif
      dsfunv(node->optype, node, LEFT, RIGHT,
	  node->ptr7, node->ptr8, node->ptr9);
    }
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    if (!(node->n.info & SHAPEKNOWN)) {
#ifdef DEBUGFREE
      printf("/* -- decode finish */\n");
#endif
      mpfree_nots(node->ptr3, node->ptr2);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
  }
}

/*
	geninner -
		generate code for both inner product and decode
                with decode, the op is APLC_PLUS
                monadic 
		inner right is innerchild (decode)
*/

/* 	macros to access the grandchildren */
#define RIGHTRIGHT (RIGHT->right)
#define RIGHTLEFT (RIGHT->left)

#define no_index(node) (is_scalar(node) || is_vector(node) \
	|| (node->n.info & NOINDEX))

void
geninner(struct node * node, enum pmodes mode, int top)
{
/*
	ptr1 -type, shared with child
	ptr2 - s sub i for right child of right child
	ptr3 - e sub i for right child of right child
	ptr4 - e sub i * (s sub i - 1)
	ptr6 - final result
*/
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    if (!(node->n.info & TYPEKNOWN))
      dsfunt(node->optype, node, RIGHT, RIGHT, node->ptr1);
    copychild(node, RIGHT, 0, 1, 1);

    /* now compute extent of inner loop, and axis values */
    axies(RIGHT, NILP, RIGHTRIGHT, 0, node->ptr3, node->ptr2);
    if (is_scalar(RIGHTRIGHT))
      axies(node, NILP, RIGHTLEFT, 0, 0, node->ptr2);
    else if (!(RIGHTRIGHT->n.info & RANKKNOWN)) {
      printf("if (0 == ");
      ctgen(RIGHTRIGHT->c.rank);
      printf(") {\n");
      axies(node, NILP, RIGHTLEFT, 0, 0, node->ptr2);
      rbr();
    }
    idecr(node->ptr2);
    iopi(node->ptr4, node->ptr2, "*", node->ptr3);
    break;

  case COMBINE:
    break;

  case VALUE:

    /* compute base values for start of loop */
    if (!(no_index(RIGHTRIGHT) && no_index(RIGHTLEFT)))
      divmod(node->index, node->ptr3,
	  RIGHTLEFT->index, RIGHTRIGHT->index);
    if (!no_index(RIGHTLEFT))
      printf("i%d = i%d * ( i%d + 1 ) + i%d;\n", RIGHTLEFT->index,
	  RIGHTLEFT->index, node->ptr2, node->ptr2);
    if (!no_index(RIGHTRIGHT))
      printf("i%d += i%d;\n", RIGHTRIGHT->index, node->ptr4);

    identity(node->optype, node->ptr6, node);

    if (RIGHT->nodetype == DECODE) {
    /* sws  initialize intermediate result value to 1.
       do this in gendecode to get type right.
      identity(RIGHT->optype, RIGHT->ptr6, RIGHT);
       only use of combine so far:
      */
      switchbox(RIGHT, COMBINE, 0);
    }

    /* generate loop for values */
    isloop(RIGHT->ptr5, node->ptr2);
    switchbox(RIGHT, VALUE, 0);
    adsfun(node->optype, node, RIGHT, node->ptr6);

    /* decrement index values for right and left side */
    if (!no_index(RIGHTLEFT))
      idecr(RIGHTLEFT->index);
    if (!no_index(RIGHTRIGHT))
      esubtract(RIGHT, RIGHTRIGHT->index, node->ptr3);

    rbr();
    break;

  case FINISH:
    /* sws call the next branch */
    switchbox(RIGHT, FINISH, 0);
    break;

  }
}

/* end  */

