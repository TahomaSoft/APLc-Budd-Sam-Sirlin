/* stub for linking */
extern int 
main(void)
{
  return 1;
}
