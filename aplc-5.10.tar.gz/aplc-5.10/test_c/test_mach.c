/* test/print default machine numbers */
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <float.h>
void
main(void)
{
  printf("imin %d\n", LONG_MIN);
  printf("imax %d\n", LONG_MAX);

  printf("eps = %30.16g\n", DBL_EPSILON);
  printf("xmin = %30.16g\n", DBL_MIN);
  printf("xmax = %30.16g\n", DBL_MAX);

  printf("rand max %d\n", RAND_MAX);
}
