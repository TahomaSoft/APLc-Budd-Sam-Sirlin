
void
main(void)
{
  int fw=5, w=10, d=4;
  char pad[] = "00000000000000000000";
  
  printf("%*d.%1.*s", fw, 9, d, pad);

}

