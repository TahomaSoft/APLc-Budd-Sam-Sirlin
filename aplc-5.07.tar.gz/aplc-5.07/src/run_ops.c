/* run_ops.c

	APL Compiler

        sam sirlin

	Run time system
	some functions

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "aplc.h"

/* ------------------*/
/* conversion from complex <-> real arrays */

/* monadic versions */
/* convert complex to real array */
extern void 
aplc_az(struct trs_struct * res, struct trs_struct * right)
{
  int i,j,n,rk;
  union mp_struct mptmp;

  switch (right->type) {
  default:
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_CHAR:
    /* no change ... */
    aplc_duptrs(res, right);
    break;
  case APLC_COMPLEX:
    /* type is real */
    res->type = APLC_REAL;
    rk = right->rank;
    res->rank = rk+1;
    aplc_vectalloc(&mptmp, res->rank, APLC_INT);
    res->shape = mptmp.ip;
    res->shape[0] = 2;
    n = 1;
    for (i=0; i<rk; i++) {
      res->shape[i+1] = right->shape[i];
      n*=right->shape[i];
    }
    res->size = 2*n;
    aplc_vectalloc(&mptmp, 2*n, APLC_REAL);
    res->value.rp = mptmp.rp;
    for (i=0; i<n; i++) {
      res->value.rp[i] = right->value.zp[0][i];
      res->value.rp[i+n] = right->value.zp[1][i];
    }
    break;
  case APLC_QUAT:
    res->type = APLC_REAL;
    rk = right->rank;
    res->rank = rk+1;
    aplc_vectalloc(&mptmp, res->rank, APLC_INT);
    res->shape = mptmp.ip;
    res->shape[0] = 4;
    n = 1;
    for (i=0; i<rk; i++) {
      res->shape[i+1] = right->shape[i];
      n*=right->shape[i];
    }
    res->size = 4*n;
    aplc_vectalloc(&mptmp, 4*n, APLC_REAL);
    res->value.rp = mptmp.rp;
    for (i=0; i<n; i++) {
      res->value.rp[i] = right->value.qp[0][i];
      res->value.rp[i+n] = right->value.qp[1][i];
      res->value.rp[i+2*n] = right->value.qp[2][i];
      res->value.rp[i+3*n] = right->value.qp[3][i];
    }
  break;
  case APLC_OCT:
    res->type = APLC_REAL;
    rk = right->rank;
    res->rank = rk+1;
    aplc_vectalloc(&mptmp, res->rank, APLC_INT);
    res->shape = mptmp.ip;
    res->shape[0] = 8;
    n = 1;
    for (i=0; i<rk; i++) {
      res->shape[i+1] = right->shape[i];
      n*=right->shape[i];
    }
    res->size = 8*n;
    aplc_vectalloc(&mptmp, 8*n, APLC_REAL);
    res->value.rp = mptmp.rp;
    for (i=0; i<n; i++) 
      for (j=0; j<8; j++) 
	res->value.rp[i+j*n] = right->value.op[j][i];
    break;
  }
  res->alloc_ind = APLC_ALLOC_VAL_F | APLC_ALLOC_SHAPE_F;
  return;
}

/* convert real array to complex */
extern void 
aplc_za(struct trs_struct * res, struct trs_struct * right)
{
  int i,j,m,n,rk;
  union mp_struct mptmp;

  switch (right->type) {
  case APLC_BOOL:
  case APLC_INT:
    /* convert to real */
    break;
  case APLC_REAL:
    break;
  default:
  case APLC_CHAR:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    printf("#za right type %d\n", right->type);
    aplc_error("#za domain error; scalar right");
    break;
  }
  rk = right->rank;
  if (rk < 1)
    aplc_error("#za domain error; scalar right");
  /* later allow replication ? */

  m = right->shape[0];
  res->rank = rk-1;
  aplc_vectalloc(&mptmp, res->rank, APLC_INT);
  res->shape = mptmp.ip;
  n = 1;
  for (i=0; i<rk-1; i++) {
    res->shape[i] = right->shape[i+1];
    n*=res->shape[i];
  }
  switch (m) {
  default:
    printf("[#za] right shape %d\n", m);
    aplc_error("#za domain error; right shape");
    break;
  case 2:
    res->type = APLC_COMPLEX;
    aplc_vectalloc(&mptmp, n, APLC_COMPLEX);
    res->value.zp[0] = mptmp.zp[0];
    res->value.zp[1] = mptmp.zp[1];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) {
	res->value.zp[0][i] = right->value.ip[i];
	res->value.zp[1][i] = right->value.ip[i+n]; 
      }
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) {
	res->value.zp[0][i] = right->value.rp[i];
	res->value.zp[1][i] = right->value.rp[i+n]; 
      }
      break;
    }
    break;
  case 4:
    res->type = APLC_QUAT;
    aplc_vectalloc(&mptmp, n, APLC_QUAT);
    for (j=0; j<4; j++)
      res->value.qp[j] = mptmp.qp[j];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) 
	for (j=0; j<4; j++) 
	  res->value.qp[j][i] = right->value.ip[i+j*n];
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) 
	for (j=0; j<4; j++) 
	  res->value.qp[j][i] = right->value.rp[i+j*n];
      break;
    }
    break;
  case 8:
    res->type = APLC_OCT;
    aplc_vectalloc(&mptmp, n, APLC_OCT);
    for (j=0; j<8; j++)
      res->value.op[j] = mptmp.op[j];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) 
	for (j=0; j<8; j++) 
	  res->value.op[j][i] = right->value.ip[i+j*n];
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) 
	for (j=0; j<8; j++) 
	  res->value.op[j][i] = right->value.rp[i+j*n];
      break;
    }
    break;
  }
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  res->size = aplc_vsize(res->rank, res->shape);
  return;
}

/* ------------------*/
/* dyadic versions 

   za2 ... not done yet...

*/
/* convert complex to real array 
   - left argument is which component to grab (index origin dependant)
   e.g. 1 1 2 #az 1i2 <->1 1 2 */
extern void 
aplc_az2(struct trs_struct * res, 
	 struct trs_struct *left, struct trs_struct *right)
{
  int i,j,k, n,rk;
  union mp_struct mptmp;

  /* left must be int */
  if ( (left->type != APLC_INT) &&
       (left->type != APLC_BOOL) ) {
    fprintf(aplcerr,"[aplc_az2] left type %d, ", left->type);
    aplc_error("#az domain error");
  }  
  if ( left->size < 1) {
    aplc_zilde(res);
    return;
  }

  /* setup size, space for result */
  res->type = APLC_REAL;
  rk = right->rank;
  res->rank = rk+1;
  aplc_vectalloc(&mptmp, res->rank, APLC_INT);
  res->shape = mptmp.ip;
  res->shape[0] = left->size;
  n = 1;
  for (i=0; i<rk; i++) {
    res->shape[i+1] = right->shape[i];
    n*=right->shape[i];
  }
  res->size = n*left->size;
  aplc_vectalloc(&mptmp, res->size, APLC_REAL);
  res->value.rp = mptmp.rp;

  switch (right->type) {
  default:
  case APLC_CHAR:
    aplc_error("#az domain error");
    break;
  case APLC_BOOL:
  case APLC_INT:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if (k != 0)
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.ip[i];
      }
    }
    break;
  case APLC_REAL:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if (k != 0)
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.rp[i];
      }
    }
    break;
  case APLC_COMPLEX:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if ( (k<0) || (k>1))
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.zp[k][i];
      }
    }
    break;
  case APLC_QUAT:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if ( (k<0) || (k>3))
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.qp[k][i];
      }
    }
    break;
  case APLC_OCT:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if ( (k<0) || (k>7))
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.op[k][i];
      }
    }
    break;
  }
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  return;
}

/* convert real array to complex 
   - left argument must match axis of right shape
     indicates what complex term each right goes to

e.g. 2 za2 1 <-> 0i1
     2 1 za2 1 0 <-> 0i1      

not done yet...

*/
extern void 
aplc_za2(struct trs_struct *res, 
	 struct trs_struct *left, struct trs_struct *right)
{
  int i,j,m,n,rk;
  union mp_struct mptmp;

  /* left must be int */
  if ( (left->type != APLC_INT) &&
       (left->type != APLC_BOOL) ) {
    fprintf(aplcerr,"[aplc_za2] left type %d, ", left->type);
    aplc_error("#za domain error");
  }  
  if ( left->size < 1) {
    aplc_zilde(res);
    return;
  }

  switch (right->type) {
  case APLC_BOOL:
  case APLC_INT:
    /* convert to real */
    break;
  case APLC_REAL:
    break;
  default:
  case APLC_CHAR:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    printf("#za right type %d\n", right->type);
    aplc_error("#za domain error; scalar right");
    break;
  }
  rk = right->rank;
  if (rk < 1)
    aplc_error("#za domain error; scalar right");
  /* later allow replication ? */

  m = right->shape[0];
  res->rank = rk-1;
  aplc_vectalloc(&mptmp, res->rank, APLC_INT);
  res->shape = mptmp.ip;
  n = 1;
  for (i=0; i<rk-1; i++) {
    res->shape[i] = right->shape[i+1];
    n*=res->shape[i];
  }
  switch (m) {
  default:
    printf("[#za] right shape %d\n", m);
    aplc_error("#za domain error; right shape");
    break;
  case 2:
    res->type = APLC_COMPLEX;
    aplc_vectalloc(&mptmp, n, APLC_COMPLEX);
    res->value.zp[0] = mptmp.zp[0];
    res->value.zp[1] = mptmp.zp[1];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) {
	res->value.zp[0][i] = right->value.ip[i];
	res->value.zp[1][i] = right->value.ip[i+n]; 
      }
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) {
	res->value.zp[0][i] = right->value.rp[i];
	res->value.zp[1][i] = right->value.rp[i+n]; 
      }
      break;
    }
    break;
  case 4:
    res->type = APLC_QUAT;
    aplc_vectalloc(&mptmp, n, APLC_QUAT);
    for (j=0; j<4; j++)
      res->value.qp[j] = mptmp.qp[j];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) 
	for (j=0; j<4; j++) 
	  res->value.qp[j][i] = right->value.ip[i+j*n];
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) 
	for (j=0; j<4; j++) 
	  res->value.qp[j][i] = right->value.rp[i+j*n];
      break;
    }
    break;
  case 8:
    res->type = APLC_OCT;
    aplc_vectalloc(&mptmp, n, APLC_OCT);
    for (j=0; j<8; j++)
      res->value.op[j] = mptmp.op[j];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) 
	for (j=0; j<8; j++) 
	  res->value.op[j][i] = right->value.ip[i+j*n];
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) 
	for (j=0; j<8; j++) 
	  res->value.op[j][i] = right->value.rp[i+j*n];
      break;
    }
    break;
  }
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  res->size = aplc_vsize(res->rank, res->shape);
}

/* ------------------*/


/* sws

   function encode. for now this looks just like residue, but
   later residue should depend on #ct

   (see the iso standard ref)

   z .is a encode c

   aplc_encode(z, a, a.type, c, c.type)

   changed are z and c

   type for c may not be handled the best possible way...
   consider integer c, real a...

*/
void
aplc_encode(union res_struct *res, 
	    union res_struct *lval, int ltype, 
	    union res_struct *rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;
  double temp, templ;

  maxtype = (ltype > rtype) ? ltype : rtype;

  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_BOOL:
  case APLC_INT:
    if (lnval.i != 0) {
      res->i = rnval.i - lnval.i *
	  floor(((double) rnval.i) / ((double) lnval.i));
      rnval.i = (rnval.i - res->i) / lnval.i;
    } else {
      res->i = rnval.i;
      rnval.i = 0;
    }
    if ((rtype == APLC_INT) || (rtype == APLC_BOOL)) {
      rval->i = rnval.i;
    } else
      fprintf(aplcerr,"case error in encode\n");
    break;
  case APLC_REAL:
    if (lnval.r != 0.0) {
      /* definition, but has trouble with large r */
      /* res->r = rnval.r - lnval.r * floor(rnval.r / lnval.r); */
      /* rnval.r = (rnval.r - res->r) / lnval.r; */
      /* alternate */
      /* rnval.r = floor(rnval.r / lnval.r); */

      /* too slow!
      temp = rnval.r;
      while (temp > lnval.r)
	temp = temp - lnval.r;
      res->r = temp;
      */
      temp = floor(rnval.r / lnval.r); 
      templ = temp*lnval.r;
      if ( templ == 1.0 + templ ) {
	res->r = 0.0;
	/* this can produce fractional results - assume ok */
	rnval.r /= lnval.r;
      } else {
	res->r = rnval.r - templ;
	rnval.r = temp;
      }
    } else {
      res->r = rnval.r;
      rnval.r = 0.0;
    }
    if ((rtype == APLC_INT) || (rtype == APLC_BOOL)) {
      rval->i = (int) rnval.r;
    } else
      rval->r = rnval.r;
    break;
  default:
    aplc_error("type error for encode function");
  }
  return;
}

#define UNBOXDEBUG 0

/* see if we have a number */
extern int
aplc_isnumtype(int type)
{
  int r;
  
  r = 0;
  switch(type) {
  default:
    break;
    /* number */
  case APLC_BIT: 
  case APLC_BOOL:
  case APLC_LABEL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    r = 1;
    break;
  }
  return r;
}

/* get the max type of two given types */
extern int
aplc_maxtype(int type1, int type2)
{
  int r;

  r = APLC_ANY;
  switch(type1) {
    /* unknown */
  default:
  case APLC_UNDEF:
  case APLC_UKTYPE: 
    /* any */
  case APLC_ANY:
    break;

    /* number */
  case APLC_BIT: 
  case APLC_BOOL:
  case APLC_LABEL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    if (aplc_isnumtype(type2)) {
      r = max(type1, type2);
      if (r == APLC_LABEL)
	r = APLC_INT;
    }
    break;

    /* character */
  case APLC_CHAR:
    if (type2 == APLC_CHAR)
      r = APLC_CHAR;
    break;

    /* boxed */
  case APLC_BOXED:
    if (type2 == APLC_BOXED)
      r = APLC_CHAR;
    break;
  }
  return r;
}

/* unbox right argument */
extern void
aplc_unbox(struct trs_struct *res, struct trs_struct *right)
{
  int i,j,k;
  int type;
  int rankmax;
  union mp_struct mptmp;
  int *si;
  struct trs_struct resv1, resv2, ress;

#if UNBOXDEBUG
  printf(">right=");
  aplc_print_trs(right);
#endif

  switch(right->type) {
  default:
    /* not boxed - just return right */
    aplc_copytrs(res, right);
    break;
  case APLC_BOXED:
    if (right->rank == 0) {
      /* scalar - just remove the box */
      aplc_copytrs(res, &right->value.trsp[0]);
    } else {
      /* get max type */
      type = right->value.trsp[0].type;
      rankmax = right->value.trsp[0].rank;
      for (i=1; i<right->size; i++) {
	/* ignore type of 0 size things */
	if (0 < right->value.trsp[i].size)
	  type = aplc_maxtype( type, right->value.trsp[i].type);
	rankmax = max(rankmax,right->value.trsp[i].rank);
      }
      /* check type */
      if (type == APLC_ANY) {
	fprintf(aplcerr, "[aplc_unbox] type error\n"); 
	aplc_error(" domain error");
      } 

      /* get max shape */
      aplc_vectalloc(&mptmp, rankmax, APLC_INT);
      si = mptmp.ip;
      for (i=0; i<rankmax; i++)
	si[i] = 0;
      /* also reshape to max rank */
      aplc_settrs(&resv1, APLC_BOXED, right->rank, right->shape);
      aplc_talloc(&resv1);
      for (i=0; i<right->size; i++) {
	aplc_copytrs(&resv1.value.trsp[i], &right->value.trsp[i]);
	k = rankmax - right->value.trsp[i].rank;
	/* printf("i %d, rankmax %d, rank %d, k %d\n", i, rankmax,
	   right->value.trsp[i].rank, k);*/
	aplc_vectalloc(&mptmp, rankmax, APLC_INT);
	for (j=0; j<k; j++)
	  mptmp.ip[j] = 1;
	for (j=0; j<right->value.trsp[i].rank; j++) {
	  si[k+j] = max(si[k+j], right->value.trsp[i].shape[j]);
	  mptmp.ip[k+j] = right->value.trsp[i].shape[j];
	}
	resv1.value.trsp[i].rank = rankmax;
	if (resv1.value.trsp[i].alloc_ind & APLC_ALLOC_SHAPE_F)
	  aplc_free(resv1.value.trsp[i].shape);
	resv1.value.trsp[i].shape = mptmp.ip;
	resv1.value.trsp[i].alloc_ind |= APLC_ALLOC_SHAPE_F;
      }      

      /* adjust type of any 0 size entries */
      for (i=0; i<resv1.size; i++) {
	if (resv1.value.trsp[i].size <1) {
	  resv1.value.trsp[i].type = type;
	}
      }
#if UNBOXDEBUG
    printf(">resv1=");
    aplc_print_trs(&resv1);
#endif

    /* now use take on each component */
    aplc_settrs(&resv2, APLC_BOXED, right->rank, right->shape);
    aplc_talloc(&resv2);
    aplc_settrs(&ress, APLC_INT, 1, &rankmax);
    /*aplc_vectalloc(&mptmp, 2, APLC_INT);
      ress.value.ip = mptmp.ip;*/
    aplc_talloc(&ress);
    for (i=0; i<rankmax; i++)
      ress.value.ip[i] = si[i];
    for (i=0; i<right->size; i++) {
      aplc_take( &resv2.value.trsp[i], &ress, &resv1.value.trsp[i]); 
    }

#if UNBOXDEBUG
    printf(">resv2=");
    aplc_print_trs(&resv2);
#endif

    /* now copy into result, ravel order */
    res->type = type;
    res->rank = right->rank + rankmax;
    aplc_vectalloc(&mptmp, res->rank, APLC_INT);
    res->shape = mptmp.ip;
    res->alloc_ind |= APLC_ALLOC_SHAPE_F;
    j = 0;
    for (i=0; i<right->rank; i++) 
      res->shape[j++] = right->shape[i];
    for (i=0; i<rankmax; i++)
      res->shape[j++] = si[i];
    res->size = aplc_vsize(res->rank, res->shape);
    aplc_talloc(res);
    k = 0;
    for (i=0; i<right->size; i++) {
      for (j=0; j<resv2.value.trsp[i].size; j++) {
	aplc_cptrsval( res, k++, &resv2.value.trsp[i], j);
      }
    }
    aplc_detalloc(&resv1);
    aplc_detalloc(&resv2);
    aplc_detalloc(&ress);
    aplc_free(si);

#if UNBOXDEBUG
    printf(">res=");
    aplc_print_trs(res);
#endif

      /*aplc_error("[aplc_unbox] non-scalar nya");*/
    }
    break;
  }
  return;
}

/* r <- a f each g b  */
extern int
aplc_each(trs_t *r,  trs_t *a, aplfp_t f, aplfp_t g, trs_t *b)
{
  int i;

  if (a->type == APLC_UKTYPE) {
    /* monadic */
    /* apply f to each component of b */
    switch(b->type) {
    default:
      /* unboxed; just apply */ 
      f(r, NULL, b);
      break;
    case APLC_BOXED:
      /* setup return */
      aplc_settrs(r, APLC_BOXED, b->rank, b->shape);
      aplc_talloc(r);
      /* now loop through components */
      for (i=0; i<r->size; i++) {
	f(&r->value.trsp[i], NULL, &b->value.trsp[i]);
      }
      break;
    }
  } else {
    /* dyadic */
    switch(a->type) {
    default:
      switch(b->type) {
      default:
	/* both unboxed; just apply */ 
	f(r, a, b);
      break;
      case APLC_BOXED:
	/* a unboxed, b boxed */
	/* setup return */
	aplc_settrs(r, APLC_BOXED, b->rank, b->shape);
	aplc_talloc(r);
	/* now loop through components */
	for (i=0; i<r->size; i++) {
	  f(&r->value.trsp[i], a, &b->value.trsp[i]);
	}
	break;
      }
      break;
    case APLC_BOXED:
      switch(b->type) {
      default:
	/* a boxed, b unboxed */ 
	/* setup return */
	aplc_settrs(r, APLC_BOXED, a->rank, a->shape);
	aplc_talloc(r);
	/* now loop through components */
	for (i=0; i<r->size; i++) {
	  f(&r->value.trsp[i], &a->value.trsp[i], b);
	}
	break;
      case APLC_BOXED:
	/* a, b boxed 
	   - could have either a scalar, else ranks, shapes must match */
	if (a->rank == 0) {
	  aplc_settrs(r, APLC_BOXED, b->rank, b->shape);
	  aplc_talloc(r);
	  /* now loop through components */
	  for (i=0; i<r->size; i++) {
	    f(&r->value.trsp[i], &a->value.trsp[0], &b->value.trsp[i]); 
	  }
	} else if (b->rank == 0) {
	  aplc_settrs(r, APLC_BOXED, a->rank, a->shape);
	  aplc_talloc(r);
	  /* now loop through components */
	  for (i=0; i<r->size; i++) {
	    f(&r->value.trsp[i], &a->value.trsp[i], &b->value.trsp[0]); 
	  }
	} else {
	  if (a->rank != b->rank)
	    aplc_error("each error; rank error");
	  if (a->size != b->size)
	    aplc_error("each error; size error");
	  aplc_settrs(r, APLC_BOXED, a->rank, a->shape);
	  aplc_talloc(r);
	  /* now loop through components */
	  for (i=0; i<r->size; i++) {
	    f(&r->value.trsp[i], &a->value.trsp[i], &b->value.trsp[i]); 
	  }
	}
	break;
      }
      break;
    }
  }
  return 0;
}

/* r <- a;b  
 (<a),<b */
extern int
aplc_link(trs_t *r,  trs_t *a, trs_t *b)
{
  int i,j,k,p,pr;
  int rank;
  int sshape[1] = {2};
  union mp_struct shape;

  if (b->type != APLC_BOXED) {
    /* (<a),<b */
    aplc_settrs(r, APLC_BOXED, 1, sshape);
    aplc_talloc(r);
    /* could use duptrs? */
    aplc_copytrs(&r->value.trsp[0], a);
    aplc_copytrs(&r->value.trsp[1], b);
  } else {
    /* (<a),b 
       left is a scalar
       rank is rank of b
       shape is shape of b except for last axis +1 */
    rank = b->rank;
    if (rank<1) {
      /* scalar b */
      rank = 1;
      aplc_vectalloc(&shape, rank, APLC_INT);
      shape.ip[0] = 2;
    } else {
      aplc_vectalloc(&shape, b->rank, APLC_INT);
      aplc_cpvec(shape.ip, b->rank, b->shape);
      shape.ip[b->rank-1]++;
    }
    aplc_settrs(r, APLC_BOXED, rank, shape.ip);
    aplc_talloc(r);
    if (r->size >0) {
      pr = 1;
      for (i=0; i<rank-1; i++)
	pr *= r->shape[i];
      i = 0;
      k = 0;
      for (p=0; p<pr;p++) {
	aplc_copytrs(&r->value.trsp[i++], a);
	for (j=1; j<shape.ip[rank-1]; j++)
	  aplc_copytrs(&r->value.trsp[i++], &b->value.trsp[k++]);
      }
    }
    aplc_free(shape.ip);
  }
  return 0;
}

/* end */

