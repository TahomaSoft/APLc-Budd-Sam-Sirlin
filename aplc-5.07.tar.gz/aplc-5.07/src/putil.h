/*
	APL Compiler

	print utilities
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_PUTIL_H
#define _APLC_PUTIL_H

/* some miscellaneous stuff */

extern int types_match(int t1, int t2);

extern int check_nsrank( info_t *s1, info_t *s2);

extern void update_info_size(info_t *s);

extern int use_axis_node( int type );


/* print utilities */
extern char *str_class(class_t xx);

void prstatenode(struct statenode * code);
void prtcode(struct statenode * code);

extern void print_rkshape(FILE *fp, char *name, info_t *s);
extern char *str_ranki(info_t *s);
extern void print_rank(FILE *fp, info_t *s);

extern char *str_rank(int rank);
extern void prnrank(FILE *fp, int rank);
extern void print_shape(FILE *fp, info_t *s);

extern void print_ivec_dec(FILE *fp, int ipt, int n);


extern char *str_type_name(int type);
extern char *prtoken(int type);

extern void print_symtab(FILE *fp, struct symnode *syms);
extern void print_sym(FILE *fp, struct symnode *syms);

extern void print_values(FILE *fp, info_t *s);
extern void print_info(FILE *fp, info_t *s);

#endif /* _APLC_PUTIL_H */
/* end of putil.h */
