/*
	APL Compiler

	print (and other) utilities for parse stage
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.
*/

#include <stdio.h>

#include "parse.h"
#include "y_tab.h"

/* ----------------------------------------------- */

/* special check for type match */

extern int
types_match(int t1, int t2)
{
  int mat = 0;

  if (t1 == t2)
    return 1;

  switch (t1) {
  case APLC_BIT:   
  case APLC_BOOL:
  case APLC_LABEL: 
  case APLC_INT:
    switch(t2) {
    case APLC_BIT:   
    case APLC_BOOL:
    case APLC_LABEL: 
    case APLC_INT:
      mat = 1;
      break;
    default:
      break;
    }
    break;

  default:
    break;
  }

  return mat;
}


extern int
check_nsrank( info_t *s1, info_t *s2)
{
  int r1a, r2a;
  int i, j;

  /* first get non-singleton rank count */
  r1a = 0;
  for (i=0; i<s1->rank; i++)
    if ( iconsts[ s1->shape+i ] != 1)
      r1a++;
  r2a = 0;
  for (i=0; i<s2->rank; i++)
    if ( iconsts[ s2->shape+i ] != 1)
      r2a++;
  if (r1a != r2a) {
    fprintf(stderr, "[trs:check_nsrank] rank missmatch %d vs %d\n",
	    r1a, r2a);
    return 1;
  }
  /* now check shapes */
  for (i=0, j=0; i<s1->rank; i++) {
    r1a = iconsts[ s1->shape+i ];
    if ( r1a != 1) {
      r2a = -1;
      while ( (j<s2->rank) && (iconsts[ s2->shape+j ] == 1) )  
	j++;
      if (j<s2->rank)
	r2a = iconsts[s2->shape+j];
      if (r1a != r2a){
	fprintf(stderr, "[trs:check_nsrank] shape missmatch (%d)%d vs (%d)%d\n",
		i, r1a, j, r2a);
	return 1;
      }
      j++;
    }
  }
  return 0;
} 

/* update size information in an info structure, if possible */
extern void
update_info_size(info_t *s)
{
  int j;

  s->size = 1;
  if ( (s->info & RANKKNOWN) && (s->info & SHAPEKNOWN) ) {
    for (j=s->rank-1; j>=0; j--)
      s->size *= iconsts[s->shape +j];
  }
  return;
}

/* ----------------------------------------------- */

/* 
   to get through the list, we need to know which node types might use
   axis for another node

   we can't just test for a null pointer, as the axis space is a union... 
 
   */
extern int 
use_axis_node( int type )
{
  switch(type) {
  default:
    return 0;
    break;

  case COMPRESS:
  case EXPAND:
  case ROTATE:
  case CAT:
  case LAM:
  case REVERSE:
  case REDUCE:
  case SCAN:
  case SM:
    /* sm axis seems to be just ident */
  case SUBASSIGN:
    return 1;
    break;
  }
}

/* ----------------------------------------------- */

/* classes defined in psym.h */
extern char *
str_class(class_t xx)
{
  switch(xx) {
  default:
  case NOCLASS:
    return "NOCLASS";
    break;
  case GLOBAL:
    return "GLOBAL";
    break;
  case PARAM:
    return "PARAM";
    break;
  case APARAM:
    return "APARAM";
    break;
  case LABCLASS:
    return "LABCLASS";
    break;
  case LOCAL:
    return "LOCAL";
    break;
  case LFUNCTION:
    return "LFUNCTION";
    break;
  case FUNCTION:
    return "FUNCTION";
    break;
  case OPERATOR:
    return "OPERATOR";
    break;
  }
}


/* sws  error printing 1/91 */
void
prstatenode(struct statenode * code)
{
  fprintf(stderr, "  contents of statenode\n");
  fprintf(stderr, "   label= %s\n", code->label);
  fprintf(stderr, "    node.nodetype= %d\n", code->code->nodetype);
  fprintf(stderr, "    node.info= %d\n", code->code->n.info);
  fprintf(stderr, "   nextstate d= %d\n", (int) code->nextstate);
/*  (void) fprintf(stderr, "   nextstate= %s\n", (char) code->nextstate);*/
  fprintf(stderr, "   list= %s\n", code->list->name);
}

/* sws  error printing 5/91 */
void
prtcode(struct statenode * code)
{
  struct statenode *p;

  for (p = code; p != NILSTATE; p = p->nextstate) {
    fprintf(stderr, "statement\n");
    prstatenode(p);
  }
  fprintf(stderr, "end statement\n");
}

extern void
print_rkshape(FILE *fp, char *name, info_t *s)
{
  fprintf(fp, "%s rank [%s], shape = [", name, str_ranki(s));
  print_shape(fp, s);
  fprintf(fp, "]\n");
  return;
}

/* sws  string representation of rank */
extern char *
str_ranki(info_t *s)
{
  char *str;
  static char tmp[20];

  if ( s->info & RANKKNOWN) {
    if (s->rank != ANYRANK) {
      sprintf(tmp, "%d", s->rank);
      str = tmp;
    } else 
      str = "arbitrary";
  } else
    str = "unknown";
  return(str);
}

extern char *
str_rank(int rank)
{
  char *str;
  static char tmp[20];

  if (rank == NORANK)
    str = "unknown";
  else if (rank == ANYRANK)
    str = "arbitrary";
  else {
    sprintf(tmp, "%d", rank);
    str = tmp;
  }
  return(str);
}

/* sws  print out rank */
extern void
prnrank(FILE *fp, int rank)
{
  fprintf(fp, "{%s}", str_rank(rank));
  return;
}

extern void
print_rank(FILE *fp, info_t *s)
{
  fprintf(fp, "{%s}", str_ranki(s));
  return;
}

/* sws  list shape vector of node with known shape */
extern void
print_shape(FILE *fp, info_t *s)
{
  int j;

  if (s->rank > 0) {
    /* size = 1; */
    fprintf(fp, "(%d) ", s->shape);
    for (j = 0; j < s->rank; j++)
      fprintf(fp, "%d ", iconsts[s->shape + j]);
  } else
    fprintf(fp, " scalar ");
  return;
}

/* print out integer vector declaration */
extern void
print_ivec_dec(FILE *fp, int ipt, int n)
{
  int i;

  fprintf(fp, "{ ");  
  for (i=0; i<n; i++) {
    fprintf(fp, "%d", iconsts[ipt+i]);
    if (i<n-1)
      fprintf(fp,", ");
  }
  fprintf(fp, "} ");  
  return;
}

/* type strings    - must match type list in aplc.h */
static char *types[] = { "unknown type", 
			 "bit", "bool", "label", "int",
			 "real", "complex", "quaternion", "octonion",
			 "char", "boxed",
			 "any" };
/* sws  string representation of type */
extern char *
str_type_name(int type)
{
  return(types[type]);
}

/* sws
get a string representation of a parser token type */
static char tmp[50];

extern char *
prtoken(int type)
{
  char *token;

  switch (type) {
  default:
    sprintf(tmp,"[prtoken] unknown type %d",type);
    token = tmp;
    break;

  case CLASS:
    token = "{CLASS}";
    break;
  case TYPE:
    token = "{TYPE}";
    break;
  case RANK:
    token = "{RANK}";
    break;
  case DEL:
    token = "{DEL}";
    break;
  case GO:
    token = "{GO}";
    break;
  case COMMENT:
    token = "{COMMENT}";
    break;
  case COLLECT:
    token = "{COLLECT}";
    break;
  case CVEC:
    token = "{CVEC}";
    break;
  case CIVEC:
    token = "{CIVEC}";
    break;
  case CSCALAR:
    token = "{CSCALAR}";
    break;
  case CISCALAR:
    token = "{CISCALAR}";
    break;
  case CCOLLECT:
    token = "{CCOLLECT}";
    break;
  case ASSIGN:
    token = "{ASSIGN}";
    break;
  case QUADASSIGN:
    token = "{QUADASSIGN}";
    break;
  case SUBASSIGN:
    token = "{SUBASSIGN}";
    break;
  case QUAD:
    token = "{QUAD}";
    break;
  case DQUAD:
    token = "{DQUAD}";
    break;
  case QQUAD:
    token = "{QQUAD}";
    break;
  case DQQUAD:
    token = "{DQQUAD}";
    break;
  case DQUADASSIGN:
    token = "{DQUADASSIGN}";
    break;
  case QQUADASSIGN:
    token = "{QQUADASSIGN}";
    break;
  case DQQUADASSIGN:
    token = "{DQQUADASSIGN}";
    break;
  case IDENT:
    token = "{IDENT}";
    break;
  case FIDENT:
    token = "{FIDENT}";
    break;
  case OPIDENT:
    token = "{OPIDENT}";
    break;
  case UIDENT:
    token = "{UIDENT}";
    break;
  case LCON:
    token = "{LCON}";
    break;
  case SCON:
    token = "{SCON}";
    break;
  case BCON:
    token = "{BCON}";
    break;
  case ICON:
    token = "{ICON}";
    break;
  case RCON:
    token = "{RCON}";
    break;
  case ZCON:
    token = "{ZCON}";
    break;
  case QCON:
    token = "{QCON}";
    break;
  case OCON:
    token = "{OCON}";
    break;
  case NL:
    token = "{NL}";
    break;
  case LP:
    token = "{LP}";
    break;
  case RP:
    token = "{RP}";
    break;
  case LB:
    token = "{LB}";
    break;
  case RB:
    token = "{RB}";
    break;
  case CM:
    token = "{CM}";
    break;
  case SM:
    token = "{SM}";
    break;
  case COLON:
    token = "{COLON}";
    break;
  case DOT:
    token = "{DOT}";
    break;
  case MSFUN:
    token = "{MSFUN}";
    break;
  case DSFUN:
    token = "{DSFUN}";
    break;
  case OUTER:
    token = "{OUTER}";
    break;
  case INNER:
    token = "{INNER}";
    break;
  case INNERCHILD:
    token = "{INNERCHILD}";
    break;
  case DECODE:
    token = "{DECODE}";
    break;
  case SLASH:
    token = "{SLASH}";
    break;
  case BSLASH:
    token = "{BSLASH}";
    break;
  case REDUCE:
    token = "{REDUCE}";
    break;
  case EXPAND:
    token = "{EXPAND}";
    break;
  case COMPRESS:
    token = "{COMPRESS}";
    break;
  case SCAN:
    token = "{SCAN}";
    break;
  case SORT:
    token = "{SORT}";
    break;
  case GRADEUP:
    token = "{GRADEUP}";
    break;
  case GRADEDOWN:
    token = "{GRADEDOWN}";
    break;
  case EPSILON:
    token = "{EPSILON}";
    break;
  case INDEX:
    token = "{INDEX}";
    break;
  case TRANS:
    token = "{TRANS}";
    break;
  case DTRANS:
    token = "{DTRANS}";
    break;
  case REVERSE:
    token = "{REVERSE}";
    break;
  case ROTATE:
    token = "{ROTATE}";
    break;
  case TAKE:
    token = "{TAKE}";
    break;
  case DROP:
    token = "{DROP}";
    break;
  case GWTAKE:
    token = "{GWTAKE}";
    break;
  case GWDROP:
    token = "{GWDROP}";
    break;
  case RHO:
    token = "{RHO}";
    break;
  case RHORHO:
    token = "{RHORHO}";
    break;
  case RESHAPE:
    token = "{RESHAPE}";
    break;
  case SUB:
    token = "{SUB}";
    break;
  case EMPTSEMI:
    token = "{EMPTSEMI}";
    break;
  case IOTA:
    token = "{IOTA}";
    break;
  case RAVEL:
    token = "{RAVEL}";
    break;
  case CAT:
    token = "{CAT}";
    break;
  case LAM:
    token = "{LAM}";
    break;
  case ROLL:
    token = "{ROLL}";
    break;
  case DEAL:
    token = "{DEAL}";
    break;
  case ENCODE:
    token = "{ENCODE}";
    break;
  case FORMAT:
    token = "{FORMAT}";
    break;
  case DFORMAT:
    token = "{DFORMAT}";
    break;
  case EXECUTE:
    token = "{EXECUTE}";
    break;
  case LCARET:
    token = "{LCARET}";
    break;
  case RCARET:
    token = "{RCARET}";
    break;
  case BOX:
    token = "{BOX}";
    break;
  case UNBOX:
    token = "{UNBOX}";
    break;
  case LINK:
    token = "{LINK}";
    break;
  case MSOLVE:
    token = "{MSOLVE}";
    break;
  case DOMINO:
    token = "{DOMINO}";
    break;
  case AVEC:
    token = "{AVEC}";
    break;
  case TCAV:
    token = "{TCAV}";
    break;
  case TYPECON:
    token = "{TYPECON}";
    break;
  case ASYSVAR:
    token = "{ASYSVAR}";
    break;
  case SYSVAR:
    token = "{SYSVAR}";
    break;
  case DSYSFUN:
    token = "{DSYSFUN}";
    break;
  case ESYSFUN:
    token = "{ESYSFUN}";
    break;
  case MSYSFUN:
    token = "{MSYSFUN}";
    break;
  case ALPHA:
    token = "{ALPHA}";
    break;
  case OMEGA:
    token = "{OMEGA}";
    break;
  case CGOTO:
    token = "{CGOTO}";
    break;
  case CATCH:
    token = "{CATCH}";
    break;
  }
  return (token);
}

/* print out symbol table */
extern void
print_symtab(FILE *fp, struct symnode *syms)
{
  struct symnode *s;

  fprintf(fp, "Symbols (name, class, type, rank)\n");
  for (s = syms; s != (struct symnode *) 0; s = s->next) {
#if 1
    fprintf(fp, "\t%s: ", s->name);
    fprintf(fp, "%s: ", str_class(s->class));
    if (s->s.info) {
      print_info(fp, &(s->s));
      fprintf(fp, "\n");
    } else {
      fprintf(fp, "type= {%s}", str_type_name(s->s.type));
      fprintf(fp, " rank= ");
      prnrank(fp, s->s.rank);
      fprintf(fp, "\n");
    }
#else
    fprintf(fp, "\t%s: type= {%s}", s->name, str_type_name(s->s.type));
    fprintf(fp, " rank= ");
    prnrank(fp, s->s.rank);
    fprintf(fp, "\n");
#endif
  }
  return;
}

/* print out a single symbol */
extern void
print_sym(FILE *fp, struct symnode *s)
{
  /*fprintf(fp, "Symbols (name, class, type, rank)\n");*/
  fprintf(fp, "\t%s: ", s->name);
  fprintf(fp, "%s: ", str_class(s->class));
  if (s->s.info) {
    print_info(fp, &(s->s));
    fprintf(fp, "\n");
  } else {
    fprintf(fp, "type= {%s}", str_type_name(s->s.type));
    fprintf(fp, " rank= ");
    prnrank(fp, s->s.rank);
    fprintf(fp, "\n");
  }
  return;
}

/* print out known values of an info_t  */
extern void
print_values(FILE *fp, info_t *s)
{
  int rank, size, i, j;
  int shape;

  rank = s->rank;
  shape = s->shape;
  size = 1;
  for (i=0; i<rank; i++)
    size *= iconsts[shape +i];
  /*fprintf(fp, "( type %d)", s->type);*/
  switch(s->type) {
  default: 
    fprintf(fp, "unknown type %d\n", s->type);
    break;
  case APLC_BOOL:
  case APLC_INT:
    fprintf(fp, "(int)");
    for (i=0; i<size; i++)
      fprintf(fp, " %d ", iconsts[i+s->values]);
    break;
  case APLC_REAL:
    fprintf(fp, "(real)");
    for (i=0; i<size; i++) {
      /* fprintf(fp, " %g ", rconsts[i+s->values]);*/
      /*fprintf(fp, " %22.15g ", rconsts[i+s->values]);*/
      fprintf(fp, " %1.15g ", rconsts[i+s->values]);
    }
    break;    
  case APLC_COMPLEX:
    fprintf(fp, "(complex)");
    for (i=0; i<size; i++) {
      fprintf(fp, " (%1.15g, %1.15g) ", 
	      zconsts[0][i+s->values], zconsts[1][i+s->values]);
    }
    break;
  case APLC_QUAT:
    fprintf(fp, "(quat)");
    for (i=0; i<size; i++) {
      fprintf(fp, " ("); 
      for (j=0; j<4; j++) {
	fprintf(fp, "%1.15g", qconsts[j][i+s->values]);
	if (j < 3)
	  fprintf(fp, ", "); 
      }
      fprintf(fp, ") "); 
    }
    break;
  case APLC_OCT:
    fprintf(fp, "(oct)");
    for (i=0; i<size; i++) {
      fprintf(fp, " ("); 
      for (j=0; j<7; j++) {
	fprintf(fp, "%1.15g", oconsts[j][i+s->values]);
	if (j < 6)
	  fprintf(fp, ", "); 
      }
      fprintf(fp, ") "); 
    }
    break;
  case APLC_CHAR:
    fprintf(fp, "(char)");
    fprintf(fp, "[");
    for (i=0; i<size; i++)
      fprintf(fp, "%c", sconsts[i+s->values]);
    fprintf(fp, "]");
    break;    
  }
}

/* decode info and print to fp */
extern void
print_info(FILE *fp, info_t *s)
{
  fprintf(fp, " [info %o] ", s->info);

  if (s->info & TYPEKNOWN)
    fprintf(fp, " TYPEKNOWN (%s)", str_type_name(s->type));
  if (s->info & RANKKNOWN) {
    if (s->rank != ANYRANK) {
      fprintf(fp, " RANKKNOWN (");
      prnrank(fp, s->rank);
      fprintf(fp, ")");
    } else
      fprintf(fp, " ANYRANK");
  }
  if (s->info & SHAPEKNOWN) {
    fprintf(fp, " SHAPEKNOWN (");
    print_shape(fp, s);
    fprintf(fp, ")");
    fprintf(fp, " size %d",s->size);
  }
  if (s->info & SHAPEARB)
    fprintf(fp, " SHAPEARB");

  /*  if (s->info)
      fprintf(fp, "\n   ");*/
  if (s->info & TYPEDECL)
    fprintf(fp, " TYPEDECL ");
  if (s->info & RANKDECL)
    fprintf(fp, " RANKDECL ");
  if (s->info & VALUESKNOWN) {
    fprintf(fp, " VALUESKNOWN [%d]", s->values);
    fprintf(fp, " = ("); print_values(fp, s); fprintf(fp, ")"); 
  }

  if (s->info & SEQUENTIAL)
    fprintf(fp, " SEQUENTIAL");
  if (s->info & HAVEVALUE)
    fprintf(fp, " HAVEVALUE");
  if (s->info & NOINDEX)
    fprintf(fp, " NOINDEX");
  if (s->info & MERGED)
    fprintf(fp, "\n    MERGED");
  if (s->info & ASSIGNP)
    fprintf(fp, "\n    ASSIGNP");
  if (s->info & EARLYBIND)
    fprintf(fp, "\n    EARLYBIND");
  if (s->info & HAVETRS)
    fprintf(fp, "\n    HAVETRS");

  return;
}


/* end of putil.c */

