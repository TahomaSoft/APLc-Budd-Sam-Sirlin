/*
	APL Compiler

	Utility routines having to do with nodes
	tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/
# include <stdio.h>
# include <string.h>
# include "parse.h"
# include "y_tab.h"
# include "gen.h"

extern struct headnode head;

/* maxtype - return the maximum type of two types */
int 
maxtype(int ltype, int rttype)
{
  /* should check that types are legal */
  if (rttype > ltype)
    return rttype;
  return ltype;
}

/* is_icon - see if a node is an integer constant */
int 
is_icon(struct node *node)
{
    return((node->nodetype == BCON) ||
	(node->nodetype == ICON));
}

/* is_mergeable - see if a node can be merged into a single accessor */
int 
is_mergeable(struct node *node)
{
    switch(node->nodetype){
    case TRANS:
    case DTRANS:
      /* only gw cases here */
    case GWTAKE:
    case GWDROP:
    case REVERSE:
	return(1);
	break;
    default:
	return(0);
	break;
    }
}

/* rtype - return the constant known type of a node */
int
rtype(struct node * node)
{
  if (!(node->n.info & TYPEKNOWN))
    return APLC_UKTYPE;
  return node->n.type;
}

/* is_parm - see if a name is a parameter */
int 
is_parm(char *name)
{
  if (head.asvar != NILCHAR)
    if (strcmp(head.asvar, name) == 0)
      return 1;
  if (head.parm1 != NILCHAR)
    if (strcmp(head.parm1, name) == 0)
      return 1;
  if (head.parm2 != NILCHAR)
    if (strcmp(head.parm2, name) == 0)
      return 1;
  return 0;
}

/* is_assoc - see if operator is associative
   sws */
int 
is_assoc(struct node *node)
{
  enum sfuns op = node->optype;
  int t = rtype(node);

  switch(op) {
  default:
    return 0;
    break;
  case APLC_FLOOR:
  case APLC_CEIL:
    switch(t) {
    default:
      return 0;
      break;
    case APLC_BIT:
    case APLC_BOOL:
    case APLC_LABEL:
    case APLC_INT:
    case APLC_REAL:
      return 1;
      break;
    }
    break;
  case APLC_PLUS: 
  case APLC_TIMES:
    switch(t) {
    default:
      return 0;
      break;
    case APLC_BIT:
    case APLC_BOOL:
    case APLC_LABEL:
    case APLC_INT:
    case APLC_REAL:
    case APLC_COMPLEX:
    case APLC_QUAT:
      return 1;
      break; 
    }
    break;
  case APLC_AND:
  case APLC_OR: 
    switch(t) {
    default:
      return 0;
      break;
    case APLC_BIT:
    case APLC_BOOL:
      return 1;
      break; 
    }
    break;
  }
#if 0
  if (op == APLC_FLOOR || op == APLC_CEIL || 
      op == APLC_AND || op == APLC_OR )
    return(1);
#endif
  return 0;
}

/* is_commute - see if operator commutes
   sws: remove +,*, so the expected order of operations is preserved 
   * doesn't commute for quaternions or octonions
   + may not associate numerically, so order matters */
int 
is_commute(struct node *node)
{
  enum sfuns op = node->optype;
  int t = rtype(node);

  switch(op) {
  default:
    return 0;
    break;
  case APLC_FLOOR:
  case APLC_CEIL:
    switch(t) {
    default:
      return 0;
      break;
    case APLC_BIT:
    case APLC_BOOL:
    case APLC_LABEL:
    case APLC_INT:
    case APLC_REAL:
      return 1;
      break;
    }
    break;
  case APLC_PLUS: 
  case APLC_TIMES:
    switch(t) {
    default:
      return 0;
      break;
    case APLC_BIT:
    case APLC_BOOL:
    case APLC_LABEL:
    case APLC_INT:
    case APLC_REAL:
    case APLC_COMPLEX:
      return 1;
      break; 
    }
    break;
  case APLC_AND:
  case APLC_NAND:
  case APLC_OR: 
  case APLC_NOR:
    switch(t) {
    default:
      return 0;
      break;
    case APLC_BIT:
    case APLC_BOOL:
      return 1;
      break; 
    }
    break;
  }
#if 0
  if (op == APLC_FLOOR || op == APLC_CEIL || 
      op == APLC_AND || op == APLC_OR || 
      op == APLC_NAND || op == APLC_NOR)
    return(1);
#endif
  return 0;
}

/* sws
   new fn to indicate if a right identity exists */
int
has_Ridentity(enum sfuns op, struct node *node)
{
  int t = rtype(node);

  switch (op) {
  default:
    break;
  case APLC_PLUS:
  case APLC_MINUS:
  case APLC_TIMES:
  case APLC_DIVIDE:
  case APLC_EXP:
  case APLC_FACT:
  case APLC_CEIL:
  case APLC_FLOOR:
    return 1;
    break;

  case APLC_AND:
  case APLC_OR:
  case APLC_EQ:
  case APLC_NE:
    if (t==APLC_BOOL)
      return 1;
    break;
  }
  return 0;
}


/* end */


