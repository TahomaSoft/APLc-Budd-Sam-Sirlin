/*
	APL Compiler

	New leaf generation code
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include <stdio.h>
#include <string.h>
#include "parse.h"
#include "y_tab.h"
#include "gen.h"


/* genop - generate code for operator calls
   new code (sws)
	- could be niladic, monadic, or dyadic
	- could be function monadic, or dyadic

	- first just handle
	r .is a (f op) b
	r .is   (f op) b
	r .is a (f op g) b
	r .is   (f op g) b

	- and cases that don't return a value

	ptr1 - left trs
	ptr2 - right trs
	ptr3 - result trs
	ptr4 - mp for values
	ptr5 - result values
*/
void
genop(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);

    /* sws  initialize result type to APLC_UKTYPE */
    /* trsuk(node->ptr3);*/
    /* better: initialize result; slower though */
    /*inittrs(node->ptr3);*/
    inittrsn(node->namea);

    /* now expect that arguments are ccollect and are in a trs
       already that will be freed later 
       - node->ptr3
       - be sure that we use the same trs */
    if (LEFT != NILP) {
      switchbox(LEFT, SHAPE, 0);
      node->ptr1 = LEFT->ptr3;
    }
    if (RIGHT != NILP) {
      switchbox(RIGHT, SHAPE, 0);
      node->ptr2 = RIGHT->ptr3;
    }

    /* opident only */
    printf("%s(", node->namep);
    /* the assigned variable */
    printf("%c%s, ", (is_parm(node->namea) ? ' ' : '&'), node->namea);
    /* rest of operator call
       - not all these cases can happen */
    if (RIGHT != NILP) {
      if (LEFT != NILP) {
	if (node->funright != NILP) {
	  /* everything */
	  printf("&trs%d, %s, %s, &trs%d);\n", 
		 node->ptr1, 
		 node->funleft->namep,
		 node->funright->namep,
		 node->ptr2);
	} else {
	  /* no right function */
	  printf("&trs%d, %s, aplc_nullf, &trs%d);\n", 
		 node->ptr1, 
		 node->funleft->namep,
		 node->ptr2);
	}
      } else {
      /* no left value */
	if (node->funright != NILP) {
	  /* everything but left value */
	  printf("&aplc_nulltrs, %s, %s, &trs%d);\n", 
		 node->funleft->namep,
		 node->funright->namep,
		 node->ptr2);
	} else {
	  /* no left value or right function */
	  printf("&aplc_nulltrs, %s, aplc_nullf, &trs%d);\n", 
		 node->funleft->namep,
		 node->ptr2);
	}
      }
    } else {
      /* no right - can't happen */
      prerror("[genop] op with no right value"); 
    }

    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gident(node->namea, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gident(node->namea, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gident(node->namea, cshapefield, APLC_UKTYPE);
    node->c.values = gident(node->namea, cvalfield, rtype(node));

    if (!top) {
      /* only put it into a mp if we have to */
      if (rtype(node) == APLC_UKTYPE)
	leafshape(node, node->ptr4);
      else if ((node->n.info & SEQUENTIAL) && !is_scalar(node))
	leafshape(node, node->ptr4);
    }
    /* otherwise might as well use given value */
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
    if (LEFT != NILP)
      switchbox(LEFT, FINISH, 0);
    if (RIGHT != NILP)
      switchbox(RIGHT, FINISH, 0);
    /* sws   may want to free the result trs
       - should free the trs for the result, except if the previous
       node is assign, which will use the trs directly */
    if ( !(node->n.info & ASSIGNP) ) {
      /* certain scalars don't need to be freed */
      if (! declscalar(node) ) {

#ifdef DEBUGFREE
	printf("/* -- opident finish */\n");
#endif
	/*printf("aplc_detalloc(&trs%d);\n", node->ptr3);*/
#ifdef DEBUGFREE
	printf("/* -- */\n");
#endif
      }
    }
    break;
  }
}


/*
	gentcav -
		generate code for atomic vector tc components
                (terminal control)
                this is a leaf 
*/
void
gentcav(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
#if 0
    printf("/* value = %d*/\n", node->n.values);
#endif
    /* node->c.values = gicn(icnst, node->n.values, APLC_INT);*/
    node->c.values =
      gcast(castop, gicn(icnst, node->n.values, APLC_INT), rtype(node));
    break;

  case COMBINE:
    break;

  case VALUE:
    break;

  case FINISH:
    break;

  }
}

/* gentypecon -
   generate code for type constants
   this is a leaf */
void
gentypecon(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
#if 0
    printf("/* value = %d*/\n", node->n.values);
#endif
    /* node->c.values = gicn(icnst, node->n.values, APLC_INT);*/
    node->c.values = gicn(tcnst, node->n.values, APLC_INT);
    break;

  case COMBINE:
    break;

  case VALUE:
    break;

  case FINISH:
    break;
  }
}

/* end */


