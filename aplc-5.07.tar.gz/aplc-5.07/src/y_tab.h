/* A Bison parser, made from apl.y, by GNU bison 1.75.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef BISON_Y_TAB_H
# define BISON_Y_TAB_H

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     CLASS = 258,
     TYPE = 259,
     RANK = 260,
     DEL = 261,
     GO = 262,
     COMMENT = 263,
     COLLECT = 264,
     CVEC = 265,
     CIVEC = 266,
     CSCALAR = 267,
     CISCALAR = 268,
     CCOLLECT = 269,
     ASSIGN = 270,
     QUADASSIGN = 271,
     SUBASSIGN = 272,
     QUAD = 273,
     QQUAD = 274,
     QQUADASSIGN = 275,
     DQUAD = 276,
     DQQUAD = 277,
     DQUADASSIGN = 278,
     DQQUADASSIGN = 279,
     QUADLZ = 280,
     IDENT = 281,
     FIDENT = 282,
     OPIDENT = 283,
     UIDENT = 284,
     LCON = 285,
     SCON = 286,
     BCON = 287,
     ICON = 288,
     RCON = 289,
     ZCON = 290,
     QCON = 291,
     OCON = 292,
     NL = 293,
     LP = 294,
     RP = 295,
     LB = 296,
     RB = 297,
     LCB = 298,
     RCB = 299,
     CM = 300,
     SM = 301,
     COLON = 302,
     DOT = 303,
     MSFUN = 304,
     DSFUN = 305,
     OUTER = 306,
     INNER = 307,
     INNERCHILD = 308,
     DECODE = 309,
     SLASH = 310,
     BSLASH = 311,
     REDUCE = 312,
     EXPAND = 313,
     COMPRESS = 314,
     SCAN = 315,
     SORT = 316,
     GRADEUP = 317,
     GRADEDOWN = 318,
     EPSILON = 319,
     INDEX = 320,
     TRANS = 321,
     DTRANS = 322,
     REVERSE = 323,
     ROTATE = 324,
     TAKE = 325,
     DROP = 326,
     GWTAKE = 327,
     GWDROP = 328,
     RHO = 329,
     RHORHO = 330,
     RESHAPE = 331,
     SUB = 332,
     EMPTSEMI = 333,
     IOTA = 334,
     RAVEL = 335,
     CAT = 336,
     LAM = 337,
     ROLL = 338,
     DEAL = 339,
     ENCODE = 340,
     FORMAT = 341,
     DFORMAT = 342,
     EXECUTE = 343,
     LCARET = 344,
     RCARET = 345,
     BOX = 346,
     UNBOX = 347,
     LINK = 348,
     MSOLVE = 349,
     DOMINO = 350,
     AVEC = 351,
     TCAV = 352,
     TYPECON = 353,
     ASYSVAR = 354,
     SYSVAR = 355,
     DSYSFUN = 356,
     ESYSFUN = 357,
     MSYSFUN = 358,
     ALPHA = 359,
     OMEGA = 360,
     CATCH = 361,
     EACH = 362,
     CGOTO = 363
   };
#endif
#define CLASS 258
#define TYPE 259
#define RANK 260
#define DEL 261
#define GO 262
#define COMMENT 263
#define COLLECT 264
#define CVEC 265
#define CIVEC 266
#define CSCALAR 267
#define CISCALAR 268
#define CCOLLECT 269
#define ASSIGN 270
#define QUADASSIGN 271
#define SUBASSIGN 272
#define QUAD 273
#define QQUAD 274
#define QQUADASSIGN 275
#define DQUAD 276
#define DQQUAD 277
#define DQUADASSIGN 278
#define DQQUADASSIGN 279
#define QUADLZ 280
#define IDENT 281
#define FIDENT 282
#define OPIDENT 283
#define UIDENT 284
#define LCON 285
#define SCON 286
#define BCON 287
#define ICON 288
#define RCON 289
#define ZCON 290
#define QCON 291
#define OCON 292
#define NL 293
#define LP 294
#define RP 295
#define LB 296
#define RB 297
#define LCB 298
#define RCB 299
#define CM 300
#define SM 301
#define COLON 302
#define DOT 303
#define MSFUN 304
#define DSFUN 305
#define OUTER 306
#define INNER 307
#define INNERCHILD 308
#define DECODE 309
#define SLASH 310
#define BSLASH 311
#define REDUCE 312
#define EXPAND 313
#define COMPRESS 314
#define SCAN 315
#define SORT 316
#define GRADEUP 317
#define GRADEDOWN 318
#define EPSILON 319
#define INDEX 320
#define TRANS 321
#define DTRANS 322
#define REVERSE 323
#define ROTATE 324
#define TAKE 325
#define DROP 326
#define GWTAKE 327
#define GWDROP 328
#define RHO 329
#define RHORHO 330
#define RESHAPE 331
#define SUB 332
#define EMPTSEMI 333
#define IOTA 334
#define RAVEL 335
#define CAT 336
#define LAM 337
#define ROLL 338
#define DEAL 339
#define ENCODE 340
#define FORMAT 341
#define DFORMAT 342
#define EXECUTE 343
#define LCARET 344
#define RCARET 345
#define BOX 346
#define UNBOX 347
#define LINK 348
#define MSOLVE 349
#define DOMINO 350
#define AVEC 351
#define TCAV 352
#define TYPECON 353
#define ASYSVAR 354
#define SYSVAR 355
#define DSYSFUN 356
#define ESYSFUN 357
#define MSYSFUN 358
#define ALPHA 359
#define OMEGA 360
#define CATCH 361
#define EACH 362
#define CGOTO 363




#ifndef YYSTYPE
#line 198 "apl.y"
typedef union {
	char *c;
	double d;
	double z[2];
	double q[4];
	double oct[8];
	struct headnode *h;
	struct headnode *oh;
	int  i;
	enum classes l;
	struct node *n;
	enum sfuns o;
	struct symnode *s;
	struct statenode *t;
	enum sysvars v;
	} yystype;
/* Line 1281 of /usr/local/share/bison/yacc.c.  */
#line 273 "y.tab.h"
# define YYSTYPE yystype
#endif

extern YYSTYPE yylval;


#endif /* not BISON_Y_TAB_H */

