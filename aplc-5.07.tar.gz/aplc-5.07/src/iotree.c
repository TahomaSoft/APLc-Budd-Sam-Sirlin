/*
	APL compiler
		parse tree i/o utilities
		timothy a. budd

	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/
#include <stdio.h>
#include "parse.h"
#include "y_tab.h"


/* to print debug info */
#define IODEBUG 0

/* ---------------------------------------------- */
/* some global variables */
int stmtno = 0;			     /* the current statement number */
char *funname = "main";		     /* the current function name */
char *passname = "main";            /* the current program */ 

/* ---------------------------------------------- */
/* error - print error message and quit 

   list current function name and statement number as well as 
   given message
*/
extern void
error(char *c)
{
  fprintf(stderr, "error: [%s] %s:%d:%s\n", passname, funname, stmtno, c);
#if 0
  exit(1);
#else
  {/* cause a crash, to allow gdb to stop in the right place */
    int *x=0;
    * x = 1;
    exit(1);
  }
#endif
}

/* putname - print a name */
void
putname(char *c)
{
  if (c != NILCHAR)
    fputs(c, stdout);
  putchar('\n');
}

/* put function header */
void
putheader(struct headnode * head)
{
  /* sws check for 0 header pointer */
#if IODEBUG
  fprintf(stderr,"putheader: %d\n",head);
#endif
  if (head != 0) {
    fwriten((char *) head, sizeof(struct headnode), 1, stdout);
    putname(head->opname);
    putname(head->fname);
    putname(head->rfname);
    putname(head->asvar);
    putname(head->parm1);
    putname(head->parm2);
  } else
    error("putheader: null header");
}

/* sws - a safe version of gets 
   used since this originally used gets
*/
char *
gets_safe(char *c)
{
  fgets(c, MAX_NAME_LEN, stdin);
  /* unlike gets, fgets can return a newline as the last char */
  if ('\n' == c[strlen(c)-1])
    c[strlen(c)-1] = '\0';
  return(c);
}

/* getfname - get function name field */
char *
getfname(char *c)
{
  c[0] = 0;
  gets_safe(c);
  if (c[0] == '\0')
    return (NILCHAR);
  else
    return (c);
}

/* get function header */
void
gethead(struct headnode * head, 
	char *opname, char *fname, char *rfname, 
	char *asvar, char *parm1, char *parm2)
{
  freadn((char *) head, sizeof(struct headnode), 1, stdin);
  head->opname = getfname(opname);
  head->fname = getfname(fname);
  head->rfname = getfname(rfname);
  head->asvar = getfname(asvar);
  head->parm1 = getfname(parm1);
  head->parm2 = getfname(parm2);
}

/* put symbol table */
void
putsyms(struct symnode * syms)
{
  struct symnode *p;

  for (p = syms; p != 0; p = p->next) {
    if (p->name) {
      putcharn(SYMS);
      fwriten((char *) p, sizeof(struct symnode), 1, stdout);
      putname(p->name);
    }
  }
  putcharn(ESYMS);
}

/* read symbol table */
struct symnode *
getsyms(void)
{
  struct symnode *fs, *os, *cs;
  char iname[MAX_NAME_LEN];
  int c;

  fs = 0;
  os = (struct symnode *) 0;/* initialize for lint */
  while ((c = getcharn()) == SYMS) {
#if IODEBUG >1
    fprintf(stderr, "getsyms: char read is %d\n", c);
#endif
    cs = structalloc(symnode);
    freadn((char *) cs, sizeof(struct symnode), 1, stdin);
    gets_safe(iname);
#if IODEBUG >1
    fprintf(stderr,"getsyms: iname read is %s\n", iname);
#endif
    cs->name = (char *) malloc((unsigned) (1 + strlen(iname)));
    cs->next = NILSYM;
    strcpy(cs->name, iname);
    if (fs == NILSYM)
      fs = os = cs;
    else
      os->next = cs;
    os = cs;
  }
  if (c != ESYMS) {
    fprintf(stderr, "getsyms: char is %d\n", c);
    error("bad symbol table format");
  }
  return (fs);
}

/* free symbol table */
void
fresyms(struct symnode * syms)
{
  if (syms != (struct symnode *) 0) {
    if (syms->next != (struct symnode *) 0)
      fresyms(syms->next);
    free((char *) syms);
  }
}

/* put lcon (sws) */
void 
put_lcon(void)
{
  int i;

  if (lctop) {
    for (i = 0; i<lctop; i++) {
      fwriten((char *) &(lconsts[i]), sizeof(struct label_struct), 1, stdout);
      putname(lconsts[i].label_name);
    }
  }
  return;
}

/* sws */
void
get_lcon(void)
{
  char iname[MAX_NAME_LEN];
  int i;

  for (i=0; i<lctop; i++) {
    freadn((char *) &(lconsts[i]), sizeof(struct label_struct), 1, stdin);
    gets_safe(iname);
    lconsts[i].label_name = (char *) malloc((unsigned) (1 + strlen(iname)));
    strcpy(lconsts[i].label_name, iname);
  }
  return;
}

/* put constants */
void
putconsts(void)
{
  int a[7], i;

  putcharn(CONSTS);

  a[0] = strlen(sconsts);
  a[1] = lctop;
  a[2] = ictop;
  a[3] = rctop;
  a[4] = zctop;
  a[5] = qctop;
  a[6] = octop;
  fwriten((char *) a, sizeof(int), 7, stdout);
  for (i = 0; i < a[0]; i++)
    putcharn(sconsts[i]);
  put_lcon();
  if (a[2])
    fwriten((char *) iconsts, sizeof(int), (unsigned) ictop, stdout);
  if (a[3])
    fwriten((char *) rconsts, sizeof(double), (unsigned) rctop, stdout);
  if (a[4]) {
    fwriten((char *) zconsts[0], sizeof(double), (unsigned) zctop, stdout);
    fwriten((char *) zconsts[1], sizeof(double), (unsigned) zctop, stdout);
  }
  if (a[5]) {
    for(i =0; i<4; i++)
      fwriten((char *) qconsts[i], sizeof(double), 
	      (unsigned) qctop, stdout);
  }
  if (a[6]) {
    for(i =0; i<8; i++)
      fwriten((char *) oconsts[i], sizeof(double), 
	      (unsigned) octop, stdout);
  }
  return;
}

/* read constants */
extern void
rdconsts(void)
{
  int a[7], i;

  if (getcharn() != CONSTS)
    error("bad format reading constants");
  freadn((char *) a, sizeof(int), 7, stdin);
  sctop = a[0];
  lctop = a[1];
  ictop = a[2];
  rctop = a[3];
  zctop = a[4];
  qctop = a[5];
  octop = a[6];
  for (i = 0; i < sctop; i++)
    sconsts[i] = getcharn();
  sconsts[i] = 0;
  get_lcon();
  if (ictop)
    freadn((char *) iconsts, sizeof(int), (unsigned) a[2], stdin);
  if (rctop)
    freadn((char *) rconsts, sizeof(double), (unsigned) a[3], stdin);
  if (zctop) {
    freadn((char *) zconsts[0], sizeof(double), (unsigned) a[4], stdin);
    freadn((char *) zconsts[1], sizeof(double), (unsigned) a[4], stdin);
  }
  if (qctop) {
    for (i=0; i<4; i++)
      freadn((char *) qconsts[i], sizeof(double), 
	     (unsigned) a[5], stdin);
  }
  if (octop) {
    for (i=0; i<8; i++)
      freadn((char *) oconsts[i], sizeof(double), 
	     (unsigned) a[6], stdin);
  }
  return;
}

/* put out code */
void
putcode(struct statenode * code)
{
  struct statenode *p;

  stmtno = 0;
  for (p = code; p != NILSTATE; p = p->nextstate) {
    stmtno++;
    putcharn(STMT);
    fwriten((char *) &p->label, sizeof(char *), 1, stdout);
    putnode(p->code);
  }
  putcharn(ESTMT);
  return;
}

/* free storage used by code 
   - note this goes to the end first, and frees backwards  */
void
frecode(struct statenode * code)
{
  if (code->nextstate != NILSTATE)
    frecode(code->nextstate);
  frenode(code->code);
  free((char *) code);
}

/* read code */
struct statenode *
rdcode(void)
{
  struct statenode *sp, *op, *fp;
  char c;

  /* sws */
#if IODEBUG
  fprintf(stderr,"[rdcode] \n");
#endif

  fp = (struct statenode *) 0;/* initialize for lint */
  op = NILSTATE;
  while ((c = getcharn()) == STMT) {
    sp = structalloc(statenode);
    freadn((char *) &sp->label, sizeof(char *), 1, stdin);
    sp->code = innode();
    sp->nextstate = NILSTATE;
    sp->list = NILSYM;
    if (op == NILSTATE)
      op = fp = sp;
    else
      op->nextstate = sp;
    op = sp;
#if IODEBUG
    fprintf(stderr,"[rdcode] read 1 stmt\n");
#endif
  }
  if (c != ESTMT) {
    fprintf(stderr, "[rdcode] last character is %d\n", c);
    fprintf(stderr, "[rdcode] expect %d\n", ESTMT);
    error("[iotree/rdcode] bad format");
  }
  return (fp);
}

/* put out node */
void
putnode(struct node * node)
{
  fwriten((char *) node, sizeof(struct node), 1, stdout);

  switch (node->nodetype) {
  default:
    fprintf(stderr, "putnode: node type %d\n", node->nodetype);
    error("illegal node type output");

  case IDENT:
    puts(node->namep);
    break;

  case BCON:
  case ICON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case LCON:
  case SCON:
  case AVEC:
  case TCAV:
  case TYPECON:
  case QQUAD:
  case QUAD:
  case COMMENT:
    break;

  case EMPTSEMI:
    if (axisgiven(node->axis))
      putnode(node->axis);
    break;

  case REVERSE:
  case REDUCE:
  case SCAN:
    if (axisgiven(node->axis))
      putnode(node->axis);
    putnode(node->right);
    break;

  case COMPRESS:
  case EXPAND:
  case ROTATE:
  case CAT:
  case LAM:
  case CATCH:
    putnode(node->left);
    if (axisgiven(node->axis))
      putnode(node->axis);
    putnode(node->right);
    break;

  case FIDENT:
    if (LEFT != NILP)
      putnode(node->left);
    if (RIGHT != NILP)
      putnode(node->right);
    if (STORE != NILP)
      putnode(node->store);
    puts(node->namep);
    puts(node->namea);
    break;

  case OPIDENT:
    if (node->funleft != NILP)
      putnode(node->funleft);
    if (node->funright != NILP)
      putnode(node->funright);
    if (LEFT != NILP)
      putnode(node->left);
    if (RIGHT != NILP)
      putnode(node->right);
    if (STORE != NILP)
      putnode(node->store);
    puts(node->namep);
    puts(node->namea);
    break;

  case SM:
    if (LEFT != NILP)
      putnode(node->left);
    if (axisgiven(node->axis))
      putnode(node->axis);
    if (RIGHT != NILP)
      putnode(node->right);
    break;

  case ASYSVAR:
  case SYSVAR:
    if (node->left != NILP)
      putnode(node->left);
    if (node->right != NILP)
      putnode(node->right);
    break;

  case SUBASSIGN:
    putnode(node->left);
    putnode(node->right);
    putnode(node->axis);
    putnode(node->store);
    break;

  case QUADASSIGN:
  case CIVEC:
  case COLLECT:
  case CCOLLECT:
  case CISCALAR:
  case CSCALAR:
  case CVEC:
  case DQQUAD:
  case DQUAD:
  case DOMINO:
  case BOX:
  case UNBOX:
  case EXECUTE:
  case FORMAT:
  case GO:
  case INNER:
  case IOTA:
  case MSFUN:
  case MSYSFUN:
  case QQUADASSIGN:
  case RAVEL:
  case RHO:
  case RHORHO:
  case ROLL:
  case SORT:
  case TRANS:
    if (node->right != NILP)
      putnode(node->right);
    break;

  case DECODE:
  case INNERCHILD:
    if (node->left != NILP)
      putnode(node->left);
    if (node->right != NILP)
      putnode(node->right);
    if (STORE != NILP)
      putnode(node->store);
    break;

  case ASSIGN:
  case CGOTO:
  case DQUADASSIGN:
  case DEAL:
  case DFORMAT:
  case DQQUADASSIGN:
  case DROP:
  case DSFUN:
  case DSYSFUN:
  case DTRANS:
  case ENCODE:
  case EPSILON:
  case ESYSFUN:
  case INDEX:
  case LINK:
  case MSOLVE:
  case OUTER:
  case RESHAPE:
  case SUB:
  case TAKE:
  case GWTAKE:
  case GWDROP:
    putnode(node->left);
    putnode(node->right);
    break;
  }
}

/* read nodes */
struct node *
innode(void)
{
  struct node *node;
  char name[MAX_NAME_LEN];

  /* try to allocate space */
  node = structalloc(node);

  if (node == (struct node *) 0)
    error("no room for parse tree");
  /* get stuff */
  freadn((char *) node, sizeof(struct node), 1, stdin);

  switch (node->nodetype) {
  default:
    fprintf(stderr, "node type %d\n", node->nodetype);
    error("illegal node type input");

  case IDENT:
    gets_safe(name);
    node->namep = (char *) malloc((unsigned) (1 + strlen(name)));
    strcpy(node->namep, name);
    break;

  case BCON:
  case ICON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case LCON:
  case SCON:
  case AVEC:
  case TCAV:
  case TYPECON:
  case QQUAD:
  case QUAD:
  case COMMENT:
    break;

  case EMPTSEMI:
    if (axisgiven(node->axis))
      node->axis = innode();
    break;

  case REDUCE:
  case REVERSE:
  case SCAN:
    if (axisgiven(node->axis))
      node->axis = innode();
    node->right = innode();
    break;

  case COMPRESS:
  case EXPAND:
  case ROTATE:
  case CAT:
  case LAM:
  case CATCH:
    node->left = innode();
    if (axisgiven(node->axis))
      node->axis = innode();
    node->right = innode();
    break;

  case FIDENT:
    if (LEFT != NILP)
      node->left = innode();
    if (RIGHT != NILP)
      node->right = innode();
    if (STORE != NILP)
      node->store = innode();
    gets_safe(name);
    node->namep = (char *) malloc((unsigned) (1 + strlen(name)));
    strcpy(node->namep, name);
    gets_safe(name);
    node->namea = (char *) malloc((unsigned) (1 + strlen(name)));
    strcpy(node->namea, name);
    break;

  case OPIDENT:
    if (node->funleft != NILP)
      node->funleft = innode();
    if (node->funright != NILP)
      node->funright = innode();
    if (LEFT != NILP)
      node->left = innode();
    if (RIGHT != NILP)
      node->right = innode();
    if (STORE != NILP)
      node->store = innode();
    gets_safe(name);
    node->namep = (char *) malloc((unsigned) (1 + strlen(name)));
    strcpy(node->namep, name);
    gets_safe(name);
    node->namea = (char *) malloc((unsigned) (1 + strlen(name)));
    strcpy(node->namea, name);
    break;

  case SM:
    if (LEFT != NILP)
      node->left = innode();
    if (axisgiven(node->axis))
      node->axis = innode();
    if (RIGHT != NILP)
      node->right = innode();
    break;

  case ASYSVAR:
  case SYSVAR:
    if (node->left != NILP)
      node->left = innode();
    if (node->right != NILP)
      node->right = innode();
    break;

  case SUBASSIGN:
    if (node->left != NILP)
      node->left = innode();
    if (node->right != NILP)
      node->right = innode();
    node->axis = innode();
    if (STORE != NILP)
      node->store = innode();
    break;

  case QUADASSIGN:
  case CIVEC:
  case COLLECT:
  case CCOLLECT:
  case CISCALAR:
  case CSCALAR:
  case CVEC:
  case DQUAD:
  case DOMINO:
  case DQQUAD:
  case BOX:
  case UNBOX:
  case EXECUTE:
  case FORMAT:
  case GO:
  case INNER:
  case IOTA:
  case MSFUN:
  case QQUADASSIGN:
  case RHO:
  case RHORHO:
  case ROLL:
  case MSYSFUN:
  case RAVEL:
  case SORT:
  case TRANS:
    if (node->right != NILP)
      node->right = innode();
    break;

  case DECODE:
  case INNERCHILD:
    if (node->left != NILP)
      node->left = innode();
    if (node->right != NILP)
      node->right = innode();
    if (STORE != NILP)
      node->store = innode();
    break;

  case ASSIGN:
  case CGOTO:
  case DQUADASSIGN:
  case DEAL:
  case DFORMAT:
  case DQQUADASSIGN:
  case DROP:
  case DSFUN:
  case DSYSFUN:
  case DTRANS:
  case ENCODE:
  case EPSILON:
  case ESYSFUN:
  case INDEX:
  case LINK:
  case MSOLVE:
  case OUTER:
  case RESHAPE:
  case SUB:
  case TAKE:
  case GWTAKE:
  case GWDROP:
    node->left = innode();
    node->right = innode();
    break;
  }
  return (node);
}

/* free storage taken by node */
void
frenode(struct node * node)
{
#if IODEBUG
  fprintf(stderr, "[%s] %s [frenode] [%d], node %s\n", 
	  passname, funname, stmtno, prtoken(node->nodetype));
#endif
  switch (node->nodetype) {
    default:
    fprintf(stderr, "node type %d\n", node->nodetype);
    error("frenode: illegal node type freed");
    break;

  case IDENT:
  case BCON:
  case ICON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case LCON:
  case SCON:
  case AVEC:
  case TCAV:
  case TYPECON:
  case QQUAD:
  case QUAD:
  case COMMENT:
    break;

  case EMPTSEMI:
#if 0
    if (axisgiven(node->axis)) {
      fprintf(stderr,"[EMPTSEMI axis:%s]", prtoken(AXIS->nodetype)); 
      frenode(node->axis);
    }
#endif
    break;

  case REVERSE:
  case REDUCE:
  case SCAN:
    if (axisgiven(node->axis))
      frenode(node->axis);
    frenode(node->right);
    break;

  case COMPRESS:
  case EXPAND:
  case ROTATE:
  case CAT:
  case LAM:
  case CATCH:
    frenode(node->left);
    if (axisgiven(node->axis))
      frenode(node->axis);
    frenode(node->right);
    break;

  case FIDENT:
    if (LEFT != NILP)
      frenode(node->left);
    if (RIGHT != NILP)
      frenode(node->right);
    if (STORE != NILP)
      frenode(node->store);
    break;

  case OPIDENT:
    if (node->funleft != NILP)
      frenode(node->funleft);
    if (node->funright != NILP)
      frenode(node->funright);
    if (LEFT != NILP)
      frenode(node->left);
    if (RIGHT != NILP)
      frenode(node->right);
    if (STORE != NILP)
      frenode(node->store);
    break;

  case SM:
    if (LEFT != NILP) {
#if IODEBUG
      fprintf(stderr,"[SM left: %s]", prtoken(LEFT->nodetype)); 
#endif
      frenode(node->left);
    }
    /*
    if (AXIS != NILP)
      frenode(node->axis);
    */
    if (RIGHT != NILP) {
#if IODEBUG
      fprintf(stderr,"[SM right:%s]", prtoken(RIGHT->nodetype)); 
#endif
      frenode(node->right);
    }
    break;

  case ASYSVAR:
  case SYSVAR:
    if (node->left != NILP)
      frenode(node->left);
    if (node->right != NILP)
      frenode(node->right);
    break;

  case SUBASSIGN:
    frenode(node->left);
    frenode(node->right);
    frenode(node->axis);
    frenode(node->store);
    break;

  case QUADASSIGN:
  case CISCALAR:
  case CIVEC:
  case COLLECT:
  case CCOLLECT:
  case CSCALAR:
  case CVEC:
  case DQQUAD:
  case DQUAD:
  case DOMINO:
  case BOX:
  case UNBOX:
  case EXECUTE:
  case FORMAT:
  case GO:
  case INNER:
  case IOTA:
  case MSFUN:
  case MSYSFUN:
  case QQUADASSIGN:
  case RAVEL:
  case RHO:
  case RHORHO:
  case ROLL:
  case SORT:
  case TRANS:
    frenode(node->right);
    break;

  case DECODE:
    frenode(node->left);
    frenode(node->right);
    frenode(node->store);
    break;

  case ASSIGN:
  case CGOTO:
  case DQUADASSIGN:
  case DQQUADASSIGN:
  case DSFUN:
  case DEAL:
  case DFORMAT:
  case DROP:
  case DSYSFUN:
  case DTRANS:
  case ENCODE:
  case EPSILON:
  case ESYSFUN:
  case INDEX:
  case INNERCHILD:
  case LINK:
  case MSOLVE:
  case OUTER:
  case RESHAPE:
  case SUB:
  case TAKE:
  case GWTAKE:
  case GWDROP:
    frenode(node->left);
    frenode(node->right);
    break;
  }
  free((char *) node);
}

/* sws  collect code writing functions 6/91
   used in pass.c
   apl.y / yy_tab.c (parser) */
extern void
writecode(int top, struct headnode * head,
	  struct symnode * syms, struct statenode * code)
{
#ifdef CHARINT
  printf("\n");
  putcharn((char) top);
  printf("\n");
#else
  putcharn((char) top);
#endif
  putheader(head);
#if IODEBUG
  fprintf(stderr, "[writecode] %s symtab\n", funname);
  print_symtab(stderr, syms);
#endif
  putsyms(syms);
  putconsts();
  putcode(code);
  return;
}

/* sws

Test for flag to pipe intermediate results as integers rather than
characters. For dos text file mode.

The functions are used in: iotree.c, pass.c, psym.c

*/

#ifdef CHARINT
/* sws */
/* write c*n chars as ints */
void
fwriten(char *p, int n, int c, FILE * iop)
{
  int i, s;

  s = n * c;
  for (i = 0; i < s; i++) {
    /* (void) fprintf(iop,"%5d",*(p+i) ); */
    printf("%5d", *(p + i));
  }
  return;
}

/* sws */
/* put a single char as an int */
void
putcharn(char c)
{
  printf("%5d ", c);
}

/* sws */
/* read n*c chars as ints */
void
freadn(char *p, int n, int c, FILE * iop)
{
  int i, val, s;

  s = n * c;
  for (i = 0; i < s; i++) {
    /* (void) fscanf(iop,"%d", &val );*/
    scanf("%d", &val);
    *(p + i) = val;
    /* (void) fprintf(stderr,"freadn charn is %d \n",val ); */
  }
  return;
}

/* sws */
/* get a single char as an int */
int
getcharn(void)
{
  int val;

  if (scanf("%d", &val) != EOF) {
    /* (void) fprintf(stderr,"charn is %d\n",val ); */
    return (val);
  }
  return (int) EOF;
}

#endif /* #ifdef CHARINT */


/* end of iotree.c */
