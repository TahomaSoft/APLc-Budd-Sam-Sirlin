/*  psym.h 

        parser symbol table declarations
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_PSYM_H
#define _APLC_PSYM_H

#include "parse.h"

/* local */
extern struct symnode *lsymtab;
extern struct symnode *lfsymtab;
/* global */
extern struct symnode *gsymtab, *gfsymtab, *gopsymtab;

extern void reinit_local_symtab(void);
extern class_t idclass(char *name, struct symnode ** symptr);
extern struct symnode *enterid(char *name, enum classes class, 
			       int type, int rank);

#endif /* _APLC_PSYM_H */
/* end of psym.h */
