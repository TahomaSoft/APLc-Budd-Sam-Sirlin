/*
	APL compiler
		driver for internal passes
		timothy a. budd

	recognizes the following flags
		-n 	don't print out processed parse tree
				(used only on last pass)

		-idigit	set index origin to digit
		-v      verbose output off (sws)

	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/
#include <stdio.h>
#include "parse.h"

/* global variables */
int *iconsts, ic[MAXCONSTS];	       /* integer constants */
double *rconsts, rc[MAXCONSTS];	       /* real constants */
double *zconsts[2], zc[2][MAXCONSTS]; /* complex constants */
double *qconsts[4], qc[4][MAXCONSTS]; /* quaternion constants */
double *oconsts[8], oc[8][MAXCONSTS]; /* octonion constants */
char *sconsts, sc[MAXCONSTS];	       /* string constants */
struct label_struct lconsts[MAXCONSTS]; /* label constants */
int ictop, rctop, zctop, qctop, octop, sctop, lctop; /* top of arrays */
int indxorgin;			     /* index origin */
struct headnode head;		     /* header for current function */

/* local function declarations */
int main(int argc, char **argv);


/* determine the current index origin 
   - note it is assumed that this is constant
*/
extern int 
get_indexorg(void)
{
  if (indxorgin != DEFAULTINDEX)
    return indxorgin;
  /* default */
  return 1;
}



/* read parse tree in, process it, print it back out 
   main will call these fns that need to be defined:
 
   passinit() at the start
   glbvar()   on each global symbol
   doprog()   on each program (fn/op/main)
*/
int
main(int argc, char **argv)
{
  int c;
  char name[120], asvar[120], parm1[120], parm2[120];
  char opname[120], rfuname[120];
  struct statenode *code;
  struct symnode *syms;
  int i, output, verbose;

  /* sws...for debugging fprintf(stderr,"[pass]\n"); */
  output = 1;
  verbose = 1;
  indxorgin = DEFAULTINDEX;

  /* sws... */
  for (i = 1; i < argc; i++) {
    if (argv[i][0] == '-')
      switch (argv[i][1]) {
      case 'n':
	output = 0;
	break;
      case 'i':
	indxorgin = argv[i][2] - '0';
	break;
      case 'v':
	verbose = 0;
	break;
      }
  }

  /* do any required initialization */
  passinit(verbose);

 /* this kludge necessary in order to  
    insure conformable declarations for 
    constant arrays                     */
  iconsts = ic;
  rconsts = rc;

  zconsts[0] = &(zc[0][0]);
  zconsts[1] = &(zc[1][0]);
  for (i=0; i<4; i++)
    qconsts[i] = &(qc[i][0]);
  for (i=0; i<8; i++)
    oconsts[i] = &(oc[i][0]);

  sconsts = sc;

  while ((c = getcharn()) != (int) EOF) {
#if 0
    /* sws... */
    fprintf(stderr,"pass; c %d\n", c);
#endif
    switch (c) {
    case GLSYM:
      gets_safe(name);
      glbvar(name);
      if (output) {
	/* printf("%c%s\n", GLSYM, name); */
	putcharn(GLSYM);
	printf("%s\n", name);
      }
      break;

    case MNPROG:
      /* sws... fprintf(stderr,"pass: mnprog\n"); */
      gethead(&head, opname, name, rfuname, asvar, parm1, parm2);
      funname = "main";
      if (verbose)
	fprintf(stderr, "   %s\n", funname);
      syms = getsyms();
      rdconsts();
      code = rdcode();
      /* sws prtcode(code); */
      /* do the particular task */
      doprog(c, &head, syms, code);
      if (output) {
	/* sws collect this into one function */
	writecode(MNPROG, &head, syms, code);
      }
      /* sws: added these here rather than in doprog */
      fresyms(syms);
      frecode(code);
      break;

    case PROG:
      /* sws... fprintf(stderr,"pass: prog\n"); */
      gethead(&head, opname, name, rfuname, asvar, parm1, parm2);
      funname = head.fname;
      if (verbose)
	fprintf(stderr, "   %s\n", funname);
      syms = getsyms();
      rdconsts();
      code = rdcode();
      /* do the particular task */
      doprog(c, &head, syms, code);
      if (output) {
	/* sws collect this into one function */
	writecode(PROG, &head, syms, code);
      }
      /* sws */
      fresyms(syms);
      frecode(code);
      break;

    case OPPROG:
      /* sws... fprintf(stderr,"pass: prog\n"); */
      gethead(&head, opname, name, rfuname, asvar, parm1, parm2);
      funname = head.opname;
      if (verbose)
	fprintf(stderr, "   %s\n", funname);
      syms = getsyms();
      rdconsts();
      code = rdcode();
      /* do the particular task */
      doprog(c, &head, syms, code);
      if (output) {
	/* sws collect this into one function */
	writecode(OPPROG, &head, syms, code);
      }
      /* sws */
      fresyms(syms);
      frecode(code);
      break;

    case ESYMS:
      /* sws ignore extra newline */
      fprintf(stderr, "[pass] read extra end symbol table (ignoring)\n");
      break;

    default:
      fprintf(stderr, "[pass] unknown character read %d\n", c);
      exit(1);
    }
  }
  /* sws... fprintf(stderr,"[pass end]\n"); */
  exit(0);
}

/* end of pass.c */
