/*
	APL Compiler

	Very Small, but Commonly Used, Code Fragments
		(putting them together saves data space)
	tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/
#include "parse.h"
#include "gen.h"

#define ITEST 1

/* comma space */
void
commasp(void)
{
  printf(", ");
}

 /* compare tree to zero add ptr(i) if i is nonzero */
void
ctzero(struct codetree * t, int i, char *op)
{
  if (i)
    t = gmon(deref, gsfun(APLC_PLUS, t, gicn(coiptr, i, APLC_INT)));
  else
    t = gmon(deref, t);

  printf("if (");
  ctgen(t);
  printf(" %s 0)\n", op);
}

 /* *(mp.ip + i) */
void
dmppi(int m, int i)
{
  printf("*(mp%d.ip + i%d)", m, i);
}

 /* else { */
void
elsebr(void)
{
  printf("else {\n");
}

 /* i = */
void
ieq(int i)
{
#if ITEST
  if (i<1) {
    fprintf(stderr, "[ieq] bad arg i=%d\n",i);
    error("[ieq] bad arg");
  }
#endif
  printf("i%d = ", i);
}

 /* i1 = c; */
void
ieqc(int i, int c)
{
#if ITEST
  if ( (i<1) || (c<1)) {
    fprintf(stderr, "[ieqc] bad arg i=%d c=%d\n",i,c);
    error("[ieqc] bad arg");
  }
#endif
  printf("i%d = %d;\n", i, c);
}

 /* i1 = i2; */
void
ieqi(int i1, int i2)
{
  printf("i%d = i%d;\n", i1, i2);
}

 /* i = tree */
void
ieqtree(int i, struct codetree * t)
{
  ieq(i);
  ctgen(t);
  seminl();
}

 /* i++; */
void
iincr(int i)
{
  printf("i%d++;\n", i);
}

 /* i--; */
void
idecr(int i)
{
  printf("i%d--;\n", i);
}

 /* i = i op i */
void
iopi(int i1, int i2, char *op, int i3)
{
  printf("i%d = i%d %s i%d;\n", i1, i2, op, i3);
}

void
ifi(int i)
{
  printf("if (i%d)\n", i);
}

 /* if ( */
void
iflp(void)
{
  printf("if (");
}

 /* integer loop */
void
iiloop(int i1, int i2)
{
  printf("for (i%d = 0; i%d < i%d; i%d++) {\n", i1, i1, i2, i1);
}

 /* down counting loop , type s */
void
isloop(int i1, int i2)
{
  printf("for (i%d = i%d; i%d >= 0; i%d--) {\n", i1, i2, i1, i1);
}

 /* down counting loop,  minus 1 */
void
izloop(int i1, int i2)
{
  printf("for (i%d = i%d - 1; i%d >= 0; i%d--) {\n", i1, i2, i1, i1);
}

/* vectalloc(mp, i, APLC_INT) */
void
impalloc(int m, int i)
{
#if VDEBUG
  printf("/* [impalloc] vectalloc */\n");
#endif
  printf("aplc_vectalloc(&mp%d, i%d, APLC_INT);\n", m, i);
}

 /* left parenthesis */
void
lp(void)
{
  printf("(");
}

 /* lrank, lshape, rrank, rshape */
void
lrnsrrns(struct node * child1, struct node * child2)
{
  rns(child1);
  commasp();
  rns(child2);
}

 /* mp1 = mp2; */
void
mpeqmp(int m1, int m2)
{
  printf("mp%d = mp%d;\n", m1, m2);
}

 /* memfree(mp.ip) */
void
mpfree(int i)
{
  /* printf("aplc_memfree(&mp%d.ip);\n", i);*/
  printf("aplc_memfree(mp%d.ip);\n", i);
}

/* memfree(mp.ip) if not scalar 
    i is the mp ptr, r the rank ptr

    sws
*/
void
mpfree_nots(int i, int r)
{
  if (r<0) {
    fprintf(stderr, "[mpfree_nots] bad arg r = %d < 0\n",r);
    error("[mpfree_nots] bad argument");
  }
  /*printf("if(i%d != 0)\n", r);*/
  printf("if (i%d)\n", r);
  printf("aplc_memfree(mp%d.ip);\n", i);
}

/* sws 
   free the shape of trs's, being careful of scalars etc.
 */
void
trs_shape_free(int i)
{
  /* printf("free(trs%d.shape);\n", i);*/
  printf("aplc_free_shape(&trs%d);\n", i);
}

 /* *(mp + i) = */
void
mpipieq(int m, int i)
{
  printf("*(mp%d.ip + i%d) = ", m, i);
}

 /* (p / (e * s)) * sp */
void
poests(int p, int e, int s, int sp)
{
  printf("(i%d / (i%d * i%d)) * i%d", p, e, s, sp);
}

 /* prerror - print error message */
void
prerror(char *s)
{
  printf("aplc_error(\"%s\");\n", s);
}

 /* left brace */
void
lbr(void)
{
  printf("{");
}

 /* right brace */
void
rbr(void)
{
  printf("}\n");
}

 /* res = res */
void
reqr(int r1, int r2)
{
  printf("res%d = res%d;\n", r1, r2);
}

/*  rank of node = set ptri 
    ptri = 
*/
void
rkeq(struct node * node, int i)
{
  if (!(node->n.info & RANKKNOWN)) {
    ieq(i);
    node->c.rank = gicn(coiptr, i, APLC_INT);
  }
}

 /* rank, shape */
void
rns(struct node * t)
{
  if (is_scalar(t)) {
    printf("0, aplc_ivone");
  } else if ( is_vector(t) && is_singleton(t) ) {
    /* another case to do is vector: rank 1, shape 1 */
    printf("1, aplc_ivone");
  } else {
    ctgen(t->c.rank);
    commasp();
    ctgen(t->c.shape);
  }
}

 /* type, rank, shape */
void
trns(struct node * t)
{
  ctgen(t->c.type);
  commasp();
  rns(t);
}

 /* right parenthesis */
void
rp(void)
{
  printf(")");
}

 /* right parenthesis, newline */
void
rpnl(void)
{
  printf(")\n");
}

 /* right parenthesis, semicolon, newline */
void
rpseminl(void)
{
  printf(");\n");
}

 /* semicolon - newline combination */
void
seminl(void)
{
  printf(";\n");
}

 /* i = const; set index var to constant */
void
seticon(int i, int c)
{
  if (i<0)
    error("[seticon] arg < 0!");
  printf("i%d = %d;\n", i, c);
}

 /* i = 0;  set index var to zero */
void
setizero(int i)
{
  seticon(i, 0);
}

 /* mp.ip = i; */
void
setmptoi(int m, int i)
{
  printf("*mp%d.ip = i%d;\n", m, i);
}

 /* i = rank */
void
setrank(int i, struct node * node)
{
  ieq(i);
  ctgen(node->c.rank);
  seminl();
}

/* settrs */
void
settrs(int t, struct node * n)
{
  printf("aplc_settrs(&trs%d, ", t);
  trns(n);
  rpseminl();
}

/* sws 
   - builds a test that returns 1 for a singleton
   ( (rank==0) || ((rank==1)&&(shape==1)) ) */
void
singleton(struct node * node)
{
  if (node->n.info & RANKKNOWN) {
    if (rankvalue(node) == 0)
      printf("(1)");
    else if (rankvalue(node) == 1) {
      printf("(*");
      ctgen(node->c.shape);
      printf(" ==1) ");
    } else
      printf("(0)");
  } else {
    printf("((");
    ctgen(node->c.rank);
    printf(" == 0) || ((");
    ctgen(node->c.rank);
    printf(" == 1) && (*");
    ctgen(node->c.shape);
    printf(" ==1)) ) ");
  }
}

 /* *mp.ip = tree */
void
smpieqt(int i, struct codetree * t)
{
  printf("*mp%d.ip = ", i);
  ctgen(t);
  seminl();
}

 /* allocate a scalar mp vector */
void
smpalloc(int i)
{
#if VDEBUG
  printf("/* [smpalloc] vectalloc */\n");
#endif
  printf("aplc_vectalloc(&mp%d, 1, APLC_INT);\n", i);
}

 /* test reduction flag */
void
testflag(int i, int r1, int r2)
{
  ifi(i);
  printf("{i%d = 0;\nres%d = res%d;\n} else\n", i, r1, r2);
}

/* sws */
/*- builds a test that returns 1 for a scalar
  (rank==0)
*/
void
testscalar(struct node * node)
{
  if (node->n.info & RANKKNOWN) {
    if (rankvalue(node) == 0)
      printf("(1)");
    else
      printf("(0)");
  } else {
    printf("(");
    ctgen(node->c.rank);
    printf(" == 0)");
  }
}

 /* *(tree + i) */
void
trepi(struct codetree * t, int i)
{
  ctgen(gmon(deref, gsfun(APLC_PLUS, t, gicn(coiptr, i, APLC_INT))));
}

/* 
   trs.type = APLC_UKTYPE
 */
void
trsuk(int i)
{
  printf("trs%d.type = APLC_UKTYPE;\n", i);
}


/* options for trs initialization
   0 simple, fast
   1 more complete */
#define INIT_TYPE 0
/* sws
   initialize a trs structure 
   - to zilde
 */
void 
inittrs(int i)
{
#if INIT_TYPE == 0
  printf("trs%d.type = APLC_UKTYPE;\n", i);
  printf("trs%d.alloc_ind = APLC_UNALLOC;\n",i);
#else
  printf("aplc_inittrs(&trs%d);\n", i);
#endif
}

/* sws
   initialize a trs structure; named 
 */
void 
inittrsn(char *s)
{
#if INIT_TYPE == 0
  printf("%s.type = APLC_UKTYPE;\n", s);
  printf("%s.alloc_ind = APLC_UNALLOC;\n",s);
#else
  printf("aplc_inittrs(&%s);\n", s);
#endif
}

/* sws
   initialize a trs structure; named pointer
 */
void 
inittrsnp(char *s)
{
#if INIT_TYPE == 0
  printf("%s->type = APLC_UKTYPE;\n", s);
  printf("%s->alloc_ind = APLC_UNALLOC;\n",s);
#else
  printf("aplc_inittrs(%s);\n", s);
#endif
}

/*
	slightly longer than one liners
*/

/* smpval - set a values into an mpval */
int
smpval(struct node * node, int mpval)
{
  struct codetree *vtree;

  vtree = node->c.values;
  if (vtree->cop == memptr)
    return (vtree->c0.cindex);
  if (node->n.info & TYPEKNOWN)
    printf("mp%d.%s = ", mpval, mp_type_str(rtype(node)));
  /*printf("mp%d.%sp = ", mpval, res_type_str(rtype(node)));*/
  else
    printf("mp%d = ", mpval);
  ctgen(vtree);
  seminl();
  return (mpval);
}

/* fill a trs structure */
void
filtrs(int t, struct node * n)
{
  /* setup space */
  settrs(t, n);
  /* put in values */ 
  if (!is_zilde(n)) {
    /* if (n->n.info & TYPEKNOWN)*/
    if ( (n->n.info & TYPEKNOWN) &&
	 (rtype(n) != APLC_COMPLEX) &&
	 (rtype(n) != APLC_QUAT) &&
	 (rtype(n) != APLC_OCT) ) {
      printf("trs%d.value.%s = ", t, mp_type_str(rtype(n)));
      /*printf("trs%d.value.%sp = ", t, res_type_str(rtype(n)));*/
    } else
      printf("trs%d.value = ", t);
    if (n->c.values == NILTREE) {
      fprintf(stderr,"node %s\n", prtoken(n->nodetype));
      if (n->left != NILP)
	fprintf(stderr,"left %s\n", prtoken(n->left->nodetype));
      if (n->right != NILP)
	fprintf(stderr,"right %s\n", prtoken(n->right->nodetype));
      error("[filtrs] tree error; right value code doesn't exist");
    }
    ctgen(n->c.values);
    seminl();
  }
}

/* rkloop - rank loop */
void
rkloop(struct node * node, int loopvar, int rankvar)
{
  int v;
  struct codetree *t;

  if (node->n.info & RANKKNOWN) {
    v = rankvalue(node);
    if (v <= 1) {
      setizero(loopvar);
      printf("{\n");
      return;
    }
    t = gicn(icnst, v - 1, APLC_INT);
  } else {
    setrank(rankvar, node);
    t = gsfun(APLC_MINUS, gicn(coiptr, rankvar, APLC_INT),
	gicn(icnst, 1, APLC_INT));
  }
  printf("for (i%d = ", loopvar);
  ctgen(t);
  printf("; i%d >= 0; i%d--) {\n", loopvar, loopvar);
}

void
divmod(int top, int bottom, int idiv, int mod)
{
  printf("i%d = i%d - i%d * (i%d = i%d / i%d);\n",
      mod, top, bottom, idiv, top, bottom);
}

void
esubtract(struct node * node, int iindex, int e)
{
  if (node->n.info & LASTAXIS)
    printf("i%d--;\n", iindex);
  else
    printf("i%d -= i%d;\n", iindex, e);
}

