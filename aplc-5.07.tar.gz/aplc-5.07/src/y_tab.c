/* A Bison parser, made from apl.y, by GNU bison 1.75.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON	1

/* Pure parsers.  */
#define YYPURE	0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     CLASS = 258,
     TYPE = 259,
     RANK = 260,
     DEL = 261,
     GO = 262,
     COMMENT = 263,
     COLLECT = 264,
     CVEC = 265,
     CIVEC = 266,
     CSCALAR = 267,
     CISCALAR = 268,
     CCOLLECT = 269,
     ASSIGN = 270,
     QUADASSIGN = 271,
     SUBASSIGN = 272,
     QUAD = 273,
     QQUAD = 274,
     QQUADASSIGN = 275,
     DQUAD = 276,
     DQQUAD = 277,
     DQUADASSIGN = 278,
     DQQUADASSIGN = 279,
     QUADLZ = 280,
     IDENT = 281,
     FIDENT = 282,
     OPIDENT = 283,
     UIDENT = 284,
     LCON = 285,
     SCON = 286,
     BCON = 287,
     ICON = 288,
     RCON = 289,
     ZCON = 290,
     QCON = 291,
     OCON = 292,
     NL = 293,
     LP = 294,
     RP = 295,
     LB = 296,
     RB = 297,
     LCB = 298,
     RCB = 299,
     CM = 300,
     SM = 301,
     COLON = 302,
     DOT = 303,
     MSFUN = 304,
     DSFUN = 305,
     OUTER = 306,
     INNER = 307,
     INNERCHILD = 308,
     DECODE = 309,
     SLASH = 310,
     BSLASH = 311,
     REDUCE = 312,
     EXPAND = 313,
     COMPRESS = 314,
     SCAN = 315,
     SORT = 316,
     GRADEUP = 317,
     GRADEDOWN = 318,
     EPSILON = 319,
     INDEX = 320,
     TRANS = 321,
     DTRANS = 322,
     REVERSE = 323,
     ROTATE = 324,
     TAKE = 325,
     DROP = 326,
     GWTAKE = 327,
     GWDROP = 328,
     RHO = 329,
     RHORHO = 330,
     RESHAPE = 331,
     SUB = 332,
     EMPTSEMI = 333,
     IOTA = 334,
     RAVEL = 335,
     CAT = 336,
     LAM = 337,
     ROLL = 338,
     DEAL = 339,
     ENCODE = 340,
     FORMAT = 341,
     DFORMAT = 342,
     EXECUTE = 343,
     LCARET = 344,
     RCARET = 345,
     BOX = 346,
     UNBOX = 347,
     LINK = 348,
     MSOLVE = 349,
     DOMINO = 350,
     AVEC = 351,
     TCAV = 352,
     TYPECON = 353,
     ASYSVAR = 354,
     SYSVAR = 355,
     DSYSFUN = 356,
     ESYSFUN = 357,
     MSYSFUN = 358,
     ALPHA = 359,
     OMEGA = 360,
     CATCH = 361,
     EACH = 362,
     CGOTO = 363
   };
#endif
#define CLASS 258
#define TYPE 259
#define RANK 260
#define DEL 261
#define GO 262
#define COMMENT 263
#define COLLECT 264
#define CVEC 265
#define CIVEC 266
#define CSCALAR 267
#define CISCALAR 268
#define CCOLLECT 269
#define ASSIGN 270
#define QUADASSIGN 271
#define SUBASSIGN 272
#define QUAD 273
#define QQUAD 274
#define QQUADASSIGN 275
#define DQUAD 276
#define DQQUAD 277
#define DQUADASSIGN 278
#define DQQUADASSIGN 279
#define QUADLZ 280
#define IDENT 281
#define FIDENT 282
#define OPIDENT 283
#define UIDENT 284
#define LCON 285
#define SCON 286
#define BCON 287
#define ICON 288
#define RCON 289
#define ZCON 290
#define QCON 291
#define OCON 292
#define NL 293
#define LP 294
#define RP 295
#define LB 296
#define RB 297
#define LCB 298
#define RCB 299
#define CM 300
#define SM 301
#define COLON 302
#define DOT 303
#define MSFUN 304
#define DSFUN 305
#define OUTER 306
#define INNER 307
#define INNERCHILD 308
#define DECODE 309
#define SLASH 310
#define BSLASH 311
#define REDUCE 312
#define EXPAND 313
#define COMPRESS 314
#define SCAN 315
#define SORT 316
#define GRADEUP 317
#define GRADEDOWN 318
#define EPSILON 319
#define INDEX 320
#define TRANS 321
#define DTRANS 322
#define REVERSE 323
#define ROTATE 324
#define TAKE 325
#define DROP 326
#define GWTAKE 327
#define GWDROP 328
#define RHO 329
#define RHORHO 330
#define RESHAPE 331
#define SUB 332
#define EMPTSEMI 333
#define IOTA 334
#define RAVEL 335
#define CAT 336
#define LAM 337
#define ROLL 338
#define DEAL 339
#define ENCODE 340
#define FORMAT 341
#define DFORMAT 342
#define EXECUTE 343
#define LCARET 344
#define RCARET 345
#define BOX 346
#define UNBOX 347
#define LINK 348
#define MSOLVE 349
#define DOMINO 350
#define AVEC 351
#define TCAV 352
#define TYPECON 353
#define ASYSVAR 354
#define SYSVAR 355
#define DSYSFUN 356
#define ESYSFUN 357
#define MSYSFUN 358
#define ALPHA 359
#define OMEGA 360
#define CATCH 361
#define EACH 362
#define CGOTO 363




/* Copy the first part of user declarations.  */

  /* c code */
  /* since (on Sun) yacc produces old code */
#define TRADITIONAL

#include "ptree.h"

/* ansi c declararions */
/* sws  function declartions */
int main(int argc, char **argv);
void yylistf(void);
void yylistfn(void);
void yyerror(char *c);
void mnbody(struct statenode *code);
void prog( struct headnode *head, struct statenode *code);
void opprog( struct headnode *head, struct statenode *code);
void resolvelabels_main(struct statenode *code);
void check_label(struct statenode *code, int i, char *name);
void fixlabel( struct node *node, int i, char *name, 
	       int ntype, struct symnode *var);

void resolvelabels(struct statenode *code, struct label_struct lar[]);
void expect(char *str);
int yywrap(void);


#define NIL 0

#define SETATTRIBUTES {dclclass = lexscope; dcltype = APLC_UKTYPE; dclrank = NORANK;}

#if defined(SUNOS) || defined(DJPC) || defined(ST) || defined(LINUX) || defined(CYGWIN) 
/* somehow this breaks the alpha and conflicts for freebsd */
extern char yytext[];/* from lex */
#endif
#ifdef DECALPHA
#endif
#ifdef FREEBSD
extern char yytext[];/* use %array to force flex to make an array */
#endif

/*#ifdef HAVE_FLEX*/
#if 1
int yylex();
#endif

int dolist; /* flag to print listing */
int linenum; /* line number of line being parsed */
int mainlnum; /* line number in main function */
int funlnum;  /* line number in user function */
int funmode; /* 0,1,2, for null, main, user fun */
int linemode; /* 0, 1, 2 for (blank, comment), unnumbered, or real line */
int line_off = 0; /* line offset for listing */
static enum classes lexscope;   /* current lexical scope */
static struct statenode *gstmts; /* global statements */
static int errflag;             /* error indicatation flag */

static enum classes dclclass;   /* attributes given in declaration header */
static int dcltype;
static int dclrank;

 /* symbol table structures */
/*extern struct symnode *gsymtab, *symtab;*/
 /* label list */
extern struct label_struct lconsts[];
 /* lable index */
extern int lctop;

/* list file name */
static FILE *listfile;



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#ifndef YYSTYPE
#line 198 "apl.y"
typedef union {
	char *c;
	double d;
	double z[2];
	double q[4];
	double oct[8];
	struct headnode *h;
	struct headnode *oh;
	int  i;
	enum classes l;
	struct node *n;
	enum sfuns o;
	struct symnode *s;
	struct statenode *t;
	enum sysvars v;
	} yystype;
/* Line 193 of /usr/local/share/bison/yacc.c.  */
#line 377 "y.tab.c"
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif

#ifndef YYLTYPE
typedef struct yyltype
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} yyltype;
# define YYLTYPE yyltype
# define YYLTYPE_IS_TRIVIAL 1
#endif

/* Copy the second part of user declarations.  */


/* Line 213 of /usr/local/share/bison/yacc.c.  */
#line 398 "y.tab.c"

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYLTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAX (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAX)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];	\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAX;	\
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  4
#define YYLAST   2031

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  110
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  55
/* YYNRULES -- Number of rules. */
#define YYNRULES  232
/* YYNRULES -- Number of states. */
#define YYNSTATES  371

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   363

#define YYTRANSLATE(X) \
  ((unsigned)(X) <= YYMAXUTOK ? yytranslate[X] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     109,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short yyprhs[] =
{
       0,     0,     3,     5,     7,    10,    11,    13,    15,    17,
      19,    24,    29,    35,    41,    45,    49,    52,    55,    59,
      63,    66,    69,    72,    76,    79,    83,    87,    89,    93,
      95,    97,    99,   101,   103,   105,   109,   113,   116,   119,
     121,   123,   130,   137,   143,   149,   157,   165,   172,   179,
     181,   182,   185,   189,   191,   194,   196,   198,   200,   202,
     204,   206,   210,   214,   216,   219,   222,   226,   228,   232,
     237,   239,   242,   246,   249,   251,   254,   257,   260,   263,
     266,   270,   273,   276,   279,   282,   285,   288,   291,   295,
     299,   303,   308,   313,   317,   323,   329,   333,   337,   341,
     346,   351,   356,   361,   366,   370,   374,   378,   382,   386,
     390,   394,   398,   403,   407,   411,   416,   420,   424,   428,
     432,   436,   440,   443,   446,   452,   457,   462,   466,   470,
     473,   475,   477,   479,   480,   484,   486,   488,   490,   492,
     494,   496,   498,   500,   502,   507,   509,   511,   513,   515,
     520,   522,   525,   527,   530,   534,   536,   538,   540,   542,
     544,   546,   548,   550,   552,   555,   559,   560,   566,   569,
     572,   575,   579,   580,   586,   589,   592,   594,   596,   598,
     600,   602,   604,   606,   608,   611,   613,   616,   619,   622,
     624,   627,   630,   633,   636,   639,   641,   644,   647,   650,
     653,   656,   659,   662,   664,   667,   670,   673,   676,   679,
     682,   685,   688,   691,   693,   696,   699,   702,   705,   708,
     711,   714,   717,   720,   723,   726,   728,   731,   733,   735,
     737,   741,   742
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short yyrhs[] =
{
     111,     0,    -1,   112,    -1,   113,    -1,   112,   114,    -1,
      -1,   138,    -1,   131,    -1,   115,    -1,   116,    -1,   125,
      47,   139,    38,    -1,   124,    47,   139,    38,    -1,   117,
     129,   135,     6,    38,    -1,   118,   129,   135,     6,    38,
      -1,   119,    46,   123,    -1,   117,    46,   123,    -1,   119,
      38,    -1,   117,    38,    -1,   120,    46,   123,    -1,   118,
      46,   123,    -1,   120,    38,    -1,   118,    38,    -1,     6,
     121,    -1,     6,    38,   121,    -1,     6,   122,    -1,     6,
      38,   122,    -1,   123,    15,   127,    -1,   127,    -1,   123,
      15,   128,    -1,   128,    -1,    26,    -1,   124,    -1,    29,
      -1,    27,    -1,    28,    -1,   123,   123,   123,    -1,   123,
     125,   123,    -1,   123,   123,    -1,   125,   123,    -1,   123,
      -1,   125,    -1,   123,    39,   123,   123,    40,   123,    -1,
     123,    39,   123,   126,    40,   123,    -1,    39,   123,   123,
      40,   123,    -1,    39,   123,   126,    40,   123,    -1,   123,
      39,   123,   123,   123,    40,   123,    -1,   123,    39,   123,
     126,   123,    40,   123,    -1,    39,   123,   123,   123,    40,
     123,    -1,    39,   123,   126,   123,    40,   123,    -1,   130,
      -1,    -1,   130,   131,    -1,   132,   134,    38,    -1,   133,
      -1,   132,   133,    -1,     3,    -1,     4,    -1,     5,    -1,
     123,    -1,   125,    -1,   126,    -1,   134,    45,   123,    -1,
     134,    45,   125,    -1,   136,    -1,   135,   136,    -1,     1,
     109,    -1,   162,    47,   137,    -1,   137,    -1,     7,   139,
      38,    -1,     7,   139,     8,    38,    -1,   138,    -1,   139,
      38,    -1,   139,     8,    38,    -1,     8,    38,    -1,    38,
      -1,    49,   139,    -1,    45,   139,    -1,    95,   139,    -1,
      86,   139,    -1,    79,   139,    -1,    68,   140,   139,    -1,
      74,   139,    -1,    83,   139,    -1,    61,   139,    -1,    66,
     139,    -1,    88,   139,    -1,    89,   139,    -1,    90,   139,
      -1,    18,    15,   139,    -1,    25,    15,   139,    -1,    19,
      15,   139,    -1,   141,    56,   140,   139,    -1,   141,    55,
     140,   139,    -1,   146,   141,   139,    -1,   146,   141,    48,
     141,   139,    -1,   146,    51,    48,   141,   139,    -1,   142,
      15,   139,    -1,   144,    15,   139,    -1,    99,    15,   139,
      -1,   146,    18,    15,   139,    -1,   146,    19,    15,   139,
      -1,   146,    56,   140,   139,    -1,   146,    45,   140,   139,
      -1,   146,    93,   140,   139,    -1,   146,    54,   139,    -1,
     146,    95,   139,    -1,   146,    71,   139,    -1,   146,    73,
     139,    -1,   146,    85,   139,    -1,   146,    64,   139,    -1,
     146,    86,   139,    -1,   146,    79,   139,    -1,   146,    68,
     140,   139,    -1,   146,    74,   139,    -1,   146,    83,   139,
      -1,   146,    55,   140,   139,    -1,   146,    70,   139,    -1,
     146,    72,   139,    -1,   146,    66,   139,    -1,   146,   101,
     139,    -1,   146,   102,   139,    -1,   146,   106,   139,    -1,
     103,   139,    -1,   102,   139,    -1,   146,    27,    28,    27,
     139,    -1,    27,    28,    27,   139,    -1,   146,    27,    28,
     139,    -1,    27,    28,   139,    -1,   146,    27,   139,    -1,
      27,   139,    -1,    27,    -1,   146,    -1,     1,    -1,    -1,
      41,   139,    42,    -1,    49,    -1,    50,    -1,    89,    -1,
      90,    -1,   143,    -1,   124,    -1,    26,    -1,   104,    -1,
     105,    -1,   145,    41,   163,    42,    -1,   143,    -1,   143,
      -1,   147,    -1,   144,    -1,   147,    41,   163,    42,    -1,
      18,    -1,   146,    18,    -1,    19,    -1,   146,    19,    -1,
      39,   139,    40,    -1,    99,    -1,   100,    -1,    96,    -1,
      97,    -1,    98,    -1,    31,    -1,   148,    -1,   154,    -1,
     151,    -1,   149,    40,    -1,    39,    31,    38,    -1,    -1,
      39,    38,   150,    31,    38,    -1,   149,    38,    -1,   149,
      31,    -1,   152,    40,    -1,    39,   154,    38,    -1,    -1,
      39,    38,   153,   154,    38,    -1,   152,    38,    -1,   152,
     154,    -1,   155,    -1,   156,    -1,   157,    -1,   158,    -1,
     159,    -1,   160,    -1,   161,    -1,    32,    -1,   155,    32,
      -1,    33,    -1,   155,    33,    -1,   156,    33,    -1,   156,
      32,    -1,    34,    -1,   155,    34,    -1,   156,    34,    -1,
     157,    34,    -1,   157,    33,    -1,   157,    32,    -1,    35,
      -1,   155,    35,    -1,   156,    35,    -1,   157,    35,    -1,
     158,    35,    -1,   158,    34,    -1,   158,    33,    -1,   158,
      32,    -1,    36,    -1,   155,    36,    -1,   156,    36,    -1,
     157,    36,    -1,   158,    36,    -1,   159,    36,    -1,   159,
      35,    -1,   159,    34,    -1,   159,    33,    -1,   159,    32,
      -1,    37,    -1,   155,    37,    -1,   156,    37,    -1,   157,
      37,    -1,   158,    37,    -1,   159,    37,    -1,   160,    37,
      -1,   160,    36,    -1,   160,    35,    -1,   160,    34,    -1,
     160,    33,    -1,   160,    32,    -1,   162,    -1,   161,   162,
      -1,    30,    -1,   124,    -1,   164,    -1,   163,    46,   164,
      -1,    -1,   139,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short yyrline[] =
{
       0,   239,   239,   243,   244,   248,   263,   266,   267,   268,
     269,   271,   275,   283,   291,   292,   293,   295,   299,   300,
     301,   303,   307,   308,   311,   312,   315,   318,   321,   324,
     327,   328,   331,   334,   337,   340,   341,   342,   343,   344,
     345,   348,   349,   350,   351,   352,   353,   354,   355,   360,
     365,   366,   369,   372,   373,   376,   377,   378,   381,   382,
     383,   384,   385,   388,   389,   393,   394,   396,   400,   401,
     402,   406,   407,   408,   410,   415,   416,   417,   418,   419,
     420,   421,   422,   423,   424,   425,   426,   427,   428,   429,
     430,   431,   432,   433,   434,   437,   438,   439,   440,   441,
     443,   445,   447,   448,   450,   453,   455,   457,   458,   459,
     462,   465,   468,   470,   471,   473,   475,   477,   478,   480,
     482,   485,   486,   487,   488,   489,   490,   491,   492,   493,
     494,   495,   496,   499,   500,   503,   504,   505,   506,   509,
     510,   514,   515,   516,   519,   522,   525,   526,   527,   530,
     531,   532,   533,   534,   535,   536,   537,   538,   539,   540,
     541,   542,   543,   544,   547,   550,   551,   551,   553,   554,
     558,   561,   562,   562,   564,   565,   569,   570,   571,   572,
     573,   574,   575,   578,   579,   582,   583,   584,   585,   588,
     589,   590,   591,   592,   593,   596,   597,   598,   599,   600,
     601,   602,   603,   606,   607,   608,   609,   610,   611,   612,
     613,   614,   615,   618,   619,   620,   621,   622,   623,   624,
     625,   626,   627,   628,   629,   632,   633,   636,   637,   640,
     641,   644,   645
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "CLASS", "TYPE", "RANK", "DEL", "GO", 
  "COMMENT", "COLLECT", "CVEC", "CIVEC", "CSCALAR", "CISCALAR", 
  "CCOLLECT", "ASSIGN", "QUADASSIGN", "SUBASSIGN", "QUAD", "QQUAD", 
  "QQUADASSIGN", "DQUAD", "DQQUAD", "DQUADASSIGN", "DQQUADASSIGN", 
  "QUADLZ", "IDENT", "FIDENT", "OPIDENT", "UIDENT", "LCON", "SCON", 
  "BCON", "ICON", "RCON", "ZCON", "QCON", "OCON", "NL", "LP", "RP", "LB", 
  "RB", "LCB", "RCB", "CM", "SM", "COLON", "DOT", "MSFUN", "DSFUN", 
  "OUTER", "INNER", "INNERCHILD", "DECODE", "SLASH", "BSLASH", "REDUCE", 
  "EXPAND", "COMPRESS", "SCAN", "SORT", "GRADEUP", "GRADEDOWN", "EPSILON", 
  "INDEX", "TRANS", "DTRANS", "REVERSE", "ROTATE", "TAKE", "DROP", 
  "GWTAKE", "GWDROP", "RHO", "RHORHO", "RESHAPE", "SUB", "EMPTSEMI", 
  "IOTA", "RAVEL", "CAT", "LAM", "ROLL", "DEAL", "ENCODE", "FORMAT", 
  "DFORMAT", "EXECUTE", "LCARET", "RCARET", "BOX", "UNBOX", "LINK", 
  "MSOLVE", "DOMINO", "AVEC", "TCAV", "TYPECON", "ASYSVAR", "SYSVAR", 
  "DSYSFUN", "ESYSFUN", "MSYSFUN", "ALPHA", "OMEGA", "CATCH", "EACH", 
  "CGOTO", "'\\n'", "$accept", "file", "globals", "initialize", "object", 
  "function", "operator", "heading", "opheading", "headpar", "opheadpar", 
  "params", "opparams", "ident", "uident", "fident", "opident", 
  "parampart", "opparampart", "dcls", "dcllist", "dclstmt", "attributes", 
  "anattribute", "namelist", "statelist", "lstatement", "ulstatement", 
  "simplestatement", "expression", "axis", "sfun", "aterm", "progid", 
  "sub", "subid", "term", "sterm", "starray", "starrayst", "@1", "narray", 
  "narrayst", "@2", "nvec", "bvec", "ivec", "rvec", "zvec", "qvec", 
  "ovec", "lvec", "lterm", "sublist", "subele", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,    10
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,   110,   111,   112,   112,   113,   114,   114,   114,   114,
     114,   114,   115,   116,   117,   117,   117,   117,   118,   118,
     118,   118,   119,   119,   120,   120,   121,   121,   122,   122,
     123,   123,   124,   125,   126,   127,   127,   127,   127,   127,
     127,   128,   128,   128,   128,   128,   128,   128,   128,   129,
     130,   130,   131,   132,   132,   133,   133,   133,   134,   134,
     134,   134,   134,   135,   135,   136,   136,   136,   137,   137,
     137,   138,   138,   138,   138,   139,   139,   139,   139,   139,
     139,   139,   139,   139,   139,   139,   139,   139,   139,   139,
     139,   139,   139,   139,   139,   139,   139,   139,   139,   139,
     139,   139,   139,   139,   139,   139,   139,   139,   139,   139,
     139,   139,   139,   139,   139,   139,   139,   139,   139,   139,
     139,   139,   139,   139,   139,   139,   139,   139,   139,   139,
     139,   139,   139,   140,   140,   141,   141,   141,   141,   142,
     142,   143,   143,   143,   144,   145,   146,   146,   146,   147,
     147,   147,   147,   147,   147,   147,   147,   147,   147,   147,
     147,   147,   147,   147,   148,   149,   150,   149,   149,   149,
     151,   152,   153,   152,   152,   152,   154,   154,   154,   154,
     154,   154,   154,   155,   155,   156,   156,   156,   156,   157,
     157,   157,   157,   157,   157,   158,   158,   158,   158,   158,
     158,   158,   158,   159,   159,   159,   159,   159,   159,   159,
     159,   159,   159,   160,   160,   160,   160,   160,   160,   160,
     160,   160,   160,   160,   160,   161,   161,   162,   162,   163,
     163,   164,   164
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     1,     2,     0,     1,     1,     1,     1,
       4,     4,     5,     5,     3,     3,     2,     2,     3,     3,
       2,     2,     2,     3,     2,     3,     3,     1,     3,     1,
       1,     1,     1,     1,     1,     3,     3,     2,     2,     1,
       1,     6,     6,     5,     5,     7,     7,     6,     6,     1,
       0,     2,     3,     1,     2,     1,     1,     1,     1,     1,
       1,     3,     3,     1,     2,     2,     3,     1,     3,     4,
       1,     2,     3,     2,     1,     2,     2,     2,     2,     2,
       3,     2,     2,     2,     2,     2,     2,     2,     3,     3,
       3,     4,     4,     3,     5,     5,     3,     3,     3,     4,
       4,     4,     4,     4,     3,     3,     3,     3,     3,     3,
       3,     3,     4,     3,     3,     4,     3,     3,     3,     3,
       3,     3,     2,     2,     5,     4,     4,     3,     3,     2,
       1,     1,     1,     0,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     4,     1,     1,     1,     1,     4,
       1,     2,     1,     2,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     2,     3,     0,     5,     2,     2,
       2,     3,     0,     5,     2,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     2,     1,     2,     2,     2,     1,
       2,     2,     2,     2,     2,     1,     2,     2,     2,     2,
       2,     2,     2,     1,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     1,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     1,     2,     1,     1,     1,
       3,     0,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       5,     0,     0,     3,     1,   132,    55,    56,    57,     0,
       0,   150,   152,     0,   141,     0,    32,   227,   160,   183,
     185,   189,   195,   203,   213,    74,     0,     0,     0,   136,
       0,     0,   133,     0,     0,     0,     0,     0,     0,     0,
       0,   157,   158,   159,   155,   156,     0,     0,   142,   143,
       4,     8,     9,    50,    50,     0,     0,   228,     0,     7,
       0,    53,     6,     0,     0,     0,   146,   148,     0,   131,
     147,   161,     0,   163,     0,   162,   176,   177,   178,   179,
     180,   181,   182,   225,    30,    33,     0,     0,    22,    24,
      39,    31,    40,    27,    29,    73,     0,     0,     0,     0,
       0,   228,   129,   160,   172,     0,   162,    76,    75,    83,
      84,     0,     0,    81,    79,    82,    78,    85,    86,    87,
      77,     0,   123,   122,    17,     0,     0,    49,    21,     0,
       0,    16,     0,    20,     0,     0,     0,    34,    58,    59,
      60,    54,     0,     0,    71,   133,   133,     0,     0,     0,
     151,   153,     0,   133,   135,     0,     0,   133,   133,     0,
       0,   133,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   137,   138,   133,     0,     0,     0,     0,     0,     0,
     169,   168,   164,   174,   170,   228,   175,   184,   186,   190,
     196,   204,   214,   188,   187,   191,   197,   205,   215,   194,
     193,   192,   198,   206,   216,   202,   201,   200,   199,   207,
     217,   212,   211,   210,   209,   208,   218,   224,   223,   222,
     221,   220,   219,   226,    23,    25,     0,     0,     0,    37,
       0,    38,    88,    90,    89,     0,   127,   165,     0,     0,
     154,   171,     0,    80,    98,    15,   132,     0,     0,    63,
      67,    70,   225,    51,    19,     0,    14,    18,     0,     0,
      52,     0,    72,     0,     0,    96,    97,   232,     0,   229,
       0,     0,     0,   128,     0,     0,   104,     0,     0,   109,
     118,     0,   116,   106,   117,   107,   113,   111,   114,   108,
     110,     0,   105,   119,   120,   121,     0,    93,     0,     0,
       0,    39,    26,    28,     0,    35,    36,   125,     0,     0,
     134,    65,     0,     0,    64,     0,     0,    11,    10,    61,
      62,    92,    91,   144,     0,    99,   100,     0,   126,   102,
       0,   115,   101,   112,   103,     0,   149,     0,     0,     0,
       0,     0,     0,   167,   173,     0,    68,    12,    66,    13,
     230,   124,    95,    94,    43,     0,    44,     0,     0,     0,
       0,     0,    69,    47,    48,    41,     0,    42,     0,    45,
      46
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short yydefgoto[] =
{
      -1,     1,     2,     3,    50,    51,    52,    53,    54,    55,
      56,    88,    89,    90,   101,    92,   140,    93,    94,   126,
     127,    59,    60,    61,   142,   248,   249,   250,   251,    63,
     112,    64,    65,    66,    67,    68,    69,    70,    71,    72,
     238,    73,    74,   239,    75,    76,    77,    78,    79,    80,
      81,    82,    83,   268,   269
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -224
static const short yypact[] =
{
    -224,    28,   463,  -224,  -224,  -224,  -224,  -224,  -224,    30,
     -34,    50,    71,    89,  -224,   649,  -224,  -224,  -224,  -224,
    -224,  -224,  -224,  -224,  -224,  -224,  1409,  1679,   342,  -224,
    1679,  1679,    66,  1679,  1679,  1679,  1679,  1679,  1139,  1229,
    1679,  -224,  -224,  -224,   104,  -224,  1679,  1679,  -224,  -224,
    -224,  -224,  -224,     6,    15,    37,    75,    -7,    77,  -224,
      74,  -224,  -224,     4,   -33,   118,     0,   123,    84,  1925,
     109,  -224,    91,  -224,   158,  -224,   108,   167,   206,   249,
     259,   273,    18,  -224,  -224,  -224,    -8,    45,  -224,  -224,
      79,  -224,    45,  -224,  -224,  -224,  1679,  1679,  1679,   556,
    1769,   137,  -224,   116,   139,   131,   134,  -224,  -224,  -224,
    -224,  1679,  1679,  -224,  -224,  -224,  -224,  -224,  -224,  -224,
    -224,  1679,  -224,  -224,  -224,    45,   949,   181,  -224,    45,
     949,  -224,    45,  -224,    45,  1679,  1679,  -224,  -224,  -224,
    -224,  -224,   -21,   159,  -224,    66,    66,  1679,  1679,  1319,
     190,   192,  1499,    66,  -224,   162,  1679,    66,    66,  1679,
    1679,    66,  1679,  1679,  1679,  1679,  1679,  1679,  1679,  1679,
    1679,  -224,  -224,    66,  1679,  1679,  1679,  1679,  1589,  1319,
    -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,
    -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,
    -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,
    -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,
    -224,  -224,  -224,  -224,  -224,  -224,    63,    -8,    45,    45,
      45,  -224,  -224,  -224,  -224,   556,  -224,  -224,   191,   183,
    -224,  -224,   179,  -224,  -224,  -224,   121,  1679,   749,  -224,
    -224,  -224,   176,  -224,  -224,   849,  -224,  -224,   193,   194,
    -224,   154,  -224,  1679,  1679,  -224,  -224,  -224,   111,  -224,
    1679,  1679,  1859,  -224,  1679,   -39,  -224,  1679,  1679,  -224,
    -224,  1679,  -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,
    -224,  1679,  -224,  -224,  -224,  -224,   -39,  -224,   114,   -20,
      47,   110,  -224,  -224,    63,  -224,  -224,  -224,   195,   197,
    -224,  -224,     5,   198,  -224,  1049,   207,  -224,  -224,  -224,
    -224,  -224,  -224,  -224,  1319,  -224,  -224,   556,  -224,  -224,
    1679,  -224,  -224,  -224,  -224,  1679,  -224,    45,   209,    45,
     210,    86,    88,  -224,  -224,   214,  -224,  -224,  -224,  -224,
    -224,  -224,  -224,  -224,  -224,    45,  -224,    45,    45,   215,
      45,   216,  -224,  -224,  -224,  -224,    45,  -224,    45,  -224,
    -224
};

/* YYPGOTO[NTERM-NUM].  */
static const short yypgoto[] =
{
    -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,
    -224,   161,   168,   119,    -2,     3,  -223,    31,    33,   203,
    -224,   138,  -224,   201,  -224,   136,  -139,   -48,   266,    -1,
     -91,   -67,  -224,  -224,  -224,  -224,  -224,  -224,  -224,  -224,
    -224,  -224,  -224,  -224,   -25,  -224,  -224,  -224,  -224,  -224,
    -224,  -224,   -66,    93,   -50
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, parse error.  */
#define YYTABLE_NINF -232
static const short yytable[] =
{
      57,   106,   178,   300,    95,    58,    84,    91,  -140,    16,
     154,    29,   143,   345,   102,  -139,   223,   260,    84,    85,
     337,    16,   145,   146,   261,   105,   107,   108,     4,   109,
     110,    87,   113,   114,   115,   116,   117,   118,   119,   120,
     135,  -145,   144,   346,   124,   122,   123,    16,    17,   186,
     171,   172,   125,   128,   263,   264,    84,    85,    91,    16,
     252,   129,   274,   139,   252,    96,   277,   278,    86,    87,
     281,    84,   185,    84,    16,   131,    16,     6,     7,     8,
     185,   342,   291,   132,    91,    91,    97,   339,    91,    84,
      91,   137,    16,   230,   227,   232,   233,   234,   102,   236,
      84,    85,   137,    16,    98,    84,    85,   111,    16,   314,
     242,   243,    84,   133,    84,    16,   314,    16,   228,   121,
     244,   134,   180,    91,   136,   149,   358,    91,   360,   181,
      91,   182,    91,   147,   258,   259,    84,    85,   148,    16,
     187,   188,   189,   190,   191,   192,   265,   266,   267,   228,
     179,   273,  -140,   323,   237,   276,   336,   324,   279,   280,
     324,   282,   283,   284,   285,   286,   287,   288,   289,   290,
    -166,   240,   241,   292,   293,   294,   295,   297,   267,   138,
      84,    85,   252,    16,     6,     7,     8,    16,    17,   252,
      19,    20,    21,    22,    23,    24,   183,   262,   184,   193,
     194,   195,   196,   197,   198,   270,   226,   271,   330,   229,
     275,   231,    16,    17,   309,    19,    20,    21,    22,    23,
      24,   310,   308,   315,    91,    91,    91,    91,    91,   335,
     311,   317,   318,   343,   307,   344,   347,   185,   199,   200,
     201,   202,   203,   204,   245,   349,   312,   224,   254,   355,
     357,   256,   362,   257,   225,   366,   368,   130,   302,    91,
     303,   141,   321,   322,   320,   253,   255,   348,    62,   325,
     326,   328,   298,   329,   350,     0,   331,   332,     0,     0,
     333,   205,   206,   207,   208,   209,   210,     0,     0,     0,
     334,   211,   212,   213,   214,   215,   216,    91,    91,    91,
       0,     0,    91,     0,   230,   217,   218,   219,   220,   221,
     222,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   267,     0,     0,   351,     0,     0,   352,
       0,     0,     0,     0,   353,    91,     0,    91,     0,    91,
      91,     0,     0,     5,     0,   299,   301,   304,   305,   306,
       0,     0,     0,    91,     0,    91,    91,     0,    91,     0,
      11,    12,     0,     0,    91,     0,    91,    13,    14,    99,
       0,    16,    17,    18,    19,    20,    21,    22,    23,    24,
     319,    26,     0,     0,     0,     0,     0,    27,     0,     0,
       0,    28,    29,     0,     0,     0,     0,  -135,  -135,     0,
       0,     0,     0,    30,     0,     0,     0,     0,    31,     0,
      32,     0,     0,     0,     0,     0,    33,     0,   338,   340,
     229,    34,     0,   341,     0,    35,     0,     0,    36,     0,
      37,    38,    39,     0,     0,     0,     0,    40,    41,    42,
      43,    44,    45,     0,    46,    47,    48,    49,     0,     0,
       0,     0,     0,     0,     0,     0,   354,     0,   356,     0,
     359,   361,     0,    -2,     5,     0,     6,     7,     8,     9,
       0,    10,     0,     0,   363,     0,   364,   365,     0,   367,
       0,    11,    12,     0,     0,   369,     0,   370,    13,    14,
      15,     0,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,     0,     0,     0,     0,     0,    27,     0,
       0,     0,    28,    29,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    30,     0,     0,     0,     0,    31,
       0,    32,     0,     0,     0,     0,     0,    33,     0,     0,
       0,     0,    34,     0,     0,     0,    35,     0,     0,    36,
       0,    37,    38,    39,     0,     0,     0,     5,    40,    41,
      42,    43,    44,    45,  -130,    46,    47,    48,    49,     0,
       0,     0,     0,     0,    11,    12,     0,     0,     0,     0,
       0,    13,    14,    99,   100,    16,    17,    18,    19,    20,
      21,    22,    23,    24,  -130,    26,  -130,     0,  -130,     0,
       0,    27,  -130,     0,     0,    28,    29,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    30,     0,     0,
       0,     0,    31,     0,    32,     0,     0,     0,     0,     0,
      33,     0,     0,     0,     0,    34,     0,     0,     0,    35,
       0,     0,    36,     0,    37,    38,    39,     0,     0,     0,
       5,    40,    41,    42,    43,    44,    45,  -130,    46,    47,
      48,    49,     0,     0,     0,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,    99,   100,    16,    17,
      18,    19,    20,    21,    22,    23,    24,  -130,    26,     0,
       0,     0,     0,     0,    27,     0,   -33,     0,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       0,     0,     0,     0,    40,    41,    42,    43,    44,    45,
     246,    46,    47,    48,    49,   313,   247,    10,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,    99,     0,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,     0,
       0,     0,     0,     0,    27,     0,     0,     0,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       0,     0,     0,     0,    40,    41,    42,    43,    44,    45,
     246,    46,    47,    48,    49,   316,   247,    10,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,    99,     0,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,     0,
       0,     0,     0,     0,    27,     0,     0,     0,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       0,     0,     0,     0,    40,    41,    42,    43,    44,    45,
     246,    46,    47,    48,    49,     0,   247,    10,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,    99,     0,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,     0,
       0,     0,     0,     0,    27,     0,     0,     0,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       0,     0,     0,     0,    40,    41,    42,    43,    44,    45,
       5,    46,    47,    48,    49,     0,   247,    10,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,    99,     0,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,     0,
       0,     0,     0,     0,    27,     0,     0,     0,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       5,     0,     0,     0,    40,    41,    42,    43,    44,    45,
       0,    46,    47,    48,    49,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,    99,     0,    16,    17,
      18,    19,    20,    21,    22,    23,    24,     0,    26,     0,
       0,     0,     0,     0,    27,     0,     0,     0,    28,    29,
       0,     0,     0,     0,  -137,  -137,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       5,     0,     0,     0,    40,    41,    42,    43,    44,    45,
       0,    46,    47,    48,    49,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,    99,     0,    16,    17,
      18,    19,    20,    21,    22,    23,    24,     0,    26,     0,
       0,     0,     0,     0,    27,     0,     0,     0,    28,    29,
       0,     0,     0,     0,  -138,  -138,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       5,     0,     0,     0,    40,    41,    42,    43,    44,    45,
       0,    46,    47,    48,    49,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,    99,     0,    16,    17,
      18,    19,    20,    21,    22,    23,    24,     0,    26,     0,
       0,  -231,     0,     0,    27,  -231,     0,     0,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       5,     0,     0,     0,    40,    41,    42,    43,    44,    45,
       0,    46,    47,    48,    49,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,    99,     0,    16,    17,
     103,    19,    20,    21,    22,    23,    24,   104,    26,     0,
       0,     0,     0,     0,    27,     0,     0,     0,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       5,     0,     0,     0,    40,    41,    42,    43,    44,    45,
       0,    46,    47,    48,    49,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,    99,   272,    16,    17,
      18,    19,    20,    21,    22,    23,    24,     0,    26,     0,
       0,     0,     0,     0,    27,     0,     0,     0,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       5,     0,     0,     0,    40,    41,    42,    43,    44,    45,
       0,    46,    47,    48,    49,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,    99,     0,    16,    17,
      18,    19,    20,    21,    22,    23,    24,     0,    26,     0,
       0,     0,     0,     0,    27,     0,     0,   296,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       5,     0,     0,     0,    40,    41,    42,    43,    44,    45,
       0,    46,    47,    48,    49,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,    99,     0,    16,    17,
      18,    19,    20,    21,    22,    23,    24,     0,    26,     0,
       0,     0,     0,     0,    27,     0,     0,     0,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       5,     0,     0,     0,    40,    41,    42,    43,    44,    45,
       0,    46,    47,    48,    49,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,   235,     0,    16,    17,
      18,    19,    20,    21,    22,    23,    24,     0,    26,     0,
       0,     0,     0,     0,    27,     0,     0,     0,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,     0,     0,    36,     0,    37,    38,    39,
       5,     0,     0,     0,    40,    41,    42,    43,    44,    45,
       0,    46,    47,    48,    49,     0,     0,    11,    12,     0,
       0,     0,     0,     0,    13,    14,   327,     0,    16,    17,
      18,    19,    20,    21,    22,    23,    24,     0,    26,     0,
       0,     0,     0,     0,    27,     0,     0,     0,    28,    29,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,     0,     0,     0,    31,     0,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,    34,     0,
       0,     0,    35,   150,   151,    36,     0,    37,    38,    39,
       0,     0,   152,     0,    40,    41,    42,    43,    44,    45,
       0,    46,    47,    48,    49,     0,     0,     0,     0,     0,
     153,     0,     0,     0,   154,    29,   155,     0,     0,   156,
     157,   158,     0,     0,     0,     0,     0,     0,     0,   159,
       0,   160,     0,   161,     0,   162,   163,   164,   165,   166,
       0,     0,     0,     0,   167,     0,     0,     0,   168,     0,
     169,   170,     0,     0,   171,   172,     0,     0,   173,     0,
     174,     0,     0,     0,     0,     0,   175,   176,     0,     0,
       0,   177
};

static const short yycheck[] =
{
       2,    26,    69,   226,    38,     2,    26,     9,    15,    29,
      49,    50,     8,     8,    15,    15,    82,    38,    26,    27,
      40,    29,    55,    56,    45,    26,    27,    28,     0,    30,
      31,    39,    33,    34,    35,    36,    37,    38,    39,    40,
      47,    41,    38,    38,    38,    46,    47,    29,    30,    74,
      89,    90,    46,    38,   145,   146,    26,    27,    60,    29,
     126,    46,   153,    60,   130,    15,   157,   158,    38,    39,
     161,    26,    74,    26,    29,    38,    29,     3,     4,     5,
      82,   304,   173,    46,    86,    87,    15,    40,    90,    26,
      92,    28,    29,    90,    15,    96,    97,    98,    99,   100,
      26,    27,    28,    29,    15,    26,    27,    41,    29,   248,
     111,   112,    26,    38,    26,    29,   255,    29,    39,    15,
     121,    46,    31,   125,    47,    41,    40,   129,    40,    38,
     132,    40,   134,    15,   135,   136,    26,    27,    15,    29,
      32,    33,    34,    35,    36,    37,   147,   148,   149,    39,
      41,   152,    15,    42,    38,   156,    42,    46,   159,   160,
      46,   162,   163,   164,   165,   166,   167,   168,   169,   170,
      31,    40,    38,   174,   175,   176,   177,   178,   179,    60,
      26,    27,   248,    29,     3,     4,     5,    29,    30,   255,
      32,    33,    34,    35,    36,    37,    38,    38,    40,    32,
      33,    34,    35,    36,    37,    15,    87,    15,   275,    90,
      48,    92,    29,    30,   239,    32,    33,    34,    35,    36,
      37,    42,    31,    47,   226,   227,   228,   229,   230,   296,
     109,    38,    38,    38,   235,    38,    38,   239,    32,    33,
      34,    35,    36,    37,   125,    38,   247,    86,   129,    40,
      40,   132,    38,   134,    86,    40,    40,    54,   227,   261,
     227,    60,   263,   264,   261,   127,   130,   315,     2,   270,
     271,   272,   179,   274,   324,    -1,   277,   278,    -1,    -1,
     281,    32,    33,    34,    35,    36,    37,    -1,    -1,    -1,
     291,    32,    33,    34,    35,    36,    37,   299,   300,   301,
      -1,    -1,   304,    -1,   301,    32,    33,    34,    35,    36,
      37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   324,    -1,    -1,   327,    -1,    -1,   330,
      -1,    -1,    -1,    -1,   335,   337,    -1,   339,    -1,   341,
     342,    -1,    -1,     1,    -1,   226,   227,   228,   229,   230,
      -1,    -1,    -1,   355,    -1,   357,   358,    -1,   360,    -1,
      18,    19,    -1,    -1,   366,    -1,   368,    25,    26,    27,
      -1,    29,    30,    31,    32,    33,    34,    35,    36,    37,
     261,    39,    -1,    -1,    -1,    -1,    -1,    45,    -1,    -1,
      -1,    49,    50,    -1,    -1,    -1,    -1,    55,    56,    -1,
      -1,    -1,    -1,    61,    -1,    -1,    -1,    -1,    66,    -1,
      68,    -1,    -1,    -1,    -1,    -1,    74,    -1,   299,   300,
     301,    79,    -1,   304,    -1,    83,    -1,    -1,    86,    -1,
      88,    89,    90,    -1,    -1,    -1,    -1,    95,    96,    97,
      98,    99,   100,    -1,   102,   103,   104,   105,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   337,    -1,   339,    -1,
     341,   342,    -1,     0,     1,    -1,     3,     4,     5,     6,
      -1,     8,    -1,    -1,   355,    -1,   357,   358,    -1,   360,
      -1,    18,    19,    -1,    -1,   366,    -1,   368,    25,    26,
      27,    -1,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    -1,    -1,    -1,    -1,    -1,    45,    -1,
      -1,    -1,    49,    50,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    61,    -1,    -1,    -1,    -1,    66,
      -1,    68,    -1,    -1,    -1,    -1,    -1,    74,    -1,    -1,
      -1,    -1,    79,    -1,    -1,    -1,    83,    -1,    -1,    86,
      -1,    88,    89,    90,    -1,    -1,    -1,     1,    95,    96,
      97,    98,    99,   100,     8,   102,   103,   104,   105,    -1,
      -1,    -1,    -1,    -1,    18,    19,    -1,    -1,    -1,    -1,
      -1,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    -1,    42,    -1,
      -1,    45,    46,    -1,    -1,    49,    50,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,    -1,
      -1,    -1,    66,    -1,    68,    -1,    -1,    -1,    -1,    -1,
      74,    -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,    83,
      -1,    -1,    86,    -1,    88,    89,    90,    -1,    -1,    -1,
       1,    95,    96,    97,    98,    99,   100,     8,   102,   103,
     104,   105,    -1,    -1,    -1,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    47,    -1,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
      -1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
       1,   102,   103,   104,   105,     6,     7,     8,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    -1,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
      -1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
       1,   102,   103,   104,   105,     6,     7,     8,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    -1,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
      -1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
       1,   102,   103,   104,   105,    -1,     7,     8,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    -1,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
      -1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
       1,   102,   103,   104,   105,    -1,     7,     8,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    -1,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
       1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
      -1,   102,   103,   104,   105,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    -1,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    -1,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    55,    56,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
       1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
      -1,   102,   103,   104,   105,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    -1,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    -1,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    55,    56,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
       1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
      -1,   102,   103,   104,   105,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    -1,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    -1,    39,    -1,
      -1,    42,    -1,    -1,    45,    46,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
       1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
      -1,   102,   103,   104,   105,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    -1,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
       1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
      -1,   102,   103,   104,   105,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    -1,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
       1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
      -1,   102,   103,   104,   105,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    -1,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    -1,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    -1,    48,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
       1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
      -1,   102,   103,   104,   105,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    -1,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    -1,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
       1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
      -1,   102,   103,   104,   105,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    -1,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    -1,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    -1,    -1,    86,    -1,    88,    89,    90,
       1,    -1,    -1,    -1,    95,    96,    97,    98,    99,   100,
      -1,   102,   103,   104,   105,    -1,    -1,    18,    19,    -1,
      -1,    -1,    -1,    -1,    25,    26,    27,    -1,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    -1,    39,    -1,
      -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    -1,    68,    -1,    -1,
      -1,    -1,    -1,    74,    -1,    -1,    -1,    -1,    79,    -1,
      -1,    -1,    83,    18,    19,    86,    -1,    88,    89,    90,
      -1,    -1,    27,    -1,    95,    96,    97,    98,    99,   100,
      -1,   102,   103,   104,   105,    -1,    -1,    -1,    -1,    -1,
      45,    -1,    -1,    -1,    49,    50,    51,    -1,    -1,    54,
      55,    56,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    64,
      -1,    66,    -1,    68,    -1,    70,    71,    72,    73,    74,
      -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,    83,    -1,
      85,    86,    -1,    -1,    89,    90,    -1,    -1,    93,    -1,
      95,    -1,    -1,    -1,    -1,    -1,   101,   102,    -1,    -1,
      -1,   106
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,   111,   112,   113,     0,     1,     3,     4,     5,     6,
       8,    18,    19,    25,    26,    27,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    45,    49,    50,
      61,    66,    68,    74,    79,    83,    86,    88,    89,    90,
      95,    96,    97,    98,    99,   100,   102,   103,   104,   105,
     114,   115,   116,   117,   118,   119,   120,   124,   125,   131,
     132,   133,   138,   139,   141,   142,   143,   144,   145,   146,
     147,   148,   149,   151,   152,   154,   155,   156,   157,   158,
     159,   160,   161,   162,    26,    27,    38,    39,   121,   122,
     123,   124,   125,   127,   128,    38,    15,    15,    15,    27,
      28,   124,   139,    31,    38,   139,   154,   139,   139,   139,
     139,    41,   140,   139,   139,   139,   139,   139,   139,   139,
     139,    15,   139,   139,    38,    46,   129,   130,    38,    46,
     129,    38,    46,    38,    46,    47,    47,    28,   123,   125,
     126,   133,   134,     8,    38,    55,    56,    15,    15,    41,
      18,    19,    27,    45,    49,    51,    54,    55,    56,    64,
      66,    68,    70,    71,    72,    73,    74,    79,    83,    85,
      86,    89,    90,    93,    95,   101,   102,   106,   141,    41,
      31,    38,    40,    38,    40,   124,   154,    32,    33,    34,
      35,    36,    37,    32,    33,    34,    35,    36,    37,    32,
      33,    34,    35,    36,    37,    32,    33,    34,    35,    36,
      37,    32,    33,    34,    35,    36,    37,    32,    33,    34,
      35,    36,    37,   162,   121,   122,   123,    15,    39,   123,
     125,   123,   139,   139,   139,    27,   139,    38,   150,   153,
      40,    38,   139,   139,   139,   123,     1,     7,   135,   136,
     137,   138,   162,   131,   123,   135,   123,   123,   139,   139,
      38,    45,    38,   140,   140,   139,   139,   139,   163,   164,
      15,    15,    28,   139,   140,    48,   139,   140,   140,   139,
     139,   140,   139,   139,   139,   139,   139,   139,   139,   139,
     139,   140,   139,   139,   139,   139,    48,   139,   163,   123,
     126,   123,   127,   128,   123,   123,   123,   139,    31,   154,
      42,   109,   139,     6,   136,    47,     6,    38,    38,   123,
     125,   139,   139,    42,    46,   139,   139,    27,   139,   139,
     141,   139,   139,   139,   139,   141,    42,    40,   123,    40,
     123,   123,   126,    38,    38,     8,    38,    38,   137,    38,
     164,   139,   139,   139,   123,    40,   123,    40,    40,   123,
      40,   123,    38,   123,   123,   123,    40,   123,    40,   123,
     123
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrlab1

/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");			\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)           \
  Current.first_line   = Rhs[1].first_line;      \
  Current.first_column = Rhs[1].first_column;    \
  Current.last_line    = Rhs[N].last_line;       \
  Current.last_column  = Rhs[N].last_column;
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#define YYLEX	yylex ()

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)
# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)
/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
#endif /* !YYDEBUG */

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*-----------------------------.
| Print this symbol on YYOUT.  |
`-----------------------------*/

static void
#if defined (__STDC__) || defined (__cplusplus)
yysymprint (FILE* yyout, int yytype, YYSTYPE yyvalue)
#else
yysymprint (yyout, yytype, yyvalue)
    FILE* yyout;
    int yytype;
    YYSTYPE yyvalue;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvalue;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyout, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyout, yytoknum[yytype], yyvalue);
# endif
    }
  else
    YYFPRINTF (yyout, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyout, ")");
}
#endif /* YYDEBUG. */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
#if defined (__STDC__) || defined (__cplusplus)
yydestruct (int yytype, YYSTYPE yyvalue)
#else
yydestruct (yytype, yyvalue)
    int yytype;
    YYSTYPE yyvalue;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvalue;

  switch (yytype)
    {
      default:
        break;
    }
}



/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
#  define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL
# else
#  define YYPARSE_PARAM_ARG YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
# endif
#else /* !YYPARSE_PARAM */
# define YYPARSE_PARAM_ARG
# define YYPARSE_PARAM_DECL
#endif /* !YYPARSE_PARAM */

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
# ifdef YYPARSE_PARAM
int yyparse (void *);
# else
int yyparse (void);
# endif
#endif


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of parse errors so far.  */
int yynerrs;


int
yyparse (YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  
  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yychar1 = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with.  */

  if (yychar <= 0)		/* This means end of input.  */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more.  */

      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yychar1 = YYTRANSLATE (yychar);

      /* We have to keep this `#if YYDEBUG', since we use variables
	 which are defined only if `YYDEBUG' is set.  */
      YYDPRINTF ((stderr, "Next token is "));
      YYDSYMPRINT ((stderr, yychar1, yylval));
      YYDPRINTF ((stderr, "\n"));
    }

  /* If the proper action on seeing token YYCHAR1 is to reduce or to
     detect an error, take that action.  */
  yyn += yychar1;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yychar1)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %d (%s), ",
	      yychar, yytname[yychar1]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];



#if YYDEBUG
  /* We have to keep this `#if YYDEBUG', since we use variables which
     are defined only if `YYDEBUG' is set.  */
  if (yydebug)
    {
      int yyi;

      YYFPRINTF (stderr, "Reducing via rule %d (line %d), ",
		 yyn - 1, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (yyi = yyprhs[yyn]; yyrhs[yyi] >= 0; yyi++)
	YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
      YYFPRINTF (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif
  switch (yyn)
    {
        case 2:
    {if (gstmts != NILSTATE && ! errflag) 
	 	 mnbody(gstmts);}
    break;

  case 4:
    {lexscope = GLOBAL; SETATTRIBUTES;
			  funmode=1;funlnum=0;}
    break;

  case 5:
    {lexscope = GLOBAL;
                         SETATTRIBUTES;
                         linenum = 1;
                         mainlnum = 0;
                         funlnum = 0;
			 funmode = 1;
			 linemode = 2;
                         gstmts = NILSTATE;
			 resetconsts();
                         addicon(0);
                         addicon(1);
                         errflag = 0; }
    break;

  case 6:
    {gstmts = addstmt(gstmts, newstate(NILCHAR, yyvsp[0].n)); 
             funmode=1;yylistfn();}
    break;

  case 10:
    {direct(yyvsp[-3].c, yyvsp[-1].n);
                                     funmode=0;yylistfn();}
    break;

  case 11:
    {direct(yyvsp[-3].c, yyvsp[-1].n);
                                     funmode=0;yylistfn();}
    break;

  case 12:
    {if (! errflag)
                                            prog(yyvsp[-4].h, yyvsp[-2].t);
					 resetconsts();
					 reinit_local_symtab();
                                         linemode=1;yylistfn();}
    break;

  case 13:
    {if (! errflag)
                                            opprog(yyvsp[-4].oh, yyvsp[-2].t);
					 resetconsts();
					 reinit_local_symtab();
                                         linemode=1;yylistfn();}
    break;

  case 14:
    {enterid(yyvsp[0].c, lexscope, APLC_UKTYPE, NORANK);yyval.h = yyvsp[-2].h;}
    break;

  case 15:
    {enterid(yyvsp[0].c, lexscope, APLC_UKTYPE, NORANK);yyval.h = yyvsp[-2].h;}
    break;

  case 16:
    {yyval.h = yyvsp[-1].h;
		                      funmode=2;linemode=1;yylistfn();}
    break;

  case 17:
    {yyval.h = yyvsp[-1].h;
		                      funmode=2;linemode=1;yylistfn();}
    break;

  case 18:
    {enterid(yyvsp[0].c, lexscope, APLC_UKTYPE, NORANK);yyval.oh = yyvsp[-2].oh;}
    break;

  case 19:
    {enterid(yyvsp[0].c, lexscope, APLC_UKTYPE, NORANK);yyval.oh = yyvsp[-2].oh;}
    break;

  case 20:
    {yyval.oh = yyvsp[-1].oh;
		                        funmode=2;linemode=1;yylistfn();}
    break;

  case 21:
    {yyval.oh = yyvsp[-1].oh;
		                        funmode=2;linemode=1;yylistfn();}
    break;

  case 22:
    {lexscope = LOCAL; yyval.h = yyvsp[0].h;}
    break;

  case 23:
    {lexscope = LOCAL; yyval.h = yyvsp[0].h;}
    break;

  case 24:
    {lexscope = LOCAL; yyval.oh = yyvsp[0].oh;}
    break;

  case 25:
    {lexscope = LOCAL; yyval.oh = yyvsp[0].oh;}
    break;

  case 26:
    {yyvsp[0].h->asvar = yyvsp[-2].c;
                                enterid(yyvsp[-2].c, APARAM, APLC_UKTYPE, NORANK);
                                yyval.h = yyvsp[0].h;}
    break;

  case 27:
    {yyval.h = yyvsp[0].h;}
    break;

  case 28:
    {yyvsp[0].oh->asvar = yyvsp[-2].c;
                                enterid(yyvsp[-2].c, APARAM, APLC_UKTYPE, NORANK);
                                yyval.oh = yyvsp[0].oh;}
    break;

  case 29:
    {yyval.oh = yyvsp[0].oh;}
    break;

  case 30:
    {yyval.c = yyvsp[0].s->name;}
    break;

  case 32:
    {yyval.c = newid(yytext);}
    break;

  case 33:
    {yyval.c = yyvsp[0].s->name;}
    break;

  case 34:
    {yyval.c = yyvsp[0].s->name;}
    break;

  case 35:
    {yyval.h = newhead(yyvsp[-1].c, yyvsp[-2].c, yyvsp[0].c);}
    break;

  case 36:
    {yyval.h = newhead(yyvsp[-1].c, yyvsp[-2].c, yyvsp[0].c);}
    break;

  case 37:
    {yyval.h = newhead(yyvsp[-1].c, NILCHAR, yyvsp[0].c);}
    break;

  case 38:
    {yyval.h = newhead(yyvsp[-1].c, NILCHAR, yyvsp[0].c);}
    break;

  case 39:
    {yyval.h = newhead(yyvsp[0].c, NILCHAR, NILCHAR);}
    break;

  case 40:
    {yyval.h = newhead(yyvsp[0].c, NILCHAR, NILCHAR);}
    break;

  case 41:
    {yyval.oh = newophead(yyvsp[-5].c, yyvsp[-3].c, yyvsp[-2].c, NILCHAR, yyvsp[0].c);}
    break;

  case 42:
    {yyval.oh = newophead(yyvsp[-5].c, yyvsp[-3].c, yyvsp[-2].c, NILCHAR, yyvsp[0].c);}
    break;

  case 43:
    {yyval.oh = newophead(NILCHAR, yyvsp[-3].c, yyvsp[-2].c, NILCHAR, yyvsp[0].c);}
    break;

  case 44:
    {yyval.oh = newophead(NILCHAR, yyvsp[-3].c, yyvsp[-2].c, NILCHAR, yyvsp[0].c);}
    break;

  case 45:
    {yyval.oh = newophead(yyvsp[-6].c, yyvsp[-4].c, yyvsp[-3].c, yyvsp[-2].c, yyvsp[0].c);}
    break;

  case 46:
    {yyval.oh = newophead(yyvsp[-6].c, yyvsp[-4].c, yyvsp[-3].c, yyvsp[-2].c, yyvsp[0].c);}
    break;

  case 47:
    {yyval.oh = newophead(NILCHAR, yyvsp[-4].c, yyvsp[-3].c, yyvsp[-2].c, yyvsp[0].c);}
    break;

  case 48:
    {yyval.oh = newophead(NILCHAR, yyvsp[-4].c, yyvsp[-3].c, yyvsp[-2].c, yyvsp[0].c);}
    break;

  case 49:
    {setlocalcons();
               addicon(0);
               addicon(1);}
    break;

  case 50:
    {SETATTRIBUTES;}
    break;

  case 51:
    {SETATTRIBUTES;}
    break;

  case 52:
    {linemode=1;yylistfn();}
    break;

  case 55:
    {dclclass = yyvsp[0].l;}
    break;

  case 56:
    {dcltype  = yyvsp[0].i;}
    break;

  case 57:
    {dclrank  = yyvsp[0].i;}
    break;

  case 58:
    {enterid(yyvsp[0].c, dclclass, dcltype, dclrank);}
    break;

  case 59:
    {enterid(yyvsp[0].c, FUNCTION, dcltype, dclrank);}
    break;

  case 60:
    {enterid(yyvsp[0].c, OPERATOR, dcltype, dclrank);}
    break;

  case 61:
    {enterid(yyvsp[0].c, dclclass, dcltype, dclrank);}
    break;

  case 62:
    {enterid(yyvsp[0].c, FUNCTION, dcltype, dclrank);}
    break;

  case 63:
    {yyval.t = yyvsp[0].t;yylistfn();}
    break;

  case 64:
    {yyval.t = addstmt(yyvsp[-1].t, yyvsp[0].t);yylistfn();}
    break;

  case 65:
    {yyerrok;}
    break;

  case 66:
    {yyval.t = newstate(yyvsp[-2].c, yyvsp[0].n);
                                            linemode=2;/* make sure */}
    break;

  case 67:
    {yyval.t = newstate(NILCHAR, yyvsp[0].n);}
    break;

  case 68:
    {yyval.n = pt1(GO, yyvsp[-1].n);}
    break;

  case 69:
    {yyval.n = pt1(GO, yyvsp[-2].n);}
    break;

  case 70:
    {yyval.n = yyvsp[0].n;}
    break;

  case 71:
    {yyval.n = pttop(yyvsp[-1].n);}
    break;

  case 72:
    {yyval.n = pttop(yyvsp[-2].n);}
    break;

  case 73:
    {yyval.n = pt1(COMMENT, (struct node *) 0);
                                   linemode=1;}
    break;

  case 74:
    {yyval.n = pt1(COMMENT, (struct node *) 0);
                                   linemode=0;}
    break;

  case 75:
    {yyval.n = pt1o(MSFUN, yyvsp[-1].o, yyvsp[0].n);}
    break;

  case 76:
    {yyval.n = pt1(RAVEL, yyvsp[0].n);}
    break;

  case 77:
    {yyval.n = pt1(DOMINO, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 78:
    {yyval.n = pt1(FORMAT, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 79:
    {yyval.n = pt1(IOTA, pt1(CISCALAR, yyvsp[0].n));}
    break;

  case 80:
    {yyval.n = pt1a(REVERSE, yyvsp[-1].n, yyvsp[-2].i, yyvsp[0].n);}
    break;

  case 81:
    {yyval.n = ptmrho(yyvsp[0].n);}
    break;

  case 82:
    {yyval.n = pt1(COLLECT, pt1(ROLL, yyvsp[0].n));}
    break;

  case 83:
    {yyval.n = ptsort(yyvsp[-1].i, pt1(CVEC, yyvsp[0].n));}
    break;

  case 84:
    {yyval.n = pt1(TRANS, yyvsp[0].n);}
    break;

  case 85:
    {yyval.n = pt1(EXECUTE, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 86:
    {yyval.n = pt1(BOX, pt1(CCOLLECT, yyvsp[0].n));}
    break;

  case 87:
    {yyval.n = pt1(UNBOX, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 88:
    {yyval.n = ptqass(yyvsp[0].n);}
    break;

  case 89:
    {yyval.n = ptqlzass(yyvsp[0].n);}
    break;

  case 90:
    {yyval.n = pt1(QQUADASSIGN, yyvsp[0].n);}
    break;

  case 91:
    {yyval.n = pt1ao(SCAN,   yyvsp[-3].o, yyvsp[-1].n, yyvsp[0].n, yyvsp[-2].i);}
    break;

  case 92:
    {yyval.n = pt1ao(REDUCE, yyvsp[-3].o, yyvsp[-1].n, yyvsp[0].n, yyvsp[-2].i);}
    break;

  case 93:
    {yyval.n = pt2o(DSFUN, yyvsp[-1].o, yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 94:
    {yyval.n = pt1ao(INNER, yyvsp[-3].o, NILP,
               pt2aos(INNERCHILD, yyvsp[-1].o, NILP, FIRSTAXIS, yyvsp[-4].n, yyvsp[0].n), LASTAXIS);}
    break;

  case 95:
    {yyval.n = pt2o(OUTER, yyvsp[-1].o, yyvsp[-4].n, yyvsp[0].n);}
    break;

  case 96:
    {yyval.n = pt2(ASSIGN, yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 97:
    {yyval.n = ptsub(yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 98:
    {yyval.n = pt1o(ASYSVAR, yyvsp[-2].v, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 99:
    {yyval.n = pt2(DQUADASSIGN, yyvsp[-3].n, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 100:
    {yyval.n = pt2(DQQUADASSIGN, yyvsp[-3].n, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 101:
    {yyval.n = pt2a(EXPAND, yyvsp[-1].n, yyvsp[-2].i, yyvsp[-3].n, yyvsp[0].n);}
    break;

  case 102:
    {yyval.n = pt2a(CAT,yyvsp[-1].n, LASTAXIS, yyvsp[-3].n, yyvsp[0].n);}
    break;

  case 103:
    {yyval.n = pt2a(LINK, yyvsp[-1].n, LASTAXIS, 
						 pt1(COLLECT,yyvsp[-3].n), pt1(COLLECT,yyvsp[0].n));}
    break;

  case 104:
    {yyval.n = pt1ao(INNER, APLC_PLUS, NILP,
               pt2aos(DECODE, APLC_TIMES, NILP, FIRSTAXIS, yyvsp[-2].n, yyvsp[0].n), LASTAXIS);}
    break;

  case 105:
    {yyval.n = pt2(MSOLVE, pt1(COLLECT, yyvsp[-2].n), pt1(COLLECT, yyvsp[0].n));}
    break;

  case 106:
    {yyval.n = pt2(DROP, pt1(CIVEC, yyvsp[-2].n), 
					      pt1(COLLECT, yyvsp[0].n));}
    break;

  case 107:
    {yyval.n = pt2(GWDROP, pt1(CIVEC, yyvsp[-2].n), yyvsp[0].n);}
    break;

  case 108:
    {yyval.n = pt2(ENCODE, yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 109:
    {yyval.n = pt2(EPSILON, yyvsp[-2].n, 
                                          ptsort(1, pt1(CVEC, pt1(RAVEL, yyvsp[0].n))));}
    break;

  case 110:
    {yyval.n = pt2(DFORMAT, 
                                          pt1(COLLECT, yyvsp[-2].n), pt1(COLLECT, yyvsp[0].n));}
    break;

  case 111:
    {yyval.n = pt2(INDEX, 
				          ptsort(1, pt1(CVEC, yyvsp[-2].n)), yyvsp[0].n);}
    break;

  case 112:
    {yyval.n = pt2a(ROTATE, yyvsp[-1].n, yyvsp[-2].i, yyvsp[-3].n, yyvsp[0].n);}
    break;

  case 113:
    {yyval.n = pt2(RESHAPE, pt1(CIVEC, yyvsp[-2].n), yyvsp[0].n);}
    break;

  case 114:
    {yyval.n = pt2(DEAL, pt1(CISCALAR, yyvsp[-2].n), pt1(CISCALAR, yyvsp[0].n));}
    break;

  case 115:
    {yyval.n = pt2a(COMPRESS, yyvsp[-1].n, yyvsp[-2].i, yyvsp[-3].n, yyvsp[0].n);}
    break;

  case 116:
    {yyval.n = pt2(TAKE, pt1(CIVEC, yyvsp[-2].n), 
					      pt1(COLLECT, yyvsp[0].n));}
    break;

  case 117:
    {yyval.n = pt2(GWTAKE, pt1(CIVEC, yyvsp[-2].n), yyvsp[0].n);}
    break;

  case 118:
    {yyval.n = pt2(DTRANS, pt1(CIVEC, yyvsp[-2].n), yyvsp[0].n);}
    break;

  case 119:
    {yyval.n = pt2o(DSYSFUN, yyvsp[-1].v, pt1(COLLECT, yyvsp[-2].n), 
                                              pt1(COLLECT, yyvsp[0].n));}
    break;

  case 120:
    {yyval.n = pt2o(DSYSFUN, yyvsp[-1].v, pt1(COLLECT, yyvsp[-2].n), 
                         pt1(COLLECT, yyvsp[0].n));}
    break;

  case 121:
    {yyval.n = pt2(CATCH,  yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 122:
    {yyval.n = ptmsys(MSYSFUN, yyvsp[-1].v, yyvsp[0].n);}
    break;

  case 123:
    {yyval.n = pt1o(MSYSFUN, yyvsp[-1].v, pt1(COLLECT, yyvsp[0].n));}
    break;

  case 124:
    {yyval.n = ptop(yyvsp[-4].n, yyvsp[-3].s,  yyvsp[-2].s, yyvsp[-1].s, yyvsp[0].n);}
    break;

  case 125:
    {yyval.n = ptop(NILP, yyvsp[-3].s,  yyvsp[-2].s, yyvsp[-1].s, yyvsp[0].n);}
    break;

  case 126:
    {yyval.n = ptop(yyvsp[-3].n, yyvsp[-2].s,  yyvsp[-1].s, NILSYM, yyvsp[0].n);}
    break;

  case 127:
    {yyval.n = ptop(NILP, yyvsp[-2].s,  yyvsp[-1].s, NILSYM, yyvsp[0].n);}
    break;

  case 128:
    {yyval.n = ptfun(yyvsp[-1].s,  yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 129:
    {yyval.n = ptfun(yyvsp[-1].s, NILP, yyvsp[0].n);}
    break;

  case 130:
    {yyval.n = ptnilfun(yyvsp[0].s);}
    break;

  case 131:
    {yyval.n = yyvsp[0].n;}
    break;

  case 132:
    {expect("expression");}
    break;

  case 133:
    {yyval.n = 0;}
    break;

  case 134:
    {yyval.n = yyvsp[-1].n;}
    break;

  case 135:
    {yyval.o = yyvsp[0].o;}
    break;

  case 136:
    {yyval.o = yyvsp[0].o;}
    break;

  case 137:
    {yyval.o = APLC_LT;}
    break;

  case 138:
    {yyval.o = APLC_GT;}
    break;

  case 139:
    {yyval.n = yyvsp[0].n;}
    break;

  case 140:
    {yyval.n = ptvar(enterid(yyvsp[0].c, dclclass, APLC_UKTYPE, NORANK));}
    break;

  case 141:
    {yyval.n = ptvar(yyvsp[0].s);}
    break;

  case 142:
    {yyval.n = sysparm("_alpha");}
    break;

  case 143:
    {yyval.n = sysparm("_omega");}
    break;

  case 144:
    {yyval.n = pt2(SUB, yyvsp[-3].n, yyvsp[-1].n);}
    break;

  case 145:
    {yyval.n = yyvsp[0].n;}
    break;

  case 146:
    {yyval.n = yyvsp[0].n;}
    break;

  case 147:
    {yyval.n = yyvsp[0].n;}
    break;

  case 148:
    {yyval.n = yyvsp[0].n;}
    break;

  case 149:
    {yyval.n = pt2(SUB, yyvsp[-3].n, yyvsp[-1].n);}
    break;

  case 150:
    {yyval.n = newnode(QUAD);}
    break;

  case 151:
    {yyval.n = pt1(DQUAD, yyvsp[-1].n);}
    break;

  case 152:
    {yyval.n = newnode(QQUAD);}
    break;

  case 153:
    {yyval.n = pt1(DQQUAD, yyvsp[-1].n);}
    break;

  case 154:
    {yyval.n = yyvsp[-1].n;}
    break;

  case 155:
    {yyval.n = pt1o(SYSVAR, yyvsp[0].v, NILP);}
    break;

  case 156:
    {yyval.n = pt1o(SYSVAR, yyvsp[0].v, NILP);}
    break;

  case 157:
    {yyval.n = newnode(AVEC);}
    break;

  case 158:
    {yyval.n = pttcav(TCAV, yyvsp[0].v);}
    break;

  case 159:
    {yyval.n = pttycon(TYPECON, yyvsp[0].v);}
    break;

  case 160:
    {yyval.n = ptsvec(yyvsp[0].c);}
    break;

  case 161:
    {yyval.n = yyvsp[0].n;}
    break;

  case 162:
    {yyval.n = yyvsp[0].n;}
    break;

  case 163:
    {yyval.n = yyvsp[0].n;}
    break;

  case 164:
    {yyval.n = finsta(yyvsp[-1].n);line_off *= -1;}
    break;

  case 165:
    {yyval.n = ptsta(yyvsp[-1].c);yylistfn();line_off++;}
    break;

  case 166:
    {yylistfn();}
    break;

  case 167:
    {yyval.n = ptsta(yyvsp[-1].c);
                                                 line_off++;yylistfn();}
    break;

  case 168:
    {yyval.n = addstanl(yyvsp[-1].n);yylistfn();}
    break;

  case 169:
    {yyval.n = addsta(yyvsp[-1].n, yyvsp[0].c);}
    break;

  case 170:
    {yyval.n = fin_na(yyvsp[-1].n);line_off *= -1;}
    break;

  case 171:
    {yyval.n = pt_na(yyvsp[-1].n);yylistfn();line_off++;}
    break;

  case 172:
    {yylistfn();}
    break;

  case 173:
    {yyval.n = pt_na(yyvsp[-1].n);
                                                line_off++;yylistfn();}
    break;

  case 174:
    {yyval.n = add_nanl(yyvsp[-1].n);yylistfn();}
    break;

  case 175:
    {yyval.n = add_na(yyvsp[-1].n, yyvsp[0].n);}
    break;

  case 176:
    {yyval.n = ptvec(yyvsp[0].n, BCON, APLC_BOOL);}
    break;

  case 177:
    {yyval.n = ptvec(yyvsp[0].n, ICON, APLC_INT);}
    break;

  case 178:
    {yyval.n = ptvec(yyvsp[0].n, RCON, APLC_REAL);}
    break;

  case 179:
    {yyval.n = ptvec(yyvsp[0].n, ZCON, APLC_COMPLEX);}
    break;

  case 180:
    {yyval.n = ptvec(yyvsp[0].n, QCON, APLC_QUAT);}
    break;

  case 181:
    {yyval.n = ptvec(yyvsp[0].n, OCON, APLC_OCT);}
    break;

  case 182:
    {yyval.n = ptvec(yyvsp[0].n, LCON, APLC_INT);}
    break;

  case 183:
    {yyval.n = ptval(BCON, addicon(yyvsp[0].i));}
    break;

  case 184:
    {addicon(yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 185:
    {yyval.n = ptval(ICON, addicon(yyvsp[0].i));}
    break;

  case 186:
    {addicon(yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 187:
    {addicon(yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 188:
    {addicon(yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 189:
    {yyval.n = ptval(RCON, addrcon(yyvsp[0].d));}
    break;

  case 190:
    {expanivec(yyvsp[-1].n, yyvsp[0].d); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 191:
    {expanivec(yyvsp[-1].n, yyvsp[0].d); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 192:
    {addrcon(yyvsp[0].d); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 193:
    {addrcon((double) yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 194:
    {addrcon((double) yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 195:
    {yyval.n = ptval(ZCON, addzcon(yyvsp[0].z));}
    break;

  case 196:
    {ivec2rvec(yyvsp[-1].n);expanrvec(yyvsp[-1].n, yyvsp[0].z); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 197:
    {ivec2rvec(yyvsp[-1].n);expanrvec(yyvsp[-1].n, yyvsp[0].z); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 198:
    {expanrvec(yyvsp[-1].n, yyvsp[0].z); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 199:
    {addzcon(yyvsp[0].z); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 200:
    {addr2zcon(yyvsp[0].d); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 201:
    {addr2zcon((double) yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 202:
    {addr2zcon((double) yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 203:
    {yyval.n = ptval(QCON, addqcon(yyvsp[0].q));}
    break;

  case 204:
    {zvec2qvec(rvec2zvec(ivec2rvec(yyvsp[-1].n))); addqcon(yyvsp[0].q); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 205:
    {zvec2qvec(rvec2zvec(ivec2rvec(yyvsp[-1].n))); addqcon(yyvsp[0].q); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 206:
    {zvec2qvec(rvec2zvec(yyvsp[-1].n)); addqcon(yyvsp[0].q); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 207:
    {zvec2qvec(yyvsp[-1].n); addqcon(yyvsp[0].q); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 208:
    {addqcon(yyvsp[0].q); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 209:
    {addz2qcon(yyvsp[0].z); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 210:
    {addr2qcon(yyvsp[0].d); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 211:
    {addr2qcon((double)yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 212:
    {addr2qcon((double)yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 213:
    {yyval.n = ptval(OCON, addocon(yyvsp[0].oct));}
    break;

  case 214:
    {qvec2ovec(zvec2qvec(rvec2zvec(ivec2rvec(yyvsp[-1].n)))); addocon(yyvsp[0].oct); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 215:
    {qvec2ovec(zvec2qvec(rvec2zvec(ivec2rvec(yyvsp[-1].n)))); addocon(yyvsp[0].oct); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 216:
    {qvec2ovec(zvec2qvec(rvec2zvec(yyvsp[-1].n))); addocon(yyvsp[0].oct); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 217:
    {qvec2ovec(zvec2qvec(yyvsp[-1].n)); addocon(yyvsp[0].oct); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 218:
    {qvec2ovec(yyvsp[-1].n); addocon(yyvsp[0].oct); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 219:
    {addocon(yyvsp[0].oct); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 220:
    {addq2ocon(yyvsp[0].q); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 221:
    {addz2ocon(yyvsp[0].z); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 222:
    {addr2ocon(yyvsp[0].d); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 223:
    {addr2ocon((double)yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 224:
    {addr2ocon((double)yyvsp[0].i); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 225:
    {yyval.n = ptval(LCON, addlcon(yyvsp[0].c));}
    break;

  case 226:
    {addlcon(yyvsp[0].c); yyval.n = aptval(yyvsp[-1].n);}
    break;

  case 227:
    {yyval.c = ((struct symnode *) yyval.c)->name;}
    break;

  case 228:
    {yyval.c = yyvsp[0].c;}
    break;

  case 229:
    {yyval.n = ptsemi(NILP, yyvsp[0].n);}
    break;

  case 230:
    {yyval.n = ptsemi(yyvsp[-2].n, yyvsp[0].n);}
    break;

  case 231:
    {yyval.n = newnode(EMPTSEMI);}
    break;

  case 232:
    {yyval.n = yyvsp[0].n;}
    break;


    }

/* Line 1016 of /usr/local/share/bison/yacc.c.  */
#line 2879 "y.tab.c"

  yyvsp -= yylen;
  yyssp -= yylen;


#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("parse error, unexpected ") + 1;
	  yysize += yystrlen (yytname[yytype]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "parse error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("parse error");
    }
  goto yyerrlab1;


/*----------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action.  |
`----------------------------------------------------*/
yyerrlab1:
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* Return failure if at end of input.  */
      if (yychar == YYEOF)
        {
	  /* Pop the error token.  */
          YYPOPSTACK;
	  /* Pop the rest of the stack.  */
	  while (yyssp > yyss)
	    {
	      YYDPRINTF ((stderr, "Error: popping "));
	      YYDSYMPRINT ((stderr,
			    yystos[*yyssp],
			    *yyvsp));
	      YYDPRINTF ((stderr, "\n"));
	      yydestruct (yystos[*yyssp], *yyvsp);
	      YYPOPSTACK;
	    }
	  YYABORT;
        }

      YYDPRINTF ((stderr, "Discarding token %d (%s).\n",
		  yychar, yytname[yychar1]));
      yydestruct (yychar1, yylval);
      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */

  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDPRINTF ((stderr, "Error: popping "));
      YYDSYMPRINT ((stderr,
		    yystos[*yyssp], *yyvsp));
      YYDPRINTF ((stderr, "\n"));

      yydestruct (yystos[yystate], *yyvsp);
      yyvsp--;
      yystate = *--yyssp;


#if YYDEBUG
      if (yydebug)
	{
	  short *yyssp1 = yyss - 1;
	  YYFPRINTF (stderr, "Error: state stack now");
	  while (yyssp1 != yyssp)
	    YYFPRINTF (stderr, " %d", *++yyssp1);
	  YYFPRINTF (stderr, "\n");
	}
#endif
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;


  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}




 /*
    |  sublist          {$$ = ptsmtolink();}

    |  term SM axis expression  {$$ = pt2a(LINK, , LASTAXIS, 
				 pt1(COLLECT,), pt1(COLLECT,));}

		*/
/* --------------------------------- */
/* included code from apl.y */

/* sws  changed to allow use under msdos file name restrictions
 include "lex.yy.c"
*/
#include "lex_yy.c"

#include "aplparse.c"

/* --------------------------------- */
/* end of apl.y */

