/*
	APL Compiler

  Common declarations for generation stage
  Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_GEN_H
#define _APLC_GEN_H

#define VDEBUG 1

/* nill codetree */
#define NILTREE (struct codetree *) 0

/* if left (name) was declared a scalar, of known type, then it
   doesn't need a trs */
#if 0
#define declscalar(node) (0)
#endif
#if 0
/* old version before complex */
#define declscalar(node) ( (node->n.info & RANKDECL)&&(rankvalue(node) == 0)&& \
			   (node->n.info & TYPEDECL) )
#endif
#if 1
/* don't allow complex scalars (at least so far) 
*/
#define declscalar(node) ( (node->n.info & RANKDECL)&&(rankvalue(node) == 0)&& \
			   (node->n.info & TYPEDECL) && \
       ( (rtype(node) == APLC_BOOL) || (rtype(node) == APLC_INT) || \
	 (rtype(node) == APLC_REAL) || (rtype(node) == APLC_CHAR) ) )
#endif

#if 0
/* this is too general... */
#define declscalar(node) ( (node->n.info & RANKKNOWN)&&(rankvalue(node) == 0)&& \
			   (node->n.info & TYPEKNOWN) )
#endif

#define isGcomplext(t) ((t==APLC_COMPLEX) ||(t==APLC_QUAT) || (t==APLC_OCT))

#define isNotGcomplex(node) ((node->n.info & TYPEKNOWN) && !isGcomplext(rtype(node)))

/* -------------------------------------- */
#include "nutil.h"

/* asgn */
int asntchk(int gen, struct node * dest, struct node * source,
    int destype, int regval, int mpval);
int sasntchk(int gen, struct node * dest, struct node * source,
    int destype, int regval, int mpval);

void genassign(struct node * node, enum pmodes mode, int top);
void gensubassign(struct node * node, enum pmodes mode, int top);

/* qasgn.c */
void genqassign(struct node * node, enum pmodes mode, int top);

/* axis */
void axies(struct node * node, struct node * axis, struct node * child,
	   int i, int e, int s);
void asubi(struct node * node, struct node * child, int iindex,
	   int e, int s);
void asubic(struct node * node, struct node * child, int iindex,
	    int e, int s);
void redshape(struct node * node, struct node * axis, int i, int e,
	      int s, int mpval, int rank);
void cmpidx1(struct node * node, struct node * child, int newindex,
	     int table, int iindex, int e, int s);
void cmpidx2(struct node * node, int temp, int newindex, int iindex,
	     int a, int e, int sp, int s);
extern void compshape(struct node * node, struct node * child,
		      int mpval, int i, int sp, int resp);
void comploop(struct node * node, int i, int e, int s, int mpval, int ms,
	      int resl, int resr, int rank);
void gencompress(struct node * node, enum pmodes mode, int top);
void genfill(int resval, struct node * node);
void genexpand(struct node * node, enum pmodes mode, int top);
void genrotate(struct node * node, enum pmodes mode, int top);
void ieqic(int i);
void iopic(int i, char *op, int j);
int resinreg2(struct node * node, int regval);
void genencode(struct node * node, enum pmodes mode, int top);

/* from catch.c */
extern void gencatch(struct node *, enum pmodes, int);

/* from catenate.c */
extern void mergetype(struct node * node, struct node * left, 
		      struct node * right, int ival);
void gencat(struct node *, enum pmodes, int);


/* common stuff from collect.c */
void colloop(struct node * node, int indexval, int maxval);

void genciscalar(struct node * node, enum pmodes mode, int top);
void gencscalar(struct node * node, enum pmodes mode, int top);
void gencivec(struct node * node, enum pmodes mode, int top);
void gencollect(struct node * node, enum pmodes mode, int top);
void genccollect(struct node * node, enum pmodes mode, int top);
void genreshape(struct node * node, enum pmodes mode, int top);

/* from ctree.c */
void mkrktype(struct node * node, int ktype, int resval);
void testtype(struct codetree * tree, int type);
void testrank(struct codetree * tree, int rank);
void testmxrank(struct codetree * tree, int rank);
void testsingle(struct codetree * rtree, struct codetree * stree);
int cteq(struct codetree * t1, struct codetree * t2);
int ctdsfun_check(enum sfuns op, int type);

void ctgen(struct codetree * tree);
struct codetree *gcnode(enum codeops cop);
struct codetree *gicn(enum codeops cop, int val, int typ);
struct codetree *gixorg(void);
struct codetree *gcast(enum codeops cop, struct codetree * cnode,
    int ctype);
struct codetree *gbin(enum codeops cop, struct codetree * cnode1,
    struct codetree * cnode2);
struct codetree *gtrs(int trsval, enum tfields tfield, int ttype);
struct codetree *gident(char *name, enum tfields field, int ttype);
struct codetree *gcond(struct codetree * cond, struct codetree * left,
    struct codetree * right);
struct codetree *gmop(enum sfuns mop, struct codetree * child);
struct codetree *gsfun(enum sfuns sfun, struct codetree * cnode1, 
    struct codetree * cnode2);
struct codetree *gmon(enum codeops cop, struct codetree * cnode);
extern char *type_str(int type);
extern char *mp_type_str(int type);
extern char *res_type_str(int type);
extern char *cast_str(int type);

/* start of cutil.c */
/* set by fixzero */
extern struct node *zeronode;

void copychild(struct node * node, struct node * child,
    int type, int rank, int shape);
char *str_coptype(enum codeops cop);
void coptype(enum codeops cop);
void gcant_happen(char *s, int n);
int rankvalue(struct node * node);
int shapevalue(struct node * node);
int valvalue(struct node * node);
int is_zilde(struct node * node);
int is_scalar(struct node * node);
int isnot_scalar(struct node * node);
int is_singleton(struct node * node);
int isnot_singleton(struct node * node); 
int is_vector(struct node * node);
void adjdcls(struct node * node);
int resinreg(struct node * node, int regval);
int ksize(struct node * node);
void getsize(int i, struct node * node);
void getsizeval(struct node * node);
void fixzero(void);
void cpshape(int memval, struct node * node);
void mktmatch(struct node * want, struct node * have, int reg);

/* end of cutil.c */

/* from frag.c */
void commasp(void);
void ctzero(struct codetree * t, int i, char *op);
void dmppi(int m, int i);
void elsebr(void);
void ieq(int i);
void ieqc(int i, int c);
void ieqi(int i1, int i2);
void ieqtree(int i, struct codetree * t);
void iincr(int i);
void idecr(int i);
void iopi(int i1, int i2, char *op, int i3);
void ifi(int i);
void iflp(void);
void iiloop(int i1, int i2);
void isloop(int i1, int i2);
void izloop(int i1, int i2);
void impalloc(int m, int i);
void lp(void);
void lrnsrrns(struct node * child1, struct node * child2);
void mpeqmp(int m1, int m2);
void mpfree(int i);
void mpfree_nots(int i, int r);
void trs_shape_free(int i);
void mpipieq(int m, int i);
void poests(int p, int e, int s, int sp);
void prerror(char *s);
void lbr(void);
void rbr(void);
void reqr(int r1, int r2);
void rkeq(struct node * node, int i);
void rns(struct node * t);
void trns(struct node * t);
void rp(void);
void rpnl(void);
void rpseminl(void);
void seminl(void);
void seticon(int i, int c);
void setizero(int i);
void setmptoi(int m, int i);
void setrank(int i, struct node * node);
void settrs(int t, struct node * n);
void singleton( struct node * node );
void smpieqt(int i, struct codetree * t);
void smpalloc(int i);
void testflag(int i, int r1, int r2);
void testscalar(struct node * node );
void trepi(struct codetree * t, int i);
void trsuk(int i);
void inittrs(int i);
void inittrsn(char *s);
void inittrsnp(char *s);

  /* slightly longer than one liners */
int smpval(struct node * node, int mpval);
void filtrs(int t, struct node * n);
void rkloop(struct node * node, int loopvar, int rankvar);
void divmod(int top, int bottom, int idiv, int mod);
void esubtract(struct node * node, int iindex, int e);

/* end of frag.c */


/* leaf.c */

/* looprank is the rank of the object currently being looped over */
extern struct codetree *looprank;

void leafshape(struct node * node, int mpval);
void leafvalue(struct node * node, int mpval, int mptype, int resval);
void leafvalue_const(struct node * node, int mpval, int mptype, int resval);
void genconst(struct node *, enum pmodes, int);
void genconst_trs(struct node *, enum pmodes, int);
void genlabel(struct node *, enum pmodes, int);
void genident(struct node *, enum pmodes, int);
void genfun(struct node *, enum pmodes, int);
void genop(struct node *, enum pmodes, int);

void genasysvar(struct node *, enum pmodes, int);
void gensysvar(struct node *, enum pmodes, int);
void gensysfun(struct node *, enum pmodes, int);
void genmfun(struct node * node, enum pmodes mode, int top);
void genmfun_type_ident(struct node * node, enum pmodes mode, int top);
void genmfun_free_ident(struct node * node, enum pmodes mode, int top);
void gendfun(struct node * node, enum pmodes mode, int top);
void genquad(struct node *, enum pmodes, int);
void genqquad(struct node * node, enum pmodes mode, int top);
void genqquad_assign(struct node * node, enum pmodes mode, int top);
void genrho(struct node *, enum pmodes, int);
void genrrho(struct node *, enum pmodes, int);
void gensort(struct node *, enum pmodes, int);
void genmember(struct node *, enum pmodes, int);
void genindex(struct node *, enum pmodes, int);
void genavec(struct node *, enum pmodes, int);

/* leaf_s.c */
void gentcav(struct node * node, enum pmodes mode, int top);
void gentypecon(struct node * node, enum pmodes mode, int top);
/* box.c */
void genbox(struct node * node, enum pmodes mode, int top);
void genlink(struct node * node, enum pmodes mode, int top);
/*void genunbox(struct node * node, enum pmodes mode, int top);*/

/* from misc.c */
void geniota(struct node *, enum pmodes, int);
void genravel(struct node *, enum pmodes, int);
void genroll(struct node *, enum pmodes, int);
void gendeal(struct node *, enum pmodes, int);
void gensub(struct node *, enum pmodes, int);
void gensemi(struct node *, enum pmodes, int);
void genempt(struct node *, enum pmodes, int);
void gengo(struct node *, enum pmodes, int);


/* sfuns.c */
void dsfunt(enum sfuns op, struct node * node,
	   struct node * left, struct node * right, int ival);
void dsfunv(enum sfuns op, struct node * node,
	   struct node * left, struct node * right,
	   int resval, int lresval, int rresval);
void adsfun(enum sfuns op, struct node * node, struct node * child,
	   int resval);
/*void msfunv(enum sfuns op, struct node * node, struct node * child,
    int resval);*/
void msfunv(int resval, enum sfuns op, struct node * node, 
	   struct node * child, int inval);

void identity(enum sfuns op, int resval, struct node * node);
void gendsfun(struct node * node, enum pmodes mode, int top);
void genmsfun(struct node * node, enum pmodes mode, int top);
void genouter(struct node * node, enum pmodes mode, int top);
void genred(struct node * node, enum pmodes mode, int top);
void genscan(struct node * node, enum pmodes mode, int top);
void gendecode(struct node * node, enum pmodes mode, int top);
void geninner(struct node * node, enum pmodes mode, int top);

/* from switch.c */
void switchbox(struct node * node, enum pmodes mode, int top);

/* from trans.c */
void gentrans(struct node * node, enum pmodes mode, int top);
void genreverse(struct node * node, enum pmodes mode, int top);
void gengwtake(struct node * node, enum pmodes mode, int top);
void gengwdrop(struct node * node, enum pmodes mode, int top);
void gentake(struct node * node, enum pmodes mode, int top);
void gendrop(struct node * node, enum pmodes mode, int top);
void gendtrans(struct node * node, enum pmodes mode, int top);

/* -------------------------------------- */
/* gen.c */
extern struct symnode *lookup_sym(char *name);

#endif
/* end of gen.h */
