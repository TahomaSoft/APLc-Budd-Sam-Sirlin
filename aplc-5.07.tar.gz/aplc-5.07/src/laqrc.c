/* laqr.f -- translated by f2c (version of 30 January 1990  16:02:04).
   You must link the resulting object file with the libraries:
	-lF77 -lI77 -lm -lc   (in that order)
*/

#include "f2c.h"

/* Table of constant values */

static integer c__0 = 0;
static doublereal c_b13 = 0.;
static integer c__2 = 2;
static integer c__1 = 1;
static doublereal c_b36 = 1.;

/* Subroutine */ 
extern int
dgelsx_(m, n, nrhs, a, lda, b, ldb, jpvt, rcond, rank, work, info)
  integer *m, *n, *nrhs;
  doublereal *a;
  integer *lda;
  doublereal *b;
  integer *ldb, *jpvt;
  doublereal *rcond;
  integer *rank;
  doublereal *work;
  integer *info;
{
  /* System generated locals */
  integer a_dim1, a_offset, b_dim1, b_offset, i_1, i_2;
  doublereal d_1;

  /* Local variables */
  static doublereal anrm, bnrm, smin, smax;
  static integer i, j, k, iascl, ibscl, ismin, ismax;
  static doublereal c1, c2;
  extern /* Subroutine */ int dtrsm_(), dlaic1_();
  static doublereal s1, s2, t1, t2;
  extern /* Subroutine */ int dorm2r_(), dlabad_();
  extern doublereal dlamch_(), dlange_();
  static integer mn;
  extern /* Subroutine */ int dlascl_(), dgeqpf_(), dlaset_(), xerbla_();
  static doublereal bignum;
  extern /* Subroutine */ int dlatzm_();
  static doublereal sminpr, smaxpr, smlnum;
  extern /* Subroutine */ int dtzrqf_();

  /* Parameter adjustments */
  a_dim1 = *lda;
  a_offset = a_dim1 + 1;
  a -= a_offset;
  b_dim1 = *ldb;
  b_offset = b_dim1 + 1;
  b -= b_offset;
  --jpvt;
  --work;

  /* Function Body */

/*  -- LAPACK driver routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DGELSX computes the minimum-norm solution to */
/*      min || A * X - B || */
/*  using a complete orthogonal factorization. That is, first we compute*/
/*  a QR factorization with column pivoting */
/*      A * P = Q * [ R11 R12 ] */
/*                  [  0  R22 ] */
/*  with the size RANK of R11 such that it is the largest leading */
/*  submatrix whose condition number is less than 1/RCOND. */
/*  Then, considering R22 to be negligible, we annihilate R12 through */
/*  orthogonal transformations from the right, arriving at */
/*     A * P = Q * [ T11 0 ] * Y */
/*                 [  0  0 ] */
/*  The minimum-norm solution is then */
/*     X = P * Y' [ inv(T11)*Q1'*B ] */
/*                [        0       ] */
/*  where Q1 are the first RANK columns of Q. */

/*  Arguments */
/*  ========= */

/*  M       (input) INTEGER */
/*          The number of rows of the matrix A.  M >= 0. */

/*  N       (input) INTEGER */
/*          The number of columns of the matrix A.  N >= 0. */

/*  NRHS    (input) INTEGER */
/*          The number of right-hand sides. NRHS >=0. */

/*  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N) */
/*          On entry, the M by N matrix A. */
/*          On exit, A has been overwritten by its complete orthogonal */
/*          factorization. */

/*  LDA     (input) INTEGER */
/*          The leading dimension of the array A.  LDA >= max(1,M). */

/*  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS) */

/*          on entry, the M by NRHS right-hand side. */
/*          on exit, the first N rows of B contain the minimum-norm */
/*                   solution. */

/*  LDB     (input) INTEGER */
/*          The leading dimension of the array B. LDB >= max(M,N). */

/*  JPVT    (input/output) INTEGER array, dimension (N) */
/*          on entry: If JPVT(i) <> 0, a(:,i) is permuted */
/*          to the front of AP, otherwise column i is a free column. */
/*          on exit: If JPVT(i) = k, then the i-th column of AP */
/*          was the k-th column of A. */

/*  RCOND   (input) DOUBLE PRECISION */
/*          The goal of the complete orthogonal factorization is to */
/*          identify a well-conditioned triangular matrix whose */
/*          condition number is less than 1/RCOND. */

/*  RANK    (output) INTEGER */
/*          The size of the largest leading triangular matrix in the */
/*          QR factorization (with pivoting) of A, whose condition number*/
/*          is less than 1/RCOND. */

/*  WORK    (workspace) DOUBLE PRECISION array, dimension */
/*                      (max( MN+3*N, 2*MN+NRHS )), */
/*          where MN = min(M,N) */

/*  INFO    (output) INTEGER */
/*          = 0: successful exit */
/*          < 0: if INFO = -i, the i-th argument had an illegal value */

/*  =====================================================================*/

/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. External Subroutines .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Executable Statements .. */

  mn = min(*m, *n);
  ismin = mn + 1;
  ismax = (mn << 1) + 1;

/*     Test the input arguments. */

  *info = 0;
  if (*m < 0) {
    *info = -1;
  } else if (*n < 0) {
    *info = -2;
  } else if (*nrhs < 0) {
    *info = -3;
  } else if (*lda < max(1, *m)) {
    *info = -5;
  } else if (*ldb < max(*m, *n)) {
    *info = -7;
  }
  if (*info != 0) {
    i_1 = -(*info);
    xerbla_("dgelsx", &i_1, 6L);
    return 0;
  }
/*     Quick return if possible */

/* Computing MAX */
  i_1 = *m, i_1 = min(*n, i_1);
  if (min(*nrhs, i_1) == 0) {
    *rank = 0;
    return 0;
  }
/*     Get machine parameters */

  smlnum = dlamch_("s", 1L) / dlamch_("p", 1L);
  bignum = 1. / smlnum;
  dlabad_(&smlnum, &bignum);

/*     Scale A, B if max entries outside range [SMLNUM,BIGNUM] */

  anrm = dlange_("m", m, n, &a[a_offset], lda, &work[1], 1L);
  iascl = 0;
  if (anrm > 0. && anrm < smlnum) {

/*        Scale matrix norm up to SMLNUM */

    dlascl_("g", &c__0, &c__0, &anrm, &smlnum, m, n, &a[a_offset], lda,
	info, 1L);
    iascl = 1;
  } else if (anrm > bignum) {

/*        Scale matrix norm down to BIGNUM */

    dlascl_("g", &c__0, &c__0, &anrm, &bignum, m, n, &a[a_offset], lda,
	info, 1L);
    iascl = 2;
  } else if (anrm == 0.) {

/*        Matrix all zero. Return zero solution. */

    i_1 = max(*m, *n);
    dlaset_("f", &i_1, nrhs, &c_b13, &c_b13, &b[b_offset], ldb, 1L);
    *rank = 0;
    goto L100;
  }
  bnrm = dlange_("m", m, nrhs, &b[b_offset], ldb, &work[1], 1L);
  ibscl = 0;
  if (bnrm > 0. && bnrm < smlnum) {

/*        Scale matrix norm up to SMLNUM */

    dlascl_("g", &c__0, &c__0, &bnrm, &smlnum, m, nrhs, &b[b_offset], ldb,
	info, 1L);
    ibscl = 1;
  } else if (bnrm > bignum) {

/*        Scale matrix norm down to BIGNUM */

    dlascl_("g", &c__0, &c__0, &bnrm, &bignum, m, nrhs, &b[b_offset], ldb,
	info, 1L);
    ibscl = 2;
  }
/*     Compute QR factorization with column pivoting of A: */
/*        A * P = Q * R */

  dgeqpf_(m, n, &a[a_offset], lda, &jpvt[1], &work[1], &work[mn + 1], info);


/*     workspace 3*N. Details of Householder rotations stored */
/*     in WORK(1:MN). */

/*     Determine RANK using incremental condition estimation */

  work[ismin] = 1.;
  work[ismax] = 1.;
  smax = (d_1 = a[a_dim1 + 1], abs(d_1));
  smin = smax;
  if ((d_1 = a[a_dim1 + 1], abs(d_1)) == 0.) {
    *rank = 0;
    i_1 = max(*m, *n);
    dlaset_("f", &i_1, nrhs, &c_b13, &c_b13, &b[b_offset], ldb, 1L);
    goto L100;
  } else {
    *rank = 1;
  }

L10:
  if (*rank < mn) {
    i = *rank + 1;
    dlaic1_(&c__2, rank, &work[ismin], &smin, &a[i * a_dim1 + 1], &a[i +
	    i * a_dim1], &sminpr, &s1, &c1);
    dlaic1_(&c__1, rank, &work[ismax], &smax, &a[i * a_dim1 + 1], &a[i +
	    i * a_dim1], &smaxpr, &s2, &c2);

    if (smaxpr * *rcond <= sminpr) {
      i_1 = *rank;
      for (i = 1; i <= i_1; ++i) {
	work[ismin + i - 1] = s1 * work[ismin + i - 1];
	work[ismax + i - 1] = s2 * work[ismax + i - 1];
/* L20: */
      }
      work[ismin + *rank] = c1;
      work[ismax + *rank] = c2;
      smin = sminpr;
      smax = smaxpr;
      ++(*rank);
      goto L10;
    }
  }
/*     Logically partition R = [ R11 R12 ] */
/*                             [  0  R22 ] */
/*     where R11 = R(1:RANK,1:RANK) */

/*     [R11,R12] = [ T11, 0 ] * Y */

  if (*rank < *n) {
    dtzrqf_(rank, n, &a[a_offset], lda, &work[mn + 1], info);
  }
/*     Details of Householder rotations stored in WORK(MN+1:2*MN) */

/*     B(1:M,1:NRHS) := Q' * B(1:M,1:NRHS) */

  dorm2r_("left", "transpose", m, nrhs, &mn, &a[a_offset], lda, &work[1], &
      b[b_offset], ldb, &work[(mn << 1) + 1], info, 4L, 9L);

/*     workspace NRHS */

/*     B(1:RANK,1:NRHS) := inv(T11) * B(1:RANK,1:NRHS) */

  dtrsm_("left", "upper", "no transpose", "non-unit", rank, nrhs, &c_b36, &
      a[a_offset], lda, &b[b_offset], ldb, 4L, 5L, 12L, 8L);

  i_1 = *n;
  for (i = *rank + 1; i <= i_1; ++i) {
    i_2 = *nrhs;
    for (j = 1; j <= i_2; ++j) {
      b[i + j * b_dim1] = 0.;
/* L30: */
    }
/* L40: */
  }

/*     B(1:N,1:NRHS) := Y' * B(1:N,1:NRHS) */

  if (*rank < *n) {
    i_1 = *rank;
    for (i = 1; i <= i_1; ++i) {
      i_2 = *n - *rank + 1;
      dlatzm_("left", &i_2, nrhs, &a[i + (*rank + 1) * a_dim1], lda, &
	  work[mn + i], &b[i + b_dim1], &b[*rank + 1 + b_dim1], ldb,
	  &work[(mn << 1) + 1], 4L);
/* L50: */
    }
  }
/*     workspace NRHS */

/*     B(1:N,1:NRHS) := P * B(1:N,1:NRHS) */

  i_1 = *nrhs;
  for (j = 1; j <= i_1; ++j) {
    i_2 = *n;
    for (i = 1; i <= i_2; ++i) {
      work[(mn << 1) + i] = 1.;
/* L60: */
    }
    i_2 = *n;
    for (i = 1; i <= i_2; ++i) {
      if (work[(mn << 1) + i] == 1.) {
	if (jpvt[i] != i) {
	  k = i;
	  t1 = b[k + j * b_dim1];
	  t2 = b[jpvt[k] + j * b_dim1];
      L70:
	  b[jpvt[k] + j * b_dim1] = t1;
	  work[(mn << 1) + k] = 0.;
	  t1 = t2;
	  k = jpvt[k];
	  t2 = b[jpvt[k] + j * b_dim1];
	  if (jpvt[k] != i) {
	    goto L70;
	  }
	  b[i + j * b_dim1] = t1;
	  work[(mn << 1) + k] = 0.;
	}
      }
/* L80: */
    }
/* L90: */
  }

/*     Undo scaling */

  if (iascl == 1) {
    dlascl_("g", &c__0, &c__0, &anrm, &smlnum, n, nrhs, &b[b_offset], ldb,
	info, 1L);
    dlascl_("u", &c__0, &c__0, &smlnum, &anrm, rank, rank, &a[a_offset],
	lda, info, 1L);
  } else if (iascl == 2) {
    dlascl_("g", &c__0, &c__0, &anrm, &bignum, n, nrhs, &b[b_offset], ldb,
	info, 1L);
    dlascl_("u", &c__0, &c__0, &bignum, &anrm, rank, rank, &a[a_offset],
	lda, info, 1L);
  }
  if (ibscl == 1) {
    dlascl_("g", &c__0, &c__0, &smlnum, &bnrm, n, nrhs, &b[b_offset], ldb,
	info, 1L);
  } else if (ibscl == 2) {
    dlascl_("g", &c__0, &c__0, &bignum, &bnrm, n, nrhs, &b[b_offset], ldb,
	info, 1L);
  }
L100:

  return 0;

/*     End of DGELSX */

}				     /* dgelsx_ */

doublereal
dlamch_(cmach, cmach_len)
  char *cmach;
  ftnlen cmach_len;
{
  /* Initialized data */

  static logical first = TRUE_;

  /* System generated locals */
  integer i_1;
  doublereal ret_val;

  /* Builtin functions */
  double pow_di();

  /* Local variables */
  static doublereal base;
  static integer beta;
  static doublereal emin, prec, emax;
  static integer imin, imax;
  static logical lrnd;
  static doublereal rmin, rmax, t, rmach;
  extern logical lsame_();
  static doublereal small, sfmin;
  extern /* Subroutine */ int dlamc2_();
  static integer it;
  static doublereal rnd, eps;


/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLAMCH determines double precision machine parameters. */

/*  Arguments */
/*  ========= */

/*  CMACH   (input) CHARACTER*1 */
/*          Specifies the value to be returned by DLAMCH: */
/*          = 'E' or 'e',   DLAMCH := eps */
/*          = 'S' or 's ,   DLAMCH := sfmin */
/*          = 'B' or 'b',   DLAMCH := base */
/*          = 'P' or 'p',   DLAMCH := eps*base */
/*          = 'N' or 'n',   DLAMCH := t */
/*          = 'R' or 'r',   DLAMCH := rnd */
/*          = 'M' or 'm',   DLAMCH := emin */
/*          = 'U' or 'u',   DLAMCH := rmin */
/*          = 'L' or 'l',   DLAMCH := emax */
/*          = 'O' or 'o',   DLAMCH := rmax */

/*          where */

/*          eps   = relative machine precision */
/*          sfmin = safe minimum, such that 1/sfmin does not overflow */
/*          base  = base of the machine */
/*          prec  = eps*base */
/*          t     = number of (base) digits in the mantissa */
/*          rnd   = 1.0 when rounding occurs in addition, 0.0 otherwise */

/*          emin  = minimum exponent before (gradual) underflow */
/*          rmin  = underflow threshold - base**(emin-1) */
/*          emax  = largest exponent before overflow */
/*          rmax  = overflow threshold  - (base**emax)*(1-eps) */


/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. External Subroutines .. */
/*     .. */
/*     .. Save statement .. */
/*     .. */
/*     .. Data statements .. */
/*     .. */
/*     .. Executable Statements .. */

  if (first) {
    first = FALSE_;
    dlamc2_(&beta, &it, &lrnd, &eps, &imin, &rmin, &imax, &rmax);
    base = (doublereal) beta;
    t = (doublereal) it;
    if (lrnd) {
      rnd = 1.;
      i_1 = 1 - it;
      eps = pow_di(&base, &i_1) / 2;
    } else {
      rnd = 0.;
      i_1 = 1 - it;
      eps = pow_di(&base, &i_1);
    }
    prec = eps * base;
    emin = (doublereal) imin;
    emax = (doublereal) imax;
    sfmin = rmin;
    small = 1. / rmax;
    if (small >= sfmin) {

/*           Use SMALL plus a bit, to avoid the possibility of
rounding */
/*           causing overflow when computing  1/sfmin. */

      sfmin = small * (eps + 1.);
    }
  }
  if (lsame_(cmach, "e", 1L, 1L)) {
    rmach = eps;
  } else if (lsame_(cmach, "s", 1L, 1L)) {
    rmach = sfmin;
  } else if (lsame_(cmach, "b", 1L, 1L)) {
    rmach = base;
  } else if (lsame_(cmach, "p", 1L, 1L)) {
    rmach = prec;
  } else if (lsame_(cmach, "n", 1L, 1L)) {
    rmach = t;
  } else if (lsame_(cmach, "r", 1L, 1L)) {
    rmach = rnd;
  } else if (lsame_(cmach, "m", 1L, 1L)) {
    rmach = emin;
  } else if (lsame_(cmach, "u", 1L, 1L)) {
    rmach = rmin;
  } else if (lsame_(cmach, "l", 1L, 1L)) {
    rmach = emax;
  } else if (lsame_(cmach, "o", 1L, 1L)) {
    rmach = rmax;
  }
  ret_val = rmach;
  return ret_val;

/*     End of DLAMCH */

}				     /* dlamch_ */


/* *********************************************************************** */

 /* Subroutine */ int
dlamc1_(beta, t, rnd, ieee1)
  integer *beta, *t;
  logical *rnd, *ieee1;
{
  /* Initialized data */

  static logical first = TRUE_;

  /* System generated locals */
  doublereal d_1, d_2;

  /* Local variables */
  static logical lrnd;
  static doublereal a, b, c, f;
  static integer lbeta;
  static doublereal savec;
  extern doublereal dlamc3_();
  static logical lieee1;
  static doublereal t1, t2;
  static integer lt;
  static doublereal one, qtr;


/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLAMC1 determines the machine parameters given by BETA, T, RND, and */

/*  IEEE1. */

/*  Arguments */
/*  ========= */

/*  BETA    (output) INTEGER */
/*          The base of the machine. */

/*  T       (output) INTEGER */
/*          The number of ( BETA ) digits in the mantissa. */

/*  RND     (output) LOGICAL */
/*          Specifies whether proper rounding  ( RND = .TRUE. )  or */
/*          chopping  ( RND = .FALSE. )  occurs in addition. This may not
*/
/*          be a reliable guide to the way in which the machine performs
*/
/*          its arithmetic. */

/*  IEEE1   (output) LOGICAL */
/*          Specifies whether rounding appears to be done in the IEEE */
/*          'round to nearest' style. */

/*  Further Details */
/*  =============== */

/*  The routine is based on the routine  ENVRON  by Malcolm and */
/*  incorporates suggestions by Gentleman and Marovich. See */

/*     Malcolm M. A. (1972) Algorithms to reveal properties of */
/*        floating-point arithmetic. Comms. of the ACM, 15, 949-951. */

/*     Gentleman W. M. and Marovich S. B. (1974) More on algorithms */
/*        that reveal properties of floating point arithmetic units. */
/*        Comms. of the ACM, 17, 276-277. */


/*     .. Local Scalars .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. Save statement .. */
/*     .. */
/*     .. Data statements .. */
/*     .. */
/*     .. Executable Statements .. */

  if (first) {
    first = FALSE_;
    one = 1.;

/*        LBETA,  LIEEE1,  LT and  LRND  are the  local values  of
BETA, */
/*        IEEE1, T and RND. */

/*        Throughout this routine  we use the function  DLAMC3  to
ensure */
/*        that relevant values are  stored and not held in registers,
 or */
/*        are not affected by optimizers. */

/*        Compute  a = 2.0**m  with the  smallest positive integer m
such */
/*        that */

/*           fl( a + 1.0 ) = a. */

    a = 1.;
    c = 1.;

/* +       WHILE( C.EQ.ONE )LOOP */
L10:
    if (c == one) {
      a *= 2;
      c = dlamc3_(&a, &one);
      d_1 = -a;
      c = dlamc3_(&c, &d_1);
      goto L10;
    }
/* +       END WHILE */

/*        Now compute  b = 2.0**m  with the smallest positive integer
m */
/*        such that */

/*           fl( a + b ) .gt. a. */

    b = 1.;
    c = dlamc3_(&a, &b);

/* +       WHILE( C.EQ.A )LOOP */
L20:
    if (c == a) {
      b *= 2;
      c = dlamc3_(&a, &b);
      goto L20;
    }
/* +       END WHILE */

/*        Now compute the base.  a and c  are neighbouring floating
point */
/*        numbers  in the  interval  ( beta**t, beta**( t + 1 ) )
and so */
/*        their difference is beta. Adding 0.25 to c is to ensure
that it */
/*        is truncated to beta and not ( beta - 1 ). */

    qtr = one / 4;
    savec = c;
    d_1 = -a;
    c = dlamc3_(&c, &d_1);
    lbeta = (integer) (c + qtr);

/*        Now determine whether rounding or chopping occurs,  by
adding a */
/*        bit  less  than  beta/2  and a  bit  more  than  beta/2  to
 a. */

    b = (doublereal) lbeta;
    d_1 = b / 2;
    d_2 = -b / 100;
    f = dlamc3_(&d_1, &d_2);
    c = dlamc3_(&f, &a);
    if (c == a) {
      lrnd = TRUE_;
    } else {
      lrnd = FALSE_;
    }
    d_1 = b / 2;
    d_2 = b / 100;
    f = dlamc3_(&d_1, &d_2);
    c = dlamc3_(&f, &a);
    if (lrnd && c == a) {
      lrnd = FALSE_;
    }
/*        Try and decide whether rounding is done in the  IEEE
'round to */
/*        nearest
' style. B/2 is half a unit in the last place of the two */
/*        numbers A and SAVEC. Furthermore, A is even, i.e. has last
bit */
/*        zero, and SAVEC is odd. Thus adding B/2 to A should not
change */
/*        A, but adding B/2 to SAVEC should change SAVEC. */

    d_1 = b / 2;
    t1 = dlamc3_(&d_1, &a);
    d_1 = b / 2;
    t2 = dlamc3_(&d_1, &savec);
    lieee1 = t1 == a && t2 > savec && lrnd;

/*        Now find  the  mantissa, t.  It should  be the  integer
part of */
/*        log to the base beta of a,  however it is safer to
determine  t */
/*        by powering.  So we find t as the smallest positive integer
for */
/*        which */

/*           fl( beta**t + 1.0 ) = 1.0. */

    lt = 0;
    a = 1.;
    c = 1.;

/* +       WHILE( C.EQ.ONE )LOOP */
L30:
    if (c == one) {
      ++lt;
      a *= lbeta;
      c = dlamc3_(&a, &one);
      d_1 = -a;
      c = dlamc3_(&c, &d_1);
      goto L30;
    }
/* +       END WHILE */

  }
  *beta = lbeta;
  *t = lt;
  *rnd = lrnd;
  *ieee1 = lieee1;
  return 0;

/*     End of DLAMC1 */

}				     /* dlamc1_ */


/* *********************************************************************** */

 /* Subroutine */ int
dlamc2_(beta, t, rnd, eps, emin, rmin, emax, rmax)
  integer *beta, *t;
  logical *rnd;
  doublereal *eps;
  integer *emin;
  doublereal *rmin;
  integer *emax;
  doublereal *rmax;
{
  /* Initialized data */

  static logical first = TRUE_;
  static logical iwarn = FALSE_;

  /* System generated locals */
  integer i_1;
  doublereal d_1, d_2, d_3, d_4, d_5;

  /* Builtin functions */
  double pow_di();

  /* Local variables */
  static logical ieee;
  static doublereal half;
  static logical lrnd;
  static doublereal leps, zero, a, b, c;
  static integer i, lbeta;
  static doublereal rbase;
  static integer lemin, lemax, gnmin;
  static doublereal small;
  static integer gpmin;
  static doublereal third, lrmin, lrmax, sixth;
  extern /* Subroutine */ int dlamc1_();
  extern doublereal dlamc3_();
  static logical lieee1;
  extern /* Subroutine */ int dlamc4_(), dlamc5_();
  static integer lt, ngnmin, ngpmin;
  static doublereal one, two;

/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLAMC2 determines the machine parameters specified in its argument */
/*  list. */

/*  Arguments */
/*  ========= */

/*  BETA    (output) INTEGER */
/*          The base of the machine. */

/*  T       (output) INTEGER */
/*          The number of ( BETA ) digits in the mantissa. */

/*  RND     (output) LOGICAL */
/*          Specifies whether proper rounding  ( RND = .TRUE. )  or */
/*          chopping  ( RND = .FALSE. )  occurs in addition. This may not
*/
/*          be a reliable guide to the way in which the machine performs
*/
/*          its arithmetic. */

/*  EPS     (output) DOUBLE PRECISION */
/*          The smallest positive number such that */

/*             fl( 1.0 - EPS ) .LT. 1.0, */

/*          where fl denotes the computed value. */

/*  EMIN    (output) INTEGER */
/*          The minimum exponent before (gradual) underflow occurs. */

/*  RMIN    (output) DOUBLE PRECISION */
/*          The smallest normalized number for the machine, given by */
/*          BASE**( EMIN - 1 ), where  BASE  is the floating point value
*/
/*          of BETA. */

/*  EMAX    (output) INTEGER */
/*          The maximum exponent before overflow occurs. */

/*  RMAX    (output) DOUBLE PRECISION */
/*          The largest positive number for the machine, given by */
/*          BASE**EMAX * ( 1 - EPS ), where  BASE  is the floating point
*/
/*          value of BETA. */

/*  Further Details */
/*  =============== */

/*  The computation of  EPS  is based on a routine PARANOIA by */
/*  W. Kahan of the University of California at Berkeley. */


/*     .. Local Scalars .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. External Subroutines .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Save statement .. */
/*     .. */
/*     .. Data statements .. */
/*     .. */
/*     .. Executable Statements .. */

  if (first) {
    first = FALSE_;
    zero = 0.;
    one = 1.;
    two = 2.;

/*        LBETA, LT, LRND, LEPS, LEMIN and LRMIN  are the local
values of */
/*        BETA, T, RND, EPS, EMIN and RMIN. */

/*        Throughout this routine  we use the function  DLAMC3  to
ensure */
/*        that relevant values are stored  and not held in registers,
 or */
/*        are not affected by optimizers. */

/*        DLAMC1 returns the parameters  LBETA, LT, LRND and LIEEE1.
*/

    dlamc1_(&lbeta, &lt, &lrnd, &lieee1);

/*        Start to find EPS. */

    b = (doublereal) lbeta;
    i_1 = -lt;
    a = pow_di(&b, &i_1);
    leps = a;

/*        Try some tricks to see whether or not this is the correct
EPS. */

    b = two / 3;
    half = one / 2;
    d_1 = -half;
    sixth = dlamc3_(&b, &d_1);
    third = dlamc3_(&sixth, &sixth);
    d_1 = -half;
    b = dlamc3_(&third, &d_1);
    b = dlamc3_(&b, &sixth);
    b = abs(b);
    if (b < leps) {
      b = leps;
    }
    leps = 1.;

/* +       WHILE( ( LEPS.GT.B ).AND.( B.GT.ZERO ) )LOOP */
L10:
    if (leps > b && b > zero) {
      leps = b;
      d_1 = half * leps;
/* Computing 5th power */
      d_3 = two, d_4 = d_3, d_3 *= d_3;
/* Computing 2nd power */
      d_5 = leps;
      d_2 = d_4 * (d_3 * d_3) * (d_5 * d_5);
      c = dlamc3_(&d_1, &d_2);
      d_1 = -c;
      c = dlamc3_(&half, &d_1);
      b = dlamc3_(&half, &c);
      d_1 = -b;
      c = dlamc3_(&half, &d_1);
      b = dlamc3_(&half, &c);
      goto L10;
    }
/* +       END WHILE */

    if (a < leps) {
      leps = a;
    }
/*        Computation of EPS complete. */

/*        Now find  EMIN.  Let A = + or - 1, and + or - (1 + BASE**(
-3)). */
/*        Keep dividing  A by BETA until (gradual) underflow occurs.
This */
/*        is detected when we cannot recover the previous A. */

    rbase = one / lbeta;
    small = one;
    for (i = 1; i <= 3; ++i) {
      d_1 = small * rbase;
      small = dlamc3_(&d_1, &zero);
/* L20: */
    }
    a = dlamc3_(&one, &small);
    dlamc4_(&ngpmin, &one, &lbeta);
    d_1 = -one;
    dlamc4_(&ngnmin, &d_1, &lbeta);
    dlamc4_(&gpmin, &a, &lbeta);
    d_1 = -a;
    dlamc4_(&gnmin, &d_1, &lbeta);
    ieee = FALSE_;

    if (ngpmin == ngnmin && gpmin == gnmin) {
      if (ngpmin == gpmin) {
	lemin = ngpmin;
/*            ( Non twos-complement machines, no gradual
underflow; */
/*              e.g.,  VAX ) */
      } else if (gpmin - ngpmin == 3) {
	lemin = ngpmin - 1 + lt;
	ieee = TRUE_;
/*            ( Non twos-complement machines, with gradual
underflow; */
/*              e.g., IEEE standard followers ) */
      } else {
	lemin = min(ngpmin, gpmin);
/*            ( A guess; no known machine ) */
	iwarn = TRUE_;
      }

    } else if (ngpmin == gpmin && ngnmin == gnmin) {
      if ((i_1 = ngpmin - ngnmin, abs(i_1)) == 1) {
	lemin = max(ngpmin, ngnmin);
/*            ( Twos-complement machines, no gradual
underflow; */
/*              e.g., CYBER 205 ) */
      } else {
	lemin = min(ngpmin, ngnmin);
/*            ( A guess; no known machine ) */
	iwarn = TRUE_;
      }

    } else if ((i_1 = ngpmin - ngnmin, abs(i_1)) == 1 && gpmin == gnmin) {

      if (gpmin - min(ngpmin, ngnmin) == 3) {
	lemin = max(ngpmin, ngnmin) - 1 + lt;
/*            ( Twos-complement machines with gradual
underflow; */
/*              no known machine ) */
      } else {
	lemin = min(ngpmin, ngnmin);
/*            ( A guess; no known machine ) */
	iwarn = TRUE_;
      }

    } else {
/* Computing MAX */
      i_1 = ngpmin, i_1 = min(ngnmin, i_1), i_1 = min(gpmin, i_1);
      lemin = min(gnmin, i_1);
/*         ( A guess; no known machine ) */
      iwarn = TRUE_;
    }
/* ** */
/* Comment out this if block if EMIN is ok */
    if (iwarn) {
      first = TRUE_;
      printf("\n warning. the value emin may be incorrect:-");
      printf("  emin = %d\n", lemin);
      printf(" if, after inspection, the value emin looks");
      printf(" acceptable please comment out\n");
      printf(" the if block as marked within the code of routine");
      printf(" dlamc2,\n otherwise supply emin explicitly.\n");
    }
/* ** */

/*        Assume IEEE arithmetic if we found denormalised  numbers
above, */
/*        or if arithmetic seems to round in the  IEEE style,
determined */
/*        in routine DLAMC1. A true IEEE machine should have both
things */
/*        true; however, faulty machines may have one or the other. */


    ieee = ieee || lieee1;

/*        Compute  RMIN by successive division by  BETA. We could
compute */
/*        RMIN as BASE**( EMIN - 1 ),  but some machines underflow
during */
/*        this computation. */

    lrmin = 1.;
    i_1 = 1 - lemin;
    for (i = 1; i <= i_1; ++i) {
      d_1 = lrmin * rbase;
      lrmin = dlamc3_(&d_1, &zero);
/* L30: */
    }

/*        Finally, call DLAMC5 to compute EMAX and RMAX. */

    dlamc5_(&lbeta, &lt, &lemin, &ieee, &lemax, &lrmax);
  }
  *beta = lbeta;
  *t = lt;
  *rnd = lrnd;
  *eps = leps;
  *emin = lemin;
  *rmin = lrmin;
  *emax = lemax;
  *rmax = lrmax;

  return 0;


/*     End of DLAMC2 */

}				     /* dlamc2_ */


/* *********************************************************************** */

doublereal
dlamc3_(a, b)
  doublereal *a, *b;
{
  /* System generated locals */
  doublereal ret_val;


/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLAMC3  is intended to force  A  and  B  to be stored prior to doing
*/
/*  the addition of  A  and  B ,  for use in situations where optimizers
*/
/*  might hold one of these in a register. */

/*  Arguments */
/*  ========= */

/*  A, B    (input) DOUBLE PRECISION */
/*          The values A and B. */


/*     .. Executable Statements .. */

  ret_val = *a + *b;

  return ret_val;

/*     End of DLAMC3 */

}				     /* dlamc3_ */


/* *********************************************************************** */

 /* Subroutine */ int
dlamc4_(emin, start, base)
  integer *emin;
  doublereal *start;
  integer *base;
{
  /* System generated locals */
  integer i_1;
  doublereal d_1;

  /* Local variables */
  static doublereal zero, a;
  static integer i;
  static doublereal rbase, b1, b2, c1, c2, d1, d2;
  extern doublereal dlamc3_();
  static doublereal one;


/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLAMC4 is a service routine for DLAMC2. */

/*  Arguments */
/*  ========= */

/*  EMIN    (output) EMIN */
/*          The minimum exponent before (gradual) underflow, computed by
*/
/*          setting A = START and dividing by BASE until the previous A */

/*          can not be recovered. */

/*  START   (input) DOUBLE PRECISION */
/*          The starting point for determining EMIN. */

/*  BASE    (input) INTEGER */
/*          The base of the machine. */


/*     .. Local Scalars .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. Executable Statements .. */

  a = *start;
  one = 1.;
  rbase = one / *base;
  zero = 0.;
  *emin = 1;
  d_1 = a * rbase;
  b1 = dlamc3_(&d_1, &zero);
  c1 = a;
  c2 = a;
  d1 = a;
  d2 = a;
/* +    WHILE( ( C1.EQ.A ).AND.( C2.EQ.A ).AND. */
/*    $       ( D1.EQ.A ).AND.( D2.EQ.A )      )LOOP */
L10:
  if (c1 == a && c2 == a && d1 == a && d2 == a) {
    --(*emin);
    a = b1;
    d_1 = a / *base;
    b1 = dlamc3_(&d_1, &zero);
    d_1 = b1 * *base;
    c1 = dlamc3_(&d_1, &zero);
    d1 = zero;
    i_1 = *base;
    for (i = 1; i <= i_1; ++i) {
      d1 += b1;
/* L20: */
    }
    d_1 = a * rbase;
    b2 = dlamc3_(&d_1, &zero);
    d_1 = b2 / rbase;
    c2 = dlamc3_(&d_1, &zero);
    d2 = zero;
    i_1 = *base;
    for (i = 1; i <= i_1; ++i) {
      d2 += b2;
/* L30: */
    }
    goto L10;
  }
/* +    END WHILE */

  return 0;

/*     End of DLAMC4 */

}				     /* dlamc4_ */


/* *********************************************************************** */

 /* Subroutine */ int
dlamc5_(beta, p, emin, ieee, emax, rmax)
  integer *beta, *p, *emin;
  logical *ieee;
  integer *emax;
  doublereal *rmax;
{
  /* System generated locals */
  integer i_1;
  doublereal d_1;

  /* Local variables */
  static integer lexp;
  static doublereal oldy;
  static integer uexp, i;
  static doublereal y, z;
  static integer nbits;
  extern doublereal dlamc3_();
  static doublereal recbas;
  static integer exbits, expsum, try_;


/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLAMC5 attempts to compute RMAX, the largest machine floating-point */

/*  number, without overflow.  It assumes that EMAX + abs(EMIN) sum */
/*  approximately to a power of 2.  It will fail on machines where this */

/*  assumption does not hold, for example, the Cyber 205 (EMIN = -28625,
*/
/*  EMAX = 28718).  It will also fail if the value supplied for EMIN is */

/*  too large (i.e. too close to zero), probably with overflow. */

/*  Arguments */
/*  ========= */

/*  BETA    (input) INTEGER */
/*          The base of floating-point arithmetic. */

/*  P       (input) INTEGER */
/*          The number of base BETA digits in the mantissa of a */
/*          floating-point value. */

/*  EMIN    (input) INTEGER */
/*          The minimum exponent before (gradual) underflow. */

/*  IEEE    (input) LOGICAL */
/*          A logical flag specifying whether or not the arithmetic */
/*          system is thought to comply with the IEEE standard. */

/*  EMAX    (output) INTEGER */
/*          The largest exponent before overflow */

/*  RMAX    (output) DOUBLE PRECISION */
/*          The largest machine floating-point number. */


/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Executable Statements .. */

/*     First compute LEXP and UEXP, two powers of 2 that bound */
/*     abs(EMIN). We then assume that EMAX + abs(EMIN) will sum */
/*     approximately to the bound that is closest to abs(EMIN). */
/*     (EMAX is the exponent of the required number RMAX). */

  lexp = 1;
  exbits = 1;
L10:
  try_ = lexp << 1;
  if (try_ <= -(*emin)) {
    lexp = try_;
    ++exbits;
    goto L10;
  }
  if (lexp == -(*emin)) {
    uexp = lexp;
  } else {
    uexp = try_;
    ++exbits;
  }

/*     Now -LEXP is less than or equal to EMIN, and -UEXP is greater */
/*     than or equal to EMIN. EXBITS is the number of bits needed to */
/*     store the exponent. */

  if (uexp + *emin > -lexp - *emin) {
    expsum = lexp << 1;
  } else {
    expsum = uexp << 1;
  }

/*     EXPSUM is the exponent range, approximately equal to */
/*     EMAX - EMIN + 1 . */

  *emax = expsum + *emin - 1;
  nbits = exbits + 1 + *p;

/*     NBITS is the total number of bits needed to store a */
/*     floating-point number. */

  if (nbits % 2 == 1 && *beta == 2) {

/*        Either there are an odd number of bits used to store a */
/*        floating-point number, which is unlikely, or some bits are
*/
/*        not used in the representation of numbers, which is
possible, */
/*        (e.g. Cray machines) or the mantissa has an implicit bit, */

/*        (e.g. IEEE machines, Dec Vax machines), which is perhaps
the */
/*        most likely. We have to assume the last alternative. */
/*        If this is true, then we need to reduce EMAX by one because
*/
/*        there must be some way of representing zero in an
implicit-bit */
/*        system. On machines like Cray, we are reducing EMAX by one
*/
/*        unnecessarily. */

    --(*emax);
  }
  if (*ieee) {

/*        Assume we are on an IEEE machine which reserves one
exponent */
/*        for infinity and NaN. */

    --(*emax);
  }
/*     Now create RMAX, the largest machine number, which should */
/*     be equal to (1.0 - BETA**(-P)) * BETA**EMAX . */

/*     First compute 1.0 - BETA**(-P), being careful that the */
/*     result is less than 1.0 . */

  recbas = 1. / *beta;
  z = *beta - 1.;
  y = 0.;
  i_1 = *p;
  for (i = 1; i <= i_1; ++i) {
    z *= recbas;
    if (y < 1.) {
      oldy = y;
    }
    y = dlamc3_(&y, &z);
/* L20: */
  }
  if (y >= 1.) {
    y = oldy;
  }
/*     Now multiply by BETA**EMAX to get RMAX. */

  i_1 = *emax;
  for (i = 1; i <= i_1; ++i) {
    d_1 = y * *beta;
    y = dlamc3_(&d_1, &c_b13);
/* L30: */
  }

  *rmax = y;
  return 0;

/*     End of DLAMC5 */

}				     /* dlamc5_ */

 /* Subroutine */ int
dlabad_(small, large)
  doublereal *small, *large;
{
  /* Builtin functions */
  double d_lg10(), sqrt();


/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLABAD takes as input the values computed by DLAMCH for underflow and
*/
/*  overflow, and returns the square root of each of these values if the
*/
/*  log of LARGE is sufficiently large.  This subroutine is intended to */

/*  identify machines with a large exponent range, such as the Crays, and
*/
/*  redefine the underflow and overflow limits to be the square roots of
*/
/*  the values computed by DLAMCH.  This subroutine is needed because */
/*  DLAMCH does not compensate for poor arithmetic in the upper half of */

/*  the exponent range, as is found on a Cray. */

/*  Arguments */
/*  ========= */

/*  SMALL   (input/output) DOUBLE PRECISION */
/*          On entry, the underflow threshold as computed by DLAMCH. */
/*          On exit, if LOG10(LARGE) is sufficiently large, the square */
/*          root of SMALL, otherwise unchanged. */

/*  LARGE   (input/output) DOUBLE PRECISION */
/*          On entry, the overflow threshold as computed by DLAMCH. */
/*          On exit, if LOG10(LARGE) is sufficiently large, the square */
/*          root of LARGE, otherwise unchanged. */

/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Executable Statements .. */

/*     If it looks like we're on a Cray, take the square root of */
/*     SMALL and LARGE to avoid overflow and underflow problems. */

  if (d_lg10(large) > 2e3) {
    *small = sqrt(*small);
    *large = sqrt(*large);
  }
  return 0;

/*     End of DLABAD */

}				     /* dlabad_ */

doublereal
dlapy2_(x, y)
  doublereal *x, *y;
{
  /* System generated locals */
  doublereal ret_val, d_1;

  /* Builtin functions */
  double sqrt();

  /* Local variables */
  static doublereal xabs, yabs, w, z;


/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLAPY2 returns sqrt(x**2+y**2), taking care not to cause unnecessary
*/
/*  overflow. */

/*  Arguments */
/*  ========= */

/*  X       (input) DOUBLE PRECISION */
/*  Y       (input) DOUBLE PRECISION */
/*          X and Y specify the values x and y. */

/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Executable Statements .. */

  xabs = abs(*x);
  yabs = abs(*y);
  w = max(xabs, yabs);
  z = min(xabs, yabs);
  if (z == 0.) {
    ret_val = w;
  } else {
/* Computing 2nd power */
    d_1 = z / w;
    ret_val = w * sqrt(d_1 * d_1 + 1.);
  }
  return ret_val;

/*     End of DLAPY2 */

}				     /* dlapy2_ */

 /* Subroutine */ int
xerbla_(srname, info, srname_len)
  char *srname;
  integer *info;
  ftnlen srname_len;
{

/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  XERBLA  is an error handler for the LAPACK routines. */
/*  It is called by an LAPACK routine if an input parameter has an */
/*  invalid value.  A message is printed and execution stops. */

/*  Installers may consider modifying the STOP statement in order to */
/*  call system-specific exception-handling facilities. */

/*  Arguments */
/*  ========= */

/*  SRNAME  (input) CHARACTER*6 */
/*          The name of the routine which called XERBLA. */

/*  INFO    (input) INTEGER */
/*          The position of the invalid parameter in the parameter list */

/*          of the calling routine. */

/*     .. Executable Statements .. */

  printf("\n ** on entry to %s parameter number %d had an illegal value\n",
      srname, *info);
  return (0);
/*     End of XERBLA */
}				     /* xerbla_ */

 /* Subroutine */ int
dlascl_(type, kl, ku, cfrom, cto, m, n, a, lda, info,
    type_len)
  char *type;
  integer *kl, *ku;
  doublereal *cfrom, *cto;
  integer *m, *n;
  doublereal *a;
  integer *lda, *info;
  ftnlen type_len;
{
  /* System generated locals */
  integer a_dim1, a_offset, i_1, i_2, i_3, i_4, i_5;

  /* Local variables */
  static logical done;
  static doublereal ctoc;
  static integer i, j;
  extern logical lsame_();
  static integer itype, k1, k2, k3, k4;
  static doublereal cfrom1;
  extern doublereal dlamch_();
  static doublereal cfromc;
  extern /* Subroutine */ int xerbla_();
  static doublereal bignum, smlnum, mul, cto1;

  /* Parameter adjustments */
  a_dim1 = *lda;
  a_offset = a_dim1 + 1;
  a -= a_offset;

  /* Function Body */

/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLASCL multiplies the M by N real matrix A by the real scalar */
/*  CTO/CFROM.  This is done without over/underflow as long as the final
*/
/*  result CTO*A(I,J)/CFROM does not over/underflow. TYPE specifies that
*/
/*  A may be full, upper triangular, lower triangular, upper Hessenberg,
*/
/*  or banded. */

/*  Arguments */
/*  ========= */

/*  TYPE    (input) CHARACTER*1 */
/*          TYPE indices the storage type of the input matrix. */
/*          = 'G':  A is a full matrix. */
/*          = 'L':  A is a lower triangular matrix. */
/*          = 'U':  A is an upper triangular matrix. */
/*          = 'H':  A is an upper Hessenberg matrix. */
/*          = 'B':  A is a symmetric band matrix with lower bandwidth KL
*/
/*                  and upper bandwidth KU and with the only the lower */
/*                  half stored. */
/*          = 'Q':  A is a symmetric band matrix with lower bandwidth KL
*/
/*                  and upper bandwidth KU and with the only the upper */
/*                  half stored. */
/*          = 'Z':  A is a band matrix with lower bandwidth KL and upper
*/
/*                  bandwidth KU. */

/*  KL      (input) INTEGER */
/*          The lower bandwidth of A.  Referenced only if TYPE = 'B', */
/*          'Q' or 'Z'. */

/*  KU      (input) INTEGER */
/*          The upper bandwidth of A.  Referenced only if TYPE = 'B', */
/*          'Q' or 'Z'. */

/*  CFROM   (input) DOUBLE PRECISION */
/*  CTO     (input) DOUBLE PRECISION */
/*          The matrix A is multiplied by CTO/CFROM. A(I,J) is computed */

/*          without over/underflow if the final result CTO*A(I,J)/CFROM */

/*          can be represented without over/underflow.  CFROM must be */
/*          nonzero. */

/*  M       (input) INTEGER */
/*          The number of rows of the matrix A.  M >= 0. */

/*  N       (input) INTEGER */
/*          The number of columns of the matrix A.  N >= 0. */

/*  A       (input/output) DOUBLE PRECISION array, dimension (LDA,M) */
/*          The matrix to be multiplied by CTO/CFROM.  See TYPE for the */

/*          storage type. */

/*  LDA     (input) INTEGER */
/*          The leading dimension of the array A.  LDA >= max(1,M). */

/*  INFO    (output) INTEGER */
/*          0  - successful exit */
/*          <0 - if INFO = -i, the i-th argument had an illegal value. */

/*  =====================================================================
*/

/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. External Subroutines .. */
/*     .. */
/*     .. Executable Statements .. */

/*     Test the input arguments */

  *info = 0;

  if (lsame_(type, "g", 1L, 1L)) {
    itype = 0;
  } else if (lsame_(type, "l", 1L, 1L)) {
    itype = 1;
  } else if (lsame_(type, "u", 1L, 1L)) {
    itype = 2;
  } else if (lsame_(type, "h", 1L, 1L)) {
    itype = 3;
  } else if (lsame_(type, "b", 1L, 1L)) {
    itype = 4;
  } else if (lsame_(type, "q", 1L, 1L)) {
    itype = 5;
  } else if (lsame_(type, "z", 1L, 1L)) {
    itype = 6;
  } else {
    itype = -1;
  }

  if (itype == -1) {
    *info = -1;
  } else if (*cfrom == 0.) {
    *info = -4;
  } else if (*m < 0) {
    *info = -6;
  } else if (*n < 0 || itype == 4 && *n != *m || itype == 5 && *n != *m) {
    *info = -7;
  } else if (itype <= 3 && *lda < max(1, *m)) {
    *info = -9;
  } else if (itype >= 4) {
/* Computing MAX */
    i_1 = *m - 1;
    if (*kl < 0 || *kl > max(0, i_1)) {
      *info = -2;
/* Computing MAX */
      i_1 = *n - 1;
    } else if (*ku < 0 || *ku > max(0, i_1) || (itype == 4 || itype == 5)
	&& *kl != *ku) {
      *info = -3;
    } else if (itype == 4 && *lda < *kl + 1 || itype == 5 && *lda < *ku +
	1 || itype == 6 && *lda < (*kl << 1) + *ku + 1) {
      *info = -9;
    }
  }
  if (*info != 0) {
    i_1 = -(*info);
    xerbla_("dlascl", &i_1, 6L);
    return 0;
  }
/*     Quick return if possible */

  if (*n == 0 || *m == 0) {
    return 0;
  }
/*     Get machine parameters */

  smlnum = dlamch_("s", 1L);
  bignum = 1. / smlnum;

  cfromc = *cfrom;
  ctoc = *cto;

L10:
  cfrom1 = cfromc * smlnum;
  cto1 = ctoc / bignum;
  if (abs(cfrom1) > abs(ctoc) && ctoc != 0.) {
    mul = smlnum;
    done = FALSE_;
    cfromc = cfrom1;
  } else if (abs(cto1) > abs(cfromc)) {
    mul = bignum;
    done = FALSE_;
    ctoc = cto1;
  } else {
    mul = ctoc / cfromc;
    done = TRUE_;
  }

  if (itype == 0) {

/*        Full matrix */

    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
      i_2 = *m;
      for (i = 1; i <= i_2; ++i) {
	a[i + j * a_dim1] *= mul;
/* L20: */
      }
/* L30: */
    }

  } else if (itype == 1) {

/*        Lower triangular matrix */

    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
      i_2 = *m;
      for (i = j; i <= i_2; ++i) {
	a[i + j * a_dim1] *= mul;
/* L40: */
      }
/* L50: */
    }

  } else if (itype == 2) {

/*        Upper triangular matrix */

    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
      i_2 = min(j, *m);
      for (i = 1; i <= i_2; ++i) {
	a[i + j * a_dim1] *= mul;
/* L60: */
      }
/* L70: */
    }

  } else if (itype == 3) {

/*        Upper Hessenberg matrix */

    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
/* Computing MAX */
      i_3 = j + 1;
      i_2 = min(*m, i_3);
      for (i = 1; i <= i_2; ++i) {
	a[i + j * a_dim1] *= mul;
/* L80: */
      }
/* L90: */
    }

  } else if (itype == 4) {

/*        Lower half of a symmetric band matrix */

    k3 = *kl + 1;
    k4 = *n + 1;
    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
/* Computing MAX */
      i_3 = k3, i_4 = k4 - j;
      i_2 = min(i_4, i_3);
      for (i = 1; i <= i_2; ++i) {
	a[i + j * a_dim1] *= mul;
/* L100: */
      }
/* L110: */
    }

  } else if (itype == 5) {

/*        Upper half of a symmetric band matrix */

    k1 = *ku + 2;
    k3 = *ku + 1;
    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
/* Computing MAX */
      i_2 = k1 - j;
      i_3 = k3;
      for (i = max(1, i_2); i <= i_3; ++i) {
	a[i + j * a_dim1] *= mul;
/* L120: */
      }
/* L130: */
    }

  } else if (itype == 6) {

/*        Band matrix */

    k1 = *kl + *ku + 2;
    k2 = *kl + 1;
    k3 = (*kl << 1) + *ku + 1;
    k4 = *kl + *ku + 1 + *m;
    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
/* Computing MAX */
      i_3 = k1 - j;
/* Computing MAX */
      i_4 = k3, i_5 = k4 - j;
      i_2 = min(i_5, i_4);
      for (i = max(k2, i_3); i <= i_2; ++i) {
	a[i + j * a_dim1] *= mul;
/* L140: */
      }
/* L150: */
    }

  }
  if (!done) {
    goto L10;
  }
  return 0;

/*     End of DLASCL */

}				     /* dlascl_ */

 /* Subroutine */ int
dlaset_(uplo, m, n, alpha, beta, a, lda, uplo_len)
  char *uplo;
  integer *m, *n;
  doublereal *alpha, *beta, *a;
  integer *lda;
  ftnlen uplo_len;
{
  /* System generated locals */
  integer a_dim1, a_offset, i_1, i_2, i_3;

  /* Local variables */
  static integer i, j;
  extern logical lsame_();

  /* Parameter adjustments */
  a_dim1 = *lda;
  a_offset = a_dim1 + 1;
  a -= a_offset;

  /* Function Body */

/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLASET initializes an m-by-n matrix A to BETA on the diagonal and */
/*  ALPHA on the offdiagonals. */

/*  Arguments */
/*  ========= */

/*  UPLO    (input) CHARACTER*1 */
/*          Specifies the part of the matrix A to be set. */
/*          = 'U':      Upper triangular part is set; the strictly lower
*/
/*                      triangular part of A is not changed. */
/*          = 'L':      Lower triangular part is set; the strictly upper
*/
/*                      triangular part of A is not changed. */
/*          Otherwise:  All of the matrix A is set. */

/*  M       (input) INTEGER */
/*          The number of rows of the matrix A.  M >= 0. */

/*  N       (input) INTEGER */
/*          The number of columns of the matrix A.  N >= 0. */

/*  ALPHA   (input) DOUBLE PRECISION */
/*          The constant to which the offdiagonal elements are to be set.
*/

/*  BETA    (input) DOUBLE PRECISION */
/*          The constant to which the diagonal elements are to be set. */

/*  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N) */
/*          On exit, the leading m-by-n submatrix of A is set as follows:
*/

/*          if UPLO = 'U', A(i,j) = ALPHA, 1<=i<=j-1, 1<=j<=n, */
/*          if UPLO = 'L', A(i,j) = ALPHA, j+1<=i<=m, 1<=j<=n, */
/*          otherwise,     A(i,j) = ALPHA, 1<=i<=m, 1<=j<=n, i.ne.j, */

/*          and, for all UPLO, A(i,i) = BETA, 1<=i<=min(m,n). */

/*  LDA     (input) INTEGER */
/*          The leading dimension of the array A.  LDA >= max(1,M). */


/*     .. Local Scalars .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Executable Statements .. */

  if (lsame_(uplo, "u", 1L, 1L)) {

/*        Set the strictly upper triangular or trapezoidal part of
the */
/*        array to ALPHA. */

    i_1 = *n;
    for (j = 2; j <= i_1; ++j) {
/* Computing MAX */
      i_3 = j - 1;
      i_2 = min(*m, i_3);
      for (i = 1; i <= i_2; ++i) {
	a[i + j * a_dim1] = *alpha;
/* L10: */
      }
/* L20: */
    }

  } else if (lsame_(uplo, "l", 1L, 1L)) {

/*        Set the strictly lower triangular or trapezoidal part of
the */
/*        array to ALPHA. */

    i_1 = min(*m, *n);
    for (j = 1; j <= i_1; ++j) {
      i_2 = *m;
      for (i = j + 1; i <= i_2; ++i) {
	a[i + j * a_dim1] = *alpha;
/* L30: */
      }
/* L40: */
    }

  } else {

/*        Set the leading m-by-n submatrix to ALPHA. */

    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
      i_2 = *m;
      for (i = 1; i <= i_2; ++i) {
	a[i + j * a_dim1] = *alpha;
/* L50: */
      }
/* L60: */
    }
  }

/*     Set the first min(M,N) diagonal elements to BETA. */

  i_1 = min(*m, *n);
  for (i = 1; i <= i_1; ++i) {
    a[i + i * a_dim1] = *beta;
/* L70: */
  }

  return 0;

/*     End of DLASET */

}				     /* dlaset_ */

 /* Subroutine */ int
dgeqpf_(m, n, a, lda, jpvt, tau, work, info)
  integer *m, *n;
  doublereal *a;
  integer *lda, *jpvt;
  doublereal *tau, *work;
  integer *info;
{
  /* System generated locals */
  integer a_dim1, a_offset, i_1, i_2, i_3;
  doublereal d_1, d_2;

  /* Builtin functions */
  double sqrt();

  /* Local variables */
  static doublereal temp;
  extern doublereal dnrm2_();
  static doublereal temp2;
  static integer i, j;
  extern /* Subroutine */ int dlarf_();
  static integer itemp;
  extern /* Subroutine */ int dswap_(), dgeqr2_(), dorm2r_();
  static integer ma, mn;
  extern /* Subroutine */ int dlarfg_();
  extern integer idamax_();
  extern /* Subroutine */ int xerbla_();
  static doublereal aii;
  static integer pvt;

  /* Parameter adjustments */
  a_dim1 = *lda;
  a_offset = a_dim1 + 1;
  a -= a_offset;
  --jpvt;
  --tau;
  --work;

  /* Function Body */

/*  -- LAPACK test routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DGEQPF computes a QR factorization with column pivoting of a */
/*  real m by n matrix A: A*P = Q*R */

/*  Arguments */
/*  ========= */

/*  M       (input) INTEGER */
/*          The number of rows of the matrix A. M >= 0. */

/*  N       (input) INTEGER */
/*          The number of columns of the matrix A. N >= 0 */

/*  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N) */
/*          On entry, the m by n matrix A. */
/*          On exit, the upper triangle of the array contains the */
/*          min(m,n) by n upper triangular matrix R; the elements */
/*          below the diagonal, together with the array TAU, */
/*          represent the orthogonal matrix Q as a product of */
/*          min(m,n) elementary reflectors. */

/*  LDA     (input) INTEGER */
/*          The leading dimension of the array A. LDA >= max(1,M). */

/*  JPVT    (input/output) INTEGER array, dimension (N) */
/*          on entry: If JPVT(I) <> 0, column I of A is permuted */
/*          to the front of AP (a leading column) */
/*          IF JPVT(I) == 0, column I of A is a free column. */
/*          on exit: If JPVT(I) = K, then the Ith column of AP */
/*          was the Kth column of A. */

/*  TAU     (output) DOUBLE PRECISION array, dimension (min(M,N)) */
/*          Stores further details of */
/*          the orthogonal matrix Q (see A). */

/*  WORK    (workspace) DOUBLE PRECISION array, dimension (3*N) */

/*  INFO    (output) INTEGER */
/*          = 0: successful exit */
/*          < 0: if INFO = -i, the i-th argument had an illegal value */

/*  Further Details */
/*  =============== */

/*  The matrix Q is represented as a product of elementary reflectors */

/*     Q = H(1) H(2) . . . H(n) */

/*  Each H(i) has the form */

/*     H = I - tau * v * v' */

/*  where tau is a real scalar, and v is a real vector with */
/*  v(1:i-1) = 0 and v(i) = 1; v(i+1:m) is stored on exit in A(i+1:m,i).
*/

/*  The matrix P is represented in jpvt as follows: If */
/*     jpvt(j) = i */
/*  then the jth column of P is the ith canonical unit vector. */

/*  =====================================================================
*/

/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. External Subroutines .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. Executable Statements .. */

/*     Test the input arguments */

  *info = 0;
  if (*m < 0) {
    *info = -1;
  } else if (*n < 0) {
    *info = -2;
  } else if (*lda < max(1, *m)) {
    *info = -4;
  }
  if (*info != 0) {
    i_1 = -(*info);
    xerbla_("dgeqpf", &i_1, 6L);
    return 0;
  }
/*     Quick return if possible */

  if (*m == 0 || *n == 0) {
    return 0;
  }
  mn = min(*m, *n);

/*     Move initial columns up front */

  itemp = 1;
  i_1 = *n;
  for (i = 1; i <= i_1; ++i) {
    if (jpvt[i] != 0) {
      if (i != itemp) {
	dswap_(m, &a[i * a_dim1 + 1], &c__1, &a[itemp * a_dim1 + 1], &
	    c__1);
	jpvt[i] = jpvt[itemp];
	jpvt[itemp] = i;
      } else {
	jpvt[i] = i;
      }
      ++itemp;
    } else {
      jpvt[i] = i;
    }
/* L10: */
  }
  --itemp;

/*     Compute the QR factorization and update remaining columns */

  if (itemp > 0) {
    ma = min(itemp, *m);
    dgeqr2_(m, &ma, &a[a_offset], lda, &tau[1], &work[1], info);
    if (ma < *n) {
      i_1 = *n - ma;
      dorm2r_("left", "transpose", m, &i_1, &ma, &a[a_offset], lda, &
	  tau[1], &a[(ma + 1) * a_dim1 + 1], lda, &work[1], info,
	  4L, 9L);
    }
  }
  if (itemp < mn) {

/*        Initialize partial column norms. The first n entries of */
/*        work store the exact column norms. */

    i_1 = *n;
    for (i = itemp + 1; i <= i_1; ++i) {
      i_2 = *m - itemp;
      work[i] = dnrm2_(&i_2, &a[itemp + 1 + i * a_dim1], &c__1);
      work[*n + i] = work[i];
/* L20: */
    }

/*        Compute factorization */

    i_1 = mn;
    for (i = itemp + 1; i <= i_1; ++i) {

/*           Determine ith pivot column and swap if necessary */

      i_2 = *n - i + 1;
      pvt = i - 1 + idamax_(&i_2, &work[i], &c__1);

      if (pvt != i) {
	dswap_(m, &a[pvt * a_dim1 + 1], &c__1, &a[i * a_dim1 + 1], &
	    c__1);
	itemp = jpvt[pvt];
	jpvt[pvt] = jpvt[i];
	jpvt[i] = itemp;
	work[pvt] = work[i];
	work[*n + pvt] = work[*n + i];
      }
/*           Generate elementary reflector H(i) */

      if (i < *m) {
	i_2 = *m - i + 1;
	dlarfg_(&i_2, &a[i + i * a_dim1], &a[i + 1 + i * a_dim1], &
	    c__1, &tau[i]);
      } else {
	dlarfg_(&c__1, &a[*m + *m * a_dim1], &a[*m + *m * a_dim1], &
	    c__1, &tau[*m]);
      }

      if (i < *n) {

/*              Apply H(i) to A(i:m,i+1:n) from the left */

	aii = a[i + i * a_dim1];
	a[i + i * a_dim1] = 1.;
	i_2 = *m - i + 1;
	i_3 = *n - i;
	dlarf_("left", &i_2, &i_3, &a[i + i * a_dim1], &c__1, &tau[i],
	    &a[i + (i + 1) * a_dim1], lda, &work[(*n << 1) + 1],
	    4L);
	a[i + i * a_dim1] = aii;
      }
/*           Update partial column norms */

      i_2 = *n;
      for (j = i + 1; j <= i_2; ++j) {
	if (work[j] != 0.) {
/* Computing 2nd power */
	  d_2 = (d_1 = a[i + j * a_dim1], abs(d_1)) / work[j];
	  temp = 1. - d_2 * d_2;
	  temp = max(temp, 0.);
/* Computing 2nd power */
	  d_1 = work[j] / work[*n + j];
	  temp2 = temp * .05 * (d_1 * d_1) + 1.;
	  if (temp2 == 1.) {
	    if (*m - i > 0) {
	      i_3 = *m - i;
	      work[j] = dnrm2_(&i_3, &a[i + 1 + j * a_dim1], &
		  c__1);
	      work[*n + j] = work[j];
	    } else {
	      work[j] = 0.;
	      work[*n + j] = 0.;
	    }
	  } else {
	    work[j] *= sqrt(temp);
	  }
	}
/* L30: */
      }

/* L40: */
    }
  }
  return 0;

/*     End of DGEQPF */

}				     /* dgeqpf_ */

 /* Subroutine */ int
dlaic1_(job, j, x, sest, w, gamma, sestpr, s, c)
  integer *job, *j;
  doublereal *x, *sest, *w, *gamma, *sestpr, *s, *c;
{
  /* System generated locals */
  doublereal d_1, d_2, d_3, d_4;

  /* Builtin functions */
  double sqrt(), d_sign();

  /* Local variables */
  extern doublereal ddot_();
  static doublereal sine, test, zeta1, zeta2, b, t, alpha, norma, s1, s2;
  extern doublereal dlamch_();
  static doublereal absgam, absalp, cosine, absest, eps, tmp;

  /* Parameter adjustments */
  --x;
  --w;

  /* Function Body */

/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLAIC1 applies one step of incremental condition estimation in */
/*  its simplest version: */

/*  Let x, twonorm(x) = 1, be an approximate singular vector of an j-by-j
*/
/*  lower triangular matrix L, such that */
/*           twonorm(L*x) = sest */
/*  Then DLAIC1 computes sestpr, s, c such that */
/*  the vector */
/*                  [ s*x ] */
/*           xhat = [  c  ] */
/*  is an approximate singular vector of */
/*                  [ L     0  ] */
/*           Lhat = [ w' gamma ] */
/*  in the sense that */
/*           twonorm(Lhat*xhat) = sestpr. */

/*  Depending on JOB, an estimate for the largest or smallest singular */
/*  value is computed. */

/*  Note that [s c]' and sestpr**2 is an eigenpair of the system */

/*      diag(sest*sest, 0) + [alpha  gamma] * [ alpha ] */
/*                                            [ gamma ] */

/*  where  alpha =  x'*w. */

/*  Arguments */
/*  ========= */

/*  JOB     (input) INTEGER */
/*          = 1: an estimate for the largest singular value is computed.
*/
/*          = 2: an estimate for the smallest singular value is computed.
*/

/*  J       (input) INTEGER */
/*          Length of X and W */

/*  X       (input) DOUBLE PRECISION array, dimension (J) */
/*          The j-vector x. */

/*  SEST    (input) DOUBLE PRECISION */
/*          Estimated singular value of j by j matrix L */

/*  W       (input) DOUBLE PRECISION array, dimension (J) */
/*          The j-vector w. */

/*  GAMMA   (input) DOUBLE PRECISION */
/*          The diagonal element gamma. */

/*  SESTPR  (output) DOUBLE PRECISION */
/*          Estimated singular value of (j+1) by (j+1) matrix Lhat. */

/*  S       (output) DOUBLE PRECISION */
/*          Sine needed in forming xhat. */

/*  C       (output) DOUBLE PRECISION */
/*          Cosine needed in forming xhat. */

/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. Executable Statements .. */

  eps = dlamch_("epsilon", 7L);
  alpha = ddot_(j, &x[1], &c__1, &w[1], &c__1);

  absalp = abs(alpha);
  absgam = abs(*gamma);
  absest = abs(*sest);

  if (*job == 1) {

/*        Estimating largest singular value */

/*        special cases */

    if (*sest == 0.) {
      s1 = max(absgam, absalp);
      if (s1 == 0.) {
	*s = 0.;
	*c = 1.;
	*sestpr = 0.;
      } else {
	*s = alpha / s1;
	*c = *gamma / s1;
	tmp = sqrt(*s * *s + *c * *c);
	*s /= tmp;
	*c /= tmp;
	*sestpr = s1 * tmp;
      }
      return 0;
    } else if (absgam <= eps * absest) {
      *s = 1.;
      *c = 0.;
      tmp = max(absest, absalp);
      s1 = absest / tmp;
      s2 = absalp / tmp;
      *sestpr = tmp * sqrt(s1 * s1 + s2 * s2);
      return 0;
    } else if (absalp <= eps * absest) {
      s1 = absgam;
      s2 = absest;
      if (s1 <= s2) {
	*s = 1.;
	*c = 0.;
	*sestpr = s2;
      } else {
	*s = 0.;
	*c = 1.;
	*sestpr = s1;
      }
      return 0;
    } else if (absest <= eps * absalp || absest <= eps * absgam) {
      s1 = absgam;
      s2 = absalp;
      if (s1 <= s2) {
	tmp = s1 / s2;
	*s = sqrt(tmp * tmp + 1.);
	*sestpr = s2 * *s;
	*c = *gamma / s2 / *s;
	*s = d_sign(&c_b36, &alpha) / *s;
      } else {
	tmp = s2 / s1;
	*c = sqrt(tmp * tmp + 1.);
	*sestpr = s1 * *c;
	*s = alpha / s1 / *c;
	*c = d_sign(&c_b36, gamma) / *c;
      }
      return 0;
    } else {

/*           normal case */

      zeta1 = alpha / absest;
      zeta2 = *gamma / absest;

      b = (1. - zeta1 * zeta1 - zeta2 * zeta2) * .5;
      *c = zeta1 * zeta1;
      if (b > 0.) {
	t = *c / (b + sqrt(b * b + *c));
      } else {
	t = sqrt(b * b + *c) - b;
      }

      sine = -zeta1 / t;
      cosine = -zeta2 / (t + 1.);
      tmp = sqrt(sine * sine + cosine * cosine);
      *s = sine / tmp;
      *c = cosine / tmp;
      *sestpr = sqrt(t + 1.) * absest;
      return 0;
    }

  } else if (*job == 2) {

/*        Estimating smallest singular value */

/*        special cases */

    if (*sest == 0.) {
      *sestpr = 0.;
      if (max(absgam, absalp) == 0.) {
	sine = 1.;
	cosine = 0.;
      } else {
	sine = -(*gamma);
	cosine = alpha;
      }
/* Computing MAX */
      d_1 = abs(sine), d_2 = abs(cosine);
      s1 = max(d_2, d_1);
      *s = sine / s1;
      *c = cosine / s1;
      tmp = sqrt(*s * *s + *c * *c);
      *s /= tmp;
      *c /= tmp;
      return 0;
    } else if (absgam <= eps * absest) {
      *s = 0.;
      *c = 1.;
      *sestpr = absgam;
      return 0;
    } else if (absalp <= eps * absest) {
      s1 = absgam;
      s2 = absest;
      if (s1 <= s2) {
	*s = 0.;
	*c = 1.;
	*sestpr = s1;
      } else {
	*s = 1.;
	*c = 0.;
	*sestpr = s2;
      }
      return 0;
    } else if (absest <= eps * absalp || absest <= eps * absgam) {
      s1 = absgam;
      s2 = absalp;
      if (s1 <= s2) {
	tmp = s1 / s2;
	*c = sqrt(tmp * tmp + 1.);
	*sestpr = absest * (tmp / *c);
	*s = -(*gamma / s2) / *c;
	*c = d_sign(&c_b36, &alpha) / *c;
      } else {
	tmp = s2 / s1;
	*s = sqrt(tmp * tmp + 1.);
	*sestpr = absest / *s;
	*c = alpha / s1 / *s;
	*s = -d_sign(&c_b36, gamma) / *s;
      }
      return 0;
    } else {

/*           normal case */

      zeta1 = alpha / absest;
      zeta2 = *gamma / absest;

/* Computing MAX */
      d_3 = zeta1 * zeta1 + 1. + (d_1 = zeta1 * zeta2, abs(d_1)), d_4 =
	  (d_2 = zeta1 * zeta2, abs(d_2)) + zeta2 * zeta2;
      norma = max(d_4, d_3);

/*           See if root is closer to zero or to ONE */

      test = (zeta1 - zeta2) * 2. * (zeta1 + zeta2) + 1.;
      if (test >= 0.) {

/*              root is close to zero, compute directly */

	b = (zeta1 * zeta1 + zeta2 * zeta2 + 1.) * .5;
	*c = zeta2 * zeta2;
	t = *c / (b + sqrt((d_1 = b * b - *c, abs(d_1))));
	sine = zeta1 / (1. - t);
	cosine = -zeta2 / t;
	*sestpr = sqrt(t + eps * 4. * eps * norma) * absest;
      } else {

/*              root is closer to ONE, shift by that amount */


	b = (zeta2 * zeta2 + zeta1 * zeta1 - 1.) * .5;
	*c = zeta1 * zeta1;
	if (b >= 0.) {
	  t = -(*c) / (b + sqrt(b * b + *c));
	} else {
	  t = b - sqrt(b * b + *c);
	}
	sine = -zeta1 / t;
	cosine = -zeta2 / (t + 1.);
	*sestpr = sqrt(t + 1. + eps * 4. * eps * norma) * absest;
      }
      tmp = sqrt(sine * sine + cosine * cosine);
      *s = sine / tmp;
      *c = cosine / tmp;
      return 0;

    }
  }
  return 0;

/*     End of DLAIC1 */

}				     /* dlaic1_ */

 /* Subroutine */ int
dtzrqf_(m, n, a, lda, tau, info)
  integer *m, *n;
  doublereal *a;
  integer *lda;
  doublereal *tau;
  integer *info;
{
  /* System generated locals */
  integer a_dim1, a_offset, i_1, i_2;
  doublereal d_1;

  /* Local variables */
  extern /* Subroutine */ int dger_();
  static integer i, k;
  extern /* Subroutine */ int dgemv_(), dcopy_(), daxpy_();
  static integer m1;
  extern /* Subroutine */ int dlarfg_(), xerbla_();

  /* Parameter adjustments */
  a_dim1 = *lda;
  a_offset = a_dim1 + 1;
  a -= a_offset;
  --tau;

  /* Function Body */

/*  -- LAPACK routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DTZRQF reduces the m by n ( m.le.n ) upper trapezoidal matrix A */
/*  to upper triangular form by means of orthogonal transformations. */

/*  The m by n ( m.le.n ) upper trapezoidal matrix A given by */

/*     A = ( U  X ), */

/*  where U is an m by m upper triangular matrix, is factorized as */

/*     A = ( R  0 ) * P, */

/*  where P is an n by n orthogonal matrix and R is an m by m upper */
/*  triangular matrix. */

/*  The  factorization is obtained by Householder's method.  The kth */
/*  transformation matrix, P( k ), which is used to introduce zeros into
*/
/*  the ( m - k + 1 )th row of A, is given in the form */

/*     P( k ) = ( I     0   ), */
/*              ( 0  T( k ) ) */

/*  where */

/*     T( k ) = I - tau*u( k )*u( k )',   u( k ) = (   1    ), */
/*                                                 (   0    ) */
/*                                                 ( z( k ) ) */

/*  tau is a scalar and z( k ) is an ( n - m ) element vector. */
/*  tau and z( k ) are chosen to annihilate the elements of the kth row */

/*  of X. */

/*  The scalar tau is returned in the kth element of TAU and the vector */

/*  u( k ) in the kth row of A, such that the elements of z( k ) are */
/*  in  a( k, m + 1 ), ..., a( k, n ). The elements of R are returned in
*/
/*  the upper triangular part of A. */

/*  P is given by */

/*     P =  P( 1 ) * P( 2 ) * ... * P( m ). */

/*  Arguments */
/*  ========= */

/*  M       (input) INTEGER */
/*          The number of rows of the matrix A.  M >= 0. */
/*          If M = 0 then an immediate return is effected. */

/*  N       (input) INTEGER */
/*          The number of columns of the matrix A.  N >= M. */

/*  A       (input/output) DOUBLE PRECISION array, dimension */
/*                         (LDA,max(1,N)) */

/*          On entry, the leading M by N upper trapezoidal part of the */
/*          array A must contain the matrix to be factorized. */

/*          On exit, the M by M upper triangular part of A will contain */

/*          the upper triangular matrix R and the remaining M by (N - M)
*/
/*          upper trapezoidal part of A will contain details of the */
/*          factorization as described above. */

/*  LDA     (input) INTEGER */
/*          The leading dimension of the array A.  LDA >= max(1,M). */

/*  TAU     (output) DOUBLE PRECISION array, dimension (max(1,M)) */
/*          On exit, TAU( k ) contains the scalar tau( k ) for the */
/*          ( m - k + 1 )th transformation as described above.  If */
/*          P( k ) = I  then TAU( k ) = 0.0. */

/*  INFO    (output) INTEGER */
/*          =    0: successful exit */
/*          .lt. 0: INFO = -k, the k-th argument had an illegal value */

/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. External Subroutines .. */
/*     .. */
/*     .. Executable Statements .. */

/*     Test the input parameters. */

  *info = 0;
  if (*m < 0) {
    *info = -1;
  } else if (*n < *m) {
    *info = -2;
  } else if (*lda < max(1, *m)) {
    *info = -4;
  }
  if (*info != 0) {
    i_1 = -(*info);
    xerbla_("dtzrqf", &i_1, 6L);
    return 0;
  }
/*     Perform the factorization. */

  if (*m == 0) {
    return 0;
  }
  if (*m == *n) {
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
      tau[i] = 0.;
/* L10: */
    }
  } else {
/* Computing MAX */
    i_1 = *m + 1;
    m1 = min(*n, i_1);
    for (k = *m; k >= 1; --k) {

/*           Use a Householder reflection to zero the kth row of
A. */
/*           First set up the reflection. */

      i_1 = *n - *m + 1;
      dlarfg_(&i_1, &a[k + k * a_dim1], &a[k + m1 * a_dim1], lda, &tau[
	      k]);

      if (tau[k] != 0. && k > 1) {

/*              We now perform the operation  A := A*P( k ).
*/

/*              Use the first ( k - 1 ) elements of TAU to
store  a( k ), */
/*              where  a( k ) consists of the first ( k - 1 )
elements of */
/*              the  kth column  of  A.  Also  let  B  denote
 the  first */
/*              ( k - 1 ) rows of the last ( n - m ) columns
of A. */

	i_1 = k - 1;
	dcopy_(&i_1, &a[k * a_dim1 + 1], &c__1, &tau[1], &c__1);

/*              Form   w = a( k ) + B*z( k )  in TAU. */

	i_1 = k - 1;
	i_2 = *n - *m;
	dgemv_("no transpose", &i_1, &i_2, &c_b36, &a[m1 * a_dim1 + 1]
	    ,lda, &a[k + m1 * a_dim1], lda, &c_b36, &tau[1], &
	    c__1, 12L);

/*              Now form  a( k ) := a( k ) - tau*w */
/*              and       B      := B      - tau*w*z( k )'. */


	i_1 = k - 1;
	d_1 = -tau[k];
	daxpy_(&i_1, &d_1, &tau[1], &c__1, &a[k * a_dim1 + 1], &c__1);

	i_1 = k - 1;
	i_2 = *n - *m;
	d_1 = -tau[k];
	dger_(&i_1, &i_2, &d_1, &tau[1], &c__1, &a[k + m1 * a_dim1],
	    lda, &a[m1 * a_dim1 + 1], lda);
      }
/* L20: */
    }
  }

  return 0;

/*     End of DTZRQF */

}				     /* dtzrqf_ */

 /* Subroutine */ int
dorm2r_(side, trans, m, n, k, a, lda, tau, c, ldc, work,
    info, side_len, trans_len)
  char *side, *trans;
  integer *m, *n, *k;
  doublereal *a;
  integer *lda;
  doublereal *tau, *c;
  integer *ldc;
  doublereal *work;
  integer *info;
  ftnlen side_len;
  ftnlen trans_len;
{
  /* System generated locals */
  integer a_dim1, a_offset, c_dim1, c_offset, i_1, i_2;

  /* Local variables */
  static logical left;
  static integer i;
  extern /* Subroutine */ int dlarf_();
  extern logical lsame_();
  static integer i1, i2, i3, ic, jc, mi, ni, nq;
  extern /* Subroutine */ int xerbla_();
  static logical notran;
  static doublereal aii;

  /* Parameter adjustments */
  a_dim1 = *lda;
  a_offset = a_dim1 + 1;
  a -= a_offset;
  --tau;
  c_dim1 = *ldc;
  c_offset = c_dim1 + 1;
  c -= c_offset;
  --work;

  /* Function Body */

/*  -- LAPACK routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DORM2R overwrites the general real m by n matrix C with */

/*        Q * C  if SIDE = 'L' and TRANS = 'N', or */

/*        Q'* C  if SIDE = 'L' and TRANS = 'T', or */

/*        C * Q  if SIDE = 'R' and TRANS = 'N', or */

/*        C * Q' if SIDE = 'R' and TRANS = 'T', */

/*  where Q is a real orthogonal matrix defined as the product of k */
/*  elementary reflectors */

/*        Q = H(1) H(2) . . . H(k) */

/*  as returned by DGEQRF. Q is of order m if SIDE = 'L' and of order n */

/*  if SIDE = 'R'. */

/*  Arguments */
/*  ========= */

/*  SIDE    (input) CHARACTER*1 */
/*          = 'L': apply Q or Q' from the Left */
/*          = 'R': apply Q or Q' from the Right */

/*  TRANS   (input) CHARACTER*1 */
/*          = 'N': apply Q  (No transpose) */
/*          = 'T': apply Q' (Transpose) */

/*  M       (input) INTEGER */
/*          The number of rows of the matrix C. M >= 0. */

/*  N       (input) INTEGER */
/*          The number of columns of the matrix C. N >= 0. */

/*  K       (input) INTEGER */
/*          The number of elementary reflectors whose product defines */
/*          the matrix Q. */
/*          If SIDE = 'L', M >= K >= 0; */
/*          if SIDE = 'R', N >= K >= 0. */

/*  A       (input) DOUBLE PRECISION array, dimension (LDA,K) */
/*          The i-th column must contain the vector which defines the */
/*          elementary reflector H(i), for i = 1,2,...,k, as returned by
*/
/*          DGEQRF in the first k columns of its array argument A. */
/*          A is modified by the routine but restored on exit. */

/*  LDA     (input) INTEGER */
/*          The leading dimension of the array A. */
/*          If SIDE = 'L', LDA >= max(1,M); */
/*          if SIDE = 'R', LDA >= max(1,N). */

/*  TAU     (input) DOUBLE PRECISION array, dimension (K) */
/*          TAU(i) must contain the scalar factor of the elementary */
/*          reflector H(i), as returned by DGEQRF. */

/*  C       (input/output) DOUBLE PRECISION array, dimension (LDC,N) */
/*          On entry, the m by n matrix C. */
/*          On exit, C is overwritten by Q*C or Q'*C or C*Q' or C*Q. */

/*  LDC     (input) INTEGER */
/*          The leading dimension of the array C. LDC >= max(1,M). */

/*  WORK    (workspace) DOUBLE PRECISION array, dimension */
/*                                   (N) if SIDE = 'L', */
/*                                   (M) if SIDE = 'R' */

/*  INFO    (output) INTEGER */
/*          = 0: successful exit */
/*          < 0: if INFO = -i, the i-th argument had an illegal value */

/*  =====================================================================
*/

/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. External Subroutines .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Executable Statements .. */

/*     Test the input arguments */

  *info = 0;
  left = lsame_(side, "l", 1L, 1L);
  notran = lsame_(trans, "n", 1L, 1L);

/*     NQ is the order of Q */

  if (left) {
    nq = *m;
  } else {
    nq = *n;
  }
  if (!left && !lsame_(side, "r", 1L, 1L)) {
    *info = -1;
  } else if (!notran && !lsame_(trans, "t", 1L, 1L)) {
    *info = -2;
  } else if (*m < 0) {
    *info = -3;
  } else if (*n < 0) {
    *info = -4;
  } else if (*k < 0 || *k > nq) {
    *info = -5;
  } else if (*lda < max(1, nq)) {
    *info = -7;
  } else if (*ldc < max(1, *m)) {
    *info = -10;
  }
  if (*info != 0) {
    i_1 = -(*info);
    xerbla_("dorm2r", &i_1, 6L);
    return 0;
  }
/*     Quick return if possible */

  if (*m == 0 || *n == 0 || *k == 0) {
    return 0;
  }
  if (left && !notran || !left && notran) {
    i1 = 1;
    i2 = *k;
    i3 = 1;
  } else {
    i1 = *k;
    i2 = 1;
    i3 = -1;
  }

  if (left) {
    ni = *n;
    jc = 1;
  } else {
    mi = *m;
    ic = 1;
  }

  i_1 = i2;
  i_2 = i3;
  for (i = i1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) {
    if (left) {

/*           H(i) is applied to C(i:m,1:n) */

      mi = *m - i + 1;
      ic = i;
    } else {

/*           H(i) is applied to C(1:m,i:n) */

      ni = *n - i + 1;
      jc = i;
    }

/*        Apply H(i) */

    aii = a[i + i * a_dim1];
    a[i + i * a_dim1] = 1.;
    dlarf_(side, &mi, &ni, &a[i + i * a_dim1], &c__1, &tau[i], &c[ic + jc
	    * c_dim1], ldc, &work[1], 1L);
    a[i + i * a_dim1] = aii;
/* L10: */
  }
  return 0;

/*     End of DORM2R */

}				     /* dorm2r_ */

 /* Subroutine */ int
dtrsm_(side, uplo, transa, diag, m, n, alpha, a, lda, b,
    ldb, side_len, uplo_len, transa_len, diag_len)
  char *side, *uplo, *transa, *diag;
  integer *m, *n;
  doublereal *alpha, *a;
  integer *lda;
  doublereal *b;
  integer *ldb;
  ftnlen side_len;
  ftnlen uplo_len;
  ftnlen transa_len;
  ftnlen diag_len;
{
  /* System generated locals */
  integer a_dim1, a_offset, b_dim1, b_offset, i_1, i_2, i_3;

  /* Local variables */
  static integer info;
  static doublereal temp;
  static integer i, j, k;
  static logical lside;
  extern logical lsame_();
  static integer nrowa;
  static logical upper;
  extern /* Subroutine */ int xerbla_();
  static logical nounit;

  /* Parameter adjustments */
  a_dim1 = *lda;
  a_offset = a_dim1 + 1;
  a -= a_offset;
  b_dim1 = *ldb;
  b_offset = b_dim1 + 1;
  b -= b_offset;

  /* Function Body */
/*     .. Scalar Arguments .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DTRSM  solves one of the matrix equations */

/*     op( A )*X = alpha*B,   or   X*op( A ) = alpha*B, */

/*  where alpha is a scalar, X and B are m by n matrices, A is a unit, or
*/
/*  non-unit,  upper or lower triangular matrix  and  op( A )  is one  of
*/

/*     op( A ) = A   or   op( A ) = A'. */

/*  The matrix X is overwritten on B. */

/*  Parameters */
/*  ========== */

/*  SIDE   - CHARACTER*1. */
/*           On entry, SIDE specifies whether op( A ) appears on the left
*/
/*           or right of X as follows: */

/*              SIDE = 'L' or 'l'   op( A )*X = alpha*B. */

/*              SIDE = 'R' or 'r'   X*op( A ) = alpha*B. */

/*           Unchanged on exit. */

/*  UPLO   - CHARACTER*1. */
/*           On entry, UPLO specifies whether the matrix A is an upper or
*/
/*           lower triangular matrix as follows: */

/*              UPLO = 'U' or 'u'   A is an upper triangular matrix. */

/*              UPLO = 'L' or 'l'   A is a lower triangular matrix. */

/*           Unchanged on exit. */

/*  TRANSA - CHARACTER*1. */
/*           On entry, TRANSA specifies the form of op( A ) to be used in
*/
/*           the matrix multiplication as follows: */

/*              TRANSA = 'N' or 'n'   op( A ) = A. */

/*              TRANSA = 'T' or 't'   op( A ) = A'. */

/*              TRANSA = 'C' or 'c'   op( A ) = A'. */

/*           Unchanged on exit. */

/*  DIAG   - CHARACTER*1. */
/*           On entry, DIAG specifies whether or not A is unit triangular
*/
/*           as follows: */

/*              DIAG = 'U' or 'u'   A is assumed to be unit triangular. */


/*              DIAG = 'N' or 'n'   A is not assumed to be unit */
/*                                  triangular. */

/*           Unchanged on exit. */

/*  M      - INTEGER. */
/*           On entry, M specifies the number of rows of B. M must be at
*/
/*           least zero. */
/*           Unchanged on exit. */

/*  N      - INTEGER. */
/*           On entry, N specifies the number of columns of B.  N must be
*/
/*           at least zero. */
/*           Unchanged on exit. */

/*  ALPHA  - DOUBLE PRECISION. */
/*           On entry,  ALPHA specifies the scalar  alpha. When  alpha is
*/
/*           zero then  A is not referenced and  B need not be set before
*/
/*           entry. */
/*           Unchanged on exit. */

/*  A      - DOUBLE PRECISION array of DIMENSION ( LDA, k ), where k is m
*/
/*           when  SIDE = 'L' or 'l'  and is  n  when  SIDE = 'R' or 'r'.
*/
/*           Before entry  with  UPLO = 'U' or 'u',  the  leading  k by k
*/
/*           upper triangular part of the array  A must contain the upper
*/
/*           triangular matrix  and the strictly lower triangular part of
*/
/*           A is not referenced. */
/*           Before entry  with  UPLO = 'L' or 'l',  the  leading  k by k
*/
/*           lower triangular part of the array  A must contain the lower
*/
/*           triangular matrix  and the strictly upper triangular part of
*/
/*           A is not referenced. */
/*           Note that when  DIAG = 'U' or 'u',  the diagonal elements of
*/
/*           A  are not referenced either,  but are assumed to be  unity.
*/
/*           Unchanged on exit. */

/*  LDA    - INTEGER. */
/*           On entry, LDA specifies the first dimension of A as declared
*/
/*           in the calling (sub) program.  When  SIDE = 'L' or 'l'  then
*/
/*           LDA  must be at least  max( 1, m ),  when  SIDE = 'R' or 'r'
*/
/*           then LDA must be at least max( 1, n ). */
/*           Unchanged on exit. */

/*  B      - DOUBLE PRECISION array of DIMENSION ( LDB, n ). */
/*           Before entry,  the leading  m by n part of the array  B must
*/
/*           contain  the  right-hand  side  matrix  B,  and  on exit  is
*/
/*           overwritten by the solution matrix  X. */

/*  LDB    - INTEGER. */
/*           On entry, LDB specifies the first dimension of B as declared
*/
/*           in  the  calling  (sub)  program.   LDB  must  be  at  least
*/
/*           max( 1, m ). */
/*           Unchanged on exit. */


/*  Level 3 Blas routine. */


/*  -- Written on 8-February-1989. */
/*     Jack Dongarra, Argonne National Laboratory. */
/*     Iain Duff, AERE Harwell. */
/*     Jeremy Du Croz, Numerical Algorithms Group Ltd. */
/*     Sven Hammarling, Numerical Algorithms Group Ltd. */


/*     .. External Functions .. */
/*     .. External Subroutines .. */
/*     .. Intrinsic Functions .. */
/*     .. Local Scalars .. */
/*     .. Parameters .. */
/*     .. */
/*     .. Executable Statements .. */

/*     Test the input parameters. */

  lside = lsame_(side, "l", 1L, 1L);
  if (lside) {
    nrowa = *m;
  } else {
    nrowa = *n;
  }
  nounit = lsame_(diag, "n", 1L, 1L);
  upper = lsame_(uplo, "u", 1L, 1L);

  info = 0;
  if (!lside && !lsame_(side, "r", 1L, 1L)) {
    info = 1;
  } else if (!upper && !lsame_(uplo, "l", 1L, 1L)) {
    info = 2;
  } else if (!lsame_(transa, "n", 1L, 1L) && !lsame_(transa, "t", 1L, 1L)
      && !lsame_(transa, "c", 1L, 1L)) {
    info = 3;
  } else if (!lsame_(diag, "u", 1L, 1L) && !lsame_(diag, "n", 1L, 1L)) {
    info = 4;
  } else if (*m < 0) {
    info = 5;
  } else if (*n < 0) {
    info = 6;
  } else if (*lda < max(1, nrowa)) {
    info = 9;
  } else if (*ldb < max(1, *m)) {
    info = 11;
  }
  if (info != 0) {
    xerbla_("dtrsm ", &info, 6L);
    return 0;
  }
/*     Quick return if possible. */

  if (*n == 0) {
    return 0;
  }
/*     And when  alpha.eq.zero. */

  if (*alpha == 0.) {
    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
      i_2 = *m;
      for (i = 1; i <= i_2; ++i) {
	b[i + j * b_dim1] = 0.;
/* L10: */
      }
/* L20: */
    }
    return 0;
  }
/*     Start the operations. */

  if (lside) {
    if (lsame_(transa, "n", 1L, 1L)) {

/*           Form  B := alpha*inv( A )*B. */

      if (upper) {
	i_1 = *n;
	for (j = 1; j <= i_1; ++j) {
	  if (*alpha != 1.) {
	    i_2 = *m;
	    for (i = 1; i <= i_2; ++i) {
	      b[i + j * b_dim1] = *alpha * b[i + j * b_dim1];
/* L30: */
	    }
	  }
	  for (k = *m; k >= 1; --k) {
	    if (b[k + j * b_dim1] != 0.) {
	      if (nounit) {
		b[k + j * b_dim1] /= a[k + k * a_dim1];
	      }
	      i_2 = k - 1;
	      for (i = 1; i <= i_2; ++i) {
		b[i + j * b_dim1] -= b[k + j * b_dim1] * a[i
		    + k * a_dim1];
/* L40: */
	      }
	    }
/* L50: */
	  }
/* L60: */
	}
      } else {
	i_1 = *n;
	for (j = 1; j <= i_1; ++j) {
	  if (*alpha != 1.) {
	    i_2 = *m;
	    for (i = 1; i <= i_2; ++i) {
	      b[i + j * b_dim1] = *alpha * b[i + j * b_dim1];
/* L70: */
	    }
	  }
	  i_2 = *m;
	  for (k = 1; k <= i_2; ++k) {
	    if (b[k + j * b_dim1] != 0.) {
	      if (nounit) {
		b[k + j * b_dim1] /= a[k + k * a_dim1];
	      }
	      i_3 = *m;
	      for (i = k + 1; i <= i_3; ++i) {
		b[i + j * b_dim1] -= b[k + j * b_dim1] * a[i
		    + k * a_dim1];
/* L80: */
	      }
	    }
/* L90: */
	  }
/* L100: */
	}
      }
    } else {

/*           Form  B := alpha*inv( A' )*B. */

      if (upper) {
	i_1 = *n;
	for (j = 1; j <= i_1; ++j) {
	  i_2 = *m;
	  for (i = 1; i <= i_2; ++i) {
	    temp = *alpha * b[i + j * b_dim1];
	    i_3 = i - 1;
	    for (k = 1; k <= i_3; ++k) {
	      temp -= a[k + i * a_dim1] * b[k + j * b_dim1];
/* L110: */
	    }
	    if (nounit) {
	      temp /= a[i + i * a_dim1];
	    }
	    b[i + j * b_dim1] = temp;
/* L120: */
	  }
/* L130: */
	}
      } else {
	i_1 = *n;
	for (j = 1; j <= i_1; ++j) {
	  for (i = *m; i >= 1; --i) {
	    temp = *alpha * b[i + j * b_dim1];
	    i_2 = *m;
	    for (k = i + 1; k <= i_2; ++k) {
	      temp -= a[k + i * a_dim1] * b[k + j * b_dim1];
/* L140: */
	    }
	    if (nounit) {
	      temp /= a[i + i * a_dim1];
	    }
	    b[i + j * b_dim1] = temp;
/* L150: */
	  }
/* L160: */
	}
      }
    }
  } else {
    if (lsame_(transa, "n", 1L, 1L)) {

/*           Form  B := alpha*B*inv( A ). */

      if (upper) {
	i_1 = *n;
	for (j = 1; j <= i_1; ++j) {
	  if (*alpha != 1.) {
	    i_2 = *m;
	    for (i = 1; i <= i_2; ++i) {
	      b[i + j * b_dim1] = *alpha * b[i + j * b_dim1];
/* L170: */
	    }
	  }
	  i_2 = j - 1;
	  for (k = 1; k <= i_2; ++k) {
	    if (a[k + j * a_dim1] != 0.) {
	      i_3 = *m;
	      for (i = 1; i <= i_3; ++i) {
		b[i + j * b_dim1] -= a[k + j * a_dim1] * b[i
		    + k * b_dim1];
/* L180: */
	      }
	    }
/* L190: */
	  }
	  if (nounit) {
	    temp = 1. / a[j + j * a_dim1];
	    i_2 = *m;
	    for (i = 1; i <= i_2; ++i) {
	      b[i + j * b_dim1] = temp * b[i + j * b_dim1];
/* L200: */
	    }
	  }
/* L210: */
	}
      } else {
	for (j = *n; j >= 1; --j) {
	  if (*alpha != 1.) {
	    i_1 = *m;
	    for (i = 1; i <= i_1; ++i) {
	      b[i + j * b_dim1] = *alpha * b[i + j * b_dim1];
/* L220: */
	    }
	  }
	  i_1 = *n;
	  for (k = j + 1; k <= i_1; ++k) {
	    if (a[k + j * a_dim1] != 0.) {
	      i_2 = *m;
	      for (i = 1; i <= i_2; ++i) {
		b[i + j * b_dim1] -= a[k + j * a_dim1] * b[i
		    + k * b_dim1];
/* L230: */
	      }
	    }
/* L240: */
	  }
	  if (nounit) {
	    temp = 1. / a[j + j * a_dim1];
	    i_1 = *m;
	    for (i = 1; i <= i_1; ++i) {
	      b[i + j * b_dim1] = temp * b[i + j * b_dim1];
/* L250: */
	    }
	  }
/* L260: */
	}
      }
    } else {

/*           Form  B := alpha*B*inv( A' ). */

      if (upper) {
	for (k = *n; k >= 1; --k) {
	  if (nounit) {
	    temp = 1. / a[k + k * a_dim1];
	    i_1 = *m;
	    for (i = 1; i <= i_1; ++i) {
	      b[i + k * b_dim1] = temp * b[i + k * b_dim1];
/* L270: */
	    }
	  }
	  i_1 = k - 1;
	  for (j = 1; j <= i_1; ++j) {
	    if (a[j + k * a_dim1] != 0.) {
	      temp = a[j + k * a_dim1];
	      i_2 = *m;
	      for (i = 1; i <= i_2; ++i) {
		b[i + j * b_dim1] -= temp * b[i + k * b_dim1];

/* L280: */
	      }
	    }
/* L290: */
	  }
	  if (*alpha != 1.) {
	    i_1 = *m;
	    for (i = 1; i <= i_1; ++i) {
	      b[i + k * b_dim1] = *alpha * b[i + k * b_dim1];
/* L300: */
	    }
	  }
/* L310: */
	}
      } else {
	i_1 = *n;
	for (k = 1; k <= i_1; ++k) {
	  if (nounit) {
	    temp = 1. / a[k + k * a_dim1];
	    i_2 = *m;
	    for (i = 1; i <= i_2; ++i) {
	      b[i + k * b_dim1] = temp * b[i + k * b_dim1];
/* L320: */
	    }
	  }
	  i_2 = *n;
	  for (j = k + 1; j <= i_2; ++j) {
	    if (a[j + k * a_dim1] != 0.) {
	      temp = a[j + k * a_dim1];
	      i_3 = *m;
	      for (i = 1; i <= i_3; ++i) {
		b[i + j * b_dim1] -= temp * b[i + k * b_dim1];

/* L330: */
	      }
	    }
/* L340: */
	  }
	  if (*alpha != 1.) {
	    i_2 = *m;
	    for (i = 1; i <= i_2; ++i) {
	      b[i + k * b_dim1] = *alpha * b[i + k * b_dim1];
/* L350: */
	    }
	  }
/* L360: */
	}
      }
    }
  }

  return 0;

/*     End of DTRSM . */

}				     /* dtrsm_ */

 /* Subroutine */ int
dlatzm_(side, m, n, v, incv, tau, c1, c2, ldc, work,
    side_len)
  char *side;
  integer *m, *n;
  doublereal *v;
  integer *incv;
  doublereal *tau, *c1, *c2;
  integer *ldc;
  doublereal *work;
  ftnlen side_len;
{
  /* System generated locals */
  integer c1_dim1, c1_offset, c2_dim1, c2_offset, i_1;
  doublereal d_1;

  /* Local variables */
  extern /* Subroutine */ int dger_();
  extern logical lsame_();
  extern /* Subroutine */ int dgemv_(), dcopy_(), daxpy_();

  /* Parameter adjustments */
  --v;
  c1_dim1 = *ldc;
  c1_offset = c1_dim1 + 1;
  c1 -= c1_offset;
  c2_dim1 = *ldc;
  c2_offset = c2_dim1 + 1;
  c2 -= c2_offset;
  --work;

  /* Function Body */

/*  -- LAPACK routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLATZM applies a Householder matrix generated by DTZRQF to a matrix.
*/

/*  Let P = I - tau*u*u',   u = ( 1 ), */
/*                              ( v ) */
/*  where v is an (m-1) vector if SIDE = 'L', or a (n-1) vector if */
/*  SIDE = 'R'. */

/*  If SIDE equals 'L', let */
/*         C = [ C1 ] 1 */
/*             [ C2 ] m-1 */
/*               n */
/*  Then C is overwritten by P*C. */

/*  If SIDE equals 'R', let */
/*         C = [ C1, C2 ] m */
/*                1  n-1 */
/*  Then C is overwritten by C*P. */

/*  Arguments */
/*  ========= */

/*  SIDE    (input) CHARACTER*1 */
/*          = 'L': form P * C */
/*          = 'R': form C * P */

/*  M       (input) INTEGER */
/*          The number of rows of the matrix C. */

/*  N       (input) INTEGER */
/*          The number of columns of the matrix C. */

/*  V       (input) DOUBLE PRECISION array, dimension */
/*                  (1 + (M-1)*abs(INCV)) if SIDE = 'L' */
/*                  (1 + (N-1)*abs(INCV)) if SIDE = 'R' */
/*          The vector v in the representation of P. V is not used */
/*          if TAU = 0. */

/*  INCV    (input) INTEGER */
/*          The increment between elements of v. INCV <> 0 */

/*  TAU     (input) DOUBLE PRECISION */
/*          The value tau in the representation of P. */

/*  C1      (input/output) DOUBLE PRECISION array, dimension */
/*                         (LDC,N) if SIDE = 'L' */
/*                         (M,1)   if SIDE = 'R' */
/*          On entry, the n-vector C1 if SIDE = 'L', or the m-vector C1 */

/*          if SIDE = 'R'. */

/*          On exit, the first row of P*C if SIDE = 'L', or the first */
/*          column of C*P if SIDE = 'R'. */

/*  C2      (input/output) DOUBLE PRECISION array, dimension */
/*                         (LDC, N)   if SIDE = 'L' */
/*                         (LDC, N-1) if SIDE = 'R' */
/*          On entry, the (m - 1) x n matrix C2 if SIDE = 'L', or the */
/*          m x (n - 1) matrix C2 if SIDE = 'R'. */

/*          On exit, rows 2:m of P*C if SIDE = 'L', or columns 2:m of C*P
*/
/*          if SIDE = 'R'. */

/*  LDC     (input) INTEGER */
/*          The leading dimension of the arrays C1 and C2. LDC >= (1,M).
*/

/*  WORK    (workspace) DOUBLE PRECISION array, dimension */
/*                      (N) if SIDE = 'L' */
/*                      (M) if SIDE = 'R' */

/*  =====================================================================
*/

/*     .. Parameters .. */
/*     .. */
/*     .. External Subroutines .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Executable Statements .. */

  if (min(*m, *n) == 0 || *tau == 0.) {
    return 0;
  }
  if (lsame_(side, "l", 1L, 1L)) {

/*        w := C1 + v' * C2 */

    dcopy_(n, &c1[c1_offset], ldc, &work[1], &c__1);
    i_1 = *m - 1;
    dgemv_("transpose", &i_1, n, &c_b36, &c2[c2_offset], ldc, &v[1], incv,
	&c_b36, &work[1], &c__1, 9L);

/*        [ C1 ] := [ C1 ] - tau* [ 1 ] * w' */
/*        [ C2 ]    [ C2 ]        [ v ] */

    d_1 = -(*tau);
    daxpy_(n, &d_1, &work[1], &c__1, &c1[c1_offset], ldc);
    i_1 = *m - 1;
    d_1 = -(*tau);
    dger_(&i_1, n, &d_1, &v[1], incv, &work[1], &c__1, &c2[c2_offset],
	ldc);

  } else if (lsame_(side, "r", 1L, 1L)) {

/*        w := C1 + C2 * v */

    dcopy_(m, &c1[c1_offset], &c__1, &work[1], &c__1);
    i_1 = *n - 1;
    dgemv_("no transpose", m, &i_1, &c_b36, &c2[c2_offset], ldc, &v[1],
	incv, &c_b36, &work[1], &c__1, 12L);

/*        [ C1, C2 ] := [ C1, C2 ] - tau* w * [ 1 , v'] */

    d_1 = -(*tau);
    daxpy_(m, &d_1, &work[1], &c__1, &c1[c1_offset], &c__1);
    i_1 = *n - 1;
    d_1 = -(*tau);
    dger_(m, &i_1, &d_1, &work[1], &c__1, &v[1], incv, &c2[c2_offset],
	ldc);
  }
  return 0;

/*     End of DLATZM */

}				     /* dlatzm_ */

 /* Subroutine */ int
dswap_(n, dx, incx, dy, incy)
  integer *n;
  doublereal *dx;
  integer *incx;
  doublereal *dy;
  integer *incy;
{
  /* System generated locals */
  integer i_1;

  /* Local variables */
  static integer i, m;
  static doublereal dtemp;
  static integer ix, iy, mp1;

  /* Parameter adjustments */
  --dx;
  --dy;

  /* Function Body */

/*     interchanges two vectors. */
/*     uses unrolled loops for increments equal one. */
/*     jack dongarra, linpack, 3/11/78. */


  if (*n <= 0) {
    return 0;
  }
  if (*incx == 1 && *incy == 1) {
    goto L20;
  }
/*       code for unequal increments or equal increments not equal */
/*         to 1 */

  ix = 1;
  iy = 1;
  if (*incx < 0) {
    ix = (-(*n) + 1) * *incx + 1;
  }
  if (*incy < 0) {
    iy = (-(*n) + 1) * *incy + 1;
  }
  i_1 = *n;
  for (i = 1; i <= i_1; ++i) {
    dtemp = dx[ix];
    dx[ix] = dy[iy];
    dy[iy] = dtemp;
    ix += *incx;
    iy += *incy;
/* L10: */
  }
  return 0;

/*       code for both increments equal to 1 */


/*       clean-up loop */

L20:
  m = *n % 3;
  if (m == 0) {
    goto L40;
  }
  i_1 = m;
  for (i = 1; i <= i_1; ++i) {
    dtemp = dx[i];
    dx[i] = dy[i];
    dy[i] = dtemp;
/* L30: */
  }
  if (*n < 3) {
    return 0;
  }
L40:
  mp1 = m + 1;
  i_1 = *n;
  for (i = mp1; i <= i_1; i += 3) {
    dtemp = dx[i];
    dx[i] = dy[i];
    dy[i] = dtemp;
    dtemp = dx[i + 1];
    dx[i + 1] = dy[i + 1];
    dy[i + 1] = dtemp;
    dtemp = dx[i + 2];
    dx[i + 2] = dy[i + 2];
    dy[i + 2] = dtemp;
/* L50: */
  }
  return 0;
}				     /* dswap_ */

 /* Subroutine */ int
dgeqr2_(m, n, a, lda, tau, work, info)
  integer *m, *n;
  doublereal *a;
  integer *lda;
  doublereal *tau, *work;
  integer *info;
{
  /* System generated locals */
  integer a_dim1, a_offset, i_1, i_2, i_3;

  /* Local variables */
  static integer i, k;
  extern /* Subroutine */ int dlarf_(), dlarfg_(), xerbla_();
  static doublereal aii;

  /* Parameter adjustments */
  a_dim1 = *lda;
  a_offset = a_dim1 + 1;
  a -= a_offset;
  --tau;
  --work;

  /* Function Body */

/*  -- LAPACK routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DGEQR2 computes a QR factorization of a real m by n matrix A: */
/*  A = Q * R. */

/*  Arguments */
/*  ========= */

/*  M       (input) INTEGER */
/*          The number of rows of the matrix A.  M >= 0. */

/*  N       (input) INTEGER */
/*          The number of columns of the matrix A.  N >= 0. */

/*  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N) */
/*          On entry, the m by n matrix A. */
/*          On exit, the elements on and above the diagonal of the array
*/
/*          contain the min(m,n) by n upper trapezoidal matrix R (R is */
/*          upper triangular if m >= n); the elements below the diagonal,
*/
/*          with the array TAU, represent the orthogonal matrix Q as a */
/*          product of elementary reflectors (see Further Details). */

/*  LDA     (input) INTEGER */
/*          The leading dimension of the array A.  LDA >= max(1,M). */

/*  TAU     (output) DOUBLE PRECISION array, dimension (min(M,N)) */
/*          The scalar factors of the elementary reflectors (see Further
*/
/*          Details). */

/*  WORK    (workspace) DOUBLE PRECISION array, dimension (N) */

/*  INFO    (output) INTEGER */
/*          = 0: successful exit */
/*          < 0: if INFO = -i, the i-th argument had an illegal value */

/*  Further Details */
/*  =============== */

/*  The matrix Q is represented as a product of elementary reflectors */

/*     Q = H(1) H(2) . . . H(k), where k = min(m,n). */

/*  Each H(i) has the form */

/*     H(i) = I - tau * v * v' */

/*  where tau is a real scalar, and v is a real vector with */
/*  v(1:i-1) = 0 and v(i) = 1; v(i+1:m) is stored on exit in A(i+1:m,i),
*/
/*  and tau in TAU(i). */

/*  =====================================================================
*/

/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. External Subroutines .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Executable Statements .. */

/*     Test the input arguments */

  *info = 0;
  if (*m < 0) {
    *info = -1;
  } else if (*n < 0) {
    *info = -2;
  } else if (*lda < max(1, *m)) {
    *info = -4;
  }
  if (*info != 0) {
    i_1 = -(*info);
    xerbla_("dgeqr2", &i_1, 6L);
    return 0;
  }
  k = min(*m, *n);

  i_1 = k;
  for (i = 1; i <= i_1; ++i) {

/*        Generate elementary reflector H(i) to annihilate A(i+1:m,i)
*/

    i_2 = *m - i + 1;
/* Computing MAX */
    i_3 = i + 1;
    dlarfg_(&i_2, &a[i + i * a_dim1], &a[min(*m, i_3) + i * a_dim1], &c__1,
	&tau[i]);
    if (i < *n) {

/*           Apply H(i) to A(i:m,i+1:n) from the left */

      aii = a[i + i * a_dim1];
      a[i + i * a_dim1] = 1.;
      i_2 = *m - i + 1;
      i_3 = *n - i;
      dlarf_("left", &i_2, &i_3, &a[i + i * a_dim1], &c__1, &tau[i], &a[
	      i + (i + 1) * a_dim1], lda, &work[1], 4L);
      a[i + i * a_dim1] = aii;
    }
/* L10: */
  }
  return 0;

/*     End of DGEQR2 */

}				     /* dgeqr2_ */

 /* Subroutine */ int
dlarfg_(n, alpha, x, incx, tau)
  integer *n;
  doublereal *alpha, *x;
  integer *incx;
  doublereal *tau;
{
  /* System generated locals */
  integer i_1;
  doublereal d_1;

  /* Builtin functions */
  double d_sign();

  /* Local variables */
  static doublereal beta;
  extern doublereal dnrm2_();
  static integer j;
  extern /* Subroutine */ int dscal_();
  static doublereal xnorm;
  extern doublereal dlapy2_(), dlamch_();
  static doublereal safmin, rsafmn;
  static integer knt;

  /* Parameter adjustments */
  --x;

  /* Function Body */

/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLARFG generates a real elementary reflector H of order n, such */
/*  that */

/*        H * ( alpha ) = ( beta ),   H' * H = I. */
/*            (   x   )   (   0  ) */

/*  where alpha and beta are scalars, and x is an (n-1)-element real */
/*  vector. H is represented in the form */

/*        H = I - tau * ( 1 ) * ( 1 v' ) , */
/*                      ( v ) */

/*  where tau is a real scalar and v is a real (n-1)-element */
/*  vector. */

/*  If the elements of x are all zero, then tau = 0 and H is taken to be
*/
/*  the unit matrix. */

/*  Otherwise  1 <= tau <= 2. */

/*  Arguments */
/*  ========= */

/*  N       (input) INTEGER */
/*          The order of the elementary reflector. */

/*  ALPHA   (input/output) DOUBLE PRECISION */
/*          On entry, the value alpha. */
/*          On exit, it is overwritten with the value beta. */

/*  X       (input/output) DOUBLE PRECISION array, dimension */
/*                         (1+(N-2)*abs(INCX)) */
/*          On entry, the vector x. */
/*          On exit, it is overwritten with the vector v. */

/*  INCX    (input) INTEGER */
/*          The increment between elements of X. INCX <> 0. */

/*  TAU     (output) DOUBLE PRECISION */
/*          The value tau. */

/*  =====================================================================
*/

/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. External Subroutines .. */
/*     .. */
/*     .. Executable Statements .. */

  if (*n <= 1) {
    *tau = 0.;
    return 0;
  }
  i_1 = *n - 1;
  xnorm = dnrm2_(&i_1, &x[1], incx);

  if (xnorm == 0.) {

/*        H  =  I */

    *tau = 0.;
  } else {

/*        general case */

    d_1 = dlapy2_(alpha, &xnorm);
    beta = -d_sign(&d_1, alpha);
    safmin = dlamch_("s", 1L);
    if (abs(beta) < safmin) {

/*           XNORM, BETA may be inaccurate; scale X and recompute
them */

      rsafmn = 1. / safmin;
      knt = 0;
  L10:
      ++knt;
      i_1 = *n - 1;
      dscal_(&i_1, &rsafmn, &x[1], incx);
      beta *= rsafmn;
      *alpha *= rsafmn;
      if (abs(beta) < safmin) {
	goto L10;
      }
/*           New BETA is at most 1, at least SAFMIN */

      i_1 = *n - 1;
      xnorm = dnrm2_(&i_1, &x[1], incx);
      d_1 = dlapy2_(alpha, &xnorm);
      beta = -d_sign(&d_1, alpha);
      *tau = (beta - *alpha) / beta;
      i_1 = *n - 1;
      d_1 = 1. / (*alpha - beta);
      dscal_(&i_1, &d_1, &x[1], incx);

/*           If ALPHA is subnormal, it may lose relative accuracy
*/

      *alpha = beta;
      i_1 = knt;
      for (j = 1; j <= i_1; ++j) {
	*alpha *= safmin;
/* L20: */
      }
    } else {
      *tau = (beta - *alpha) / beta;
      i_1 = *n - 1;
      d_1 = 1. / (*alpha - beta);
      dscal_(&i_1, &d_1, &x[1], incx);
      *alpha = beta;
    }
  }

  return 0;

/*     End of DLARFG */

}				     /* dlarfg_ */

 /* Subroutine */ int
dlarf_(side, m, n, v, incv, tau, c, ldc, work, side_len)
  char *side;
  integer *m, *n;
  doublereal *v;
  integer *incv;
  doublereal *tau, *c;
  integer *ldc;
  doublereal *work;
  ftnlen side_len;
{
  /* System generated locals */
  integer c_dim1, c_offset;
  doublereal d_1;

  /* Local variables */
  extern /* Subroutine */ int dger_();
  extern logical lsame_();
  extern /* Subroutine */ int dgemv_();

  /* Parameter adjustments */
  --v;
  c_dim1 = *ldc;
  c_offset = c_dim1 + 1;
  c -= c_offset;
  --work;

  /* Function Body */

/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLARF applies a real elementary reflector H to a real m by n matrix */

/*  C, from either the left or the right. H is represented in the form */

/*        H = I - tau * v * v' */

/*  where tau is a real scalar and v is a real vector. */

/*  If tau = 0, then H is taken to be the unit matrix. */

/*  Arguments */
/*  ========= */

/*  SIDE    (input) CHARACTER*1 */
/*          = 'L': form  H * C */
/*          = 'R': form  C * H */

/*  M       (input) INTEGER */
/*          The number of rows of the matrix C. */

/*  N       (input) INTEGER */
/*          The number of columns of the matrix C. */

/*  V       (input) DOUBLE PRECISION array, dimension */
/*                     (1 + (M-1)*abs(INCV)) if SIDE = 'L' */
/*                  or (1 + (N-1)*abs(INCV)) if SIDE = 'R' */
/*          The vector v in the representation of H. V is not used if */
/*          TAU = 0. */

/*  INCV    (input) INTEGER */
/*          The increment between elements of v. INCV <> 0. */

/*  TAU     (input) DOUBLE PRECISION */
/*          The value tau in the representation of H. */

/*  C       (input/output) DOUBLE PRECISION array, dimension (LDC,N) */
/*          On entry, the m by n matrix C. */
/*          On exit, C is overwritten by the matrix H * C if SIDE = 'L',
*/
/*          or C * H if SIDE = 'R'. */

/*  LDC     (input) INTEGER */
/*          The leading dimension of the array C. LDC >= max(1,M). */

/*  WORK    (workspace) DOUBLE PRECISION array, dimension */
/*                         (N) if SIDE = 'L' */
/*                      or (M) if SIDE = 'R' */

/*  =====================================================================
*/

/*     .. Parameters .. */
/*     .. */
/*     .. External Subroutines .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. Executable Statements .. */

  if (lsame_(side, "l", 1L, 1L)) {

/*        Form  H * C */

    if (*tau != 0.) {

/*           w := C' * v */

      dgemv_("transpose", m, n, &c_b36, &c[c_offset], ldc, &v[1], incv,
	  &c_b13, &work[1], &c__1, 9L);

/*           C := C - v * w' */

      d_1 = -(*tau);
      dger_(m, n, &d_1, &v[1], incv, &work[1], &c__1, &c[c_offset], ldc);
    }
  } else {

/*        Form  C * H */

    if (*tau != 0.) {

/*           w := C * v */

      dgemv_("no transpose", m, n, &c_b36, &c[c_offset], ldc, &v[1],
	  incv, &c_b13, &work[1], &c__1, 12L);

/*           C := C - w * v' */

      d_1 = -(*tau);
      dger_(m, n, &d_1, &work[1], &c__1, &v[1], incv, &c[c_offset], ldc);
    }
  }
  return 0;

/*     End of DLARF */

}				     /* dlarf_ */

 /* Subroutine */ int
dcopy_(n, dx, incx, dy, incy)
  integer *n;
  doublereal *dx;
  integer *incx;
  doublereal *dy;
  integer *incy;
{
  /* System generated locals */
  integer i_1;

  /* Local variables */
  static integer i, m, ix, iy, mp1;

  /* Parameter adjustments */
  --dx;
  --dy;

  /* Function Body */

/*     copies a vector, x, to a vector, y. */
/*     uses unrolled loops for increments equal to one. */
/*     jack dongarra, linpack, 3/11/78. */


  if (*n <= 0) {
    return 0;
  }
  if (*incx == 1 && *incy == 1) {
    goto L20;
  }
/*        code for unequal increments or equal increments */
/*          not equal to 1 */

  ix = 1;
  iy = 1;
  if (*incx < 0) {
    ix = (-(*n) + 1) * *incx + 1;
  }
  if (*incy < 0) {
    iy = (-(*n) + 1) * *incy + 1;
  }
  i_1 = *n;
  for (i = 1; i <= i_1; ++i) {
    dy[iy] = dx[ix];
    ix += *incx;
    iy += *incy;
/* L10: */
  }
  return 0;

/*        code for both increments equal to 1 */


/*        clean-up loop */

L20:
  m = *n % 7;
  if (m == 0) {
    goto L40;
  }
  i_1 = m;
  for (i = 1; i <= i_1; ++i) {
    dy[i] = dx[i];
/* L30: */
  }
  if (*n < 7) {
    return 0;
  }
L40:
  mp1 = m + 1;
  i_1 = *n;
  for (i = mp1; i <= i_1; i += 7) {
    dy[i] = dx[i];
    dy[i + 1] = dx[i + 1];
    dy[i + 2] = dx[i + 2];
    dy[i + 3] = dx[i + 3];
    dy[i + 4] = dx[i + 4];
    dy[i + 5] = dx[i + 5];
    dy[i + 6] = dx[i + 6];
/* L50: */
  }
  return 0;
}				     /* dcopy_ */

 /* Subroutine */ int
dgemv_(trans, m, n, alpha, a, lda, x, incx, beta, y,
    incy, trans_len)
  char *trans;
  integer *m, *n;
  doublereal *alpha, *a;
  integer *lda;
  doublereal *x;
  integer *incx;
  doublereal *beta, *y;
  integer *incy;
  ftnlen trans_len;
{
  /* System generated locals */
  integer a_dim1, a_offset, i_1, i_2;

  /* Local variables */
  static integer info;
  static doublereal temp;
  static integer lenx, leny, i, j;
  extern logical lsame_();
  static integer ix, iy, jx, jy, kx, ky;
  extern /* Subroutine */ int xerbla_();

  /* Parameter adjustments */
  a_dim1 = *lda;
  a_offset = a_dim1 + 1;
  a -= a_offset;
  --x;
  --y;

  /* Function Body */
/*     .. Scalar Arguments .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DGEMV  performs one of the matrix-vector operations */

/*     y := alpha*A*x + beta*y,   or   y := alpha*A'*x + beta*y, */

/*  where alpha and beta are scalars, x and y are vectors and A is an */
/*  m by n matrix. */

/*  Parameters */
/*  ========== */

/*  TRANS  - CHARACTER*1. */
/*           On entry, TRANS specifies the operation to be performed as */

/*           follows: */

/*              TRANS = 'N' or 'n'   y := alpha*A*x + beta*y. */

/*              TRANS = 'T' or 't'   y := alpha*A'*x + beta*y. */

/*              TRANS = 'C' or 'c'   y := alpha*A'*x + beta*y. */

/*           Unchanged on exit. */

/*  M      - INTEGER. */
/*           On entry, M specifies the number of rows of the matrix A. */
/*           M must be at least zero. */
/*           Unchanged on exit. */

/*  N      - INTEGER. */
/*           On entry, N specifies the number of columns of the matrix A.
*/
/*           N must be at least zero. */
/*           Unchanged on exit. */

/*  ALPHA  - DOUBLE PRECISION. */
/*           On entry, ALPHA specifies the scalar alpha. */
/*           Unchanged on exit. */

/*  A      - DOUBLE PRECISION array of DIMENSION ( LDA, n ). */
/*           Before entry, the leading m by n part of the array A must */
/*           contain the matrix of coefficients. */
/*           Unchanged on exit. */

/*  LDA    - INTEGER. */
/*           On entry, LDA specifies the first dimension of A as declared
*/
/*           in the calling (sub) program. LDA must be at least */
/*           max( 1, m ). */
/*           Unchanged on exit. */

/*  X      - DOUBLE PRECISION array of DIMENSION at least */
/*           ( 1 + ( n - 1 )*abs( INCX ) ) when TRANS = 'N' or 'n' */
/*           and at least */
/*           ( 1 + ( m - 1 )*abs( INCX ) ) otherwise. */
/*           Before entry, the incremented array X must contain the */
/*           vector x. */
/*           Unchanged on exit. */

/*  INCX   - INTEGER. */
/*           On entry, INCX specifies the increment for the elements of */

/*           X. INCX must not be zero. */
/*           Unchanged on exit. */

/*  BETA   - DOUBLE PRECISION. */
/*           On entry, BETA specifies the scalar beta. When BETA is */
/*           supplied as zero then Y need not be set on input. */
/*           Unchanged on exit. */

/*  Y      - DOUBLE PRECISION array of DIMENSION at least */
/*           ( 1 + ( m - 1 )*abs( INCY ) ) when TRANS = 'N' or 'n' */
/*           and at least */
/*           ( 1 + ( n - 1 )*abs( INCY ) ) otherwise. */
/*           Before entry with BETA non-zero, the incremented array Y */
/*           must contain the vector y. On exit, Y is overwritten by the
*/
/*           updated vector y. */

/*  INCY   - INTEGER. */
/*           On entry, INCY specifies the increment for the elements of */

/*           Y. INCY must not be zero. */
/*           Unchanged on exit. */


/*  Level 2 Blas routine. */

/*  -- Written on 22-October-1986. */
/*     Jack Dongarra, Argonne National Lab. */
/*     Jeremy Du Croz, Nag Central Office. */
/*     Sven Hammarling, Nag Central Office. */
/*     Richard Hanson, Sandia National Labs. */


/*     .. Parameters .. */
/*     .. Local Scalars .. */
/*     .. External Functions .. */
/*     .. External Subroutines .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Executable Statements .. */

/*     Test the input parameters. */

  info = 0;
  if (!lsame_(trans, "n", 1L, 1L) && !lsame_(trans, "t", 1L, 1L) && !
      lsame_(trans, "c", 1L, 1L)) {
    info = 1;
  } else if (*m < 0) {
    info = 2;
  } else if (*n < 0) {
    info = 3;
  } else if (*lda < max(1, *m)) {
    info = 6;
  } else if (*incx == 0) {
    info = 8;
  } else if (*incy == 0) {
    info = 11;
  }
  if (info != 0) {
    xerbla_("dgemv ", &info, 6L);
    return 0;
  }
/*     Quick return if possible. */

  if (*m == 0 || *n == 0 || *alpha == 0. && *beta == 1.) {
    return 0;
  }
/*     Set  LENX  and  LENY, the lengths of the vectors x and y, and set
*/
/*     up the start points in  X  and  Y. */

  if (lsame_(trans, "n", 1L, 1L)) {
    lenx = *n;
    leny = *m;
  } else {
    lenx = *m;
    leny = *n;
  }
  if (*incx > 0) {
    kx = 1;
  } else {
    kx = 1 - (lenx - 1) * *incx;
  }
  if (*incy > 0) {
    ky = 1;
  } else {
    ky = 1 - (leny - 1) * *incy;
  }

/*     Start the operations. In this version the elements of A are */
/*     accessed sequentially with one pass through A. */

/*     First form  y := beta*y. */

  if (*beta != 1.) {
    if (*incy == 1) {
      if (*beta == 0.) {
	i_1 = leny;
	for (i = 1; i <= i_1; ++i) {
	  y[i] = 0.;
/* L10: */
	}
      } else {
	i_1 = leny;
	for (i = 1; i <= i_1; ++i) {
	  y[i] = *beta * y[i];
/* L20: */
	}
      }
    } else {
      iy = ky;
      if (*beta == 0.) {
	i_1 = leny;
	for (i = 1; i <= i_1; ++i) {
	  y[iy] = 0.;
	  iy += *incy;
/* L30: */
	}
      } else {
	i_1 = leny;
	for (i = 1; i <= i_1; ++i) {
	  y[iy] = *beta * y[iy];
	  iy += *incy;
/* L40: */
	}
      }
    }
  }
  if (*alpha == 0.) {
    return 0;
  }
  if (lsame_(trans, "n", 1L, 1L)) {

/*        Form  y := alpha*A*x + y. */

    jx = kx;
    if (*incy == 1) {
      i_1 = *n;
      for (j = 1; j <= i_1; ++j) {
	if (x[jx] != 0.) {
	  temp = *alpha * x[jx];
	  i_2 = *m;
	  for (i = 1; i <= i_2; ++i) {
	    y[i] += temp * a[i + j * a_dim1];
/* L50: */
	  }
	}
	jx += *incx;
/* L60: */
      }
    } else {
      i_1 = *n;
      for (j = 1; j <= i_1; ++j) {
	if (x[jx] != 0.) {
	  temp = *alpha * x[jx];
	  iy = ky;
	  i_2 = *m;
	  for (i = 1; i <= i_2; ++i) {
	    y[iy] += temp * a[i + j * a_dim1];
	    iy += *incy;
/* L70: */
	  }
	}
	jx += *incx;
/* L80: */
      }
    }
  } else {

/*        Form  y := alpha*A'*x + y. */

    jy = ky;
    if (*incx == 1) {
      i_1 = *n;
      for (j = 1; j <= i_1; ++j) {
	temp = 0.;
	i_2 = *m;
	for (i = 1; i <= i_2; ++i) {
	  temp += a[i + j * a_dim1] * x[i];
/* L90: */
	}
	y[jy] += *alpha * temp;
	jy += *incy;
/* L100: */
      }
    } else {
      i_1 = *n;
      for (j = 1; j <= i_1; ++j) {
	temp = 0.;
	ix = kx;
	i_2 = *m;
	for (i = 1; i <= i_2; ++i) {
	  temp += a[i + j * a_dim1] * x[ix];
	  ix += *incx;
/* L110: */
	}
	y[jy] += *alpha * temp;
	jy += *incy;
/* L120: */
      }
    }
  }

  return 0;

/*     End of DGEMV . */

}				     /* dgemv_ */

 /* Subroutine */ int
daxpy_(n, da, dx, incx, dy, incy)
  integer *n;
  doublereal *da, *dx;
  integer *incx;
  doublereal *dy;
  integer *incy;
{
  /* System generated locals */
  integer i_1;

  /* Local variables */
  static integer i, m, ix, iy, mp1;

  /* Parameter adjustments */
  --dx;
  --dy;

  /* Function Body */

/*     constant times a vector plus a vector. */
/*     uses unrolled loops for increments equal to one. */
/*     jack dongarra, linpack, 3/11/78. */


  if (*n <= 0) {
    return 0;
  }
  if (*da == 0.) {
    return 0;
  }
  if (*incx == 1 && *incy == 1) {
    goto L20;
  }
/*        code for unequal increments or equal increments */
/*          not equal to 1 */

  ix = 1;
  iy = 1;
  if (*incx < 0) {
    ix = (-(*n) + 1) * *incx + 1;
  }
  if (*incy < 0) {
    iy = (-(*n) + 1) * *incy + 1;
  }
  i_1 = *n;
  for (i = 1; i <= i_1; ++i) {
    dy[iy] += *da * dx[ix];
    ix += *incx;
    iy += *incy;
/* L10: */
  }
  return 0;

/*        code for both increments equal to 1 */


/*        clean-up loop */

L20:
  m = *n % 4;
  if (m == 0) {
    goto L40;
  }
  i_1 = m;
  for (i = 1; i <= i_1; ++i) {
    dy[i] += *da * dx[i];
/* L30: */
  }
  if (*n < 4) {
    return 0;
  }
L40:
  mp1 = m + 1;
  i_1 = *n;
  for (i = mp1; i <= i_1; i += 4) {
    dy[i] += *da * dx[i];
    dy[i + 1] += *da * dx[i + 1];
    dy[i + 2] += *da * dx[i + 2];
    dy[i + 3] += *da * dx[i + 3];
/* L50: */
  }
  return 0;
}				     /* daxpy_ */

 /* Subroutine */ int
dger_(m, n, alpha, x, incx, y, incy, a, lda)
  integer *m, *n;
  doublereal *alpha, *x;
  integer *incx;
  doublereal *y;
  integer *incy;
  doublereal *a;
  integer *lda;
{
  /* System generated locals */
  integer a_dim1, a_offset, i_1, i_2;

  /* Local variables */
  static integer info;
  static doublereal temp;
  static integer i, j, ix, jy, kx;
  extern /* Subroutine */ int xerbla_();

  /* Parameter adjustments */
  --x;
  --y;
  a_dim1 = *lda;
  a_offset = a_dim1 + 1;
  a -= a_offset;

  /* Function Body */
/*     .. Scalar Arguments .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DGER   performs the rank 1 operation */

/*     A := alpha*x*y' + A, */

/*  where alpha is a scalar, x is an m element vector, y is an n element
*/
/*  vector and A is an m by n matrix. */

/*  Parameters */
/*  ========== */

/*  M      - INTEGER. */
/*           On entry, M specifies the number of rows of the matrix A. */
/*           M must be at least zero. */
/*           Unchanged on exit. */

/*  N      - INTEGER. */
/*           On entry, N specifies the number of columns of the matrix A.
*/
/*           N must be at least zero. */
/*           Unchanged on exit. */

/*  ALPHA  - DOUBLE PRECISION. */
/*           On entry, ALPHA specifies the scalar alpha. */
/*           Unchanged on exit. */

/*  X      - DOUBLE PRECISION array of dimension at least */
/*           ( 1 + ( m - 1 )*abs( INCX ) ). */
/*           Before entry, the incremented array X must contain the m */
/*           element vector x. */
/*           Unchanged on exit. */

/*  INCX   - INTEGER. */
/*           On entry, INCX specifies the increment for the elements of */

/*           X. INCX must not be zero. */
/*           Unchanged on exit. */

/*  Y      - DOUBLE PRECISION array of dimension at least */
/*           ( 1 + ( n - 1 )*abs( INCY ) ). */
/*           Before entry, the incremented array Y must contain the n */
/*           element vector y. */
/*           Unchanged on exit. */

/*  INCY   - INTEGER. */
/*           On entry, INCY specifies the increment for the elements of */

/*           Y. INCY must not be zero. */
/*           Unchanged on exit. */

/*  A      - DOUBLE PRECISION array of DIMENSION ( LDA, n ). */
/*           Before entry, the leading m by n part of the array A must */
/*           contain the matrix of coefficients. On exit, A is */
/*           overwritten by the updated matrix. */

/*  LDA    - INTEGER. */
/*           On entry, LDA specifies the first dimension of A as declared
*/
/*           in the calling (sub) program. LDA must be at least */
/*           max( 1, m ). */
/*           Unchanged on exit. */


/*  Level 2 Blas routine. */

/*  -- Written on 22-October-1986. */
/*     Jack Dongarra, Argonne National Lab. */
/*     Jeremy Du Croz, Nag Central Office. */
/*     Sven Hammarling, Nag Central Office. */
/*     Richard Hanson, Sandia National Labs. */


/*     .. Parameters .. */
/*     .. Local Scalars .. */
/*     .. External Subroutines .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Executable Statements .. */

/*     Test the input parameters. */

  info = 0;
  if (*m < 0) {
    info = 1;
  } else if (*n < 0) {
    info = 2;
  } else if (*incx == 0) {
    info = 5;
  } else if (*incy == 0) {
    info = 7;
  } else if (*lda < max(1, *m)) {
    info = 9;
  }
  if (info != 0) {
    xerbla_("dger  ", &info, 6L);
    return 0;
  }
/*     Quick return if possible. */

  if (*m == 0 || *n == 0 || *alpha == 0.) {
    return 0;
  }
/*     Start the operations. In this version the elements of A are */
/*     accessed sequentially with one pass through A. */

  if (*incy > 0) {
    jy = 1;
  } else {
    jy = 1 - (*n - 1) * *incy;
  }
  if (*incx == 1) {
    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
      if (y[jy] != 0.) {
	temp = *alpha * y[jy];
	i_2 = *m;
	for (i = 1; i <= i_2; ++i) {
	  a[i + j * a_dim1] += x[i] * temp;
/* L10: */
	}
      }
      jy += *incy;
/* L20: */
    }
  } else {
    if (*incx > 0) {
      kx = 1;
    } else {
      kx = 1 - (*m - 1) * *incx;
    }
    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
      if (y[jy] != 0.) {
	temp = *alpha * y[jy];
	ix = kx;
	i_2 = *m;
	for (i = 1; i <= i_2; ++i) {
	  a[i + j * a_dim1] += x[ix] * temp;
	  ix += *incx;
/* L30: */
	}
      }
      jy += *incy;
/* L40: */
    }
  }

  return 0;

/*     End of DGER  . */

}				     /* dger_ */

 /* Subroutine */ int
dscal_(n, da, dx, incx)
  integer *n;
  doublereal *da, *dx;
  integer *incx;
{
  /* System generated locals */
  integer i_1;

  /* Local variables */
  static integer i, m, ix, mp1;

  /* Parameter adjustments */
  --dx;

  /* Function Body */

/*     scales a vector by a constant. */
/*     uses unrolled loops for increment equal to one. */
/*     jack dongarra, linpack, 3/11/78. */
/*     modified to correct problem with negative increment, 8/21/90. */


  if (*n <= 0) {
    return 0;
  }
  if (*incx == 1) {
    goto L20;
  }
/*        code for increment not equal to 1 */

  ix = 1;
  if (*incx < 0) {
    ix = (-(*n) + 1) * *incx + 1;
  }
  i_1 = *n;
  for (i = 1; i <= i_1; ++i) {
    dx[ix] = *da * dx[ix];
    ix += *incx;
/* L10: */
  }
  return 0;

/*        code for increment equal to 1 */


/*        clean-up loop */

L20:
  m = *n % 5;
  if (m == 0) {
    goto L40;
  }
  i_1 = m;
  for (i = 1; i <= i_1; ++i) {
    dx[i] = *da * dx[i];
/* L30: */
  }
  if (*n < 5) {
    return 0;
  }
L40:
  mp1 = m + 1;
  i_1 = *n;
  for (i = mp1; i <= i_1; i += 5) {
    dx[i] = *da * dx[i];
    dx[i + 1] = *da * dx[i + 1];
    dx[i + 2] = *da * dx[i + 2];
    dx[i + 3] = *da * dx[i + 3];
    dx[i + 4] = *da * dx[i + 4];
/* L50: */
  }
  return 0;
}				     /* dscal_ */

doublereal
ddot_(n, dx, incx, dy, incy)
  integer *n;
  doublereal *dx;
  integer *incx;
  doublereal *dy;
  integer *incy;
{
  /* System generated locals */
  integer i_1;
  doublereal ret_val;

  /* Local variables */
  static integer i, m;
  static doublereal dtemp;
  static integer ix, iy, mp1;

  /* Parameter adjustments */
  --dx;
  --dy;

  /* Function Body */

/*     forms the dot product of two vectors. */
/*     uses unrolled loops for increments equal to one. */
/*     jack dongarra, linpack, 3/11/78. */


  ret_val = 0.;
  dtemp = 0.;
  if (*n <= 0) {
    return ret_val;
  }
  if (*incx == 1 && *incy == 1) {
    goto L20;
  }
/*        code for unequal increments or equal increments */
/*          not equal to 1 */

  ix = 1;
  iy = 1;
  if (*incx < 0) {
    ix = (-(*n) + 1) * *incx + 1;
  }
  if (*incy < 0) {
    iy = (-(*n) + 1) * *incy + 1;
  }
  i_1 = *n;
  for (i = 1; i <= i_1; ++i) {
    dtemp += dx[ix] * dy[iy];
    ix += *incx;
    iy += *incy;
/* L10: */
  }
  ret_val = dtemp;
  return ret_val;

/*        code for both increments equal to 1 */


/*        clean-up loop */

L20:
  m = *n % 5;
  if (m == 0) {
    goto L40;
  }
  i_1 = m;
  for (i = 1; i <= i_1; ++i) {
    dtemp += dx[i] * dy[i];
/* L30: */
  }
  if (*n < 5) {
    goto L60;
  }
L40:
  mp1 = m + 1;
  i_1 = *n;
  for (i = mp1; i <= i_1; i += 5) {
    dtemp = dtemp + dx[i] * dy[i] + dx[i + 1] * dy[i + 1] + dx[i + 2] *
	dy[i + 2] + dx[i + 3] * dy[i + 3] + dx[i + 4] * dy[i + 4];
/* L50: */
  }
L60:
  ret_val = dtemp;
  return ret_val;
}				     /* ddot_ */

doublereal
dlange_(norm, m, n, a, lda, work, norm_len)
  char *norm;
  integer *m, *n;
  doublereal *a;
  integer *lda;
  doublereal *work;
  ftnlen norm_len;
{
  /* System generated locals */
  integer a_dim1, a_offset, i_1, i_2;
  doublereal ret_val, d_1, d_2, d_3;

  /* Builtin functions */
  double sqrt();

  /* Local variables */
  static integer i, j;
  static doublereal scale;
  extern logical lsame_();
  static doublereal value;
  extern /* Subroutine */ int dlassq_();
  static doublereal sum;

  /* Parameter adjustments */
  a_dim1 = *lda;
  a_offset = a_dim1 + 1;
  a -= a_offset;
  --work;

  /* Function Body */

/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLANGE  returns the value of the one norm,  or the Frobenius norm, or
*/
/*  the  infinity norm,  or the  element of  largest absolute value  of a
*/
/*  real matrix A. */

/*  Description */
/*  =========== */

/*  DLANGE returns the value */

/*     DLANGE = ( max(abs(A(i,j))), NORM = 'M' or 'm' */
/*              ( */
/*              ( norm1(A),         NORM = '1', 'O' or 'o' */
/*              ( */
/*              ( normI(A),         NORM = 'I' or 'i' */
/*              ( */
/*              ( normF(A),         NORM = 'F', 'f', 'E' or 'e' */

/*  where  norm1  denotes the  one norm of a matrix (maximum column sum),
*/
/*  normI  denotes the  infinity norm  of a matrix  (maximum row sum) and
*/
/*  normF  denotes the  Frobenius norm of a matrix (square root of sum of
*/
/*  squares).  Note that  max(abs(A(i,j)))  is not a  matrix norm. */

/*  Arguments */
/*  ========= */

/*  NORM    (input) CHARACTER*1 */
/*          Specifies the value to be returned in DLANGE as described */
/*          above. */

/*  M       (input) INTEGER */
/*          The number of rows of the matrix A.  M >= 0.  When M = 0, */
/*          DLANGE is set to zero. */

/*  N       (input) INTEGER */
/*          The number of columns of the matrix A.  N >= 0.  When N = 0,
*/
/*          DLANGE is set to zero. */

/*  A       (input) DOUBLE PRECISION array, dimension (LDA,N) */
/*          The m by n matrix A. */

/*  LDA     (input) INTEGER */
/*          The leading dimension of the array A.  LDA >= max(M,1). */

/*  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK), */
/*          where LWORK >= M when NORM = 'I'; otherwise, WORK is not */
/*          referenced. */


/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. External Subroutines .. */
/*     .. */
/*     .. External Functions .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Executable Statements .. */

  if (min(*m, *n) == 0) {
    value = 0.;
  } else if (lsame_(norm, "m", 1L, 1L)) {

/*        Find max(abs(A(i,j))). */

    value = 0.;
    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
      i_2 = *m;
      for (i = 1; i <= i_2; ++i) {
/* Computing MAX */
	d_2 = value, d_3 = (d_1 = a[i + j * a_dim1], abs(d_1));
	value = max(d_3, d_2);
/* L10: */
      }
/* L20: */
    }
  } else if (lsame_(norm, "o", 1L, 1L) || *norm == '1') {

/*        Find norm1(A). */

    value = 0.;
    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
      sum = 0.;
      i_2 = *m;
      for (i = 1; i <= i_2; ++i) {
	sum += (d_1 = a[i + j * a_dim1], abs(d_1));
/* L30: */
      }
      value = max(value, sum);
/* L40: */
    }
  } else if (lsame_(norm, "i", 1L, 1L)) {

/*        Find normI(A). */

    i_1 = *m;
    for (i = 1; i <= i_1; ++i) {
      work[i] = 0.;
/* L50: */
    }
    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
      i_2 = *m;
      for (i = 1; i <= i_2; ++i) {
	work[i] += (d_1 = a[i + j * a_dim1], abs(d_1));
/* L60: */
      }
/* L70: */
    }
    value = 0.;
    i_1 = *m;
    for (i = 1; i <= i_1; ++i) {
/* Computing MAX */
      d_1 = value, d_2 = work[i];
      value = max(d_2, d_1);
/* L80: */
    }
  } else if (lsame_(norm, "f", 1L, 1L) || lsame_(norm, "e", 1L, 1L)) {

/*        Find normF(A). */

    scale = 0.;
    sum = 1.;
    i_1 = *n;
    for (j = 1; j <= i_1; ++j) {
      dlassq_(m, &a[j * a_dim1 + 1], &c__1, &scale, &sum);
/* L90: */
    }
    value = scale * sqrt(sum);
  }
  ret_val = value;
  return ret_val;

/*     End of DLANGE */

}				     /* dlange_ */

logical
lsame_(ca, cb, ca_len, cb_len)
  char *ca, *cb;
  ftnlen ca_len;
  ftnlen cb_len;
{
  /* System generated locals */
  logical ret_val;

  /* Local variables */
  static integer inta, intb, zcode;


/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  LSAME returns .TRUE. if CA is the same letter as CB regardless of */
/*  case. */

/*  Arguments */
/*  ========= */

/*  CA      (input) CHARACTER*1 */
/*  CB      (input) CHARACTER*1 */
/*          CA and CB specify the single characters to be compared. */

/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. Executable Statements .. */

/*     Test if the characters are equal */

  ret_val = *ca == *cb;
  if (ret_val) {
    return ret_val;
  }
/*     Now test for equivalence if both characters are alphabetic. */

  zcode = 122;

/*     Use 'Z' rather than 'A' so that ASCII can be detected on Prime */
/*     machines, on which ICHAR returns a value with bit 8 set. */
/*     ICHAR('A') on Prime machines returns 193 which is the same as */
/*     ICHAR('A') on an EBCDIC machine. */

  inta = *ca;
  intb = *cb;

  if (zcode == 90 || zcode == 122) {

/*        ASCII is assumed - ZCODE is the ASCII code of either lower
or */
/*        upper case 'Z'. */

    if (inta >= 97 && inta <= 122) {
      inta += -32;
    }
    if (intb >= 97 && intb <= 122) {
      intb += -32;
    }
  } else if (zcode == 233 || zcode == 169) {

/*        EBCDIC is assumed - ZCODE is the EBCDIC code of either
lower or */
/*        upper case 'Z'. */

    if (inta >= 129 && inta <= 137 || inta >= 145 && inta <= 153 || inta
	>= 162 && inta <= 169) {
      inta += 64;
    }
    if (intb >= 129 && intb <= 137 || intb >= 145 && intb <= 153 || intb
	>= 162 && intb <= 169) {
      intb += 64;
    }
  } else if (zcode == 218 || zcode == 250) {

/*        ASCII is assumed, on Prime machines - ZCODE is the ASCII
code */
/*        plus 128 of either lower or upper case 'Z'. */

    if (inta >= 225 && inta <= 250) {
      inta += -32;
    }
    if (intb >= 225 && intb <= 250) {
      intb += -32;
    }
  }
  ret_val = inta == intb;

/*     RETURN */

/*     End of LSAME */

  return ret_val;
}				     /* lsame_ */

integer
idamax_(n, dx, incx)
  integer *n;
  doublereal *dx;
  integer *incx;
{
  /* System generated locals */
  integer ret_val, i_1;
  doublereal d_1;

  /* Local variables */
  static doublereal dmax_;
  static integer i, ix;

  /* Parameter adjustments */
  --dx;

  /* Function Body */

/*     finds the index of element having max. absolute value. */
/*     jack dongarra, linpack, 3/11/78. */
/*     modified to correct problem with negative increment, 8/21/90. */


  ret_val = 0;
  if (*n < 1) {
    return ret_val;
  }
  ret_val = 1;
  if (*n == 1) {
    return ret_val;
  }
  if (*incx == 1) {
    goto L20;
  }
/*        code for increment not equal to 1 */

  ix = 1;
  if (*incx < 0) {
    ix = (-(*n) + 1) * *incx + 1;
  }
  dmax_ = (d_1 = dx[ix], abs(d_1));
  ix += *incx;
  i_1 = *n;
  for (i = 2; i <= i_1; ++i) {
    if ((d_1 = dx[ix], abs(d_1)) <= dmax_) {
      goto L5;
    }
    ret_val = i;
    dmax_ = (d_1 = dx[ix], abs(d_1));
L5:
    ix += *incx;
/* L10: */
  }
  return ret_val;

/*        code for increment equal to 1 */

L20:
  dmax_ = abs(dx[1]);
  i_1 = *n;
  for (i = 2; i <= i_1; ++i) {
    if ((d_1 = dx[i], abs(d_1)) <= dmax_) {
      goto L30;
    }
    ret_val = i;
    dmax_ = (d_1 = dx[i], abs(d_1));
L30:
    ;
  }
  return ret_val;
}				     /* idamax_ */

doublereal
dnrm2_(n, dx, incx)
  integer *n;
  doublereal *dx;
  integer *incx;
{
  /* Initialized data */

  static doublereal zero = 0.;
  static doublereal one = 1.;
  static doublereal cutlo = 8.232e-11;
  static doublereal cuthi = 1.304e19;

  /* Format strings */
  static char fmt_30[] = "";
  static char fmt_50[] = "";
  static char fmt_70[] = "";
  static char fmt_110[] = "";

  /* System generated locals */
  integer i_1;
  doublereal ret_val, d_1;

  /* Builtin functions */
  double sqrt();

  /* Local variables */
  static doublereal xmax;
  static integer next, i, j, ix;
  static doublereal hitest, sum;

  /* Assigned format variables */
  char *next_fmt;

  /* Parameter adjustments */
  --dx;

  /* Function Body */

/*     euclidean norm of the n-vector stored in dx() with storage */
/*     increment incx . */
/*     if    n .le. 0 return with result = 0. */
/*     if n .ge. 1 then incx must be .ge. 1 */

/*           c.l.lawson, 1978 jan 08 */
/*     modified to correct problem with negative increment, 8/21/90. */
/*     modified to correct failure to update ix, 1/25/92. */

/*     four phase method     using two built-in constants that are */
/*     hopefully applicable to all machines. */
/*         cutlo = maximum of  dsqrt(u/eps)  over all known machines. */
/*         cuthi = minimum of  dsqrt(v)      over all known machines. */
/*     where */
/*         eps = smallest no. such that eps + 1. .gt. 1. */
/*         u   = smallest positive no.   (underflow limit) */
/*         v   = largest  no.            (overflow  limit) */

/*     brief outline of algorithm.. */

/*     phase 1    scans zero components. */
/*     move to phase 2 when a component is nonzero and .le. cutlo */
/*     move to phase 3 when a component is .gt. cutlo */
/*     move to phase 4 when a component is .ge. cuthi/m */
/*     where m = n for x() real and m = 2*n for complex. */

/*     values for cutlo and cuthi.. */
/*     from the environmental parameters listed in the imsl converter */
/*     document the limiting values are as follows.. */
/*     cutlo, s.p.   u/eps = 2**(-102) for  honeywell.  close seconds are
*/
/*                   univac and dec at 2**(-103) */
/*                   thus cutlo = 2**(-51) = 4.44089e-16 */
/*     cuthi, s.p.   v = 2**127 for univac, honeywell, and dec. */
/*                   thus cuthi = 2**(63.5) = 1.30438e19 */
/*     cutlo, d.p.   u/eps = 2**(-67) for honeywell and dec. */
/*                   thus cutlo = 2**(-33.5) = 8.23181d-11 */
/*     cuthi, d.p.   same as s.p.  cuthi = 1.30438d19 */
/*     data cutlo, cuthi / 8.232d-11,  1.304d19 / */
/*     data cutlo, cuthi / 4.441e-16,  1.304e19 / */

  if (*n > 0) {
    goto L10;
  }
  ret_val = zero;
  goto L300;

L10:
  next = 0;
  next_fmt = fmt_30;
  sum = zero;
  i = 1;
  if (*incx < 0) {
    i = (-(*n) + 1) * *incx + 1;
  }
  ix = 1;
/*                                                 begin main loop */
L20:
  switch (next) {
  case 0:
    goto L30;
  case 1:
    goto L50;
  case 2:
    goto L70;
  case 3:
    goto L110;
  }
L30:
  if ((d_1 = dx[i], abs(d_1)) > cutlo) {
    goto L85;
  }
  next = 1;
  next_fmt = fmt_50;
  xmax = zero;

/*                        phase 1.  sum is zero */

L50:
  if (dx[i] == zero) {
    goto L200;
  }
  if ((d_1 = dx[i], abs(d_1)) > cutlo) {
    goto L85;
  }
/*                                prepare for phase 2. */
  next = 2;
  next_fmt = fmt_70;
  goto L105;

/*                                prepare for phase 4. */

L100:
  ix = j;
  next = 3;
  next_fmt = fmt_110;
  sum = sum / dx[i] / dx[i];
L105:
  xmax = (d_1 = dx[i], abs(d_1));
  goto L115;

/*                   phase 2.  sum is small. */
/*                             scale to avoid destructive underflow. */

L70:
  if ((d_1 = dx[i], abs(d_1)) > cutlo) {
    goto L75;
  }
/*                     common code for phases 2 and 4. */
/*                     in phase 4 sum is large.  scale to avoid overflow.
*/

L110:
  if ((d_1 = dx[i], abs(d_1)) <= xmax) {
    goto L115;
  }
/* Computing 2nd power */
  d_1 = xmax / dx[i];
  sum = one + sum * (d_1 * d_1);
  xmax = (d_1 = dx[i], abs(d_1));
  goto L200;

L115:
/* Computing 2nd power */
  d_1 = dx[i] / xmax;
  sum += d_1 * d_1;
  goto L200;


/*                  prepare for phase 3. */

L75:
  sum = sum * xmax * xmax;


/*     for real or d.p. set hitest = cuthi/n */
/*     for complex      set hitest = cuthi/(2*n) */

L85:
  hitest = cuthi / (real) (*n);

/*                   phase 3.  sum is mid-range.  no scaling. */

  i_1 = *n;
  for (j = ix; j <= i_1; ++j) {
    if ((d_1 = dx[i], abs(d_1)) >= hitest) {
      goto L100;
    }
/* Computing 2nd power */
    d_1 = dx[i];
    sum += d_1 * d_1;
    i += *incx;
/* L95: */
  }
  ret_val = sqrt(sum);
  goto L300;

L200:
  ++ix;
  i += *incx;
  if (ix <= *n) {
    goto L20;
  }
/*              end of main loop. */

/*              compute square root and adjust for scaling. */

  ret_val = xmax * sqrt(sum);
L300:
  return ret_val;
}				     /* dnrm2_ */

 /* Subroutine */ int
dlassq_(n, x, incx, scale, sumsq)
  integer *n;
  doublereal *x;
  integer *incx;
  doublereal *scale, *sumsq;
{
  /* System generated locals */
  integer i_1, i_2;
  doublereal d_1;

  /* Local variables */
  static doublereal absxi;
  static integer ix;

  /* Parameter adjustments */
  --x;

  /* Function Body */

/*  -- LAPACK auxiliary routine (version 1.0) -- */
/*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd., */
/*     Courant Institute, Argonne National Lab, and Rice University */
/*     February 29, 1992 */

/*     .. Scalar Arguments .. */
/*     .. */
/*     .. Array Arguments .. */
/*     .. */

/*  Purpose */
/*  ======= */

/*  DLASSQ  returns the values  scl  and  smsq  such that */

/*     ( scl**2 )*smsq = x( 1 )**2 +...+ x( n )**2 + ( scale**2 )*sumsq,*/

/*  where  x( i ) = X( 1 + ( i - 1 )*INCX ). The value of  sumsq  is */
/*  assumed to be non-negative and  scl  returns the value */

/*     scl = max( scale, abs( x( i ) ) ). */

/*  scale and sumsq must be supplied in SCALE and SUMSQ and */
/*  scl and smsq are overwritten on SCALE and SUMSQ respectively. */

/*  The routine makes only one pass through the vector x. */

/*  Arguments */
/*  ========= */

/*  N       (input) INTEGER */
/*          The number of elements to be used from the vector X. */

/*  X       (input) DOUBLE PRECISION */
/*          The vector for which a scaled sum of squares is computed. */
/*             x( i )  = X( 1 + ( i - 1 )*INCX ), 1 <= i <= n. */

/*  INCX    (input) INTEGER */
/*          The increment between successive values of the vector X. */
/*          INCX > 0. */

/*  SCALE   (input/output) DOUBLE PRECISION */
/*          On entry, the value  scale  in the equation above. */
/*          On exit, SCALE is overwritten with  scl , the scaling factor*/
/*          for the sum of squares. */

/*  SUMSQ   (input/output) DOUBLE PRECISION */
/*          On entry, the value  sumsq  in the equation above. */
/*          On exit, SUMSQ is overwritten with  smsq , the basic sum of */

/*          squares from which  scl  has been factored out. */


/*     .. Parameters .. */
/*     .. */
/*     .. Local Scalars .. */
/*     .. */
/*     .. Intrinsic Functions .. */
/*     .. */
/*     .. Executable Statements .. */

  if (*n > 0) {
    i_1 = (*n - 1) * *incx + 1;
    i_2 = *incx;
    for (ix = 1; i_2 < 0 ? ix >= i_1 : ix <= i_1; ix += i_2) {
      if (x[ix] != 0.) {
	absxi = (d_1 = x[ix], abs(d_1));
	if (*scale < absxi) {
/* Computing 2nd power */
	  d_1 = *scale / absxi;
	  *sumsq = *sumsq * (d_1 * d_1) + 1;
	  *scale = absxi;
	} else {
/* Computing 2nd power */
	  d_1 = absxi / *scale;
	  *sumsq += d_1 * d_1;
	}
      }
/* L10: */
    }
  }
  return 0;

/*     End of DLASSQ */

}				     /* dlassq_ */
