/* f2cif.c 

   fortran intrinsic functions needed by f2c  
   sws 5/92 

	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

  (certain) fortran builtin functions, from f2c library 
 I've taken what is needed by the LAPACK qr routines */

#include <math.h>
#include "f2c.h"

#define log10e 0.43429448190325182765

extern double
d_lg10(doublereal *x)
{
  /*double log();*/

  return (log10e * log(*x));
}


extern double
d_sign(doublereal *a, doublereal*b)
{
  double x;

  x = (*a >= 0 ? *a : -*a);
  return (*b >= 0 ? x : -x);
}

extern double
pow_di(doublereal *ap, integer *bp)
{
  double powdi, x;
  integer n;

  powdi = 1.0;
  x = *ap;
  n = *bp;

  if (n != 0) {
    if (n < 0) {
      if (x == 0) {
	return (powdi);
      }
      n = -n;
      x = 1 / x;
    }
    for (;;) {
      if (n & 01)
	powdi *= x;
      if (n >>= 1)
	x *= x;
      else
	break;
    }
  }
  return (powdi);
}

/* end of f2cif.c */
