/*
	apl compiler
		build new parse tree nodes
			timothy a. budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include <stdio.h>
#include <string.h>

#include "parse.h"
#include "ptree.h"
#include "y_tab.h"


/* externals from yacc */
extern void prog(struct headnode * head, struct statenode * code);
extern void yyerror(char *c);

/* slen - string length without escape characters 
   - sws; don't use c escapes...
*/
extern int
slen(char *c)
{
  int i;
  char *p;

  i = 0;
  for (p = c; *p; p++)
/*	if (*p != '\\')*/
    i++;
  return (i);
}


/* newid - create a new id string */
char *
newid(char *name)
{
  char *x;

  x = (char *) malloc((unsigned) strlen(name) + 1);
  if (x == NILCHAR)
    yyerror("out of space");
  strcpy(x, name);
  return (x);
}

/* newhead - make a new function header node */
struct headnode *
newhead(char *name, char *parm1, char *parm2)
{
  struct headnode *x;
  struct symnode *h = NILSYM;

  x = structalloc(headnode);
  if (x == NILHEAD)
    yyerror("out of space");
  if (name != NILCHAR) {
    h = enterid(name, FUNCTION, APLC_UKTYPE, NORANK);
    funname = h->name;/* setup current function name */
  }
  x->opname = NILCHAR;
  x->fname = name;
  x->rfname = NILCHAR;
  x->asvar = NILCHAR;
  x->parm1 = parm1;
  x->parm2 = parm2;
  if (parm1 != NILCHAR) {
    /*enterid(parm1, PARAM, APLC_UKTYPE, NORANK);*/
    enterid(parm1, PARAM, APLC_ANY, ANYRANK);
  }
  if (parm2 != NILCHAR) {
    /*enterid(parm2, PARAM, APLC_UKTYPE, NORANK);*/
    enterid(parm2, PARAM, APLC_ANY, ANYRANK);
  }
  return (x);
}

/* direct - direct defintion declaration 
   - label is the fn name */
void 
direct(char *label, struct node * expr)
{
  struct node *x; 
  struct symnode *s;
  struct headnode *h;

  h = newhead(label, "_alpha", "_omega");
  h->asvar = "_zeta";
  /* get info about name? setup assignment variable */
  idclass("_zeta", &s);
  x = pt2(ASSIGN, ptvar(s), expr);
  prog(h, newstate(NILCHAR, x));
  resetconsts();
  reinit_local_symtab();
}

/* newstate - produce a new statement node */
struct statenode *
newstate(char *label, struct node * code)
{
  struct statenode *x;

  if (code->nodetype == COMMENT && label == NILCHAR)
    return (NILSTATE);
  x = structalloc(statenode);
  if (x == NILSTATE)
    yyerror("out of space");
  x->label = label;
  x->code = code;
  x->nextstate = NILSTATE;
  x->list = NILSYM;
  return (x);
}

/* addstmt - add a statement to statement list */
struct statenode *
addstmt(struct statenode * first, struct statenode * new)
{
  struct statenode *i;

  if (new == NILSTATE)
    return (first);
  else if (first == NILSTATE)
    return (new);
  else {
    for (i = first; i->nextstate != NILSTATE; i = i->nextstate);
    i->nextstate = new;
    return (first);
  }
}

/* newnode - produce a new parse tree node */
struct node *
newnode(int type)
{
  struct node *x;

  x = structalloc(node);
  if (x == (struct node *) 0)
    yyerror("out of space");
  x->nodetype = type;
  x->n.info = 0;
  x->left = x->right = x->axis = x->store = NILP;
  x->namep = NILCHAR;
  x->namea = NILCHAR;
  x->funleft = x->funright = NILP;
  x->n.type = x->n.rank = x->n.shape = x->n.values = 0;
  x->n.size = -1;
  x->optype = APLC_NOT;
  x->index = 0;
  return (x);
}

/* pt1 - simple 1 child node */
struct node *
pt1(int type, struct node * child)
{
  struct node *x;

  x = newnode(type);
  x->right = child;
  return (x);
}

/* ptaxis - process an (integer) axis specifier */
void 
ptaxis(struct node * x, struct node * axis, int ainfo)
{
  if (axis != NILP) {
    x->axis = pt1(CISCALAR, axis);
  } else {
    x->axis = NILP;
    x->n.info |= ainfo;
  }
}

/* ptgaxis - process a general axis specifier */
void 
ptgaxis(struct node * x, struct node * axis, int ainfo)
{
  if (axis != NILP) {
    x->axis = pt1(CSCALAR, axis);
  } else {
    x->axis = NILP;
    x->n.info |= ainfo;
  }
}

/* pt1a - 1 child node with axis */
struct node *
pt1a(int type, struct node * axis, int ainfo, struct node * child)
{
  struct node *x;

  x = pt1(type, child);
  ptaxis(x, axis, ainfo);
  return (x);
}

/* pt1o - 1 child node with operator */
struct node *
pt1o(int type, enum sfuns op, struct node * child)
{
  struct node *x;

  x = pt1(type, child);
  x->optype = op;
  return (x);
}

/* pt1ao - one child node with both axis and operator */
struct node *
pt1ao(int type, enum sfuns op, struct node * axis, struct node * child, int ainfo)
{
  struct node *x;

  x = pt1a(type, axis, ainfo, child);
  x->optype = op;
  return (x);
}

/* pt2 - simple 2 child node */
struct node *
pt2(int type, struct node * child1, struct node * child2)
{
  struct node *x;

  x = newnode(type);
  x->left = child1;
  x->right = child2;
  return (x);
}

/* pt2a - 2 child node with axis */
struct node *
pt2a(int type, struct node *axis, int ainfo, 
     struct node *child1, struct node * child2)
{
  struct node *x;

  x = pt2(type, child1, child2);
  /* sws  allow for real axis for cat - possible laminate */
  if (type != CAT)
    ptaxis(x, axis, ainfo);
  else
    ptgaxis(x, axis, ainfo);
  return (x);
}

/* pt2o - two child node with operator */
struct node *
pt2o(int type, enum sfuns op, struct node * child1, struct node * child2)
{
  struct node *x;

  x = pt2(type, child1, child2);
  x->optype = op;
  return (x);
}

/* pt2ao - two child node with both operator and axis */
struct node *
pt2ao(int type, enum sfuns op, struct node * axis, int ainfo, 
  struct node * child1, struct node * child2)
{
  struct node *x;

  x = pt2a(type, axis, ainfo, child1, child2);
  x->optype = op;
  return (x);
}

/* pt2aos - two child node with both operator and axis and store 
            sws  used for decode for an intermediate result
*/
struct node *
pt2aos(int type, enum sfuns op, struct node * axis, int ainfo, 
  struct node * child1, struct node * child2)
{
  struct node *x;

  x = pt2a(type, axis, ainfo, child1, child2);
  x->optype = op;
  x->store = pt1(SM, NILP);
  return (x);
}

/* ptsort - sort function */
struct node *
ptsort(int direction, struct node * child)
{
  struct node *x;

  x = pt1(SORT, child);
  x->ptr0 = direction;
  return (x);
}

/* ptsvec - string constant (vector) */
struct node *
ptsvec(char *chars)
{
  struct node *x;
  int len;

  x = newnode(SCON);
  x->n.type = (int) APLC_CHAR;
  len = slen(chars);
  x->n.shape = addicon(len);
  x->n.size = len;
  if (len == 1)
    x->n.rank = 0; /* sws  scalar */
  else
    x->n.rank = 1; /* vector */
  x->n.values = slen(sconsts);
  x->n.info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN |
      SHAPEKNOWN | VALUESKNOWN);
  if (strlen(chars) + strlen(sconsts) > MAXCONSTS)
    yyerror("too many string constants");
  strcat(sconsts, chars);
  /*fprintf(stderr,"[ptsvec] len %d, [%s]\n",len, chars);*/
  free(chars);/* was built with strdup */ 
  return (x);
}

/* ptval - scalar value */
struct node *
ptval(int type, int val)
{
  struct node *x;

  x = newnode(type);
  x->n.rank = 0;
  x->n.shape = 1;
  x->n.size = 1;
  x->n.values = val;
  x->n.info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN |
      SHAPEKNOWN | VALUESKNOWN);
  return (x);
}

/* aptval - add a scalar value, forming an array */
struct node *
aptval(struct node * node)
{
  node->n.rank = 1;
  node->n.shape++;
  return (node);
}

/* ptvec - constant vector */
struct node *
ptvec(struct node * x, int type, int rtype)
{

  x->nodetype = type;
  x->n.type = rtype;
  x->n.info |= (TYPEDECL | TYPEKNOWN);
  x->n.size = x->n.shape;
  if (x->n.rank)
    x->n.shape = addicon(x->n.shape);
#if 0
  fprintf(stderr, "[ptvec] rank %d, shape %d, size %d\n",
	  x->n.rank, x->n.shape, x->n.size);
#endif  
  return (x);
}

struct node *
sysparm(char *name)
{
  struct symnode *x; 

  idclass(name, &x);/* get info about name */
  if (x == NILSYM) {
    /* declare system generated variables */
    enterid(newid("_alpha"), PARAM, APLC_UKTYPE, NORANK);
    enterid(newid("_omega"), PARAM, APLC_UKTYPE, NORANK);
    enterid(newid("_zeta"),  APARAM, APLC_UKTYPE, NORANK);
    /* try it again */
    idclass(name, &x);/* get info about name */
    if (x == NILSYM)
      yyerror("sysparm error");
  }
  return (ptvar(x));
}

/* ptvar - variable node */
struct node *
ptvar(struct symnode * var)
{
  struct node *x;

  x = newnode(IDENT);
  x->namep = var->name;
  if ((var->s.type != APLC_UKTYPE) && (var->s.type != APLC_ANY))
    x->n.info |= (TYPEDECL | TYPEKNOWN);
  x->n.type = var->s.type;
  /* if (var->s.rank != NORANK)*/
  if (var->s.rank == ANYRANK) {
    x->n.info |= RANKKNOWN;
    x->n.rank = ANYRANK;
  } else if ( var->s.rank != NORANK )
    x->n.info |= (RANKDECL | RANKKNOWN);
  x->n.rank = var->s.rank;
  return (x);
}

/* ptfun - functions
           used for dyadic or monadic user fns 
 */
struct node *
ptfun(struct symnode *fun, struct node *child1, struct node *child2)
{
  struct node *x;

  /* sws  old version used collects in apl.y */
  /* x = pt2(FIDENT, child1, child2); */

#ifdef  BYREF
  /* sws   this version will pass idents by reference */
  if (child1 != NILP)
    x = pt2(FIDENT, pt1(COLLECT, child1), pt1(COLLECT, child2));
  else
    x = pt2(FIDENT, child1, pt1(COLLECT, child2));
#else
  /*- sws   this version will always loop to collect idents,
            pass by value */
  if (child1 != NILP)
    x = pt2(FIDENT, pt1(CCOLLECT, child1), pt1(CCOLLECT, child2));
  else
    x = pt2(FIDENT, child1, pt1(CCOLLECT, child2));
#endif

  x->namep = fun->name;
  x->namea = fun->name;
  x->n.type = fun->s.type;
  if ((fun->s.type != APLC_UKTYPE) & (fun->s.type != APLC_ANY))
    x->n.info |= (TYPEDECL | TYPEKNOWN);
  x->n.rank = fun->s.rank;
  if ( (fun->s.rank != NORANK) && (fun->s.rank != ANYRANK) )
    x->n.info |= (RANKDECL | RANKKNOWN);
  return (x);
}

/* ptmrho - monadic rho (shape)
   - could also be rho rho, or rank
 */
struct node *
ptmrho(struct node * child)
{
  struct node *x;

  if (child->nodetype == RHO) {
    /* rank case */
    x = child;
    x->nodetype = RHORHO;
  } else {
    x = newnode(RHO);
    x->right = child;
  }
  return (x);
}

/* ptmsys - msysfun
 */
struct node *
ptmsys(int type, enum sfuns op, struct node * child)
{
  struct node *x;

  if (child->nodetype == IDENT) {
    x = pt1(type, child);
  } else {
    /* add a collect */
    x = pt1(type, pt1(COLLECT, child));
  }
  x->optype = op;
  return (x);
}


/* ptsub - subscripted assignment 

   SUB SUBASSIGN expression :     SUBASSIGN(SUB, expression)  

   sub is
   subid LB sublist RB : SUB(subid, sublist) 

   becomes
   SUBASSIGN
    left   subid
    right  expression
    axis   sublist (SM)
    store  SM
 */
struct node *
ptsub(struct node * child1, struct node * child2)
{
  child1->axis = child1->right;
  /* child1->left = child1->left */
  child1->right = child2;
  child1->store = pt1(SM, NILP);
  /* child1->store = NILP; */
  child1->nodetype = SUBASSIGN;
  return (child1);
}


/* pttop - top of expression 

   note that this controls the addition of a QUADASSIGN (printing of
   results)

*/
struct node *
pttop(struct node * child)
{
  struct node *x;
  int type;

  type = child->nodetype;
  /* if not assignment, print out expression */
  if (type == ASSIGN || type == QUADASSIGN || 
      type == DQUADASSIGN || type == QQUADASSIGN || type == DQQUADASSIGN ||
      type == SUBASSIGN)
    x = child;
  else if (type == ASYSVAR && child->right != NILP)
    x = child;
  else if (type == CATCH)
    x = child;
  else
    x = ptqass(child);
  /*x = pt1(QUADASSIGN, child);*/
  return (x);
}

/* ptsemi - semicolon */
struct node *
ptsemi(struct node * child1, struct node * child2)
{
  struct node *x;

  x = pt2(SM, child1, child2);
  if (child1 == NILP)
    x->ptr1 = 0;
  else
    x->ptr1 = child1->ptr1 + 1;
  return (x);
}


/* end of ptree.c */


