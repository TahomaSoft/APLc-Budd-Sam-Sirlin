/*
	APL Compiler

	New parse tree functions 
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/
#include <stdio.h>
#include <string.h>

#include "parse.h"
#include "ptree.h"
#include "y_tab.h"

/* externals from yacc */
extern void prog(struct headnode * head, struct statenode * code);
extern void yyerror(char *c);

/* ptstore - simple store child node */
struct node *
ptstore(int type)
{
  struct node *x;

  x = newnode(type);
  /* x->namep= NILCHAR; */
  return (x);
}

/* sws 
   put a format after a quadassign 
   - format is smarter about spacing; 
   --- can't do this for non-top as it leaves a char   */
struct node *
ptqass(struct node * child)
{
  struct node *x;
  /* box collect */
  if ( (child->nodetype == FORMAT) ||
       (child->nodetype == SCON)   ||
       (child->nodetype == FIDENT) ||
       (child->nodetype == COLLECT) )
    x = pt1(QUADASSIGN, child);/* no need */
  else
    x = pt1(QUADASSIGN, pt1(COLLECT,child));/* normal */
#if 0
  /* box format collect */
  if ( (child->nodetype == FORMAT) ||
       (child->nodetype == SCON) )
    x = pt1(QUADASSIGN, child);/* no need */
  else if (child->nodetype == COLLECT)
    x = pt1(QUADASSIGN, pt1(FORMAT,child));
  else
    x = pt1(QUADASSIGN, pt1(FORMAT,pt1(COLLECT,child)));/* normal */
#endif
#if 0
  /* old default, lasy evaluation printing */
  x = pt1(QUADASSIGN, child);
#endif
  return (x);
}

/* old default, lasy evaluation printing */
struct node *
ptqlzass(struct node * child)
{
  struct node *x;

  x = pt1(QUADASSIGN, child);
  return (x);
}

/* sws
   pttcav - scalar component of atomic vector
   based on pt1o - 1 child node with operator */
struct node *
pttcav(int type, enum sysvars var)
{
  struct node *x;

  x = newnode(type);
  x->optype = var;
  x->n.type = (int) APLC_CHAR;
  x->n.rank = 0;
  x->n.shape = 1;
  x->n.size = 1;
  switch(var) {
  default:
    yyerror("[pttcav] parse error");
    break;
  case TCBEL: 
    x->n.values = 7;
    break;
  case TCBS:  
    x->n.values = 8;
    break;
  case TCCR:  
    x->n.values = 13;
    break;
  case TCDEL: 
    x->n.values = 127;
    break;
  case TCESC: 
    x->n.values = 27;
    break;
  case TCFF:  
    x->n.values = 12;
    break;
  case TCHT:  
    x->n.values = 9;
    break;
  case TCLF:  
    x->n.values = 10;
    break;
  case TCNUL: 
    x->n.values = 0;
    break;
  }
  /* don't set valuesknown or adjdcls will barf */
  x->n.info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN | SHAPEKNOWN );
  return (x);
}

/* sws
   pttycon - type constant
   based on pttcav */
struct node *
pttycon(int type, int var)
{
  struct node *x;

  x = newnode(type);
  x->optype = var;
  x->n.type = (int) APLC_INT;
  x->n.rank = 0;
  x->n.shape = 1;
  x->n.size = 1;
  x->n.values = var;
  /* don't set valuesknown or adjdcls will barf */
  x->n.info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN | SHAPEKNOWN );
  return (x);
}

/* ptnillfun - functions
   used for nilladic user fns (sws) */
struct node *
ptnilfun(struct symnode * fun)
{
  struct node *x;

  x = pt2(FIDENT, NILP, NILP);
  x->namep = fun->name;
  x->namea = fun->name;
  x->n.type = fun->s.type;
  if ((fun->s.type != APLC_UKTYPE) & (fun->s.type != APLC_ANY))
    x->n.info |= (TYPEDECL | TYPEKNOWN);
  x->n.rank = fun->s.rank;
  if (fun->s.rank == ANYRANK) {
    x->n.info |= RANKKNOWN;
    x->n.rank = ANYRANK;
  } else if (fun->s.rank != NORANK)
    x->n.info |= (RANKDECL | RANKKNOWN);
  return (x);
}

/* newophead - make a new operator header node */
struct headnode *
newophead(char *parm1, 
	  char *fname, char *name, char *rfname, 
	  char *parm2)
{
  struct headnode *x;
  struct symnode *h = NILSYM;

  x = structalloc(headnode);
  if (x == NILHEAD)
    yyerror("[newophead] out of space");
  if (name != NILCHAR) {
    h = enterid(name, OPERATOR, APLC_UKTYPE, NORANK);
    funname = h->name;/* setup current function name */
  }
  if (fname != NILCHAR)
    enterid(fname, LFUNCTION, APLC_ANY, ANYRANK);
  if (rfname != NILCHAR) {
    enterid(rfname, LFUNCTION, APLC_ANY, ANYRANK); 
  }
  x->opname = name;
  x->fname = fname;
  x->rfname = rfname;
  x->asvar = NILCHAR;
  x->parm1 = parm1;
  x->parm2 = parm2;
  if (parm1 != NILCHAR)
    enterid(parm1, PARAM, APLC_ANY, ANYRANK);
  if (parm2 != NILCHAR)
    enterid(parm2, PARAM, APLC_ANY, ANYRANK);
  return (x);
}

/* ptop - operator  
   left (leftfun op rightrun) right  */
struct node *
ptop(struct node *child1, struct symnode *fun, struct symnode *op, 
     struct symnode *rfun, struct node *child2)
{
  struct node *x;

#if 0
  /* sws   this version will pass idents by reference */
  if (child1 != NILP)
    x = pt2(FIDENT, pt1(COLLECT, child1), pt1(COLLECT, child2));
  else
    x = pt2(FIDENT, child1, pt1(COLLECT, child2));
#endif

  x = newnode(OPIDENT);
  x->namep = op->name;
  x->namea = op->name;
  x->n.type = op->s.type;

  /*x->funleft = ptfun(fun, NILP,NILP); */
  x->funleft = newnode(FIDENT);
  x->funleft->namep = fun->name;  
  x->funleft->namea = fun->name;  
  x->funleft->n.type = fun->s.type;
  if (rfun != NILSYM) {
    x->funright = newnode(FIDENT);
    x->funright->namep = rfun->name;  
    x->funright->namea = rfun->name;  
    x->funright->n.type = rfun->s.type;
  } else
    x->funright = NILP; 
 
  /*- sws   this version will always loop to collect idents,
            pass by value */
  if (child1 != NILP)
    x->left = pt1(CCOLLECT, child1);
  if (child2 != NILP)
    x->right = pt1(CCOLLECT, child2);

  if ((op->s.type != APLC_UKTYPE) & (op->s.type != APLC_ANY))
    x->n.info |= (TYPEDECL | TYPEKNOWN);
  x->n.rank = fun->s.rank;
  if (op->s.rank == ANYRANK) {
    x->n.info |= RANKKNOWN;
    x->n.rank = ANYRANK;
  } else if (op->s.rank != NORANK)
    x->n.info |= (RANKDECL | RANKKNOWN);
  return (x);
}

/* given a tree built for sub array list,
   convert for link */
struct node *
ptsmtolink(struct node *child)
{
  struct node *x;
  struct node *c;
  struct node *xt;

  x = newnode(LINK);
  x->right = pt1(COLLECT, child->right);
  xt = x;
  c = child;
  while (c->left != NULL) {
    fprintf(stderr,"[] c = %p, L %p, R %p\n", c, c->left, c->right);
    c = c->left;
    xt ->left = newnode(LINK);
    xt = xt->left;
    xt->right = pt1(COLLECT, c->right);
  }
  return x;
}

/* end */

