/*
	APL Compiler

        sam sirlin

	Run time system
	routines having to do with matrices
        calls linpack routines for now...

*/

#include "aplc.h"
#include <stdio.h>
#include <math.h>

/* function declarations */
void 
domino(struct trs_struct * res, struct trs_struct * right,
    int type, int rank, int *shape);
void 
msolve(struct trs_struct * res,
    struct trs_struct * left, int ltype, int lrank, int *lshape,
    struct trs_struct * right, int rtype, int rrank, int *rshape);



/* printout matrix in mp_struct, for debugging */
static void
prtmat(union mp_struct a, int m, int n)
{
  union mp_struct temp;
  int i, j;

  temp = a;
  for (i = 0; i < m; i++) {
    for (j = 0; j < n; j++) {
      printf("%f ", *temp.rp++);
    }
    printf("\n");
  }
}

/* matrix inverse */
void
domino(struct trs_struct * res, struct trs_struct * right,
    int type, int rank, int *shape)
{
  union mp_struct a;
  union mp_struct at;
  union mp_struct c;
  union mp_struct mptemp;

  double *det, rcond, *work, *z;
  int i, *ipvt, job, lda, m, n, size;
  int dgedi_(), dgeco_();

  job = 1;
  m = shape[0];
  lda = m;
  n = shape[1];
  size = m * n;

  /* setup workspace */
  aplc_vectalloc(&mptemp, n, APLC_REAL);
  det = mptemp.rp;
  aplc_vectalloc(&mptemp, n, APLC_REAL);
  work = mptemp.rp;
  aplc_vectalloc(&mptemp, n, APLC_REAL);
  z = mptemp.rp;
  aplc_vectalloc(&mptemp, n, APLC_INT);
  ipvt = mptemp.ip;

  /* printf("\n type %d, rank %d shape %d,%d\n", type,rank,lda,n); */

  /* put stuff in result  */
  aplc_vectalloc(&a, size, APLC_REAL);
  c = right->value;
  at = a;
  switch (type) {
  default:
    aplc_error("Domino domain error, int or real expected");
    break;
  case APLC_BOOL:
  case APLC_INT:
    for (i = 0; i < size; i++) {
      *at.rp++ = (double) *c.ip++;
    }
    break;

  case APLC_REAL:
    for (i = 0; i < size; i++) {
      *at.rp++ = *c.rp++;
    }
    break;
  }

/* sws  for debugging */
/*
   printf("\n A \n");
    prtmat(a,m,n);
*/

  (void) dgeco_(a.rp, &lda, &n, ipvt, &rcond, z);
  /* printf("rcond %g\n",rcond); */
  if (rcond > EPS)
    (void) dgedi_(a.rp, &lda, &n, ipvt, det, work, &job);
  else
    aplc_error("Domino domain error - singular matrix");

/* sws  debugging printout
    prtmat(a,m,n);
*/

  res->type = APLC_REAL;
  res->rank = 2;
  aplc_vectalloc(&mptemp, 2, APLC_INT);
  res->shape = mptemp.ip;
  res->shape[0] = lda;
  res->shape[1] = n;
  res->value = a;
}

/* solution to linear equations */
void
msolve(struct trs_struct * res,
    struct trs_struct * left, int ltype, int lrank, int *lshape,
    struct trs_struct * right, int rtype, int rrank, int *rshape)
{
  union mp_struct a, at;
  union mp_struct b, bt;
  union mp_struct c;
  union mp_struct mptemp;

  double rcond, *z;
  int i, *ipvt, j, job, lda, m, n, size, lsize;
  int dgesl_(), dgeco_();

  /* job = 0   solves Ax = b */
  /* job != 0         A'x = b */
  job = 1;

  m = rshape[0];
  n = rshape[1];
  lda = m;
  size = m * n;

  /* setup workspace */
  aplc_vectalloc(&mptemp, n, APLC_REAL);
  z = mptemp.rp;
  aplc_vectalloc(&mptemp, n, APLC_INT);
  ipvt = mptemp.ip;

  /* put right stuff in a  */
  aplc_vectalloc(&a, size, APLC_REAL);
  c = right->value;
  at = a;
  switch (rtype) {
  default:
    aplc_error("Msolve domain error, int or real expected (R)");
    break;
  case APLC_BOOL:
  case APLC_INT:
    for (i = 0; i < size; i++) {
      *at.rp++ = (double) *c.ip++;
    }
    break;
  case APLC_REAL:
    for (i = 0; i < size; i++) {
      *at.rp++ = *c.rp++;
    }
    break;
  }

  /* factor A */
  dgeco_(a.rp, &lda, &n, ipvt, &rcond, z);
  /* printf("rcond %g\n",rcond); */
  if (rcond > EPS) {
    /* put transpose of left stuff in b  */
    lsize = lshape[0] * lshape[1];
    aplc_vectalloc(&b, lsize, APLC_REAL);
    c = left->value;
    bt = b;
    switch (ltype) {
    default:
      aplc_error("Msolve domain error, int or real expected (L)");
      break;
    case APLC_BOOL:
    case APLC_INT:
      for (i = 0; i < lshape[0]; i++) {
	for (j = 0; j < lshape[1]; j++) {
	  (b.rp)[i + lshape[0] * j] = (double) *c.ip++;
	}
      }
      break;
    case APLC_REAL:
      for (i = 0; i < lshape[0]; i++) {
	for (j = 0; j < lshape[1]; j++) {
	  (b.rp)[i + lshape[0] * j] = *c.rp++;
	}
      }
      break;
    }

/* sws  debugging printout
    printf("\n a\n");
    prtmat(a,m,n);
    printf("\n b\n");
    prtmat(b,lshape[1],lshape[0]);
*/

    /* solve for each column of left */
    /* which is a row of b */
    for (j = 0; j < lshape[1]; j++) {
      dgesl_(a.rp, &lda, &n, ipvt, &(b.rp)[j * lshape[0]], &job);
    }
  } else
    aplc_error("Domino domain error - singular matrix");

/*
  printf("\n bn\n");
  prtmat(b, lshape[1], lshape[0]);
*/

  /* setup return value */
  res->type = APLC_REAL;
  res->rank = 2;
  aplc_vectalloc(&mptemp, 2, APLC_INT);
  res->shape = mptemp.ip;
  res->shape[0] = lshape[0];
  res->shape[1] = lshape[1];

  /* put transpose of (new) b in result */
  aplc_vectalloc(&mptemp, lsize, APLC_REAL);
  c = mptemp;
  for (i = 0; i < lshape[0]; i++) {
    for (j = 0; j < lshape[1]; j++) {
      *c.rp++ = (b.rp)[i + lshape[0] * j];
    }
  }
  res->value = mptemp;
}

/* end of runmat.c */
