/* catenate.c

	APL Compiler

	Code Generation routines for catenate and laminate
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.
*/

#include <stdio.h>
#include "parse.h"
#include "y_tab.h"
#include "gen.h"

/* local functions */
static int axi(struct node * node, struct node * axis, int i, 
	       short int *reg, int taxisp);
static void axes(struct node * node, struct node * axis, int e, int sL, 
		 int sR);
static void axes_lam(struct node *node, struct node *axis, int e, int sL,
		     int sR);


/* sws version of dsfunt, for cat, subassign
   - get the max of two types, possibly at runtime 
     at runtime this will be in ptr ival
   - generate code for node type
*/
extern void
mergetype(struct node * node,
    struct node * left, struct node * right, int ival)
{
  if (cteq(left->c.type, right->c.type)) {
      node->c.type = left->c.type;
      return;
  }
  ieq(ival);
  printf("aplc_mergetype(");
  ctgen(left->c.type);
  commasp();
  ctgen(right->c.type);
  rpseminl();
  node->c.type = gicn(coiptr, ival, 0);
}


/*
sws
	axi - generate code to produce

        reg   - (pointer to) register of axis value (if real)
	i     - (pointer to) the position of the axis (zero based)
	taxisp - (pointer to) the axis type
	taxis  - the axis type

	the argument i, contains the integer pointer into which the
	associated value is to be placed

        does nothing if LASTAXIS

	used by gencat
*/

static int 
axi(struct node * node, struct node * axis, int i, short int *reg, 
    int taxisp)
{
  int taxis;

  if (node->n.info & FIRSTAXIS) {
    setizero(i);
    printf("i%d = APLC_INT;\n", taxisp);
    seminl();
    taxis = APLC_INT;
  } else if (node->n.info & LASTAXIS) {
    setizero(i);  /* do the same as above, ignored anyway */
    printf("i%d = APLC_INT;\n", taxisp);
    taxis = APLC_INT;
  } else {
    /* axis value is not obvious, may be known */
    /* test code:
    taxis = axis->n.type;
    fprintf(stderr,"[catenate] axi, axis type =[%d]\n", 
    taxis);*/

    switchbox(axis, SHAPE, 0);
    if (axis->n.info & TYPEKNOWN) {
      taxis = rtype(axis);
      if ( (taxis == APLC_INT) || (taxis == APLC_BOOL) ) {
	ieqtree(i, gsfun(APLC_MINUS, axis->c.values, gixorg()));
	printf("i%d = APLC_INT;\n", taxisp);
	taxis = APLC_INT;
      } else if (taxis == APLC_REAL) {
	/* put (real) value in register */
	*reg = resinreg(axis, *reg);
	/* subtract off indexorigin */
	ctgen(gbin(coasgn, axis->c.values,
		gsfun(APLC_MINUS, axis->c.values, gixorg())));
	seminl();
	/* alternate version... */
	/* put (real) value in register */
	/* subtract off indexorigin */
/*--
		    reg= resinreg(axis, reg);
		    printf("res%d.r = ",reg);
		    printf(" - ");
		    gixorg();
		    seminl();
*/
	printf("i%d = APLC_REAL;\n", taxisp);
	taxis = APLC_REAL;
      } else {
	fprintf(stderr,"[catenate] axi, illegal axis type =[%d]\n", 
		taxis);
	error("illegal axis type");
      }
    } else {
      /* axis type unknown */
#if 0
      printf("/* [axi] axis type unknown */\n");
      /* put value in register */
      /* doesn't work if type unknown  .uck */
      *reg = resinreg(axis, *reg);
#endif

      /* we know axis right is cscalar, so must have a mp; havevalue */
#if 0
      /* for debugging */
      printf("/* ");
      ctgen(axis->c.values);
      printf("*/\n");
#endif
      /* put in reg */
      printf("aplc_mp2res(&res%d, &", *reg);
      /* ctgen( gmon(deref, axis->c.values) );*/
      /* ctgen( axis->c.values );*/
      /* expect code tree is deref */
      if (axis->c.values->cop == resptr)
	;/* in res already */
      else if (axis->c.values->cop == deref) {
	ctgen( axis->c.values->c0.cleft );
	printf(", 0,");
	ctgen(axis->c.type);
	rpseminl();
      } else {
	fprintf(stderr," cop = %d\n", axis->c.values->cop);
	error("[catenate/axi] code tree");
      }

      /* subtract off indexorigin */
      printf("aplc_resfun(&res%d, ", *reg);
      ctgen(axis->c.type);
      printf(", APLC_MINUS, ");
      ctgen(gixorg());
      rpseminl();
      taxis = APLC_UKTYPE;
      ieq(taxisp);
      ctgen(axis->c.type);
      seminl();
    }
    switchbox(axis, FINISH, 0);

  }
  return (taxis);
}

/*  sws
	axes - generate code to produce the following values

	axis is i
	e - the expansion vector value at position i (e sub i)
	sL - the shape of the left node at position i (s sub i)
	sR - the shape of the right node at position i (s sub i)

	the arguments e, and s contain the index registers into which the
	associated values are to be placed.

        In all three cases if the
	value is zero no code is generated to place the value.
	One of e or s must be non-zero.

        only for cases when the shape is known

        used in gencat
*/
static void 
axes(struct node *node, struct node *axis, int e, int sL, int sR)
{
  int rl, rr;

  if ( ! ((LEFT->n.info & SHAPEKNOWN) && (RIGHT->n.info & SHAPEKNOWN)) ) {
    /* error, can't find stuff; shouldn't happen */
    fprintf(stderr,"\n[axes] left:");    print_info(stderr, &(LEFT->n));
    fprintf(stderr,"\n    right:");    print_info(stderr, &(RIGHT->n));
    error("[catenate/axes] nonce error");
    return;
  }

  if (is_scalar(LEFT)) {
    seticon(sL , 1);
    axies(node, node->axis, RIGHT, 0, e, sR);
  } else if (is_scalar(RIGHT)) {
    seticon(sR, 1);
    axies(node, node->axis, LEFT, 0, e, sL);
  } else {
    /* need to check ranks */
    rl = rankvalue(LEFT);
    rr = rankvalue(RIGHT);
    if (rl == rr) {
      axies(node, node->axis, LEFT, 0, e, sL);
      axies(node, node->axis, RIGHT, 0, 0, sR);
    } else if (rl == rr - 1) {
      seticon(sL, 1);
      axies(node, node->axis, RIGHT, 0, e, sR);
    } else if ((rl - 1) == rr) {
      seticon(sR, 1);
      axies(node, node->axis, LEFT, 0, e, sL);
    }
    /* else consider laminate */
    else
      error("[catenate/axes] rank error");
  }
  return;
}


/* need special local values for
   - axis
   - left shape
   - right shape

   e computation
   n = rank+1
   e[n] = 1
   e[i] = s'[i+1]e[i+1] = s[i]e[i+1]

   i = 1.5 -> 2
   s=(s1,s2,s3)
   s'=(s1,2,s2,s3)
   e = (2*s2*s3, s2*s3, s3, 1) 
   e[i] = e[2] = s2*s3
 */
static void 
axes_lam(struct node *node, struct node *axis, int e, int sL, int sR)
{
  double ax;
  int iax;
  int i, e_val;

  if ( ! ( (LEFT->n.info & SHAPEKNOWN) && 
	   (RIGHT->n.info & SHAPEKNOWN) &&
	   (AXIS->n.info & VALUESKNOWN) ) ) {
    /* error, can't find stuff; shouldn't happen */
    fprintf(stderr,"\n[axes_lam] left:"); print_info(stderr, &(LEFT->n));
    fprintf(stderr,"\n    right:"); print_info(stderr, &(RIGHT->n));
    fprintf(stderr,"\n    axis:"); print_info(stderr, &(AXIS->n));
    error("[catenate/axes] nonce error");
    return;
  }

  ax = rconsts[AXIS->n.values];/* the axis value */
  iax = ceil(ax);
  if (is_scalar(LEFT)) {
    seticon(sL, 1);
    /*axies(node, node->axis, RIGHT, 0, e, sR);*/
    if (is_scalar(RIGHT)) {    
      seticon(sR, 1);
      seticon(e, 1);
    } else {
      /* then right shape is a new axis at iax (means sR is 1) */
      seticon(sR, 1);
      e_val = 1;
      for (i= RIGHT->n.rank-1; i>=iax-1; i--) {
	e_val *= iconsts[RIGHT->n.shape+i];
      }
      seticon(e, e_val);
    }
  } else {
    /* left is not a scalar */
    /*axies(node, node->axis, LEFT, 0, e, sL);*/
    /* then left shape is a new axis at iax (means sL is 1) */
    seticon(sL, 1);
    seticon(sR, 1);
    e_val = 1;
    for (i= LEFT->n.rank-1; i>=iax-1; i--) {
      e_val *= iconsts[LEFT->n.shape+i];
    }
    seticon(e , e_val);
  }
  return;
}


/*
  gencat - generate code for catenation function

  check if sequential and no possible replication - 
  (left non-scalar and right non-scalar)
  (left scalar and right scalar)
*/
#define isnot_scalar(node) ((node->n.info & RANKKNOWN) && (rankvalue(node) != 0))
#define CATSEQ ( (node->n.info & SEQUENTIAL) && (\
   ( isnot_scalar(LEFT) && isnot_scalar(RIGHT) ) || \
   ( (is_scalar(LEFT)) && ( is_scalar(RIGHT)) ) ) )

/*
	ptr1 -  type
	ptr2 -  rank
	ptr3 -  shape mp
	ptr4 -  s sub i for left hand side, sL
	ptr5 -  e sub i
	ptr6 -  size along ith dimension (sum of s's)
	ptr7 -  (axis register);  result
	ptr8 -  s sub i for right hand side, sR
	ptr9 -  axis;       value in given axis
	ptr10 - axis type; temp
*/
void 
gencat(struct node * node, enum pmodes mode, int top)
{
  int taxis;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);

    /* sws  modified to always define a type */
    if (!(node->n.info & TYPEKNOWN)) {
      mergetype(node, LEFT, RIGHT, node->ptr1); 
    } else {
      ieq(node->ptr1);
      ctgen(node->c.type);
      seminl();
    }

    /*  modified axies to get axis, register, axis type */
    taxis = axi(node, node->axis, node->ptr9, &(node->ptr7), node->ptr10);

    /* get e sL, sR */
    if ( !(node->n.info & SHAPEKNOWN) ) {

      /* check for laminate */
      if (taxis != APLC_INT) {
	/* for laminate, once we know how to get real value, if known, may
	   make better code 
	   for now, assume everything is unknown - the
	   decision of cat/lam done at run-time in catshape/lamshape
	*/

	/* determine axis type, value */
	/* lamcheck(&a.type, a.value, &axis); */
	printf("aplc_lamcheck(&i%d, &res%d, &i%d);\n",
	       node->ptr10, node->ptr7, node->ptr9);
      }

      rkeq(node, node->ptr2);
      /* aplc_catshape(shape, leftrank, leftshape, rightrank, rightshape,
               axis, axisind, taxis, e, sl, sr) */
      printf("aplc_catshape(&mp%d, ", node->ptr3);
      lrnsrrns(LEFT, RIGHT);
      printf(", i%d, ", node->ptr9);
      if (node->n.info & FIRSTAXIS)
	printf("1");
      else if (node->n.info & LASTAXIS)
	printf("2");
      else
	printf("0");
      printf(", i%d", node->ptr10);
      printf(", &i%d,&i%d,&i%d", node->ptr5, node->ptr4, node->ptr8);
      rpseminl();
      node->c.shape = gicn(memptr, node->ptr3, APLC_INT);
    } else {
      if (taxis == APLC_INT) {
	/* doesn't work for laminate */
	axes(node, node->axis, node->ptr5, node->ptr4, node->ptr8);
      } else {
	axes_lam(node, node->axis, node->ptr5, node->ptr4, node->ptr8);
      }
    }

    /* compute sum of left and right along axis */
    iopi(node->ptr6, node->ptr4, "+", node->ptr8);
    /* sequential axis is special case */
    if ( CATSEQ ) {
      if (!(LEFT->n.info & NOINDEX))
	setizero(LEFT->index);
      if (!(RIGHT->n.info & NOINDEX))
	setizero(RIGHT->index);
    }
    break;
  case COMBINE:
    break;

  case VALUE:
    /* first compute asubi */
    ieq(node->ptr9);
    asubic(node, RIGHT, node->index, node->ptr5, node->ptr6);
    seminl();
    printf("if (i%d < i%d) {\n", node->ptr9, node->ptr4);

    /* left side */
    if ( ! ( CATSEQ || (LEFT->n.info & NOINDEX) ) ) {
     if (LEFT->n.info & RANKKNOWN) {
      cmpidx2(node, node->ptr10, LEFT->index, node->index,
	  node->ptr9, node->ptr5, node->ptr4, node->ptr6);
     } else {
      /* need runtime test for singleton */
      iflp();
      /* testscalar(LEFT->c.rank, LEFT->c.shape); */
      singleton(LEFT);
      rpnl();
      setizero(LEFT->index);
      elsebr();
      cmpidx2(node, node->ptr10, LEFT->index, node->index,
	  node->ptr9, node->ptr5, node->ptr4, node->ptr6);
      rbr();
     }
    }
    switchbox(LEFT, VALUE, 0);
    node->ptr7 = resinreg(LEFT, node->ptr7);
    if ( CATSEQ && !(LEFT->n.info & NOINDEX) )
	iincr(LEFT->index);

    if (!cteq(LEFT->c.type, node->c.type)) {
      /* sws  code to make types conform to maxtype */
      printf(" /* gencat left type check */\n");
      printf("aplc_cktype(&res%d, i%d, ", node->ptr7, node->ptr1);
      ctgen(LEFT->c.type);
      printf(");\n");
    }
    rbr();

    /* right side */
    elsebr();
    if ( !( CATSEQ || (RIGHT->n.info & NOINDEX) ) ) {
     if (RIGHT->n.info & RANKKNOWN) {
      printf("i%d -= i%d;\n", node->ptr9, node->ptr4);
      cmpidx2(node, node->ptr10, RIGHT->index, node->index,
	  node->ptr9, node->ptr5, node->ptr8, node->ptr6);
     } else {
      /* need runtime test for singleton */
      iflp();
      /*testscalar(RIGHT->c.rank, RIGHT->c.shape); */
      singleton(RIGHT);
      rpnl();
      setizero(RIGHT->index);
      elsebr();
      printf("i%d -= i%d;\n", node->ptr9, node->ptr4);
      cmpidx2(node, node->ptr10, RIGHT->index, node->index,
	  node->ptr9, node->ptr5, node->ptr8, node->ptr6);
      rbr();
     }
    }
    switchbox(RIGHT, VALUE, 0);
    node->ptr2 = resinreg(RIGHT, node->ptr7);
    if (node->ptr2 != node->ptr7)
      printf("res%d = res%d;\n", node->ptr7, node->ptr2);
    if ( ( CATSEQ && !(RIGHT->n.info & NOINDEX) ) )
	iincr(RIGHT->index);

    if (!cteq(RIGHT->c.type, node->c.type)) {
      /* sws  code to make types conform to maxtype */
      printf(" /* gencat right type check */\n");
      printf("aplc_cktype(&res%d, i%d, ", node->ptr7, node->ptr1);
      ctgen(RIGHT->c.type);
      printf(");\n");
    }

    rbr();
    node->c.values = gicn(resptr, node->ptr7, rtype(node));

    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    if (!(node->n.info & SHAPEKNOWN)) {
#ifdef DEBUGFREE
      printf("/* -- cat finish */\n");
#endif
      mpfree(node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
  return;
}

/* end of catenate.c */






