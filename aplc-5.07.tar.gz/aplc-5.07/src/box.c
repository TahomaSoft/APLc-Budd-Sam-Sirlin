/*
	APL Compiler

	New box/unbox generation code
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include <stdio.h>
#include <string.h>
#include "parse.h"
#include "y_tab.h"
#include "gen.h"


/* genbox()
   box up the right argument, producing a scalar of nested type 
   right should be collected already 

    node->ptr1 = mp
    node->ptr2 = res
    node->ptr3 = result trs
*/
extern void 
genbox(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    printf("/* box shape */\n");
    settrs(node->ptr3, node);
    /* allocate space for the trs and value */
    printf("aplc_talloc(&trs%d);\n", node->ptr3);
    /* trs1.value.trsp[0] = &trs2;
    printf("trs%d.value.trsp[0] = ", node->ptr3);
    printf("&trs%d;\n", RIGHT->ptr3); */
    /* aplc_copytrs(&trs1.value.trsp[0], &trs2); */
    printf("aplc_copytrs(trs%d.value.trsp, &trs%d);\n",
	   node->ptr3, RIGHT->ptr3);

    node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));
    leafshape(node, node->ptr1);

    /*ctgen(RIGHT->c.values);*/

#if 0
    node->c.values = gcast(castop, gicn(icnst, 0, APLC_INT), rtype(node));
#endif
    printf("/* box shape end */\n");
    break;

  case COMBINE:
    break;

  case VALUE:
    /* ?? from rho 
       leafvalue(node, node->ptr2, APLC_INT, 0);*/
    leafvalue(node, node->ptr1, rtype(node), node->ptr2);
    break;

  case FINISH:
    /* need some work here... */
    switchbox(RIGHT, FINISH, 0);
#ifdef DEBUGFREE
    printf("/* -- box finish */\n");
#endif
    if ( !(node->n.info & ASSIGNP) ) {
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
    }
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;
  }
}

extern void 
genlink(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    filtrs(node->ptr1, LEFT);
    filtrs(node->ptr2, RIGHT);

    /* aplc_link(res, left, right); */
    printf("aplc_link(");
    printf("&trs%d, &trs%d, ", node->ptr3, node->ptr1);
    printf("&trs%d", node->ptr2);
    rpseminl();

    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);
    node->c.values = gtrs(node->ptr3, cvalfield, rtype(node));

    leafshape(node, node->ptr4);
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);

    /* deallocate the shapes of the trs's created 
     - this may need rethinking later ... */
    trs_shape_free(node->ptr1);
    trs_shape_free(node->ptr2);

    if ( !(node->n.info & ASSIGNP) )  {
      /* should free the trs for the result, except if the previous
	 node is assign, which will use the trs directly */
#ifdef DEBUGFREE
      printf("/* -- genlink finish */\n");
#endif
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

#if 0
extern void 
genunbox(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
  case SHAPE:
    switchbox(RIGHT, SHAPE, 0);
    break;

  case COMBINE:
    break;

  case VALUE:
    break;

  case FINISH:
    break;
  }
}
#endif

/* end */

