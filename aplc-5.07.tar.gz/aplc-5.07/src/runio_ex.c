/* runio_ex.c

 APL Compiler - Run Time System

 - execute routines
 - quad routines
 - string to number routines; conversion/validation

 Sam Sirlin

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

/* ------------------------------------------------------------ */
#include "aplc.h"
#include "run.h"

/* ------------------------------------------------------------ */
/* sws  for file io */
#include <stdio.h>
#include <stdlib.h>

/* for isdigit() */
#include <ctype.h>

#if HAVE_STRING_H
/* sws  for execute */
#include <string.h>
#endif

/* ------------------------------------------------------ */
/* ------------------------------------------------------ */

/* max size of a word that converted to a number by execute */
#define MAXWORD 64

/* make  execute \n, for jbw */
/* also used in runop.c */
/* #define WEB_MOD */

/* ------------------------------------------------------ */
/* ------------------------------------------------------ */
/* local declarations */
/*static int getnum(FILE * file);*/

static int is_ws(int c, int type);

/*static int sgetnum(char *string, int wstype);*/
static int sgetnum(char *string, int wstype, int onerr);

static int getword(char *word, char *string, int *i, int length, 
		   int wstype);

/* ------------------------------------------------------ */
/* some work space for passing number strings */
static char numstr[30];

/* ------------------------------------------------------ */
/* ------------------------------------------------------ */

#if 0
/*
 getnum - read in a single number from a file
          return its type

	  used: aplc_quad
*/

static int
getnum(FILE * file)
{
  int c, i, type;
  char *p;
  char neg[] = ".ng";

  p = numstr;
  c = fgetc(file);
#if 0
  while ((c == ' ') || (c == '\t') || (c == '\f')) {
    c = fgetc(file);
  }
#else
  while (is_ws(c,0))
    c = fgetc(file);
#endif
  /* check for leading negation */
  if ((c == '-') || (c == '_')) {
    *p++ = '-';
    c = fgetc(file);
  } else {
    i = 0;
    while ((i < 3) && (neg[i] == c)) {
      c = fgetc(file);
      i++;
    }
    if (i == 3)
      *p++ = '-';
  }

  if (c == EOF)
    aplc_error("[quad] unexpected end of file");
  if (c == '\n')
    return (APLC_UKTYPE);
  type = APLC_UKTYPE;
  for (; isdigit(c); c = fgetc(file)) {
    type = APLC_INT;
    *p++ = c;
  }
  if (c == '.') {
    type = APLC_REAL;
    *p++ = c;
    for (c = fgetc(file); isdigit(c); c = fgetc(file))
      *p++ = c;
  }
  if ((c == 'e') || (c == 'E')) {
    type = APLC_REAL;
    *p++ = c;
    c = fgetc(file);
    if ((c == '+') || (c == '-')) {
      *p++ = c;
      c = fgetc(file);
    } else if (c == '_') {
      *p++ = '-';
      c = fgetc(file);
    } else {
      i = 0;
      while ((i < 3) && (neg[i] == c)) {
	c = fgetc(file);
	i++;
      }
      if (i == 3)
	*p++ = '-';
    }

    for (; isdigit(c); c = fgetc(file))
      *p++ = c;
  }
  if (type != APLC_UKTYPE)
    ungetc(c, file);
  else
    fprintf(aplcerr, "\n[quad] unknown character in input : %c [%d]\n",
	c, c);
  *p = '\0';
  /* printf("\nnumstr %s\n", numstr); */
  return (type);
}
#endif

/* ------------------------------------------------------ */
/*
 sgetnum - read in a single number from a string
           return its type
           global numstr is built
 
input string
      wstype - white space types
      onerr - behavior on error
            0 ignore
            1 complain 




	   used from above:
	   static char numstr[30];

	   used: aplc_fi, aplc_vi
	         aplc_execute
*/

static int
sgetnum(char *string, int wstype, int onerr)
{
  int type;
  char *c, *p;
  char neg[] = ".ng";


  /* pass over leading whitespace */
  c = string;
  /* printf("\n got c= [%s]\n", c); */
  while (is_ws(*c, wstype)) {
    c++;
  }

  p = numstr;
  /* check for leading negation */
  if ((*c == '-') || (*c == '_')) {
    c++;
    *p++ = '-';
  } else if (0 == strncmp(c, neg, 3)) {
    c += 3;
    *p++ = '-';
  }
  /* end of string */
  if (*c == '\0')
    return (APLC_UKTYPE);
  type = APLC_UKTYPE;
  for (; isdigit(*c); c++) {
    type = APLC_INT;
    *p++ = *c;
  }
  if (*c == '.') {
    type = APLC_REAL;
    *p++ = *c;
    for (c++; isdigit(*c); c++)
      *p++ = *c;
  }
  if ((*c == 'e') || (*c == 'E')) {
    type = APLC_REAL;
    *p++ = *c;
    c++;
    if ((*c == '+') || (*c == '-')) {
      *p++ = *c;
      c++;
    } else if (*c == '_') {
      *p++ = '-';
      c++;
    } else if (0 == strncmp(c, neg, 3)) {
      *p++ = '-';
      c += 3;
    }
    for (; isdigit(*c); c++)
      *p++ = *c;
  }
  /* stop after all digits */ 
#ifdef WEB_MOD 
  if ((type == APLC_UKTYPE) || ((*c != '\0') && (*c != '\n'))) {
    if (onerr)
      fprintf(aplcerr, 
	      "\n[sgetnum] domain error, End Of String character %d[%c]\n",
	      *c,*c);
    return APLC_UKTYPE;
  }
#else
  /* check for normal end-of-string */
  if ((type == APLC_UKTYPE) || (*c != '\0')) {
    if (onerr)
      fprintf(aplcerr, "\n[sgetnum] domain error, character %d[%c]\n", 
	    *c,*c);
    return APLC_UKTYPE;
  }
#endif
  *p = '\0';
  return (type);
}

/* ------------------------------------------------------ */
/* ------------------------------------------------------ */
/*
   Get next word, keeping track of current position (i) in the input
   string. Return 1 if word found, 0 if nothing left

   specify wstype for is_ws(), to determine word separators

   used: aplc_fi, aplc_vi
         aplc_execute
*/
static int
getword(char *word, char *c, int *i, int length, int wstype)
{
  int iw;
  int len = 0;

  /* pass over leading blanks or tabs or newlines */
  while ( (*i < length) &&  is_ws(c[*i], wstype) ) {
    (*i)++;
  }
  if (*i < length) {
    /* now copy rest into word */
    while ((*i < length) && (! is_ws(c[*i], wstype)) ) {
      if (len > MAXWORD ) {
	/* word is too long */
	printf("[getword] word too long! > %d\n", MAXWORD);
	*word = '\0';
	printf("   so far have [%s]\n", word-len);
	aplc_error("[getword] word too long");
      }
      *word = c[*i];
      len++;
      (*i)++;
      word++;
    }
    iw = 1;
  } else
    iw = 0;
  /* add an end-of-string marker to the end */
  *word = '\0';
  return (iw);
}

/* ------------------------------------------------------ */
/* ------------------------------------------------------ */
/* this function is to characterize whitespace, 
   for word separation 

   input c: character
         type: ws category
   

   this declaration causes compiler warnings:
   static int is_ws(char c);
 */
static int
is_ws(int c, int type)
{
  switch(type) {
  default:
  case 0:
    /* for quad */
    if ( (c==' ') || 
	 (c=='\f') ||  (c=='\t') )
      return 1;
    break;
  case 1:
    /* for execute */
    if ( (c==' ') || 
	 (c=='\f') || (c=='\n') ||  (c=='\r') ||  (c=='\t') )
      return 1;
    break;
  case 2:
    /* for vi/fi */
    if ( (c==' ') || (c==',') || (c=='/') ||
	 (c=='\f') || (c=='\n') ||  (c=='\r') ||  (c=='\t') )
      return 1;
    break;
  }
  return 0;
}

/* ------------------------------------------------------ */
/* ------------------------------------------------------ */
/* quad - input quad */

/* new version
   - use qq first, so then we have the whole string
   - then we can resuse execute fns */
extern void
aplc_quad(FILE * file, struct trs_struct * trs)
{
  struct trs_struct qqtrs;

  /* prompt */
  fprintf(aplcout,".bx:\n");
  /* get input string */
  aplc_qquad(file, &qqtrs);
  /* parse via execute */
  aplc_execute(trs, &qqtrs);
  /* free qquad */
  aplc_detalloc(&qqtrs);
  return;
}

#if 0
/* old version - reads from file directly */
extern void
aplc_quad(FILE * file, struct trs_struct * trs)
{
  int i, c, ntype, type;

  fprintf(aplcout,".bx:\n");
  c = fgetc(file);
  if (c == '\'') {
    aplc_error("character input not implemented yet");
    return;
  }
  ungetc(c, file);
  /* use the rank as a counter */
  trs->rank = 0;
  /* allocate APLC_IBUFSIZE places, this should be fixed later */
  aplc_vectalloc(&trs->value, APLC_IBUFSIZE, APLC_REAL);
  type = APLC_INT;
  while ((ntype = getnum(file)) != APLC_UKTYPE)
    switch (ntype) {
    case APLC_INT:
      if (type == APLC_INT)
	trs->value.ip[trs->rank++] = atoi(numstr);
      else
	trs->value.rp[trs->rank++] = (double) atoi(numstr);
      break;
    case APLC_REAL:
      if (type == APLC_INT) {
	/* convert into real */
	for (i = trs->rank - 1; i >= 0; i--)
	  trs->value.rp[i] = trs->value.ip[i];
	trs->value.rp[trs->rank++] = atof(numstr);
	type = APLC_REAL;
      } else {
	trs->value.rp[trs->rank++] = atof(numstr);
      }
      /*- sws
	 printf(" number %s, %g", numstr, atof(numstr)); */
      break;
    }
  trs->type = type;
  if (trs->rank == 1) {
    trs->rank = 0;
    trs->shape = aplc_dsval(1);
  } else {
    trs->shape = aplc_dsval(trs->rank);
    trs->rank = 1;
  }
}
#endif

/* ------------------------------------------------------ */
/* ------------------------------------------------------ */

/*
   functions for monadic execute
   limited to conversion from characters to numbers
   recognize
   int     [".ng"_-]?[0-9]+
     dnum    [".ng"-_]?(([0-9]+"."[0-9]*)|([0-9]*"."[0-9]+))
     exp     [eE][+-_]?[0-9]+
   rnum    ({inum}{exp}|{dnum}|{dnum}{exp})

*/


/* ------------------------------------------------------ */
/* execute - only convert string to number for now */
extern void
aplc_execute(struct trs_struct * res, struct trs_struct * right)
{
  int i, ntype, type, length, rank;
  int count, rcount, nbuf, size;
  char *c;
  char word[MAXWORD];

  rank = right->rank;
  if (rank == 0)
    length = 1;
  else {
    /* non scalar */
    for (i = 0, length = 1; i < rank; i++) {
      length *= right->shape[i];
    }
  }
  /* printf("\n ex length %d\n", length );*/

  /* jbww UKC 96_01   */
  if (length == 0) {
    aplc_zilde(res);
    return;
  }
  c = right->value.cp;
  if (*c == '\'') {
    aplc_error("[execute] character input not implemented yet");
    return;
  }
  count = 0;
  size = 0;
  /* allocate APLC_IBUFSIZE places to start */
  aplc_vectalloc(&res->value, APLC_IBUFSIZE, APLC_REAL);
  nbuf = 1;
  type = APLC_INT;
  rcount = 0;
  ntype = APLC_INT;
  while ((rcount < length) && (getword(word, c, &rcount, length, 1))) {
    /* printf("\n exword [%s]\n", word );*/
    /* printf("\n exword [%d][%s]\n", size,word );*/
    /* also creates numstr */
    ntype = sgetnum(word, 0, 1);

    if (++count == APLC_IBUFSIZE) {
      count = 0;
      nbuf++;
      switch (type) {
      default:
	aplc_error("[execute] type error");
	break;

      case APLC_BOOL:
      case APLC_INT:
	aplc_vectrealloc(&res->value, APLC_IBUFSIZE * nbuf, APLC_INT);
	break;

      case APLC_REAL:
	aplc_vectrealloc(&res->value, APLC_IBUFSIZE * nbuf, APLC_REAL);
	break;
      }
    }
    switch (ntype) {
    default:
      aplc_error("[execute] type error");
      break;

    case APLC_BOOL:
    case APLC_INT:
      if (type == APLC_INT)
	res->value.ip[size++] = atoi(numstr);
      else
	res->value.rp[size++] = (double) atoi(numstr);
      break;
    case APLC_REAL:
      if (type == APLC_INT) {
	/* convert into real */
#if 1
	aplc_vectpromote(&res->value, APLC_IBUFSIZE * nbuf, 
			 APLC_INT, APLC_REAL);
#else
	aplc_vectrealloc(&res->value, APLC_IBUFSIZE * nbuf, APLC_REAL);
	for (i = size - 1; i >= 0; i--)
	  res->value.rp[i] = res->value.ip[i];
#endif
	res->value.rp[size++] = atof(numstr);
	type = APLC_REAL;
      } else {
	res->value.rp[size++] = atof(numstr);
      }
      /*- sws
	printf(" number %s, %g", numstr, atof(numstr)); */
      break;
    }
  }
  res->type = type;
  res->alloc_ind = APLC_ALLOC_VAL_F;
  if (size == 0) {
    aplc_detalloc(res);/* free anything there */
    aplc_zilde(res);
  } else {
    if (size == 1)
      res->rank = 0;
    else
      res->rank = 1;
    res->shape = aplc_dsval(size);
    res->alloc_ind |= APLC_ALLOC_SHAPE_F;
  }
  res->size = aplc_vsize(res->rank, res->shape);
  return;
}

/* ------------------------------------------------------ */
/* ------------------------------------------------------ */
/* string to number 
   conversion/validation
*/

/*
   functions for 
   conversion from characters to numbers

   recognize
   int     [".ng"_-]?[0-9]+
     dnum    [".ng"-_]?(([0-9]+"."[0-9]*)|([0-9]*"."[0-9]+))
     exp     [eE][+-_]?[0-9]+
   rnum    ({inum}{exp}|{dnum}|{dnum}{exp})


   allow commas (1,2,3) or tabs as whitespace delimiters

*/


/* ------------------------------------------------------ */
/* ------------------------------------------------------ */
/* fi - convert string to number
   based on old execute code

   sws
 */
extern void
aplc_fi(struct trs_struct * res, struct trs_struct * right)
{
  int i, ntype, type, length, rank;
  int count, rcount, nbuf, size;
  char *c;
  char word[MAXWORD];
  /*union mp_struct mptemp;*/

  rank = right->rank;
  if (rank == 0)
    length = 1;
  else {
    /* non scalar */
    for (i = 0, length = 1; i < rank; i++) {
      length *= right->shape[i];
    }
  }
  if (length == 0) {
    aplc_detalloc(res);/* free anything there */
    aplc_zilde(res);
    return;
  }
  c = right->value.cp;
  count = 0;
  size = 0;
  /* allocate APLC_IBUFSIZE places to start */
#if DEBUGFI >0
    printf("\n[aplc_fi] allocating space for %d reals\n",  APLC_IBUFSIZE);
#endif
  aplc_vectalloc(&res->value, APLC_IBUFSIZE, APLC_REAL);
  nbuf = 1;
  type = APLC_INT;
  rcount = 0;
  ntype = APLC_INT;
  while ((rcount < length) && (getword(word, c, &rcount, length, 2))) {
#if DEBUGFI >0
    /* printf("\n word [%s]\n", word );*/
    printf("\n s, c, word [%d %d][%s]\n", size,count, word );
#endif
    ntype = sgetnum(word, 1, 0);

    if (++count == APLC_IBUFSIZE) {
#if DEBUGFI >0
      printf("reallocation %d * %d, type %d\n",
             nbuf, APLC_IBUFSIZE, type);
#endif
      count = 0;
      nbuf++;
      switch (type) {
      default:
	fprintf(aplcerr, "type %d\n", type);
	aplc_error("[quad fi] type error 1");
	break;

      case APLC_BOOL:
      case APLC_INT:
	aplc_vectrealloc(&res->value, APLC_IBUFSIZE * nbuf, APLC_INT);
	break;

      case APLC_REAL:
	aplc_vectrealloc(&res->value, APLC_IBUFSIZE * nbuf, APLC_REAL);
	break;
      }
    }
#if DEBUGFI >0
    fprintf(aplcerr, "ntype %d, [%s]\n", ntype,word);
#endif
    switch (ntype) {
    default:
      /* fprintf(aplcerr, "type %d, [%s]\n", ntype,word);*/
      /* aplc_error("[quad fi] type error 2");*/
      if (type == APLC_INT)
	res->value.ip[size++] = 0;
      else
	res->value.rp[size++] = (double) 0;
      break;

    case APLC_BOOL:
    case APLC_INT:
      if (type == APLC_INT)
	res->value.ip[size++] = atoi(numstr);
      else
	res->value.rp[size++] = (double) atoi(numstr);
      break;
    case APLC_REAL:
      if (type == APLC_INT) {
	/* convert into real */
#if DEBUGFI >0
        printf("conversion to real at %d\n", size);
#endif
#if 1
	aplc_vectpromote(&res->value, APLC_IBUFSIZE * nbuf, 
			 APLC_INT, APLC_REAL);
#else
        /* save old stuff */
        mptemp.ip = res->value.ip;
	/* re allocate space */
	aplc_vectalloc(&res->value, APLC_IBUFSIZE * nbuf, APLC_REAL);
        /* copy */
	for (i = size - 1; i >= 0; i--)
	  res->value.rp[i] = (double) mptemp.ip[i];
        /* free */
        aplc_free(mptemp.ip); 
#endif
	res->value.rp[size++] = atof(numstr);
	type = APLC_REAL;
      } else {
	res->value.rp[size++] = atof(numstr);
      }
      /*- sws
	printf(" number %s, %g", numstr, atof(numstr)); */
      break;
    }
#if DEBUGFI >0
    switch(type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      printf("\nints so far:\n");
      for (i=0; i<size; i++)
        printf("[%d]", res->value.ip[i]);
      break;
      break;
    case APLC_REAL:
      printf("\nreals so far:\n");
      for (i=0; i<size; i++)
        printf("[%g]", res->value.rp[i]);
      break;
    }
#endif

  }
  res->type = type;
  res->alloc_ind = APLC_ALLOC_VAL_F;
  if (size == 0) {
    aplc_detalloc(res);/* free anything there */
    aplc_zilde(res);
  } else {
    if (size == 1)
      res->rank = 0;
    else
      res->rank = 1;
    res->shape = aplc_dsval(size);
    res->alloc_ind |= APLC_ALLOC_SHAPE_F;
  }
  res->size = aplc_vsize(res->rank, res->shape);
  return;
}

/* ------------------------------------------------------ */
/* vi - validate convertion of string to numbers
   based on vi

   sws
 */
extern void
aplc_vi(struct trs_struct * res, struct trs_struct * right)
{
  int i, ntype, type, length, rank;
  int count, rcount, nbuf, size;
  char *c;
  char word[MAXWORD];

  rank = right->rank;
  if (rank == 0)
    length = 1;
  else {
    /* non scalar */
    for (i = 0, length = 1; i < rank; i++) {
      length *= right->shape[i];
    }
  }
  if (length == 0) {
    aplc_zilde(res);
    return;
  }
  c = right->value.cp;
  count = 0;
  size = 0;
  /* allocate APLC_IBUFSIZE places to start */
  aplc_vectalloc(&res->value, APLC_IBUFSIZE, APLC_INT);
  nbuf = 1;
  type = APLC_INT;
  rcount = 0;
  ntype = APLC_INT;
  while ((rcount < length) && (getword(word, c, &rcount, length, 2))) {
    ntype = sgetnum(word, 1, 0);
    if (++count == APLC_IBUFSIZE) {
      count = 0;
      nbuf++;
      aplc_vectrealloc(&res->value, APLC_IBUFSIZE * nbuf, APLC_INT);
    }
    switch (ntype) {
    default:
      res->value.ip[size++] = 0;
      break;

    case APLC_BOOL:
    case APLC_INT:
    case APLC_REAL:
      res->value.ip[size++] = 1;
      break;
      break;
    }
  }
  res->type = APLC_INT;
  res->alloc_ind = APLC_ALLOC_VAL_F;
  if (size == 0) {
    aplc_detalloc(res);/* free anything there */
    aplc_zilde(res);
  } else {
    if (size == 1)
      res->rank = 0;
    else
      res->rank = 1;
    res->shape = aplc_dsval(size);
    res->alloc_ind |= APLC_ALLOC_SHAPE_F;
  }
  res->size = aplc_vsize(res->rank, res->shape);
  return;
}

/* ------------------------------------------------------ */
/* ------------------------------------------------------ */
/* end */
