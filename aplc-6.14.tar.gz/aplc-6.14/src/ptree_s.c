/*
	APL Compiler

	New parse tree functions 
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/
#include <stdio.h>
#include <string.h>

#include "parse.h"
#include "ptree.h"
#include "y_tab.h"
#include "aplparse.h"

/* externals from yacc */
extern void prog(struct headnode * head, struct statenode * code);
extern void yyerror(char *c);

static void list_search_fid( struct node *node);


#define PSDEBUG 1

/* for ptanon: */
/* max anon fn name length */
#define MAXANAME 256

/* number of anon fns created so far */
static int anon_count = 0;
/* add to name pointer to get start of number */
#define FNAME_NUM 9

/* store a set of {name, tree} pairs */
typedef struct anon_tree {
  char *name;
  struct node *tree;
  struct anon_tree *next;  
} anon_tree_t;  
static anon_tree_t *anon_tree = 0;
static anon_tree_t *anon_tree_current;

/* search nodes for a local fun or var name */
static void
list_search_fid( struct node *node)
{
  class_t cls;
  struct symnode *xs;
  struct symnode *xsn;

  /* look for a local fident */
  if (NILP == node)
    return;
#if PSDEBUG
  fprintf(stderr,"[list_search_fid] node %s\n",  prtoken(node->nodetype));
#endif
  switch(node->nodetype) {
  case IDENT:
    /* look in current symtab */
#if PSDEBUG
    fprintf(stderr," looking for %s\n",  node->namep);
#endif
    cls = idclass(node->namep, &xs);
    if (cls) {
#if PSDEBUG
      fprintf(stderr," in local (%d) ",prog_depth); print_sym(stderr, xs);
      fprintf(stderr,"\n");
      fprintf(stderr," depth (%d) ",xs->depth);
      fprintf(stderr,"\n");
#endif
      /* check for (local)&(not current depth) */
      if ( (xs->depth > 0) && (xs->depth < prog_depth) ) {
        /* found a local ident at a higher level */
        /* check to see if it already exists */
        if (xs->glbname) {
          /* already there -- just use it */
          node->namep = xs->glbname;
          /* mark this as a copy */ 
          xsn = add_sym(node->namep, lsymtab, NILCHAR, lsymtab, 
                        GLOCALCOPY, xs->s.type, xs->s.rank, 0);
        } else {
          /* - make a global name and add  */
          node->namep = fid_gen_global(node->namep);
          xsn = add_sym(node->namep, lsymtab, NILCHAR, lsymtab, 
                        GLOCAL, xs->s.type, xs->s.rank, 0);
          /* also add an alias at the original depth (1) */
          xs->glbname = name_strcpy(node->namep);
        }
      }
    }
    break;

  case FIDENT:
#if PSDEBUG
    fprintf(stderr," looking for %s\n",  node->namep);
#endif
    cls = idclass(node->namep, &xs);
    if (cls) {
#if PSDEBUG
      fprintf(stderr," in local (%d) ",prog_depth); print_sym(stderr, xs);
      fprintf(stderr,"\n");
      fprintf(stderr," depth (%d) ",xs->depth);
      fprintf(stderr,"\n");
#endif
      /* check for (local)&(not current depth) */
      if ( (xs->depth > 0) && (xs->depth < prog_depth) ) {
        /* found a local ident at a higher level */
        /* check to see if an alias already exists */
        if (xs->glbname) {
          /* use it */
          node->namep = xs->glbname;
          /* now add it (might be there already under new name) */
          xsn = add_sym(node->namep, lsymtab, NILCHAR, lsymtab, 
            GLFUNCTIONCOPY, xs->s.type, xs->s.rank, xs->s.oinfo);
        } else {
          /* - make a global name and add  */
          node->namep = fid_gen_global(node->namep);
          xsn = add_sym(node->namep, lsymtab, NILCHAR, lsymtab, 
                        GLFUNCTION, xs->s.type, xs->s.rank, xs->s.oinfo);
          /* also add an alias at the original depth (1) */
          xs->glbname = name_strcpy(node->namep);
        }
      }
    }
    break;
  default:
    break;
  }
  /* continue looking */
  list_search_fid(node->left);
  list_search_fid(node->right);
  list_search_fid(node->funleft);
  list_search_fid(node->funright);
  list_search_fid(node->axis);
  list_search_fid(node->store);
  return;
}

/* ptanon - create an anonymous function value node 

   - an assignment will be added
     _zeta .is child

   - expect some set of {_zeta,_alpha,_omega} will be 
     entered into the local symbol table
 */
struct node *
ptanon(struct node *child)
{
  struct node *x;
  struct node *x2;
  struct symnode *s;
  struct headnode *h;
  char fname[MAXANAME] = "aplc_anon000";/* anon fn name */
  char temp[4];
  int i, m;
  anon_tree_t *atemp;
  int funmode;

#if PSDEBUG
  fprintf(stderr,"[ptanon] current funname {%s}\n",funname);
#endif

  if (anon_tree) {
#if PSDEBUG
    /* print out current tree */
    fprintf(stderr,"current node:\n");
    prt_node_list(child);
    fprintf(stderr,"Anon fn list:\n");
    atemp = anon_tree;
    i = 0;
    while (atemp) {
      m = match_nodes(atemp->tree, child);
      fprintf(stderr,"[%d] %s match %d\n",i++, atemp->name, m);
      atemp = atemp->next;
    }
#endif
#if 1
    /* check to see if child is in our list */
    atemp = anon_tree;
    while (atemp) {
      if (match_nodes(atemp->tree, child)) {
        /* we have a match, point to that rather than making a new fn 
         - perform cleanup as prog.c first */
#if PSDEBUG
        fprintf(stderr,"[ptanon] done; using existing fn %s.\n", atemp->name);
#endif
        pop_symb_const();
        return ptfncon_name(atemp->name);
        break;
      }
      atemp = atemp->next;
    }
#endif
  }

  /* number the anonymous function 
     - use a static int count */
  /* sprintf( temp, "%3d", fnctop);*/
  sprintf( temp, "%3d", anon_count++);
  /* fprintf(stderr,"fn1 %s [%s]\n", fname,temp);*/
  for (i=0; i<3; i++) {
    /*fprintf(stderr,"> %d %c [%c]\n", i, fname[FNAME_NUM+i], temp[i]);*/
    if (temp[i] != ' ') {
      fname[FNAME_NUM+i] = temp[i];
    }
  }
  /* append the current f name -- ensure uniqueness even if we link
     with other aplc processed files */
  strncat(fname, funname,(size_t) (MAXANAME-12));
#if PSDEBUG
  fprintf(stderr," ptanon fn name %s\n", fname);
#endif

  /* add the name, tree to our list */
  if (!anon_tree) {
    /* initialize first */
    anon_tree_current = structalloc(anon_tree);
    anon_tree = anon_tree_current;
  } else {
    anon_tree_current->next = structalloc(anon_tree);
    anon_tree_current = anon_tree_current->next;
  }
  anon_tree_current->name = name_strcpy(fname);
  anon_tree_current->tree = copynode(child);
  anon_tree_current->next = 0;
#if PSDEBUG > 1
  fprintf(stderr," [ptanon] tree updated\n");
#endif

  /* register fname as a fn */
  /* first check for left arg */
  idclass("_alpha", &s);
#if PSDEBUG > 1
  fprintf(stderr," [ptanon] idclass(_alpha)+\n");
#endif
  if (s == NILSYM)
    h = newhead(fname, NILCHAR, "_omega");
  else
    h = newhead(fname, "_alpha", "_omega");
#if PSDEBUG > 1
  fprintf(stderr," [ptanon] newhead+\n");
#endif
  h->asvar = "_zeta";
  h->asvar = "_zeta";
  /* setup return var */
  x2 = pt2(ASSIGN, sysparm("_zeta"), child);
#if PSDEBUG > 1
  fprintf(stderr," [ptanon] added assign.\n");
#endif
  addicon(0);/* ensure 0 */
  addicon(1);/* ensure 1 */
#if PSDEBUG > 1
  fprintf(stderr," [ptanon] added constants.\n");
#endif

  funmode = get_funmode();
#if PSDEBUG 
  fprintf(stderr," [ptanon] prog_depth %d, funmode %d\n", 
          prog_depth, funmode);
#endif
  /* look for a local fident or ident if we're in an op or fn
     - watch for multi-layers */
  if (funmode > 1) 
    list_search_fid(x2);

  /* write out the program, this will go before the prog we're in */
  prog(h, newstate(NILCHAR, x2));

  /* now setup the return value -- pointer to the function we've
     created */
  x = ptfncon_name(fname);
#if PSDEBUG
  fprintf(stderr,"[ptanon] done with %s.\n", fname);
#endif
  return x;
}

/* return an fncon node pointing to fname */
struct node *
ptfncon_name(char *fname)
{
  struct node *x;

#if PSDEBUG
  fprintf(stderr,"[ptfncon_name] %s\n",fname);
#endif
  x = newnode(FNCON);
  x->n.type = APLC_FNP;
  x->n.rank = 0;
  x->n.shape = 1;
  x->n.size = 1;
  /* point to fn in symbol table */
  /* add name to anon fun list */
  x->n.values = addfncon(fname);
  /*x->namep = h->fname;*/
  x->namep = fnconsts[x->n.values];
  x->n.info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN |
		SHAPEKNOWN | VALUESKNOWN);
  return x;
}

/* add anonymous function 
   - make up a unique name 
   - not used
*/
extern int
addanoncon(struct node *child)
{
  struct node *x2;
  struct symnode *s;
  struct headnode *h;
  char fname[] = "aplc_anon000";/* anon fn name */
  char temp[4];
  int i;

#if PSDEBUG
  fprintf(stderr,"[addanoncon] \n");
#endif
  /* number the anonymous function 
     - use a static int count */
  /* sprintf( temp, "%3d", fnctop);*/
  sprintf( temp, "%3d", anon_count++);
  /* fprintf(stderr,"fn1 %s [%s]\n", fname,temp);*/
  for (i=0; i<3; i++) {
    /*fprintf(stderr,"> %d %c [%c]\n", i, fname[FNAME_NUM+i], temp[i]);*/
    if (temp[i] != ' ') {
      fname[FNAME_NUM+i] = temp[i];
    }
  }
#if PSDEBUG
  fprintf(stderr," anon fn name %s\n", fname);
#endif
  /* register fname as a fn */
  h = newhead(fname, "_alpha", "_omega");
  h->asvar = "_zeta";
  h->asvar = "_zeta";
  /* get info about name? setup assignment variable */
  idclass("_zeta", &s);
  x2 = pt2(ASSIGN, ptvar(s), child);
  addicon(0);/* ensure 0 */
  addicon(1);/* ensure 1 */

  /* write out the program, this will go before the prog we're in */
  prog(h, newstate(NILCHAR, x2));
  return addfncon(fname);
}


/* ptapplyfun - used for dyadic or monadic user fns  */
static int apply_count = 0;
struct node *
ptapplyfun(struct node *fun, struct node *child1, struct node *child2)
{
  struct node *x;
  /*char resname[] = "aplc_apply000";*//* result name */
  char resname[] = "aplc_apply";/* result name */
  /*  char temp[4];
      int i;*/
  /*#define RESNAME_NUM 10*/

#ifdef  BYREF
  /* sws   this version will pass idents by reference */
  if (child1 != NILP)
    x = pt2(APPLY, pt1(COLLECT, child1), pt1(COLLECT, child2));
  else
    x = pt2(APPLY, child1, pt1(COLLECT, child2));
#else
  /*- sws   this version will always loop to collect idents,
            pass by value */
  if (child1 != NILP)
    x = pt2(APPLY, pt1(CCOLLECT, child1), pt1(CCOLLECT, child2));
  else
    x = pt2(APPLY, child1, pt1(CCOLLECT, child2));
#endif
#if 0
  sprintf( temp, "%3d", apply_count);
  for (i=0; i<3; i++) {
    if (temp[i] != ' ') {
      resname[RESNAME_NUM+i] = temp[i];
    }
  }
#endif
  /*fprintf(stderr,"resname %s\n", resname);*/
  x->namep = name_strcpy(resname);
  x->namea = resname;/* will be set later, in access */
  /* put fnptr in store */
  x->store = fun;
  return (x);
}

static int cond_count = 0;
/* addition to pointer to get to number in vname */
#define VNAME_NUM 9

/* ptcond - conditional 
   create a variable condsxx for switch -- integer scalar
   create a variable condxx for output
   condsxx = store;
   if condsxx {
     condxx = left;
   } else {
     condxx = right;
  }
*/
struct node *
ptcond(int type, struct node *lt, struct node *st, struct node *rt)
{
  struct node *x;
  struct symnode *s = NILSYM;
  char vname[] = "aplc_condr000";/* result name */
  char sname[] = "aplc_conds000";/* switch name */
  char temp[4];
  int i;

  /*$$ = pt2s(COND,pt1(CCOLLECT,$1), pt1(CISCALAR,$3), pt1(CCOLLECT,$4));}*/
  /* get name */
  sprintf( temp, "%3d", cond_count++);
  for (i=0; i<3; i++) {
    if (temp[i] != ' ') {
      vname[VNAME_NUM+1+i] = temp[i];
      sname[VNAME_NUM+1+i] = temp[i];
    }
  }
#if PSDEBUG
  fprintf(stderr," cond var name %s\n", vname);
#endif
  /* register vname as a var 
     x = pt2(ASSIGN, 
     ptvar(enterid(left->namep, dclclass, APLC_UKTYPE, NORANK)), right);

     ptvar(enterid(vname, GLOBAL, APLC_UKTYPE, NORANK));*/

  x = pt2(type, lt,rt);
  /* add assignment */
  /*s = enterid(vname, GLOBAL, APLC_UKTYPE, NORANK);*/
  s = enterid(vname, get_lexscope(), APLC_UKTYPE, NORANK, NOVALENCE);
  x = pt2(type, 
	  pt2(ASSIGN, ptvar(s), lt), 
	  pt2(ASSIGN, ptvar(s), rt));
  /*s = enterid(sname, get_lexscope(), APLC_UKTYPE, NORANK, NOVALENCE);*/
  s = enterid(sname, get_lexscope(), APLC_INT, 0, NOVALENCE);
  /*x->store = pt1(CISCALAR,st);*/
  x->store = pt2(ASSIGN, ptvar(s), pt1(CISCALAR,st));
  x->namep = name_strcpy(vname);
  return x;
}

#if 0 
struct node *
ptcond_old(int type, struct node *lt, struct node *st, struct node *rt)
{
  struct node *x;
  struct symnode *s = NILSYM;
  char vname[] = "aplc_cond000";/* result name */
  char temp[4];
  int i;

  /*$$ = pt2s(COND,pt1(CCOLLECT,$1), pt1(CISCALAR,$3), pt1(CCOLLECT,$4));}*/
  /* get name */
  sprintf( temp, "%3d", cond_count++);
  for (i=0; i<3; i++) {
    if (temp[i] != ' ') {
      vname[VNAME_NUM+i] = temp[i];
    }
  }
#if PSDEBUG
  fprintf(stderr," cond var name %s\n", vname);
#endif
  /* register vname as a var 
     x = pt2(ASSIGN, 
     ptvar(enterid(left->namep, dclclass, APLC_UKTYPE, NORANK)), right);

     ptvar(enterid(vname, GLOBAL, APLC_UKTYPE, NORANK));*/

  x = pt2(type, lt,rt);
  /* add assignment */
  /*s = enterid(vname, GLOBAL, APLC_UKTYPE, NORANK);*/
  s = enterid(vname, get_lexscope(), APLC_UKTYPE, NORANK, NOVALENCE);
  x = pt2(type, 
	  pt2(ASSIGN, ptvar(s), lt), 
	  pt2(ASSIGN, ptvar(s), rt));
  x->store = pt1(CISCALAR,st);
  x->namep = name_strcpy(vname);
  return x;
}
#endif

/* ptstore - simple store child node */
struct node *
ptstore(int type)
{
  struct node *x;

  x = newnode(type);
  /* x->namep= NILCHAR; */
  return (x);
}

/* sws 
   put a format after a quadassign 
   - format is smarter about spacing; 
   --- can't do this for non-top as it leaves a char   */
struct node *
ptqass(struct node * child)
{
  struct node *x;
  /* box collect */
  if ( (child->nodetype == FORMAT) ||
       (child->nodetype == SCON)   ||
       (child->nodetype == FIDENT) ||
       (child->nodetype == COLLECT) )
    x = pt1(QUADASSIGN, child);/* no need */
  else
    x = pt1(QUADASSIGN, pt1(COLLECT,child));/* normal */
#if 0
  /* box format collect */
  if ( (child->nodetype == FORMAT) ||
       (child->nodetype == SCON) )
    x = pt1(QUADASSIGN, child);/* no need */
  else if (child->nodetype == COLLECT)
    x = pt1(QUADASSIGN, pt1(FORMAT,child));
  else
    x = pt1(QUADASSIGN, pt1(FORMAT,pt1(COLLECT,child)));/* normal */
#endif
#if 0
  /* old default, lasy evaluation printing */
  x = pt1(QUADASSIGN, child);
#endif
  return (x);
}

/* old default, lasy evaluation printing */
struct node *
ptqlzass(struct node * child)
{
  struct node *x;

  x = pt1(QUADASSIGN, child);
  return (x);
}

/* sws
   pttcav - scalar component of atomic vector
   based on pt1o - 1 child node with operator */
struct node *
pttcav(int type, enum sysvars var)
{
  struct node *x;

  x = newnode(type);
  x->optype = var;
  x->n.type = (int) APLC_CHAR;
  x->n.rank = 0;
  x->n.shape = 1;
  x->n.size = 1;
  switch(var) {
  default:
    yyerror("[pttcav] parse error");
    break;
  case TCBEL: 
    x->n.values = 7;
    break;
  case TCBS:  
    x->n.values = 8;
    break;
  case TCCR:  
    x->n.values = 13;
    break;
  case TCDEL: 
    x->n.values = 127;
    break;
  case TCESC: 
    x->n.values = 27;
    break;
  case TCFF:  
    x->n.values = 12;
    break;
  case TCHT:  
    x->n.values = 9;
    break;
  case TCLF:  
    x->n.values = 10;
    break;
  case TCNUL: 
    x->n.values = 0;
    break;
  }
  /* don't set valuesknown or adjdcls will barf */
  x->n.info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN | SHAPEKNOWN );
  return (x);
}

/* sws
   pttycon - type constant
   based on pttcav */
struct node *
pttycon(int type, int var)
{
  struct node *x;

  x = newnode(type);
  x->optype = var;
  x->n.type = (int) APLC_INT;
  x->n.rank = 0;
  x->n.shape = 1;
  x->n.size = 1;
  x->n.values = var;
  /* don't set valuesknown or adjdcls will barf */
  x->n.info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN | SHAPEKNOWN );
  return (x);
}

/* ptnillfun - functions
   used for nilladic user fns (sws) */
struct node *
ptnilfun(struct symnode * fun)
{
  struct node *x;

  x = pt2(FIDENT, NILP, NILP);
  x->namep = fun->name;
  x->namea = fun->name;
  x->n.type = fun->s.type;
  x->n.info = fun->s.info;
  x->n.oinfo = fun->s.oinfo;
  if ((fun->s.type != APLC_UKTYPE) && (fun->s.type != APLC_ANY))
    x->n.info |= (TYPEDECL | TYPEKNOWN);
  x->n.rank = fun->s.rank;
  if (fun->s.rank == ANYRANK) {
    x->n.info |= RANKKNOWN;
    x->n.rank = ANYRANK;
  } else if (fun->s.rank != NORANK)
    x->n.info |= (RANKDECL | RANKKNOWN);
  return (x);
}

/* newophead - make a new operator header node */
struct headnode *
newophead(char *parm1, 
	  char *lfname, char *name, char *rfname, 
	  char *parm2)
{
  struct headnode *x;
  struct symnode *h = NILSYM;

  x = structalloc(headnode);
  if (x == NILHEAD)
    yyerror("[newophead] out of space");
  if (name != NILCHAR) {
    h = enterid(name, OPERATOR, APLC_UKTYPE, NORANK, 
                get_fop_valence_comp(parm1, rfname));
    funname = h->name;/* setup current function name */
  }
#if PSDEBUG
  /* display information */
  fprintf(stderr,"[newophead] ");
  print_sym(stderr, h);
#endif
  x->opname = name;
  x->lfname = lfname;
  x->rfname = rfname;
  x->asvar = NILCHAR;
  x->parm1 = parm1;
  x->parm2 = parm2;
  /* derive valence */
  if (! (h->s.oinfo & O_OPTYPE) ) {
#if 0
    /* default is FOF */
    h = add_sym(name, gsymtab, NILCHAR, gsymtab, OPERATOR, 
                APLC_UKTYPE, NORANK, O_OPTYPE | O_LF | O_RF);
#else
    /* no def valence */
    h = add_sym(name, gsymtab, NILCHAR, gsymtab, OPERATOR, 
                APLC_UKTYPE, NORANK, 0);
#endif
#if PSDEBUG
    /* display information */
    fprintf(stderr,"[newophead] update ");
    print_sym(stderr, h);
#endif
  }
  if (lfname != NILCHAR) {
    if (h->s.oinfo & O_LF)
      enterid(lfname, LFUNCTION, APLC_ANY, ANYRANK,NOVALENCE);
    else
      enterid(lfname, PARAM, APLC_ANY, ANYRANK,NOVALENCE);
  }
  if (rfname != NILCHAR) {
    if (h->s.oinfo & O_RF)
      enterid(rfname, LFUNCTION, APLC_ANY, ANYRANK,NOVALENCE); 
    else
      enterid(rfname, PARAM, APLC_ANY, ANYRANK,NOVALENCE); 
  }
  if (parm1 != NILCHAR)
    enterid(parm1, PARAM, APLC_ANY, ANYRANK,NOVALENCE);
  if (parm2 != NILCHAR)
    enterid(parm2, PARAM, APLC_ANY, ANYRANK,NOVALENCE);
  return (x);
}

/* change from MSYSFUN to FIDENT, for operator */
symnode_t *
pt_msys2fn(enum sfuns op)
{
  symnode_t *x;

  x = structalloc(symnode);
  x->name = name_strcpy(str_msysfun(op));  
  x->class = FUNCTION;
  init_info(&(x->s));
  return x;
}

/* change from DSYSFUN to FIDENT, for operator */
symnode_t *
pt_dsys2fn(enum sfuns op)
{
  symnode_t *x;

  x = structalloc(symnode);
  x->name = name_strcpy(str_dsysfun(op));  
  x->class = FUNCTION;
  init_info(&(x->s));
  return x;
}

/* incorporate a symnode into a FIDENT node 
   for use in ptop */
struct node *
symnode2node(struct symnode *fun)
{
  struct node *x;

  if (fun != NILSYM) {
    x = newnode(FIDENT);
    x->namep = fun->name;  
    x->namea = fun->name;  
    x->n.type = fun->s.type;
    x->n.oinfo = fun->s.oinfo;
    x->symnode = fun;
    x->n.rank = fun->s.rank;
  } else
    x = NILP; 
  return x;
}

/* ptop - operator  
   left (leftfun op rightrun) right  */
struct node *
ptop(node_t *child1, node_t*lfun, 
     struct symnode *op, 
     node_t *rfun, struct node *child2,
     int valence)
{
  struct node *x;

#if 0
  /* sws   this version will pass idents by reference */
  if (child1 != NILP)
    x = pt2(FIDENT, pt1(COLLECT, child1), pt1(COLLECT, child2));
  else
    x = pt2(FIDENT, child1, pt1(COLLECT, child2));
#endif
  if (! op->name)
    yyerror("[ptop] missing op->name");
#if PSDEBUG
  if (lfun && lfun->namep) {
    if (rfun && rfun->namep)
      fprintf(stderr,"ptop: (%s %s %s) \n", lfun->namep,op->name,rfun->namep);
    else
      fprintf(stderr,"ptop: (%s %s) \n", lfun->namep,op->name);
  } else {
    if (rfun && rfun->namep)
      fprintf(stderr,"ptop: (%s %s) \n", op->name,rfun->namep);
    else
      fprintf(stderr,"ptop: (%s) \n", op->name);
  }
#endif

  x = newnode(OPIDENT);
  x->namep = op->name;
  x->namea = op->name;
  x->n.type = op->s.type;

#if PSDEBUG
  fprintf(stderr,"ptop: op->s.oinfo(%d), valence (%d) \n", op->s.oinfo, valence);
#endif
  x->n.oinfo = op->s.oinfo | valence;

  /* if lfun is a V, make sure it's put into a trs */ 
  if ( (lfun != NILP) && (!(x->n.oinfo & O_LF)) 
       &&(lfun->nodetype != CCOLLECT) ) 
    x->funleft =  pt1(CCOLLECT,lfun);
  else
    x->funleft = lfun;

  /* if rfun is a V, make sure it's put into a trs */ 
  if ( (rfun != NILP) && (!(x->n.oinfo & O_RF))  
       &&(rfun->nodetype != CCOLLECT) )
    x->funright =  pt1(CCOLLECT, rfun);
  else
    x->funright = rfun;
 
  /*- sws   this version will always loop to collect idents,
            pass by value */
  if (child1 != NILP)
    x->left = pt1(CCOLLECT, child1);
  if (child2 != NILP)
    x->right = pt1(CCOLLECT, child2);

  if ((op->s.type != APLC_UKTYPE) && (op->s.type != APLC_ANY))
    x->n.info |= (TYPEDECL | TYPEKNOWN);
  if (lfun) {
    x->n.rank = lfun->n.rank;
  }
  if (op->s.rank == ANYRANK) {
    x->n.info |= RANKKNOWN;
    x->n.rank = ANYRANK;
  } else if (op->s.rank != NORANK)
    x->n.info |= (RANKDECL | RANKKNOWN);
  return (x);
}

/* given a tree built for sub array list,
   convert for link */
struct node *
ptsmtolink(struct node *child)
{
  struct node *x;
  struct node *c;
  struct node *xt;

  x = newnode(LINK);
  x->right = pt1(COLLECT, child->right);
  xt = x;
  c = child;
  while (c->left != NULL) {
    fprintf(stderr,"[] c = %p, L %p, R %p\n", (void *)c, 
	    (void *)c->left, (void *)c->right);
    c = c->left;
    xt ->left = newnode(LINK);
    xt = xt->left;
    xt->right = pt1(COLLECT, c->right);
  }
  return x;
}

/* ------------------------ */
/* new fns for general objects */

/* general object
   one of 5 types
   (general, int)
   (scalar fun sfun)
   (system var/fun sysfun)
   (fident, fun)

   (other, term) doesn't need to be passed in here
 */
struct node *
ptgobj(int type, enum sfuns sfun, enum sysvars sysfun, symnode_t *fun)
{
  struct node *x;

#if PSDEBUG
  fprintf(stderr,"[ptgobj] %d,%d %d\n", type, sfun, sysfun);
#endif
  x = newnode(type);
  switch(type) {
  case REVERSE:
  case SLASH:
  case BSLASH:
  case SORT:
  case LCARET:
  case RCARET:
    /* store the axis */
    x->index = sfun;
    break;
  case MSFUN:
  case DSFUN:
    /* store the function */
    x->index = sfun;
    break;
  case BQT:
    /* store the bqt_state */
    x->index = sfun;
    break;
  case LCB:
  case RCB:
    x->index = cbracket_state;
    break;

  case DSYSFUN:
  case MSYSFUN:
  case ESYSFUN:
    /* store the system function */
    x->index = sysfun;
    break;
  case FIDENT:
  case OPIDENT:
    x->namep = fun->name;
    x->namea = fun->name;
    x->n.type = fun->s.type;
    x->n.oinfo = fun->s.oinfo;
    x->symnode = fun;
#if 0
    fprintf(stderr,"[ptgobj] (f/o)ident %s %s\n",x->namep,x->namea);
    print_info(stderr, &x->n);fprintf(stderr,"\n");
    print_info(stderr, &x->symnode->s);fprintf(stderr,"\n");
#endif
    break;
  }
  return x;
}

/* catenate right onto a list starting at node
   node->right->...  ->(new right)

   - special case of BQT `xxx` -> (anon fn)
     node->index is bqt state 
     node->right->BQT->...->BQT 
     reduce to
       node->right->fncon
   - special case of RCB {xxx} -> (anon fn)
     reduce to
       node->right->fncon
 */
struct node *
cat_gobj(struct node *node, struct node *right)
{
  struct node *x, *y, *expr;
  int i=0;

#if PSDEBUG
  fprintf(stderr,"[cat_gobj] (%d:%s)", node->nodetype,prtoken(node->nodetype));
#endif
  /* get to the end of the current list starting at node */
  x = node;
  while(x->right) {
#if PSDEBUG
    if (x->right->nodetype == BQT)
      fprintf(stderr,"(%d:%s:%d)", x->right->nodetype, prtoken(x->right->nodetype), x->right->index);
    else
      fprintf(stderr,"(%d:%s)", x->right->nodetype, prtoken(x->right->nodetype));
#endif
    x = x->right;
    i++;
  }

#if PSDEBUG
  if (right->nodetype == BQT)
    fprintf(stderr,"+ [%d], (%d:%s:%d)\n", 1+i, right->nodetype,
	    prtoken(right->nodetype), right->index);
  else
    fprintf(stderr,"+ [%d], (%d:%s)\n", 1+i, right->nodetype,
	    prtoken(right->nodetype));
#endif
  /* check for end of an anonymous fn `xxx` */ 
  if ( (right->nodetype == BQT) && (right->index == 0) ) {
    /* found the end - make the fn */
#if PSDEBUG
    fprintf(stderr,"[cat_gobj found end of anon defn]\n");
#endif

    /* go back to find the start */
    expr = x;
    while(expr->nodetype != BQT) {
      if (expr->left)
	expr = expr->left;
      else
	yyerror("[cat_gobj] parse error; can't find start of `");
    }
#if PSDEBUG
    fprintf(stderr,"[cat_gobj] found an anon defn\n");
#endif
    expr->right->left = 0;/* parse only starting at expr->right */
    setlocalcons();
    y = ptanon(parse_gobj(expr->right));
    /* replace expr with the new FNCON node */
    expr->nodetype = TERM;
    expr->axis = y;
    expr->right = 0;
    y->left = 0;
    /* stop there */
#if PSDEBUG
    fprintf(stderr,"[cat_gobj] done with anon defn\n");
#endif
    /*print_gobj(node);*/
    print_gobjlist(node);
#if PSDEBUG
    fprintf(stderr,"[cat_gobj] anon done.\n");
#endif
    return node;
  }

  /* check for end of curly bracket anon fn {} */
  if ( right->nodetype == RCB ) {
#if PSDEBUG
    fprintf(stderr,"[cat_gobj] found end of anon defn {}\n");
#endif
    /* find start -- matching LCB */
    /* go back to find the start */
    expr = x;
    while(expr->nodetype != LCB) {
      if (expr->left)
	expr = expr->left;
      else
	yyerror("[cat_gobj] parse error; can't find start of {}");
    }
#if PSDEBUG
    fprintf(stderr,"[cat_gobj] found an anon defn {}\n");
#endif
    /* build anon fn */
    expr->right->left = 0;/* parse only starting at expr->right */
    setlocalcons();
    y = ptanon(parse_gobj(expr->right));
    /* replace expr with the new FNCON node */
    expr->nodetype = TERM;
    expr->axis = y;
    expr->right = 0;
    y->left = 0;
    /* stop there */
#if PSDEBUG
    fprintf(stderr,"[cat_gobj] done with anon defn {}\n");
#endif
    /*print_gobj(node);*/
    print_gobjlist(node);
#if PSDEBUG
    fprintf(stderr,"[cat_gobj] anon {} done.\n");
#endif
    return node;
  }

  /* check for index: (term)(axiso)
     - this shold become an atomic term 
     - since the tight binding of term, axis is anomalous (neither fn or
       op behave quite this way
  */
  if (right->nodetype == AXISO) {
    if (x->nodetype == TERM) {
#if PSDEBUG
      fprintf(stderr,"[cat_gobj] found (term)[]\n");
#endif
      /* found (term)(axiso) 
         - want to replace x with (term (x,axiso)) 
         - real term contents will be in x->axis 
         - axis contents are also in right->axis */
      y = newnode(SUB);
      y->left = x->axis;
      y->right = right->axis;
      x->axis = y;
#if PSDEBUG
      fprintf(stderr,"[cat_gobj] term done.\n");
#endif
      return node;
      /* stop */      
    }
  }
 
  /* nominal new objects 
     - add the new object to the end */
#if PSDEBUG
  fprintf(stderr,"[cat_gobj] normal right.\n");
#endif
  x->right = right;
  /* add a backwards link as well */
  x->right->left = x;

  x = x->right;
  /* now expand AXISO nodes; these are really two, (F/O) V */  
  if (x->nodetype == AXISO) {
    x->right = newnode(TERM);
    x->right->axis = x->axis;
  }

#if PSDEBUG
  fprintf(stderr,"[cat_gobj] normal done.\n");
#endif
  return node;
}

/* end */

