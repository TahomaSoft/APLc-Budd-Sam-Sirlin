/*
	APL Compiler

	catch code generation
	Samuel W. Sirlin (sws)

	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

#include <stdio.h>

#include "parse.h"
#include "y_tab.h"
#include "gen.h"


void 
gencatch(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
  case SHAPE:
    adjdcls(node);

    printf("aplc_trap(1);\n");
    printf("if ( 0 == setjmp(aplc_env)) {\n");
    printf("/* catch left shape */\n");
    switchbox(LEFT, SHAPE, 1);
#if 0
    printf("/* catch left value */\n");
    switchbox(LEFT, VALUE, 1);
#endif
    printf("/* catch left finish */\n");
    switchbox(LEFT, FINISH, 1);
    printf("/* catch left end */\n");
    printf("\n} else {\n");
    printf("/* catch right */\n");
    switchbox(RIGHT, SHAPE, 1);
#if 0
    switchbox(RIGHT, VALUE, 1);
#endif
    switchbox(RIGHT, FINISH, 1);
    printf("/* catch right end */\n");
    printf("\n}\n");
    printf("aplc_trap(0);\n");
    break;

  case COMBINE:
    break;

  case VALUE:
    break;

  case FINISH:
    break;
  }
}

/* end */
