/* 
   aplc constant declarations
   sws  1/8/96
   2/21/2004 change #define name to avoid conflicts

   some externals to const.c 

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_CONST_H
#define _APLC_CONST_H

/* definition of a structure for constants */
typedef struct {
  int i_consts[MAXCONSTS];   /* integer constants */
  int ic_top;/* top of iconsts */
  double r_consts[MAXCONSTS];/* real constants */
  int rc_top;
  double z_consts[2][MAXCONSTS]; /* complex constants */
  int zc_top;
  double q_consts[4][MAXCONSTS]; /* quaternion constants */
  int qc_top;
  double o_consts[8][MAXCONSTS]; /* octonion constants */
  int oc_top;
  char s_consts[MAXCONSTS];      /* string constants */
  int sc_top;
  char *fn_consts[MAXCONSTS];    /* fn pointers - names */ 
  int fnc_top;
  struct label_struct l_consts[MAXCONSTS]; /* labels */
  int lc_top;
} const_t;

/* variables */
/* maximum symbol table depth -- allow for nested anon defn 
   - note this is only during parsing */
#define MAX_PROG_DEPTH 5
/*#define MAX_CONST_DEPTH 3
extern const_t pconsts[MAX_CONST_DEPTH];*/
extern const_t pconsts[MAX_PROG_DEPTH];
extern const_t *pconstsp;/* pointer to current */
extern int const_depth;

/* all needed information for a prog/oprog */
typedef struct {
  char *name;
  int type;
  struct headnode *heads;
  const_t pconsts;
  struct symnode *symtabs;
  struct statenode *code;
} prog_t;

/* all information for fns 
   - declared in aplparse.c or pass.c */
extern prog_t progs[MAX_PROG_DEPTH];  
extern int prog_depth; 

#define ICTOP(i) (progs[i].pconsts.ic_top)
#define RCTOP(i) (progs[i].pconsts.rc_top)

#define FNCTOP(i) (progs[i].pconsts.fnc_top)

#define ictop  pconstsp->ic_top
#define rctop  pconstsp->rc_top
#define zctop  pconstsp->zc_top
#define qctop  pconstsp->qc_top
#define octop  pconstsp->oc_top
#define sctop  pconstsp->sc_top
#define fnctop pconstsp->fnc_top
#define lctop  pconstsp->lc_top

#define iconsts  pconstsp->i_consts
#define rconsts  pconstsp->r_consts
#define zconsts  pconstsp->z_consts
#define qconsts  pconstsp->q_consts
#define oconsts  pconstsp->o_consts
#define sconsts  pconstsp->s_consts
#define fnconsts pconstsp->fn_consts
#define lconsts  pconstsp->l_consts

/* functions */
extern void init_constants(void);
#if FILE_LINE_DEBUG
#define setlocalcons()  setlocalcons_fn(__FILE__, __LINE__) 
#define resetconsts()   resetconsts_fn(__FILE__, __LINE__) 
#else
#define setlocalcons()  setlocalcons_fn("", 0) 
#define resetconsts()   resetconsts_fn("", 0) 
#endif
extern void setlocalcons_fn(char *file, int line);
extern void resetconsts_fn(char *file, int line);

extern int addicon(int i);
extern int addicon_scalar(int x);

extern int addrcon(double x);

extern int addzcon(double x[2]);
extern int addr2zcon(double x);

extern int addqcon(double x[4]);
extern int addz2qcon(double x[2]);
extern int addr2qcon(double x);

extern int addocon(double x[8]);
extern int addq2ocon(double x[4]);
extern int addz2ocon(double x[2]);
extern int addr2ocon(double x);

extern int addfncon(char *x);

extern int addlcon(char *x);
extern void lcon_clean(void);

extern struct node* ivec2rvec(struct node *ivec);
extern struct node* rvec2zvec(struct node *rvec);
extern struct node* zvec2qvec(struct node *zvec);
extern struct node *qvec2ovec(struct node *qvec);

extern void expanivec(struct node *ivec, double r);
extern void expanrvec(struct node *rvec, double z[2]);


#endif /* _APLC_CONST_H */
/* end of const.h */ 
