/*
	APL Compiler

	code generation for assignment and sub assignment

	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/
#include <stdio.h>

#include "parse.h"
#include "y_tab.h"
#include "gen.h"

/* debug printouts */
#define ASDEBUG 1


/* local functions */
static void genassign_ident(struct node * node, enum pmodes mode, int top);
/*static void genassign_early(struct node * node, enum pmodes mode, int top);*/

static void genassign_named(struct node * node, enum pmodes mode, int top);
static void genassign_late(struct node * node, enum pmodes mode, int top);

static void genassign_pre(struct node * node, enum pmodes mode, int top);

/* asntchk 
   - do assignment statement type checking 
   - used here and in collect.c

   gen: generate code or not
   dest: where to put stuff
   source: where it comes from 
   destype: destination type
   regval: register to put value
   mpval: mp for value
 */
extern int
asntchk(int gen, struct node *dest, struct node *source,
	int destype, int regval, int mpval)
{
  int stype;

  stype = rtype(source);
  if ( (destype != APLC_UKTYPE) &&
       (destype != APLC_BOXED) ) { 
    /* known, simple target type */
#if ASDEBUG
    printf(" /* asntchk (type known and simple) mkrktype */\n");
#endif
    mkrktype(source, destype, regval);
    if ( (destype == APLC_COMPLEX) ||
	 (destype == APLC_QUAT) ||
	 (destype == APLC_OCT) ) {
      /* can't use scalar code */
      regval = resinreg(source, regval);
      /* sws  watch out for scalars - right index then won't exist */
      if (is_scalar(source))
	printf("aplc_setmp(&res%d, &mp%d, 0, ", regval, mpval);
      else
	printf("aplc_setmp(&res%d, &mp%d, i%d, ", regval, mpval, dest->index);
      ctgen(dest->c.type);
      rpseminl();
      dest->c.values = gicn(resptr, regval, APLC_UKTYPE);
      return (regval);
    } else if (is_scalar(source))
      dest->c.values = gbin(coasgn,
			    gmon(deref, gicn(memptr, mpval, destype)),
			    source->c.values);
    else {
      dest->c.values = gbin(coasgn,
			    gmon(deref, 
				 gmon(postinc,
				      gicn(memptr, mpval, destype))),
			    source->c.values);
    }
    if (gen) {
      ctgen(dest->c.values);
      seminl();
    }
  } else if ( (stype != APLC_UKTYPE) && 
	      (stype != APLC_COMPLEX) &&
	      (stype != APLC_QUAT) &&
	      (stype != APLC_OCT) &&
	      (destype != APLC_BOXED) ) { 
#if 0
    /* target is unknown, but source is - shouldn't happen? 
       - happens in genassign_late, sequential, with trs,
         as left type is used there ... */
    fprintf(stderr,"[asntchk] types des %d, src %d\n",
	    destype, stype);
    error("[asntchk] type error");
#endif
#if ASDEBUG
    printf(" /* asntchk targ unk, source known? */\n");
#endif
    if (is_scalar(source))
      dest->c.values = gbin(coasgn,
		    gmon(deref, gicn(memptr, mpval, rtype(source))),
			    source->c.values);
    else
      dest->c.values = gbin(coasgn,
			    gmon(deref, gmon(postinc,
				     gicn(memptr, mpval, rtype(source)))),
			    source->c.values);
    if (gen) {
      ctgen(dest->c.values);
      seminl();
    }
  } else {
    /* don't know, and don't care, about type */
#if ASDEBUG
    printf(" /* asntchk types unknown or boxed */\n");
#endif
    regval = resinreg(source, regval);
    /* sws  watch out for scalars - right index then won't exist */
    if (is_scalar(source))
      printf("aplc_setmp(&res%d, &mp%d, 0, ", regval, mpval);
    else
      printf("aplc_setmp(&res%d, &mp%d, i%d, ", regval, mpval, dest->index);
    ctgen(dest->c.type);
    rpseminl();
    dest->c.values = gicn(resptr, regval, APLC_UKTYPE);
  }
  return (regval);
}

/* sasntchk - do assignment statement type checking

   sws version of asntchk, but for subassignment we have to be more
       careful here than in assignment, as the sub assignment might
       actually change the type of the variable (e.g. int->real)

       if the destination type (final type of the variable) is unknown,
       then we need a run-time check

       return regval, which might change */
int
sasntchk(int gen, struct node * dest, struct node * source,
    int destype, int regval, int mpval)
{
  if ( (destype != APLC_UKTYPE) && 
       (!isGcomplext(destype)) && isNotGcomplex(source) ) { 
    /* known target type */
    mkrktype(source, destype, regval);
    if (is_scalar(source))
      dest->c.values = gbin(coasgn,
			    gmon(deref, gicn(memptr, mpval, destype)),
			    source->c.values);
    else
      dest->c.values = gbin(coasgn,
			    gmon(deref, gmon(postinc,
					   gicn(memptr, mpval, destype))),
			    source->c.values);
    if (gen) {
      ctgen(dest->c.values);
      seminl();
    }
  } else {
    /* sws destination type is unknown - must check at run time even
       if source type is known. 
       don't know, BUT do care, about type */
    regval = resinreg(source, regval);
    printf(" /* sasntchk type check */\n");
    printf("aplc_cktype(&res%d, ", regval);
    ctgen(dest->c.type);
    printf(", ");
    ctgen(source->c.type);
    printf(");\n");
    /* sws     watch out for scalars - right index then won't exist */
    if (is_scalar(source))
      printf("aplc_setmp(&res%d, &mp%d, 0, ", regval, mpval);
    else
      printf("aplc_setmp(&res%d, &mp%d, i%d, ", regval, mpval,
	  dest->index);
    ctgen(dest->c.type);
    rpseminl();
    dest->c.values = gicn(resptr, regval, APLC_UKTYPE);
  }
  return (regval);
}

/* 
   return 1 if right trs3 should be just set into the name trs by assign
          0 else
*/
static int
asgn_pass_trs(struct node * node)
{
  int y;

  y = 0;
  switch ( RIGHT->nodetype ) {
    /* monadic cases */
  case BOX:
  case FIDENT:
  case OPIDENT:
  case EXECUTE:
  case FORMAT:
    y = 1;
    break;
  case MSYSFUN:
  case ESYSFUN:
  case DSYSFUN:
    switch( RIGHT->optype ) {
    case SYS_SYS:
    case SYS_FREAD:
    case SYS_CL:
    case SYS_FREE:
    case SYS_FI:
    case SYS_VI:
    case SYS_VTYPE:
      /* ambivalent or dyadic */
    case SYS_AZ:
    case SYS_ZA:
    case SYS_OP:
    case SYS_LSEEK:
    case SYS_FWRITE:
    case SYS_FAPPEND:
    case SYS_PIPE:
    case SYS_SPAWN:
    case SYS_FCNTL:
    case SYS_SS:

      y = 1;
      break;
    default:
      y = 0;
      break;
    }
    break;
    /* dyadic cases */
  case DFORMAT:
  case MSOLVE:
  case TAKE:
  case DROP:
  case LINK:
    y = 1;
    break;
  case ZCON:
  case QCON:
  case OCON:
    y = 1;
    break;

  default:
    y = 0;
    break;
  }
  return(y);
}


/* some defines for assign */

/*#define TYPESMATCH(a,b)  (cteq(a->c.type, b->c.type))*/
#define TYPESMATCH(a,b)  (node_types_match(a,b))

static int
node_types_match(struct node *n1, struct node * n2)
{
  int mat = 0;

  if (cteq(n1->c.type, n2->c.type))
    return 1;

  if ( (n1->n.info & TYPEKNOWN) &&
       (n2->n.info & TYPEKNOWN) )
    if (types_match(n1->n.type, n2->n.type))
      mat = 1;
  return mat;
}

/*  genassign - generate code for assignment statements
    - note that if this is a top node, then it will be called only for
      shape and finish modes
    - this is the entry point from switch */
void
genassign(struct node * node, enum pmodes mode, int top)
{
  struct symnode *sym;

#if ASDEBUG
  printf("/* genassign */\n");
#endif
  if (node->n.info & EARLYBIND) {
    /* in this case we assume the assignment has already been done, 
       so we just have an ident (leaf) here */
#if ASDEBUG
    printf("/* genassign EARLYBIND */\n");
#endif
    genassign_ident(node, mode, top);
  }  else if ( (RIGHT->n.info & ASSIGNP ) &&
	       (!(node->n.info & ASSNAMEREF))  &&
	       ( (RIGHT->nodetype == FIDENT) ||
		 (RIGHT->nodetype == OPIDENT) ||
		 (RIGHT->nodetype == LINK)    ||
		 (RIGHT->nodetype == TAKE)    ||
		 (RIGHT->nodetype == DROP) ) ) {
    /* these nodes will do the actual assignment */
#if ASDEBUG
    printf("/* calling genasgn_pre */\n");
#endif
    genassign_pre(node, mode, top);    
  } else {
#if ASDEBUG
    printf("/* lookup */\n");
#endif
    sym = lookup_sym(LEFT->namep);
    if (0 == sym) {
#if ASDEBUG
      fprintf(stderr,"[asgn] symbol %s not found in table - assuming global\n",
	      LEFT->namep );
      printf("/* calling genassign_late */\n");
#endif
      genassign_late(node, mode, top);
    } else {
#if ASDEBUG
      printf("/* assignment */\n");
#endif
#if 0
      fprintf(stderr,"assignment to name %s\n", LEFT->namep);
      print_info(stderr, &sym->s);
      fprintf(stderr, "\n");
#endif
      if ( (node->n.info & TYPEKNOWN) &&
	   RankIsKnown(node) &&
	   (node->n.info & SHAPEKNOWN) &&
	   (node->n.info & ASSNAMEOK) &&
	   (sym->s.info & TYPEKNOWN) && /* also check symtab */    
	   sRankIsKnown(sym) &&
	   (sym->s.info & SHAPEKNOWN) ) {
	/* for now, restrict types */
	switch(node->n.type) {
	case APLC_BOOL:
	case APLC_INT:
	case APLC_REAL:
	case APLC_CHAR:
	  genassign_named(node, mode, top);
	  break;
	default:
	  genassign_late(node, mode, top);
	  break;
	}
      } else
	genassign_late(node, mode, top);
    }
  }
#if ASDEBUG
  printf("/* genassign done */\n");
#endif
  return;
}

/* alternate genassign for early binding
   - to get here, we already did the assignment, so here we
   just return the existing name, like an ident (leaf)

   note that if this is a top node, then it will be called only for
   shape and finish modes

  ptr1 = memory pointer
  nu ptr2 = trs register pointer
  nu ptr3 = size of right hand side
  ptr4 = result register

*/
static void
genassign_ident(struct node * node, enum pmodes mode, int top)
{
  /*fprintf(stderr,"genassign_ident\n");*/
  switch (mode) {
  case SHAPE:
#if ASDEBUG
    printf("/* genassign_ident */\n");
#endif
    /*adjdcls(node); already done */

#if 0
    if (strcmp(LEFT->namep, lastvar)) {
      /* by remembering the name we prevent
	 two checks immediately adjacent */
      char emsg[50];

      lastvar = LEFT->namep;
      printf("if (%s%stype == APLC_UKTYPE) ",
	  lastvar, (is_pointer(lastvar) ? "->" : "."));
      /* prerror("undefined value used");*/
      sprintf(emsg, "undefined value (%s) used", lastvar);
      prerror(emsg);
    }
#endif
    if (!(node->n.info & TYPEKNOWN)) {
      node->c.type = gident(LEFT->namep, ctypefield, APLC_UKTYPE);
    }
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gident(LEFT->namep, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gident(LEFT->namep, cshapefield, APLC_UKTYPE);

    node->c.values = gident(LEFT->namep, cvalfield, rtype(node));

    /* only put it into a mp if we have to */
    if (rtype(node) == APLC_UKTYPE)
      leafshape(node, node->ptr1);
    else if ((node->n.info & SEQUENTIAL) && !is_scalar(node))
      leafshape(node, node->ptr1);
    /* otherwise might as well use given value */
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr1, rtype(node), node->ptr4);
    break;

  case FINISH:
    break;
  }
  return;
}



/* alternate genassign 

   - just put a collect in shape
   - move finish to shape as well

*/

/*
  -------------->currently not used<--------------

genassign - generate code for assignment statements

note that if this is a top node, then it will be called only for
shape and finish modes

  ptr1 = memory pointer
  ptr2 = trs register pointer
  ptr3 = size of right hand side
  ptr4 = result register

*/
#if 0
static void
genassign_early(struct node * node, enum pmodes mode, int top)
{
  struct codetree *savetree;

  switch (mode) {
  case SHAPE:
#if ASDEBUG
    printf("/* asgn_e shape */\n");
#endif
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    adjdcls(LEFT);/* this is to fix any type/anyrank problems in ident */
    /* note that now left->n.type doesn't work - need rtype */
    copychild(node, RIGHT, 1, 1, 1);
    /* make sure type of right matches type of left, if declared */
    if (!(node->n.info & TYPEKNOWN)) {
      if (LEFT->n.info & TYPEDECL) {
	testtype(node->c.type, rtype(LEFT));
      }
    }
    /* make sure rank of right matches type of left, if declared */
    if (!(node->n.info & RANKKNOWN)) {
      if (LEFT->n.info & RANKDECL)
	testrank(node->c.rank, LEFT->n.rank);
    }
    /* Now for values.
       if right is HAVEVALUE, then we could just use it's trs. This
       may not be ok for some things though:
         - types may not match
         - if they use the same mp, but later are changed
       so most are just collected anyway here. 
       */

#if ASDEBUG
    printf("/* asgn_e shape val */\n");
    printf("/* match %d, pass %d */\n", 
	   TYPESMATCH(node,RIGHT), asgn_pass_trs(node));
#endif
    if (  TYPESMATCH(node,RIGHT) && asgn_pass_trs(node) ) {
      /* sws 
	 in the FIDENT case, we can use the trs from the fident
	 directly. This isn't the case with all HAVEVALUE
	 (e.g. assign). */
      node->ptr2 = RIGHT->ptr3;
      /* if (top) */
      node->c.values = RIGHT->c.values;
      /* leafshape(node, node->ptr1);*/
#if ASDEBUG
      printf("/*[asgn_e] fn*/\n");
#endif
      /* copied from finish: */
      switchbox(RIGHT, FINISH, 0);
      /* free old values */
      printf("aplc_detalloc(%c%s);\n", 
	     (is_pointer(LEFT->namep) ? ' ' : '&'), LEFT->namep);
      printf("aplc_assign(%c%s, &trs%d);\n",
	     (is_pointer(LEFT->namep) ? ' ' : '&'), LEFT->namep, node->ptr2);

      break;
    }
    if (declscalar(LEFT)) {
      /* very special case, easy code. 
	 type, rank, and shape are known, so caller doesn't need code
	 for them - just build result code
	 */
      if (top) {
	switchbox(RIGHT, VALUE, 0);
	if ( !TYPESMATCH(LEFT, RIGHT) ) {
	  /* put right in res struct, fix type at runtime */
	  mkrktype(RIGHT, rtype(LEFT), node->ptr4);
	}
	/* type of right now matches */
	/* cast right values to left type */
	node->c.values = gbin(coasgn,
			      gmon(deref, 
				   gident(LEFT->namep, cvalfield, rtype(LEFT))),
			      gcast(castop, RIGHT->c.values, rtype(LEFT)));
	ctgen(node->c.values);
	seminl();
      } else {
	/* not top */
	node->c.values = gident(LEFT->namep, cvalfield, rtype(LEFT));
	switchbox(RIGHT, VALUE, 0);
	/* just use left name */
	if ( !TYPESMATCH(LEFT,RIGHT) ) {
	  /* put right in res struct, fix type at runtime */
	  mkrktype(RIGHT, rtype(LEFT), node->ptr4);
	}
	node->c.values = gbin(coasgn,
			      gmon(deref, gident(LEFT->namep, cvalfield, rtype(LEFT))),
			      gcast(castop, RIGHT->c.values, rtype(LEFT)));
      }
      /* no point in building a loop to collect values */
      switchbox(RIGHT, FINISH, 0);
      break;
    }
    /* right is not a known scalar */
    /* check for zilde right */
    if (is_zilde(RIGHT)) {
#if ASDEBUG
      printf("/* asgn_e shape zilde */\n");
#endif
      /* doesn't much matter what the value is */
      node->c.values = RIGHT->c.values;
      settrs(node->ptr2, node);/* need a trs */
      /* no point in building a loop to collect values */
      switchbox(RIGHT, FINISH, 0);
      /* free old values */
      printf("aplc_detalloc(%c%s);\n", 
	     (is_pointer(LEFT->namep) ? ' ' : '&'), LEFT->namep);
      printf("aplc_assign(%c%s, &trs%d);\n",
	     (is_pointer(LEFT->namep) ? ' ' : '&'), LEFT->namep, node->ptr2);
      /* quit now */
      break;
    }
    /* one of
       ! node type known 
       ( node type known and right type known) and 
       node type == right type  

       ? same as 
       node type == right type  
       */

   /* general case - need to build a loop to collect right */
    savetree = looprank;
    looprank = node->c.rank;
    settrs(node->ptr2, node);
    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gtrs(node->ptr2, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gtrs(node->ptr2, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gtrs(node->ptr2, cshapefield, APLC_UKTYPE);
    ieq(node->ptr3);
    printf("aplc_talloc(&trs%d);\n", node->ptr2);
    if (RIGHT->n.info & HAVEVALUE) {
      node->c.values = gtrs(node->ptr2, cvalfield, rtype(node));
      leafshape(node, node->ptr1);
    } else {
      node->c.values = gtrs(node->ptr2, cvalfield, rtype(node));
      leafshape(node, node->ptr1);
    }
    colloop(RIGHT, RIGHT->index, node->ptr3);
    switchbox(RIGHT, VALUE, 0);
    node->ptr4 = asntchk(1, node, RIGHT, rtype(node),
			 node->ptr4, node->ptr1);
    rbr();
    /* restore old looprank */
    looprank = savetree;

    /* put this before the possible mp assignment below */
#if ASDEBUG
    printf("/*[asgn_e] fin*/\n");
#endif
    /* copied from finish: */
    switchbox(RIGHT, FINISH, 0);
    /* free old values */
    printf("aplc_detalloc(%c%s);\n", 
	(is_pointer(LEFT->namep) ? ' ' : '&'), LEFT->namep);
    printf("aplc_assign(%c%s, &trs%d);\n",
	(is_pointer(LEFT->namep) ? ' ' : '&'), LEFT->namep, node->ptr2);

    if (!top) {
      /* now setup for value phase */
#if ASDEBUG
      printf("/*[asgn_e] shape lp val*/\n");
#endif
      /* copied from genident */
      node->c.values = gident(LEFT->namep, cvalfield, rtype(node));
      /* only put it into a mp if we have to */
      if (rtype(node) == APLC_UKTYPE)
	leafshape(node, node->ptr1);
      else if ((node->n.info & SEQUENTIAL) && !is_scalar(node))
	leafshape(node, node->ptr1);
      /* otherwise might as well use given value */
    }
    break;

  case COMBINE:
    break;

  case VALUE:
#if ASDEBUG
    printf("/*[asgn_e] val*/\n");
#endif
    if (declscalar(LEFT)) {
#if ASDEBUG
      printf("/* [asgn_e decls] */\n");
#endif
      /* leave as is */
      break;
    }
    if (is_zilde(RIGHT)) {
      /* node->c.values = gtrs(node->ptr2, cvalfield, rtype(node));*/
      node->c.values = gmon(deref, 
			    gident(LEFT->namep, cvalfield, rtype(node)) );
      break;
    }
    /* all other cases - use name */ 
    /* node->c.values = gident(LEFT->namep, cvalfield, rtype(node));*/
    /* can't use name, as this will be incremented - use mp */
    /* leafshape(node, node->ptr1);*/
    leafvalue(node, node->ptr1, rtype(node), node->ptr4);
#if 0
    if (node->n.info & SEQUENTIAL)
      node->c.values = gmon(deref,
			    gmon(postinc, node->c.values));
    else
      node->c.values = gmon(deref,
			    gsfun(APLC_PLUS, node->c.values,
				 gicn(coiptr, node->index, 0)));0 should be a type
#endif
#if 0
    if (  asgn_pass_trs(node) && TYPESMATCH(node,RIGHT)  ) {
      switchbox(RIGHT, VALUE, 0);
      node->c.values = RIGHT->c.values;
    } else {
      /* like genident: */
      printf("/*[asgn/lv]*/\n");
      leafvalue(node, node->ptr1, rtype(node), node->ptr4);
    }
#endif
    break;

  case FINISH:
    break;
  }
}
#endif

/* end of alternate assign*/


/*
  genassign_named - generate code for assignment statements

  this version uses the name directly, instead of a temp copy, assuming 
  - type, rank, shape are known 
  - matches right
  - we don't want to pass a trs from right

  note that if this is a top node, then it will be called only for
  shape and finish modes

  ptr1 = memory pointer
  ptr2 = trs register pointer
  ptr4 = result register

*/
static void
genassign_named(struct node * node, enum pmodes mode, int top)
{
  struct codetree *savetree;

  switch (mode) {
  case SHAPE:
#if ASDEBUG
    printf("/* asgn_named shape */\n");
#endif
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    adjdcls(LEFT);/* this is to fix any type/anyrank problems in ident */
    copychild(node, RIGHT, 1, 1, 1);

    /* Now for values.
       if right is HAVEVALUE, then we could just use it's trs. This
       may not be ok for some things though:
       - types may not match
       - if they use the same mp, but later are changed
       so most are just collected anyway here.        */

#if ASDEBUG
    printf("/* asgn_named shape val */\n");
#if 1
    printf("/* typesmatch(node, RIGHT) %d, asgn_pass_trs(node) %d */\n", 
	   TYPESMATCH(node,RIGHT), asgn_pass_trs(node));
    printf("/");printf("* type(node) "); 
    ctgen(node->c.type);
    printf("; type(right) "); 
    ctgen(RIGHT->c.type);
    printf("*/\n"); 
#endif
#endif /* ASDEBUG */
    /* if left (name) was declared a scalar, of known type, then it
       doesn't need a trs 
       - this is now also ok for singleton */
    if ( declscalar(LEFT) || (1==ksize(node)) ) {
#if ASDEBUG
      printf("/* asgn_named shape val scalar or singleton */\n");
#endif
      /* cast right values to left type */
      switchbox(RIGHT, VALUE, 0);
      if ( !TYPESMATCH(LEFT,RIGHT) ) {
	/* put right in res struct, fix type at runtime */
	mkrktype(RIGHT, rtype(LEFT), node->ptr4);
      }
      /* type of right now matches */

      /* special case for zcon, qcon? */

      /* 11/1/03 new code */
      /* need to distinguish between 
	 local . and 
	 arguments (parms) -> */ 
      printf("%s%svalue.%s[0] = ", 
	     LEFT->namep, 
	     (is_pointer(LEFT->namep) ? "->" : "."),
	     mp_type_str(rtype(LEFT)) );
      ctgen( gcast(castop, RIGHT->c.values, rtype(LEFT)) );
      seminl();

      if (!top) {
	/* not top */
	node->c.values = gident(LEFT->namep, cvalfield, rtype(LEFT));
      }
      /* no point in building a loop to collect values */
      break;
    } /* end of scalar case */
    /* check for zilde right */
    if (is_zilde(RIGHT)) {
#if ASDEBUG
      printf("/* asgn_named shape zilde */\n");
#endif
      /* doesn't much matter what the value is */
      node->c.values = RIGHT->c.values;
      settrs(node->ptr2, node);/* need a trs */
      node->c.values = gmon(deref, 
			    gident(LEFT->namep, cvalfield, rtype(node)) );
      /* no point in building a loop to collect values */
      break;
    }
    
    /* not a scalar or singleton or zilde; need a loop */ 
    savetree = looprank;
    looprank = node->c.rank;

    if (!top) {
      node->c.values = gident(LEFT->namep, cvalfield, rtype(node));
      if ((node->n.info & SEQUENTIAL) && !is_scalar(node))
	leafshape(node, node->ptr1);
    }
    if (top || !(node->n.info & SEQUENTIAL)) {
      /*colloop(RIGHT, RIGHT->index, node->ptr3);*/
      printf("for (i%d = 0; i%d < %d; i%d++) {\n", 
	     RIGHT->index, RIGHT->index, ksize(node), RIGHT->index);

      switchbox(RIGHT, VALUE, 0);
      /* do the assignment */
      /*      node->ptr4 = asntchk(1, node, RIGHT, rtype(node),
	      node->ptr4, node->ptr1);*/
      printf("%s%svalue.%s[i%d] = ",
	     LEFT->namep, (is_pointer(LEFT->namep) ? "->" : "."),
	     mp_type_str(node->n.type), RIGHT->index);
      ctgen(RIGHT->c.values); seminl();
      rbr();
    }
    looprank = savetree;
    break;

  case COMBINE:
    break;

  case VALUE:
    /* must be not top to get here 
     in sequential case we still need to do the assignment */
#if ASDEBUG
    printf("/* asgn_named value */\n");
#endif
    if (declscalar(LEFT)) {
      leafvalue(node, node->ptr1, rtype(node), node->ptr4);
      break;
    }
    if (is_zilde(RIGHT)) {
      /* don't much care here, as no value to use! */
      break;
    }
    if (node->n.info & SEQUENTIAL) {
#if ASDEBUG
      printf("/* asgn_named value sequential */\n");
#endif
      switchbox(RIGHT, VALUE, 0);
      /*node->ptr4 = asntchk(0, node, RIGHT, rtype(LEFT), 
	node->ptr4, node->ptr1);*/
      node->c.values = gbin(coasgn, 
			    gbin( coindex,
				  gident(LEFT->namep, cvalfield, rtype(LEFT)),
				  gicn( coiptr, node->index, APLC_INT) ),
			    RIGHT->c.values);
			     
    } else {
      leafvalue(node, node->ptr1, rtype(node), node->ptr4);
    }
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
#if ASDEBUG
    printf("/* asgn_named fin */\n");
#endif
    break;
  }
}
/* end of assign_named */


/* old version - does actual assignment only at the end */
/*
  genassign - generate code for assignment statements

  note that if this is a top node, then it will be called only for
  shape and finish modes

  ptr1 = memory pointer
  ptr2 = trs register pointer
  ptr3 = size of right hand side
  ptr4 = result register

*/
static void
genassign_late(struct node * node, enum pmodes mode, int top)
{
  struct codetree *savetree;
  struct symnode *sym;

  switch (mode) {
  case SHAPE:
#if ASDEBUG
    printf("/* asgn shape */\n");
#endif
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    adjdcls(LEFT);/* this is to fix any type/anyrank problems in ident */
    /* note that now left->n.type doesn't work - need rtype */
    copychild(node, RIGHT, 1, 1, 1);
    if (!(node->n.info & TYPEKNOWN)) {
      if (LEFT->n.info & TYPEDECL) {
	testtype(node->c.type, rtype(LEFT));
      }
    }

    /* Now for values.
       if right is HAVEVALUE, then we could just use it's trs. This
       may not be ok for some things though:
       - types may not match
       - if they use the same mp, but later are changed
       so most are just collected anyway here. 

       */

    /* lookup name in symbol table - may need class */
    sym = lookup_sym(LEFT->namep);
      

#if ASDEBUG
    printf("/* asgn shape val */\n");
#if 0
    printf("/* declared scalar %d */\n", declscalar(LEFT));
#endif
#if 1
    printf("/* typesmatch(node, RIGHT) %d, asgn_pass_trs(node) %d */\n", 
	   TYPESMATCH(node,RIGHT), asgn_pass_trs(node));
    /* putting comment string together can mess up highlighting */
    printf("/");printf("* type(node) ");
    ctgen(node->c.type);
    printf("; type(right) "); 
    ctgen(RIGHT->c.type);
    printf("*/\n"); 
#endif
    {
      if (sym)
	printf("/* name %s, class %s */\n", 
	       LEFT->namep, str_class(sym->class));
      else
	printf("/* name %s, unknown class */\n", LEFT->namep);
    }
#endif /* ASDEBUG */
    if (  TYPESMATCH(node,RIGHT) && asgn_pass_trs(node) )
      /*if (  TYPESMATCH(node,RIGHT) && asgn_pass_trs(node) 
	&& (sym && (sym->class != PARAM)) ) */
      {
      /* sws 
	 in the FIDENT case, we can use the trs from the fident
	 directly. This isn't the case with all HAVEVALUE
	 (e.g. assign). 	 
      Also need to be careful of code that tries to set PARAMs 
      - these can't be freed */
#if ASDEBUG
      printf("/* asgn shape val rtrs */\n");
#endif
      node->ptr2 = RIGHT->ptr3;
      node->c.values = RIGHT->c.values;
      break;
    }
    /* if left (name) was declared a scalar, of known type, then it
       doesn't need a trs */
    if (declscalar(LEFT)) {
#if ASDEBUG
      printf("/* asgn shape val scalar */\n");
#endif
      /* cast right values to left type */
      switchbox(RIGHT, VALUE, 0);
      if ( !TYPESMATCH(LEFT,RIGHT) ) {
	/* put right in res struct, fix type at runtime */
	mkrktype(RIGHT, rtype(LEFT), node->ptr4);
      }
      /* type of right now matches */

      /* special case for zcon, qcon? */

#if 1
      /* 11/1/03 new code */
      printf("%s%svalue.%s[0] = ", 
	     LEFT->namep, 
	     (is_pointer(LEFT->namep) ? "->" : "."),
	     mp_type_str(rtype(LEFT)) );
      ctgen( gcast(castop, RIGHT->c.values, rtype(LEFT)) );
      seminl();
#else
      /* need to distinguish between local . and arguments (parms) -> */
      printf("%s%sscalar.%s = ", 
	     LEFT->namep, 
	     (is_pointer(LEFT->namep) ? "->" : "."),
	     res_type_str(rtype(LEFT)) );
      ctgen( gcast(castop, RIGHT->c.values, rtype(LEFT)) );
      seminl();
#endif
      if (!top) {
	/* not top */
	node->c.values = gident(LEFT->namep, cvalfield, rtype(LEFT));
      }
      /* no point in building a loop to collect values */
      break;
    } /* end of scalar case */
    /* check for zilde right */
    if (is_zilde(RIGHT)) {
#if ASDEBUG
      printf("/* asgn shape zilde */\n");
#endif
      /* doesn't much matter what the value is */
      node->c.values = RIGHT->c.values;
      settrs(node->ptr2, node);/* need a trs */
      node->c.values = gmon(deref, 
			    gident(LEFT->namep, cvalfield, rtype(node)) );
      /* no point in building a loop to collect values */
      break;
    }
    /* one of
       ! node type known 
       ( node type known and right type known) and 
       node type == right type  

       ? same as 
       node type == right type  
       */
    savetree = looprank;
    looprank = node->c.rank;

    /* make things simpler if we know we have a scalar */
    if (is_scalar(node)) {
      printf("aplc_settrs(&trs%d, ", node->ptr2);
      ctgen(node->c.type);
      printf(", 0, aplc_ivone);\n");
    } else
      settrs(node->ptr2, node);

    if (!(node->n.info & TYPEKNOWN))
      node->c.type = gtrs(node->ptr2, ctypefield, APLC_UKTYPE);
    if (!(node->n.info & RANKKNOWN))
      node->c.rank = gtrs(node->ptr2, crankfield, APLC_UKTYPE);
    if (!(node->n.info & SHAPEKNOWN))
      node->c.shape = gtrs(node->ptr2, cshapefield, APLC_UKTYPE);

    ieq(node->ptr3);
    printf("aplc_talloc(&trs%d);\n", node->ptr2);
    if (RIGHT->n.info & HAVEVALUE) {
      /* node->c.values = RIGHT->c.values;       */
      node->c.values = gtrs(node->ptr2, cvalfield, rtype(node));
      leafshape(node, node->ptr1);
    } else {
      node->c.values = gtrs(node->ptr2, cvalfield, rtype(node));
      leafshape(node, node->ptr1);
    }
    if (top || !(node->n.info & SEQUENTIAL)) {
      colloop(RIGHT, RIGHT->index, node->ptr3);
      switchbox(RIGHT, VALUE, 0);
      node->ptr4 = asntchk(1, node, RIGHT, rtype(node),
			   node->ptr4, node->ptr1);
      rbr();
      /* now setup for value phase */
      if (!(node->n.info & SEQUENTIAL)) {
	if (RIGHT->n.info & HAVEVALUE) {
	  /*
	    node->c.values = RIGHT->c.values;
	    leafshape(node, node->ptr1);
	    */
	  node->c.values = gtrs(node->ptr2, cvalfield, rtype(node));
	  leafshape(node, node->ptr1);
	} else {
	  node->c.values = gtrs(node->ptr2, cvalfield, rtype(node));
	  /*
	    leafshape(node, node->ptr1);
	    */
	}
      }
    }
    looprank = savetree;
    break;

  case COMBINE:
    break;

  case VALUE:
    /* must be not top to get here */
#if ASDEBUG
    printf("/* asgn value */\n");
#endif
    if (  TYPESMATCH(node,RIGHT) && asgn_pass_trs(node) ) {
      switchbox(RIGHT, VALUE, 0);
      node->c.values = RIGHT->c.values;
      break;
    }
    if (declscalar(LEFT)) {
      leafvalue(node, node->ptr1, rtype(node), node->ptr4);
      break;
    }
    if (is_zilde(RIGHT)) {
      /* don't much care here, as no value to use! */
      break;
    }
    if (node->n.info & SEQUENTIAL) {
#if ASDEBUG
      printf("/* asgn value sequential */\n");
#endif
      switchbox(RIGHT, VALUE, 0);
      node->ptr4 = asntchk(0, node, RIGHT, rtype(LEFT), 
			   node->ptr4, node->ptr1);
    } else {
      leafvalue(node, node->ptr1, rtype(node), node->ptr4);
    }
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
#if ASDEBUG
    printf("/* asgn fin */\n");
#endif
    if (  TYPESMATCH(node,RIGHT) && asgn_pass_trs(node) ) {
      /* free old values */
      printf("aplc_detalloc(%c%s);\n", 
	     (is_pointer(LEFT->namep) ? ' ' : '&'), LEFT->namep);
      if ( (RIGHT->nodetype == FIDENT) ||
	   (RIGHT->nodetype == OPIDENT) ) 
	printf("aplc_assign(%c%s, &%s);\n",
	       (is_pointer(LEFT->namep) ? ' ' : '&'), LEFT->namep, RIGHT->namea);
      else
	printf("aplc_assign(%c%s, &trs%d);\n",
	       (is_pointer(LEFT->namep) ? ' ' : '&'), LEFT->namep, node->ptr2);
      break;
    }
    if (declscalar(LEFT)) {
      /* use existing res_struct/trs, don't free/assign */
      break;
    }
    /* free old values */
    printf("aplc_detalloc(%c%s);\n", 
	   (is_pointer(LEFT->namep) ? ' ' : '&'), LEFT->namep);
    printf("aplc_assign(%c%s, &trs%d);\n",
	   (is_pointer(LEFT->namep) ? ' ' : '&'), LEFT->namep, node->ptr2);
    break;
  }
}
/* end of old assign */


/*
  genassign_pre - assume assign already done, e.g. by fn node to the
                  right

  note that if this is a top node, then it will be called only for
  shape and finish modes

  ptr1 = memory pointer
  ptr2 = trs register pointer
  ptr3 = size of right hand side
  ptr4 = result register

*/
static void
genassign_pre(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
  case SHAPE:
#if ASDEBUG
    printf("/* asgn_pre shape */\n");
#endif
    adjdcls(node);

#if ASDEBUG
    printf("/* asgn_pre fin */\n");
#endif
    adjdcls(LEFT);/* this is to fix any type/anyrank problems in ident */
    /* first free anything */
    /* free old values 
       - don't do this here; 
       it should be handled locally for efficiency 
       ...
    */ 
    printf("aplc_detalloc(%c%s);\n", 
	   (is_pointer(LEFT->namep) ? ' ' : '&'), LEFT->namep);

    switchbox(RIGHT, SHAPE, 0);
    /* note that now left->n.type doesn't work - need rtype */
    copychild(node, RIGHT, 1, 1, 1);
    if (!(node->n.info & TYPEKNOWN)) {
      if (LEFT->n.info & TYPEDECL) {
	testtype(node->c.type, rtype(LEFT));
      }
    }

#if ASDEBUG
    printf("/* asgn_pre shape val */\n");
#endif /* ASDEBUG */
    /*switchbox(RIGHT, VALUE, 0);*/

    if (!top) {
      /* not top */
      node->c.values = gident(LEFT->namep, cvalfield, rtype(LEFT));
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    /* must be not top to get here */
#if ASDEBUG
    fprintf(stderr,"asgn_pre value\n");
    printf("/* asgn_pre value */\n");
#endif
    switchbox(RIGHT, VALUE, 0);
    node->c.values = RIGHT->c.values;
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    break;
  }
}


/* 
   subassign options

I. existing

  o if left and right types are known and equal, 
  - don't need store, 
  - just collect right into axis of left

  o general case:
  - use STORE to collect LEFT at maxtype(LEFT, RIGHT)
  - then copy right into axis of store

  o non top
  - use axis for index, read from either left or store

II. 

o assume we can only do 

*/

/* old subassign */
#if 0
/*
  gensubassign - generate code for subscripted assignment statements
  sws  new function

  a[i] <- x
  LEFT[ AXIS ] <- RIGHT

   SUBASSIGN
    LEFT   subid
    RIGHT  expression
    AXIS   sublist (SM)
    STORE  SM


  o if left and right types are known and equal, 
  - don't need store, 
  - just collect right into axis of left

  o general case:
  - use STORE to collect LEFT at maxtype(LEFT, RIGHT)
  - then copy right into axis of store

  note that if this is a top node, then it will be called only for
  shape and finish modes


         stuff to store left at maxtype
	ptr1 = memory pointer
	ptr2 = trs register pointer
	ptr3 = size of left hand side
	ptr4 = result register, left, store
	ptr5 = type
	ptr6 = result register, right, store
	ptr7 = memory pointer, for collection
	ptr8 = size of right hand side

      not needed(?; still in resource):

	store->index  offset'
	left->index   offset'  (from sub)

	node->index   offset
	axis->index   offset   (from sub)
	right->index  offset   (from assign)


*/
void
gensubassign(struct node * node, enum pmodes mode, int top)
{
  struct codetree *savetree;

  switch (mode) {
  case SHAPE:

    adjdcls(node);
    adjdcls(STORE);
    switchbox(RIGHT, SHAPE, 0);
    switchbox(LEFT, SHAPE, 0);

    AXIS->axis = LEFT;	     /* from sub */
    switchbox(AXIS, SHAPE, 1);	     /* not sure why we need top here */

    /* check ranks of right vs axis */
    if ( (!(RIGHT->n.info & RANKKNOWN)) || 
	 (!(RIGHT->n.info & SHAPEKNOWN)) ) {
      /* need run time check */
      /* only check if right is not a singleton */
      getsize(node->ptr8, RIGHT);
      printf("if ( 1 != i%d ) {\n", node->ptr8);
      iflp();
      ctgen(RIGHT->c.rank);
      printf(" != 0) {\n");
      iflp();
      if (AXIS->n.info & RANKKNOWN)
	printf("%d ", rankvalue(AXIS));
      else
	ctgen(AXIS->c.rank);
      printf(" != ");
      ctgen(RIGHT->c.rank);
      printf(") ");
      prerror("[sub assignment] runtime rank error 2");
      printf("}\n");
      printf("}\n");
    } else {
      /* let scalar right through */
      /* let singleton right through */
      if ( !is_singleton(RIGHT) ) {
	/* note we check non-singleton shapes */
	if ( (AXIS->n.info & RANKKNOWN) && (AXIS->n.info & SHAPEKNOWN) ) {
	  if ( check_nsrank(&(RIGHT->n), &(AXIS->n)) ) {
	    print_rkshape(stderr, "axis", &(AXIS->n));
	    print_rkshape(stderr, "right", &(RIGHT->n));
	    error(" [sub assignment] rank error 1");
	  }
	} else
	  testrank(AXIS->c.rank, rankvalue(RIGHT));
      }
    }

    /* should probably test for shapes as well ... */

    if ( (LEFT->n.info & TYPEKNOWN) && (RIGHT->n.info & TYPEKNOWN) 
	 && (rtype(LEFT) == rtype(RIGHT)) ) {
      /* don't need store, more efficient code */

      /* get memory pointer to left */
      leafshape(LEFT, node->ptr1);

      /* loop to put RIGHT in part of LEFT */
      /* offset/offset' loop, put temp stuff in final register */
      /* generate offset, for RIGHT (AXIS) */
      savetree = looprank;
      looprank = RIGHT->c.rank;
      getsize(node->ptr8, AXIS);
      colloop(AXIS, AXIS->index, node->ptr8);

      /* from gensub */
      /* generate offset', for LEFT */
      switchbox(AXIS, VALUE, 1);
      ieqtree(LEFT->index, AXIS->c.values);

      switchbox(RIGHT, VALUE, 0);
      node->ptr6 = resinreg(RIGHT, node->ptr6);

      /* aplc_setmp(res, mp, i, type) */
      printf("aplc_setmp(&res%d, &mp%d, i%d, ",
	     node->ptr6, node->ptr1, LEFT->index);
      ctgen(LEFT->c.type);
      printf(");\n");

      rbr();
      looprank = savetree;
      /*
	end of sub assignment loops in special case
	LEFT updated
	*/

      /* now build node for right values, in case we need to pass them on
       (non top node)
       take this more-or-less from assign/shape
       */
      if (!top) {
	/* get type from right */
	copychild(node, RIGHT, 1, 0, 0);
	/* this only works for non scalar right */
	/*      copychild(node, RIGHT, 0, 1, 1);*/
	/* get rank, shape from index expression */ 
	copychild(node, AXIS, 0, 1, 1);
	node->c.values = gident(LEFT->namep, cvalfield, rtype(LEFT));
      }

    } else {
      /* general case, need to build store */

      /* first copy rank and shape information (not type) */
      copychild(STORE, LEFT, 0, 1, 1);
      /* define the result type (maxtype) and put correct type in store.
        from axis (CAT)	*/
      if (!(STORE->n.info & TYPEKNOWN)) {
	/* dsfunt(APLC_NOT, STORE, LEFT, RIGHT, node->ptr5);*/
	mergetype(STORE, LEFT, RIGHT, node->ptr5);
      } else {
	ieq(node->ptr5);
	ctgen(STORE->c.type);
	seminl();
      }
      /* make a trs to collect LEFT values at maxtype in STORE */

#if 0
      /* use existing trs if from a function ?
        need to fix this...
	doesn't seem useful.
	*/
      if (RIGHT->nodetype == FIDENT) {
	node->ptr2 = RIGHT->ptr3;
	break;
      }
#endif

      /* make trs to collect LEFT values at maxtype */
      settrs(node->ptr2, STORE);

      /* build loop to collect left into store, adjusting type */
      savetree = looprank;
      looprank = STORE->c.rank;
      if (!(STORE->n.info & TYPEKNOWN))
	STORE->c.type = gtrs(node->ptr2, ctypefield, APLC_UKTYPE);
      if (!(STORE->n.info & RANKKNOWN))
	STORE->c.rank = gtrs(node->ptr2, crankfield, APLC_UKTYPE);
      if (!(STORE->n.info & SHAPEKNOWN))
	STORE->c.shape = gtrs(node->ptr2, cshapefield, APLC_UKTYPE);

      /* size of left */
      ieq(node->ptr3); 
      printf("aplc_talloc(&trs%d);\n", node->ptr2);
      STORE->c.values =	gtrs(node->ptr2, cvalfield, rtype(STORE));
      leafshape(STORE, node->ptr1);

      /* set up memory pointer for collection - loop may change it */
      mpeqmp(node->ptr7, node->ptr1);

      /* put LEFT in STORE */
      /* offset loop, put left stuff in temp register with correct type */
      STORE->index = LEFT->index;
      colloop(LEFT, LEFT->index, node->ptr3);
      switchbox(LEFT, VALUE, 0);
      /* do the actual value set, carefully checking types */ 
      node->ptr4 = sasntchk(1, STORE, LEFT, rtype(STORE),
			    node->ptr4, node->ptr7);
      rbr();
      looprank = savetree;

      /* if top node, or we need to collect right values
	 ...
	 changed this to always get the values in a, since
	 we can't use asnchk for sub assignment, ... 
	 maybe we can fix this

	if (top || ! (node->n.info & SEQUENTIAL)) {
	*/

      /* build loop to collect right values into store */
      savetree = looprank;
      looprank = RIGHT->c.rank;

      /* put RIGHT in part of STORE */
      /* offset/offset' loop, put temp stuff in final register */
      /* generate offset, for RIGHT (AXIS) */

      getsize(node->ptr8, AXIS);
      colloop(AXIS, AXIS->index, node->ptr8);

      /* from gensub */
      /* generate offset', for LEFT */
      switchbox(AXIS, VALUE, 1);
      ieqtree(LEFT->index, AXIS->c.values);

      switchbox(RIGHT, VALUE, 0);
      node->ptr6 = resinreg(RIGHT, node->ptr6);

      /* check types if neccessary */
      if ((!(STORE->n.info & TYPEKNOWN)) ||
	  (!(RIGHT->n.info & TYPEKNOWN)) ||
	  (rtype(STORE) != rtype(RIGHT))) {
	printf(" /* gensubassign type check */\n");
	printf("aplc_cktype(&res%d, ", node->ptr6);
	ctgen(STORE->c.type);
	printf(", ");
	ctgen(RIGHT->c.type);
	printf(");\n");
      }
      /* aplc_setmp(res, mp, i, type) */
      printf("aplc_setmp(&res%d, &mp%d, i%d, ",
	     node->ptr6, node->ptr1, LEFT->index);
      ctgen(STORE->c.type);
      printf(");\n");
      rbr();
      looprank = savetree;
      /* end of sub assignment loops
	 STORE built and updated */

      /* now build node for right values, in case we need to pass them on
	 (non top node)
	 take this more-or-less from assign/shape
       */
      if (!top) {
	/* get type from store */
	copychild(node, STORE, 1, 0, 0);
	/* this only works for non scalar right */
	/*      copychild(node, RIGHT, 0, 1, 1);*/
	/* get rank, shape from index expression */ 
	copychild(node, AXIS, 0, 1, 1);
	node->c.values = gtrs(node->ptr2, cvalfield, rtype(node));
      }
    }
    break;

  case COMBINE:
    break;

  case VALUE:

    /*  this may need more debugging, but looks good so far...
	o get index from axis
	o index into node, either left or store
     */

    /* from assign - is this ok here? */
    /*	if (RIGHT->nodetype == FIDENT) {
	    switchbox(RIGHT, VALUE, 0);
	    node->c.values = RIGHT->c.values;
	}
	else...
	*/

    /* mostly shouldn't need this as it's done above 
       switchbox(AXIS, VALUE, 1);*/
    printf("/* code type  of right: */\n");
    coptype(AXIS->c.values->cop);
    printf("/* code: \n");
    ctgen(AXIS->c.values);
    printf(" */\n");
    if ( !(LEFT->n.info & TYPEKNOWN) ) {
      /* need to get index explicitly here */ 
      fprintf(stderr,"here\n");
      /*switchbox(AXIS, VALUE, 1);*/
    } else
      fprintf(stderr,"not here\n");

    /* from gensub, modified to read from STORE */
    ieqtree(LEFT->index, AXIS->c.values);

    /* aplc_mp2res(res, mp, i, type) */
    printf("aplc_mp2res(&res%d, &mp%d, i%d, ",
	   node->ptr4, node->ptr1, LEFT->index);
    ctgen(node->c.type);
    rpseminl();
    node->c.values = gicn(resptr, node->ptr4, rtype(node));
    break;

  case FINISH:
    switchbox(AXIS, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    if ( (LEFT->n.info & TYPEKNOWN) && (RIGHT->n.info & TYPEKNOWN) 
	 && (rtype(LEFT) == rtype(RIGHT)) ) {
      /* don't need anything here */
    } else {
      /* free old values */
      printf("aplc_detalloc(%c%s);\n", 
	     (is_pointer(LEFT->namep) ? ' ' : '&'),
	     LEFT->namep);
      /* now assign store trs to name */
      printf("aplc_assign(%c%s, &trs%d);\n",
	     (is_pointer(LEFT->namep) ? ' ' : '&'),
	     LEFT->namep, node->ptr2);
    }
    break;
  }
}
/* end of old subassign */


#else
/* new subassign

   - result is just right

 */


/*
  gensubassign - generate code for subscripted assignment statements
  sws  new function

  a[i] <- x
  LEFT[ AXIS ] <- RIGHT

   SUBASSIGN
    LEFT   subid
    RIGHT  expression
    AXIS   sublist (SM)
    STORE  SM


  o if left and right types are known and equal, 
  - don't need store, 
  - just collect right into axis of left

  o general case:
  - use STORE to collect LEFT at maxtype(LEFT, RIGHT)
  - then copy right into axis of store

  note that if this is a top node, then it will be called only for
  shape and finish modes


         stuff to store left at maxtype
	ptr1 = memory pointer
	ptr2 = trs register pointer
	ptr3 = size of left hand side
	ptr4 = result register, left, store
	ptr5 = type
	ptr6 = result register, right, store
	ptr7 = memory pointer, for collection
	ptr8 = size of right hand side

new:
	ptr9 = memory pointer
	ptr10 = trs register pointer


      not needed(?; still in resource):

	store->index  offset'
	left->index   offset'  (from sub)

	node->index   offset
	axis->index   offset   (from sub)
	right->index  offset   (from assign)


*/
void
gensubassign(struct node * node, enum pmodes mode, int top)
{
  struct codetree *savetree;

  switch (mode) {
  case SHAPE:

    adjdcls(node);
    adjdcls(STORE);
    switchbox(RIGHT, SHAPE, 0);
    switchbox(LEFT, SHAPE, 0);
    if (!top) {
      /* get all from right */
      copychild(node, RIGHT, 1, 1, 1);
      node->c.values = RIGHT->c.values;
    }

    AXIS->axis = LEFT;	     /* from sub */
    switchbox(AXIS, SHAPE, 1);	     /* not sure why we need top here */

    /* check ranks of right vs axis */
    if ( (!(RIGHT->n.info & RANKKNOWN)) || 
	 (!(RIGHT->n.info & SHAPEKNOWN)) ) {
      /* need run time check */
      /* only check if right is not a singleton */
      getsize(node->ptr8, RIGHT);
      printf("if ( 1 != i%d ) {\n", node->ptr8);
      iflp();
      printf(" 1 != aplc_suba_check(");
      if (AXIS->n.info & RANKKNOWN)
	printf("%d ", rankvalue(AXIS));
      else
	ctgen(AXIS->c.rank);
      commasp();
      ctgen(AXIS->c.shape); commasp();
      ctgen(RIGHT->c.rank); commasp();
      ctgen(RIGHT->c.shape); rp();rpnl();
      prerror("[sub assignment] runtime rank error 2");
      printf("}\n");

#if 0
      /* only check if right is not a singleton */
      getsize(node->ptr8, RIGHT);
      printf("if ( 1 != i%d ) {\n", node->ptr8);
      iflp();
      ctgen(RIGHT->c.rank);
      printf(" != 0) {\n");
      iflp();
      if (AXIS->n.info & RANKKNOWN)
	printf("%d ", rankvalue(AXIS));
      else
	ctgen(AXIS->c.rank);
      printf(" != ");
      ctgen(RIGHT->c.rank);
      printf(") ");
      prerror("[sub assignment] runtime rank error 2");
      printf("}\n");
      printf("}\n");
#endif
    } else {
      /* let scalar right through 
      if (rankvalue(RIGHT) != 0) {*/
      /* let singleton right through */
      if ( !is_singleton(RIGHT) ) {
	if ( (AXIS->n.info & RANKKNOWN) && (AXIS->n.info & SHAPEKNOWN) ) {
	  if ( check_nsrank(&(RIGHT->n), &(AXIS->n)) ) {
	    fprintf(stderr,"rank missmatch; left %d, right %d\n", 
		    rankvalue(AXIS), rankvalue(RIGHT) );
	    print_rkshape(stderr, "axis", &(AXIS->n));
	    print_rkshape(stderr, "right", &(RIGHT->n));
	    error(" [sub assignment] rank error 1");
	  }
	} else
	  testrank(AXIS->c.rank, rankvalue(RIGHT));
      }
    }

    /* should probably test for shapes as well ... */

    /* now collect values */
    if ( (LEFT->n.info & TYPEKNOWN) && (RIGHT->n.info & TYPEKNOWN) 
	 && (rtype(LEFT) == rtype(RIGHT)) ) {
      /* don't need store, more efficient code */
      printf("/* gensubassign; special case */\n");
      /* get memory pointer to left */
      leafshape(LEFT, node->ptr1);

      if (!top) {
	/* *get memory pointer to node */
	/* *make trs to collect right values */
	settrs(node->ptr10, node);
	printf("aplc_talloc(&trs%d);\n", node->ptr10);
	node->c.values = gtrs(node->ptr10, cvalfield, rtype(node));
	leafshape(node, node->ptr9);
      }
      /* loop to put RIGHT in part of LEFT */
      /* offset/offset' loop, put temp stuff in final register */
      /* generate offset, for RIGHT (AXIS) */
      savetree = looprank;
      looprank = RIGHT->c.rank;
      getsize(node->ptr8, AXIS);
      /* * */
      /* if axis is a scalar but right is not
       colloop will not initialize the index, 
       but right will possibly use it */
      if ( is_scalar(AXIS) && !  is_scalar(RIGHT) )
	setizero(AXIS->index);
      colloop(AXIS, AXIS->index, node->ptr8);

      /* from gensub */
      /* generate offset', for LEFT */
      switchbox(AXIS, VALUE, 1);
      ieqtree(LEFT->index, AXIS->c.values);

      switchbox(RIGHT, VALUE, 0);
      node->ptr6 = resinreg(RIGHT, node->ptr6);

      /* aplc_setmp(res, mp, i, type) */
      printf("aplc_setmp(&res%d, &mp%d, i%d, ",
	     node->ptr6, node->ptr1, LEFT->index);
      ctgen(LEFT->c.type);
      printf(");\n");

      if (!top) {
	/* *aplc_setmp(res, mp, i, type) */
	printf("aplc_setmp(&res%d, &mp%d, ",
	       node->ptr6, node->ptr9);
	printf("\n(");
	singleton(node);
	printf(" ? 0: i%d ),\n", node->index);
	ctgen(node->c.type);
	printf(");\n");
	/* * */
	/* iincr(node->index);*/
      }

      rbr();
      looprank = savetree;
      /*
	end of sub assignment loops in special case
	LEFT updated
	*/

    } else {
      /* general case, need to build store, possibly changing type */

      /* first copy rank and shape information (not type) */
      copychild(STORE, LEFT, 0, 1, 1);
      /* define the result type (maxtype) and put correct type in store.
        from axis (CAT)	*/
      if (!(STORE->n.info & TYPEKNOWN)) {
	/* dsfunt(APLC_NOT, STORE, LEFT, RIGHT, node->ptr5);*/
	mergetype(STORE, LEFT, RIGHT, node->ptr5);
      } else {
	ieq(node->ptr5);
	ctgen(STORE->c.type);
	seminl();
      }
      /* make a trs to collect LEFT values at maxtype in STORE */

#if 0
      /* use existing trs if from a function ?
        need to fix this...
	doesn't seem useful.
	*/
      if (RIGHT->nodetype == FIDENT) {
	node->ptr2 = RIGHT->ptr3;
	break;
      }
#endif

      /* make trs to collect LEFT values at maxtype */
      settrs(node->ptr2, STORE);

      /* build loop to collect left into store, adjusting type */
      savetree = looprank;
      looprank = STORE->c.rank;
      if (!(STORE->n.info & TYPEKNOWN))
	STORE->c.type = gtrs(node->ptr2, ctypefield, APLC_UKTYPE);
      if (!(STORE->n.info & RANKKNOWN))
	STORE->c.rank = gtrs(node->ptr2, crankfield, APLC_UKTYPE);
      if (!(STORE->n.info & SHAPEKNOWN))
	STORE->c.shape = gtrs(node->ptr2, cshapefield, APLC_UKTYPE);

       /* size of left */
      ieq(node->ptr3); 
      printf("aplc_talloc(&trs%d);\n", node->ptr2);
      STORE->c.values =	gtrs(node->ptr2, cvalfield, rtype(STORE));
      leafshape(STORE, node->ptr1);

      /* set up memory pointer for collection - loop may change it */
      mpeqmp(node->ptr7, node->ptr1);

      /* put LEFT in STORE */
      /* offset loop, put left stuff in temp register with correct type */
      STORE->index = LEFT->index;
      colloop(LEFT, LEFT->index, node->ptr3);
      switchbox(LEFT, VALUE, 0);
      /* do the actual value set, carefully checking types */ 
      node->ptr4 = sasntchk(1, STORE, LEFT, rtype(STORE),
			    node->ptr4, node->ptr7);
      rbr();
      looprank = savetree;

      /* build loop to collect right values into store */
      savetree = looprank;
      looprank = RIGHT->c.rank;

      if (!top) {
	/* *get memory pointer to node */
	/* *make trs to collect right values */
	settrs(node->ptr10, node);
	printf("aplc_talloc(&trs%d);\n", node->ptr10);
	node->c.values = gtrs(node->ptr10, cvalfield, rtype(node));
	leafshape(node, node->ptr9);
      }

      /* put RIGHT in part of STORE */
      /* offset/offset' loop, put temp stuff in final register */
      /* generate offset, for RIGHT (AXIS) */

      getsize(node->ptr8, AXIS);
      /* * */
      /* if axis is a scalar but right is not
       colloop will not initialize the index, 
       but right will possibly use it */
      if ( is_scalar(AXIS) && !  is_scalar(RIGHT) )
	setizero(AXIS->index);
      colloop(AXIS, AXIS->index, node->ptr8);

      /* from gensub */
      /* generate offset', for LEFT */
      switchbox(AXIS, VALUE, 1);
      ieqtree(LEFT->index, AXIS->c.values);

      switchbox(RIGHT, VALUE, 0);
      node->ptr6 = resinreg(RIGHT, node->ptr6);

      if (!top) {
	/* *aplc_setmp(res, mp, i, type) */
	printf("aplc_setmp(&res%d, &mp%d, ",
	       node->ptr6, node->ptr9);
	printf("\n(");
	singleton(node);
	printf(" ? 0: i%d ),\n", node->index);
	ctgen(node->c.type);
	printf(");\n");
      }

      /* check types if neccessary */
      if ((!(STORE->n.info & TYPEKNOWN)) ||
	  (!(RIGHT->n.info & TYPEKNOWN)) ||
	  (rtype(STORE) != rtype(RIGHT))) {
	printf(" /* gensubassign type check */\n");
	printf("aplc_cktype(&res%d, ", node->ptr6);
	ctgen(STORE->c.type);
	printf(", ");
	ctgen(RIGHT->c.type);
	printf(");\n");
      }
      /* aplc_setmp(res, mp, i, type) */
      printf("aplc_setmp(&res%d, &mp%d, i%d, ",
	     node->ptr6, node->ptr1, LEFT->index);
      ctgen(STORE->c.type);
      printf(");\n");

      rbr();
      looprank = savetree;
      /* end of sub assignment loops
	 STORE built and updated */

    }
    break;

  case COMBINE:
    break;

  case VALUE:

    /*  this may need more debugging, but looks good so far...
	o get all from right
     */

    /* have right stored in trs, so read out */
    leafvalue(node, node->ptr9, rtype(node), node->ptr6);

    break;

  case FINISH:
    switchbox(AXIS, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
#ifdef DEBUGFREE
    printf("/* -- gensub finish */\n");
#endif
    if ( (LEFT->n.info & TYPEKNOWN) && (RIGHT->n.info & TYPEKNOWN) 
	 && (rtype(LEFT) == rtype(RIGHT)) ) {
      /* don't need anything here */
    } else {
      /* free old values */
      printf("aplc_detalloc(%c%s);\n", 
	     (is_pointer(LEFT->namep) ? ' ' : '&'),
	     LEFT->namep);
      /* now assign store trs to name */
      printf("aplc_assign(%c%s, &trs%d);\n",
	     (is_pointer(LEFT->namep) ? ' ' : '&'),
	     LEFT->namep, node->ptr2);
    }
    if (!top) {
      printf("aplc_detalloc(&trs%d);\n", node->ptr10);
    }
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;
  }
}
#endif /* new subassign */

/* end of asgn.c */


