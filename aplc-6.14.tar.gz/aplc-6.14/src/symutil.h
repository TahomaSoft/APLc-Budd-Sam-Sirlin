/*
	APL Compiler

	general symbol table utilities
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_SYMUTIL_H
#define _APLC_SYMUTIL_H

extern void init_info(info_t *x);
extern void init_codetree(codetree_t *x);
extern struct node *newnode(int type);
extern struct node *addcollect(struct node * node);
extern struct node *addccollect(struct node * node);
extern struct node *addbox(struct node * node);

extern struct symnode * lookup_name(char *name, struct symnode *table);

extern int sym_class_match( class_t c1, class_t c2);

extern char *name_strcpy(char *name);
extern int name_strmatch(char *n1, char *n2);

extern symnode_t *add_sym(char *name, struct symnode **table, 
			  char *alias, struct symnode **atable, 
			  class_t class, int type, int rank, 
                          int valence);

extern int extract_valence(int o);
extern int extract_optype(int o);

extern int get_valence(int type);

extern char *fid_gen_global(char *name);

#endif /* _APLC_SYMUTIL_H */ 
/* end */
