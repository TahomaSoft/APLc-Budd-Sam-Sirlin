/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     CLASS = 258,
     TYPE = 259,
     RANK = 260,
     VALENCE = 261,
     DEL = 262,
     GO = 263,
     COMMENT = 264,
     COLLECT = 265,
     CVEC = 266,
     CIVEC = 267,
     CSCALAR = 268,
     CISCALAR = 269,
     CCOLLECT = 270,
     ASSIGN = 271,
     QUADASSIGN = 272,
     SUBASSIGN = 273,
     QUAD = 274,
     QQUAD = 275,
     QQUADASSIGN = 276,
     DQUAD = 277,
     DQQUAD = 278,
     DQUADASSIGN = 279,
     DQQUADASSIGN = 280,
     QUADLZ = 281,
     IDENT = 282,
     UIDENT = 283,
     FIDENT = 284,
     OPIDENT = 285,
     LCON = 286,
     SCON = 287,
     BCON = 288,
     ICON = 289,
     RCON = 290,
     ZCON = 291,
     QCON = 292,
     OCON = 293,
     FNCON = 294,
     NL = 295,
     LP = 296,
     RP = 297,
     LB = 298,
     RB = 299,
     LCB = 300,
     RCB = 301,
     BQT = 302,
     CM = 303,
     SM = 304,
     COLON = 305,
     DOLLAR = 306,
     DOT = 307,
     MSFUN = 308,
     DSFUN = 309,
     OUTER = 310,
     INNER = 311,
     INNERCHILD = 312,
     DECODE = 313,
     SLASH = 314,
     BSLASH = 315,
     REDUCE = 316,
     EXPAND = 317,
     COMPRESS = 318,
     SCAN = 319,
     SORT = 320,
     GRADEUP = 321,
     GRADEDOWN = 322,
     EPSILON = 323,
     INDEXOF = 324,
     TRANS = 325,
     DTRANS = 326,
     REVERSE = 327,
     ROTATE = 328,
     TAKE = 329,
     DROP = 330,
     GWTAKE = 331,
     GWDROP = 332,
     RHO = 333,
     RHORHO = 334,
     RESHAPE = 335,
     SUB = 336,
     EMPTSEMI = 337,
     CAT = 338,
     INDEXFN = 339,
     IOTA = 340,
     LAM = 341,
     MATCH = 342,
     RAVEL = 343,
     ROLL = 344,
     DEAL = 345,
     ENCODE = 346,
     FORMAT = 347,
     DFORMAT = 348,
     EXECUTE = 349,
     LCARET = 350,
     RCARET = 351,
     ANON = 352,
     BOX = 353,
     LINK = 354,
     RESHAPEX = 355,
     UNBOX = 356,
     MSOLVE = 357,
     DOMINO = 358,
     AVEC = 359,
     TCAV = 360,
     TYPECON = 361,
     ASYSVAR = 362,
     SYSVAR = 363,
     DSYSFUN = 364,
     ESYSFUN = 365,
     MSYSFUN = 366,
     ALPHA = 367,
     OMEGA = 368,
     DELTA = 369,
     ALPHAU = 370,
     OMEGAU = 371,
     CATCH = 372,
     COND = 373,
     APPLY = 374,
     EACH = 375,
     AXISO = 376,
     ATERM = 377,
     TERM = 378,
     EXPRO = 379,
     CGOTO = 380
   };
#endif
/* Tokens.  */
#define CLASS 258
#define TYPE 259
#define RANK 260
#define VALENCE 261
#define DEL 262
#define GO 263
#define COMMENT 264
#define COLLECT 265
#define CVEC 266
#define CIVEC 267
#define CSCALAR 268
#define CISCALAR 269
#define CCOLLECT 270
#define ASSIGN 271
#define QUADASSIGN 272
#define SUBASSIGN 273
#define QUAD 274
#define QQUAD 275
#define QQUADASSIGN 276
#define DQUAD 277
#define DQQUAD 278
#define DQUADASSIGN 279
#define DQQUADASSIGN 280
#define QUADLZ 281
#define IDENT 282
#define UIDENT 283
#define FIDENT 284
#define OPIDENT 285
#define LCON 286
#define SCON 287
#define BCON 288
#define ICON 289
#define RCON 290
#define ZCON 291
#define QCON 292
#define OCON 293
#define FNCON 294
#define NL 295
#define LP 296
#define RP 297
#define LB 298
#define RB 299
#define LCB 300
#define RCB 301
#define BQT 302
#define CM 303
#define SM 304
#define COLON 305
#define DOLLAR 306
#define DOT 307
#define MSFUN 308
#define DSFUN 309
#define OUTER 310
#define INNER 311
#define INNERCHILD 312
#define DECODE 313
#define SLASH 314
#define BSLASH 315
#define REDUCE 316
#define EXPAND 317
#define COMPRESS 318
#define SCAN 319
#define SORT 320
#define GRADEUP 321
#define GRADEDOWN 322
#define EPSILON 323
#define INDEXOF 324
#define TRANS 325
#define DTRANS 326
#define REVERSE 327
#define ROTATE 328
#define TAKE 329
#define DROP 330
#define GWTAKE 331
#define GWDROP 332
#define RHO 333
#define RHORHO 334
#define RESHAPE 335
#define SUB 336
#define EMPTSEMI 337
#define CAT 338
#define INDEXFN 339
#define IOTA 340
#define LAM 341
#define MATCH 342
#define RAVEL 343
#define ROLL 344
#define DEAL 345
#define ENCODE 346
#define FORMAT 347
#define DFORMAT 348
#define EXECUTE 349
#define LCARET 350
#define RCARET 351
#define ANON 352
#define BOX 353
#define LINK 354
#define RESHAPEX 355
#define UNBOX 356
#define MSOLVE 357
#define DOMINO 358
#define AVEC 359
#define TCAV 360
#define TYPECON 361
#define ASYSVAR 362
#define SYSVAR 363
#define DSYSFUN 364
#define ESYSFUN 365
#define MSYSFUN 366
#define ALPHA 367
#define OMEGA 368
#define DELTA 369
#define ALPHAU 370
#define OMEGAU 371
#define CATCH 372
#define COND 373
#define APPLY 374
#define EACH 375
#define AXISO 376
#define ATERM 377
#define TERM 378
#define EXPRO 379
#define CGOTO 380




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE

{
	char *c;
	double d;
	double z[2];
	double q[4];
	double oct[8];
	struct headnode *h;
	struct headnode *oh;
	int  i;
	enum classes l;
	struct node *n;
	enum sfuns o;
	struct symnode *s;
	struct statenode *t;
	enum sysvars v;
	}
/* Line 1489 of yacc.c.  */

	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYLTYPE yylloc;
