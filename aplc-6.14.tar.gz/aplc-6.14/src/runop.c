/*
	APL Compiler

	Run time system
	routines having to do with scalar functions values
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "aplc.h"

/* if nonzero, check for some domain errors... 
   won't catch them all */
#define DCHECKS 1

/* for debugging */
#define ROPDB 0

/* make  0%0 legal, for jbw */
/* also used in runio.c */
/* #define WEB_MOD */

/* sws  declarations */
/* external stuff */
#ifdef SUNOS4
extern int rand(void);
#endif


/* local function definitions */
static int aplcomp(int *i, int *j);
/* need a 4 byte int = 32 bit int*/
#if SIZEOF_INT == 4
typedef unsigned int mother_int_t;
/*typedef unsigned long mother_int_t;*/
#elif SIZEOF_LONG == 4
typedef unsigned long mother_int_t;
#endif

/*static double Mother(unsigned long *pSeed);*/
static double Mother(mother_int_t *pSeed);

/* some globals initialized here */
int aplc_ixorg = 1;		/* index origin */
/* type of pseudo random number generator 
   0 rand/srand 
   1 mother */
#if USEMOTHER
int aplc_prng = 1; 
#else
int aplc_prng = 0; 
#endif
/* random number seed */
/*unsigned long aplc_seed = 1;*/
aplc_seed_t aplc_seed = 1;

/* flag to initialize new seed value */
int aplc_rl_init = 1;

/* absolute value for integers */
extern int
aplc_iabs(int i)
{
  return ((i < 0) ? -i : i);
}

/* sws */
/* conftype - make two argument types conform to the largest;
              return value of desired type 
	      - this may change the inputs */
extern int
aplc_conftype(union res_struct *lval, int ltype, 
	      union res_struct *rval, int rtype)
{
  if (ltype == rtype)
    return (ltype);
  else if (ltype < rtype) {
    aplc_cktype(lval, rtype, ltype);
    return (rtype);
  } else {
    aplc_cktype(rval, ltype, rtype);
    return (ltype);
  }
}

/* conftype2 - make two argument types conform to the largest;
              return value of desired type 
	      - this will not change the inputs */
extern int
aplc_conftype2(union res_struct *lnval, 
	       union res_struct *lval, int ltype, 
	       union res_struct *rnval, 
	       union res_struct *rval, int rtype)
{
  int maxtype;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(lnval, maxtype, lval, ltype);
  aplc_cktype2(rnval, maxtype, rval, rtype);
  return (maxtype);

}

/* sws aplc_cktype2 - check to see if a value is of the correct type,
                      converting it if necessary. This version leaves
                      the original unchanged. */
extern void
aplc_cktype2(union res_struct *resout, int type, 
	     union res_struct *res, int giventype)
{
  int i;

#if ROPDB > 0
  fprintf(aplcerr,"[aplc_cktype2] type %d, giventype %d\n", 
	  type, giventype);

#endif  
  /* error checking */
  if (type == 0) {
    if (giventype != 0)
      return;
    aplc_error("unknown type");
  }
  switch (type) {
  case APLC_BOOL:
    if (giventype == APLC_BOOL) {
      resout->i = res->i;
      return;
    } else if ((giventype == APLC_INT) &&
	((res->i == 0) || (res->i == 1))) {
      resout->i = res->i;
      return;
    } else {
      fprintf(aplcerr, "giventype= %d]\n", giventype);
      aplc_error("illegal coversion to bit");
    }
    break;
  case APLC_INT:
    if ((giventype == APLC_INT) || (giventype == APLC_BOOL)) {
      resout->i = res->i;
      return;
    } else {
      fprintf(aplcerr,"giventype %d, ", giventype);
      aplc_error("illegal conversion to int");
    }
    break;
  case APLC_REAL:
    if ((giventype == APLC_BOOL) || (giventype == APLC_INT)) {
      resout->r = (double) res->i;
      return;
    } else if (giventype == APLC_REAL) {
      resout->r = res->r;
      return;
    } else {
      fprintf(aplcerr, "giventype= %d]\n", giventype);
      aplc_error("illegal conversion to real");
    }
    break;
  case APLC_COMPLEX:
    if (giventype == APLC_COMPLEX) {
      resout->z[0] = res->z[0];
      resout->z[1] = res->z[1];
      return;
    }      
    if ((giventype == APLC_BOOL) || (giventype == APLC_INT)) {
      resout->z[0] = (double) res->i;
      resout->z[1] = 0.0;
      return;
    }
    if (giventype == APLC_REAL) {
      resout->z[0] = (double) res->r;
      resout->z[1] = 0.0;
      return;
    }
    fprintf(aplcerr, "giventype= %d]\n", giventype);
    aplc_error("illegal conversion to complex");
    break;
  case APLC_QUAT:
    if (giventype == APLC_QUAT) {
      for (i=0; i<4; i++)
	resout->q[i] = res->q[i];
      return;
    }      
    if ((giventype == APLC_BOOL) || (giventype == APLC_INT)) {
      resout->q[0] = (double) res->i;
      resout->q[1] = 0.0;
      resout->q[2] = 0.0;
      resout->q[3] = 0.0;
      return;
    }
    if (giventype == APLC_REAL) {
      resout->q[0] = res->r;
      resout->q[1] = 0.0;
      resout->q[2] = 0.0;
      resout->q[3] = 0.0;
      return;
    }
    if (giventype == APLC_COMPLEX) {
      resout->q[0] = res->z[0];
      resout->q[1] = res->z[1];
      resout->q[2] = 0.0;
      resout->q[3] = 0.0;
      return;
    }
    fprintf(aplcerr, "giventype= %d]\n", giventype);
    aplc_error("illegal conversion to quat");
    break;
  case APLC_OCT:
    if (giventype == APLC_OCT) {
      for (i=0; i<8; i++)
	resout->o[i] = res->o[i];
      return;
    }      
    if ((giventype == APLC_BOOL) || (giventype == APLC_INT)) {
      resout->o[0] = (double) res->i;
      for (i=1; i<8; i++)
	resout->o[i] = 0.0;
      return;
    }
    if (giventype == APLC_REAL) {
      resout->o[0] = res->r;
      for (i=1; i<8; i++)
	resout->o[i] = 0.0;
      return;
    }
    if (giventype == APLC_COMPLEX) {
      resout->o[0] = res->z[0];
      resout->o[1] = res->z[1];
      for (i=2; i<8; i++)
	resout->o[i] = 0.0;
      return;
    }
    if (giventype == APLC_QUAT) {
      for (i=0; i<4; i++)
	resout->o[i] = res->q[i];
      for (i=4; i<8; i++)
	resout->o[i] = 0.0;
      return;
    }
    fprintf(aplcerr, "giventype= %d]\n", giventype);
    aplc_error("illegal conversion to oct");
    break;
  case APLC_CHAR:
    if (giventype == APLC_CHAR) {
      resout->c = res->c;
      return;
    } else {
      fprintf(aplcerr, "giventype= %d]\n", giventype);
      aplc_error("illegal conversion to char");
    }
    break;
  case APLC_BOXED:
    if (giventype == APLC_BOXED) {
      resout->trs = res->trs;
      return;
    } else {
      fprintf(aplcerr, "giventype= %d]\n", giventype);
      aplc_error("illegal conversion to boxed");
    }
    break;
  default:
    fprintf(aplcerr, " [type= %d ,", type);
    fprintf(aplcerr, "giventype= %d]\n", giventype);
    aplc_error("unknown type in aplc_cktype2");
    break;
  }
}

/* aplc_cktype - check to see if a value is of the correct type,
   converting it if necessary

  sws: this doesn't work all the time, since a value may be demanded
  more than once, and this routine changes it's type 

  res : input (scalar)
  type      : desired type
  giventype : current type of res
*/
extern void
aplc_cktype(union res_struct * res, int type, int giventype)
{
  int i;

  /* sws error checking */
  if (type == 0) {
    if (giventype != 0)
      return;
    aplc_error("[cktype] unknown type");
  }
  if (type == giventype)
    return;

  switch (type) {
  case APLC_BOOL:
    if (giventype == APLC_BOOL)
      return;
    if (giventype == APLC_INT) {
      if ((res->i == 0) || (res->i == 1))
	return;
    }
    aplc_error("[cktype] illegal coversion to bit");
    break;
  case APLC_INT:
    if (giventype == APLC_BOOL)
      return;
    fprintf(aplcerr,"giventype %d, ", giventype);
    aplc_error("[cktype] illegal conversion to int");
    break;
  case APLC_REAL:
    if ((giventype == APLC_BOOL) || (giventype == APLC_INT)) {
      res->r = (double) res->i;
      return;
    }
    aplc_error("[cktype] illegal conversion to real");
    break;
  case APLC_COMPLEX:
    if ((giventype == APLC_BOOL) || (giventype == APLC_INT)) {
      res->z[0] = (double) res->i;
      res->z[1] = 0.0;
      return;
    }
    if (giventype == APLC_REAL) {
      res->z[0] = (double) res->r;
      res->z[1] = 0.0;
      return;
    }
    aplc_error("[cktype] illegal conversion to complex");
    break;
  case APLC_QUAT:
    if ((giventype == APLC_BOOL) || (giventype == APLC_INT)) {
      res->q[0] = (double) res->i;
      res->q[1] = 0.0;
      res->q[2] = 0.0;
      res->q[3] = 0.0;
      return;
    }
    if (giventype == APLC_REAL) {
      res->q[0] = res->r;
      res->q[1] = 0.0;
      res->q[2] = 0.0;
      res->q[3] = 0.0;
      return;
    }
    if (giventype == APLC_COMPLEX) {
      res->q[0] = res->z[0];
      res->q[1] = res->z[1];
      res->q[2] = 0.0;
      res->q[3] = 0.0;
      return;
    }
    aplc_error("[cktype] illegal conversion to quat");
    break;
  case APLC_OCT:
    if ((giventype == APLC_BOOL) || (giventype == APLC_INT)) {
      res->o[0] = (double) res->i;
      for (i=1; i<8; i++)
	res->o[i] = 0.0;
      return;
    }
    if (giventype == APLC_REAL) {
      res->o[0] = res->r;
      for (i=1; i<8; i++)
	res->o[i] = 0.0;
      return;
    }
    if (giventype == APLC_COMPLEX) {
      res->o[0] = res->z[0];
      res->o[1] = res->z[1];
      for (i=2; i<8; i++)
	res->o[i] = 0.0;
      return;
    }
    if (giventype == APLC_QUAT) {
      for (i=0; i<4; i++)
	res->o[i] = res->q[i];
      for (i=4; i<8; i++)
	res->o[i] = 0.0;
      return;
    }
    fprintf(aplcerr, "giventype= %d\n", giventype);
    aplc_error("[cktype] illegal conversion to oct");
    break;
  case APLC_CHAR:
    fprintf(aplcerr, "giventype= %d\n", giventype);
    aplc_error("[cktype] illegal conversion to char");
    break;
  case APLC_BOXED:
#if 1
    {
    /* make a copy of res
       create the scalar trs */
      res_t rtemp;
      aplc_cpres(&rtemp, res, giventype);
      aplc_inittrs(&res->trs);
      res->trs.type = giventype;
      res->trs.rank = 0;
      res->trs.size = 1;
      aplc_talloc(&res->trs);
      aplc_cpres2trs(&res->trs, 0, &rtemp);
    }
#else
    fprintf(aplcerr, "giventype= %d\n", giventype);
    aplc_error("[cktype] illegal conversion to boxed");
#endif
    break;
  default:
    fprintf(aplcerr, "object:\n");
    aplc_printit(res, giventype,1);
    fprintf(aplcerr, " [type= %d ,", type);
    fprintf(aplcerr, "giventype= %d]\n", giventype);
    aplc_error("[cktype] unknown type in aplc_cktype");
    break;
  }
}

/* sws  generate fill element at runtime for expansion */
extern void
aplc_genfill(union res_struct * res, int type)
{
  int i;

  switch (type) {
    case APLC_BOOL:
    case APLC_INT:
    res->i = 0;
    break;
  case APLC_REAL:
    res->r = 0.0;
    break;
  case APLC_COMPLEX:
    res->z[0] = 0.0;
    res->z[1] = 0.0;
    break;
  case APLC_QUAT:
    for (i=0; i<4; i++)
      res->q[i] = 0.0;
    break;
  case APLC_OCT:
    for (i=0; i<8; i++)
      res->o[i] = 0.0;
    break;
  case APLC_CHAR:
    res->c = ' ';
    break;
  case APLC_BOXED:
    aplc_inittrs(&res->trs);
    res->trs.type = APLC_BOXED;
    break;
  default:
    aplc_error("genfill type aplc_error");
  }
}

/* aplc_identity - compute an aplc_identity value */
extern void
aplc_identity(enum sfuns op, union res_struct * res, int type)
{
  int i;

  switch (op) {
  case APLC_PLUS:
  case APLC_MINUS:
  case APLC_ABS:
  case APLC_OR:
  case APLC_LT:
  case APLC_GT:
  case APLC_NE:
    switch (type) {
    case APLC_BOOL:
    case APLC_INT:
      res->i = 0;
      break;
    case APLC_REAL:
      res->r = 0.0;
      break;
    case APLC_COMPLEX:
      res->z[0] = 0.0;
      res->z[1] = 0.0;
      break;
    case APLC_QUAT:
      res->q[0] = 0.0;
      res->q[1] = 0.0;
      res->q[2] = 0.0;
      res->q[3] = 0.0;
      break;
    case APLC_OCT:
      for (i=0; i<8; i++)
	res->o[i] = 0.0;	
      break;
    default:
      fprintf(aplcerr, "type %d\n", type);
      aplc_error("[aplc_identity](+) type error");
    }
    break;

  case APLC_TIMES:
  case APLC_DIVIDE:
  case APLC_EXP:
  case APLC_FACT:
  case APLC_AND:
  case APLC_LE:
  case APLC_EQ:
  case APLC_GE:
    switch (type) {
    case APLC_BOOL:
    case APLC_INT:
      res->i = 1;
      break;
    case APLC_REAL:
      res->r = 1.0;
      break;
    case APLC_COMPLEX:
      res->z[0] = 1.0;
      res->z[1] = 0.0;
      break;
    case APLC_QUAT:
      res->q[0] = 1.0;
      res->q[1] = 0.0;
      res->q[2] = 0.0;
      res->q[3] = 0.0;
      break;
    case APLC_OCT:
      res->o[0] = 1.0;	
      for (i=1; i<8; i++)
	res->o[i] = 0.0;	
      break;
    default:
      fprintf(aplcerr, "type %d\n", type);
      aplc_error("[aplc_identity](*) type error");
    }
    break;

 /* smallest number */
  case APLC_CEIL:
    switch (type) {
    case APLC_BOOL:
    case APLC_INT:
      res->i = INT_MIN;
      break;
    case APLC_REAL:
      res->r = -DBL_MAX;
      break;
    case APLC_COMPLEX:
      res->z[0] = -DBL_MAX;
      res->z[1] = 0.0;
      break;
    case APLC_QUAT:
      res->q[0] = -DBL_MAX;
      res->q[1] = 0.0;
      res->q[2] = 0.0;
      res->q[3] = 0.0;
      break;
    case APLC_OCT:
      res->o[0] = -DBL_MAX;
      for (i=1; i<8; i++)
	res->o[i] = 0.0;
      break;
    default:
      fprintf(aplcerr, "type %d\n", type);
      aplc_error("[aplc_identity](ceil) type error");
    }
    break;

 /* largest number */
  case APLC_FLOOR:
    switch (type) {
    case APLC_BOOL:
    case APLC_INT:
      res->i = INT_MAX;
      break;
    case APLC_REAL:
      res->r = DBL_MAX;
      break;
    case APLC_COMPLEX:
      res->z[0] = DBL_MAX;
      res->z[1] = 0.0;
      break;
    case APLC_QUAT:
      res->q[0] = DBL_MAX;
      res->q[1] = 0.0;
      res->q[2] = 0.0;
      res->q[3] = 0.0;
      break;
    case APLC_OCT:
      res->o[0] = DBL_MAX;
      for (i=1; i<8; i++)
	res->o[i] = 0.0;
      break;
    default:
      fprintf(aplcerr, "type %d\n", type);
      aplc_error("[aplc_identity](floor) type error");
    }
    break;

  default:
    fprintf(aplcerr, "operator %d\n", op);
    aplc_error("[aplc_identity] unknown op used");
  }
}


/*
	sorting routines */

static int stype, sdir;
static union mp_struct *svals;

/* comparison function used in grade up or down */
static int
aplcomp(int *i, int *j)
{
  int r;

  switch (stype) {
  case APLC_BOOL:
  case APLC_INT:
    if (svals->ip[*i] == svals->ip[*j]) {
      /* sws  original */
      /* r = 0;*/
      /* sws  preserve indicial order among equals */
      r = (*i-*j)*sdir;
    }
    else if (svals->ip[*i] < svals->ip[*j])
      r = -1;
    else
      r = 1;
    break;
  case APLC_REAL:
    if (svals->rp[*i] == svals->rp[*j]) {
      /*r = 0;*/
      r = (*i-*j)*sdir;
    }
    else if (svals->rp[*i] < svals->rp[*j])
      r = -1;
    else
      r = 1;
    break;
  case APLC_CHAR:
    if (svals->cp[*i] == svals->cp[*j]) {
      /* r = 0;*/
      r = (*i-*j)*sdir;
    }
    else if (svals->cp[*i] < svals->cp[*j])
      r = -1;
    else
      r = 1;
    break;
  default:
    r = 1;
  }
  return (sdir * r);
}

/* grade up or down */
extern void
aplsort(union mp_struct * result, union mp_struct * values, int size, 
        int type, int direction)
{
  int i;

  aplc_vectalloc(result, size, APLC_INT);
  for (i = 0; i < size; i++)
    result->ip[i] = i;
  stype = type;
  svals = values;
  sdir = direction;
  /*
  qsort((void *) result->ip, size, sizeof(int),
      (int (*) (void *, void *)) aplcomp);
  qsort((void *) result->ip, size, sizeof(int),
      (int (*) (const void *, const void *)) aplcomp); */
  qsort((void *) result->ip, (size_t) size, sizeof(int),
      (int (*) (const void *, const void *)) aplcomp);
  return;
}

/*
aplsearch
        search for an item in a list
       
	this should be optimized to use binary search,
	check types only once (instead of each iteration through loop),
	but this will work for now

 input 
   index   is the result of aplsort, an index into the values
   values  is the list of values
   result  is the item
   restype is the result type
   size    is the number of values in the list
   
	sws  note zero index origin here

*/
extern int
aplsearch(int *iindex, union mp_struct * values, 
	  union res_struct * result, int valtype, int restype, int size)
{
  register int step, position;

  /* check for degenerate case */
  if (size <= 0 )
    return(0);

  for (step = 1; 2 * step <= size; step *= 2);
  position = step - 1;

  switch (valtype) {
  case APLC_CHAR:
    switch (restype) {
    default:
      return (size);
      break;
    case APLC_CHAR:
      do {
	step /= 2;
	if (values->cp[iindex[position]] == result->c) {
	  /* return (iindex[position]);*/
	  while ( (position >= 0) && 
		 (values->cp[iindex[position]] == result->c) )
	    position--;
	  return (iindex[++position]);
	}
	else if (values->cp[iindex[position]] <
	    result->c) {
	  position += step;
	  if (position >= size)
	    position = size - 1;
	} else
	  position -= step;
      } while (step != 0);
      break;
    }
    break;
  case APLC_INT:
  case APLC_BOOL:
    switch (restype) {
    default:
      return (size);
      break;
    case APLC_INT:
    case APLC_BOOL:
      do {
	step /= 2;
	if (values->ip[iindex[position]] == result->i) {
	  /* return (iindex[position]);*/
	  /* sws  check to see this is the lowest position */
	  while ( (position >= 0) &&
		 (values->ip[iindex[position]] == result->i) )
	    position--;
	  return (iindex[++position]);
	}
	else if (values->ip[iindex[position]] <
	    result->i) {
	  position += step;
	  if (position >= size)
	    position = size - 1;
	} else
	  position -= step;
      } while (step != 0);
      break;
    case APLC_REAL:
      do {
	step /= 2;
	if ((double) values->ip[iindex[position]] == result->r) {
	  while ( (position >= 0) &&
		 ( (double) values->ip[iindex[position]] == result->r) )
	    position--;
	  return (iindex[++position]);
	}
	else if ((double) values->ip[iindex[position]] <
	    result->r) {
	  position += step;
	  if (position >= size)
	    position = size - 1;
	} else
	  position -= step;
      } while (step != 0);
      break;
    }
    break;
  case APLC_REAL:
    switch (restype) {
    default:
      return (size);
      break;
    case APLC_INT:
    case APLC_BOOL:
      do {
	step /= 2;
	if (values->rp[iindex[position]] == (double) result->i) {
	  while ( (position >= 0) &&
		 (values->rp[iindex[position]] == (double) result->i) )
	    position--;
	  return (iindex[++position]);
	}
	else if (values->rp[iindex[position]] < (double) result->i) {
	  position += step;
	  if (position >= size)
	    position = size - 1;
	} else
	  position -= step;
      } while (step != 0);
      break;
    case APLC_REAL:
      do {
	step /= 2;
	if (values->rp[iindex[position]] == result->r) {
	  while ( (position >= 0) &&
		 (values->rp[iindex[position]] == result->r) )
	    position--;
	  return (iindex[++position]);
	}
	else if (values->rp[iindex[position]] < result->r) {
	  position += step;
	  if (position >= size)
	    position = size - 1;
	} else
	  position -= step;
      } while (step != 0);
      break;
    }
    break;
  }
  return (size);
}

/* -------------------------------------------------- */
/* random number generator 

From: Bob Wheeler <bwheeler@ssnet.com>
Newsgroups: sci.stat.consult,sci.math.num-analysis
Subject: Marsaglia's Mother of all RNG's (Long?)
Date: Fri, 28 Oct 94 19:32:08 EDT

original algorithm by:
George Marsaglia geo@stat.fsu.edu

*/
static short mother1[10];
static short mother2[10];
/*static short mStart=1;*/

#define m16Long 65536L				/* 2^16 */
#define m16Mask 0xFFFF          /* mask for lower 16 bits */
#define m15Mask 0x7FFF			/* mask for lower 15 bits */
#define m31Mask 0x7FFFFFFF     /* mask for 31 bits */
#define m32Double  4294967295.0  /* 2^32-1 */

/* Mother **************************************************************
|	George Marsaglia's The mother of all random number generators
|		producing uniformly distributed pseudo random 32 bit values 
with
|		period about 2^250.
|	The text of Marsaglia's posting is appended at the end of the function.
|
|	The arrays mother1 and mother2 store carry values in their
|		first element, and random 16 bit numbers in elements 1 to 8.
|		These random numbers are moved to elements 2 to 9 and a new
|		carry and number are generated and placed in elements 0 and 1.
|	The arrays mother1 and mother2 are filled with random 16 bit values
|		on first call of Mother by another generator.  mStart is the 
switch.
|
|	Returns:
|	A 32 bit random number is obtained by combining the output of the
|		two generators and returned in *pSeed.  It is also scaled by
|		2^32-1 and returned as a double between 0 and 1
|
|	SEED:
|	The inital value of *pSeed may be any long value
|
|	Bob Wheeler 8/8/94
*/

/* change  unsigned long *pSeed -> mother_int_t  
      long is 4 bytes on 386, sparc, 
      but 8 on amd...
      unsigned long  number, number1, number2;*/
static double 
Mother(mother_int_t *pSeed)
{
  mother_int_t number, number1, number2;
  short n, *p;
  unsigned short sNumber;

  /* Initialize motheri with 9 random values the first time */
  /*   if (mStart) {*/
  if (aplc_rl_init) {
    sNumber=*pSeed&m16Mask;   /* The low 16 bits */
    number=*pSeed&m31Mask;    /* Only want 31 bits */

    p=mother1;
    for (n=18;n--;) {
      number=30903*sNumber+(number>>16);   /* One line 
					      multiply-with-cary */
      *p++=sNumber=number&m16Mask;
      if (n==9)
	p=mother2;
    }
    /* make cary 15 bits */
    mother1[0]&=m15Mask;
    mother2[0]&=m15Mask;
    /* mStart=0;*/
    aplc_rl_init = 0;
  }

  /* Move elements 1 to 8 to 2 to 9 */
  /*#if defined(SUNOS5)*/
#if HAVE_MEMMOVE
  /* original code */
  memmove(mother1+2,mother1+1,8*sizeof(short));
  memmove(mother2+2,mother2+1,8*sizeof(short));
#else
  /* (SUNOS4) */
  /* should be general? */
  memcpy(mother1+2,mother1+1,8*sizeof(short));
  memcpy(mother2+2,mother2+1,8*sizeof(short));
#endif

  /* Put the carry values in numberi */
  number1=mother1[0];
  number2=mother2[0];

  /* Form the linear combinations */
	
  number1+=1941*mother1[2]+1860*mother1[3]+1812*mother1[4]+1776*mother1[5]+
    1492*mother1[6]+1215*mother1[7]+1066*mother1[8]+12013*mother1[9];
	
  number2+=1111*mother2[2]+2222*mother2[3]+3333*mother2[4]+4444*mother2[5]+
    5555*mother2[6]+6666*mother2[7]+7777*mother2[8]+9272*mother2[9];

  /* Save the high bits of numberi as the new carry */
  mother1[0]=number1/m16Long;
  mother2[0]=number2/m16Long;
  /* Put the low bits of numberi into motheri[1] */
  mother1[1]=m16Mask&number1;
  mother2[1]=m16Mask&number2;

  /* Combine the two 16 bit random numbers into one 32 bit */
  *pSeed=(((long)mother1[1])<<16)+(long)mother2[1];

  /* Return a double value between 0 and 1 */
  return ((double)*pSeed)/m32Double;
}

/* --------------------------------------------------
           roll and deal functions
*/

/* roll function - 
   random integer between aplc_ixorg, limit-1+aplc_ixorg */
int
aplc_randint(int limit)
{
  if (aplc_prng)
    return aplc_ixorg + (int) (0.5 + Mother((mother_int_t *)&aplc_seed)*(limit-1));
  else
    return (aplc_ixorg + (rand() / 100) % limit);
}

/* deal dyadic function - num values from iota val */
void
aplc_deal(union mp_struct * values, int num, int val)
{
  int i, j, k;

  for (i = 0; i < num; i++) {
    j = 1;
    while (j == 1) {
      values->ip[i] = aplc_randint(val);
      j = 0;
      for (k = 0; k < i; k++)
	if (values->ip[i] == values->ip[k])
	  j = 1;
    }
  }
  return;
}


/* sws
   some new stuff used in catenate/laminate
*/

/*
  compute    res = res op int

  only does +- so far...

*/
void
aplc_resfun(union res_struct * res, int type, enum sfuns op, int i)
{
  switch (op) {
    default:
    aplc_error("[aplc_resfun] unknown op in aplc_resfun");
    break;
  case APLC_PLUS:
    switch (type) {
    case APLC_INT:
      res->i = res->i + i;
      break;
    case APLC_REAL:
      res->r = res->r + (double) i;
      break;
    default:
      aplc_error("[aplc_resfun] illegal type in aplc_resfun");
      break;
    }
    break;
  case APLC_MINUS:
    switch (type) {
    case APLC_INT:
      res->i = res->i - i;
      break;
    case APLC_REAL:
      res->r = res->r - (double) i;
      break;
    default:
      aplc_error("[aplc_resfun] illegal type in aplc_resfun");
      break;
    }
    break;
  }
  return;
}

/*
  do special monadic operations
  returning integers

  ival = op res
*/
int
aplc_imsfun(enum sfuns op, union res_struct * res, int type)
{
  switch (op) {
    default:
    aplc_error("unknon op in aplc_imsfun");
    break;
  case APLC_CEIL:
    switch (type) {
    case APLC_INT:
      return (ceil((double)res->i));
      break;
    case APLC_REAL:
      return ((int) ceil(res->r));
      break;
    default:
      aplc_error("illegal type in aplc_resfun");
      break;
    }
  }
  /* lint stuffing */
  return (0);
}

/* end of runop.c */
