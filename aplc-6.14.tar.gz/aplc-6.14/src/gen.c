/*
 This is the code generation pass.
 - print out structure, declarations
 - call routines to generate code

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#include "parse.h"
#include "gen.h"
#include "y_tab.h"

/* ---------------------------------------------------------------- */
#define INMAIN  (head == NILHEAD || head->opname == NILCHAR) 

/* for debugging printout */
#define GDEBUG 0
#define nl()   printf("\n")

/* ---------------------------------------------------------------- */
/* local functions */
static void listpunct(int i, int vartop);
static void gcdcls(void);

static void gen_const_dcls(struct statenode * code);
static void gen_const_do_stmt(struct node *node);

static int is_var(symnode_t *sy);
static int is_apar(symnode_t *sy);
static void gen_glocal_dcls(symnode_t *syms);
static void gen_syms_decl( symnode_t *syms );
static void gen_syms_alias(symnode_t *syms);
static void gen_syms_init( symnode_t *syms );
static int find_goto( struct statenode * code);


static void do_stmt(struct node *node);
static void do_early(struct node *node);
static void early_search(struct node *node);
static void stcode(struct node *node);

/* ---------------------------------------------------------------- */
/* a constant zero - used several places */
struct node *zeronode;
/* copy of global symbol table */
static struct symnode *symtab;

/* ---------------------------------------------------------------- */
/* passinit - initialize this pass */
void 
passinit(int verbose)
{
  /* sws */
  if (verbose)
    fprintf(stderr, "Starting code generation\n");

#ifdef MUSER
  /* for multiple users, aplc.h in system include directory */
   printf("#include <aplc.h>\n");
#else
  /* for single user, aplc.h in directory */
   printf("#include \"aplc.h\"\n");
#endif

#if 1
  printf("#include <setjmp.h>\n");
  printf("extern jmp_buf aplc_env;\n");
#endif

  zeronode = structalloc(node);
  fixzero(); /* make sure zero is ok */
  return;
}


/* glbvar - process a global variable name */
void 
glbvar(char *name)
{
  /*printf("extern struct trs_struct %s;\n", name);*/
  printf("extern struct trs_struct %s;/* global */\n", name);
}

/* ---------------------------------------------------------------- */

/* size of an aplc object in terms of fundamental c sizes */
static int
aplc_count(int type)
{
  switch(type) {
  case APLC_BOOL:
  case APLC_INT:
    return 1;
    break;
  case APLC_REAL:
    return 1;
    break;
  case APLC_COMPLEX:
    return 2;
    break;
  case APLC_QUAT:
    return 4;
    break;
  case APLC_OCT:
    return 8;
    break;
  case APLC_CHAR:
    return sizeof(char);
    break;
  default:
  case APLC_ANY:
  case APLC_UKTYPE:
  case APLC_LABEL:
    return 0;
    break;
  }
  return 0;
}

/* sws
   print some punction for lists */
static void
listpunct(int i, int vartop)
{
  if ( (i + 1) < vartop ) {
    commasp();
    if (i % 10 == 9)
      nl();
  } else {
    printf("}");
    seminl();
  }
  return;
}

static void
listpunct_sub(int i, int vartop)
{
  if ( (i + 1) < vartop ) {
    commasp();
    if (i % 10 == 9)
      nl();
  } else {
    printf("}");
  }
  return;
}


/* gcdcls - generate constant declarations */
static void 
gcdcls(void)
{
  int i, n;

  if (ictop) {
    printf("int i_%s[%d] = {", funname, ictop);
    if (ictop > 9)
      nl();
    for (i = 0; i < ictop; i++) {
      /* printf("%d%c ", iconsts[i], ((i + 1) < ictop ? ',' : '}'));*/
      printf("%d", iconsts[i]);
      listpunct(i, ictop);
    }
  }

  if (rctop) {
    printf("double r_%s[%d] = {", funname, rctop);
    if (rctop > 9)
      nl();
    for (i = 0; i < rctop; i++) {
      /* printf("%g%c ", rconsts[i], ((i + 1) < rctop ? ',' : '}'));*/
      /*printf("%23.16g", rconsts[i]);*/
      /*printf("%23.16e", rconsts[i]);*/
      printf("%22.15e", rconsts[i]);
      listpunct(i, rctop);
    }
  }

  /* these are done in another way */
#if 0
  if (zctop) {
    printf("double z_%s[2][%d] = {", funname, zctop);
    if (zctop > 9)
      nl();
    for (j=0; j<2; j++) {
      printf("{ ");
      for (i = 0; i < zctop; i++) {
	printf("%22.15e", zconsts[j][i]);
	listpunct_sub(i, zctop);
      }
      listpunct(j, 2);nl();
    }
  }

  if (qctop) {
    printf("double q_%s[%d] = {", funname, qctop);
    if (qctop > 9)
      nl();
    for (i = 0; i < qctop; i++) {
      printf("%22.15g", qconsts[i]);
      listpunct(i, qctop);
    }
  }
#endif

  if (sctop) {
    /* sws
       changed char declaration to avoid long unbreakable strings
       later this should be individual strings, if possible?...
       - also need to escape some special characters 
       */
    /* printf("char c_%s[] = \"%s\";\n", funname, sconsts); */

    n = strlen(sconsts);
    printf("char c_%s[] = {", funname);
    if (n > 9)
      nl();
    for (i = 0; i < n; i++) {
      /* sws  watch for long lines */
      if (i > 0) {
	printf(",");
	if (0 == i % 10)
	  printf("\n");
      }
      /* sws  watch for special characters */
      if (sconsts[i] == '\'')
	printf("'\\''");	     /* sws -  quote in string */
      else if (sconsts[i] == '\\')
	printf("'\\\\'");	     /* sws -  \ in string */
      else if (sconsts[i] == '\n')
	printf("'\\n'");	     /* sws -  \n in string */
      else
	printf("'%c'", sconsts[i]);

    }
    printf("}");
    seminl();
  }
#if 0
  /* sws shouldn't need this anymore */
  if (lctop) {
    printf("int l_%s[%d] = {", funname, lctop);
    if (lctop > 9)
      nl();
    for (i = 0; i < lctop; i++) {
      printf("%d", lconsts[i].label_num);
      listpunct(i, lctop);
    }
  }
#endif
  return;
}

/* sws
   new fn to generate component that can be pointed to by trs

   loop through all statements
   prepare constants
   use index that would index into xx_main as specifier:
   z_main[3] <-> z_main3
   */
static void
gen_const_dcls(struct statenode * code)
{
  struct statenode *p;

  for (p = code; p != NILSTATE; p = p->nextstate) {
    gen_const_do_stmt(p->code);
  }
  return;
}

/* sws
   search through a statement 
   generate the declaration

   only zcon, qcon, ocon
*/
static void
gen_const_do_stmt(struct node *node)
{
  int i, j;
  int size;

  if (NULL == node)
    return;
  if ( node->nodetype == ZCON ) {
    /* get size */
    size = 1;
    for (i=0; i<node->n.rank; i++)
      size *= iconsts[node->n.shape +i];
    printf("double z_%s%d[2][%d] = {\n", funname, node->n.values, size);
    for (j=0; j<2; j++) {
      printf("{ ");
      for (i=0; i<size; i++) {
	printf("%22.15e", zconsts[j][i+node->n.values]);
	listpunct_sub(i, size);
      }
      listpunct(j, 2);nl();
    }
    return;
  }
  if ( node->nodetype == QCON ) {
    /* get size */
    size = 1;
    for (i=0; i<node->n.rank; i++)
      size *= iconsts[node->n.shape +i];
    printf("double q_%s%d[4][%d] = {\n", funname, node->n.values, size);
    for (j=0; j<4; j++) {
      printf("{ ");
      for (i=0; i<size; i++) {
	printf("%22.15e", qconsts[j][i+node->n.values]);
	listpunct_sub(i, size);
      }
      listpunct(j,4);nl();
    }
    return;
  }
  if ( node->nodetype == OCON ) {
    /* get size */
    size = 1;
    for (i=0; i<node->n.rank; i++)
      size *= iconsts[node->n.shape +i];
    printf("double o_%s%d[8][%d] = {\n", funname, node->n.values, size);
    for (j=0; j<8; j++) {
      printf("{ ");
      for (i=0; i<size; i++) {
	printf("%22.15e", oconsts[j][i+node->n.values]);
	listpunct_sub(i, size);
      }
      listpunct(j,8);nl();
    }
    return;
  }
  gen_const_do_stmt(FUNRIGHT);
  gen_const_do_stmt(FUNLEFT);
  gen_const_do_stmt(RIGHT);
  if ( use_axis_node(node->nodetype) ) {
    gen_const_do_stmt(AXIS);
  }
  gen_const_do_stmt(LEFT);
  return;
}

/* does not include apars */
static int
is_var(symnode_t *sy)
{
  if ( (GLOBAL == sy->class) || 
       (LOCAL == sy->class) )
    return 1;
  return 0;
}

/* the assigned parameter for a function */
static int
is_apar(symnode_t *sy)
{
  if ( APARAM == sy->class )
    return 1;
  return 0;
}

/* declarations for glocal or glfunction
   -- global pointers declared near local fn */
static void
gen_glocal_dcls(symnode_t *syms)
{
  symnode_t *sy;

  for (sy = syms; sy != NILSYM; sy = sy->next) {
    if ( GLOCAL == sy->class ) {
      printf("/* %s, class %s */\n", sy->name, str_class(sy->class));
      printf("struct trs_struct *%s;\n", sy->name);
    }
    if ( GLFUNCTION == sy->class ) {
      printf("/* %s, class %s */\n", sy->name, str_class(sy->class));
      printf("aplc_fp_t %s;\n", sy->name);
    }
  }
  return;
} 



/* declarations for symbol table entries 
   - generate exactly if possible */
static void
gen_syms_decl( symnode_t *syms )
{
  symnode_t *sy;

  for (sy = syms; sy != NILSYM; sy = sy->next) {
    printf("/* %s, class %s, is_pointer %d */\n", sy->name, 
	   str_class(sy->class), is_pointer(sy->name));
    printf("/* %s info: \n", sy->name);
    print_info(stdout, &sy->s);
    printf(" */\n");
    /* can't use stack to define aparams */
    if ( is_apar(sy) ) {
      /* just setup shape in some cases */
      /*(sy->s.info & TYPEKNOWN) && */
      if ( TYPEisknown(sy) &&
	   (sy->s.info & RANKKNOWN) && 
	   (sy->s.info & SHAPEKNOWN) ){
	if ( !( (sy->s.info & TYPEDECL) && (sy->s.info & RANKDECL) ) ) {
	  printf("int %s_shape[%d] = ", sy->name, max(1, sy->s.rank));
	  if (sy->s.rank == 0)
	    printf("{0}");
	  else {
	    print_ivec_dec(stdout, sy->s.shape, sy->s.rank);
	  }
	  seminl();
	}
      }
    }
    if ( is_var(sy) ) {
      printf("/* %s: type= {%s}, rank= {%s} */ \n", sy->name, 
	     str_type_name(sy->s.type), str_rank(sy->s.rank));

      /*if ( (sy->s.info & TYPEKNOWN) &&*/
      if ( TYPEisknown(sy) &&
	   (sy->s.info & RANKKNOWN) && 
	   (sy->s.info & SHAPEKNOWN) ){
	printf("int %s_shape[%d] = ", sy->name, max(1, sy->s.rank));
	if (sy->s.rank == 0)
	  printf("{0}");
	else {
	  print_ivec_dec(stdout, sy->s.shape, sy->s.rank);
	}
	seminl();
	switch(sy->s.type) {
	default:
	case APLC_INT:
	case APLC_BOOL:
	case APLC_REAL:
	  printf("%s %s_value[%d];\n", 
		 cast_str(sy->s.type), sy->name, sy->s.size);
	  break;
	case APLC_COMPLEX:
	case APLC_QUAT:
	case APLC_OCT:
	  printf("%s %s_value[%d][%d];\n", 
		 cast_str(sy->s.type), sy->name, 
		 aplc_count(sy->s.type),sy->s.size);
	  break;
	}
	/*mp_type_str(sy->s.type),*/

	/* only for locals */
	if ( is_var(sy) ) {
	  printf("struct trs_struct %s = {", sy->name);
	  printf("%s,", type_str(sy->s.type)); /* type */
	  printf("%d,", sy->s.rank); /* rank */
	  printf("%s_shape,", sy->name);/* shape */
	  printf("%d,", sy->s.size); /* size */
	  printf("APLC_ALLOC_NF"); /* alloc_ind */
	  /*printf("%s_value,", sy->name);*/ /* value */
	  printf("};\n");
	}
      } else /* not much known */
	/* only for locals */
	if ( is_var(sy) )
	  printf("struct trs_struct %s;\n", sy->name);
    }
  }
  return;
}

/* generate alias assignments
   globals defined from current locals */
static void
gen_syms_alias(symnode_t *syms)
{
  symnode_t *sy;

  for (sy = syms; sy != NILSYM; sy = sy->next) {
    if (sy->glbname) {
      printf("/* %s: {%s} %s */ \n", sy->glbname, sy->name, 
             str_class(sy->class));
      /* glbname is a pointer, name may be */
      printf("%s = %s%s;\n", sy->glbname, 
             (is_pointer(sy->name) ? " " : "&"), sy->name);
    }
  }
  return;
}

/* generate the initialization for symbol table entries
   - note the difference between real locals and the return var
   - ref is either . (locals) or -> (return var) */
static void
gen_syms_init( symnode_t *syms)
{
  symnode_t *sy;
  char *sref;
  char *vref=".";
  /*char *apref="->";*/
  int i;

  for (sy = syms; sy != NILSYM; sy = sy->next) {
    printf("/* %s: %s, type= {%s}, rank= {%s} */ \n", 
	   sy->name, str_class(sy->class), 
	   str_type_name(sy->s.type), str_rank(sy->s.rank));
    if ( is_var(sy) ) {
      printf("/* local var %s: type= {%s}, rank= {%s} */ \n", sy->name, 
	     str_type_name(sy->s.type), str_rank(sy->s.rank));
      sref = vref;
#if GDEBUG
      printf("/* %s: \n", sy->name);
      print_info(stdout, &sy->s);
      printf(" */\n");
#endif
      printf("/* %s: type= {%s}, rank= {%s} */ \n", sy->name, 
	     str_type_name(sy->s.type), str_rank(sy->s.rank));
#if 0
      if ( ( sy->s.info & RANKKNOWN) &&
	   (sy->s.rank == 0) ) {
	/* scalar */
      } 
#endif
      /*if ( (sy->s.info & TYPEKNOWN) && (sy->s.type != APLC_ANY) &&*/
      if ( TYPEisknown(sy) &&
	   ( sy->s.info & RANKKNOWN) &&
	   ( sy->s.info & SHAPEKNOWN ) ) {
	switch(sy->s.type) {
	default:
	case APLC_INT:
	case APLC_BOOL:
	case APLC_REAL:
	  printf("%s%svalue.%s = %s_value;\n",
		 sy->name,sref,mp_type_str(sy->s.type), 
		 sy->name);
	  break;
	case APLC_COMPLEX:
	case APLC_QUAT:
	case APLC_OCT:
	  for (i=0; i<aplc_count(sy->s.type); i++)
	    printf("%s%svalue.%s[%d] = %s_value[%d];\n",
		   sy->name,sref,mp_type_str(sy->s.type),i,
		   sy->name,i);
	  break;
	}
	printf("%s%salloc_ind = APLC_ALLOC_NFS;\n",
	       sy->name, sref );
        printf("%s%salloc_rank = 0;\n", sy->name,sref); 
        printf("%s%salloc_size = 0;\n", sy->name,sref); 


	/* this block isn't used ... */
	if ( is_apar(sy) ) {
	  printf("%s%stype = %s;\n", sy->name,sref, type_str(sy->s.type)); 
	  printf("%s%srank = %d;\n", sy->name,sref, sy->s.rank); 
	  printf("%s%sshape = %s_shape;\n", sy->name,sref, sy->name); 
	  printf("%s%ssize = %d;\n", sy->name,sref, sy->s.size); 
	  printf("%s%salloc_ind = APLC_ALLOC_NF;\n", sy->name,sref); 
	}
      } else {
	/* all not known - others may be ... */
	/* general case */
	printf("%s%stype = APLC_UKTYPE;\n", sy->name,sref);
	printf("%s%salloc_ind = APLC_UNALLOC;\n",sy->name,sref);
        printf("%s%salloc_rank = 0;\n", sy->name,sref); 
        printf("%s%salloc_size = 0;\n", sy->name,sref); 
      }
    } /* else not a variable - nothing to do */ 
    if ( is_apar(sy) ) {
      /* Normally expect known apars to be declared above.
	 If this is an assign parameter, and not declared, then the
	 caller may not know the type, rank, shape and so may not have
	 allocated space, hence we must do so now */
#if GDEBUG
      printf("/");printf("* name %s\n", sy->name);
      print_info(stdout, &sy->s);
      printf("*/\n");
#endif
      /*if ( (sy->s.info & TYPEKNOWN) && (sy->s.type != APLC_ANY) &&*/
      if ( TYPEisknown(sy) &&
	   ( sy->s.info & RANKKNOWN) &&
	   ( sy->s.info & SHAPEKNOWN ) ) {
	if ( !( (sy->s.info & TYPEDECL) && (sy->s.info & RANKDECL) ) ) {
	  printf("aplc_settrs(%s, %s, ", sy->name,
		 type_str(sy->s.type));  
	  printf("%d, %s_shape);\n", sy->s.rank, sy->name);
	  printf("aplc_talloc(%s);\n", sy->name);
	}
      }
    }
  } /* loop over symbol table */
  return;
}

/* search for GO -- goto -- in a function 
   -- note only need to look at the first node on a line */
static int
find_goto( struct statenode * code)
{
  struct statenode *p;
  int rv = 0;

  for (p = code; (!rv)&&(p != NILSTATE); p = p->nextstate) {
    if (p->code->nodetype == GO)
      rv = 1;
  }
  return rv;
}


/* doprog - process function */
void 
doprog(int type, struct headnode * head, struct symnode * syms, 
       struct statenode * code)
{
  struct statenode *p;
  struct symnode *sy;
  int i, flag_goto;

#if GDEBUG
  fprintf(stderr,"[doprog] %d\n", type);
#endif
  /* make available globally for searching */
  symtab = syms;

  switch(type) {
  default:
    /* should probably complain */
    fprintf(stderr, "Unknown prog type %d\n", type);
    break;

  case MNPROG:
  case PROG:
    /* generate function declaration 
       fn(result, left, right) */
    if (head == NILHEAD || head->opname == NILCHAR)  {
      /* we're in main */
      printf("/* ------------- main ------------- */\n");
      /* give the real (not forward) declarations for global variables */
      gen_syms_decl(syms);
      gcdcls();
      gen_const_dcls(code);
      /* Declare main as an int, and return 0         */
      printf("int\nmain(int argc, char *argv[]) {\n");
    } else {
      /* a function, not main */
      printf("/* ------------- %s ------------- */\n",head->opname);
      gcdcls();
      gen_const_dcls(code);
      gen_glocal_dcls(syms);
      if (head->asvar == NILCHAR)
	head->asvar = "_no1";
      if (head->parm1 == NILCHAR)
	head->parm1 = "_no2";
      if (head->parm2 == NILCHAR)
	head->parm2 = "_no3";
      /* ansi function declaration */
      printf("int\n%s", head->opname);
      printf("(struct trs_struct *%s, struct trs_struct *%s, struct trs_struct *%s)\n",
	     head->asvar, head->parm1, head->parm2);
      printf("{\n");

      /* give declarations for local variables */
      gen_syms_decl(syms);
    }
    break;

  case OPPROG:
    /* generate operator declaration 
       op(result, left, fnleft, fnright, right) */
    printf("/* ------------op %s ------------- */\n",head->opname);
    gcdcls();
    gen_const_dcls(code);
    gen_glocal_dcls(syms);
    if (head->asvar == NILCHAR)
      head->asvar = "_no1";
    if (head->parm1 == NILCHAR)
      head->parm1 = "_no2";
    if (head->parm2 == NILCHAR)
      head->parm2 = "_no3";
    if (head->lfname == NILCHAR)
      head->lfname = "_nof1";
    if (head->rfname == NILCHAR)
      head->rfname = "_nof2";
#if 1
    /* show the current symbol table, for debugging */
      if (syms) {
        printf("/* ");
        print_symtab(stdout, syms);           
        printf(" */\n");
      }
#endif
    /* print op header */
    printf("int\n%s", head->opname);
    printf("(struct trs_struct *%s, struct trs_struct *%s, ", 
	   head->asvar, head->parm1);
    /* allow the operands to be fn or var */
    sy = lookup_name(head->lfname, syms);
    if (sy && (sy->class == LFUNCTION) )
      printf(" int (*%s) (struct trs_struct *, struct trs_struct *, struct trs_struct *), ", head->lfname);
    else
      printf("struct trs_struct *%s,\n", head->lfname);
    sy = lookup_name(head->rfname, syms);
    if (sy && (sy->class == LFUNCTION) )
      printf(" int (*%s) (struct trs_struct *, struct trs_struct *, struct trs_struct *), ", head->rfname);
    else
      printf("struct trs_struct *%s,\n", head->rfname);
    printf("struct trs_struct *%s)\n", head->parm2);
    printf("{\n");

    /* give declarations for local variables */
    gen_syms_decl(syms);
    break;
  }

#if GDEBUG
  fprintf(stderr,"[doprog] decls\n");
#endif
  /* declare the statment number 
     - stmtno needs to be local to each fn */
  printf("int stmtno;\n");

  /* generate declarations for registers */
  if (head->maxtrs > 0) {
    printf("struct trs_struct ");
    for (i = 1; i <= head->maxtrs; i++) {
      printf("trs%d%c ", i, (i == head->maxtrs) ? ';' : ',');
      if (i % 10 == 9)
	nl();
    }
    nl();
  }
  if (head->maxmp > 0) {
    printf("union mp_struct ");
    for (i = 1; i <= head->maxmp; i++) {
      printf("mp%d%c ", i, (i == head->maxmp) ? ';' : ',');
      if (i % 10 == 9)
	nl();
    }
    nl();
  }
  if (head->maxres > 0) {
    printf("union res_struct res0, ");
    for (i = 1; i <= head->maxres; i++) {
      printf("res%d%c ", i, (i == head->maxres) ? ';' : ',');
      if (i % 10 == 9)
	nl();
    }
    nl();
  }
  /*printf("int i0%c ", (head->maxi) ? ',' : ';');*/
  /* sws  always make i0=0, for singleton indices */
  printf("int i0 = 0;/* for singleton indices */\n");
  if (head->maxi > 0) 
    printf("int ");
  for (i = 1; i <= head->maxi; i++) {
    printf("i%d%c ", i, (i == head->maxi) ? ';' : ',');
    if (i % 10 == 9)
      nl();
  }
  printf("/* end of declarations */\n\n");

  /* give initial values to variables */

  if (INMAIN) {
    /* input arguments made accessible */
    printf("aplc_setargs(argc, argv);\n");
  }

  /* generate pointers to aliases */
  gen_syms_alias(syms);

  /* initialize trs's */
  for (i = 1; i <= head->maxtrs; i++) {
    inittrs(i);
  }
  /* initialize local named trs's */
  gen_syms_init(syms);

  flag_goto = find_goto(code);
#if 0
  printf("\n/* flag_goto = %d */\n", flag_goto);
#endif
  if (flag_goto) {
    /* generate switch statement surrounding code */
    printf("\nstmtno = 1;\n");
    printf("while (stmtno)\n switch(stmtno) {\n");
    printf("default: stmtno = 0;\n   break;\n");
  }

  /* generate code for each statement */
  stmtno = 0;
  for (p = code; p != NILSTATE; p = p->nextstate) {
    stmtno++;
#if GDEBUG
    fprintf(stderr,"[doprog] [%d]\n", stmtno);
#endif
    if (p->label != NILCHAR) {
      /* add a comment before the code with the label name */
      for (i=0; (i<lctop) && (stmtno != lconsts[i].label_num); i++)
	;
      if (i<lctop)
	printf("/* %s: */\n", lconsts[i].label_name);
    }
    if (flag_goto) {
      printf("case %d: stmtno = %d;\n", stmtno, stmtno);
    }
    printf("aplc_trace(\"%s\", %d);\n", funname, stmtno);
    do_stmt(p->code);
  }

#if GDEBUG
  fprintf(stderr,"[doprog] ending\n");
#endif
  /* generate ending stuff */
  if (flag_goto) {
    printf("stmtno = 0;\n");
    rbr();/* ends switch statement */
  }
  /* free any local memory */
#ifdef DEBUGFREE
      printf("/* -- doprog finish */\n");
#endif
  for (sy = syms; sy != NILSYM; sy = sy->next)
    if (is_var(sy)) {
      printf("aplc_detalloc(&%s);\n", sy->name);
    }
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
  printf("return 0;\n");/* return value */
  rbr();/* ends  function */
  printf("\n");/* some extra space */
#if GDEBUG
  fprintf(stderr,"[doprog] done.\n");
#endif
  return;
}

/* 
   generate code for a statement - line of code

   - this checks to see if we have an early bind situation, where an
   assignment must completed first and then used later in the same
   statement

   */
static void
do_stmt(struct node *node)
{
#if GDEBUG
  fprintf(stderr,"do_stmt [%d] %s\n", stmtno, prtoken(node->nodetype));
#endif
  early_search(node);
  stcode(node);
#if GDEBUG
  fprintf(stderr,"do_stmt done.\n");
#endif
  return;
}

/* 
   - search through a statement for assign with EARLYBIND
   - if found, unset earlybind, run do_stmt starting there
   - then reset earlybind, so when we come back to node it will act like an ident 

   (- then set earlydone, so when we come back to node it will act like an ident )
 */
static void
do_early(struct node *node)
{
#if GDEBUG
  fprintf(stderr,"do_early %s\n", node->left->namep);
#endif
  if (NULL == node)
    return;
  /* need to generate code here */
  node->n.info ^= EARLYBIND;  /* unset */
  do_stmt(node);
  node->n.info |= EARLYBIND;  /* now reset */
  return;
}

/* 
   search a statement starting at node for an assign node with EARLYBIND 
   - if found, stop and return that node 
   - if not found, return null
   */
static void 
early_search(struct node *node)
{
  /* fprintf(stderr,"early_search\n");*/
  if (NULL == node)
    return;
#if GDEBUG
  fprintf(stderr,"early_search not null (%d) %s\n", 
	  node->nodetype,
	  prtoken(node->nodetype));
#endif
  if ( (node->nodetype == ASSIGN ) &&
       (node->n.info & EARLYBIND) ) {
    do_early(node);
    return;
  }
#if GDEBUG
  fprintf(stderr,"early_search funright\n");
#endif
  early_search(FUNRIGHT);
#if GDEBUG
  fprintf(stderr,"early_search funleft\n");
#endif
  early_search(FUNLEFT);
#if GDEBUG
  fprintf(stderr,"early_search right\n");
#endif
  early_search(RIGHT);
  if ( use_axis_node(node->nodetype) ) {
#if GDEBUG
    fprintf(stderr,"early_search axis\n");
#endif
    early_search(AXIS);
  }
#if GDEBUG
  fprintf(stderr,"early_search left\n");
#endif
  early_search(LEFT);
  return;
}

/* actually generate the code for statement starting at node 
   - run through all the statements */
static void
stcode(struct node *node)
{
#if GDEBUG
  fprintf(stderr,"stcode\n");
#endif
  switchbox(node, SHAPE, 1);
  switchbox(node, FINISH, 1);
  return;
}

/* lookup a name in the current symbol table */
extern struct symnode *
lookup_sym(char *name)
{
  return lookup_name(name, symtab);
}

/* end of gen.c */



