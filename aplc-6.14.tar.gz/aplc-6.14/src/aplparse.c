/*
        APL Compiler

        some routines for the parse stage
        included by apl.y

        Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.
*/

#include <ptree.h>

#define AYDEBUG 1
#define LISTDEBUG 0

/* for more debugging information on resolve_labels, set this to 1 */ 
#define DEBL 0

#define isFNCON(x) ((x->nodetype == FNCON) || ((x->nodetype == TERM) && (x->axis) && (x->axis->nodetype==FNCON)) )
#define isFNCONterm(x) ((x->nodetype == TERM) && (x->axis) && (x->axis->nodetype==FNCON))

/* line offset for listing */
int line_off = 0; 


/* note a single set of these also need to be declared for each pass, 
   in pass.c */ 

/* set of constants collected
   3 depths:
   0 global
   1 local, inside a fn
   2 local, inside a fn, used if a fn defn is inside a fn
*/
/*const_t pconsts[MAX_CONST_DEPTH];*/
const_t *pconstsp;/* pointer to current */
int prog_depth = 0;

/* all information for fns */
prog_t progs[MAX_PROG_DEPTH];  

extern int
get_funmode(void)
{
  return funmode;
}

extern enum classes
get_lexscope(void)
{
  return lexscope;
}

/* set pointer to global constants
   initialize */
extern void
init_constants(void)
{
  int k;

  prog_depth = -1;
  init_symtabs();
  setlocalcons();
  funname = "main";
  for (k=0; k<MAX_PROG_DEPTH; k++) {
    progs[k].pconsts.ic_top = 0;
    progs[k].pconsts.rc_top = 0;
    progs[k].pconsts.zc_top = 0;
    progs[k].pconsts.qc_top = 0;
    progs[k].pconsts.oc_top = 0;

  /* sws should we set sctop = 0?
   - currently not used; length of sconsts itself is checked */
    progs[k].pconsts.sc_top = 0;
    progs[k].pconsts.fnc_top = 0;
    progs[k].pconsts.lc_top = 0;
    progs[k].pconsts.s_consts[0] = '\0';
  }    
  return;
}

/* push depth
   setup new local pointers */
extern void 
setlocalcons_fn(char *file, int line)
{
  if (prog_depth >= 0) {
    /* save current fn name at new level 
       - note funname set before this */
    progs[prog_depth].name = name_strcpy(funname);
  }
  if (MAX_PROG_DEPTH <= ++prog_depth)
    error("[setlocalcons] maximum constant depth exceeded");
#if AYDEBUG
  fprintf(stderr,"[setlocalcons] %s %d, depth ->%d\n",
          file, line, prog_depth);
#endif
  pconstsp = &progs[prog_depth].pconsts;
  push_lsymtab();
  return;
}

/* reinit the current constant table, if it's local 
   - don't change the global table */
extern void
reinit_local_consts(void)
{
  int k = prog_depth;

  if (k > 0) {
    progs[k].pconsts.ic_top = 0;
    progs[k].pconsts.rc_top = 0;
    progs[k].pconsts.zc_top = 0;
    progs[k].pconsts.qc_top = 0;
    progs[k].pconsts.oc_top = 0;

  /* sws should we set sctop = 0?
   - currently not used; length of sconsts itself is checked */
    progs[k].pconsts.sc_top = 0;
    progs[k].pconsts.fnc_top = 0;
    progs[k].pconsts.lc_top = 0;
    progs[k].pconsts.s_consts[0] = '\0';
    /* note fnctop is only global */
  }
  return;
}

/* pop const & symtab stack  
   - with debugging info */
extern void 
resetconsts_fn(char *file, int line) 
{
  if (prog_depth < 1) {
    fprintf(stderr,"[resetconsts] minimum constant depth exceeded; kept at 0\n");
    return;
  }
  --prog_depth;
  /*pconstsp = &pconsts[prog_depth];*/
  funname = progs[prog_depth].name;
  pconstsp = &progs[prog_depth].pconsts;
#if AYDEBUG
  fprintf(stderr,"[resetconsts] %s %d, prog_depth->%d, (%s)\n", 
          file, line, prog_depth, funname);
  fprintf(stderr,"- ictop %d rctop %d fntop %d\n", 
          ictop, rctop, fnctop);
  {
    int i;
    for (i=0; i<MAX_PROG_DEPTH; i++) {
      if (progs[i].name)
      fprintf(stderr,"- %s depth %d ICTOP %d RCTOP %d FNTOP %d\n", 
              progs[i].name,
              i, ICTOP(i), RCTOP(i), FNCTOP(i));
      else
      fprintf(stderr,"- {} depth %d ICTOP %d RCTOP %d FNTOP %d\n", 
              i, ICTOP(i), RCTOP(i), FNCTOP(i));
    }
  }
#endif
  pop_lsymtab();
  return;
}

/* main routine for lexical parsing 
   sws: allow for some command line inputs
  -l  produce a listing aplc.list
  -l name  put listing in file name
*/
int
main(int argc, char **argv) 
{
  int i;
  char *fname;
  char *defname = "aplc.list";

  /* turn on bison trace */
  yydebug = 1;

  /* sws */
  fprintf(stderr,"APLc version 6.14  October, 2008 (sws)\n");
  fprintf(stderr,"Starting parse\n");

  fname = defname;
  dolist = 0;
  for (i=0; i<argc; i++) {
    /* fprintf(stderr,"argv[%d] = %s\n", i, argv[i]);*/
    if (argv[i][0] == '-')
      switch (argv[i][1]) {
      default:
        fprintf(stderr,"usage  parse -l or parse -l fname\n");
      case 'l':
        dolist = 1;
        if (argc>++i)
          fname = argv[i];
        break;
      }
  }
  if (dolist)
    listfile = fopen(fname,"w");
  yyparse();
  if (dolist)
    fclose(listfile);
  if (! errflag)
    exit(0);
  else
    exit(1);
}

/* called on return from lexer */
extern void
yyret_debug(void)
{
#if AYDEBUG
  fprintf(stderr, "[lex return] ");
  fprintf(stderr, "last tokens: 0:%s, 1:%s, ", 
          prtoken(last_token[0]), prtoken(last_token[1]));
  yylist_print("RET");  
  fprintf(stderr, "[lret]\n");
#endif
#if LISTDEBUG
  fprintf(listfile, "[lex return] ");
  fprintf(listfile, "last tokens: 0:%s, 1:%s, ", 
          prtoken(last_token[0]), prtoken(last_token[1]));
  fprintf(listfile, "[lret]\n");
#endif
  return;
}

/* eventually remove this - it prints the lines the lexer sees */
extern void 
yylistf(void)
{
  /*
  if (!dolist)
    return;
  fprintf(listfile,"[%3d] %s\n", linenum, linebuf);*/
  ;
  return;
}

extern void
yylist_debug(char *s)
{
#if LISTDEBUG
  /*fprintf(listfile,"{%s:yytext[%s]}",s, yytext);  */
  fprintf(listfile,"{%s:yytext[%s] %d",s, yytext, yyleng);  
  fprintf(listfile,"(%3d)fm:%d lm:%d, oldbuf{%s}, linebuf{%s} ", 
          linenum-1, funmode,linemode, oldbuf, linebuf);
  fprintf(listfile,", linesofar{%s}, linepos %d, string_count %d}\n", 
          linesofar, linepos, string_count);
#if LISTDEBUG > 1
  fprintf(stderr,"{%s:yytext[%s]",s, yytext);  
  fprintf(stderr,"linepos %d,",linepos);  
  fprintf(stderr,"linebuf {%s},",linebuf);  
  fprintf(stderr,"linesofar {%s},",linesofar);  
  fprintf(stderr,"(%3d)fm:%d lm:%d oldbuf{%s} }", 
          linenum-1, funmode,linemode, oldbuf);
#endif
#endif
  return;
}

extern void
yylist_print(char *s)
{
#if LISTDEBUG
  fprintf(listfile,"{%s}",s);  
#if LISTDEBUG > 1
  fprintf(stderr,"{%s}",s);  
#endif
#endif
  return;
}


extern void
line_off_inc(void)
{
  line_off++;
  return;
}

extern void
line_off_neg(void)
{
  line_off *= -1;
  return;
}


/*

  funmode [0,1,2], for null, main, user fun 
  linemode [0, 1, 2] for (blank, comment), unnumbered, or normal line 

*/
extern void 
yylistfn(void)
{
  int ln, off;

  if (!dolist)
    return;

  /* the parser is behind the lexer */
  ln = linenum-1;
  /* reset if larger than 1 */
  if (line_off <0) {
    off = - line_off;
    line_off = 0;
  } else
    off = line_off;
#if LISTDEBUG
  /* for debugging */
  fprintf(listfile,"(%3d)fm:%d lm:%d oldbuf{%s}\n", ln, funmode,linemode, oldbuf);
#endif
#if LISTDEBUG > 1
  /* for debugging */
  fprintf(stderr,"(%3d)fm:%d lm:%d oldbuf{%s}\n", ln, funmode,linemode, oldbuf);
#endif
  switch(funmode) {
  default:
    break;
  case 0:
    /* not in main or a fn */
    fprintf(listfile,"%3d.       %s\n", ln, oldbuf);
    break;
  case 1:
    /* in main */
    if (linemode==0) 
      fprintf(listfile,"%3d.\n", ln);
    if (linemode==1) 
      fprintf(listfile,"%3d.       %s\n", ln, oldbuf);
    if (linemode==2) {
      mainlnum++;
      mainlnum -= off;
      fprintf(listfile,"%3d. [%3d] %s\n", ln, mainlnum, oldbuf);
    }
    break;
  case 2:
  case 3:
    /* in a user defined function or operator */
    if (linemode==0) 
      fprintf(listfile,"%3d.\n", ln);
    if (linemode==1) 
      fprintf(listfile,"%3d.       %s\n", ln, oldbuf);
    if (linemode==2) {
      funlnum++;
      funlnum -= off;
      fprintf(listfile,"%3d. [%3d] %s\n", ln, funlnum, oldbuf);
    }
    break;
  }
  linemode=2;
  return;
}

/* copy from yytext up to nl into linesofar */
extern void
yycopy2nl(void)
{
  char *cyytext, *clinebuf;
  int count = 0;

  /*fprintf(stderr,"\nyytext {%s}\n", yytext);
    fprintf(stderr,"linebuf {%s}\n", linebuf);*/
  clinebuf = linebuf;
  while (*clinebuf != 0) {
    /*fprintf(stderr,"+");*/
    clinebuf++;
  }
  cyytext = yytext;
  while (*cyytext != '\n') {
    /*fprintf(stderr,"=");*/
    if (count++ > MAXLINE)
      fprintf(stderr,"[yycopy2nl] count %d > %d\n", count, MAXLINE);
      error("[yycopy2nl] line too long");
    *clinebuf++ = *cyytext++;
  }
  *clinebuf = 0;
  /*fprintf(stderr,"linebuf(+) %s\n", linebuf);*/
  /*fprintf(stderr,"[yycopy2nl] count %d\n", count);*/
  return;
}

/* yyerror - print error messages
   sws  this now includes positioning the ^ at the error  */
extern void
yyerror(char *c)
{ 
  char lnum[20];

  if (linenum==1)
    strcpy(linebuf,linesofar);
  /* fprintf(stderr,"[yyerror] line %d, next token ",linenum);*/
  /*  fprintf(stderr, "%s\n", prtoken(yychar));*/
  fprintf(stderr,"[yyerror] line %d\n",linenum);
  fprintf(stderr,"[%d] %s\n",linenum, linebuf);
  sprintf(lnum,"[%d]",linenum);
  fprintf(stderr,"%*s\n", (int) (strlen(lnum) + linepos), "^");
  fprintf(stderr, "last tokens: %s, %s, ", 
          prtoken(last_token[0]), prtoken(last_token[1]));
  fprintf(stderr, "yytext= {%s}\n", yytext);
  error(c);
  return;
}

/* mnbody - output code for the main routine 
   called at the end of the file if we have main code */
extern void
mnbody(struct statenode *code)
{ 
  struct headnode *mnhead;

  resolvelabels_main(code);

#if AYDEBUG
  fprintf(stderr, "[mnbody] global symtab\n");
  print_symtab(stderr, *gsymtab);
  fprintf(stderr," consts: ictop %d, rctop %d, zctop %d, fnctop %d\n",
          ictop, rctop, zctop, fnctop);
#endif
  mnhead = newhead(NILCHAR, NILCHAR, NILCHAR);
  /* sws collect the code writing functions */
  writecode(MNPROG,mnhead,*gsymtab,code);
  fresyms(*gsymtab);
  frecode(code);
  return;
}

/* update symnode b based on symnode a */
extern void
update_info(struct symnode *b,  struct symnode *a)
{
  if (a->s.type != APLC_UKTYPE) {
    if (b->s.type != a->s.type) {
      if (b->s.type == APLC_UKTYPE) {
        b->s.type = a->s.type;
        b->s.info |= TYPEKNOWN | TYPEDECL;
      } else {
        fprintf(stderr,"[parse] Warning: type missmatch %s, type (%s) ",
                b->name, str_type_name(b->s.type));
        fprintf(stderr,"doesn't match declaration of %s, type (%s)\n",  
                a->name, str_type_name(a->s.type));
      } 
    }
  }
  if (a->s.rank != NORANK) {
    if (b->s.rank != a->s.rank) {
      if (b->s.rank == NORANK) {
        b->s.rank = a->s.rank;
        b->s.info |= RANKKNOWN | RANKDECL;
      } else {
        fprintf(stderr,"[parse] Warning: type missmatch %s, rank (%d) ",
                b->name, b->s.rank);
        fprintf(stderr,"doesn't match declaration of %s, rank (%d)\n",  
                a->name, a->s.rank);
      } 
    }
  }
  if (a->s.info & SHAPEKNOWN) {
    if ( !(b->s.info & SHAPEKNOWN) ) {
      b->s.shape = a->s.shape;
      b->s.info |= SHAPEKNOWN;
      b->s.size = a->s.size;
    }
  }
  return;    
}

/* reset symbol tables and constants */
extern void
pop_symb_const(void)
{
  /* reset local symbol table */
  reinit_local_symtab();
  reinit_local_consts();
  /* pop down */
  resetconsts();
  return;
}

/* prog - output code for functions (programs), 
   called when we have a function above 
   need:
   - headnode
   - code 
   - local consts
   - lsymtab
*/
extern void 
prog( struct headnode *head, struct statenode *code)
{
  enum classes ic;
  struct symnode *fn;  /* node for fn name (global) */
  struct symnode *var; /* node for asvar name (local) */ 

#if AYDEBUG
  /*fprintf(stderr,"[prog] %s <- %s %s %s\n", 
    head->asvar, head->parm1, head->fname, head->parm2 ); */
  fprintf(stderr,"[prog] ");
  if (head->asvar)
    fprintf(stderr,"%s <- ", head->asvar);
  if (head->parm1)
    fprintf(stderr,"%s ", head->parm1);
  fprintf(stderr,"%s ", head->opname);
  if (head->parm2)
    fprintf(stderr,"%s\n", head->parm2);
#endif
#if AYDEBUG
  fprintf(stderr, " %s local symtab\n", head->opname);
  print_symtab(stderr, *lsymtab);
  fprintf(stderr, " global symtab\n");
  print_symtab(stderr, *gsymtab);
#endif

  /* check on external function definition vs internal definition
     - promote one or the other if possible 
     - this is probably already done?! 
  */
  if (NILCHAR != head->asvar) {
    /* look up the name, should be class FUNCTION */
    ic = idclass(head->opname, &fn);
#if AYDEBUG
    fprintf(stderr,"fun   %s class %d, type %d, rank %d\n", 
            head->opname, (int)ic, fn->s.type, fn->s.rank);
    print_info(stderr, &fn->s);fprintf(stderr,"\n");
#endif
    /* if type is known, declare type of asvar */ 
    ic = idclass(head->asvar, &var);
#if AYDEBUG
    fprintf(stderr,"asvar %s class %d, type %d, rank %d\n", 
            head->asvar, (int)ic, var->s.type, var->s.rank);
    print_info(stderr, &var->s);fprintf(stderr,"\n");
#endif
    update_info(fn, var);
    update_info(var, fn);
#if AYDEBUG
    fprintf(stderr,"fun   %s class %d, type %s, rank %s\n", 
            head->opname, (int)ic, str_type_name(fn->s.type), 
            str_rank(fn->s.rank));
    fprintf(stderr,"asvar %s class %d, type %s, rank %s\n", 
            head->asvar, (int)ic, str_type_name(var->s.type), 
            str_rank(var->s.rank));
#endif
  }
#if AYDEBUG
  fprintf(stderr, " %s final local symtab\n", head->opname);
  print_symtab(stderr, *lsymtab);
  fprintf(stderr, " final global symtab\n");
  print_symtab(stderr, *gsymtab);

  fprintf(stderr," consts: ictop %d, rctop %d, zctop %d, fnctop %d\n",
          ictop, rctop, zctop, fnctop);
#endif

  resolvelabels(code, lconsts);
  resolve_delta(code, head->opname);

  /* sws collect the code writing functions */
  writecode(PROG,head,*lsymtab,code);
  fresyms(*lsymtab);
  frecode(code);
  pop_symb_const();
#if AYDEBUG
  fprintf(stderr,"[prog] done with %s.\n", head->opname);
#endif
  return;
}

/* opprog - output code for operators (programs), 
   called when we have a function above */
extern void 
opprog( struct headnode *head, struct statenode *code)
{
  enum classes ic;
  struct symnode *fn; 
  struct symnode *var; 

#if AYDEBUG
  /*fprintf(stderr,"[opprog] %s <- %s (%s %s %s) %s\n", 
          head->asvar, head->parm1, 
          head->lfname, head->opname, head->rfname, head->parm2 ); */
  fprintf(stderr,"[opprog] ");
  if (head->asvar)
    fprintf(stderr,"%s <- ", head->asvar);
  if (head->parm1)
    fprintf(stderr,"%s ", head->parm1);
  fprintf(stderr,"(");
  if (head->lfname)
    fprintf(stderr,"%s ", head->lfname);
  fprintf(stderr,"%s ", head->opname);
  if (head->rfname)
    fprintf(stderr,"%s ", head->rfname);
  fprintf(stderr,") ");
  if (head->parm2)
    fprintf(stderr,"%s\n", head->parm2);

#endif

  /* check on external function definition vs internal definition
     - promote one or the other if possible 
     - this is probably already done?! 
  */
  if (NILCHAR != head->asvar) {
    /* look up the name, should be class OP  */
    ic = idclass(head->opname, &fn);
#if AYDEBUG
    fprintf(stderr,"op    %s class %d, type %d, rank %d\n", 
            head->opname, (int)ic, fn->s.type, fn->s.rank);
    print_info(stderr, &fn->s);fprintf(stderr,"\n");
#endif

    /* if type is known, declare type of asvar */ 
    ic = idclass(head->asvar, &var);
#if AYDEBUG
    fprintf(stderr,"asvar %s class %d, type %d, rank %d\n", 
            head->asvar, (int)ic, var->s.type, var->s.rank);
    print_info(stderr, &var->s);fprintf(stderr,"\n");
#endif
    update_info(fn, var);
    update_info(var, fn);

#if AYDEBUG
    fprintf(stderr,"op    %s class %d, type %s, rank %s\n", 
            head->opname, (int)ic, str_type_name(fn->s.type), 
            str_rank(fn->s.rank));
    fprintf(stderr,"asvar %s class %d, type %s, rank %s\n", 
            head->asvar, (int)ic, str_type_name(var->s.type), 
            str_rank(var->s.rank));
    fprintf(stderr, " [oprog] %s final local symtab\n", head->opname);
    print_symtab(stderr, *lsymtab);
    fprintf(stderr, " final global symtab\n");
    print_symtab(stderr, *gsymtab);
#endif
  }

  resolvelabels(code, lconsts);
  resolve_delta(code, head->opname);
  /* sws collect the code writing functions */
  writecode(OPPROG,head,*lsymtab,code);
  fresyms(*lsymtab);
  frecode(code);
  pop_symb_const();
#if AYDEBUG
  fprintf(stderr,"[opprog] done with %s.\n", head->opname);
#endif
  return;
}

/* resolve line labels in main
   - main shouldn't have any */
extern void
resolvelabels_main(struct statenode *code)
{
  int i;

#if DEBL
  /* print all labels */
  fprintf(stderr,"[rlm] labels (%d): ", lctop);
  for (i = 0; i < lctop; i++) {
    fprintf(stderr,"{%s},", lconsts[i].label_name);
  }
  fprintf(stderr,"\n");
#endif
  if (!lctop) 
    return;
  /* have to fix these */
  for (i = 0; i < lctop; i++) {
#if DEBL
    fprintf(stderr,"Looking for {%s}\n", lconsts[i].label_name);
#endif
    /* look through the code for this name */
    /* statement list */
    check_label(code, i, lconsts[i].label_name);
  }
  /* remove all from the list */
  lctop = 0;
#if DEBL
  fprintf(stderr,"[rlm] done\n");
#endif
  return;
}

/* given 
     a label name in lcon, 
     i index in lcon 
     code 
   turn into ident, if possible
*/
extern void 
check_label(struct statenode *code, int i, char *name)
{
  enum classes ic;
  struct symnode *var; 
  int ntype;
  struct statenode *y;

  /* look up the name */
  ic = idclass(name, &var);
#if DEBL
  fprintf(stderr,"[cl] class %d, %s\n", (int)ic, str_class(ic));
#endif
  if (ic == NOCLASS) {
    fprintf(stderr,"[check_label] name: [%s], class: %s (%d)\n", 
            name, str_class(ic), (int)ic);
    fprintf(stderr,"(unresoved symbol)\n");
    yyerror("unresolved label"); 
  }
  /* get node type 
     - can't really have a fn here; would be a parse error
     - param ought to be impossible; should have been caught already
     - labclass appears unused
   */
  switch(ic) {
  case GLOBAL: 
    if (var->s.type == APLC_LABEL) {
      fprintf(stderr,"[check_label] name: [%s], class: %s (%d)\n", 
              name, str_class(ic), (int)ic);
      yyerror("cannot have global label");
    }
    ntype = IDENT;
    break;
  case PARAM: 
    ntype = IDENT;
    break;
  case LOCAL:
    if (var->s.type == APLC_LABEL)
      ntype = LCON;
    else 
      ntype = IDENT;
    break;
  case FUNCTION: 
    ntype = FIDENT;
    break;
  case OPERATOR:
    ntype = OPIDENT;
    break;
  case LABCLASS:  
  case NOCLASS:
  default:
    ntype = UIDENT;
    break;
  }
#if 0
  fprintf(stderr,"[cl] class %d, type %d\n", 
          (int)ic, (int) var->s.type);
#endif
#if DEBL
  /* print all labels */
  fprintf(stderr,"[cl] changing to node type %s (%d)\n", prtoken(ntype), ntype);
  prtcode(code);
#endif
  for (y = code; y != NILSTATE; y = y->nextstate) {
    fixlabel(y->code, i, lconsts[i].label_name, ntype, var);
  }
  /* mark as invalid, for later cleanup */
  lconsts[i].valid = 0;
  return;
}

/* possibly change a label to an ident */
extern void
fixlabel( struct node *node, int i, char *name, 
          int ntype, struct symnode *var)
{
  /* search through nodes */
  switch (node->nodetype) {
  default:
    if (LEFT != NILP)
      fixlabel(LEFT,i, name, ntype, var);
    if (RIGHT != NILP)
      fixlabel(RIGHT,i, name, ntype, var);
      break;
  case LCON:
    /* see if it matches */
    if (node->n.values == i) {
#if DEBL
      /* print all labels */
      fprintf(stderr,"[fl] match (%d) %s\n", i, name);
#endif
      /* change the node from a label to an ident */
      node->nodetype = ntype;
      switch(ntype) {
      default:
        fprintf(stderr,"[fl] node type %d not handled\n", ntype); 
        yyerror("unresolved label");
        break;
      case IDENT:
        node->n.info = 0;
        node->namep = var->name;
        if ((var->s.type != APLC_UKTYPE) && (var->s.type != APLC_ANY))
          node->n.info |= (TYPEDECL | TYPEKNOWN);
        node->n.type = var->s.type;
        if (var->s.rank != NORANK)
          node->n.info |= (RANKDECL | RANKKNOWN);
        node->n.rank = var->s.rank;
        break;
      }
    }
    break;
  }
  return;
}

/* look through the label constants
   - find the name in the code to get the value */
extern void
resolvelabels(struct statenode *code, struct label_struct lar[])
{ 
  int i, j;
  struct statenode *y;

#if DEBL
  /* print all labels */
  fprintf(stderr,"[rl] labels (%d): ", lctop);
  for (i = 0; i < lctop; i++) {
    fprintf(stderr,"{%s},", lar[i].label_name);
  }
  fprintf(stderr,"\n");
#endif
  for (i = 0; i < lctop; i++) {
    j = 0;
#if DEBL
    fprintf(stderr,"[rl] %d label %s", i, lar[i].label_name);
#endif
    for (y = code; y != NILSTATE; y = y->nextstate) {
      j++;
      if ((y->label != NILCHAR) && 
          (strcmp(lar[i].label_name, y->label)) == 0) {
        lar[i].label_num = j;
        /* found a label; quit */
#if DEBL
        fprintf(stderr," = %d\n", j );
#endif
        break;
      }
    }
    if (y == NILSTATE) {
      /* couldn't resolve label - assume it's not a label then */
#if 0
      fprintf(stderr,"[resolvelabels] label (%s);\n",lar[i].label_name);
      fprintf(stderr," unresolved label or undeclared variable\n"); 
      yyerror("unresolved label");
#endif
      fprintf(stderr,"\n[rl] unresolved label or undeclared variable\n"); 
      fprintf(stderr," label (%s);\n",lar[i].label_name);
      fprintf(stderr," attempting to determine type\n"); 
      check_label(code, i, lconsts[i].label_name);
    }
  }
  /*  would like to do this, but not possible without changing all
      code references to the various lconsts...  
      lcon_clean();*/
  return;
}

/* search code
   change all FIDENT .delta nodes into FIDENT pname */
extern void
resolve_delta(struct statenode *code, char *pname)
{
  struct statenode *y;

  fprintf(stderr,"[resolve_delta]\n");

  /* process each line */
  for (y = code; y != NILSTATE; y = y->nextstate) {
    /* y->code is node; start of a line */
    resolve_delta_node(y->code, pname);
  }
  return;
}

/* search node and all sub-nodes 
   change all FIDENT .delta nodes into FIDENT pname */
extern void
resolve_delta_node(node_t *node, char *pname)
{
  if (!node)
    return;
  /* process node */
  if (node->nodetype == FIDENT) {
    fprintf(stderr,"[resolve_delta_node] FIDENT %s\n", node->namep);
    if (0 == strcmp(node->namep,".delta")) {
      fprintf(stderr,"[resolve_delta_node] .delta->%s\n", pname);
      /* rename */
      node->namep = pname;
      print_info(stderr, &node->n);fprintf(stderr,"\n");
    }
  }
  /* process sub nodes */
  if (node->left)
    resolve_delta_node(node->left, pname);
  if (node->right)
    resolve_delta_node(node->right, pname);
  if (node->axis)
    resolve_delta_node(node->axis, pname);
  if (node->funleft)
    resolve_delta_node(node->funleft, pname);
  if (node->funright)
    resolve_delta_node(node->funright, pname);
  return;
}

/* set by del_toggle - indication of local fn [0,1] */
int del_state = 0;
/* toggle fn for del 
 - note can't be nested ? */
extern void
del_toggle(void)
{
  if (del_state == 0) {
    /* starting fn definition
     - switch state before any expression */
    setlocalcons();
    del_state = 1;
  } else {
    /* ending fn def */
    del_state = 0;
    /* done in prog/oprog 
       resetconsts();*/
  }
  fprintf(stderr,"[del_toggle] %d\n", del_state);
  return;
}

/* toggle fn for back quote */
/* set by bqt_toggle - indication of local fn [0,1] */
int bqt_state = 0;
extern void
bqt_toggle(void)
{
  if (bqt_state == 0) {
    /* starting anon fn 
       - need to switch state before any expression */
    bqt_state = 1;
    setlocalcons();
  } else {
    /* ending anon fn */
    /* need to reset consts, lsymtab; don't clear though */
    bqt_state = 0;
    resetconsts();
  }
#if AYDEBUG
  fprintf(stderr,"[bqt_toggle] %d\n", bqt_state);
#endif
  return;
}

int cbracket_state = 0;
/* start of anonymous fn {} */
extern void
lcbracket(void)
{
  /* starting anon fn 
     - need to switch state before any expression */
  setlocalcons();
  cbracket_state++;
#if AYDEBUG
  fprintf(stderr,"[{cbs %d]\n", cbracket_state);
#endif
  return;
}

extern void
rcbracket(void)
{
  /* ending anon fn */
  /* need to reset consts, lsymtab; don't clear though */
  resetconsts();
  cbracket_state--;
#if AYDEBUG
  fprintf(stderr,"[}cbs %d]\n", cbracket_state);
#endif
  return;
}

/* error message for missplaced string */
extern void
err_expect(char *str)
{ 
  char buffer[100];

  sprintf(buffer, "expected %s found %s", str, yytext);
  yyerror(buffer);
  return;
}

/* ---------------------------------------------------------- */
/* new parsing utilities */

/* copy only a set of n nodes */
extern struct node *
copyNnodes(struct node *old, int n)
{
  struct node *xstart, *x;
  int i;

#if AYDEBUG
  fprintf(stderr,"[copyNnodes] %d\n", n);
#endif
  x = copy1node(old);
  xstart = x;
  for (i=1; i<n; i++) {
    if (!old->right)
      yyerror("[copyNnodes] bad right");
    x->right = copy1node(old->right);
    old = old->right;
    x = x->right;
  }
  return xstart;
}

/* copy1node - produce a copy of a parse tree node */
extern struct node *
copy1node(struct node *old)
{
  struct node *x;

  x = newnode(old->nodetype);

  x->left = NULL;
  x->right = NULL;
  x->funleft = NULL;
  x->funright = NULL;
#if 1
  if (old->axis)
    x->axis = copynode(old->axis);
#else
  x->axis = NULL;
#endif
  x->store = NULL;

  /*x->n = old->n;*/
  x->n.info   = old->n.info;
  x->n.type   = old->n.type;
  x->n.rank   = old->n.rank;
  x->n.shape  = old->n.shape;
  x->n.size   = old->n.size;
  x->n.values = old->n.values;
  x->n.oinfo = old->n.oinfo;

  x->namep = old->namep;
  x->namea = old->namea;

  x->optype = old->optype;
  x->symnode = old->symnode;
  x->index = old->index;

  x->ptr0 = old->ptr0;
  x->ptr1 = old->ptr1;

  return (x);
}

/* copynode - produce a copy of a parse tree node
   also copy left, right, etc attached nodes */
extern struct node *
copynode(struct node *old)
{
  struct node *x;

  x = newnode(old->nodetype);

  if (old->left)
    x->left = copynode(old->left);
  if (old->right)
    x->right = copynode(old->right);
  if (old->funleft)
    x->funleft = copynode(old->funleft);
  if (old->funright)
    x->funright = copynode(old->funright);
  if (old->axis)
    x->axis = copynode(old->axis);
  if (old->store)
    x->store = copynode(old->store);

  /*x->n = old->n;*/
  x->n.info   = old->n.info;
  x->n.type   = old->n.type;
  x->n.rank   = old->n.rank;
  x->n.shape  = old->n.shape;
  x->n.size   = old->n.size;
  x->n.values = old->n.values;
  x->n.oinfo = old->n.oinfo;

  x->namep = old->namep;
  x->namea = old->namea;

  x->optype = old->optype;
  x->symnode = old->symnode;
  x->index = old->index;

  x->ptr0 = old->ptr0;
  x->ptr1 = old->ptr1;

  return (x);
}

#if 0
#define FPE(x) fprintf(stderr,x);
#else
#define FPE(x) 
#endif

#define Match_nfield(field)   if (n1->field) {   \
                               if (n2->field) \
                                 val  = val && match_nodes(n1->field, n2->field);  \
                               else { \
                                 FPE("(no 2 field)\n"); \
                                 val = 0; \
                               } \
                              } else if (n2->field) { \
                                FPE("(no 1 field)\n"); \
                                val = 0; \
                              } \
                              if (!val) \
                                return val;

#define Match_field(field) if (n1->field != n2->field) \
                             return 0; 


/* copynode - produce a copy of a parse tree node
   also copy left, right, etc attached nodes */
extern int 
match_nodes(struct node *n1, struct node *n2)
{
  int val = 1;

  FPE("match_nodes.\n");
  Match_nfield(left);
  FPE("left.\n");
  Match_nfield(right);
  FPE("right.");
  Match_nfield(funleft);
  Match_nfield(funright);
  Match_nfield(axis);
  Match_nfield(store);
  FPE("nfields.");

  Match_field(n.info);
  Match_field(n.type);
  Match_field(n.rank);
  Match_field(n.shape);
  Match_field(n.size);
  Match_field(n.values);
  Match_field(n.oinfo);
  FPE("n.");

  Match_field(optype);
  Match_field(index);
  Match_field(ptr0);
  Match_field(ptr1);
  FPE("ptrs");

  val = val && name_strmatch(n1->namep, n2->namep);
  val = val && name_strmatch(n1->namea, n2->namea);

  return val;
}


/* copynode1 - produce a copy of a parse tree node 
   don't add others left/right */
extern struct node *
copynode1(struct node *old)
{
  struct node *x;

  x = newnode(old->nodetype);

#if 0
  if (old->left)
    x->left = copynode(old->left);
  if (old->right)
    x->right = copynode(old->right);
  if (old->funleft)
    x->funleft = copynode(old->funleft);
  if (old->funright)
    x->funright = copynode(old->funright);
  if (old->axis)
    x->axis = copynode(old->axis);
  if (old->store)
    x->store = copynode(old->store);
#endif

  /*x->n = old->n;*/
  x->n.info   = old->n.info;
  x->n.type   = old->n.type;
  x->n.rank   = old->n.rank;
  x->n.shape  = old->n.shape;
  x->n.size   = old->n.size;
  x->n.values = old->n.values;
  x->n.oinfo = old->n.oinfo;

  x->namep = old->namep;
  x->namea = old->namea;

  x->optype = old->optype;
  x->index = old->index;

  x->ptr0 = old->ptr0;
  x->ptr1 = old->ptr1;

  return (x);
}

/* get an FIDENT node reference to a function node
   -- need to create a fn if we don't have one */
extern node_t *
get_fn_node(node_t *fn)
{
  return symnode2node(get_fn_symnode(fn));
}

/* get a symnode reference to a (single) function node
   -- need to create a fn if we don't have one */
extern struct symnode *
get_fn_symnode(struct node *fn)
{
  struct symnode *fns = NULL;

#if AYDEBUG
  fprintf(stderr,"[get_fn_symnode] %s\n", prtoken(fn->nodetype));
#endif
  switch(fn->nodetype) {
    /* some cases where fn already exists: */
  case FNCON:
    fns = id_lookup(fn);
    break;
  case FIDENT:
    fns = fn->symnode;
    break;
  case TERM:
    if (fn->axis )
      fns = id_lookup(fn->axis);
    else
      yyerror("[get_fn_symnode] bad TERM node");
    break;

  case DROP:
  case TAKE:
  case RHO:
  case DSFUN:
  case MSFUN:
  default:
    /*if (fn->symnode) */
    if (fn->symnode != NILSYM) {
      fns = fn->symnode;
      break;
    }
    /*  .zeta .is F .omega :cond (0<#type .alpha) .alpha F .omega */
    /* build a new gobj, copy of current,
       add arguments
       then can use parse_node */
    {
      struct node *x, *y, *mon, *dyad, *test;
      struct symnode *sa, *so;
      struct node *om, *al;
      int val;
      int lexscope_old;

      /* toggle scope, as for `  */
      /*bqt_toggle();*/
      lcbracket();
      /*setlocalcons();*/
      lexscope_old = lexscope;
      lexscope = LOCAL;
      /* see if we need to call as monadic/dyadic/ambivelent */
      val = get_valence(fn->nodetype);
      sysparm("_zeta");
      x = sysparm("_omega");
      idclass("_omega",&so);
      if (val>1) {
        y = sysparm("_alpha");
        idclass("_alpha",&sa);
      }
#if AYDEBUG
      fprintf(stderr," [fn] building anon for valence %d\n", val);
#endif
      om = newnode(TERM);
      om->axis = x;
      if ( (val==1) || (val==3)) {
        /* build monadic invocation */
        /* build a gobj */
        mon = cat_gobj(copy1node(fn), om);
#if AYDEBUG
        fprintf(stderr," [cat mon done]\n");
#endif
      }
      if ( (val==2) || (val==3)) {
        /* build dyadic invocation */
        /*y = sysparm("_alpha");
          idclass("_alpha",&sa);*/
        /* build a gobj */
        al = newnode(TERM);
        al->axis = y;
        dyad = cat_gobj( cat_gobj(al,copy1node(fn)), om);
#if AYDEBUG
        fprintf(stderr," [cat dyad done]\n");
#endif
      }
      if ( val==3 ) {
        /* build test
           0 < #type .alpha*/
        test = pt2o(DSFUN, APLC_LT, ptval(BCON, addicon(0)), 
                    ptmsys(MSYSFUN, SYS_VTYPE, ptvar(sa)));
      }
      /* proceed the same way as {} 
         note final reset of syms, constants is done in ptanon(prog) */
      rcbracket();
      setlocalcons();
      switch(val) {
      case 1:
        x = ptanon(parse_gobj(mon));
        break;
      case 2:
        x = ptanon(parse_gobj(dyad));
        break;
      default:
      case 3:
        /* x is now a ref 
           build cond, call annon */
        x = ptanon(  ptcond(COND, parse_gobj(mon), test, parse_gobj(dyad)) );
        break;
      }
      fns = id_lookup(x);
      /*bqt_toggle();*/
      lexscope = lexscope_old;
    }
    break;
    /*yyerror("[get_fn_symnode] unknown fn node");*/
  }
#if AYDEBUG
  fprintf(stderr,"[get_fn_symnode] done: ");
  print_sym(stderr,fns);
#endif
  return fns;
}

/* get an FIDENT node reference to a function node
   -- need to create a fn if we don't have one */
extern node_t *
get_list_node(node_t *fn)
{
#if 0 == AYDEBUG
  return symnode2node(get_list_symnode(fn));
#else
  node_t *xx;
  xx = symnode2node(get_list_symnode(fn));
  fprintf(stderr,"[get_list_node] oinfo %d\n", xx->n.oinfo);
  return xx;
#endif
}

extern int
get_node_valence(node_t *x)
{
  switch(check_node_kind_parse(x)) {
  default:
  case PNK_VAL:
    return 0;
    break;
  case PNK_FN:
    if (x->nodetype == FIDENT) {
      if (x->n.oinfo & O_V_AMBIVALENT)
        return 3;
      else
        return 1;
    } else {
      return get_valence(x->nodetype);
    }
    break;
  case PNK_OP:
    if (check_op_valence(x) & O_V_AMBIVALENT)
      return 3;
    else
      return 1;
    break;
  }
  return 0;
}

/* get a symnode reference to a set of function nodes
   - need to create a fn if we don't have one 
   - assume we have a set of nodes in a chain 
     fn->left ... ->left = null */
extern struct symnode *
get_list_symnode(struct node *fn)
{
  struct symnode *fns = NULL;
  node_t *gend;
  const_t *pconstsp_last;
  int n;

  /*n = count_gobjlist(fn, gend);*/
  gend = count_gobjlist(fn, &n);
#if AYDEBUG
  fprintf(stderr,"[get_list_symnode] length %d\n", n);
  print_gobjlist(fn);
#endif
  if (1==n)
    return get_fn_symnode(fn);

  /*  .zeta .is F .omega :cond (0<#type .alpha) .alpha F .omega */
  /* build a new gobj, copy of current,
     add arguments
     then can use parse_node */
  {
    struct node *x, *y, *mon, *dyad, *test;
    struct symnode *sa, *so;
    struct node *om, *al;
    int val;
    int lexscope_old;

    pconstsp_last = pconstsp;
    /* toggle scope, as for `  */
    /*bqt_toggle();*/
    lcbracket();
    /*setlocalcons();*/
    lexscope_old = lexscope;
    lexscope = LOCAL;
    add_all_const(fn, pconstsp_last);
    /* see if we need to call as monadic/dyadic/ambivelent */
    /* val = get_valence(fn->nodetype);*/
    if (n==2) {
      /* test the rightmost node -- fn or op */
      val = get_node_valence(gend);
    } else {
      /* n==3; test middle op */
      val = get_node_valence(gend->left);
    }
    sysparm("_zeta");
    x = sysparm("_omega");
    idclass("_omega",&so);
    if (val>1) {
      y = sysparm("_alpha");
      idclass("_alpha",&sa);
    }
#if AYDEBUG
    fprintf(stderr," [list] building anon for valence %d\n", val);
#endif
    om = newnode(TERM);
    om->axis = x;
    if ( (val==1) || (val==3)) {
      /* build monadic invocation */
      /* build a gobj */
      mon = cat_gobj(copyNnodes(fn,n), om);
#if AYDEBUG
      fprintf(stderr," [cat list mon done]\n");
#endif
    }
    if ( (val==2) || (val==3)) {
      /* build dyadic invocation */
      /* build a gobj */
      al = newnode(TERM);
      al->axis = y;
      /*dyad = cat_gobj( cat_gobj(al,copynode(fn)), om);*/
      dyad = cat_gobj( cat_gobj(al, copyNnodes(fn,n)), om);
#if AYDEBUG
      fprintf(stderr," [cat list dyad done]\n");
#endif
    }
    if ( val==3 ) {
      /* build test
         0 < #type .alpha*/
      test = pt2o(DSFUN, APLC_LT, ptval(BCON, addicon(0)), 
                  ptmsys(MSYSFUN, SYS_VTYPE, ptvar(sa)));
    }
    /* proceed the same way as {} 
       note final reset of syms, constants is done in ptanon(prog) */
    rcbracket();
    setlocalcons();
    switch(val) {
    case 1:
      x = ptanon(parse_gobj(mon));
      break;
    case 2:
      x = ptanon(parse_gobj(dyad));
      break;
    default:
    case 3:
      /* x is now a ref 
         build cond, call annon */
      x = ptanon(  ptcond(COND, parse_gobj(mon), test, parse_gobj(dyad)) );
      break;
    }
    fns = id_lookup(x);
    /*bqt_toggle();*/
    lexscope = lexscope_old;
  }
#if AYDEBUG
  fprintf(stderr,"[get_list_symnode] done: ");
  print_sym(stderr,fns);
#endif
  return fns;
}



/* simple parse of a value */
#define PV(g) parse_node(NILP,NILP,g,NILP,NILP)
#define PVC(g)  ((g)?parse_node(NILP,NILP,g,NILP,NILP):NILP)

/* - turn a set of nodes into a tree
   - fix and copy a terminal node 
   note that right is already converted to a tree    */
extern struct node *
parse_node(struct node *left, struct node *fnleft, 
           struct node *node, 
           struct node *fnright, struct node *right)
{
  struct node *x, *leftp, *fL, *fR;
  int optype;

#if AYDEBUG
  /*fprintf(stderr,"[parse_node] %s\n", prtoken(node->nodetype));*/
  fprintf(stderr,"[parse_node] ");
  print_gobj(node);
  fprintf(stderr,"\n");

  if (LEFT)
    fprintf(stderr,"  [node->left] %s\n", prtoken(LEFT->nodetype));
  if (AXIS)
    fprintf(stderr,"  [node->axis] %s\n", prtoken(AXIS->nodetype));
  if (RIGHT)
    fprintf(stderr,"  [node->right] %s\n", prtoken(RIGHT->nodetype));

  if (left)
    fprintf(stderr,"  [left] %s\n", prtoken(left->nodetype));
  /*  if (fnleft)
      fprintf(stderr,"  [funleft] %s\n", prtoken(fnleft->nodetype));*/
  if (fnleft) {
    fprintf(stderr,"  [funleft] "); print_gobj(fnleft); fprintf(stderr,"\n");
  }
  if (fnright)
    fprintf(stderr,"  [funright] %s\n", prtoken(fnright->nodetype));
  if (right) {
    fprintf(stderr,"  [right] %s\n", prtoken(right->nodetype));
    if (right->left) {
      fprintf(stderr,"  [right->left] %s\n", prtoken(right->left->nodetype));
    }
  }
#endif

  switch(node->nodetype) {
  default:
    /* sterm: asysvar, sysvar, tcav, typecon, scon 
       avec, nvec, narray, exparray quad, qquad     */
    /*yyerror("[parse_node] ??\n");*/
    /* force left to null */
    node->left = 0;
    x = copynode(node);
    break;

  case CATCH:
    x = pt2(CATCH,  left, right);
    break;

  case ASSIGN:
    if (!left) 
      yyerror("[parse_node] assign missing left");
    if (!right)
      yyerror("[parse_node] assign missing right");
    leftp = PV(left);
    switch (leftp->nodetype) {
    case SYSVAR:
      x = pt1o(ASYSVAR, leftp->optype, pt1(COLLECT, right)); 
      break;
    case QUAD: 
      x = ptqass(right);
      break;
    case QQUAD: 
      x = pt1(QQUADASSIGN,right);
      break;
    case QUADLZ:
      x = ptqlzass(right);
      break;
    case SUB: /* sub   ASSIGN expression */
      x = ptsub(leftp, right);
      break;
    default: /* aterm ASSIGN expression */
      if (leftp->nodetype==LCON) {
        x = pt2(ASSIGN, ptvar(
       enterid(leftp->namep, dclclass, APLC_UKTYPE, NORANK, NOVALENCE)), right);
      } else {
        x = pt2(ASSIGN, leftp, right);
      }
      break;
    }
    break;

  case CM:
    if (left)
      x = pt2a(CAT,NILP,LASTAXIS, PV(left), right);
    else 
      x = pt1(RAVEL,right);
    break;

  case DECODE:
    if (!left) 
      yyerror("[parse_node] decode missing left");
    x  = pt1ao(INNER, APLC_PLUS, NILP,
               pt2aos(DECODE, APLC_TIMES, NILP, FIRSTAXIS, PV(left), right), LASTAXIS);
    break;

  case DOMINO:
    if (left)
      x = pt2(MSOLVE, pt1(COLLECT, PV(left)), pt1(COLLECT, right));
    else
      x = pt1(DOMINO, pt1(COLLECT, right));
    break;

  case DROP:
    if (!left) 
      yyerror("[parse_node] drop missing left");
    x = pt2(DROP, pt1(CIVEC, PV(left)), pt1(COLLECT, right));
    break;

  case GWDROP:
    if (!left) 
      yyerror("[parse_node] gwdrop missing left");
    x = pt2(GWDROP, pt1(CIVEC, PV(left)), right);
    break;

  case ENCODE:
    if (!left) 
      yyerror("[parse_node] encode missing left");
    x = pt2(ENCODE, PV(left), right);
    break;

  case EPSILON:
    if (!left) 
      yyerror("[parse_node] epsilon missing left");
    x = pt2(EPSILON, PV(left), 
            ptsort(1, pt1(CVEC, pt1(RAVEL, right))));
    break;

  case EXECUTE:
    x = pt1(EXECUTE, pt1(COLLECT, right));
    break;

  case FORMAT:
    if (left)
      x = pt2(DFORMAT, pt1(COLLECT, PV(left)), pt1(COLLECT, right));
    else
      x = pt1(FORMAT, pt1(COLLECT, right));
    break;

  case FIDENT:
    if (right)
      if (left)
        x = ptfun(node->symnode,  PV(left), right);
      else
        x = ptfun(node->symnode,  NILP, right);
    else
      x = ptnilfun(node->symnode);
#if 0
    fprintf(stderr,"[parse_node] fident %s %s\n",x->namep,x->namea);
    print_info(stderr, &x->n);fprintf(stderr,"\n");
#endif
    break;

  case IOTA:
    if (left)
      x = pt2(INDEXOF, ptsort(1, pt1(CVEC,PV(left))), right);
    else 
      x = pt1(IOTA, pt1(CISCALAR,right));
    break;

  case LCARET:
    if (left) /* lt */
      x = pt2o(DSFUN, node->index, PV(left),right);
    else 
      x = pt1(BOX, pt1(CCOLLECT,right));
    break;
  case RCARET:
    if (left) /* gt */
      x = pt2o(DSFUN, node->index,PV(left),right);
    else 
      x = pt1(UNBOX, pt1(CCOLLECT,right));
    break;

  case LINK:
    if (!left) 
      yyerror("[parse_node] link missing left");
    x = pt2a(LINK, NILP, LASTAXIS, pt1(COLLECT,PV(left)), pt1(COLLECT,right));
    break;

  case INDEXFN:
    if (!left) 
      yyerror("[parse_node] indexfn missing left");
    x = pt2(INDEXFN, pt1(COLLECT,PV(left)), pt1(COLLECT,right));
    break;

  case MATCH:
    if (!left) 
      yyerror("[parse_node] match missing left");
    x = pt2(MATCH, pt1(COLLECT,PV(left)), pt1(COLLECT,right));
    break;

  case REVERSE:
    if (left)
      x = pt2a(ROTATE, NILP, node->index, PV(left),right);
    else
      x = pt1a(REVERSE, NILP, node->index, right);
    break;

  case RHO:
    if (left)
      x = pt2(RESHAPE, pt1(CIVEC,PV(left)),right);
    else 
      x = ptmrho(right);
    break;

  case ROLL:
    if (left)
      x = pt2(DEAL, pt1(CISCALAR, PV(left)), pt1(CISCALAR, right));
    else
      x = pt1(COLLECT, pt1(ROLL, right));
    break;

  case SORT:
    x = ptsort(node->index, pt1(CVEC, right));
    break;

  case TAKE:
    if (!left) 
      yyerror("[parse_node] take missing left");
    x = pt2(TAKE, pt1(CIVEC, PV(left)), pt1(COLLECT, right));
    break;

  case GWTAKE:
    if (!left) 
      yyerror("[parse_node] gwtake missing left");
    x = pt2(GWTAKE, pt1(CIVEC, PV(left)), right);
    break;

  case TRANS:
    if (left)
      x = pt2(DTRANS, pt1(CIVEC, PV(left)), right);
    else
      x = pt1(TRANS, right);
    break;

  case DSYSFUN:
    if (!left) 
      yyerror("[parse_node] dsysfun missing left");
    x = pt2o(DSYSFUN, node->index, pt1(COLLECT, PV(left)), pt1(COLLECT, right));
    break;

  case ESYSFUN:
    if (left)
      x = pt2o(DSYSFUN, node->index, pt1(COLLECT, PV(left)), pt1(COLLECT, right));
    else
      x = pt1o(MSYSFUN, node->index, pt1(COLLECT, right));
    break;

    case MSYSFUN:
      x = ptmsys(MSYSFUN, node->index, right);
      break;

    /* sfun */
  case MSFUN:
  case DSFUN:
    if (left)
      x = pt2o(DSFUN, node->index, PV(left),right);
    else 
      x = pt1o(MSFUN, node->index, right);
    break;

    /* operators */
  case APPLY:
    leftp = PVC(left);
    if (fnleft->nodetype == TERM)
      x = ptapplyfun(fnleft->axis, leftp, right);
    else
      x = ptapplyfun(fnleft, leftp, right);
    break;

  case AXISO:
    /* axis can be fn (a[x]) or op (+/[x]) 
       - op can only handle certain fns  */
    /*if (check_node_kind(NILP,node,NILP) == PNK_FN) {*/
    if ( !fnleft ) { 
      /* really function - SUB */
#if AYDEBUG
      fprintf(stderr," (axiso->sub)\n");
#endif
      if (!left) 
        yyerror("[parse_node] axiso/sub missing left");
      x = pt2(SUB, PV(left), right);
    } else {
      /* have fnleft; operator 
         -- note fnleft could be another operator */
#if AYDEBUG
      fprintf(stderr," (axisop)\n");
#endif
      /* Note we expect axis (fnright) to be (appropriate for SUB)
         (R)-SM-(ICON)
         - need to remove the SM */
      if (node->axis) {
#if AYDEBUG
        fprintf(stderr," axis %s\n", prtoken(node->axis->nodetype));
        fprintf(stderr," axis->right %s\n", prtoken(node->axis->right->nodetype));
#endif
        if (SM == node->axis->nodetype)
          node->axis = node->axis->right;
        else
          yyerror("[parse_node] CAT axis error");
      }
      /* have two main options:
         () F O V V   (a) f [x] b
         () O F O V V (a) f o [x] b 
      */
#if AYDEBUG
      fprintf(stderr," (fnleft kind %d)\n", check_node_kind(left,fnleft,node));
      if (left)
        fprintf(stderr," (left kind %d)\n", check_node_kind(NILP,left,NILP));
#endif
      if (check_node_kind(left,fnleft,node) == PNK_FN) {
        /* V F O V V  or  F O V V 
           V F [V] V  or  F[V] V */

        if (left) {/* dyadic form */
#if AYDEBUG
          fprintf(stderr," dyadic: a f[x] b\n");
#endif
          leftp = PV(left);
          switch(fnleft->nodetype) {
          default:
            yyerror("[parse_node] axis dyadic fn error"); 
            break;
          case CM:
            x = pt2a(CAT, node->axis, LASTAXIS, leftp,right);
            break;
          case LINK: /* link with axis not yet implemented */
            yyerror("link with axis nya");
            x = pt2a(LINK, node->axis, LASTAXIS, pt1(COLLECT,leftp), pt1(COLLECT,right));
            break;
          case BSLASH:
            x = pt2a(EXPAND, node->axis, node->index, leftp,right);
            break;
          case SLASH:
            x = pt2a(COMPRESS, node->axis, node->index, leftp,right);
            break;
          case REVERSE:
            x = pt2a(ROTATE, node->axis, node->index, leftp,right);
            break;
          }
        } else {/* monadic */
#if AYDEBUG
          fprintf(stderr," monadic: f[x] b\n");
#endif
          switch(fnleft->nodetype) {
          default:
            yyerror("[parse_node] axis monadic fn error"); 
            break;
          case REVERSE:
            x = pt1a(REVERSE, node->axis, node->index, right);
            break;
          }
        }
      } else {
        /* fnleft is an op */
        /* F O O V V : F O [x] V 
           or 
           V O O V V : V O [x] V */
#if AYDEBUG
        fprintf(stderr," (F/V) O [V] V\n");
#endif
        switch(fnleft->nodetype) {
        default:
          yyerror("[parse_node] axis left error"); 
          break;
        case BSLASH:
          /* can be scan or expand */
          if ( (check_node_kind(NILP, left, NILP) == PNK_FN) || isFNCON(left) ) {
            if (IsSimpleFn(left))
              x = pt1ao(SCAN, left->index, node->axis,right, BSLASH);
            else
              x = ptop(NILP, get_fn_node(left), 
                       lexop("aplc_scan",O_MONADIC_MONADIC), 
                       node->axis, right, (O_LF));
          } else {
            x = pt2a(EXPAND, node->axis, node->index, PV(left),right);
          }
          break;
        case SLASH:
          /* can be reduce or compress */
          if ( (check_node_kind(NILP, left, NILP) == PNK_FN) || isFNCON(left) ) {
            /*fprintf(stderr," (fun)/[x] b\n");*/
            /* F / V */
            if (IsSimpleFn(left))
              x = pt1ao(REDUCE, left->index, node->axis,right, SLASH);
            else
              x = ptop(NILP, get_fn_node(left), 
                       lexop("aplc_reduce",O_MONADIC_MONADIC), 
                       node->axis, right, (O_LF));
          } else {
            /* V / V */
            x = pt2a(COMPRESS, node->axis, node->index, PV(left), right);
          }
          break;
        } /* left type switch */
      } /* end of fnleft check */
    }/* end of axiso fn/op test */
    break;

  case BSLASH:
    /* can be expand or scan */
    if (!fnleft) 
      yyerror("[parse_node] backslash missing fnleft");
    if ( (check_node_kind(NILP, fnleft, NILP) == PNK_FN) || isFNCON(fnleft) ) {
      if (IsSimpleFn(fnleft))
        x = pt1ao(SCAN, fnleft->index, NILP, right, node->index);
      else
        x = ptop(left, get_fn_node(fnleft), 
                 lexop("aplc_scan",O_MONADIC_MONADIC), 
                 NILP, right, (O_LF));
    } else { 
      x = pt2a(EXPAND, NILP, node->index, PV(fnleft), right);
    }
    break;

  case SLASH:
    /* slash now always an op, but fnleft could be F or V */
    if (!fnleft) 
      yyerror("slash with no fnleft!");
    if ( (check_node_kind(NILP, fnleft, NILP) == PNK_FN) || isFNCON(fnleft) ) {
#if AYDEBUG
      fprintf(stderr," F/V\n");
#endif
      if (IsSimpleFn(fnleft))
        x = pt1ao(REDUCE, fnleft->index, NILP, right, node->index);
      else
        x = ptop(left, get_fn_node(fnleft), 
                 lexop("aplc_reduce",O_MONADIC_MONADIC), 
                 NILP, right, (O_LF));
    } else {
      /* fnleft is apparently a V */
#if AYDEBUG
      fprintf(stderr," V/V\n");
#endif
      x = pt2a(COMPRESS, NILP, node->index, PV(fnleft), right);
    } 
    break;

  case DOT:
    if (!fnleft)
      yyerror("[parse_node] dot with no fn left"); 
    if (!fnright)
      yyerror("[parse_node] dot with no fn right"); 
    /* could be inner or outer */
    /* ----------------------------- */
    if (fnleft->nodetype == OUTER) {
      /* outer product */
      if (!left) 
        yyerror("[parse_node] outer product missing left");
      if (IsSimpleFn(fnright))
        x = pt2o(OUTER, fnright->index, PVC(left), right); 
      else
        x = ptop(PVC(left), NILP, 
                 lexop("aplc_outer",O_F_DYADIC), 
                 get_fn_node(fnright), right, (O_LF | O_RF));
      x->n.oinfo |= O_VALENCE | O_F_DYADIC | O_V_AMBIVALENT;
      x->n.oinfo |= O_OPTYPE | (O_LF | O_RF);
    } else {
      /* ----------------------------- */
      /* inner product -- dyadic */
      /* assume both are user fns if one is ... */
      if (IsSimpleFn(fnleft)) {
        if (IsSimpleFn(fnright)) {
          /* simple case */
          x = pt1ao(INNER, fnleft->index, NILP,
                    pt2aos(INNERCHILD, fnright->index, NILP, FIRSTAXIS, 
                           PVC(left), right), LASTAXIS);
        } else {
          /* fnleft simple, right not */
          x = ptop(PVC(left), get_fn_node(fnleft), 
                   lexop("aplc_inner", O_F_DYADIC|O_V_AMBIVALENT), 
                   get_fn_node(fnright), right, (O_LF | O_RF));
        }
      } else {
        if (IsSimpleFn(fnright)) {
          /* fnleft not simple, right simple */
          x = ptop(PVC(left), get_fn_node(fnleft), 
                   lexop("aplc_inner", O_F_DYADIC|O_V_AMBIVALENT), 
                   get_fn_node(fnright), right, (O_LF | O_RF));
        } else {
          /* neither fnleft or right simple */
          x = ptop(PVC(left), get_fn_node(fnleft), 
                   lexop("aplc_inner", O_F_DYADIC|O_V_AMBIVALENT), 
                   get_fn_node(fnright), right, (O_LF | O_RF));
        }
      }
      x->n.oinfo |= O_VALENCE | O_F_DYADIC | O_V_AMBIVALENT;
      x->n.oinfo |= O_OPTYPE | (O_LF | O_RF);
    }
    break;

  case OPIDENT:
    optype = 0;
#if 0
    /* for now, only allow FoF */ 
    optype = O_VALENCE | O_OPTYPE | O_LF | O_RF;
#endif
    fprintf(stderr,"[parse_node: OPIDENT] type %d, kind %d, %s, %s, valence %s, optype %s", 
            node->nodetype, check_node_kind_parse(node),
            prtoken(node->nodetype), node->namep, 
            str_valence(node->n.oinfo),str_optype(node->n.oinfo));
    if (!(node->n.oinfo & O_VALENCE))
      yyerror("[parse_node OPIDENT] unknown operator valence");
    if (!(node->n.oinfo & O_OPTYPE))
      yyerror("[parse_node OPIDENT] unknown operator optype");

    if (fnleft) {
      if (node->n.oinfo & O_LF)
        fL = get_fn_node(fnleft);/* fL = symnode2node(get_fn_symnode(fnleft));*/
      else
        fL = PV(fnleft);
    } else {
      fL = NILP;
      yyerror("OPIDENT null fnleft");
    }
    if (fnright) {
      if (node->n.oinfo & O_RF)
        fR = get_fn_node(fnright);/*fR = symnode2node(get_fn_symnode(fnright));*/
      else
        fR = PV(fnright);
    } else
      fR = NILP;
    x = ptop(PVC(left), fL, node->symnode, fR, right, optype);
    break;

    /* terminals -- the real contents is in the axis */
  case ATERM:
  case TERM:
    x = copynode(node->axis);
    break;
  }
  return x;
}

/* check the valence of an operator (value valence) (function valence)
   return either 
   00 monadic monadic       (F O) w
   01 dyadic  monadic       (F O G) w
   02 monadic ambivalent  a (F O) w
   03 dyadic  ambivalent  a (F O G) w
   */
extern int
check_op_valence( struct node *x )
{
  switch(x->nodetype) {
  default:
  case AXISO:     /* axis  F[i] R or L F[i] R */
  case DOT:       /* inner V F.F V */
    return O_F_DYADIC | O_V_AMBIVALENT;
    break;

  case OPIDENT:
    /* each, or user defined */
    return x->n.oinfo;
    break;

  case APPLY:/* Fcon .apply R or L Fcon .apply R */
    return O_V_AMBIVALENT;
    break;

  case BSLASH: 
  case SLASH: /* +/ V, or V/V */
    return O_MONADIC_MONADIC;
    break;
  }
  return O_F_DYADIC | O_V_AMBIVALENT;
}

extern char *
str_node_kind( enum parse_node_kind kind )
{
  switch(kind) {
  case PNK_NONE: 
    return "";
    break;
  case PNK_FN: 
    return "FN";
    break;
  case PNK_OP: 
    return "OP";
    break;
  case PNK_VAL:
    return "VAL";
    break;
  }
  return "";
}

/* fn to check the kind of a node 
   - none, fn, op, or val */
extern enum parse_node_kind
check_node_kind(node_t *left, node_t *x, node_t *right)
{
  enum parse_node_kind kind;

#if AYDEBUG > 1
  fprintf(stderr,"[check_node_kind] %s\n", prtoken(x->nodetype));
#endif

  if (!x) {
    yyerror("[check_node_kind] invalid node"); 
    return PNK_NONE;
  }
  if (!x->nodetype) {
    yyerror("[check_node_kind] invalid node type"); 
    return PNK_NONE;
  }

  switch(x->nodetype) {
  case AXISO:
    if (left) {
      /* could be fn or op, depending on preceeding node */
      if ( ( check_node_kind(NILP, left, NILP) == PNK_FN ) ||
           ( check_node_kind(NILP, left, NILP ) == PNK_OP ) )
        kind= PNK_OP;
      else {
        kind= PNK_FN;
      }
    } else 
      kind= PNK_FN;
    break;

  case BSLASH:
  case SLASH:
    kind= PNK_OP;
    break;

  case APPLY:
  case DOT:
  case OPIDENT:
    kind = PNK_OP;
    break;

  case TERM:
    /* mosts TERMs really are; 
       allow FNCONs to be used as fns */
    if ((x->axis) && (x->axis->nodetype == FNCON)) {
#if AYDEBUG > 1
      fprintf(stderr," - [check_node_kind] checking axis: %s\n", prtoken(x->axis->nodetype));
#endif
      kind = check_node_kind(left, x->axis, right);
    } else
      kind = PNK_VAL;
    break;

  case FNCON:
    /* a value, unless 
     `f` val 
     op `f` val 
     `g` op `f` val 
     so then
     `f` `g` is F V */
    if ( ( right && ( (check_node_kind(NILP, right, NILP) == PNK_VAL) ||
                      (check_node_kind(NILP, right, NILP) == PNK_OP) ) ) ||
         ( left && (check_node_kind(NILP, left, NILP) == PNK_OP) ) )
      kind = PNK_FN;
    else
      kind = PNK_VAL;
    break;

  default:/* default is fn */
  case OUTER:
    kind= PNK_FN;
    break;

  case ATERM:
  case IDENT:
  case BCON:
  case ICON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case SCON:
  case LCON:
    kind = PNK_VAL;
    break;
  }
#if AYDEBUG > 1
  fprintf(stderr," - [check_node_kind] done %d\n", kind);
#endif
  return kind;
}

/* fn to check the kind of a node 
   - fn, op, or val 
   this version depends on the node having node->(left/right) if necessary */
extern enum parse_node_kind
check_node_kind_parse(node_t *x)
{
  enum parse_node_kind kind;

#if AYDEBUG > 1
  fprintf(stderr,"[check_node_kind_parse] %s\n", prtoken(x->nodetype));
#endif

  if (!x) {
    yyerror("[check_node_kind_parse] invalid node"); 
    return PNK_NONE;
  }
  if (!x->nodetype) {
    yyerror("[check_node_kind_parse] invalid node type"); 
    return PNK_NONE;
  }

  switch(x->nodetype) {
  case AXISO:
    if (x->left) {
      /* could be fn or op, depending on preceeding node */
      if ( ( check_node_kind_parse(x->left) == PNK_FN ) ||
           ( check_node_kind_parse(x->left) == PNK_OP ) )
        kind= PNK_OP;
      else {
        kind= PNK_FN;
      }
    } else 
      kind= PNK_FN;
    break;

  case BSLASH:
  case SLASH:
    kind= PNK_OP;
    break;

  case APPLY:
  case DOT:
  case OPIDENT:
    kind = PNK_OP;
    break;

  case ATERM:
    kind = PNK_VAL;
    break;

  case TERM:
    /* mosts TERMs really are; 
       allow FNCONs to be used as fns */
    if ((x->axis) && (x->axis->nodetype == FNCON)) {
#if AYDEBUG > 1
      fprintf(stderr," - [check_node_kind_parse] checking axis: %s\n", prtoken(x->axis->nodetype));
#endif
      kind = check_node_kind(x->left,x->axis,x->right);
    } else
      kind = PNK_VAL;
    break;

  case FNCON:
    /* a value, unless 
     `f` val 
     op `f` val 
     `g` op `f` val 
     so then
     `f` `g` is F V */
    if ( (x->right && ( (check_node_kind_parse(x->right) == PNK_VAL) ||
                        (check_node_kind_parse(x->right) == PNK_OP) ) ) ||
         (x->left && (check_node_kind_parse(x->left) == PNK_OP) ) )
      kind = PNK_FN;
    else
      kind = PNK_VAL;
    break;

  default:/* default is fn */
  case OUTER:
    kind= PNK_FN;
    break;
  }
#if AYDEBUG > 1
  fprintf(stderr," - [check_node_kind_parse] done %d\n", kind);
#endif
  return kind;
}

/* count the objects in a list, return the number, end object */
extern node_t *
count_gobjlist(node_t *glist, int *n)
{
  node_t *gtemp;
  node_t *gend;
  *n = 0;
  for (gtemp=glist; gtemp != NILP; gtemp=gtemp->right) {
    (*n)++;
    gend = gtemp;
  }
  return gend; 
}

extern int
const_size(int rank, int *shape)
{
  int s = 1;

  while(rank>0) {
    s *= *shape++;
    rank--;
  }
  return s;
}

extern int
add_nscon(char *ip, int n)
{
  int i, ic;

  if (n + strlen(sconsts) >= MAXCONSTS) 
    yyerror("[add_nscon] too many string consts");
  ic = slen(sconsts);
  for (i=0; i<n; i++) {
    sconsts[ic+i] = ip[i];
  }
  sconsts[ic+n] = '\0';
  return ic;
}

extern int 
add_nicon(int *ip,  int n)
{
  int i, ic;

  if (n + ictop > MAXCONSTS)
    yyerror("[add_nicon] too many integer consts");
  ic = ictop;
  for (i=0; i<n; i++)
    iconsts[ictop++] = *ip++;
  return ic;
}

extern int 
add_nrcon(double *ip,  int n)
{
  int i, ic;

  if (n + rctop > MAXCONSTS)
    yyerror("[add_nrcon] too many real consts");
  ic = rctop;
  for (i=0; i<n; i++)
    rconsts[rctop++] = *ip++;
  return ic;
}

extern int 
add_nzcon(double ip[2][MAXCONSTS], int k, int n)
{
  int i, ic;

#if AYDEBUG > 1
  fprintf(stderr,"[add_nzcon] k %d, n %d\n", k,n);
#endif
  if (n + zctop > MAXCONSTS) 
    yyerror("[add_nzcon] too many complex consts");
  ic = zctop;
  for (i=0; i<n; i++) {
    zconsts[0][zctop] = ip[0][k+i];
    zconsts[1][zctop++] = ip[1][k+i];
#if AYDEBUG > 1
    fprintf(stderr," (%g, %g)\n", ip[0][k+i], ip[1][k+i]);
#endif
  }
  return ic;
}

extern int 
add_nqcon(double ip[4][MAXCONSTS], int k, int n)
{
  int i, ic, j;

  if (n + qctop > MAXCONSTS)
    yyerror("[add_nqcon] too many quaternion consts");
  ic = qctop;
  for (i=0; i<n; i++) {
    for (j=0; j<4; j++) {
      qconsts[j][qctop] = ip[j][k+i];
    }
    qctop++;
  }
  return ic;
}

extern int 
add_nocon(double ip[2][MAXCONSTS], int k, int n)
{
  int i, ic, j;

  if (n + octop > MAXCONSTS)
    yyerror("[add_nocon] too many octonion consts");
  ic = octop;
  for (i=0; i<n; i++) {
    for (j=0; j<8; j++) {
      oconsts[j][octop] = ip[j][k+i];
    }
    octop++;
  }
  return ic;
}


/* add all constants into current local table 
   - need last table defined */
extern void
add_all_const(node_t *glist,  const_t *pconstsp_last)
{
  int n;

#if AYDEBUG 
  fprintf(stderr,"[add_all_const]\n");
#endif

  switch(glist->nodetype) {
  default:
    break;
  case FNCON:
  case LCON:
    fprintf(stderr," const type %d\n", glist->nodetype);
    yyerror("[add_all_const] unhandled const");
    break;

  case SCON:
    n = const_size(glist->n.rank, 
                   &pconstsp_last->i_consts[glist->n.shape]);
    if (glist->n.rank > 0)
      glist->n.shape = add_nicon(&pconstsp_last->i_consts[glist->n.shape],
                                 glist->n.rank);
    if (n > 0) {
      glist->n.values = add_nscon(&pconstsp_last->s_consts[glist->n.values], n);
    }
#if AYDEBUG > 1
    fprintf(stderr,"[add_all_const] scon r %d, s %d\n", 
            glist->n.rank, n );
#endif
    break;

  case BCON:
  case ICON:
    n = const_size(glist->n.rank, 
                   &pconstsp_last->i_consts[glist->n.shape]);
    if (glist->n.rank > 0)
      glist->n.shape = add_nicon(&pconstsp_last->i_consts[glist->n.shape],
                                 glist->n.rank);
    if (n > 0)
      glist->n.values = add_nicon(&pconstsp_last->i_consts[glist->n.values], n);
#if AYDEBUG > 1
    fprintf(stderr,"[add_all_const] icon r %d, s %d\n", 
            glist->n.rank, n );
#endif
    break;
  case RCON:
    n = const_size(glist->n.rank, &pconstsp_last->i_consts[glist->n.shape]);
    if (glist->n.rank > 0)
      glist->n.shape = add_nicon(&pconstsp_last->i_consts[glist->n.shape], glist->n.rank);
    if (n > 0)
      glist->n.values = add_nrcon(&pconstsp_last->r_consts[glist->n.values], n);
#if AYDEBUG > 1
    fprintf(stderr,"[add_all_const] rcon r %d, s %d\n", 
            glist->n.rank, n );
#endif
    break;
  case ZCON:
    n = const_size(glist->n.rank, &pconstsp_last->i_consts[glist->n.shape]);
    if (glist->n.rank > 0)
      glist->n.shape = add_nicon(&pconstsp_last->i_consts[glist->n.shape], glist->n.rank);
    if (n > 0) 
      glist->n.values = add_nzcon(pconstsp_last->z_consts, glist->n.values, n);
#if AYDEBUG > 1
    fprintf(stderr,"[add_all_const] zcon r %d, s %d\n", 
            glist->n.rank, n );
#endif
    break;
  case QCON:
    n = const_size(glist->n.rank, &pconstsp_last->i_consts[glist->n.shape]);
    if (glist->n.rank > 0)
      glist->n.shape = add_nicon(&pconstsp_last->i_consts[glist->n.shape], glist->n.rank);
    if (n > 0)
      glist->n.values = add_nqcon(pconstsp_last->q_consts, glist->n.values, n);
#if AYDEBUG > 1
    fprintf(stderr,"[add_all_const] qcon r %d, s %d\n", 
            glist->n.rank, n );
#endif
    break;
  case OCON:
    n = const_size(glist->n.rank, &pconstsp_last->i_consts[glist->n.shape]);
    if (glist->n.rank > 0)
      glist->n.shape = add_nicon(&pconstsp_last->i_consts[glist->n.shape], glist->n.rank);
    if (n > 0)
      glist->n.values = add_nocon(pconstsp_last->o_consts, glist->n.values, n);
#if AYDEBUG > 1
    fprintf(stderr,"[add_all_const] ocon r %d, s %d\n", 
            glist->n.rank, n );
#endif
    break;
  }
  if (glist->axis)
    add_all_const(glist->axis, pconstsp_last);
  if (glist->right)
    add_all_const(glist->right, pconstsp_last);

  return; 
}

/* print */
extern void
print_gobjlist(node_t *glist)
{
  node_t *gtemp;
  int n;

  n = 0;
  for (gtemp=glist; gtemp != NILP; gtemp=gtemp->right) {
    fprintf(stderr," (%d", ++n);
    print_gobj(gtemp);
#if 0
    print_info(stderr, &gtemp->n);fprintf(stderr,"\n");    
#endif
    fprintf(stderr," )\n");
  }
  fprintf(stderr," total length %d\n", n);
  return;  
}

/* single print */
extern void
print_gobj(node_t *gtemp)
{
  node_t *gaxis;

  if (!gtemp)
    yyerror("[print_gobj] invalid node");

  switch (gtemp->nodetype) {
  default:
    fprintf(stderr," type %d, kind %d, %s", 
            gtemp->nodetype, check_node_kind_parse(gtemp),
            prtoken(gtemp->nodetype));
    break;
  case FNCON:
    fprintf(stderr," type %d, kind %d, %s [%s][%s]", 
            gtemp->nodetype, check_node_kind_parse(gtemp),
            prtoken(gtemp->nodetype), 
            gtemp->namep, fnconsts[gtemp->n.values]);
    break;
  case TERM:
    gaxis = gtemp->axis;
    if (gaxis->nodetype==IDENT)
      fprintf(stderr," type %d, kind %d, %s: %s[%s]", 
              gtemp->nodetype, check_node_kind_parse(gtemp),
              prtoken(gtemp->nodetype),
              prtoken(gaxis->nodetype),gaxis->namep );
    else if (gaxis->nodetype==LCON)
      fprintf(stderr,"type %d, kind %d, %s: %s[%s]", 
              gtemp->nodetype, check_node_kind_parse(gtemp),
              prtoken(gtemp->nodetype),
              prtoken(gaxis->nodetype),
              lconsts[gaxis->n.values].label_name );
    else
      fprintf(stderr," type %d, kind %d, %s: %s", 
              gtemp->nodetype, check_node_kind_parse(gtemp),
              prtoken(gtemp->nodetype),
              prtoken(gtemp->axis->nodetype) );
    break;
  case FIDENT:
    fprintf(stderr," type %d, kind %d, %s, %s, valence %s", 
            gtemp->nodetype, check_node_kind_parse(gtemp),
            prtoken(gtemp->nodetype), gtemp->namep, 
            str_valence(gtemp->n.oinfo));
#if 0
    print_info(stderr, &gtemp->n);fprintf(stderr,"\n"); 
    print_info(stderr, &(gtemp->symnode->s));fprintf(stderr,"\n");    
#endif
    break;
  case OPIDENT:
    fprintf(stderr," type %d, kind %d, %s, %s, valence %s, optype %s", 
            gtemp->nodetype, check_node_kind_parse(gtemp),
            prtoken(gtemp->nodetype), gtemp->namep, 
            str_valence(gtemp->n.oinfo),str_optype(gtemp->n.oinfo));
    break;
  case DSFUN:
  case MSFUN:
    fprintf(stderr," type %d, kind %d, %s: %s", 
            gtemp->nodetype, check_node_kind_parse(gtemp),
            prtoken(gtemp->nodetype), str_sfun(gtemp->index));
    break;
  }
  return;  
}

/* ------------------------------------------------------ */

/* parsing structure used in the following functions */
/*static gparse_t gparse;*/
#define Pgk gparsep->gk
#define Pgp gparsep->gp
#define Pgend gparsep->gend
#define Pgtemp gparsep->gend
/*#define Pgtemp gtemp*/


/* parse a list, vector of objects, into a tree 
   return a pointer to the tree
*/
extern struct node *
parse_gobj(struct node *glist)
{
  /*struct node *gk;*/
  /*struct node *gend;*/
  /*struct node *gtemp;*/
  gparse_t gparse, *gparsep;
  struct node *gL, *gLF, *gRF;

  gparsep = &gparse;
#if AYDEBUG
  fprintf(stderr,"[parse_gobj] starting\n");
#endif
  /* get to the end */
  for (Pgk=glist; Pgk->right != NILP; Pgk=Pgk->right) {
    /* add in a link backwards */
    Pgk->right->left = Pgk;
  }
#if AYDEBUG
  print_gobjlist(glist);
#endif

  /* last point can be variable, constant, or niladic fn 
     - leaf   
     not operator:  (index  in term)
     back up 1 */
  /* put out end  */
  if (check_node_kind_parse(Pgk) == PNK_OP) {
    fprintf(stderr," ? O\n");
    yyerror("[parse_gobj] invalid stream?"); 
  }

  Pgend = parse_node(NILP,NILP, Pgk, NILP,NILP);
  Pgk = Pgk->left;
  /* - start at current position gk 
     - create parse tree in gend, adding more to the top 
     - advance gk backwards to start */
  while (Pgk != NILP) {
#if AYDEBUG
    /*fprintf(stderr," gk (%d)\n", Pgk->nodetype);*/
    fprintf(stderr," gk (%d) ", Pgk->nodetype);
    print_gobj(Pgk);
    fprintf(stderr,"\n");
#endif

    /* 
       - grab as large a single expression as possible going forwards
       - assume gk->right is already an exp  (V)
       - gk can be fn or op
       if fn
       gn->left can be nil, exp(var or fn), or op
       parse_one_group(gk) */
    switch(check_node_kind_parse(Pgk)) {
    default:
    case PNK_NONE:
      fprintf(stderr," PNK_NONE error\n");
      error("[parse_gobj] node type error");
      break;

    case PNK_FN: /* gk is FN */
#if AYDEBUG
      fprintf(stderr," ? F V\n");
#endif
      /* have F V; possibilities (5 terms):
.=missing
                       F V
                     V F V 
               (Od V) (F V) 

           ([F,V] Om) (F V)

                  V Od F V 
                V V Od F V 
   ([F,V] Od [F,V]) Od F V 
                  F Od F V 
                V F Od F V 
        ([F,V] Om)  Od F V       */
      /* could be monadic or dyadic */
      if (!(Pgk->left)) {
#if AYDEBUG
        fprintf(stderr," F V\n");
#endif
        /* no left: F V */
        Pgtemp = parse_node(NILP,NILP, Pgk, NILP,Pgend);
      } else {
#if AYDEBUG
        fprintf(stderr," () F V\n");
#endif
        switch( check_node_kind_parse(Pgk->left) ) {
        default:
        case PNK_FN:
#if AYDEBUG
          fprintf(stderr," (F) (F V)\n");
#endif
          /* no more parse possible, stop here */
          Pgtemp = parse_node(NILP,NILP, Pgk, NILP,Pgend);
          break;
        case PNK_VAL: /* gk->left is FN */
#if AYDEBUG
          fprintf(stderr," ? V F V\n");
#endif
          if ( Pgk->left->left 
               && (PNK_OP==check_node_kind_parse(Pgk->left->left)) 
               && (O_F_DYADIC & check_op_valence(Pgk->left->left)) ) {
            /* V on left will be grabbed by the op if the op is dyadic */
#if AYDEBUG
            fprintf(stderr," F V\n");
#endif
            Pgtemp = parse_node(NILP,NILP, Pgk, NILP,Pgend);
          } else {
#if AYDEBUG
            fprintf(stderr," V F V\n");
#endif
            /* dyadic: fn */
            Pgtemp = parse_node(Pgk->left, NILP, Pgk, NILP, Pgend);
            Pgk = Pgk->left;/* left-most term */
          }
          break;

        case PNK_OP: /* gk->left is OP */
          /* have O F V, but can only continue if O is FUN_DYADIC */ 
          if ( (O_F_DYADIC & check_op_valence(Pgk->left)) ) {
#if AYDEBUG
            fprintf(stderr," ? O F V\n");
#endif
            /* have O F V; possibilities:
                 F O F V 
               V F O F V 
                 V O F V 
               V V O F V 
 ([F,V] Od [F,V]) Od F V 
      ([F,V] Om)  Od F V
            */
            gRF = Pgk;/* the Rf */
            Pgk = Pgk->left;/* the op */
            if (!Pgk->left) {
              yyerror("[parse_gobj] invalid stream? Missing F left: () O F V"); 
              /* this may be ok?? */
            } else {
              gLF = Pgk->left;/* the Lf */
              switch( check_node_kind(NILP,gLF,NILP) ) {
              default:
              case PNK_OP:
                /* (O) O F V */
#if AYDEBUG
                fprintf(stderr,"(? O) O F V\n");
#endif
                Pgp = gLF;
                gLF = get_op_fp(gparsep);
                /* check for further left, starting at Pgp */
                if (!Pgp->left) {
#if AYDEBUG
                  fprintf(stderr," (F O) O F V\n");
#endif
                  Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
                  Pgk = Pgp;
                } else {
#if AYDEBUG
                  fprintf(stderr," () (F O) O F V\n");
#endif
                  switch( check_node_kind_parse(Pgp->left) ) {
                  default:
                  case PNK_OP:
                  case PNK_FN:
                    Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
                    Pgk = Pgp;
                    break;
                  case PNK_VAL:
                    Pgtemp = parse_node(Pgp->left, gLF, Pgk, gRF, Pgend);
                    Pgk = Pgp->left;
                    break;
                  }          
                }
                break;
              case PNK_FN:
                /* () F O F V */
                if ( !gLF->left ) {
                  /* monadic: F O F V */
#if AYDEBUG
                  fprintf(stderr," F O F V\n");
#endif
                  Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
                  Pgk = gLF;
                } else {
                  /* (VFO) F O F V */
                  switch( check_node_kind(NILP,gLF->left,gLF) ) { 
                  default:
                  case PNK_FN:
                    /* monadic: (F) F O F V */
#if AYDEBUG
                    fprintf(stderr," (F) F O F V\n");
#endif
                    Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
                    Pgk = gLF;
                    break;
                  case PNK_OP:
                    /* dyadic/monadic:  (O) F O F V or 
                       monadic/monadic: ((... O F) O F) V */
                    if (O_F_DYADIC & check_op_valence(Pgk->left)) {
#if 1 || AYDEBUG
                      fprintf(stderr," (... O F) O F V\n");
#endif
                      Pgp = Pgk->left;
                      gLF = get_op_fp(gparsep);
                      /* check for further left, starting at Pgp */
                      if (!Pgp->left) {
#if AYDEBUG
                        fprintf(stderr," (f) O F V\n");
#endif
                        Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
                        Pgk = Pgp;
                      } else {
#if AYDEBUG
                        fprintf(stderr," () (f) O F V\n");
#endif
                        switch( check_node_kind_parse(Pgp->left) ) {
                        default:
                        case PNK_OP:
                        case PNK_FN:
                          Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
                          Pgk = Pgp;
                          break;
                        case PNK_VAL:
                          Pgtemp = parse_node(Pgp->left, gLF, Pgk, gRF, Pgend);
                          Pgk = Pgp->left;
                          break;
                        }          
                      }
                      /*
                      yyerror("[parse_gobj] case not done"); 
                      Pgtemp = parse_node(NILP, NILP, Pgk, gRF, Pgend);
                      Pgk = gLF;*/

                    } else {
#if AYDEBUG
                      fprintf(stderr," (O) F O F V\n");
#endif
                      Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
                      Pgk = gLF;
                    }
                    break;
                  case PNK_VAL:
                    /* full: V F O F V */
#if AYDEBUG
                    fprintf(stderr," V F O F V\n");
#endif
                    Pgtemp = parse_node(gLF->left, gLF, Pgk, gRF, Pgend);
                    Pgk = gLF->left;
                    break;
                  }
                }
                break;

              case PNK_VAL:
                /* () V O F V */
                if ( !gLF->left ) {
                  /* monadic V O F V */
#if AYDEBUG
                  fprintf(stderr," V O F V\n");
#endif
                  Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
                  Pgk = gLF;
                } else {
                  /* (VFO) V O F V */
                  switch( check_node_kind(NILP,gLF->left,gLF) ) { 
                  default:
                  case PNK_FN:
                    /* monadic: (F) V O F V */
#if AYDEBUG
                    fprintf(stderr," (F) V O F V\n");
#endif
                    Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
                    Pgk = gLF;
                    break;
                  case PNK_OP:
                    /* monadic: (O) V O F V or
                                (O V) O F V ? */
#if AYDEBUG
                    fprintf(stderr," (O) V O F V\n");
#endif
                    Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
                    Pgk = gLF;
                    break;
                  case PNK_VAL:
                    /* full: V V O F V or 
                     (O V) V O F V ? */
#if AYDEBUG
                    fprintf(stderr," V V O F V\n");
#endif
                    Pgtemp = parse_node(gLF->left, gLF, Pgk, gRF, Pgend);
                    Pgk = gLF->left;
                    break;
                  }
                }
                break;
              }
            }
          } else {
            /* O is not FDYADIC, can't add op; stop here */
#if AYDEBUG
            fprintf(stderr," F V\n");
#endif
            Pgtemp = parse_node(NILP, NILP, Pgk, NILP, Pgend);
          }
          break;
        }
      }
      break;

    case PNK_OP: /* gk is OP */
#if AYDEBUG
      fprintf(stderr," ? O V\n");
#endif
      /* have O V; possibilities:
           (F,V) O V
         V (F,V) O V 
           F Om Om V -> (F Om) Om V
         F Od F Om V -> (F Od F) Om V
      or  (...O) O V*/
      if (!Pgk->left) {
        fprintf(stderr,"[parse_gobj] ERROR -- () O V : no op left arg\n");
        yyerror("[parse_gobj] invalid stream? (O V)"); 
      }
      gLF = Pgk->left;
      switch(check_node_kind_parse(gLF)) {
      default:
      case PNK_NONE: 
      case PNK_VAL:
      case PNK_FN: 
        if ( !gLF->left) {
          /* F O V */
#if AYDEBUG
          fprintf(stderr," (F|V) O V\n");
#endif
          Pgtemp = parse_node(NILP, gLF, Pgk, NILP, Pgend);
          Pgk = gLF;
        } else {
          /* x F O V; switch depending on x */
          switch(check_node_kind_parse(gLF->left)) {
          case PNK_VAL:
            /* V F O V */
#if AYDEBUG
            fprintf(stderr," V (F|V) O V\n");
#endif
            Pgtemp = parse_node(gLF->left, gLF, Pgk, NILP, Pgend);
            Pgk = gLF->left;
            break;
          case PNK_NONE: 
          case PNK_FN: 
            /* (F) (F O V) */
#if AYDEBUG
            fprintf(stderr,"(F) (F|V) O V\n");
#endif
            Pgtemp = parse_node(NILP, gLF, Pgk, NILP, Pgend);
            Pgk = gLF;
            break;
          case PNK_OP: 
            /* ... Om (F O V) 
               (... Od F) O V 
               V (... Od F) O V 
            */
            if (O_F_DYADIC & check_op_valence(gLF->left)) {
#if AYDEBUG
              fprintf(stderr," ... (f Od F) O V\n");
#endif
              Pgp = gLF;/* start at the fn */
              gLF = get_op_fp(gparsep);
              /* check for further left, starting at Pgp */
              if (!Pgp->left) {
                /* now parse as f O V */
                Pgtemp = parse_node(NILP, gLF, Pgk, NILP, Pgend);
                Pgk = Pgp;
              } else {
#if AYDEBUG
                fprintf(stderr," () (f Od F) O V\n");
#endif
                /* found something, check it out */
                switch( check_node_kind_parse(Pgp->left) ) {
                default:
                case PNK_OP:
                case PNK_FN:
                  Pgtemp = parse_node(NILP, gLF, Pgk, NILP, Pgend);
                  Pgk = Pgp;
                  break;
                case PNK_VAL:
                  Pgtemp = parse_node(Pgp->left, gLF, Pgk, NILP, Pgend);
                  Pgk = Pgp->left;
                  break;
                }          
              }
            } else {
#if AYDEBUG
              fprintf(stderr,"((F|V) O V)\n");
#endif
              Pgtemp = parse_node(NILP, gLF, Pgk, NILP, Pgend);
              Pgk = gLF;
            }
            break;
          }
        }
        break;
      case PNK_OP: 
        /* O O V 
           could be:
             ((F|V) Om) Om V
           V ((F|V) Om) Om V
           (... Om) Om) Om V
           in any case we need to create at least 1 anon fn for left 
         */
#if AYDEBUG
        fprintf(stderr," ? O O V\n");
#endif
        if ( !gLF->left) 
          yyerror("[parse_gobj] parse error: () O O V"); 
        /* grab as much as we can in a fn pointer */ 
        Pgp = gLF;
        gLF = get_op_fp(gparsep);
        /* check for further left, starting at Pgp */
        if (!Pgp->left) {
#if AYDEBUG
          fprintf(stderr," (F O) O V\n");
#endif
          Pgtemp = parse_node(NILP, gLF, Pgk, NILP, Pgend);
          Pgk = Pgp;
        } else {
#if AYDEBUG
          fprintf(stderr," () (F O) O V\n");
#endif
          switch( check_node_kind_parse(Pgp->left) ) {
          default:
          case PNK_OP:
          case PNK_FN:
            Pgtemp = parse_node(NILP, gLF, Pgk, NILP, Pgend);
            Pgk = Pgp;
            break;
          case PNK_VAL:
            Pgtemp = parse_node(Pgp->left, gLF, Pgk, NILP, Pgend);
            Pgk = Pgp->left;
            break;
          }          
        }
        break;
      }
      break;

    case PNK_VAL: /* gk is V */
#if AYDEBUG
      fprintf(stderr," V V\n");
#endif
      /* have V V; possibilities:
         F O V V
         V F O V V 
    
        .but F could be F OP, so also have
         F Om Od V V     -> (F Om) O V V  e.g. +/[1] x
         V F Od F Od V V -> V (F Od F) O V V    x +.*[1] y
      */
      /* better have an op further left */
      if (!Pgk->left)
        yyerror("[parse_gobj] invalid stream? (V V)"); 
      if ( check_node_kind_parse(Pgk->left) != PNK_OP )
        yyerror("[parse_gobj] invalid stream? (? V V)"); 
      /* FIXME the op should be F_DYADIC... */
      gRF = Pgk;
      Pgk = Pgk->left;
      /* better have an FN or OP further left */
      if (!Pgk->left)
        yyerror("[parse_gobj] invalid stream? (? O V V)"); 

      if (Pgk->nodetype == AXISO) {
        /* xx  old method */
        switch(check_node_kind_parse(Pgk->left)) { 
        default:
        case PNK_VAL:
#if 0
          /*yyerror("[parse_gobj] invalid stream? (V O V V)"); */
#if AYDEBUG
          fprintf(stderr," V O V V\n");
#endif
          Pgtemp = parse_node(gLF->left, gLF, Pgk, gRF, Pgend);
          Pgk = gLF->left;
          break;
#endif
        case PNK_FN:
          gLF = Pgk->left;
          /* check for VAL on left */
          /* nya -- allow (F O F) O V V ...   */
          if ( (gLF->left) && (check_node_kind(NILP,gLF->left,gLF) == PNK_VAL ) ) {
#if AYDEBUG
            fprintf(stderr," V F O V V\n");
#endif
            Pgtemp = parse_node(gLF->left, gLF, Pgk, gRF, Pgend);
            Pgk = gLF->left;
          } else {
#if AYDEBUG
            fprintf(stderr," F O V V\n");
#endif
            Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
            Pgk = gLF;
          }
          break;
        case PNK_OP:
          /* nya FIXME ? O O V V 
             -- except for axiso, this should be handled 
             in some recursive fashion */
          gLF = Pgk->left;/* op */
          if (Pgk->nodetype != AXISO)
            yyerror("[parse_gobj] case not handled (O O V V)"); 
          /* check for FN on left */
          if (!gLF->left) 
            yyerror("[parse_gobj] invalid stream? (O O V V)"); 
          if (check_node_kind(NILP,gLF->left,gLF) == PNK_OP)
            yyerror("[parse_gobj] case not handled (O O O V V)"); 
          gL = gLF->left;
          /* no room for a var... ? */
#if AYDEBUG
          fprintf(stderr," (V|F) O O V V?\n");
#endif
          Pgtemp = parse_node(gL, gLF, Pgk, gRF, Pgend);
          Pgk = gLF->left;
          break;
        } /* switch(Pgk->left) end */
      } else {
        /* xx just use new fn */
        Pgp = Pgk->left;
        gLF = get_op_fp(gparsep);
        /* check for further left, starting at Pgp */
        if (!Pgp->left) {
#if AYDEBUG
          fprintf(stderr," (F/V) O V V\n");
#endif
          Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
          Pgk = Pgp;
        } else {
#if AYDEBUG
          fprintf(stderr," () (F/V) O V V\n");
#endif
          switch( check_node_kind_parse(Pgp->left) ) {
          default:
          case PNK_OP:
          case PNK_FN:
            Pgtemp = parse_node(NILP, gLF, Pgk, gRF, Pgend);
            Pgk = Pgp;
            break;
          case PNK_VAL:
            Pgtemp = parse_node(Pgp->left, gLF, Pgk, gRF, Pgend);
            Pgk = Pgp->left;
            break;
          }          
        }
      }  /* xx */
      break;
    }

    /* - glue onto end; already done */
    /*Pgend = gtemp;*/
    /*- update gk */
    Pgk = Pgk->left;
  } /* end of while */
  return Pgend;
}

/*
  fp = get_op_fp
  create local fn for operator arguments

  - grabs longest fn exp on left -> anon fn
    start at Pgp, 
    Pgp could be V/F or O: (...Od F) or (...O) 
  - updates "line pointer" gp (or gLF or gL?)
  - recursive */
node_t * 
get_op_fp(gparse_t *gparsep)
{
  node_t *x, *xL, *xO;
  node_t *xend;

#if AYDEBUG
  fprintf(stderr,"[get_op_fp]  ");
  print_gobj(Pgp);
  fprintf(stderr,"\n");
#endif

  if (check_node_kind_parse(Pgp) == PNK_OP) {
    /* ... O   monadic op*/
#if AYDEBUG
    fprintf(stderr,"[get_op_fp]  ... O\n");
#endif
    if (O_F_DYADIC & check_op_valence(Pgp))
      yyerror("[get_op_fp] op must be monadic");
    if ( !Pgp->left) 
      yyerror("[get_op_fp] parse error: missing leftF for O "); 
    /* start at Pgp
       collect longest "fn" exp including the O
       if we hit another op, recurse */
    switch(check_node_kind_parse(Pgp->left)) {
    default:
    case PNK_VAL: 
      /* done; build fn from V O */
#if AYDEBUG
      fprintf(stderr,"  (V O)\n");
#endif
      Pgp->right = NILP;
      x = get_list_node(Pgp);
      Pgp = Pgp->left;
      break;

    case PNK_FN:
#if AYDEBUG
      fprintf(stderr,"  (F O)\n");
#endif
      Pgp->right = NILP;/* stop at the op */
      xO = Pgp;
      Pgp = Pgp->left;/* the F */
      /* could have another layer ... */
      xL = get_op_fp(gparsep);
      xL->right = xO;
      x = get_list_node(xL);
      break;

    case PNK_OP: 
      /* have another layer; recurse ... */
#if AYDEBUG
      fprintf(stderr,"  (O O)\n");
#endif
      Pgp->right = NILP;/* stop at the op */
      xO = Pgp;
      Pgp = Pgp->left;/* the next O */
      xL = get_op_fp(gparsep);
      xL->right = xO;
      x = get_list_node(xL);
      break;
    }
  } else {
    /* ... (F/V) 
     - possibly just F/V 
     - possibly dyadic O */
#if AYDEBUG
    fprintf(stderr,"[get_op_fp]  ... (F/V)\n");
#endif
    /* check for anything left */
    if ( ( !Pgp->left) || ( check_node_kind_parse(Pgp->left) != PNK_OP) 
         || (! (O_F_DYADIC & check_op_valence(Pgp->left))) ) {
      /* just (F/V) */
      return Pgp;
    }
    /* have ... Od (F/V)
       now expect a fn left of the op */
    xend = Pgp;
    xend->right = NILP;
    Pgp = Pgp->left;/* the op */
    xO = Pgp;
    if ( !Pgp->left) 
      yyerror("[get_op_fp] parse error: missing LF () O (F/V)"); 
    Pgp = Pgp->left; /* the LF */
    /* this may recurse */
    xL = get_op_fp(gparsep);
    xL->right = xO;
    x = get_list_node(xL);
  }
  /* create anon fn -- need generalized get_fn_(sym)node  */  
#if AYDEBUG
  fprintf(stderr,"[get_op_fp] done\n");
#endif
  return x;
}

#if 0
/* create anon fn -- generalized get_fn_(sym)node  
   need to get length 
   if length==1, call get_fn_node...

*/  
extern node_t *
get_gobj_node(struct node *glist)
{
  ;
}


 /*
 op_parse_gobj(struct node *gLF, struct node *gRF)

*/
extern void
op_parse_gobj(struct node *gLF, struct node *gR)
{
  /* 
     need something like
     get_fn_node(node_t *fn) (one fn node -> anon fn)
     but for a set of nodes (set of nodes) -> anon fn
     ...
     update Pgtemp
     update Pgk
   */
  return;
}
#endif

/* end */
