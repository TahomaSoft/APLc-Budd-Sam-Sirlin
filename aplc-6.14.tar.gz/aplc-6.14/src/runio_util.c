/* runio_f.c

 APL Compiler - Run Time System

 - input/output print utilities

	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

/* ------------------------------------------------------------ */
/* some important defines, so see what we should include */
#include <aplc_config.h>

/* sws  for file io */
#include <stdio.h>
#include <stdlib.h>

#if HAVE_STRING_H
/* sws  for trs2str */
#include <string.h>
#endif

#if HAVE_SYS_TYPES_H
#include <sys/types.h>
#endif

#if HAVE_FCNTL_H
/* sws for open */
#include <fcntl.h>
#endif

#if TIME_WITH_SYS_TIME 
#include <sys/time.h>
#include <time.h>
#else
#if HAVE_SYS_TIME_H
#include <sys/time.h>
#else
#include <time.h>
#endif 
#endif

#if HAVE_SYS_STAT_H 
/* sws  to get file sizes */
#include <sys/stat.h>
#endif

#if HAVE_UNISTD_H
/* jbww to get dup, pipe, fork; sws to get usleep for fbsd */
#include <unistd.h>
#endif

#if HAVE_TERMIOS_H 
/* jbww to get file control */
#include <termios.h>
#endif

#include "aplc.h"
#include "run.h"


/* sws
   aplc_print_trs
   - print a trs structure
   - for debugging 
   */
void
aplc_print_trs(struct trs_struct *res) 
{
  int i, s;

  printf("type %d, rank %d, size %d\n", 
	 res->type, res->rank, res->size);
  printf(", alloc_ind %d, alloc_type %d, alloc_rank %d, alloc_size %d\n", 
	 res->alloc_ind, res->alloc_type, res->alloc_rank,res->alloc_size);
  printf("shape ");
  if (res->rank != 0) {
    for (i=0; i<res->rank; i++)
      printf(" %d", res->shape[i]);
    printf("\n");
  }
  else
    printf("(scalar)\n");
  printf("values {");
  s = aplc_vsize(res->rank, res->shape);
  for (i=0; i<s; i++)
    switch(res->type) {
    default:
      printf(" ?");
      break;
    case APLC_BOOL:
    case APLC_INT:
      printf(" %d", res->value.ip[i]);
      break;
    case APLC_REAL:
      printf(" %g", res->value.rp[i]);
      break;
    case APLC_CHAR:
      printf(" %c", res->value.cp[i]);
      break;
    case APLC_BOXED:
      printf(" {");
      aplc_print_trs( &res->value.trsp[i] );
      printf("} ");
      break;
    }
  printf("}\n");
}

/* sws 
   print an integer vector with a name, for debugging
   later move this to runio?  */
extern void
aplc_fprintf_ivec(FILE *p, char *s, int *v, int n)
{
  int k;

  fprintf(p,"%s = {", s);
  for (k=0; k<n; k++)
    fprintf(p," %d", v[k]);
  fprintf(p,"}\n");
  return;
}

/* end */
