/* 
 3/23/2007 sws
 APL Compiler parsing functions 

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLPARSE_H
#define _APLPARSE_H

/* simple scaler fn used in original operators */
#define IsSimpleFn(x)  ( (x->nodetype == MSFUN)  ||  \
                         (x->nodetype == DSFUN)  ||  \
                         (x->nodetype == LCARET) ||  \
                         (x->nodetype == RCARET) )

extern int get_funmode(void);
extern enum classes get_lexscope(void);
extern void init_constants(void);
extern void setlocalcons_fn(char *file, int line);
extern void reinit_local_consts(void);
extern void resetconsts_fn(char *file, int line);
extern void yyret_debug(void);
extern void yylistf(void);
extern void yylist_debug(char *s);
extern void yylist_print(char *s);
extern void line_off_inc(void);
extern void line_off_neg(void);
extern void yylistfn(void);
extern void yycopy2nl(void);
extern void yyerror(char *c);
extern void mnbody(struct statenode *code);
extern void update_info(struct symnode *b,  struct symnode *a);
extern void pop_symb_const(void);
extern void prog( struct headnode *head, struct statenode *code);
extern void opprog( struct headnode *head, struct statenode *code);
extern void resolvelabels_main(struct statenode *code);
extern void check_label(struct statenode *code, int i, char *name);
extern void fixlabel( struct node *node, int i, char *name, 
		      int ntype, struct symnode *var);
extern void resolvelabels(struct statenode *code, struct label_struct lar[]);

extern void resolve_delta(struct statenode *code, char *pname);
extern void resolve_delta_node(node_t *node, char *pname);

extern void del_toggle(void);
extern void bqt_toggle(void);

extern int cbracket_state;
extern void lcbracket(void);
extern void rcbracket(void);

extern void err_expect(char *str);

#if 0
extern void oplist_vfofv(struct node *vL, 
			 struct symnode *fL, struct symnode *op, struct symnode *fR, 
			 struct node *vR);
extern void oplist_nfofv(struct symnode *fL, struct symnode *op, struct symnode *fR, 
			 struct node *vR);
extern void oplist_vfov(struct node *vL, 
			struct symnode *fL, struct symnode *op, 
			struct node *vR);
extern void oplist_fov( struct symnode *fL, struct symnode *op, 
			struct node *vR);

extern void opcheck_1_fov(struct node *fL, struct symnode *op, struct node *vR);
extern void opcheck_2_vfov(struct node *vL, struct node *fL,
			   struct symnode *op, struct node *vR);
extern void opcheck_2_vfofv(struct node *t1, struct node *t2,
			    struct symnode *t3, struct symnode *t4, 
			    struct node *t5);
extern void opcheck_3_fofv(struct symnode *t1, struct symnode *t2, 
			   struct node *t3, struct node *t4);
#endif

extern struct node *copyNnodes(struct node *old, int n);
extern struct node *copy1node(struct node *old);
extern struct node *copynode(struct node *old);
extern int match_nodes(struct node *n1, struct node *n2);

extern node_t *get_fn_node(node_t *fn);
extern struct symnode *get_fn_symnode(struct node *fn);

extern node_t *get_list_node(node_t *fn);
extern struct symnode *get_list_symnode(struct node *fn);

extern struct node *parse_node(struct node *left, struct node *fnleft, 
			       struct node *node, 
			       struct node *fnright, struct node *right);

extern int check_op_valence( struct node *x );
extern enum parse_node_kind check_node_kind(node_t *left, node_t *x, node_t *right);
extern enum parse_node_kind check_node_kind_parse(node_t *x);

/*extern int count_gobjlist(node_t *glist, node_t *gend);*/
extern node_t *count_gobjlist(node_t *glist, int *n);

extern int const_size(int rank, int *shape);
extern int add_nscon(char *ip, int n);
extern int add_nicon(int *ip,  int n);
extern int add_nrcon(double *ip,  int n);
extern int add_nzcon(double ip[2][MAXCONSTS], int k, int n);
extern int add_nqcon(double ip[4][MAXCONSTS], int k, int n);
extern int add_nocon(double ip[2][MAXCONSTS], int k, int n);

extern void add_all_const(node_t *glist,  const_t *pconstsp_last);

extern void print_gobjlist(node_t *glist);
extern void print_gobj(node_t *glist);


extern struct node *parse_gobj(struct node *glist);

node_t * get_op_fp(gparse_t *gparsep);
/*extern void op_parse_gobj(struct node *gLF, struct node *gR);*/

#endif
