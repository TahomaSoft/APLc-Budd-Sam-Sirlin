/* runio_qq.c

 APL Compiler - Run Time System

 quote quad routines

 Sam Sirlin

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

/* some important defines, so see what we should include */
#include <aplc_config.h>

#if HAVE_STRING_H
/* sws  for trs2str */
#include <string.h>
#endif

#include "aplc.h"
#include "run.h"

/* quote quad (qq) prompt */
static char qq_prompt[APLC_IBUFSIZE];
static int qq_prompt_len = 0; 


/* sws
   qquad - input quote quad
   return character vector
*/
extern void
aplc_qquad(FILE * file, struct trs_struct * trs)
{
  int c, i;

  /* counter */
  i = 0;
  /* allocate APLC_IBUFSIZE places, this should be fixed later */
  aplc_vectalloc(&trs->value, APLC_IBUFSIZE, APLC_CHAR);
  trs->alloc_ind = APLC_ALLOC_VAL_F;
  /* output prompt */
  if (qq_prompt_len > 0) {
    printf("%s", qq_prompt);
    while( i<qq_prompt_len)
      trs->value.cp[i++] = qq_prompt[i];
    /* now reset prompt to nothing */
    qq_prompt_len = 0;
  }
  while ((i <= APLC_IBUFSIZE)
	 && ((c = fgetc(file)) != (int) EOF)
	 && (c != (int) '\n')) {
    trs->value.cp[i++] = (char) c;
  }
  trs->type = APLC_CHAR;
  if (i == 1)
    trs->rank = 0;
  else
    trs->rank = 1;
  trs->shape = aplc_dsval(i);
  trs->alloc_ind |= APLC_ALLOC_SHAPE_F;
  trs->size = i;
  return;
}

/* sws
   qquad - output quote quad
   set qquad prompt */
extern void
aplc_qquad_assign(struct trs_struct *trs)
{
  int rsize;
  int i;

  if (trs->type != APLC_CHAR)
    aplc_error("[qquad assign] type not char");
  /* get size of right */
  /*rsize = aplc_vsize(trs->rank, trs->shape);*/
  rsize = trs->size;
  if (rsize < 1)
    return;
  /* now copy */
  qq_prompt_len = rsize;
  for (i=0; i<rsize; i++)
    qq_prompt[i] = trs->value.cp[i];
  qq_prompt[rsize] = '\0';
#if 0
  printf("[qq prompt set to {%s}\n", qq_prompt);
#endif  
  return;
}

/* ------------------------------------------------------------ */

/* r .is #readline prompt
   - write prompt to stdio
   - read a line 
   - read using gnu readline, if available */

#ifdef HAVE_READLINE

#include <readline/readline.h>
#include <readline/history.h>

extern int
aplc_readline(struct trs_struct *res, struct trs_struct *left, struct trs_struct * right)
{
  char *in;
  char *out;

  if (right->type != APLC_CHAR)
    aplc_error("[readline] prompt type not char");
  in = APLC_MALLOC(1+right->size);
  aplc_cp2str(in, right);
  out = readline(in);
  res->value.cp = out;
  res->alloc_ind = APLC_ALLOC_VAL_F;
  res->type = APLC_CHAR;
  res->size = strlen(out);
  /* if non-empty, add to the history list */
  if (res->size)
    add_history(out);
  if (res->size == 1)
    res->rank = 0;
  else
    res->rank = 1;
  res->shape = aplc_dsval(res->size);
  res->alloc_ind |= APLC_ALLOC_SHAPE_F;
  aplc_free(in);
  return 0;
}

#else
/* no gnu readline available */
extern int
aplc_readline(struct trs_struct * res, struct trs_struct *left, struct trs_struct * right)
{
  int i, np, nr;

  aplc_qquad_assign(right);
  aplc_qquad(stdin, res);
  /* chop off leading prompt  */
  np = right->size;
  nr = res->size;
  for (i=0; i< nr-np; i++)
    res->value.cp[i] = res->value.cp[i+np];
  res->size -= np;
  *(res->shape) = res->size;
  return 0;
}

#endif /* #ifdef HAVE_READLINE else */


/* end */
