/* f2cif.c - fortran intrinsic functions need by f2c  sws 5/92 */
  /* fortran builtin functions */

double d_lg10();
/* double sqrt(); */
double d_sign();
double pow_di();

/* log base 10 */
double 
d_lg10(r) {

}

/*  sign(a,b), double precision change of sign */
double d_sign(a1,a2)
double *a1, *a2;
{
  if (*a2 < 0.0) 
    return(-dabs(*a1));
  else
    return(dabs(*a1));
}

/* real to integer power */
double 
pow_di(r, i)
double *r;
int *i;
{
 double p;
 int j;

for (j= 1, p= *r; j<= i; j++) {
 p= p*r;
}
return(p);
}

/* end   */
