/* run_ops.c

 APL Compiler

 Sam Sirlin

 Run time system
 some functions

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "aplc.h"

/* ------------------*/
/* conversion from complex <-> real arrays */

/* monadic versions */
/* convert complex to real array */

extern int
aplc_az(struct trs_struct * res, 
	struct trs_struct *left, struct trs_struct *right)
{
  int i,j,n,rk;
  union mp_struct mptmp;

  switch (right->type) {
  default:
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_CHAR:
    /* no change ... */
    aplc_duptrs(res, right);
    break;
  case APLC_COMPLEX:
    /* type is real */
    res->type = APLC_REAL;
    rk = right->rank;
    res->rank = rk+1;
    aplc_vectalloc(&mptmp, res->rank, APLC_INT);
    res->shape = mptmp.ip;
    res->shape[0] = 2;
    n = 1;
    for (i=0; i<rk; i++) {
      res->shape[i+1] = right->shape[i];
      n*=right->shape[i];
    }
    res->size = 2*n;
    aplc_vectalloc(&mptmp, 2*n, APLC_REAL);
    res->value.rp = mptmp.rp;
    for (i=0; i<n; i++) {
      res->value.rp[i] = right->value.zp[0][i];
      res->value.rp[i+n] = right->value.zp[1][i];
    }
    break;
  case APLC_QUAT:
    res->type = APLC_REAL;
    rk = right->rank;
    res->rank = rk+1;
    aplc_vectalloc(&mptmp, res->rank, APLC_INT);
    res->shape = mptmp.ip;
    res->shape[0] = 4;
    n = 1;
    for (i=0; i<rk; i++) {
      res->shape[i+1] = right->shape[i];
      n*=right->shape[i];
    }
    res->size = 4*n;
    aplc_vectalloc(&mptmp, 4*n, APLC_REAL);
    res->value.rp = mptmp.rp;
    for (i=0; i<n; i++) {
      res->value.rp[i] = right->value.qp[0][i];
      res->value.rp[i+n] = right->value.qp[1][i];
      res->value.rp[i+2*n] = right->value.qp[2][i];
      res->value.rp[i+3*n] = right->value.qp[3][i];
    }
  break;
  case APLC_OCT:
    res->type = APLC_REAL;
    rk = right->rank;
    res->rank = rk+1;
    aplc_vectalloc(&mptmp, res->rank, APLC_INT);
    res->shape = mptmp.ip;
    res->shape[0] = 8;
    n = 1;
    for (i=0; i<rk; i++) {
      res->shape[i+1] = right->shape[i];
      n*=right->shape[i];
    }
    res->size = 8*n;
    aplc_vectalloc(&mptmp, 8*n, APLC_REAL);
    res->value.rp = mptmp.rp;
    for (i=0; i<n; i++) 
      for (j=0; j<8; j++) 
	res->value.rp[i+j*n] = right->value.op[j][i];
    break;
  }
  res->alloc_ind = APLC_ALLOC_VAL_F | APLC_ALLOC_SHAPE_F;
  return 0;
}

/* convert real array to complex */
extern int
aplc_za(struct trs_struct * res, 
	 struct trs_struct *left, struct trs_struct *right)
{
  int i,j,m,n,rk;
  union mp_struct mptmp;

  switch (right->type) {
  case APLC_BOOL:
  case APLC_INT:
    /* convert to real */
    break;
  case APLC_REAL:
    break;
  default:
  case APLC_CHAR:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    printf("#za right type %d\n", right->type);
    aplc_error("#za domain error; scalar right");
    break;
  }
  rk = right->rank;
  if (rk < 1)
    aplc_error("#za domain error; scalar right");
  /* later allow replication ? */

  m = right->shape[0];
  /* drop rank by 1, drop first shape */
  res->rank = rk-1;
  aplc_vectalloc(&mptmp, res->rank, APLC_INT);
  res->shape = mptmp.ip;
  n = 1;
  for (i=0; i<rk-1; i++) {
    res->shape[i] = right->shape[i+1];
    n*=res->shape[i];
  }
  switch (m) {
  default:
    printf("[#za] right shape %d\n", m);
    aplc_error("#za domain error; right shape");
    break;
  case 2:
    res->type = APLC_COMPLEX;
    aplc_vectalloc(&mptmp, n, APLC_COMPLEX);
    res->value.zp[0] = mptmp.zp[0];
    res->value.zp[1] = mptmp.zp[1];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) {
	res->value.zp[0][i] = right->value.ip[i];
	res->value.zp[1][i] = right->value.ip[i+n]; 
      }
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) {
	res->value.zp[0][i] = right->value.rp[i];
	res->value.zp[1][i] = right->value.rp[i+n]; 
      }
      break;
    }
    break;
  case 4:
    res->type = APLC_QUAT;
    aplc_vectalloc(&mptmp, n, APLC_QUAT);
    for (j=0; j<4; j++)
      res->value.qp[j] = mptmp.qp[j];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) 
	for (j=0; j<4; j++) 
	  res->value.qp[j][i] = right->value.ip[i+j*n];
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) 
	for (j=0; j<4; j++) 
	  res->value.qp[j][i] = right->value.rp[i+j*n];
      break;
    }
    break;
  case 8:
    res->type = APLC_OCT;
    aplc_vectalloc(&mptmp, n, APLC_OCT);
    for (j=0; j<8; j++)
      res->value.op[j] = mptmp.op[j];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) 
	for (j=0; j<8; j++) 
	  res->value.op[j][i] = right->value.ip[i+j*n];
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) 
	for (j=0; j<8; j++) 
	  res->value.op[j][i] = right->value.rp[i+j*n];
      break;
    }
    break;
  }
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  res->size = aplc_vsize(res->rank, res->shape);
  return 0;
}

/* ------------------*/
/* dyadic versions */


/* convert complex to real array 
   - grab different components along the "complex axis"
   - left indicates which complex component 
   - left argument is which component to grab 
     (index origin dependant)
   e.g. 1 1 2 #az 1i2 <-> 1 1 2 */
extern int
aplc_daz(struct trs_struct * res, 
	 struct trs_struct *left, struct trs_struct *right)
{
  int i,j,k, n,rk;
  union mp_struct mptmp;

  /* left must be int */
  if ( (left->type != APLC_INT) &&
       (left->type != APLC_BOOL) ) {
    fprintf(aplcerr,"[aplc_az2] left type %d, ", left->type);
    aplc_error("#az domain error");
  }  
  if ( left->size < 1) {
    aplc_zilde(res);
    return 0;
  }

  /* setup size, space for result */
  res->type = APLC_REAL;
  rk = right->rank;
  res->rank = rk+1;
  aplc_vectalloc(&mptmp, res->rank, APLC_INT);
  res->shape = mptmp.ip;
  res->shape[0] = left->size;
  n = 1;
  for (i=0; i<rk; i++) {
    res->shape[i+1] = right->shape[i];
    n*=right->shape[i];
  }
  res->size = n*left->size;
  aplc_vectalloc(&mptmp, res->size, APLC_REAL);
  res->value.rp = mptmp.rp;

  switch (right->type) {
  default:
  case APLC_CHAR:
    aplc_error("#az domain error");
    break;
  case APLC_BOOL:
  case APLC_INT:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if (k != 0)
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.ip[i];
      }
    }
    break;
  case APLC_REAL:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if (k != 0)
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.rp[i];
      }
    }
    break;
  case APLC_COMPLEX:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if ( (k<0) || (k>1))
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.zp[k][i];
      }
    }
    break;
  case APLC_QUAT:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if ( (k<0) || (k>3))
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.qp[k][i];
      }
    }
    break;
  case APLC_OCT:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if ( (k<0) || (k>7))
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.op[k][i];
      }
    }
    break;
  }
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  return 0;
}

/* convert real array to complex 
   - left argument must match first right shape
       L = (rho R)[1]
     indicates what complex term each right goes to

e.g. 
     2 1 #za 1 0 <-> 0i1      

   try to be the inverse of #az (doesn't work in all cases):
   1 2 #az 1i2 <-> 1 2 
   1 2 #za 1 2 <-> 1i2 
   2 1 #za 1 2 <-> 2i1 

*/
extern int
aplc_dza(struct trs_struct *res, 
	 struct trs_struct *left, struct trs_struct *right)
{
  int i,j,k, m,n,rk;
  int isLscalar;
  union mp_struct mptmp;
  

  /* left must be int */
  if ( (left->type != APLC_INT) &&
       (left->type != APLC_BOOL) ) {
    fprintf(aplcerr,"[aplc_za2] left type %d, ", left->type);
    aplc_error("#za domain error");
  }  
  if ( left->size < 1) {
    aplc_zilde(res);
    return 0;
  }
  if (left->rank <1)
    isLscalar = 1;
  else
    isLscalar = 0;

  switch (right->type) {
  case APLC_BOOL:
  case APLC_INT:
    /* convert to real */
    break;
  case APLC_REAL:
    break;
  default:
  case APLC_CHAR:
    printf("#za right type %d\n", right->type);
    aplc_error("#za domain error; char right");
    break;
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    printf("#za right type %d\n", right->type);
    aplc_error("#za domain error; complex right");
    break;
  }
  rk = right->rank;
  if (rk < 1)
    aplc_error("#za domain error; scalar right");
  /* later allow replication ? */

  m = right->shape[0];
  if ( left->size < m) {
    aplc_error("#za domain error; left size < 1 take shape right");
  }

  /* drop 1 rank, drop first shape */
  res->rank = rk-1;
  aplc_vectalloc(&mptmp, res->rank, APLC_INT);
  res->shape = mptmp.ip;
  /* compute result size */
  n = 1;
  for (i=0; i<rk-1; i++) {
    res->shape[i] = right->shape[i+1];
    n*=res->shape[i];
  }
  switch (m) {
  default:
    printf("[#za] right shape %d\n", m);
    aplc_error("#za domain error; right shape");
    break;
  case 2:
    res->type = APLC_COMPLEX;
    aplc_vectalloc(&mptmp, n, APLC_COMPLEX);
    res->value.zp[0] = mptmp.zp[0];
    res->value.zp[1] = mptmp.zp[1];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) {
	for (j=0; j<2; j++) {
	  /*res->value.zp[1][i] = right->value.ip[i + j*n]; */
	  /*fprintf(stderr,"i %d, j %d, left %d\n",i,j,left->value.ip[j]);*/
	  k = left->value.ip[j] - aplc_ixorg;
	  /*fprintf(stderr,"k %d, i+n*k %d\n",k, i+n*k);*/
	  res->value.zp[j][i] = right->value.ip[i + n*k]; 
	}
      }
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) {
	for (j=0; j<2; j++) {
	  k = left->value.ip[j] - aplc_ixorg;
	  res->value.zp[j][i] = right->value.rp[i+k*n];
	}
      }
      break;
    }
    break;
  case 4:
    res->type = APLC_QUAT;
    aplc_vectalloc(&mptmp, n, APLC_QUAT);
    for (j=0; j<4; j++)
      res->value.qp[j] = mptmp.qp[j];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) 
	for (j=0; j<4; j++) {
	  k = left->value.ip[j] - aplc_ixorg;
	  res->value.qp[j][i] = right->value.ip[i+k*n];
	}
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) 
	for (j=0; j<4; j++) {
	  k = left->value.ip[j] - aplc_ixorg;
	  res->value.qp[j][i] = right->value.rp[i+k*n];
	}
      break;
    }
    break;
  case 8:
    res->type = APLC_OCT;
    aplc_vectalloc(&mptmp, n, APLC_OCT);
    for (j=0; j<8; j++)
      res->value.op[j] = mptmp.op[j];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
#if 0
      /* debugging.... print right */
      fprintf(stderr,"[dza] right = [\n");
      for (i=0; i<right->size; i++)
        fprintf(stderr," %d ", right->value.ip[i]);   
      fprintf(stderr,"\n");
#endif
      for (i=0; i<n; i++) 
	for (j=0; j<8; j++) {
	  k = left->value.ip[j] - aplc_ixorg;
	  res->value.op[j][i] = right->value.ip[i+k*n];
#if 0
          /* debugging.... */
          fprintf(stderr,"[dza] %d %d %d: %d\n", i,j,k, right->value.ip[i+k*n]);   
#endif
	}
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) 
	for (j=0; j<8; j++) {
	  k = left->value.ip[j] - aplc_ixorg;
	  res->value.op[j][i] = right->value.rp[i+k*n];
	}
      break;
    }
    break;
  }
  res->alloc_ind = APLC_ALLOC_SHAPE_F | APLC_ALLOC_VAL_F;
  res->size = aplc_vsize(res->rank, res->shape);
  return 0;
}

/* ------------------*/


/* sws

   function encode. for now this looks just like residue, but
   later residue should depend on #ct

   (see the iso standard ref)

   z .is a encode c

   aplc_encode(z, a, a.type, c, c.type)

   changed are z and c

   type for c may not be handled the best possible way...
   consider integer c, real a...

*/
void
aplc_encode(union res_struct *res, 
	    union res_struct *lval, int ltype, 
	    union res_struct *rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;
  double temp, templ;

  maxtype = (ltype > rtype) ? ltype : rtype;

  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_BOOL:
  case APLC_INT:
    if (lnval.i != 0) {
      res->i = rnval.i - lnval.i *
	  floor(((double) rnval.i) / ((double) lnval.i));
      rnval.i = (rnval.i - res->i) / lnval.i;
    } else {
      res->i = rnval.i;
      rnval.i = 0;
    }
    if ((rtype == APLC_INT) || (rtype == APLC_BOOL)) {
      rval->i = rnval.i;
    } else
      fprintf(aplcerr,"case error in encode\n");
    break;
  case APLC_REAL:
    if (lnval.r != 0.0) {
      /* definition, but has trouble with large r */
      /* res->r = rnval.r - lnval.r * floor(rnval.r / lnval.r); */
      /* rnval.r = (rnval.r - res->r) / lnval.r; */
      /* alternate */
      /* rnval.r = floor(rnval.r / lnval.r); */

      /* too slow!
      temp = rnval.r;
      while (temp > lnval.r)
	temp = temp - lnval.r;
      res->r = temp;
      */
      temp = floor(rnval.r / lnval.r); 
      templ = temp*lnval.r;
      if ( templ == 1.0 + templ ) {
	res->r = 0.0;
	/* this can produce fractional results - assume ok */
	rnval.r /= lnval.r;
      } else {
	res->r = rnval.r - templ;
	rnval.r = temp;
      }
    } else {
      res->r = rnval.r;
      rnval.r = 0.0;
    }
    if ((rtype == APLC_INT) || (rtype == APLC_BOOL)) {
      rval->i = (int) rnval.r;
    } else
      rval->r = rnval.r;
    break;
  default:
    aplc_error("type error for encode function");
  }
  return;
}

#define UNBOXDEBUG 0

/* see if we have a number */
extern int
aplc_isnumtype(int type)
{
  int r;
  
  r = 0;
  switch(type) {
  default:
    break;
    /* number */
  case APLC_BIT: 
  case APLC_BOOL:
  case APLC_LABEL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    r = 1;
    break;
  }
  return r;
}

/* get the max type of two given types 
   - only used in unbox... */
extern int
aplc_maxtype(int type1, int type2)
{
  int r;

  r = APLC_ANY;
  switch(type1) {
    /* unknown */
  default:
  case APLC_UNDEF:
  case APLC_UKTYPE: 
    /* any */
  case APLC_ANY:
    break;

    /* number */
  case APLC_BIT: 
  case APLC_BOOL:
  case APLC_LABEL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    if (aplc_isnumtype(type2)) {
      r = max(type1, type2);
      if (r == APLC_LABEL)
	r = APLC_INT;
    }
    break;

    /* character */
  case APLC_CHAR:
    if (type2 == APLC_CHAR)
      r = APLC_CHAR;
    break;

    /* boxed */
  case APLC_BOXED:
    if (type2 == APLC_BOXED)
      r = APLC_BOXED;
    break;
  }
  return r;
}

/* ---------------------------------------------------------------- */
/* mergetype - return the result type of joining two types via 
         -` catenate, or subassign(?)
         -  inner, outer
   sws */
int
aplc_mergetype(int lefttype, int righttype)
{
#if 1
  if (lefttype == righttype)
    return lefttype;

  if ( aplc_isnumtype(lefttype) && aplc_isnumtype(righttype) ) 
    return (lefttype > righttype) ? lefttype : righttype ;
  /* else we have different types, not numbers
     hence use boxed result */ 
  return APLC_BOXED;
#else
  return (lefttype > righttype) ? lefttype : righttype ;
#endif
}


/* ---------------------------------------------------------------- */
/* unbox right argument */
extern void
aplc_unbox(struct trs_struct *res, struct trs_struct *right)
{
  int i,j,k;
  int type;
  int rankmax;
  union mp_struct mptmp;
  int *si;
  trs_t resv1, resv2, ress;

#if UNBOXDEBUG
  printf(">right=");
  aplc_print_trs(right);
#endif

  switch(right->type) {
  default:
    /* not boxed - just return right */
    aplc_copytrs(res, right);
    break;
  case APLC_BOXED:
    /* check for 0 size right */
    if (right->size == 0) {
      /* just return zilde */
      aplc_zilde(res);
      break;
    }
    if (right->rank == 0) {
      /* scalar - just remove the box */
      aplc_copytrs(res, &right->value.trsp[0]);
    } else {
      /* get max type */
      type = right->value.trsp[0].type;
      rankmax = right->value.trsp[0].rank;
      for (i=1; i<right->size; i++) {
	/* ignore type of 0 size things */
	if (0 < right->value.trsp[i].size)
	  type = aplc_maxtype( type, right->value.trsp[i].type);
	rankmax = max(rankmax,right->value.trsp[i].rank);
      }
      /* check type */
#if UNBOXDEBUG
      printf("[unbox] result type %d\n", type);
#endif
      if (type == APLC_ANY) {
	fprintf(aplcerr, "[aplc_unbox] type error\n"); 
	aplc_error(" domain error");
      } 

      /* get max shape */
      aplc_vectalloc(&mptmp, rankmax, APLC_INT);
      si = mptmp.ip;
      for (i=0; i<rankmax; i++)
	si[i] = 0;
      /* also reshape to max rank */
      aplc_inittrs( &resv1 );
      aplc_settrs(&resv1, APLC_BOXED, right->rank, right->shape);
      aplc_talloc(&resv1);
      for (i=0; i<right->size; i++) {
	aplc_copytrs(&resv1.value.trsp[i], &right->value.trsp[i]);
	k = rankmax - right->value.trsp[i].rank;
	/* printf("i %d, rankmax %d, rank %d, k %d\n", i, rankmax,
	   right->value.trsp[i].rank, k);*/
	aplc_vectalloc(&mptmp, rankmax, APLC_INT);
	for (j=0; j<k; j++) {
	  /* extend right shape using 1's */
	  si[j] = max(si[j], 1);
	  mptmp.ip[j] = 1;
	}
	for (j=0; j<right->value.trsp[i].rank; j++) {
	  si[k+j] = max(si[k+j], right->value.trsp[i].shape[j]);
	  mptmp.ip[k+j] = right->value.trsp[i].shape[j];
	}
	resv1.value.trsp[i].rank = rankmax;
	if (resv1.value.trsp[i].alloc_ind & APLC_ALLOC_SHAPE_F)
	  aplc_free(resv1.value.trsp[i].shape);
	resv1.value.trsp[i].shape = mptmp.ip;
	resv1.value.trsp[i].alloc_ind |= APLC_ALLOC_SHAPE_F;
      }      

      /* adjust type of any 0 size entries */
      for (i=0; i<resv1.size; i++) {
	if (resv1.value.trsp[i].size <1) {
	  resv1.value.trsp[i].type = type;
	}
      }
#if UNBOXDEBUG
    printf(">resv1=");
    aplc_print_trs(&resv1);
#endif

    /* now use take on each component */
    aplc_inittrs( &resv2 );
    aplc_settrs(&resv2, APLC_BOXED, right->rank, right->shape);
    aplc_talloc(&resv2);
    aplc_inittrs( &ress );
    aplc_settrs(&ress, APLC_INT, 1, &rankmax);
    /*aplc_vectalloc(&mptmp, 2, APLC_INT);
      ress.value.ip = mptmp.ip;*/
    aplc_talloc(&ress);
    for (i=0; i<rankmax; i++)
      ress.value.ip[i] = si[i];
    for (i=0; i<right->size; i++) {
      aplc_take( &resv2.value.trsp[i], &ress, &resv1.value.trsp[i]); 
    }

#if UNBOXDEBUG
    printf(">resv2=");
    aplc_print_trs(&resv2);
#endif

    /* now copy into result, ravel order */
    res->type = type;
    res->rank = right->rank + rankmax;
    aplc_vectalloc(&mptmp, res->rank, APLC_INT);
    res->shape = mptmp.ip;
    res->alloc_ind |= APLC_ALLOC_SHAPE_F;
    j = 0;
    for (i=0; i<right->rank; i++) 
      res->shape[j++] = right->shape[i];
    for (i=0; i<rankmax; i++)
      res->shape[j++] = si[i];
    res->size = aplc_vsize(res->rank, res->shape);
    aplc_talloc(res);
    k = 0;
    for (i=0; i<right->size; i++) {
      for (j=0; j<resv2.value.trsp[i].size; j++) {
	aplc_cptrsval( res, k++, &resv2.value.trsp[i], j);
      }
    }
    aplc_detalloc(&resv1);
    aplc_detalloc(&resv2);
    aplc_detalloc(&ress);
    aplc_free(si);

#if UNBOXDEBUG
    printf(">res=");
    aplc_print_trs(res);
#endif

      /*aplc_error("[aplc_unbox] non-scalar nya");*/
    }
    break;
  } /* end of right type switch */
  return;
}

/* r <- a f each g b  
used as  
   r <- a f each  b  
   r <-   f each  b  
   - ambivalent
   - g is (currently) unused
 */
extern int
aplc_each(trs_t *r,  trs_t *a, aplc_fp_t f, aplc_fp_t g, trs_t *b)
{
  int i,j,k, as, bs, rank;
  int *shape;
  trs_t a_trs, b_trs;/* temp scalar trs */
  res_t a_trsv, b_trsv;

  aplc_inittrs( &a_trs );
  aplc_inittrs( &b_trs );
  if (a->type == APLC_UKTYPE) {
    /* monadic */
    /* apply f to each component of b */
    switch(b->type) {
    default:
      /* apply to vectors in the same manner */
      /* setup copy */
      aplc_settrs(&b_trs, b->type, 0, (int *)0);
      aplc_link_res(&b_trs, &b_trsv);
      /* setup return */
      aplc_settrs(r, APLC_BOXED, b->rank, b->shape);
      aplc_talloc(r);
      /* now loop through components */
      for (i=0; i<r->size; i++) {
	/* initialize each here, in case nothing is returned */
	aplc_inittrs(&r->value.trsp[i]);
	/* copy in current value */
	aplc_cptrsval(&b_trs,0, b, i);
	/*f(&r->value.trsp[i], NULL, &b_trs);*/
	f(&r->value.trsp[i], &aplc_nulltrs, &b_trs);
      }
      break;
    case APLC_BOXED:
      /* setup return */
      aplc_settrs(r, APLC_BOXED, b->rank, b->shape);
      aplc_talloc(r);
      /* now loop through components */
      for (i=0; i<r->size; i++) {
	/* initialize each here, in case nothing is returned */
	aplc_inittrs(&r->value.trsp[i]);
	/*f(&r->value.trsp[i], NULL, &b->value.trsp[i]);*/
	f(&r->value.trsp[i], &aplc_nulltrs, &b->value.trsp[i]);
      }
      break;
    }
  } else {
    /* dyadic */
    /* check sizes, get result rank, shape */
    as = aplc_vsize(a->rank, a->shape);
    bs = aplc_vsize(b->rank, b->shape);
    rank = 0;/* for gcc warnings */
    shape = (int *)0;
    if ( (a->rank == 0) || ( 1 == as) ) {
      rank = b->rank;
      shape = b->shape;
    } else if ( (b->rank == 0) || ( 1 == bs) || (as == bs) ) {
      rank = a->rank;
      shape = a->shape;
    } else {
      aplc_fprintf_ivec(stderr,"  left shape", a->shape, a->rank);
      aplc_fprintf_ivec(stderr,"  right shape", b->shape, b->rank);
      aplc_error("[each] shape error");
    }
#if 0
    /* force complete shape match - do we want to do this? */
    if (a->rank != b->rank)
      aplc_error("each error; rank error");
    if (a->size != b->size)
      aplc_error("each error; size error");
#endif
    switch(a->type) {
    default:
      switch(b->type) {
      default:
	/* both unboxed */ 
	/* apply to vectors in the same manner */
	/* setup copy */
	aplc_settrs(&a_trs, a->type, 0, (int *)0);
	aplc_link_res(&a_trs, &a_trsv);
	aplc_settrs(&b_trs, b->type, 0, (int *)0);
	aplc_link_res(&b_trs, &b_trsv);
	/* setup return */
	aplc_settrs(r, APLC_BOXED, rank, shape);
	aplc_talloc(r);
	/* now loop through components */
	for (i=0,j=0,k=0; i<r->size; i++) {
	  /* initialize each here, in case nothing is returned */
	  aplc_inittrs(&r->value.trsp[i]);
	  /* copy in current value */
	  aplc_cptrsval(&a_trs,0, a, j++);
	  aplc_cptrsval(&b_trs,0, b, k++);
	  f(&r->value.trsp[i], &a_trs, &b_trs);
	  if (j==as)
	    j--;
	  if (k==bs)
	    k--;
	}
	break;
      case APLC_BOXED:
	/* a unboxed, b boxed */
	aplc_settrs(&a_trs, a->type, 0, (int *)0);
	aplc_link_res(&a_trs, &a_trsv);
	aplc_settrs(r, APLC_BOXED, rank, shape);
	aplc_talloc(r);
	for (i=0,j=0,k=0; i<r->size; i++) {
	  /* initialize each here, in case nothing is returned */
	  aplc_inittrs(&r->value.trsp[i]);
	  aplc_cptrsval(&a_trs,0, a, j++);
	  f(&r->value.trsp[i], &a_trs, &b->value.trsp[k++]);
	  if (j==as)
	    j--;
	  if (k==bs)
	    k--;
	}
#if 0
	/* setup return */
	aplc_settrs(r, APLC_BOXED, b->rank, b->shape);
	aplc_talloc(r);
	/* now loop through components */
	for (i=0; i<r->size; i++) {
	  /* initialize each here, in case nothing is returned */
	  aplc_inittrs(&r->value.trsp[i]);
	  f(&r->value.trsp[i], a, &b->value.trsp[i]);
	}
#endif
	break;
      }
      break;
    case APLC_BOXED:
      switch(b->type) {
      default:
	/* a boxed, b unboxed */ 
	aplc_settrs(&b_trs, b->type, 0, (int *)0);
	aplc_link_res(&b_trs, &b_trsv);
	/* setup return */
	aplc_settrs(r, APLC_BOXED, rank, shape);
	aplc_talloc(r);
	/* now loop through components */
	for (i=0,j=0,k=0; i<r->size; i++) {
	  /* initialize each here, in case nothing is returned */
	  aplc_inittrs(&r->value.trsp[i]);
	  aplc_cptrsval(&b_trs,0, b, k++);
	  f(&r->value.trsp[i], &a->value.trsp[j++], &b_trs);
	  if (j==as)
	    j--;
	  if (k==bs)
	    k--;
	}
	break;
      case APLC_BOXED:
	/* a, b boxed 
	   - could have either a scalar, else ranks, shapes must match */
	aplc_settrs(r, APLC_BOXED, rank, shape);
	aplc_talloc(r);
	/* now loop through components */
	for (i=0,j=0,k=0; i<r->size; i++) {
	  /* initialize each here, in case nothing is returned */
	  aplc_inittrs(&r->value.trsp[i]);
	  f(&r->value.trsp[i], &a->value.trsp[j++], &b->value.trsp[k++]); 
	  if (j==as)
	    j--;
	  if (k==bs)
	    k--;
	}
	break;
      }
      break;
    }
  }
  return 0;
}

/* indexfn index function 
   r .is i .index b  (similar to r .is b[i]) 

   use last axis of i as axis of b

   Note:
   apl2 index uses a nested index vector, outer product
   length of i must match rank of b 
   - can't do scatter indexing easily

*/
extern int
aplc_index(trs_t *r,  trs_t *i, trs_t *b)
{
  int j,k,rank,m,p;
  int *ev;

  switch(i->type) {
  default:
    aplc_error("[index] type error");
    break;
  case APLC_BIT:
  case APLC_BOOL:
  case APLC_INT:
    /* expect last axis of i matches rank of b 
       - also allow smaller sizes */
    if (i->rank) {
      if (b->rank) {
        /* non scalar -- test shape */
        if ( i->shape[i->rank-1] != b->rank ) {
          aplc_error("[index] shape error");
        }
        /* result type is type of b
           result shape matches up to last axis of i */
        aplc_settrs(r, b->type, i->rank-1, i->shape);
      } else {
        /* b is scalar */
        aplc_settrs(r, b->type, i->rank, i->shape);
      }
    } else {
      /* i is scalar -- so is result */
      aplc_settrs(r, b->type, 0, i->shape);
    }
    aplc_talloc(r);
    rank = b->rank;
    /* get expansion vector */
    ev = aplc_evec(b->rank, b->shape);
    /* now copy values from b to r */
    /* loop over size 
       - sequential over r, i */
    k = 0;/* initialize index into i */
    for (j=0; j<r->size; j++) {
      /* r[j] = b[i[j;]] 
         - sum up inner product of ev, indices of i  
         v = i[rank*j + (1:rank)-1]
         k = e[1]*v[1] + ... */
      for (m=0, p=0; m<rank; m++) {
        p += ev[m]*(i->value.ip[k] - aplc_ixorg);
        if (i->rank)
          k++;/* increment if i is not scalar */
      }
      aplc_cptrsval(r,j, b,p);
    }
    break;
  case APLC_BOXED:
    /* nya */
    aplc_error("[index] boxed left nya");
    /* in this case we expect to have a set of boxes
       inside each box is a thing of length rank(b) (integers or boxes) 
       if boxes, we form an outer product

       create an intermediate boxed product, size of i
       look in each component of i, do outer product...
       use unbox to bring all contents to common shape
     */
    break;
  }
  return 0;
}

/* link - heterogenous catenate
   r <- a;b  
   (<a),<b   if b isn't boxed
   (<a),b    if b is boxed
*/
extern int
aplc_link(trs_t *r,  trs_t *a, trs_t *b)
{
  int i,j,k,p,pr;
  int rank;
  int sshape[1] = {2};
  int free_flag = 0;
  union mp_struct shape;

  if (b->type != APLC_BOXED) {
    /* (<a),<b */
    aplc_settrs(r, APLC_BOXED, 1, sshape);
    aplc_talloc(r);
    /* could use duptrs? */
    aplc_copytrs(&r->value.trsp[0], a);
    aplc_copytrs(&r->value.trsp[1], b);
  } else {
    /* (<a),b 
       left is a scalar
       rank is rank of b
       shape is shape of b except for last axis +1 */
    rank = b->rank;
    if (rank<1) {
      /* scalar b */
      rank = 1;
      /*aplc_vectalloc(&shape, rank, APLC_INT);
      shape.ip[0] = 2;
      aplc_settrs(r, APLC_BOXED, rank, shape.ip);*/
      aplc_settrs(r, APLC_BOXED, 1, sshape);
      shape.ip = sshape;
    } else {
      aplc_vectalloc(&shape, b->rank, APLC_INT);
      free_flag = 1;/* can free shape.ip */
      aplc_cpvec(shape.ip, b->rank, b->shape);
      shape.ip[b->rank-1]++;
      aplc_settrs(r, APLC_BOXED, rank, shape.ip);
    }
    aplc_talloc(r);
    if (r->size >0) {
      pr = 1;
      for (i=0; i<rank-1; i++)
	pr *= r->shape[i];
      i = 0;
      k = 0;
      for (p=0; p<pr;p++) {
	aplc_copytrs(&r->value.trsp[i++], a);
	for (j=1; j<shape.ip[rank-1]; j++)
	  aplc_copytrs(&r->value.trsp[i++], &b->value.trsp[k++]);
      }
    }
    if (free_flag)
      aplc_free(shape.ip);
  }
  return 0;
}

/* return int depending on match */ 
extern int
aplc_match_fn(trs_t *a, trs_t *b)
{
  int i,j;

  if (a->type != b->type)
    return 0;
  if (a->rank != b->rank)
    return 0;
  if (a->rank > 0) {
    for (i=0; i<a->rank; i++)
      if (a->shape[i] != b->shape[i])
        return 0;
  }
  /* check values */
  switch(a->type) {
  default:
  case APLC_UKTYPE:
    printf("type %d\n", a->type);
    aplc_error("unhandled case in match");
    break;
  case APLC_CHAR:
    for (i=0; i<a->size; i++)
      if (a->value.cp[i] != b->value.cp[i])
        return 0;
    break;
  case APLC_BIT: 
  case APLC_BOOL: 
  case APLC_LABEL: 
  case APLC_INT:
    for (i=0; i<a->size; i++)
      if (a->value.ip[i] != b->value.ip[i])
        return 0;
    break;
  case APLC_REAL:
    for (i=0; i<a->size; i++)
      if (a->value.rp[i] != b->value.rp[i])
        return 0;
    break;
  case APLC_COMPLEX:
    for (i=0; i<a->size; i++)
      for (j=0; j<2; j++)
        if (a->value.zp[j][i] != b->value.zp[j][i])
          return 0;
    break;
  case APLC_QUAT: 
    for (i=0; i<a->size; i++)
      for (j=0; j<4; j++)
        if (a->value.qp[j][i] != b->value.qp[j][i])
          return 0;
    break;
  case APLC_OCT: 
    for (i=0; i<a->size; i++)
      for (j=0; j<8; j++)
        if (a->value.op[j][i] != b->value.op[j][i])
          return 0;
    break;
  case APLC_BOXED: 
    for (i=0; i<a->size; i++)
      if (!aplc_match_fn(&a->value.trsp[i], &b->value.trsp[i]))
        return 0;
    break;
  }
  return 1;
}

extern int
aplc_match(trs_t *r,  trs_t *a, trs_t *b)
{
  r->type = APLC_INT;
  r->rank = 0;
  r->size = 1;
  if (!r->alloc_ind) {
    /*r->value.ip = &r->scalar.i;*/
    aplc_link_scalar(r);
  }
  *r->value.ip = aplc_match_fn(a,b);
  return 0;
}

/* inner product operator
   a f.g b */
extern int
aplc_inner(trs_t *r,  trs_t *a, aplc_fp_t f, aplc_fp_t g, trs_t *b)
{
  trs_t r1,r2, a1,b1,rold;
  union mp_struct shapemp;
  int rank, type ;
  int i,j,L,Lm, e, flag;
  int ia=0;
  int ib=0;

  type = aplc_mergetype(a->type, b->type);
  rank = aplc_innershape(&shapemp, a->rank, a->shape, b->rank, b->shape);
  /* setup return */
  aplc_settrs(r, type, rank, shapemp.ip);
  aplc_talloc(r);

  /* compute expansion vector e1 */
  e = aplc_esubi(0, b->rank,b->shape);
  /* get reduction length */
  if (b->rank == 0) {
    if (a->rank == 0)
      L = 1;
    else
      L = a->shape[a->rank-1];
  } else {
    if (b->rank == 0) 
      L = 1;
    else
      L = b->shape[0];
  }  
  Lm = L-1;
  /* now loop through components */
  aplc_settrs(&a1, a->type, 0, (int *)0);
  aplc_settrs(&b1, b->type, 0, (int *)0);
  aplc_settrs(&r1, type, 0, (int *)0);
  aplc_settrs(&r2, type, 0, (int *)0);
  aplc_settrs(&rold, type, 0, (int *)0);
  aplc_link_scalar(&a1);
  aplc_link_scalar(&b1);
  aplc_link_scalar(&r1);
  aplc_link_scalar(&r2);
  aplc_link_scalar(&rold);
  for (i=0; i< r->size; i++) {
    if (a->rank > 0) {
      /* offsetL = (offset div e1)*L + (L-1)   */
      ia = (i/e)*L + Lm;
    }
    if (b->rank > 0) {
      /* offsetR = (offset mod e1) + (L-1)*e1  */
      ib = (i%e) + Lm*e;
    }
    flag = 1;
    /* reduction loop */
    for (j=L-1; j>=0; j--) {
      if (a->rank > 0) {
        if (b->rank > 0) {
          aplc_cptrsval(&a1,0, a, ia);
          aplc_cptrsval(&b1,0, b, ib);
          g(&r1, &a1,&b1);
        } else {
          aplc_cptrsval(&a1,0, a, ia);
          g(&r1, &a1,b);
        }
      } else {
        if (b->rank > 0) {
          aplc_cptrsval(&b1,0, b, ib);
          g(&r1, a,&b1);
        } else {
          g(&r1, a,b);
        }
      }
      if (flag) {
        flag = 0;
        aplc_cptrsval(&r2,0, &r1,0);
      } else {
        f(&r2, &r1,&rold);
      }
      aplc_cptrsval(&rold,0, &r2,0);
      ia -= 1;
      ib -= e;
    } /* end of reduction loop */ 
    r->type = rold.type;
    aplc_cptrsval(r,i, &rold, 0);
  } /* end of r loop */
  return 0;
}

/* general outer product operator
   r <- a .jot . g b  */
extern int
aplc_outer(trs_t *r,  trs_t *a, aplc_fp_t f, aplc_fp_t g, trs_t *b)
{
  trs_t a_trs, b_trs, r_trs;/* temp scalar trs */
  union mp_struct shapemp;
  int rank, as,bs, type, i,j,k;
  int flag;

  aplc_inittrs( &a_trs );
  aplc_inittrs( &b_trs );
  aplc_inittrs( &r_trs );
  type = aplc_mergetype(a->type, b->type);/* guess */
  /* rank is sum of ranks of a,b */
  /* shape is (shape a),(shape b) */
  rank = aplc_outershape(&shapemp, a->rank, a->shape, b->rank, b->shape);
  /* result a[i] g b[j] */
  as = aplc_vsize(a->rank, a->shape);
  bs = aplc_vsize(b->rank, b->shape);
  /* setup return */
  aplc_settrs(r, type, rank, shapemp.ip);
  /* now loop through components */
  aplc_settrs(&a_trs, a->type, 0, (int *)0);
  aplc_settrs(&b_trs, b->type, 0, (int *)0);
  aplc_link_scalar(&a_trs);
  aplc_link_scalar(&b_trs);
  /*aplc_settrs(&r_trs, type, 0, (int *)0); guess 
  aplc_link_scalar(&r_trs); */
  aplc_inittrs(&r_trs);
  k = 0;
  flag = 0;
  for (i=0; i<as; i++) {
    for (j=0; j<bs; j++) {
      /* r[k] = g(a[i],b[j]) */
      aplc_cptrsval(&a_trs,0, a, i);
      aplc_cptrsval(&b_trs,0, b, j);
      g( &r_trs, &a_trs, &b_trs);
      if (!flag) {
          /* after first calculation, determine type, allocate */
          r->type = r_trs.type;
          aplc_talloc(r);
          flag = 1;
      }
      aplc_cptrsval(r,k++, &r_trs,0 );
    }
  }
  aplc_detalloc(&r_trs);
  return 0;
}

/* return an int, given a general type */ 
extern int
aplc_get_int(trs_t *a)
{
  switch(a->type) {
  default:
  case APLC_UKTYPE:
    break;
  case APLC_BIT: 
  case APLC_BOOL: 
  case APLC_LABEL: 
  case APLC_INT:
    return a->value.ip[0];
    break;
  case APLC_REAL: 
    return (int) a->value.rp[0];
    break;
  case APLC_COMPLEX: 
    return (int) *a->value.zp[0];
    break;
  case APLC_QUAT: 
    return (int) *a->value.qp[0];
    break;
  case APLC_OCT: 
    return (int) *a->value.op[0];
    break;
  }
  printf("type %d\n", a->type);
  aplc_error("[aplc_get_int] type error");
  return 0;
}


/* reduce operator: 
   f / b        FOV 
   f /[i] b     FOOVV
   - note currently axis assumes index origin is 1 ...
*/
extern int
aplc_reduce(trs_t *r,  trs_t *a, aplc_fp_t f, trs_t *i, trs_t *b)
{
  trs_t r1, b1, rold;
  int axis, axis0, ia,j,k,e,s,t1,t2, flag;
  union mp_struct shape;

  aplc_inittrs( &r1 );
  aplc_inittrs( &b1 );
  aplc_inittrs( &rold );
  if ( (! i) || (i->type == APLC_UKTYPE) ) {
    /* no axis; last axis */
    axis = b->rank;
  } else {
    /* axis specified in i 
     -- need scalar int */
    axis = aplc_get_int(i);
    /* axis = aplc_get_int(i) + 1 - aplc_ixorg; */
  }
  axis0 = axis-1;/* 0-origin axis */ 

  /* now check the shape of b */
  if ( b->size == 0 ) {
    /* b has at least one 0 shape element 
       identity not known, so error */
    printf("reduce: shape of argument: (%d) (", b->rank);
    for (j=0; j<b->rank; j++)
      printf(" %d ", b->shape[j]);
    printf(")\n");
    aplc_error("[aplc_reduce] domain error");
    return 1;
  }
  if ( (b->rank == 0) || (b->size < 2) ) {
    /* b is a scalar or singleton or empty */
    r = b;
    return 0;
  }

  /* have at least 2 components */
  /* setup result trs */
  aplc_vectalloc(&shape, (b->rank-1), APLC_INT);
  /* copy all but axis i */
  for (j=0,k=0; j<b->rank; j++) {
    if (j != axis0)
      shape.ip[k++] = b->shape[j];
  }
  /* don't really know type yet -- guess */
  aplc_settrs(r, b->type, b->rank-1, shape.ip);
  /* values not allocated yet */
  flag = 0;
  /* compute expansion vector along reduced axis */
  e = aplc_esubi(axis0,b->rank,b->shape);
  /*  e=1;
  for (j=b->rank-1; j>axis0; j--)
  e *= b->shape[j];*/
  s = b->shape[axis0];
  t1 = e*s;
  t2 = t1-e;
  /* at s-1, ib = (ia div e) t1 + t2 + (ia mod e) */
  aplc_settrs(&b1, b->type, 0, (int *)0);
  aplc_settrs(&r1, b->type, 0, (int *)0);
  aplc_settrs(&rold, b->type, 0, (int *)0);
  aplc_link_scalar(&b1);
  aplc_link_scalar(&r1);
  aplc_link_scalar(&rold);
  for (ia=0; ia< r->size; ia++) {
    /* each result component comes from a reduction 
       r = b1 f b2 f ... f bn
       length of each loop is b->shape[axis-1]
       need starting b vector index
       b index offset
     */
    /* (offset div ei)*t1 + t2 + (offset mod e) */
    j = (ia / e)*t1 + t2 + (ia % e);
    aplc_cptrsval(&rold,0, b, j);
    for (k=1; k<s; k++) {
      j -= e;
      aplc_cptrsval(&b1,0, b, j);
      /* r = bn op r */
      f(&r1, &b1,&rold);
      aplc_cptrsval(&rold,0, &r1,0);
    }
    r->type = r1.type;
    if (!flag) {
      aplc_talloc(r);
      flag = 1;
    }
    aplc_cptrsval(r,ia, &r1, 0);
  }
  return 0;  
}

/* scan operator: 
   f \ b        FOV 
   f \[i] b     FOOVV
   - note currently axis assumes index origin is 1 ...
*/
extern int
aplc_scan(trs_t *r,  trs_t *a, aplc_fp_t f, trs_t *i, trs_t *b)
{
  trs_t r1, b1, rold;
  int axis, axis0, ia,ai,j,k,e,s,t1,t2, flag;
  union mp_struct shape;

  aplc_inittrs( &r1 );
  aplc_inittrs( &b1 );
  aplc_inittrs( &rold );
  if ( (! i) || (i->type == APLC_UKTYPE) ) {
    /* no axis; last axis */
    axis = b->rank;
  } else {
    /* axis specified in i 
     -- need scalar int */
    axis = aplc_get_int(i);
    /* axis = aplc_get_int(i) + 1 - aplc_ixorg; */
  }
  axis0 = axis-1;/* 0-origin axis */ 

  /* now check the shape of b */
  if ( (b->rank == 0) || (b->size < 2) ) {
    /* b is a scalar or singleton or empty */
    r = b;
    return 0;
  }

  /* have at least 2 components */
  /* setup result trs */
  aplc_vectalloc(&shape, b->rank, APLC_INT);
  /* copy all axes */
  for (j=0; j<b->rank; j++)
    shape.ip[j] = b->shape[j];
  /* don't really know type yet -- guess */
  aplc_settrs(r, b->type, b->rank, shape.ip);

  /* values not allocated yet */
  flag = 0;
  /* compute expansion vector along scan axis */
  e = aplc_esubi(axis0,b->rank,b->shape);
  /*  e=1;
  for (j=b->rank-1; j>axis0; j--)
  e *= b->shape[j];*/
  s = b->shape[axis0];
  t1 = e*s;
  t2 = t1-e;
  /* at s-1, ib = (ia div e) t1 + t2 + (ia mod e) */
  aplc_settrs(&b1, b->type, 0, (int *)0);
  aplc_settrs(&r1, b->type, 0, (int *)0);
  aplc_settrs(&rold, b->type, 0, (int *)0);
  aplc_link_scalar(&b1);
  aplc_link_scalar(&r1);
  aplc_link_scalar(&rold);
  for (ia=0; ia<r->size; ia++) {
    /* each result component comes from a reduction
       r = b1 f b2 f ... f bn
       length of each loop is index along axis
       starting b vector index is same as index of a
       b index offset */
    j = ia;
    /* need index along axis 
     ai = (offset div ei) mod si */
    ai = (ia/e)%s;
    aplc_cptrsval(&rold,0, b, j);
    for (k=1; k<=ai; k++) {
      j -= e;
      aplc_cptrsval(&b1,0, b, j);
      /* r = bn op r */
      f(&r1, &b1,&rold);
      aplc_cptrsval(&rold,0, &r1,0);
    }
    r->type = rold.type;
    if (!flag) {
      aplc_talloc(r);
      flag = 1;
    }
    aplc_cptrsval(r,ia, &rold, 0);
  }
  return 0;  
}

#define XDEBUG 0

/* reshapex - variant of reshape
   r <- i .rhox b  
 
   i may or may not have more components than shape of b

   also see trs.c for more details

*/
extern int
aplc_reshapex(trs_t *r,  trs_t *a, trs_t *b)
{
  int rk = a->shape[0];
  int i, sp,rp;
  union mp_struct mptmp;

  /* errors */
  if ( (a->rank != 1) ||
       (a->type != APLC_INT) )
    aplc_error("[aplc_reshapex] error");
    
  /*if (rk <= b->rank) {*/
  if (rk == b->rank) {
    /* just return b unchanged */
#if XDEBUG 
    printf("[reshapex] return b\n");
#endif
    aplc_assign(r, b);
    return 0;
  } else if (b->rank < rk) {
#if XDEBUG 
    printf("[reshapex] rk %d > right rank %d\n",rk, b->rank);
#endif
    for (i=0, sp=1; i < rk - b->rank; i++)
      sp *= a->value.ip[i];
    rp = b->shape[0]/sp;
#if XDEBUG 
    printf(" sp %d\n", sp);
    printf(" rp %d\n", rp);
#endif
    /* selective copy from assign */
    r->type = b->type;
    r->rank = rk;
    /*r->shape = b->shape;*/
    r->shape = a->value.ip;
    /* overwrite end */
    r->shape[rk-b->rank] = rp;
    for (i=1; i< b->rank; i++)
      r->shape[rk-b->rank + i] = b->shape[i];
    r->size = b->size;
    r->alloc_ind = 0;
    /*r->scalar = b->scalar;*/
    if (r->alloc_ind & APLC_ALLOC_VAL_S) {
      /* scalar */
      aplc_link_scalar(r);
      r->alloc_ind |= APLC_ALLOC_VAL_S;
    } else
      r->value = b->value;
    /* now we don't want 2 freeable trs 
       - turn originals off */
#if XDEBUG 
    printf(" a alloc_ind %d\n", a->alloc_ind);
#endif
    if (a->alloc_ind & APLC_ALLOC_VAL_S) 
      r->alloc_ind |= APLC_ALLOC_SHAPE_NF;

    if (a->alloc_ind & APLC_ALLOC_VAL_F) 
      a->alloc_ind ^= APLC_ALLOC_VAL_F;
    if (b->alloc_ind & APLC_ALLOC_VAL_F) 
      b->alloc_ind ^= APLC_ALLOC_VAL_F;
    return 0;
  }
  /* else b->rank > rk */
#if XDEBUG 
  printf("[reshapex] rk %d, right rank %d...\n",rk, b->rank);
#endif
  r->type = b->type;
  r->rank = rk-1 + b->rank;
  aplc_vectalloc(&mptmp, r->rank, APLC_INT);
  r->shape = mptmp.ip;
  /* copy first part of shape, from a */
  for (i=0, sp=1; i< rk-1; i++) {
    r->shape[i] = a->value.ip[i];
    sp *= a->value.ip[i];
  }
  rp = b->shape[0]/sp;
#if XDEBUG 
  printf(" sp %d\n", sp);
  printf(" rp %d\n", rp);
#endif
  /* overwrite end */
  r->shape[rk-1] = rp;
  for (i=1; i< b->rank; i++)
    r->shape[rk + i - 1] = b->shape[i];
  r->size = b->size;
  r->alloc_ind = APLC_ALLOC_SHAPE_F;
  /*r->scalar = b->scalar;*/
  if (r->alloc_ind & APLC_ALLOC_VAL_S) {
    /* scalar */
    aplc_link_scalar(r);
    r->alloc_ind |= APLC_ALLOC_VAL_S;
  } else
    r->value = b->value;
  /* now we don't want 2 freeable trs 
     - turn originals off */
#if XDEBUG 
  printf(" a alloc_ind %d\n", a->alloc_ind);
#endif
  if (b->alloc_ind & APLC_ALLOC_VAL_F) 
    b->alloc_ind ^= APLC_ALLOC_VAL_F;
  return 0; 
}

/* end */

