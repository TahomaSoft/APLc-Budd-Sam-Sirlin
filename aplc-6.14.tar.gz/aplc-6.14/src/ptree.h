/*
	APL Compiler

	parse tree function declarations
	Samuel W.  Sirlin (sws)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 02111-1307, USA.

*/

#ifndef _APLC_PTREE_H
#define _APLC_PTREE_H

#include "parse.h"
#include "psym.h"
#include "ptree_s.h"

extern int slen(char *c);

/* ptree.c */

struct headnode *newhead(char *, char *, char *);

void direct(char *, struct node *);
struct statenode *newstate(char *, struct node *);
struct statenode *addstmt(struct statenode *, struct statenode *);
struct node *newnode(int);
struct node *pt1(int, struct node *);
void ptaxis(struct node *, struct node *, int);
void ptgaxis(struct node *, struct node *, int);
struct node *pt1a(int, struct node *, int, struct node *);
struct node *pt1o(int, enum sfuns, struct node *);
struct node *pt1ao(int, enum sfuns, struct node *, struct node *, int);
struct node *pt2(int, struct node *, struct node *);
struct node *pt2a(int, struct node *, int, struct node *, struct node *);
struct node *pt2o(int, enum sfuns, struct node *, struct node *);
struct node *pt2ao(int, enum sfuns, struct node *, int, 
   struct node *, struct node *);
struct node *pt2aos(int, enum sfuns, struct node *, int, 
   struct node *, struct node *);
struct node *pt2s(int type, struct node *lt, struct node *st, 
		  struct node *rt);
struct node *ptsort(int, struct node *);

struct node *ptsvec(char *);
struct node *ptval(int, int);
struct node *aptval(struct node *);
struct node *ptvec(struct node *, int, int);

struct node *sysparm(char *);
struct node *ptvar(struct symnode *);
struct node *ptfun(struct symnode *, struct node *, struct node *);

struct node *ptmrho(struct node *);
struct node *ptmsys(int type, enum sfuns op, struct node * child);
struct node *ptsub(struct node *, struct node *);
struct node *pttop(struct node *);
struct node *ptsemi(struct node *, struct node *);

#endif /* _APLC_PTREE_H */
/* end of ptree.h */
