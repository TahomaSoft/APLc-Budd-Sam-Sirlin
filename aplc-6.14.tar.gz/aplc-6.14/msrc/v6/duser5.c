/* duser.c 
   gateway program from matlab to aplc

   dyadic apl function 
   r .is a user b

  3/95 sws
  2/2004 updated to allow passing multidimensional data
         real, complex, character
*/

#include <math.h>
#include "mex.h"
#include "matrix.h"

#include "aplc.h"

extern int user(struct trs_struct *c, struct trs_struct *a, 
                struct trs_struct *b);

static void matapl_freearg(struct trs_struct *a);
static void mat2apl(mxArray *p, struct trs_struct *a);

#define DDEBUG 0

/* function to carefully clear the arguments */
static void
matapl_freearg(struct trs_struct *a)
{
  switch(a->type) {
  default:
    aplc_free_shape(a);
    break;
  case APLC_CHAR:
    aplc_detalloc(a);
    break;
  }
  return;
}


/* transfer data matlab->apl */
static void
mat2apl(mxArray *p, struct trs_struct *a)
{
  int type, rank, *r;
  const int *mshape; 
  int i;
  int status;

#if DDEBUG
  fprintf(stderr,"type r%d, c%d\n", mxIsDouble(p), mxIsComplex(p));
#endif
  /* note complex data will return true for mxIsComplex() and 
     mxIsDouble() */
  if (mxIsComplex(p))
    type = APLC_COMPLEX;
  else if ( mxIsDouble(p)) 
    type = APLC_REAL;
  else if (mxIsChar(p))
    type = APLC_CHAR;
  else
    mexErrMsgTxt("type error");
  rank = mxGetNumberOfDimensions(p);
  mshape = mxGetDimensions(p);
#if DDEBUG
  fprintf(stderr,"type %d, rank %d, shape [",type,rank);
  for (i=0; i<rank; i++)
    fprintf(stderr,"%d ",mshape[i]);    
  fprintf(stderr,"]\n");    
#endif

  /* apl shape is reversed */
  r = (int *)malloc(rank);
  for (i=0; i<rank; i++)
    r[i] = mshape[rank-1-i];
  aplc_settrs(a, type, rank, r);
  switch(type) {
  default:
  case APLC_REAL:
    a->value.rp = mxGetPr( p);
#if DDEBUG
    fprintf(stderr,"values [");
    for (i=0; i<a->size; i++)
      fprintf(stderr," %g ", a->value.rp[i]);
    fprintf(stderr,"]\n");
#endif
    break;
  case APLC_COMPLEX:
    a->value.zp[0] = mxGetPr( p);
    a->value.zp[1] = mxGetPi( p);
    break;
  case APLC_CHAR:
#if 0
    aplc_talloc(a);/* allocate space */
#endif
    /* need space for \0 */
    a->value.cp = (char *) malloc(a->size+1);
    /* mxCHAR *mxGetChars(const mxArray *array_ptr);*/
    status = mxGetString(p, a->value.cp, 1+a->size);
    if (status != 0) 
      mexErrMsgTxt("memory error");
    break;
  }
  return;
}

void
mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) 
{
  static  struct trs_struct c, a, b;
  int rank, *rc;
  int rc1 = 1;
  int i;
  double *cpr, *cpi;
  mxChar *charData;

  /* put inputs in trs_struct
     note that apl gets the transpose


 int elements, j, number_of_dims, cmplx;
  int nnz = 0, count = 0; 
  double *pr, *pi, *pind;
  const int  *dim_array;    

 elements = mxGetNumberOfElements(prhs[0]);

  number_of_dims = mxGetNumberOfDimensions(prhs[0]);
 dim_array = mxGetDimensions(prhs[0]);
 */

  mat2apl(prhs[0], &a);
  mat2apl(prhs[1], &b);
  /* call the apl function */
  user(&c, &a,&b);

#if DDEBUG
  printf("return value: ");
  printf("type %d, rank = %d, size = %d, ", c.type, c.rank, c.size);
  printf("shape = ");
  for (i=0; i<c.rank; i++)
    printf("%d ", c.shape[i]);
  printf("\n");
  if (c.type == APLC_REAL) {
    printf("values [");
    for (i=0; i<c.size; i++)
      printf("%g ", c.value.rp[i]);
    printf("]\n");
  }
  if (c.type == APLC_CHAR) {
    printf("values [");
    for (i=0; i<c.size; i++)
      printf("%c", c.value.cp[i]);
    printf("]\n");
  }
#endif

  /* put the results in output structure for matlab 
     note matlab gets the transpose of the apl result */

  /*

  plhs[0] = mxCreateString(output_buf);

  mxArray *mxCreateCharArray(int ndim, const int *dims);

  mxCHAR *mxGetChars(const mxArray *array_ptr);

  int nelem = mxGetNumberOfElements(plhs[0]);
  mxChar *charData = (mxChar *)mxGetData(plhs[0]);


  plhs[0] = mxCreateDoubleMatrix(nnz, number_of_dims, mxREAL);
  plhs[0] = mxCreateDoubleMatrix(rows, cols, mxCOMPLEX);

  mxArray *mxCreateNumericArray(int ndim, const int *dims, 
                mxClassID class, mxComplexity ComplexFlag);

                mxXlassID's:
                mxDOUBLE_CLASS,
                mxCHAR_CLASS
  */

  rank = c.rank;
  /* reverse shapes for matlab */
#if 0
  /*rc = (int *) mxMalloc(c.size);*/
  rc = (int *) malloc(c.size);
  for (i=0; i<rank; i++)
    rc[i] = c.shape[rank-1-i];
#else
  if (rank < 1) {
    rank = 1;
    rc = &rc1;
  } else {
  rc = (int *) malloc(rank);
  for (i=0; i<rank; i++)
    rc[i] = c.shape[rank-1-i];
  }
#endif
#if DDEBUG
  fprintf(stderr," have c shape , type %d\n", c.type);
#endif
  switch(c.type) {
  case APLC_INT:
  case APLC_BOOL:
    plhs[0] = mxCreateNumericArray(rank, rc, mxDOUBLE_CLASS, mxREAL);
    cpr = mxGetPr( plhs[0]);
    for (i=0; i<c.size; i++)
      cpr[i] = c.value.ip[i];
    break;
  case APLC_REAL:
#if DDEBUG
    fprintf(stderr," build real array\n");
#endif
    plhs[0] = mxCreateNumericArray(rank, rc, mxDOUBLE_CLASS, mxREAL);
    cpr = mxGetPr( plhs[0]);
#if DDEBUG
    fprintf(stderr," pop real array\n");
#endif
    for (i=0; i<c.size; i++)
      cpr[i] = c.value.rp[i];
    break;
  case APLC_COMPLEX:
    plhs[0] = mxCreateNumericArray(rank, rc, mxDOUBLE_CLASS, mxCOMPLEX);
    cpr = mxGetPr( plhs[0]);
    cpi = mxGetPi( plhs[0]);
    for (i=0; i<c.size; i++) {
      cpr[i] = c.value.zp[0][i];
      cpi[i] = c.value.zp[1][i];
    }
    break;
  case APLC_CHAR:
    plhs[0] = mxCreateCharArray(rank, rc);
    charData = mxGetChars(plhs[0]);
    for (i=0; i<c.size; i++)
      charData[i] = c.value.cp[i];
    break;
  default:
    fprintf(stderr,"type %d not handled\n", c.type);
    mexErrMsgTxt("return type error");
    break;
  }
#if DDEBUG
  fprintf(stderr," done with types\n");
#endif
  /*free(c.value.rp);*/
  matapl_freearg(&a);
  matapl_freearg(&b);
  aplc_detalloc(&c);
#if DDEBUG
  fprintf(stderr,"mexFuntion done\n");
#endif
  return;
}

