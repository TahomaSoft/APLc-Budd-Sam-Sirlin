
int
fib(int n)
{
  if (n < 2)
    return 1;
  return fib(n-1) + fib(n-2);
}

void
main(void)
{
#if 0
  printf("%d\n", fib(30));
#else
  int i;

  for (i=2; i<31; i++)
    printf("fib(%d) = %d\n", i, fib(i));
#endif
}
