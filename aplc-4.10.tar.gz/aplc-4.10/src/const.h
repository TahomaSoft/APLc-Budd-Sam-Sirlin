/* 
aplc 
sws  1/8/96

some externals to const.c 

*/

#ifndef _CONST
#define _CONST

/* functions */
extern void setlocalcons(void);
extern void resetconsts(void);

extern int addicon(int i);

extern int addrcon(double x);

extern int addzcon(double x[2]);
extern int addr2zcon(double x);

extern int addqcon(double x[4]);
extern int addz2qcon(double x[2]);
extern int addr2qcon(double x);

extern int addocon(double x[8]);
extern int addq2ocon(double x[4]);
extern int addz2ocon(double x[2]);
extern int addr2ocon(double x);

extern int addlcon(char *x);
struct node* ivec2rvec(struct node *ivec);
struct node* rvec2zvec(struct node *rvec);
struct node* zvec2qvec(struct node *zvec);
struct node *qvec2ovec(struct node *qvec);

extern void expanivec(struct node *ivec, double r);
extern void expanrvec(struct node *rvec, double z[2]);

/* variables */

extern int ictop, rctop, zctop, qctop, octop, sctop, lctop;
extern int *iconsts; 
extern double *rconsts;
extern double *zconsts[2];
extern double *qconsts[4];
extern double *oconsts[8];
extern char *sconsts;
extern struct label_struct lconsts[];

#endif
/* end of const.h */ 
