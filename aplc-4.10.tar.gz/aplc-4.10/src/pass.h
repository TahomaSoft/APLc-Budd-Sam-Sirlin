/* sws    pass.h 
        declarations for stuff in the pass group of code

const.c
pass.c
iotree.c

*/

#ifndef _PASS
#define _PASS

/* iotree.c */
/*
Test for flag to pipe intermediate results as integers rather than
characters. For dos text file mode.

The functions are used in: iotree.c, pass.c, psym.c

This file just defines the old method. The new definitions may be 
found in iotree.c

*/
#ifndef CHARINT
/* original versions of the output functions */
#define  fwriten  fwrite
#define  putcharn  putchar
#define  freadn  fread
#define  getcharn  getchar

#else
/* prototype for modified versions */
extern void fwriten(char *, int, int, FILE *);
extern void freadn(char *, int, int, FILE *);
extern void putcharn(char);
extern int getcharn(void);

#endif

/* iotree.c */ 
extern void error(char *c);
void putname(char *c);
void putheader(struct headnode *head);
char *gets_safe(char *c);
char *getfname(char *c);
extern void gethead(struct headnode * head, char *name, char *asvar, 
		    char *parm1, char *parm2);
void putsyms(struct symnode *syms);
struct symnode *getsyms(void);
extern void frecode(struct statenode * code);
extern void fresyms(struct symnode * syms);

void put_lcon(void);
void get_lcon(void);

void putconsts(void);
void putcode(struct statenode *code);

struct statenode *rdcode(void);
void putnode(struct node *);
struct node *innode(void);
void frenode(struct node *);
extern void writecode(int top, struct headnode * head, 
		      struct symnode * syms, struct statenode * code);
extern void rdconsts(void);


/* expected in the particular application */
void doprog(struct headnode * head, struct symnode * syms, 
	    struct statenode * code);
void glbvar(char *name);
void passinit(int verbose);

#endif
/* end of pass.h */
