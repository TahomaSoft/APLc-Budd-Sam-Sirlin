/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/
/*
            This pass is in charge of code generation.
		code generation - print out declarations,
		call routines to generate code
		timothy a. budd / sws

                (gen.c was dcls.c)
*/

#include "parse.h"
#include "gen.h"
#include "y_tab.h"

/* external variables used:
extern int *iconsts, ictop, rctop, sctop, lctop;
extern double *rconsts;
extern char *sconsts;
extern union label_struct lconsts[];
*/

extern char *funname;

/* a constant zero - used several places */
struct node *zeronode;

/* for debugging printout */
#define GDEBUG 0
#define nl()   printf("\n")


/* these are defined for the pass:
void passinit(int verbose);
void glbvar(char *name);
void doprog(struct headnode * head, struct symnode * syms, struct statenode * code);
*/

/* local functions */
static void listpunct(int i, int vartop);
static void gcdcls(void);

static void gen_const_dcls(struct statenode * code);
static void gen_const_do_stmt(struct node *node);

static void do_stmt(struct node *node);
static void do_early(struct node *node);
static void early_search(struct node *node);
static void stcode(struct node *node);


/* passinit - initialize this pass */
void 
passinit(int verbose)
{
  /* sws */
  if (verbose)
    fprintf(stderr, "Starting code generation\n");

/* ---------------------------------------------------------------- */
#ifdef MUSER
  /* for multiple users, aplc.h in system include directory */
   printf("#include <aplc.h>\n");
#else
  /* for single user, aplc.h in directory */
   printf("#include \"aplc.h\"\n");
#endif

#if 1
  printf("#include <setjmp.h>\n");
  printf("extern jmp_buf aplc_env;\n");
#endif


   /* declare some global trs's for null args of fns */
   printf("static struct trs_struct trs_n1, trs_n2;\n");

/* ---------------------------------------------------------------- */

  zeronode = structalloc(node);
}

/* glbvar - process a global variable name */
void 
glbvar(char *name)
{
  printf("extern struct trs_struct %s;\n", name);
}

/* sws
   print some punction for lists */
static void
listpunct(int i, int vartop)
{
  if ( (i + 1) < vartop ) {
    commasp();
    if (i % 10 == 9)
      nl();
  } else {
    printf("}");
    seminl();
  }
}

static void
listpunct_sub(int i, int vartop)
{
  if ( (i + 1) < vartop ) {
    commasp();
    if (i % 10 == 9)
      nl();
  } else {
    printf("}");
  }
}


/* gcdcls - generate constant declarations */
static void 
gcdcls(void)
{
  int i, n;
  /*int j;*/

  if (ictop) {
    printf("int i_%s[%d] = {", funname, ictop);
    if (ictop > 9)
      nl();
    for (i = 0; i < ictop; i++) {
      /* printf("%d%c ", iconsts[i], ((i + 1) < ictop ? ',' : '}'));*/
      printf("%d", iconsts[i]);
      listpunct(i, ictop);
    }
  }

  if (rctop) {
    printf("double r_%s[%d] = {", funname, rctop);
    if (rctop > 9)
      nl();
    for (i = 0; i < rctop; i++) {
      /* printf("%g%c ", rconsts[i], ((i + 1) < rctop ? ',' : '}'));*/
      /*printf("%23.16g", rconsts[i]);*/
      /*printf("%23.16e", rconsts[i]);*/
      printf("%22.15e", rconsts[i]);
      listpunct(i, rctop);
    }
  }

#if 0
  if (zctop) {
    printf("double z_%s[2][%d] = {", funname, zctop);
    if (zctop > 9)
      nl();
    for (j=0; j<2; j++) {
      printf("{ ");
      for (i = 0; i < zctop; i++) {
	printf("%22.15e", zconsts[j][i]);
	listpunct_sub(i, zctop);
      }
      listpunct(j, 2);nl();
    }
  }

  if (qctop) {
    printf("double q_%s[%d] = {", funname, qctop);
    if (qctop > 9)
      nl();
    for (i = 0; i < qctop; i++) {
      printf("%22.15g", qconsts[i]);
      listpunct(i, qctop);
    }
  }
#endif

  if (sctop) {
    /* sws
       changed char declaration to avoid long unbreakable strings
       later this should be individual strings, if possible?...
       - also need to escape some special characters 
       */
    /* printf("char c_%s[] = \"%s\";\n", funname, sconsts); */

    n = strlen(sconsts);
    printf("char c_%s[] = {", funname);
    if (n > 9)
      nl();
    for (i = 0; i < n; i++) {
      /* sws  watch for long lines */
      if (i > 0) {
	printf(",");
	if (0 == i % 10)
	  printf("\n");
      }
      /* sws  watch for special characters */
      if (sconsts[i] == '\'')
	printf("'\\''");	     /* sws -  quote in string */
      else if (sconsts[i] == '\\')
	printf("'\\\\'");	     /* sws -  \ in string */
      else if (sconsts[i] == '\n')
	printf("'\\n'");	     /* sws -  \n in string */
      else
	printf("'%c'", sconsts[i]);

    }
    printf("}");
    seminl();
  }
#if 0
  /* sws shouldn't need this anymore */
  if (lctop) {
    printf("int l_%s[%d] = {", funname, lctop);
    if (lctop > 9)
      nl();
    for (i = 0; i < lctop; i++) {
      printf("%d", lconsts[i].label_num);
      listpunct(i, lctop);
    }
  }
#endif
}

/* sws
   new fn to generate component that can be pointed to by trs

   loop through all statements
   prepare constants
   use index that would index into xx_main as specifier:
   z_main[3] <-> z_main3
   */
static void
gen_const_dcls(struct statenode * code)
{
  struct statenode *p;

  for (p = code; p != NILSTATE; p = p->nextstate) {
    gen_const_do_stmt(p->code);
  }
  return;
}

/* sws
   search through a statement 
   generate the declaration

   only zcon, qcon, ocon
*/
static void
gen_const_do_stmt(struct node *node)
{
  int i, j;
  int size;

  if (NULL == node)
    return;
  if ( node->nodetype == ZCON ) {
    /* get size */
    size = 1;
    for (i=0; i<node->rank.n; i++)
      size *= iconsts[node->shape.n +i];
    printf("double z_%s%d[2][%d] = {\n", funname, node->values.n, size);
    for (j=0; j<2; j++) {
      printf("{ ");
      for (i=0; i<size; i++) {
	printf("%22.15e", zconsts[j][i+node->values.n]);
	listpunct_sub(i, size);
      }
      listpunct(j, 2);nl();
    }
    return;
  }
  if ( node->nodetype == QCON ) {
    /* get size */
    size = 1;
    for (i=0; i<node->rank.n; i++)
      size *= iconsts[node->shape.n +i];
    printf("double q_%s%d[4][%d] = {\n", funname, node->values.n, size);
    for (j=0; j<4; j++) {
      printf("{ ");
      for (i=0; i<size; i++) {
	printf("%22.15e", qconsts[j][i+node->values.n]);
	listpunct_sub(i, size);
      }
      listpunct(j,4);nl();
    }
    return;
  }
  if ( node->nodetype == OCON ) {
    /* get size */
    size = 1;
    for (i=0; i<node->rank.n; i++)
      size *= iconsts[node->shape.n +i];
    printf("double o_%s%d[8][%d] = {\n", funname, node->values.n, size);
    for (j=0; j<8; j++) {
      printf("{ ");
      for (i=0; i<size; i++) {
	printf("%22.15e", oconsts[j][i+node->values.n]);
	listpunct_sub(i, size);
      }
      listpunct(j,8);nl();
    }
    return;
  }
  gen_const_do_stmt(RIGHT);
  if ( use_axis_node(node->nodetype) ) {
    gen_const_do_stmt(AXIS);
  }
  gen_const_do_stmt(LEFT);
  return;
}

#define INMAIN  (head == NILHEAD || head->fname == NILCHAR) 

/* doprog - process function */
void 
doprog(struct headnode * head, struct symnode * syms, 
       struct statenode * code)
{
  struct statenode *p;
  struct symnode *sy;
  int i;

  /* generate function declaration */
  if (head == NILHEAD || head->fname == NILCHAR)  {
    /* we're in main */
    printf("/* ------------- main ------------- */\n");
    /* give the real (not forward) declarations for global variables */
    for (sy = syms; sy != NILSYM; sy = sy->next) {
      printf("struct trs_struct %s;\n", sy->name);
    }
    gcdcls();
    gen_const_dcls(code);
    /* Declare main as an int, and return 0         */
    printf("int\nmain(int argc, char *argv[]) {\n");
  } else {
    /* a function, not main */
    printf("/* ------------- %s ------------- */\n",head->fname);
    gcdcls();
    gen_const_dcls(code);
    if (head->asvar == NILCHAR)
      head->asvar = "_no1";
    if (head->parm1 == NILCHAR)
      head->parm1 = "_no2";
    if (head->parm2 == NILCHAR)
      head->parm2 = "_no3";
    /* sws keep things k&r for now */
    /* printf("void %s(%s, %s, %s)\n", head->fname, head->asvar, */
#if 0
    /* old k&r version for function declaration */ 
    printf("int %s(%s, %s, %s)\n", head->fname, head->asvar,
	head->parm1, head->parm2);
    printf("struct trs_struct *%s, *%s, *%s;\n",
	head->asvar, head->parm1, head->parm2);
#else
    /* ansi function declaration */
    printf("int\n%s", head->fname);
    printf("(struct trs_struct *%s, struct trs_struct *%s, struct trs_struct *%s)\n",
	head->asvar, head->parm1, head->parm2);
#endif
    printf("{\n");

    /* give declarations for local variables */
    for (sy = syms; sy != NILSYM; sy = sy->next)
      if (!is_parm(sy->name))
	printf("struct trs_struct %s;\n",
	    sy->name);
  }
  /* - declare statment number 
     stmtno needs to be local to each fn     */
  printf("int stmtno;\n");

  /* generate declarations for registers */
  if (head->maxtrs > 0) {
    printf("struct trs_struct ");
    for (i = 1; i <= head->maxtrs; i++) {
      printf("trs%d%c ", i, (i == head->maxtrs) ? ';' : ',');
      if (i % 10 == 9)
	nl();
    }
    nl();
  }
  if (head->maxmp > 0) {
    printf("union mp_struct ");
    for (i = 1; i <= head->maxmp; i++) {
      printf("mp%d%c ", i, (i == head->maxmp) ? ';' : ',');
      if (i % 10 == 9)
	nl();
    }
    nl();
  }
  if (head->maxres > 0) {
    printf("union res_struct res0, ");
    for (i = 1; i <= head->maxres; i++) {
      printf("res%d%c ", i, (i == head->maxres) ? ';' : ',');
      if (i % 10 == 9)
	nl();
    }
    nl();
  }
  /*printf("int i0%c ", (head->maxi) ? ',' : ';');*/
  /* sws  always make i0=0, for singleton indices */
  printf("int i0 = 0;/* for singleton indices */\n");
  if (head->maxi > 0) 
    printf("int ");
  for (i = 1; i <= head->maxi; i++) {
    printf("i%d%c ", i, (i == head->maxi) ? ';' : ',');
    if (i % 10 == 9)
      nl();
  }
#if 0
  /* sws 1/16/2000 no longer needed; val pointer now internal to trs */
  /* declare res for known scalars */
  printf("\n/* declations for known scalars */\n"); 
  /* initialize local named trs's */
  for (sy = syms; sy != NILSYM; sy = sy->next) {
    if (!is_parm(sy->name)) {
      if (sy->vrank == 0) 
	printf("union res_struct res_%s;\n",sy->name);
    }
  }
#endif
  printf("/* end of declarations */\n\n");

  /* give initial values to variables */

  if (INMAIN) {
    /* input arguments made accessible */
    printf("aplc_setargs(argc, argv);\n");
  }


  /* initialize trs's */
  for (i = 1; i <= head->maxtrs; i++) {
    inittrs(i);
  }
  /* initialize local named trs's */
  for (sy = syms; sy != NILSYM; sy = sy->next) {
    if (!is_parm(sy->name)) {
      printf("/* local %s: type= {%s}, rank= {%s} */ \n", sy->name, 
	     str_type_name(sy->type), str_rank(sy->vrank));
      if ( (sy->type != APLC_UNDEF) && 
	   (sy->type != APLC_UKTYPE) && 
	   (sy->type != APLC_ANY) && 
	   (sy->vrank == 0) ){
	printf("%s.type = %s;\n", sy->name, type_str(sy->type));
	printf("%s.rank = %d;\n", sy->name, sy->vrank);
	printf("%s.shape = aplc_ivone;\n", sy->name);
	printf("%s.alloc_ind = APLC_ALLOC_NF;\n", sy->name);
	/* printf("%s.value.%s = &res_%s.%s;\n", 
	       sy->name, mp_type_str(sy->type),
	       sy->name, res_type_str(sy->type));*/
	if (sy->type == APLC_COMPLEX) {
#if 0
	  printf("%s.value.%s[0] = &(%s.scalar.%s[0]);\n", 
		 sy->name, mp_type_str(sy->type),
		 sy->name, res_type_str(sy->type));
	  printf("%s.value.%s[1] = &(%s.scalar.%s[1]);\n", 
		 sy->name, mp_type_str(sy->type),
		 sy->name, res_type_str(sy->type));
#endif
	  ;
	} else if ( (sy->type == APLC_QUAT) ||
		    (sy->type == APLC_OCT) ) {
	  ;
	} else
	  printf("%s.value.%s = &%s.scalar.%s;\n", 
		 sy->name, mp_type_str(sy->type),
		 sy->name, res_type_str(sy->type));
      } else
	inittrsn(sy->name);
    }
    /* initialize result trs */
    if ( (head->asvar != NILCHAR) && 
	 (strcmp(head->asvar, sy->name) == 0) ) {
      printf("/* asvar %s: type= {%s}, rank= {%s} */ \n", sy->name, 
	     str_type_name(sy->type), str_rank(sy->vrank));
      /* check for scalar */
      if ( (sy->type != APLC_UNDEF) && 
	   (sy->type != APLC_UKTYPE) && 
	   (sy->type != APLC_ANY) && 
	   (sy->vrank == 0) ){
	printf("%s->type = %s;\n", sy->name, type_str(sy->type));
	printf("%s->rank = %d;\n", sy->name, sy->vrank);
	printf("%s->shape = aplc_ivone;\n", sy->name);
	printf("%s->alloc_ind = APLC_ALLOC_NF;\n", sy->name);
	if (sy->type == APLC_COMPLEX) {
	  printf("%s->value.%s[0] = &(%s->scalar.%s[0]);\n", 
		 sy->name, mp_type_str(sy->type),
		 sy->name, res_type_str(sy->type));
	  printf("%s->value.%s[1] = &(%s->scalar.%s[1]);\n", 
		 sy->name, mp_type_str(sy->type),
		 sy->name, res_type_str(sy->type));
	} else
	  printf("%s->value.%s = &%s->scalar.%s;\n", 
		 sy->name, mp_type_str(sy->type),
		 sy->name, res_type_str(sy->type));
	/* printf("aplc_vectalloc(&%s->value, 1, %s);\n",
	       sy->name, type_str(sy->type));*/
      } else
	inittrsnp(sy->name);
    }
  }

  /* generate switch statement surrounding code */
  printf("\nstmtno = 1;\n");
  printf("while (stmtno)\n switch(stmtno) {\n");
  printf("default: stmtno = 0;\n   break;\n");

  /* generate code for each statement */
  stmtno = 0;
  for (p = code; p != NILSTATE; p = p->nextstate) {
    stmtno++;
    if (p->label != NILCHAR) {
      /* add a comment before the code with the label name */
      for (i=0; (i<lctop) && (stmtno != lconsts[i].label_num); i++)
	;
      if (i<lctop)
	printf("/* %s: */\n", lconsts[i].label_name);
    }
    printf("case %d: stmtno = %d;\n", stmtno, stmtno);
    printf("aplc_trace(\"%s\", %d);\n", funname, stmtno);
    do_stmt(p->code);
  }

  /* generate ending stuff */
  printf("stmtno = 0;\n");
  rbr();/* ends switch statement */
  /* free any local memory */
  for (sy = syms; sy != NILSYM; sy = sy->next)
    if (!is_parm(sy->name))
      printf("aplc_detalloc(&%s);\n", sy->name);
  printf("return(0);\n");/* return value */
  rbr();/* ends  function */
  printf("\n");/* some extra space */
}

/* 
   generate code for a statement - line of code

   - this checks to see if we have an early bind situation, where an
   assignment must completed first and then used later in the same
   statement

   */
static void
do_stmt(struct node *node)
{
#if GDEBUG
  fprintf(stderr,"do_stmt [%d] %s\n", stmtno, prtoken(node->nodetype));
#endif
  early_search(node);
  stcode(node);
}

/* 
   - search through a statement for assign with EARLYBIND
   - if found, unset earlybind, run do_stmt starting there
   - then reset earlybind, so when we come back to node it will act like an ident 

   (- then set earlydone, so when we come back to node it will act like an ident )
 */
static void
do_early(struct node *node)
{
#if GDEBUG
  fprintf(stderr,"do_early %s\n", node->left->a.namep);
#endif
  if (NULL == node)
    return;
  /* need to generate code here */
  node->info ^= EARLYBIND;  /* unset */
  do_stmt(node);
  node->info |= EARLYBIND;  /* now reset */
}

/* 
   search a statement starting at node for an assign node with EARLYBIND 
   - if found, stop and return that node 
   - if not found, return null
   */
static void 
early_search(struct node *node)
{
  /* fprintf(stderr,"early_search\n");*/
  if (NULL == node)
    return;
#if GDEBUG
  fprintf(stderr,"early_search not null (%d) %s\n", 
	  node->nodetype,
	  prtoken(node->nodetype));
#endif
  if ( (node->nodetype == ASSIGN ) &&
       (node->info & EARLYBIND) ) {
    do_early(node);
    return;
  }
#if GDEBUG
  fprintf(stderr,"early_search right\n");
#endif
  early_search(RIGHT);
  if ( use_axis_node(node->nodetype) ) {
#if GDEBUG
    fprintf(stderr,"early_search axis\n");
#endif
    early_search(AXIS);
  }
#if GDEBUG
  fprintf(stderr,"early_search left\n");
#endif
  early_search(LEFT);
  return;
}

/* 
   actually generate the code for statement starting at node 
*/
static void
stcode(struct node *node)
{
#if GDEBUG
  fprintf(stderr,"stcode\n");
#endif
  switchbox(node, SHAPE, 1);
  switchbox(node, FINISH, 1);
}

/* end of gen.c */


