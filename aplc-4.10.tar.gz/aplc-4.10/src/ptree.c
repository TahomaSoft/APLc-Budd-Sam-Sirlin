/*
	apl compiler
		build new parse tree nodes
			timothy a. budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

#include <stdio.h>
#include <string.h>

#include "parse.h"
#include "ptree.h"
#include "y_tab.h"


/* externals from yacc */
extern void prog(struct headnode * head, struct statenode * code);
extern void yyerror(char *c);

/* slen - string length without escape characters 
   - sws; don't use c escapes...
*/
extern int
slen(char *c)
{
  int i;
  char *p;

  i = 0;
  for (p = c; *p; p++)
/*	if (*p != '\\')*/
    i++;
  return (i);
}


/* newid - create a new id string */
char *
newid(char *name)
{
  char *x;

  x = (char *) malloc((unsigned) strlen(name) + 1);
  if (x == NILCHAR)
    yyerror("out of space");
  strcpy(x, name);
  return (x);
}

/* newhead - make a new function header node */
struct headnode *
newhead(char *name, char *parm1, char *parm2)
{
  struct headnode *x;

  x = structalloc(headnode);
  if (x == NILHEAD)
    yyerror("out of space");
  enterid(name, FUNCTION, APLC_UKTYPE, NORANK);
  x->fname = name;
  x->asvar = NILCHAR;
  x->parm1 = parm1;
  x->parm2 = parm2;
  if (parm1 != NILCHAR)
    enterid(parm1, PARAM, APLC_UKTYPE, NORANK);
  if (parm2 != NILCHAR)
    enterid(parm2, PARAM, APLC_UKTYPE, NORANK);
  return (x);
}

/* direct - direct defintion declaration */
void 
direct(char *label, struct node * expr)
{
  struct node *x; 
  struct symnode *s;
  struct headnode *h;

  h = newhead(label, "_alpha", "_omega");
  h->asvar = "_zeta";
  idclass("_zeta", &s);
  x = pt2(ASSIGN, ptvar(s), expr);
  prog(h, newstate(NILCHAR, x));
  resetconsts();
  reinitsymtab();
}

/* newstate - produce a new statement node */
struct statenode *
newstate(char *label, struct node * code)
{
  struct statenode *x;

  if (code->nodetype == COMMENT && label == NILCHAR)
    return (NILSTATE);
  x = structalloc(statenode);
  if (x == NILSTATE)
    yyerror("out of space");
  x->label = label;
  x->code = code;
  x->nextstate = NILSTATE;
  x->list = NILSYM;
  return (x);
}

/* addstmt - add a statement to statement list */
struct statenode *
addstmt(struct statenode * first, struct statenode * new)
{
  struct statenode *i;

  if (new == NILSTATE)
    return (first);
  else if (first == NILSTATE)
    return (new);
  else {
    for (i = first; i->nextstate != NILSTATE; i = i->nextstate);
    i->nextstate = new;
    return (first);
  }
}

/* newnode - produce a new parse tree node */
struct node *
newnode(int type)
{
  struct node *x;

  x = structalloc(node);
  if (x == (struct node *) 0)
    yyerror("out of space");
  x->nodetype = type;
  x->info = 0;
  x->left = x->right = x->a.axis = x->store = NILP;
  x->type.n = x->rank.n = x->shape.n = x->values.n = 0;
  x->size.n = -1;
  x->optype = APLC_NOT;
  x->index = 0;
  return (x);
}

/* pt1 - simple 1 child node */
struct node *
pt1(int type, struct node * child)
{
  struct node *x;

  x = newnode(type);
  x->right = child;
  return (x);
}

/* ptaxis - process an (integer) axis specifier */
void 
ptaxis(struct node * x, struct node * axis, int ainfo)
{
  if (axis != NILP) {
    x->a.axis = pt1(CISCALAR, axis);
  } else {
    x->a.axis = NILP;
    x->info |= ainfo;
  }
}

/* ptgaxis - process a general axis specifier */
void 
ptgaxis(struct node * x, struct node * axis, int ainfo)
{
  if (axis != NILP) {
    x->a.axis = pt1(CSCALAR, axis);
  } else {
    x->a.axis = NILP;
    x->info |= ainfo;
  }
}

/* pt1a - 1 child node with axis */
struct node *
pt1a(int type, struct node * axis, int ainfo, struct node * child)
{
  struct node *x;

  x = pt1(type, child);
  ptaxis(x, axis, ainfo);
  return (x);
}

/* pt1o - 1 child node with operator */
struct node *
pt1o(int type, enum sops op, struct node * child)
{
  struct node *x;

  x = pt1(type, child);
  x->optype = op;
  return (x);
}

/* pt1ao - one child node with both axis and operator */
struct node *
pt1ao(int type, enum sops op, struct node * axis, struct node * child, int ainfo)
{
  struct node *x;

  x = pt1a(type, axis, ainfo, child);
  x->optype = op;
  return (x);
}

/* pt2 - simple 2 child node */
struct node *
pt2(int type, struct node * child1, struct node * child2)
{
  struct node *x;

  x = newnode(type);
  x->left = child1;
  x->right = child2;
  return (x);
}

/* pt2a - 2 child node with axis */
struct node *
pt2a(int type, struct node * axis, int ainfo, struct node * child1, 
     struct node * child2)
{
  struct node *x;

  x = pt2(type, child1, child2);
  /* sws  allow for real axis for cat - possible laminate */
  if (type != CAT)
    ptaxis(x, axis, ainfo);
  else
    ptgaxis(x, axis, ainfo);
  return (x);
}

/* pt2o - two child node with operator */
struct node *
pt2o(int type, enum sops op, struct node * child1, struct node * child2)
{
  struct node *x;

  x = pt2(type, child1, child2);
  x->optype = op;
  return (x);
}

/* pt2ao - two child node with both operator and axis */
struct node *
pt2ao(int type, enum sops op, struct node * axis, int ainfo, 
  struct node * child1, struct node * child2)
{
  struct node *x;

  x = pt2a(type, axis, ainfo, child1, child2);
  x->optype = op;
  return (x);
}

/* pt2aos - two child node with both operator and axis and store 
            sws  used for decode for an intermediate result
*/
struct node *
pt2aos(int type, enum sops op, struct node * axis, int ainfo, 
  struct node * child1, struct node * child2)
{
  struct node *x;

  x = pt2a(type, axis, ainfo, child1, child2);
  x->optype = op;
  x->store = pt1(SM, NILP);
  return (x);
}

/* ptsort - sort function */
struct node *
ptsort(int direction, struct node * child)
{
  struct node *x;

  x = pt1(SORT, child);
  x->a.ptr0 = direction;
  return (x);
}

/* ptsvec - string constant (vector) */
struct node *
ptsvec(char *chars)
{
  struct node *x;
  int len;

  x = newnode(SCON);
  x->type.n = (int) APLC_CHAR;
  len = slen(chars);
  x->shape.n = addicon(len);
  x->size.n = len;
  if (len == 1)
    x->rank.n = 0; /* sws  scalar */
  else
    x->rank.n = 1; /* vector */
  x->values.n = slen(sconsts);
  x->info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN |
      SHAPEKNOWN | VALUESKNOWN);
  if (strlen(chars) + strlen(sconsts) > MAXCONSTS)
    yyerror("too many string constants");
  strcat(sconsts, chars);
  /*fprintf(stderr,"[ptsvec] len %d, [%s]\n",len, chars);*/
  free(chars);/* was built with strdup */ 
  return (x);
}

/* ptval - scalar value */
struct node *
ptval(int type, int val)
{
  struct node *x;

  x = newnode(type);
  x->rank.n = 0;
  x->shape.n = 1;
  x->size.n = 1;
  x->values.n = val;
  x->info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN |
      SHAPEKNOWN | VALUESKNOWN);
  return (x);
}

/* aptval - add a scalar value, forming an array */
struct node *
aptval(struct node * node)
{
  node->rank.n = 1;
  node->shape.n++;
  return (node);
}

/* ptvec - constant vector */
struct node *
ptvec(struct node * x, int type, int rtype)
{

  x->nodetype = type;
  x->type.n = rtype;
  x->info |= (TYPEDECL | TYPEKNOWN);
  x->size.n = x->shape.n;
  if (x->rank.n)
    x->shape.n = addicon(x->shape.n);
  return (x);
}


struct node *
sysparm(char *name)
{
  struct symnode *x; 

  idclass(name, &x);
  if (x == NILSYM) {
    /* declare system generated variables */
    enterid(newid("_alpha"), PARAM, APLC_UKTYPE, NORANK);
    enterid(newid("_omega"), PARAM, APLC_UKTYPE, NORANK);
    enterid(newid("_zeta"), LOCAL, APLC_UKTYPE, NORANK);
    /* try it again */
    idclass(name, &x);
    if (x == NILSYM)
      yyerror("sysparm error");
  }
  return (ptvar(x));
}

/* ptvar - variable node */
struct node *
ptvar(struct symnode * var)
{
  struct node *x;

  x = newnode(IDENT);
  x->a.namep = var->name;
  if ((var->type != APLC_UKTYPE) & (var->type != APLC_ANY))
    x->info |= (TYPEDECL | TYPEKNOWN);
  x->type.n = var->type;
  if (var->vrank != NORANK)
    x->info |= (RANKDECL | RANKKNOWN);
  x->rank.n = var->vrank;
  return (x);
}

/* ptfun - functions
           used for dyadic or monadic user fns 
 */
struct node *
ptfun(struct symnode * fun, struct node * child1, struct node * child2)
{
  struct node *x;

  /* sws  old version used collects in apl.y */
  /* x = pt2(FIDENT, child1, child2); */

#ifdef  BYREF
  /* sws   this version will pass idents by reference */
  if (child1 != NILP)
    x = pt2(FIDENT, pt1(COLLECT, child1), pt1(COLLECT, child2));
  else
    x = pt2(FIDENT, child1, pt1(COLLECT, child2));
#else
  /*- sws   this version will always loop to collect idents,
            pass by value */
  if (child1 != NILP)
    x = pt2(FIDENT, pt1(CCOLLECT, child1), pt1(CCOLLECT, child2));
  else
    x = pt2(FIDENT, child1, pt1(CCOLLECT, child2));
#endif

  x->a.namep = fun->name;
  x->type.n = fun->type;
  if ((fun->type != APLC_UKTYPE) & (fun->type != APLC_ANY))
    x->info |= (TYPEDECL | TYPEKNOWN);
  x->rank.n = fun->vrank;
  if (fun->vrank != NORANK)
    x->info |= (RANKDECL | RANKKNOWN);
  return (x);
}

/* ptnillfun - functions
           used for nilladic user fns (sws)
 */
struct node *
ptnilfun(struct symnode * fun)
{
  struct node *x;

  x = pt2(FIDENT, NILP, NILP);
  x->a.namep = fun->name;
  x->type.n = fun->type;
  if ((fun->type != APLC_UKTYPE) & (fun->type != APLC_ANY))
    x->info |= (TYPEDECL | TYPEKNOWN);
  x->rank.n = fun->vrank;
  if (fun->vrank != NORANK)
    x->info |= (RANKDECL | RANKKNOWN);
  return (x);
}

/* ptmrho - monadic rho (shape)
   - could also be rho rho, or rank
 */
struct node *
ptmrho(struct node * child)
{
  struct node *x;

  if (child->nodetype == RHO) {
    /* rank case */
    x = child;
    x->nodetype = RHORHO;
  } else {
    x = newnode(RHO);
    x->right = child;
  }
  return (x);
}

/* ptmsys - msysfun
 */
struct node *
ptmsys(int type, enum sops op, struct node * child)
{
  struct node *x;

  if (child->nodetype == IDENT) {
    x = pt1(type, child);
  } else {
    /* add a collect */
    x = pt1(type, pt1(COLLECT, child));
  }
  x->optype = op;
  return (x);
}

/* ptstore - simple store child node */
struct node *
ptstore(int type)
{
  struct node *x;

  x = newnode(type);
  /* x->a.namep= NILCHAR; */
  return (x);
}

/* ptsub - subscripted assignment 

   SUB SUBASSIGN expression :     SUBASSIGN(SUB, expression)  

   sub is
   subid LB sublist RB : SUB(subid, sublist) 

   becomes
   SUBASSIGN
    left   subid
    right  expression
    axis   sublist (SM)
    store  SM
 */
struct node *
ptsub(struct node * child1, struct node * child2)
{
  child1->a.axis = child1->right;
  /* child1->left = child1->left */
  child1->right = child2;
  child1->store = pt1(SM, NILP);
  /* child1->store = NILP; */
  child1->nodetype = SUBASSIGN;
  return (child1);
}

/* sws 
   put a format after a boxassign 
   - format is smarter about spacing; 
   --- can't do this for non-top as it leaves a char   */
struct node *
ptboxass(struct node * child)
{
  struct node *x;
  /* box collect */
  if ( (child->nodetype == FORMAT) ||
       (child->nodetype == SCON)   ||
       (child->nodetype == FIDENT) ||
       (child->nodetype == COLLECT) )
    x = pt1(BOXASSIGN, child);/* no need */
  else
    x = pt1(BOXASSIGN, pt1(COLLECT,child));/* normal */
#if 0
  /* box format collect */
  if ( (child->nodetype == FORMAT) ||
       (child->nodetype == SCON) )
    x = pt1(BOXASSIGN, child);/* no need */
  else if (child->nodetype == COLLECT)
    x = pt1(BOXASSIGN, pt1(FORMAT,child));
  else
    x = pt1(BOXASSIGN, pt1(FORMAT,pt1(COLLECT,child)));/* normal */
#endif
#if 0
  /* old default, lasy evaluation printing */
  x = pt1(BOXASSIGN, child);
#endif
  return (x);
}

/* old default, lasy evaluation printing */
struct node *
ptboxlzass(struct node * child)
{
  struct node *x;

  x = pt1(BOXASSIGN, child);
  return (x);
}

/* pttop - top of expression 

   note that this controls the addition of a BOXASSIGN (printing of
   results)

*/
struct node *
pttop(struct node * child)
{
  struct node *x;
  int type;

  type = child->nodetype;
  /* if not assignment, print out expression */
  if (type == ASSIGN || type == BOXASSIGN || 
      type == DBOXAS || type == QBOXAS || type == DQBOXAS ||
      type == SUBASSIGN)
    x = child;
  else if (type == ASYSVAR && child->right != NILP)
    x = child;
  else if (type == CATCH)
    x = child;
  else
    x = ptboxass(child);
  /*x = pt1(BOXASSIGN, child);*/
  return (x);
}

/* ptsemi - semicolon */
struct node *
ptsemi(struct node * child1, struct node * child2)
{
  struct node *x;

  x = pt2(SM, child1, child2);
  if (child1 == NILP)
    x->ptr1 = 0;
  else
    x->ptr1 = child1->ptr1 + 1;
  return (x);
}


/* sws
   pttcav - scalar component of atomic vector
   based on pt1o - 1 child node with operator */
struct node *
pttcav(int type, enum sysvars var)
{
  struct node *x;

  x = newnode(type);
  x->optype = var;
  x->type.n = (int) APLC_CHAR;
  x->rank.n = 0;
  x->shape.n = 1;
  x->size.n = 1;
  switch(var) {
  default:
    yyerror("[pttcav] parse error");
    break;
  case TCBEL: 
    x->values.n = 7;
    break;
  case TCBS:  
    x->values.n = 8;
    break;
  case TCCR:  
    x->values.n = 13;
    break;
  case TCDEL: 
    x->values.n = 127;
    break;
  case TCESC: 
    x->values.n = 27;
    break;
  case TCFF:  
    x->values.n = 12;
    break;
  case TCHT:  
    x->values.n = 9;
    break;
  case TCLF:  
    x->values.n = 10;
    break;
  case TCNUL: 
    x->values.n = 0;
    break;
  }
  /* don't set valuesknown or adjdcls will barf */
  x->info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN | SHAPEKNOWN );
  return (x);
}


/* end of ptree.c */
