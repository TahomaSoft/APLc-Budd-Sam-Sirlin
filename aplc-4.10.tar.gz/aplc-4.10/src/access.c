/*
	apl compiler
		access format inferencer
		timothy a. budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/
/*
	This pass is in charge of setting two bits appropriately in the
	info field for each node - these bits are as follows

	SEQUENTIAL - access will be in ravel order, once through the entire
		structure

	HAVEVALUE - at the end of the shape phase the value field will have
		the pointer to all of memory for the node

	NOINDEX - set if the expression in the node does not need an index
		register (i.e., it is a scalar and always the same value,
		or access is sequential and it maintains its own counter).

	MERGED - set if the function of the node can be merged with its
		parent node to form a single accessor.

(sws)
        ASSIGNP - previous node is assign, and types match,
                  so a given trs may be used directly 

                  - only saves effort with certain nodes

        EARLYBIND - early binding needed for assign, 
                    finish in shape phase

   lookout for cases like 
      a + a .is ...
   where we need to bind the assign early, and hence need to collect 
   a at once
   versus
      x + a .is ...
      a .is a + ...
   where we don't, and can 

*/

#include <stdio.h>

#include "parse.h"
#include "y_tab.h"
#include "nutil.h"

/* for more prints */
#define ADEBUG 0

/* external declarations */

/* sws  do we need singleton here ? */
#define is_scalar(node) ((node->info & RANKKNOWN) && (node->rank.n == 0))
#define is_vector(node) ((node->info & RANKKNOWN) && (node->rank.n == 1))
#define is_icon(node) ((node->nodetype == BCON) || (node->nodetype == ICON))


/* local declarations */
static void setaxis(struct node * node);
static struct node *addcollect(struct node * node);
static int doaccess(struct node * node, int top);

struct idnode {    /* id list node */
  char *name;
  struct idnode *next;
};
struct idnode *id_list;

/*static void prt_id_list(void);*/
static void prt_idnode(struct idnode *node);
static void add_idnode(struct node *node);
static int match_idnode(char *name);
static void free_idnode(struct idnode *node);

static void init_id_list(void);
static void reinit_id_list(void);


/* ------------------------------------------------ */

/* passinit - initialize this pass (do nothing) */
void
passinit(int verbose)
{
  /* sws */
  if (verbose)
    fprintf(stderr, "Starting access\n");
}

/* glbvar - process a global variable name */
void
glbvar(char *name)
{
  ;
}

/* ----------------------------------------- */
/*
   lookout for cases like 
      a + a .is ...
   where we need to bind the assign early, and hence need to collect 
   a at once
   versus
      x + a .is ...
      a .is a + ...
   where we don't, and can 

proceed down a statement
- save ident names not used in assignments
- at assign, check assign ident against current ident list
- if a match then need early binding
*/
/* ----------------------------------------- */


#if 0
static void
prt_id_list(void)
{
  fprintf(stderr,"[access] current list:\n");
  prt_idnode(id_list);
  fprintf(stderr,". \n");
}
#endif

static void
prt_idnode(struct idnode *node)
{
  if ( node != NULL ) {
    if ( node->name != NULL ) {
      /*
      fprintf(stderr,"name %s\n", node->name); 
      fprintf(stderr,"next [%d]\n", (int) node->next); 
      */
      fprintf(stderr,"(%s, [%d])\n", node->name, (int) node->next); 
    }
    prt_idnode(node->next);
  }
}

static void
add_idnode(struct node *node)
{
  struct idnode *new;
  int n; 

#if ADEBUG
  fprintf(stderr,"[access] adding %s\n", node->a.namep);
#endif
  new = structalloc(idnode);
  n = strlen(node->a.namep);
  /* if size_t is not defined will need simpler call */
  /* new->name = (char *) malloc( n);*/
  /* new->name = (char *) malloc( (size_t) n);*/
  new->name = (char *) malloc( (unsigned) n+1);
  strcpy(new->name, node->a.namep);
  new->next = id_list;
  id_list = new;

#if ADEBUG
  /* prt_id_list();*/
#endif
}

/* search list for a name
   return 1 if found */
static int
match_idnode(char *name)
{
  struct idnode *p;

#if ADEBUG
  fprintf(stderr,"[access] match; looking for %s\n", name);
  prt_id_list();
#endif
  for (p=id_list; p != NULL; p = p->next) {
#if ADEBUG
    fprintf(stderr,"[access] at %s\n", p->name);
#endif
    if (strcmp(p->name, name) == 0) {
#if ADEBUG
      fprintf(stderr,"[access] (found match)\n");
#endif
      return 1;
    }
#if ADEBUG
    fprintf(stderr,"[access] not a match [%d]\n", (int) p->next);
#endif
  }

#if ADEBUG
  fprintf(stderr,"[access] no match found\n");
#endif
  return 0;
}

static void
free_idnode(struct idnode *node)
{
#if ADEBUG
  /*  fprintf(stderr,"[access] free\n");*/
#endif
  if ( node != NULL ) {
    /*fprintf(stderr,"[access] deeper [%d]\n", (int) node);*/
    if ( node->next != NULL ) {
      free_idnode(node->next);
      free(node->next);      
    }
    if ( node->name != NULL )
      free(node->name);      
  }
}

static void
init_id_list(void)
{
  /* free_idnode(id_list);*/
  id_list = NULL;
}

static void
reinit_id_list(void)
{
  free_idnode(id_list);
  free(id_list); 
  id_list = NULL;
}

/* doprog - process function */
void
doprog(struct headnode * head, struct symnode * syms,
    struct statenode * code)
{
  struct statenode *p;

  /* sws ...debugging 
     fprintf(stderr,"access before\n"); 
     prstatenode(code);
     fprintf(stderr,"access after\n"); */
  /* idlist_init();*/

  init_id_list();
  stmtno = 0;
  for (p = code; p != NILSTATE; p = p->nextstate) {
#if ADEBUG
    fprintf(stderr,"[access] [%d]\n", 1+stmtno);
#endif
    stmtno++;
    doaccess(p->code, 1);
#if ADEBUG
    /* prt_id_list();*/
#endif
    reinit_id_list();
  }
  /* sws prstatenode(code); */

}

/* 
   setaxis - set sequential mode in axis 
   and doaccess on axis if possible
   */
static void
setaxis(struct node * node)
{
  if ((node->info & FIRSTAXIS) || (node->info & LASTAXIS))
    ;	/* nothing to do */
  else {
    (node->a.axis)->info |= SEQUENTIAL;
    doaccess(node->a.axis, 0);
  }
}

/*
 addcollect - add a collect node into the tree to avoid
 repeated calls on a costly operation
*/
static struct node *
addcollect(struct node * node)
{
  struct node *x;

  /* fprintf(stderr,"adding a collect over %d\n", node->nodetype); */

  x = structalloc(node);
  if (x == (struct node *) 0)
    error("out of space");
  x->nodetype = COLLECT;
  x->info = 0;
  x->left = x->a.axis = NILP;
  x->right = node;
  x->optype = APLC_NOT;
  x->index = 0;
  /* sws  add information if available */
  if (node->info & TYPEKNOWN) {
    x->type.n = node->type.n;
    x->info |= TYPEKNOWN;
  }
  if (node->info & RANKKNOWN) {
    x->info |= RANKKNOWN;
    x->rank.n = node->rank.n;
  }
  if (node->info & SHAPEKNOWN) {
    x->info |= SHAPEKNOWN;
    x->shape.n = node->shape.n;
  }
  return (x);
}

/* sws
   indication that this is a complex node - it must have its own loop
*/
#define CMPLEX 5

/*
 doaccess - propigate accessing information 
*/
static int
doaccess(struct node * node, int top)
{
  int lcomp, rcomp, cmplx;

  cmplx = 0;

  switch (node->nodetype) {

  default:
    /* caserr("doaccess",node->nodetype); */
    fprintf(stderr, "[doaccess] unknown node ");
    exit(1);
    break;

  case ASSIGN:
    /* sws check for ident used above */
    if (match_idnode(LEFT->a.namep))
      node->info |= EARLYBIND;
    /* set ASSIGNP bit - watch out for possible type missmatch */
    if (!(node->info & TYPEKNOWN))
      /* will take type from right, so must match */
      RIGHT->info |= ASSIGNP;
    else {
      /* type is known, must then match right */
      if ( (RIGHT->info & TYPEKNOWN) && 
	   (node->type.n == RIGHT->type.n) ) 
	RIGHT->info |= ASSIGNP;
    }
    if (top)
      node->info |= SEQUENTIAL;
    if (node->info & SEQUENTIAL)
      RIGHT->info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    if (!(node->info & SEQUENTIAL))
      node->info |= HAVEVALUE;
    cmplx = 0;
    break;

  case AVEC:
  case TCAV:
    cmplx = 0;
    break;

  case BCON:
  case ICON:
  case RCON:
  case SCON:
    if (is_scalar(node) && is_icon(node))
      ;
    else
      node->info |= HAVEVALUE;
    if (is_scalar(node))
      node->info |= NOINDEX;
    if (node->info & SEQUENTIAL)
      node->info |= NOINDEX;
    cmplx = 0;
    break;

  case ZCON:
  case QCON:
  case OCON:
    node->info |= HAVEVALUE;
    cmplx = 0;
    break;

  case LCON:
    node->info |= HAVEVALUE;
    node->info |= NOINDEX;
    cmplx = 0;
    break;

  case IDENT:
    node->info |= HAVEVALUE;
    if (is_scalar(node))
      node->info |= NOINDEX;
    /* sws  exclude APLC_ANY/ANYRANK case from NOINDEX 
       - also complex types
     */
    if ((node->info & TYPEKNOWN) &&
	(node->type.n != APLC_ANY) &&
	(node->type.n != APLC_COMPLEX) &&
	(node->type.n != APLC_QUAT) &&
	(node->type.n != APLC_OCT) &&
	(node->info & RANKKNOWN) &&
	(node->rank.n != ANYRANK) &&
	(node->info & SEQUENTIAL))
      node->info |= NOINDEX;
    cmplx = 0;
    /* add name to list */
    add_idnode(node);
    break;

  case BOX:
  case QQUAD:
  case DBOX:
  case DQQUAD:
    if (RIGHT != NILP) {
      RIGHT->info |= SEQUENTIAL;
      rcomp = doaccess(RIGHT, 0);
    }
    node->info |= HAVEVALUE;
    cmplx = 0;
    break;

  case QBOXAS:
    if (!(RIGHT->info & HAVEVALUE)) {
      node->right = addcollect(RIGHT);
    }
    break;

  case BOXASSIGN:
    if (top) {
      RIGHT->info |= SEQUENTIAL;
    } 
    cmplx = doaccess(RIGHT, 0);
    if (!top){
      /* want to pass on the right to the left;
	 make sure we don't do calculations twice */
      if (!(RIGHT->info & HAVEVALUE)) {
	node->right = addcollect(RIGHT);
      }
      node->info = RIGHT->info;
    }
    break;

  case DBOXAS:
  case DQBOXAS:
    RIGHT->info |= SEQUENTIAL;
    if (LEFT != NILP) {		     /* file name */
      LEFT->info |= SEQUENTIAL;
      lcomp = doaccess(LEFT, 0);
    }
    rcomp = doaccess(RIGHT, 0);
    node->info |= HAVEVALUE;	     /* sws */
    if (RIGHT->info & NOINDEX)
      node->info |= NOINDEX;
    cmplx = 0;
    break;

  case CAT:
/* sws
   not always a good idea, given possible replication
*/
/*
	if (node->info & SEQUENTIAL) {
	    LEFT->info  |= SEQUENTIAL;
	    RIGHT->info |= SEQUENTIAL;
	}
*/
    /* if (axisgiven(AXIS)) { if ((! icons(AXIS)) && AXIS->nodetype != RCON)
       { AXIS->info |= SEQUENTIAL; ...doaccess(AXIS, 0); } } */
    lcomp = doaccess(LEFT, 0);
    setaxis(node);
    rcomp = doaccess(RIGHT, 0);
    cmplx = lcomp + rcomp;
    break;

  case CATCH:
    /* treat both left and right as top */
    lcomp = doaccess(LEFT, 1);
    rcomp = doaccess(RIGHT, 1);
    cmplx = 0;
    break;

  case CISCALAR:
  case CIVEC:
  case COLLECT:
  case CSCALAR:
  case CVEC:
  case CCOLLECT:
    /*- sws
      if RIGHT is an assignment, don't set it to sequential
      so it will set HAVEVALUE  and collect
    */
    if (!(RIGHT->nodetype == ASSIGN))
      RIGHT->info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    node->info |= HAVEVALUE; /* sws */
    cmplx = 0;
#if 0
    /* old way */
    if (node->nodetype == CCOLLECT) {
      /* sws  special collect that always copies */
      RIGHT->info &= ~HAVEVALUE;
      /* this nodetype is not used after this stage */
      node->nodetype = COLLECT;
    }
#endif
    break;


  case COMMENT:
    cmplx = 0;
    break;

  case COMPRESS:
    LEFT->info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);
    setaxis(node);
    rcomp = doaccess(RIGHT, 0);
    cmplx = rcomp;
    break;

  case DEAL:
    LEFT->info |= SEQUENTIAL;
    RIGHT->info |= SEQUENTIAL;
    node->info |= HAVEVALUE;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case DECODE:
  case INNERCHILD:
    lcomp = doaccess(LEFT, 0);
    if (lcomp > 0) {
      node->left = addcollect(LEFT);
      lcomp = doaccess(LEFT, 0);
    }
    rcomp = doaccess(RIGHT, 0);
    if (rcomp > 0) {
      node->right = addcollect(RIGHT);
      rcomp = doaccess(RIGHT, 0);
    }
    cmplx = CMPLEX;
    break;

  case DFORMAT:
    LEFT->info |= SEQUENTIAL;
    RIGHT->info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    node->info |= HAVEVALUE;
    cmplx = 0;
    break;

    /* sws  based on inner */
  case DOMINO:
    rcomp = doaccess(RIGHT, 0);
    if (is_scalar(node))
      node->info |= NOINDEX;
    node->info |= HAVEVALUE;
    cmplx = 0;
    break;

  case DSOP:
    if (node->info & SEQUENTIAL) {
      RIGHT->info |= SEQUENTIAL;
      LEFT->info |= SEQUENTIAL;
    }
    lcomp = doaccess(LEFT, 0);
    if (lcomp > 0) {
      node->left = addcollect(LEFT);
      lcomp = doaccess(LEFT, 0);
    }
    rcomp = doaccess(RIGHT, 0);
    if (rcomp > 0) {
      node->right = addcollect(RIGHT);
      rcomp = doaccess(RIGHT, 0);
    }
    /*
	if ((RIGHT->info & NOINDEX) && (LEFT->info & NOINDEX))
	    node->info |= NOINDEX;
	    */
    cmplx = lcomp + rcomp;
    break;

  case DSYSFUN:
  case ESYSFUN:
  case MSYSFUN:
    if (LEFT != NILP)
      lcomp = doaccess(LEFT, 0);
    if (RIGHT != NILP)
      rcomp = doaccess(RIGHT, 0);
#if 0
    if (node->nodetype == MSYSFUN)
      rcomp = doaccess(RIGHT, 0);
    else {
      lcomp = doaccess(LEFT, 0);
      rcomp = doaccess(RIGHT, 0);
    }
#endif
    node->info |= HAVEVALUE;
    cmplx = 0;
    break;

  case DTRANS:
    if (is_mergeable(RIGHT))
      RIGHT->info |= MERGED;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    if (RIGHT->info & NOINDEX)
      node->info |= NOINDEX;
    cmplx = rcomp;
    break;

  case EMPTSEMI:
    cmplx = 0;
    break;

  case ENCODE:
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    /* sws */
    /* cmplx = lcomp + rcomp; */
    /* since stuff is calculated in the value phase */
    node->info |= HAVEVALUE;
    cmplx = 0;
    break;

  case EXPAND:
    if (node->info & SEQUENTIAL)
      RIGHT->info |= SEQUENTIAL;
    LEFT->info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);
    setaxis(node);
    rcomp = doaccess(RIGHT, 0);
    cmplx = rcomp;
    break;

  case EPSILON:
    if (node->info & SEQUENTIAL)
      LEFT->info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    cmplx = lcomp;
    break;

  case EXECUTE:
    rcomp = doaccess(RIGHT, 0);
    cmplx = rcomp;
    break;

  case FIDENT:
    node->info |= HAVEVALUE;
    if (LEFT != NILP)
      lcomp = doaccess(LEFT, 0);
    if (RIGHT != NILP)
      rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case FORMAT:
    RIGHT->info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    node->info |= HAVEVALUE;
    cmplx = 0;
    break;

  case GO:
    RIGHT->info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case INDEX:
    if (node->info & SEQUENTIAL)
      RIGHT->info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    cmplx = rcomp;
    break;

  case INNER:
    rcomp = doaccess(RIGHT, 0);
    if (is_scalar(node))
      node->info |= NOINDEX;
    cmplx = rcomp;
    break;

  case IOTA:
    rcomp = doaccess(RIGHT, 0);
    if (node->info & SEQUENTIAL)
      node->info |= NOINDEX;
    cmplx = 0;
    break;

  case LAM:
    error("laminate not implemented");
    cmplx = 0;
    break;


  case MSOLVE:
    rcomp = doaccess(RIGHT, 0);
    lcomp = doaccess(LEFT, 0);
    if (is_scalar(node))
      node->info |= NOINDEX;
    node->info |= HAVEVALUE;
    cmplx = 0;
    break;

  case MSOP:
    if (node->info & SEQUENTIAL)
      RIGHT->info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    if (RIGHT->info & NOINDEX)
      node->info |= NOINDEX;
    cmplx = rcomp;
    break;

  case OUTER:
    if (node->info & SEQUENTIAL)
      LEFT->info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    if (rcomp > 0) {
      node->right = addcollect(RIGHT);
      rcomp = doaccess(RIGHT, 0);
    }
    lcomp = doaccess(LEFT, 0);
    if (!(node->info & SEQUENTIAL))
      if (lcomp > 0) {
	node->left = addcollect(LEFT);
	lcomp = doaccess(LEFT, 0);
      }
    cmplx = rcomp + lcomp;
    break;

  case RAVEL:
    if (node->info & SEQUENTIAL)
      RIGHT->info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    if (RIGHT->info & HAVEVALUE)
      node->info |= HAVEVALUE;
    if (RIGHT->info & NOINDEX)
      node->info |= NOINDEX;
    cmplx = rcomp;
    break;

  case REDUCE:
    setaxis(node);
    if ((node->info & SEQUENTIAL) &&
	(node->info & LASTAXIS) &&
	(commute(node->optype)))
      RIGHT->info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    if (is_vector(RIGHT) && commute(node->optype))
      node->info |= NOINDEX;
    /* sws still need a loop... */
    /*	if (RIGHT->info & SEQUENTIAL)
	    cmplx = 0; */
    else {
      if (rcomp > 0) {
	node->right = addcollect(RIGHT);
	rcomp = doaccess(RIGHT, 0);
      }
      /* sws cmplx = CMPLEX; */
    }
    cmplx = CMPLEX;
    break;

  case REVERSE:
    setaxis(node);
    if (is_mergeable(RIGHT))
      RIGHT->info |= MERGED;
    rcomp = doaccess(RIGHT, 0);
    if (RIGHT->info & NOINDEX)
      node->info |= NOINDEX;
    cmplx = rcomp;
    break;

  case RESHAPE:
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    cmplx = rcomp;
    break;

  case RHO:
    node->info |= HAVEVALUE;
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case RHORHO:
    /* node->info |= HAVEVALUE;*/
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case ROLL:
    if (node->info & SEQUENTIAL)
      RIGHT->info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case ROTATE:
    lcomp = doaccess(LEFT, 0);
    setaxis(node);
    rcomp = doaccess(RIGHT, 0);
    cmplx = lcomp + rcomp;
    break;

  case SCAN:
    setaxis(node);
    if ((node->info & SEQUENTIAL) &&
	(node->info & LASTAXIS) &&
	commute(node->optype))
      RIGHT->info |= SEQUENTIAL;
    rcomp = doaccess(RIGHT, 0);

    if (RIGHT->info & SEQUENTIAL) {
      /* sws cmplx = 0; */
      if (RIGHT->info & NOINDEX)
	node->info |= NOINDEX;
    } else {
      if (rcomp > 0) {
	node->right = addcollect(RIGHT);
	rcomp = doaccess(RIGHT, 0);
      }
      /* cmplx = CMPLEX; */
    }
    cmplx = CMPLEX;
    break;

  case SM:
    if ((node->info & SEQUENTIAL) && (LEFT == NILP))
      RIGHT->info |= SEQUENTIAL;
    if (LEFT != NILP)
      lcomp = doaccess(LEFT, 0);
    else
      lcomp = 0;
    /* tell axis it's top to force it to collect? */
    if (AXIS != NILP)
      lcomp = doaccess(AXIS, 1);
    rcomp = doaccess(RIGHT, 0);
    if (LEFT == NILP) {
      if (RIGHT->info & NOINDEX)
	node->info |= NOINDEX;
    } else if ((LEFT->info & NOINDEX) && (RIGHT->info & NOINDEX))
      node->info |= NOINDEX;
    cmplx = lcomp + rcomp;
    break;

  case SORT:
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case SUB:
    if (node->info & SEQUENTIAL)
      RIGHT->info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 1);
    cmplx = lcomp + rcomp;
    break;

  case SUBASSIGN:
#if 0
    /* subassign can also use the right */ 
    if ( ! ( (LEFT->info & TYPEKNOWN) && (RIGHT->info & TYPEKNOWN) 
	 && (LEFT->type.n == RIGHT->type.n) ) ) {
      if (RIGHT->nodetype == FIDENT) 
	RIGHT->info |= ASSIGNP; 
    }
#endif
    RIGHT->info |= SEQUENTIAL;
    lcomp = doaccess(LEFT, 0);/* just an ident */
    /* sws why top ??? */
    /* tell axis it's top to force it to collect? */
    lcomp = doaccess(AXIS, 1);
    rcomp = doaccess(RIGHT, 0);
    cmplx = 0;
    break;

  case ASYSVAR:
  case SYSVAR:
    if (LEFT != NILP)
      doaccess(LEFT, 0);
    if (RIGHT != NILP)
      doaccess(RIGHT, 0);
    node->info |= HAVEVALUE;
    cmplx = 0;
    break;

    /* non mergeable (standard) versions of take/drop */ 
  case TAKE:
  case DROP:
    node->info |= HAVEVALUE;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    cmplx = rcomp;
    break;

    /* mergeable versions of take/drop */ 
  case GWTAKE:
  case GWDROP:
    if (is_mergeable(RIGHT))
      RIGHT->info |= MERGED;
    lcomp = doaccess(LEFT, 0);
    rcomp = doaccess(RIGHT, 0);
    if (RIGHT->info & NOINDEX)
      node->info |= NOINDEX;
    cmplx = rcomp;
    break;

  case TRANS:
    if (is_mergeable(RIGHT))
      RIGHT->info |= MERGED;
    rcomp = doaccess(RIGHT, 0);
    if (RIGHT->info & NOINDEX)
      node->info |= NOINDEX;
    cmplx = rcomp;
    break;
  }
  return (cmplx);
}

/* end of access.c */
