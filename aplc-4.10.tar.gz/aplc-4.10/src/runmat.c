/*
	APL Compiler

        sam sirlin

	Run time system
	routines having to do with matrices
        calls linpack routines for now...

        take, drop added


This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.

*/

#include <stdio.h>
#include <math.h>
#include "aplc.h"

/* local function declarations */
static int imax(int i, int j);
static void prtmat(union mp_struct a, int m, int n);


/* maximum of 2 integer arguments */
static int
imax(int i, int j)
{
  return ((i > j) ? i : j);
}

/* 
   printout matrix in mp_struct, for debugging 
   print out a as an mxn matrix
*/
static void
prtmat(union mp_struct a, int m, int n)
{
  union mp_struct temp;
  int i, j;

  temp = a;
  for (i = 0; i < m; i++) {
    for (j = 0; j < n; j++) {
      /* printf("%f ", *temp.rp++);*/
      printf("%10.5g ", *temp.rp++);
    }
    printf("\n");
  }
}

/* matrix inverse */
extern void
aplc_domino(struct trs_struct * res, struct trs_struct * right)
{
  union mp_struct a;
  union mp_struct at;
  union mp_struct b;
  union mp_struct c;
  union mp_struct mptemp;
  int type;
  int rrank;
  int *shape;

  int rank, info, nrhs;
  double *work;
  int *jpvt;
  int i, j, m, n, mn, nw;
  double rcond;
  int lda, ldb;
  int size, lsize;

  type = right->type;
  rrank = right->rank;
  shape = right->shape;

  if (rrank == 2) {
    m = shape[0];
    n = shape[1];
  } else if (rrank == 1) {
    m = shape[0];
    n = 1;
  } else {
    m = 1;
    n = 1;
  }

  /* don't force exit for this error, just notify the user */
  if (m < n)
    aplc_error("length aplc_error [domino - non unique solution]");

  lda = m;
  ldb = (m < n) ? n : m;
  nrhs = m;
  size = m * n;
  rcond = EPS;

  /* setup workspace */
  mn = (m < n) ? m : n;
  nw = imax(mn + 3 * n, 2 * mn + nrhs);
  aplc_vectalloc(&mptemp, nw, APLC_REAL);
  work = mptemp.rp;

  aplc_vectalloc(&mptemp, n, APLC_INT);
  jpvt = mptemp.ip;
  for (i = 0; i < n; ++i) {
    jpvt[i] = 0;
  }

  /* printf("\n mn %d, nw %d\n", mn, nw); */

  /* put stuff in transpose of a  */
  aplc_vectalloc(&a, size, APLC_REAL);
  c = right->value;
  at = a;
  switch (type) {
  default:
    aplc_error("domain aplc_error [domino - int or real expected]");
    aplc_zilde(res);
    return;
    break;
  case APLC_BOOL:
  case APLC_INT:
    for (i = 0, j = 0; i < size; i++, j += n) {
      if (j >= size)
	j %= size - 1;
      *at.rp++ = (double) c.ip[j];
    }
    break;

  case APLC_REAL:
    for (i = 0, j = 0; i < size; i++, j += n) {
      if (j >= size)
	j %= size - 1;
      *at.rp++ = c.rp[j];
    }
    break;
  }

  /* put identity in b  */
  lsize = ldb * nrhs;
  aplc_vectalloc(&b, lsize, APLC_REAL);
  c = b;
  j = nrhs + 1;
  for (i = 0; i < lsize; i++) {
    if (0 == i % j)
      *c.rp++ = 1.0;
    else
      *c.rp++ = 0.0;
  }

/* sws  debugging printout
    printf("\n a\n");
    prtmat(a,n,m);
    printf("\n b\n");
    prtmat(b,nrhs,ldb);
    printf("\n m %d, n %d, nrhs %d, lda %d, ldb %d, rcond %g\n",
           m,n,nrhs,lda,ldb, rcond);
*/

  /* solve */
  dgelsx_(&m, &n, &nrhs, a.rp, &lda, b.rp, &ldb, jpvt, &rcond,
      &rank, work, &info);
  if (rank != n) {
    /* don't force exit for this error, just notify the user */
    fprintf(aplcerr, "\ndgelsx info = %d, rank= %d\n", info, rank);
    aplc_error("domain aplc_error [domino - matrix not of full right rank]");
  }
/*
  printf("\n bn\n");
  prtmat(b, n, m);
*/

  res->type = APLC_REAL;
  res->rank = 2;
  aplc_vectalloc(&mptemp, 2, APLC_INT);
  res->shape = mptemp.ip;
  res->shape[0] = n;
  res->shape[1] = nrhs;
  lsize = n * nrhs;

  /* put transpose of (new) b in result */
  aplc_vectalloc(&mptemp, lsize, APLC_REAL);
  c = mptemp;
  for (i = 0; i < n; i++) {
    for (j = 0; j < nrhs; j++) {
      *c.rp++ = (b.rp)[i + ldb * j];
    }
  }
  res->value = mptemp;
}

/* solution to linear equations */
extern void
aplc_msolve(struct trs_struct * res,
    struct trs_struct * left, struct trs_struct * right)
{
  union mp_struct a, at;
  union mp_struct b, bt;
  union mp_struct c;
  union mp_struct mptemp;
  int ltype, lrank;
  int *lshape;
  int rtype, rrank;
  int *rshape;

  int rank, info, nrhs;
  double *work;
  int *jpvt;
  int i, j, m, n, mn, nw;
  double rcond;
  int lda, ldb;
  int size, lsize;

  rtype = right->type;
  rrank = right->rank;
  rshape = right->shape;
  ltype = left->type;
  lrank = left->rank;
  lshape = left->shape;

  if (rrank == 2) {
    m = rshape[0];
    n = rshape[1];
  } else if (rrank == 1) {
    m = rshape[0];
    n = 1;
  } else {
    m = 1;
    n = 1;
  }

  /* don't force exit for this error, just notify the user */
  if (m < n)
    aplc_error("length aplc_error [msolve - non unique solution]");

  if (lrank == 2) {
    ldb = lshape[0];
    nrhs = lshape[1];
  } else if (rrank == 1) {
    ldb = lshape[0];
    nrhs = 1;
  } else {
    ldb = 1;
    nrhs = 1;
  }
  if (m != ldb) {
    aplc_error("length aplc_error [msolve - dimensions don't match]");
    aplc_zilde(res);
    return;
  }
  lda = m;
  size = m * n;
  rcond = EPS;

  /* setup workspace */
  mn = (m < n) ? m : n;
  nw = imax(mn + 3 * n, 2 * mn + nrhs);
  aplc_vectalloc(&mptemp, nw, APLC_REAL);
  work = mptemp.rp;

  aplc_vectalloc(&mptemp, n, APLC_INT);
  jpvt = mptemp.ip;
  for (i = 0; i < n; ++i) {
    jpvt[i] = 0;
  }

  /* printf("\n mn %d, nw %d\n", mn, nw); */

  /* put right stuff in transpose of a  */
  aplc_vectalloc(&a, size, APLC_REAL);
  c = right->value;
  at = a;
  switch (rtype) {
  default:
    aplc_error("domain aplc_error [msolve - int or real expected on right]");
    aplc_zilde(res);
    return;
    break;
  case APLC_BOOL:
  case APLC_INT:
    for (i = 0, j = 0; i < size; i++, j += n) {
      if (j >= size)
	j %= size - 1;
      *at.rp++ = (double) c.ip[j];
    }
    break;
  case APLC_REAL:
    for (i = 0, j = 0; i < size; i++, j += n) {
      if (j >= size)
	j %= size - 1;
      *at.rp++ = c.rp[j];
    }
    break;
  }

  /* put transpose of left stuff in b  */
  lsize = ldb * nrhs;
  aplc_vectalloc(&b, lsize, APLC_REAL);
  c = left->value;
  bt = b;
  switch (ltype) {
  default:
    aplc_error("domain aplc_error [msolve - int or real expected on left]");
    aplc_zilde(res);
    return;
    break;
  case APLC_BOOL:
  case APLC_INT:
    for (i = 0; i < lshape[0]; i++) {
      for (j = 0; j < lshape[1]; j++) {
	(b.rp)[i + lshape[0] * j] = (double) *c.ip++;
      }
    }
    break;
  case APLC_REAL:
    for (i = 0; i < lshape[0]; i++) {
      for (j = 0; j < lshape[1]; j++) {
	(b.rp)[i + lshape[0] * j] = *c.rp++;
      }
    }
    break;
  }

/* sws  debugging printout
    printf("\n a\n");
    prtmat(a,n,m);
    printf("\n b\n");
    prtmat(b,nrhs,ldb);
    printf("\n m %d, n %d, nrhs %d, lda %d, ldb %d, rcond %g\n",
           m,n,nrhs,lda,ldb, rcond);
*/

  /* solve */
  dgelsx_(&m, &n, &nrhs, a.rp, &lda, b.rp, &ldb, jpvt, &rcond,
      &rank, work, &info);

  if (rank != n) {
    fprintf(aplcerr,"\ndgelsx info = %d, rank= %d\n", info, rank);
    aplc_error("domain aplc_error [domino - matrix not of full right rank]");
  }
/*
  printf("\n bn\n");
  prtmat(b, nrhs, ldb);
*/

  /* setup return value */
  res->type = APLC_REAL;
  res->rank = 2;
  aplc_vectalloc(&mptemp, 2, APLC_INT);
  res->shape = mptemp.ip;
  res->shape[0] = n;
  res->shape[1] = nrhs;
  lsize = n * nrhs;

  /* put transpose of (new) b in result */
  aplc_vectalloc(&mptemp, lsize, APLC_REAL);
  c = mptemp;
  for (i = 0; i < n; i++) {
    for (j = 0; j < nrhs; j++) {
      *c.rp++ = (b.rp)[i + ldb * j];
    }
  }
  res->value = mptemp;
}


/* general drop fn

   res .is left drop right

 */
extern void
aplc_drop(struct trs_struct * res,
    struct trs_struct * left, struct trs_struct * right)
{
  int ltype, lrank;
  int *lshape;
  int rtype, rrank;
  int *rshape;
  union mp_struct mptemp;
  union mp_struct s, delta;
  int i,j;
  int degen_flag;
  int size;
  int alpha;
  int temp;
  int index;

  rtype = right->type;
  rrank = right->rank;
  rshape = right->shape;
  ltype = left->type;
  lrank = left->rank;
  lshape = left->shape;

  /* first some error checking */
  if ( (ltype != APLC_INT) && (ltype != APLC_BOOL) ) {
    fprintf(aplcerr,"left type = %d\n", ltype);
    aplc_error("[drop] type error (left not int)");
  }

#if 0
  fprintf(aplcerr,"[drop] lrank %d, rrank %d\n",lrank,rrank);  
  aplc_fprintf_ivec(aplcerr, "lshape", lshape, lrank);
  aplc_fprintf_ivec(aplcerr, "rshape", rshape, rrank);
#endif
  /* scalar should appear as a vector */
  if (lrank != 1)
    aplc_error("[drop] rank error (left not vector)");

  if (0 == rrank) {
    /* scalar right */
    res->type = rtype;
    res->rank = left->shape[0];
    /* allocate space for shape vector */
    aplc_vectalloc(&mptemp, res->rank, APLC_INT);
    res->shape = mptemp.ip;
    /* shape components are 0 or 1 */
    degen_flag = 0;
    for (i=0; i<left->shape[0]; i++) {
      if (left->value.ip[i]) {
	res->shape[i] = 0;
	degen_flag = 1;
      } else {
	res->shape[i] = 1;
      }
    }
    if (degen_flag) {
      res->size = 0;
      res->value.ip = (void *)0;
    } else {
      res->size = aplc_talloc(res);
      aplc_cptrsval(res,0, right,0);/* set the value */
    }
    /*aplc_fprintf_ivec(aplcerr, "res->shape", res->shape, res->rank);*/
    return;
  }

  if (lshape[0] != rrank) {
    fprintf(aplcerr,"left shape[0] = %d, right rank = %d\n",
	    lshape[0],  rrank);
    aplc_error("[drop] shape error (left shape not right rank)");
  }

  /* setup result type, rank, shape */
  res->type = rtype;
  res->rank = rrank;
  /* allocate space for shape vector */
  aplc_vectalloc(&mptemp, rrank, APLC_INT);
  res->shape = mptemp.ip;
  /* copy in left values to shape
     - also see if result is of 0 size
     - also compute offset vector, s
   */
  /* offset vector */
  aplc_vectalloc(&s, rrank, APLC_INT);
  degen_flag = 0;
  for (i=0; i<lshape[0]; i++) {
    res->shape[i] = right->shape[i] - aplc_iabs(left->value.ip[i]);
    if (0 >= res->shape[i]) {
      /* degenerate case, size is 0 */
      degen_flag = 1;
      res->shape[i] = 0;
    }
    if (left->value.ip[i] > 0)
      s.ip[i] = left->value.ip[i];
    else
      s.ip[i] = 0;
  }
  if (degen_flag) {
    /* we're done, don't need offset */
    free(s.ip);
    res->size = 0;
    return;
  }

  /* ok, to get here we must have something left    */
  alpha = aplc_td_accessor(res->rank, res->shape, 
		      rrank, right->shape,
		      &delta, s.ip);
#if 0
  /* print delta */
  printf("delta = [");
  for (i=0; i<rank; i++)
    printf("%d ",delta.ip[i]);
  printf("]\n");
#endif
  /* allocate space for result */
  res->size = aplc_vsize(res->rank, res->shape);
  size = aplc_talloc(res);
  index = alpha;
  for (i = 0; i < size; i++) {
    aplc_cptrsval(res,i, right,index);/* set the value */
    temp = res->shape[rrank-1];
    for (j = rrank - 1; j >= 0; j--) {
      index += delta.ip[j];
      if ( (j>0) && (0 == ((i + 1) % temp) ) )
	temp *= res->shape[j-1];
      else
	break;
    }
  }
  /* free the offset vector, delta */
  free(s.ip);
  free(delta.ip);
  return;
}

#define TDBG 0

/* general take fn

   res .is left take right

 */
extern void
aplc_take(struct trs_struct * res,
    struct trs_struct * left, struct trs_struct * right)
{
  int ltype, lrank;
  int *lshape;
  int rtype, rrank;
  int *rshape;
  union mp_struct mptemp;
  union mp_struct s, delta;
  union mp_struct e, a, rse;
  int i,j;
  int degen_flag;
  int size;
  int alpha;
  int temp;
  int index;
  int lsize, rsize;
  union res_struct rfill; 
  int over_flag;
  int fill_flag;

  rtype = right->type;
  rrank = right->rank;
  rshape = right->shape;
  rsize = aplc_vsize(rrank, rshape);
  ltype = left->type;
  lrank = left->rank;
  lshape = left->shape;
  lsize = aplc_vsize(lrank, lshape);

#if TDBG
  printf("[take] left trs\n");
  aplc_print_trs(left);
  printf("[take] right trs\n");
  aplc_print_trs(right);
#endif
  /* first some error checking */
  /* left type must be an int */
  if ( (ltype != APLC_INT) && (ltype != APLC_BOOL) ) {
    fprintf(aplcerr,"left type = %d\n", ltype);
    aplc_error("[take] type error (left not int)");
  }
  /* left must be singleton or vector */ 
  if ( (lsize > 1) && (lrank != 1) )
    aplc_error("[take] rank error (left not vector)");

  /*  if (lshape[0] != rrank) {*/
  /* allow scalar right */ 
  if ( (0 < rrank) && (lshape[0] != rrank) ) {
    fprintf(aplcerr,"left shape[0] = %d, right rank = %d\n",
	    lshape[0],  rrank);
    aplc_error("[take] shape error (left shape not right rank)");
  }

  /* setup result type, rank, shape */
  res->type = rtype;
  if ( 0 < rrank )
    res->rank = rrank;
  else
    res->rank = lsize;
  /* allocate space for shape vector */
  aplc_vectalloc(&mptemp, res->rank, APLC_INT);
  res->shape = mptemp.ip;
  /* copy in left values to shape */
  /* copy in left values to shape
     - also see if result is of 0 size
     - also compute offset vector, s
     - also see if we need overtake 
   */
  /* offset vector */
  aplc_vectalloc(&s, res->rank, APLC_INT);
  degen_flag = 0;
  over_flag = 0;
  /* note left shape[0] is right rank, should be the same as lsize    */ 
  for (i=0; i<lsize; i++) {
    res->shape[i] = aplc_iabs(left->value.ip[i]);
    if (0 >= res->shape[i]) {
      degen_flag = 1;
      res->shape[i] = 0;
    }
    if (left->value.ip[i] < 0) {
      if (rrank > 0)
	s.ip[i] = right->shape[i] + left->value.ip[i];/* note this subtracts */
      else
	s.ip[i] = 1 + left->value.ip[i];/* note this subtracts */
    }
    else
      s.ip[i] = 0;
    if ( rrank == 0 ) {
      if ( aplc_iabs(left->value.ip[i]) > 1) 
	over_flag = 1;
    } else if ( right->shape[i] < aplc_iabs(left->value.ip[i]) )
      over_flag = 1;
  }
  if (degen_flag) {
    /* we're done */
#if TDBG
    printf("[take] res d trs\n");
    aplc_print_trs(res);
#endif
    return;
  }
  /* ok, to get here we must have something left 
   */
  alpha = aplc_td_accessor(res->rank, res->shape, 
		      rrank, right->shape,
		      &delta, s.ip);
  /* allocate space for result */
  res->size = aplc_vsize(res->rank, res->shape);
  size = aplc_talloc(res);

  if (0 == over_flag) {
    /* don't have to handle overtake */
    index = alpha;
    for (i = 0; i < size; i++) {
      /* set the value */
      aplc_cptrsval(res,i, right,index);
      temp = res->shape[res->rank-1];
      for (j = res->rank - 1; j >= 0; j--) {
	index += delta.ip[j];
	if ( (j>0) && (0 == ((i + 1) % temp) ) )
	  temp *= res->shape[j-1];
	else
	  break;
      }
    }
    /* free the offset vector, delta */
    free(s.ip);
    free(delta.ip);
#if TDBG
    printf("[take] res trs\n");
    aplc_print_trs(res);
#endif
    return;
  }

  /* ok, we need overtake

     s[i] is the offset for axis i, possibly negative

     use s as the index into right

   */

  /* build the exp vector for expanded right */
  aplc_vectalloc(&e, res->rank, APLC_INT);
  /* also build shape of expanded right */
  aplc_vectalloc(&rse, res->rank, APLC_INT);
  e.ip[res->rank-1] = 1;
  for (i = res->rank-1; i >0; i--) {
    /*e.ip[i-1] = right->shape[i]*e.ip[i];*/
    if (rrank > 0)
      rse.ip[i] = max( right->shape[i], aplc_iabs(left->value.ip[i]) );
    else
      rse.ip[i] = max( 1, aplc_iabs(left->value.ip[i]) );
    e.ip[i-1] = rse.ip[i]*e.ip[i];
  }
  if (rrank > 0)
    rse.ip[0] = max( right->shape[0], aplc_iabs(left->value.ip[0]) );
  else
    rse.ip[0] = max( 1, aplc_iabs(left->value.ip[0]) );

#if 0
  for (i=0; i< res->rank; i++) {
    printf("%d, %d\n", rse.ip[i], e.ip[i]);
  }
#endif

  /* storage for indicies into expanded right */
  aplc_vectalloc(&a, res->rank, APLC_INT);
  /* get the fill element */
  aplc_genfill(&rfill, rtype);
  index = alpha;
  for (i = 0; i < size; i++) {
    /* set the value
       - first determine indicies of expanded right
       - adjust with offset to right indicies
       - next fill if any are out of bounds
     */
    /* a[i] = (offset div e[i]) mod s[i] */
    fill_flag = 0;
    for (j = 0; j < res->rank; j++) {
      /* printf("i %d, j %d; %d, %d\n", i,j, e.ip[j], rse.ip[j]);*/
      a.ip[j] = (i/e.ip[j]) % rse.ip[j];
      /* adjust by offset */
      a.ip[j] = a.ip[j] + s.ip[j];
      if (rrank > 0) {
	if ( (a.ip[j] <0) || (a.ip[j] >= right->shape[j]) )
	  fill_flag = 1;
      } else {
	if ( (a.ip[j] <0) || (a.ip[j] >= 1) )
	  fill_flag = 1;
      }

    }
    /* now actually put the value or fill in */
    if ( fill_flag )
      aplc_cpres2trs(res,i, &rfill);
    else
      aplc_cptrsval(res,i, right,index);
    /* get next index */
    temp = res->shape[res->rank-1];
    for (j = res->rank - 1; j >= 0; j--) {
      index += delta.ip[j];
      if ( (j>0) && (0 == ((i + 1) % temp) ) )
	temp *= res->shape[j-1];
      else
	break;
    }
  }
  /* free the offset vector, delta */
  /* sometimes s.ip = a.ip; freed twice?? */
  free(e.ip);
  free(rse.ip);
  free(a.ip);
  free(s.ip);
  free(delta.ip);
#if TDBG
  printf("[take] res o trs\n");
  aplc_print_trs(res);
#endif
  return;
}

/* end of runmat.c */
