/*
	APL compiler
		resource declarations
		timothy a. budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/
/*
	This pass is in charge of allocating resources to the various
	nodes.

	The following are the resources considered:
   	   trs values - type, rank, shape structures
	   mp values - memory pointers
	   res values - results (memory values)
	   i values - integer registers, for index registers, counters, etc.
*/

#include <stdio.h>

#include "parse.h"
#include "y_tab.h"
#include "nutil.h"
#include "util2.h"

#define is_scalar(node) ((node->info & RANKKNOWN) && (node->rank.n == 0))
#define is_vector(node) ((node->info & RANKKNOWN) && (node->rank.n == 1))
#define lrinf(left, right) {doinf(left, 0); doinf(right, 0);}

#define typeisknown(node) ((node->info & TYPEKNOWN) && (APLC_ANY != node->type.n))
#define rkisknown(node) ((node->info & RANKKNOWN) && (ANYRANK != node->rank.n))

static int trscounter;		     /* counter for trs registers */
static int mpcounter;		     /* counter for mp registers */
static int rescounter;		     /* counter for res registers */
static int icounter;		     /* counter for index registers */
static int trsmax;		     /* max value for trs registers */
static int mpmax;		     /* max value for mp registers */
static int resmax;		     /* max value for res registers */
static int imax;		     /* max value for index registers */

/* declarations */
void passinit(int verbose);
void glbvar(char *name);
void doprog(struct headnode * head, struct symnode * syms,
	    struct statenode * code);
void doaxis(struct node * node);
static void mergeresource(struct node * node, struct node * child);
void doinf(struct node * node, int top);

/* externals */

extern void doinf(struct node * node, int top);


/* passinit - initialize this pass (do nothing) */
void
passinit(int verbose)
{
  /* sws */
  if (verbose)
    (void) fprintf(stderr, "Starting resource\n");
}

/* glbvar - process a global variable name */
void
glbvar(char *name)
{
  ;
}

/* doprog - process function */
void
doprog(struct headnode * head, struct symnode * syms,
    struct statenode * code)
{
  struct statenode *p;

  stmtno = 0;
  trsmax = mpmax = resmax = imax = 0;
  for (p = code; p != NILSTATE; p = p->nextstate) {
    stmtno++;
    /* sws why start at 1?! - because postinc is used */
    trscounter = mpcounter = rescounter = icounter = 1;
    /* trscounter = mpcounter = rescounter = icounter = 0;*/
    doinf(p->code, 1);
    if (trscounter > trsmax)
      trsmax = trscounter;
    if (mpcounter > mpmax)
      mpmax = mpcounter;
    if (rescounter > resmax)
      resmax = rescounter;
    if (icounter > imax)
      imax = icounter;
  }
  head->maxtrs = trsmax - 1;
  head->maxmp = mpmax - 1;
  head->maxres = resmax - 1;
  head->maxi = imax - 1;

  /* sws	fresyms(syms); frecode(code); */
}

/* doaxis - set sequential mode in axis */
void
doaxis(struct node * node)
{
  struct node *a;

  if ((node->info & FIRSTAXIS) || (node->info & LASTAXIS))
    ;
  else {
    a = node->a.axis;
    doinf(a, 0);
  }
}

/*
	mergeresource -
		process resources for mergable operators
*/
static void
mergeresource(struct node * node, struct node * child)
{
  if (!(node->info & MERGED)) {
    node->ptr1 = mpcounter++;
    node->ptr2 = mpcounter++;
    node->ptr3 = mpcounter++;
    node->ptr4 = icounter++;
    node->ptr5 = mpcounter++;
    node->ptr6 = icounter++;
    node->ptr7 = icounter++;
    node->ptr8 = icounter++;
    if (node->info & SEQUENTIAL)
      node->ptr10 = rescounter++;
  }
  if (is_mergeable(child)) {
    child->ptr1 = node->ptr1;
    child->ptr2 = node->ptr2;
    child->ptr3 = node->ptr3;
    child->ptr4 = node->ptr4;
    child->ptr5 = node->ptr5;
    child->ptr6 = node->ptr6;
    child->ptr7 = node->ptr7;
    child->ptr8 = node->ptr8;
    child->ptr10 = node->ptr10;
    child->index = node->index;
  } else
    child->index = icounter++;
}

/* based on assgn.c, modified for rankvalue */
#if 1
#define declscalar(node) ( (node->info & RANKDECL)&&(node->rank.n == 0)&& \
			   (node->info & TYPEDECL) )
#endif


/*
	doinf - node inferencer */

void
doinf(struct node * node, int top)
{
  switch (node->nodetype) {

    default:
    caserr("[doinf] ", node->nodetype);
    break;

  case ASSIGN:
    /* if (node->info & EARLYBIND) {*/
    node->ptr1 = mpcounter++;    /* memory pointer */
#if 0 
    if (!declscalar(LEFT))
      node->ptr2 = trscounter++;   /* trs register */
#endif
    if ( (!declscalar(LEFT)) ||
	 (!typeisknown(node)) ||
	 ( typeisknown(node) && 
	   ( (node->type.n == APLC_COMPLEX) ||
	     (node->type.n == APLC_QUAT)    ||
	     (node->type.n == APLC_OCT) ) ) ) {
      node->ptr2 = trscounter++;   /* trs register */
    }
    node->ptr3 = icounter++;     /* size of right */
    node->ptr4 = rescounter++;   /* result register */
    /* if (top)*/
    /* add an index if we don't have one */
    if (top || (node->index == 0) )
      node->index = icounter++;
    RIGHT->index = node->index;	     /* loop index variable */
    doinf(RIGHT, 0);
    break;

  case AVEC:
  case TCAV:
    break;

  case BCON:
  case ICON:
  case RCON:
  case SCON:
  case LCON:
  case IDENT:
    node->ptr1 = mpcounter++;	     /* memory pointer */
    node->ptr2 = rescounter++;	     /* result register */
    node->ptr3 = icounter++;	     /* type */
    node->ptr4 = icounter++;	     /* int value */
    break;

  case ZCON:
  case QCON:
  case OCON:
    node->ptr1 = mpcounter++;
    node->ptr2 = rescounter++;
    node->ptr3 = trscounter++;
    node->ptr4 = icounter++;	     /* type */
    node->ptr5 = icounter++;	     /* size */
    break;

  case BOX:
  case QQUAD:
  case DBOX:
  case DQQUAD:
    node->ptr1 = trscounter++;
    node->ptr2 = mpcounter++;
    node->ptr3 = rescounter++;
    break;

  case QBOXAS:
    node->ptr2 = trscounter++;
    node->ptr3 = trscounter++;
    node->ptr4 = mpcounter++;
    node->ptr5 = rescounter++;
    if (RIGHT != NILP)
      doinf(RIGHT, 0);
    break;
    break;

  case BOXASSIGN:
    node->ptr1 = icounter++; /* size of right */
    node->ptr2 = trscounter++; /* right */
    /*
    if ( !(RIGHT->info & TYPEKNOWN) ||
    (RIGHT->type.n != APLC_CHAR) )*/
    node->ptr3 = trscounter++; /* result */
    node->ptr4 = icounter++;
    node->ptr5 = trscounter++;/* right */
#if 0
    node->ptr3 = icounter++;	     /* size of right */
    node->ptr4 = rescounter++;	     /* result reg */
    node->ptr5 = mpcounter++;
    if (!top) {
      node->ptr6 = mpcounter++;
      if (!(node->info & VALUESKNOWN)) {
	if (!(RIGHT->info & HAVEVALUE)) {
	  node->ptr7 = trscounter++; /* trs register */
	}
      }
    }
#endif
    RIGHT->index = icounter++;
    doinf(RIGHT, 0);
    break;

  case DBOXAS:
  case DQBOXAS:
    /* nya */
    break;

  case CAT:
    doaxis(node);
    node->ptr1 = icounter++;
    node->ptr2 = icounter++;
    node->ptr3 = mpcounter++;
    node->ptr4 = icounter++;
    node->ptr5 = icounter++;
    node->ptr6 = icounter++;
    node->ptr7 = rescounter++;
    node->ptr8 = icounter++;
    node->ptr9 = icounter++;
    node->ptr10 = icounter++;
    if (node->info & SEQUENTIAL) {
      LEFT->index = icounter++;
      RIGHT->index = icounter++;
    } else {
      /* sws  need to check these:
	 probably the vector case only applies to true cat, not lam
	 */
      if (is_scalar(LEFT))
	LEFT->index = node->ptr9;
      else
	LEFT->index = icounter++;
      if (is_scalar(RIGHT)) 
	RIGHT->index = node->ptr9;
      else
	RIGHT->index = icounter++;
    }
    doinf(LEFT, 0);
    doinf(RIGHT, 0);
    break;

  case CATCH:
    doinf(LEFT, 1);
    doinf(RIGHT, 1);
    break;

  case CIVEC:
    RIGHT->index = icounter++;
    node->ptr1 = icounter++;
    node->ptr3 = mpcounter++;
    node->ptr4 = mpcounter++;
    node->ptr5 = rescounter++;
    node->ptr6 = mpcounter++;
    doinf(RIGHT, 0);
    break;

  case COLLECT:
  case CVEC:
    node->ptr2 = icounter++;	     /* size of right */
    if (! ( (node->info & VALUESKNOWN) ||
	    (RIGHT->info & HAVEVALUE) ) )
      node->ptr3 = trscounter++; /* trs register */
    node->ptr4 = rescounter++;	     /* result reg */
    node->ptr5 = mpcounter++;
    node->ptr6 = mpcounter++;
    RIGHT->index = icounter++;
    doinf(RIGHT, 0);
    break;

  case CCOLLECT:
    node->ptr2 = icounter++;	     /* size of right */
    node->ptr3 = trscounter++;	     /* trs register */
    node->ptr4 = rescounter++;	     /* result reg */
    node->ptr5 = mpcounter++;
    node->ptr6 = mpcounter++;
    RIGHT->index = icounter++;
    doinf(RIGHT, 0);
    break;

  case COMMENT:
    break;

  case COMPRESS:
  case EXPAND:
    doaxis(node);
    LEFT->index = icounter++;
    node->ptr1 = icounter++;
    node->ptr2 = icounter++;
    node->ptr3 = icounter++;
    node->ptr4 = mpcounter++;
    node->ptr5 = icounter++;
    node->ptr6 = rescounter++;
    node->ptr7 = rescounter++;
    node->ptr8 = mpcounter++;
    node->ptr9 = icounter++;
    if (!(node->info & RANKKNOWN))
      node->ptr10 = icounter++;
    if (node->nodetype == COMPRESS)
      node->ptr11 = icounter++;
    if (is_scalar(RIGHT) || is_vector(RIGHT))
      RIGHT->index = node->ptr9;
    else
      RIGHT->index = icounter++;

    /* only for scalars... */
    node->ptr12 = rescounter++;
    node->ptr13 = rescounter++;

    doinf(LEFT, 0);
    doinf(RIGHT, 0);
    break;

  case CISCALAR:
    RIGHT->index = icounter++;
    node->ptr1 = rescounter++;
    doinf(RIGHT, 0);
    break;

  case CSCALAR:
    RIGHT->index = icounter++;
    node->ptr1 = rescounter++;
    doinf(RIGHT, 0);
    break;

  case DEAL:
    /* sws?? RIGHT->index = node->index; */
    node->ptr1 = mpcounter++;
    node->ptr2 = mpcounter++;
    node->ptr3 = rescounter++;
    doinf(LEFT, 0);
    doinf(RIGHT, 0);
    break;

  case DECODE:
  case INNERCHILD:
    if (!typeisknown(node))
      node->ptr1 = icounter++;
    if (!rkisknown(node))
      node->ptr2 = icounter++;
    if (!(node->info & SHAPEKNOWN))
      node->ptr3 = mpcounter++;
    node->ptr5 = icounter++;	     /* loop counter */
    node->ptr6 = rescounter++;
    node->ptr7 = rescounter++;
    node->ptr8 = rescounter++;
    node->ptr9 = rescounter++;
    if (is_vector(LEFT))
      LEFT->index = node->ptr5;
    else
      LEFT->index = icounter++;
    if (is_vector(RIGHT))
      RIGHT->index = node->ptr5;
    else
      RIGHT->index = icounter++;
    doinf(LEFT, 0);
    doinf(RIGHT, 0);
    break;

  case DFORMAT:
  case MSOLVE:
    lrinf(LEFT, RIGHT);
    node->ptr1 = trscounter++;
    node->ptr2 = trscounter++;
    node->ptr3 = trscounter++;
    node->ptr4 = mpcounter++;
    node->ptr5 = rescounter++;
    break;

  case DOMINO:
  case EXECUTE:
  case FORMAT:
    node->ptr2 = trscounter++;
    node->ptr3 = trscounter++;
    node->ptr4 = mpcounter++;
    node->ptr5 = rescounter++;
    doinf(RIGHT, 0);
    break;

  case DSOP:
    RIGHT->index = LEFT->index = node->index;
    node->ptr1 = rescounter++;
    node->ptr2 = rescounter++;
    node->ptr3 = icounter++;
    node->ptr4 = icounter++;
    node->ptr5 = mpcounter++;
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    break;

  case DTRANS:
    mergeresource(node, RIGHT);
    if (!(node->info & SHAPEKNOWN))
      node->ptr9 = mpcounter++;
    doinf(LEFT, 0);
    doinf(RIGHT, 0);
    break;

  case EMPTSEMI:
    if (!(node->info & SHAPEKNOWN))
      node->ptr4 = mpcounter++;
    break;

  case ENCODE:
    LEFT->index = icounter++;
    RIGHT->index = icounter++;
    /* if (top)*/
    if (top || (node->index == 0) )
      node->index = icounter++;

    if (!typeisknown(node))
      node->a.ptr0 = icounter++;
    node->ptr1 = mpcounter++;
    node->ptr2 = icounter++;
    node->ptr3 = rescounter++;
    node->ptr4 = rescounter++;
    node->ptr5 = rescounter++;
    node->ptr6 = icounter++;
    node->ptr7 = icounter++;
    node->ptr8 = icounter++;
    node->ptr9 = icounter++;
    node->ptr10 = icounter++;
    node->ptr11 = trscounter++;
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    break;

  case EPSILON:
    LEFT->index = node->index;
    node->ptr1 = rescounter++;
    node->ptr2 = mpcounter++;
    node->ptr3 = rescounter++;	     /* sws */
    doinf(LEFT, 0);
    doinf(RIGHT, 0);
    break;

  case SYSVAR:
    node->ptr3 = trscounter++;
    node->ptr4 = mpcounter++;
    node->ptr5 = rescounter++;
    break;

  case ASYSVAR:
    node->ptr2 = trscounter++;
    node->ptr3 = trscounter++;
    node->ptr4 = mpcounter++;
    node->ptr5 = rescounter++;
    if (RIGHT != NILP)
      doinf(RIGHT, 0);
    break;

  case FIDENT:
#if 0
    /* normally left and right will come from ccollect, so 
       we don't need a new trs 
       later we should add a global nulltrs for these 
       - done
       */ 
    if (LEFT == NILP)
      node->ptr1 = trscounter++;
    if (RIGHT == NILP)
      node->ptr2 = trscounter++;
#endif
    node->ptr3 = trscounter++;
    node->ptr4 = mpcounter++;
    node->ptr5 = rescounter++;
    if (LEFT != NILP)
      doinf(LEFT, 0);
    if (RIGHT != NILP)
      doinf(RIGHT, 0);
    break;

  case DSYSFUN:
  case ESYSFUN:
  case MSYSFUN:
    /* non mergeable (standard) versions of take/drop */ 
  case DROP:
  case TAKE:
    node->ptr1 = trscounter++;
    node->ptr2 = trscounter++;
    node->ptr3 = trscounter++;
    node->ptr4 = mpcounter++;
    node->ptr5 = rescounter++;
    if (LEFT != NILP)
      doinf(LEFT, 0);
    if (RIGHT != NILP)
      doinf(RIGHT, 0);
    break;

  case GO:
    RIGHT->index = icounter++;
    node->ptr1 = icounter++;
    doinf(RIGHT, 0);
    break;

  case INDEX:
    RIGHT->index = node->index;
    node->ptr1 = rescounter++;	     /* sws, was simple integer */
    node->ptr2 = rescounter++;
    node->ptr3 = mpcounter++;
    doinf(LEFT, 0);
    doinf(RIGHT, 0);
    break;

  case INNER:
    RIGHT->index = node->index;
    node->ptr1 = RIGHT->ptr1;
    node->ptr2 = icounter++;
    node->ptr3 = icounter++;
    node->ptr4 = icounter++;
    node->ptr6 = rescounter++;
    doinf(RIGHT, 0);
    break;

  case IOTA:
    /* sws switched */
    /* node->ptr1 = mpcounter++;*/
    node->ptr1 = rescounter++;
    if (node->info & SEQUENTIAL)
      node->ptr2 = icounter++;
    doinf(RIGHT, 0);
    break;

  case LAM:
    break;

  case MSOP:
    RIGHT->index = node->index;
    if (!typeisknown(node))
      node->ptr1 = icounter++;
    node->ptr2 = rescounter++;
    node->ptr3 = rescounter++;
    doinf(RIGHT, 0);
    break;

  case OUTER:
    LEFT->index = icounter++;
    RIGHT->index = icounter++;
    if (!typeisknown(node))
      node->a.ptr0 = icounter++;
    if (!(node->info & SHAPEKNOWN))
      node->ptr1 = mpcounter++;
    node->ptr2 = icounter++;
    node->ptr4 = rescounter++;
    node->ptr5 = rescounter++;
    /* ?? if ( (! (node->info & RANKKNOWN)) || ANYRANK == node->rank.n ) */
    if (!(node->info & SHAPEKNOWN))
      node->ptr6 = icounter++;
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    break;

  case RAVEL:
    RIGHT->index = node->index;
    node->ptr1 = mpcounter++;
    node->ptr2 = icounter++;
    doinf(RIGHT, 0);
    break;

  case REDUCE:
    doaxis(node);
    RIGHT->index = icounter++;
    node->ptr1 = mpcounter++;
    node->ptr2 = icounter++;
    node->ptr3 = icounter++;
    node->ptr4 = icounter++;
    node->ptr5 = rescounter++;
    /*if (!typeisknown(node))*/
      node->ptr6 = icounter++;
    if (!rkisknown(node))
      node->ptr7 = icounter++;
    node->ptr8 = icounter++;
    node->ptr9 = icounter++;
    node->ptr10 = icounter++;
    node->ptr11 = rescounter++;
    /*node->ptr12 = icounter++;*/
    doinf(RIGHT, 0);
    break;

  case REVERSE:
    doaxis(node);
    mergeresource(node, RIGHT);
    node->ptr9 = icounter++;
    doinf(RIGHT, 0);
    break;

  case RESHAPE:
    if ((node->info & SHAPEKNOWN) &&
	(RIGHT->info & SHAPEKNOWN) &&
	(numin(RIGHT) >= numin(node))) {
      RIGHT->index = node->index;
      if (node->info & SEQUENTIAL) {
	RIGHT->info |= SEQUENTIAL;
	/* this situation occurs often enough to make it a worthwhile special
	   case */
	if (RIGHT->nodetype == IOTA)
	  node->info |= NOINDEX;
      }
    } else {
      RIGHT->index = icounter++;
      node->ptr1 = icounter++;
    }
    doinf(LEFT, 0);
    doinf(RIGHT, 0);
    break;

  case RHO:
    node->ptr1 = mpcounter++;
    node->ptr2 = mpcounter++;
    doinf(RIGHT, 0);
    break;

  case RHORHO:
    node->ptr1 = icounter++;
    doinf(RIGHT, 0);
    break;

  case ROLL:
    RIGHT->index = node->index;
    node->ptr1 = rescounter++;
    node->ptr2 = icounter++;
    doinf(RIGHT, 0);
    break;

  case ROTATE:
    doaxis(node);
    node->ptr1 = icounter++;
    node->ptr2 = icounter++;
    node->ptr3 = icounter++;
    if (!(LEFT->info & TYPEKNOWN))
      node->ptr4 = rescounter++;
    LEFT->index = icounter++;
    if (is_scalar(RIGHT) || is_vector(RIGHT))
      RIGHT->index = node->ptr3;
    else
      RIGHT->index = icounter++;
    doinf(LEFT, 0);
    doinf(RIGHT, 0);
    break;

  case SCAN:
    doaxis(node);

/* sws
   this needs to be after the right index is set, so the index can
   be passed along:
        doinf(RIGHT, 0);
*/
    node->ptr1 = icounter++;
    if (!(RIGHT->info & SEQUENTIAL))
      node->ptr2 = icounter++;
    node->ptr3 = icounter++;
    node->ptr5 = icounter++;
    if (RIGHT->info & SEQUENTIAL)
      RIGHT->index = node->index;
    else if (is_vector(RIGHT))
      RIGHT->index = node->ptr5;
    else
      RIGHT->index = icounter++;
    node->ptr6 = rescounter++;
    if (!typeisknown(node))
      node->ptr7 = icounter++;
    node->ptr8 = icounter++;
    node->ptr9 = rescounter++;
    doinf(RIGHT, 0);
    break;

  case SM:
    if (LEFT == NILP)
      RIGHT->index = node->index;
    else {
      LEFT->ptr3 = node->ptr3;
      LEFT->index = icounter++;
      doinf(LEFT, 0);
      RIGHT->index = icounter++;
    }
    if (AXIS == NILP)
      doinf(AXIS, 0);
    doinf(RIGHT, 0);
    node->ptr2 = icounter++;
    if (!rkisknown(node))
      node->ptr4 = icounter++;
    if (!(node->info & SHAPEKNOWN))
      node->ptr5 = mpcounter++;
    node->ptr6 = rescounter++;
    break;

  case SORT:
    node->ptr1 = rescounter++;
    node->ptr2 = mpcounter++;
    node->ptr3 = mpcounter++;
    node->ptr4 = mpcounter++;
    doinf(RIGHT, 0);
    break;

  case SUB:
    LEFT->index = RIGHT->ptr3 = icounter++;	/* offset' */
    RIGHT->index = node->index;	     /* offset */
    doinf(LEFT, 0);
    doinf(RIGHT, 1);
    break;

  case SUBASSIGN:
    /* sws from assign... */
    /* trs for collecting right values */
    node->ptr1 = mpcounter++;	     /* memory pointer */
    node->ptr2 = trscounter++;	     /* trs register */
    node->ptr3 = icounter++;	     /* size of right */
    node->ptr4 = rescounter++;	     /* result register, node, store */
    node->ptr5 = icounter++;	     /* type  */
    node->ptr6 = rescounter++;	     /* result register, right */
    node->ptr7 = mpcounter++;	     /* memory pointer */
    node->ptr8 = icounter++;	     /* size of right */

    /* for new alternate subassign */
    node->ptr9 = mpcounter++;	     /* memory pointer */
    node->ptr10 = trscounter++;	     /* trs register */

    /* if (top)*/
    /* add an index if we don't have one */
    if (top || (node->index == 0) )
      node->index = icounter++;

    /* loop index variables */
    /* sws offset' */
    LEFT->index = STORE->index = icounter++;
    /* RIGHT->index = AXIS->ptr3 = icounter++; */
    /* offset */
    RIGHT->index = AXIS->ptr3 = node->index;
    AXIS->index = RIGHT->index;

    doinf(LEFT, 0);
    doinf(AXIS, 1);
    doinf(RIGHT, 0);
    break;

    /* mergeable versions of take/drop */ 
  case GWDROP:
  case GWTAKE:
    mergeresource(node, RIGHT);
    if (!(node->info & SHAPEKNOWN))
      node->ptr9 = mpcounter++;
    doinf(LEFT, 0);
    doinf(RIGHT, 0);
    break;

  case TRANS:
    mergeresource(node, RIGHT);
    if (!(node->info & SHAPEKNOWN))
      node->ptr9 = mpcounter++;
    doinf(RIGHT, 0);
    break;
  }
}

/* end of resource.c */
