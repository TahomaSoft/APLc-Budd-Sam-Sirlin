/* f2cif.c - fortran intrinsic functions need by f2c  sws 5/92 */
/* (certain) fortran builtin functions, from f2c library */
/* I've taken what is needed by the LAPACK qr routines */

#include "f2c.h"

#define log10e 0.43429448190325182765

double
d_lg10(x)
  doublereal *x;
{
  double log();

  return (log10e * log(*x));
}


double
d_sign(a, b)
  doublereal *a, *b;
{
  double x;

  x = (*a >= 0 ? *a : -*a);
  return (*b >= 0 ? x : -x);
}


double
pow_di(ap, bp)
  doublereal *ap;
  integer *bp;
{
  double pow, x;
  integer n;

  pow = 1;
  x = *ap;
  n = *bp;

  if (n != 0) {
    if (n < 0) {
      if (x == 0) {
	return (pow);
      }
      n = -n;
      x = 1 / x;
    }
    for (;;) {
      if (n & 01)
	pow *= x;
      if (n >>= 1)
	x *= x;
      else
	break;
    }
  }
  return (pow);
}

/* end of f2cif.c */
