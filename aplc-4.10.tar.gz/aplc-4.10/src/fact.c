/*
	APL Compiler

	Run time system
	routines having to do with scalar functions values

    sws: factorial function
         
*/


# include <stdio.h>
# include <math.h>

#include "aplc.h" 

/* could use a table here ... */


/* factorial for positive integers */
extern int 
aplc_fact(int n)
{
    int i;
    i=1;
    while (n > 0){
	i *= n--;
    }
    return(i);
}

/* end of fact.c */
