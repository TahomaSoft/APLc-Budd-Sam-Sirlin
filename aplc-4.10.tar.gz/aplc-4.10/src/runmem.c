/*
	APL Compiler
	
	Run time routines - Memory Allocation / TRS manipulation
	tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

#include "aplc.h"

/* sws put here since it needs error */
#include "memalloc.h"

/* to get buffersize: */
#include "run.h"

#define NILTRS  (struct trs_struct *) 0

/*  integer vector 1, scalar one shape */
int aplc_ivone[1] = {1};
/* integer zero - vector for shape */
int aplc_ivzero[1] = {0};

/* assign - assign a trs structure to an identifier 
            note this 
	    copies type, rank
	    does not copy shape or value, but just assigns pointers 
 */
extern void
aplc_assign(struct trs_struct * id, struct trs_struct * trs)
{
  id->type = trs->type;
  id->rank = trs->rank;
  id->shape = trs->shape;
  id->size = trs->size;
  id->alloc_ind = trs->alloc_ind;
  id->value = trs->value;
}

/*  equate values, with some type checking and changing.
    can't just increase storage of id here - this
    must be done more carefully
*/
/* sws ...
assign_ind - assign part of a trs structure to part of an identifier
                id[idi]= trs[trsi]
*/
extern void
aplc_assign_ind(struct trs_struct * id, int idi, 
		struct trs_struct * trs, int trsi)
{
  int itype, ttype;

  /* assume id is of rank >0 check rank of trs, treat scalar
     seperately check types
  */
  itype = id->type;
  ttype = trs->type;

  if (trs->rank == 0) {
    /* scalar right term - ignore index */
    switch (itype) {
    case APLC_CHAR:
      if (ttype != APLC_CHAR) {
	aplc_error("[aplc_assign_ind] impossible conversion to APLC_CHAR");
	break;
      } else {
	id->value.cp[idi] = *(trs->value.cp);
	break;
      }
    case APLC_BOOL:
    case APLC_INT:
      if (ttype != APLC_INT) {
	aplc_error("[aplc_assign_ind] impossible conversion to APLC_INT");
	break;
      } else {
	id->value.ip[idi] = *(trs->value.ip);
	break;
      }
    case APLC_REAL:
      if (ttype == APLC_INT) {
	id->value.rp[idi] = *(trs->value.ip);
	break;
      } else if (ttype == APLC_REAL) {
	id->value.rp[idi] = *(trs->value.rp);
	break;
      } else {
	aplc_error("[aplc_assign_ind] impossible conversion to REAL");
	break;
      }
    default:
      fprintf(aplcerr, "type %d\n", itype);
      aplc_error("[aplc_assign_ind] impossible type");
    }
  } else {
    /* expected case, right index necessary */
    switch (itype) {
    case APLC_CHAR:
      if (ttype != APLC_CHAR) {
	aplc_error("[aplc_assign_ind] impossible conversion to APLC_CHAR");
	break;
      } else {
	id->value.cp[idi] = trs->value.cp[trsi];
	break;
      }
    case APLC_BOOL:
    case APLC_INT:
      if (ttype != APLC_INT) {
	aplc_error("[aplc_assign_ind] impossible conversion to APLC_INT");
	break;
      } else {
	id->value.ip[idi] = trs->value.ip[trsi];
	break;
      }
    case APLC_REAL:
      if (ttype == APLC_INT) {
	id->value.rp[idi] = trs->value.ip[trsi];
	break;
      } else if (ttype == APLC_REAL) {
	id->value.rp[idi] = trs->value.rp[trsi];
	break;
      } else {
	aplc_error("[aplc_assign_ind] impossible conversion to REAL");
	break;
      }
    default:
      fprintf(aplcerr, "type %d\n", itype);
      aplc_error("[aplc_assign_ind] impossible type");
    }
  }
}

/* sws
   initialize a trs structure - to zilde
   */
extern void
aplc_inittrs(struct trs_struct * trs)
{
  trs->type = APLC_UKTYPE;
  /* scalar 
     trs->rank = 0;
     trs->shape = (int *) 0;*/
  trs->rank = 1;
  trs->shape = aplc_ivzero;
  trs->size = 0; 
  trs->alloc_ind = APLC_UNALLOC;
  trs->value.ip = (int *) 0;
}

/* sws */
/* settrs - set type, rank, and shape values into a trs structure 
   - note that shape is now copied (sws) rather than setting a pointer 
     so we can memfree (or not) the original source and can later 
     free the trs
   - calculate size  
   - assume this is followed by something like talloc, which puts
     values
*/
extern void
aplc_settrs(struct trs_struct * trs, int type, int rank, int *shape)
{
  int i;
  union mp_struct mptmp;


  trs->type = type;
  if ( (type == APLC_UNDEF) || 
       (type == APLC_UKTYPE) ) {
    /* ignore request if type doesn't make sense */
    trs->rank = 1;
    trs->shape = aplc_ivzero;
    return;
  }
  trs->rank = rank;
  /* trs->shape = shape;*/
  if (rank > 0) {
    if ( (rank == 1) && (shape[0] == 0) ) {
      /* zilde - don't allocate, use static 0 */
      trs->shape = aplc_ivzero;
    } else {
      aplc_vectalloc(&mptmp, rank, APLC_INT);
      trs->shape = mptmp.ip;
      for (i=0; i<rank; i++)
	trs->shape[i] = shape[i];
    }
  } else {
    /* rank is zero, must be scalar, put shape=1 anyway */
    trs->shape = aplc_ivone;
  }
  /* compute the size */
  trs->size = aplc_vsize(trs->rank, trs->shape);
}

/* aplc_mp2res - get a value from storage for a variable 
   - take it from a mp_struct and put it in a res_struct
*/
extern void
aplc_mp2res(union res_struct * res, union mp_struct * mp, int i, int type)
{
  int j;

  switch (type) {
    case APLC_CHAR:
    res->c = *(mp->cp + i);
    break;
  case APLC_BOOL:
  case APLC_INT:
    res->i = *(mp->ip + i);
    break;
  case APLC_REAL:
    res->r = *(mp->rp + i);
    break;
  case APLC_COMPLEX:
    res->z[0] = mp->zp[0][i];
    res->z[1] = mp->zp[1][i];
    break;
  case APLC_QUAT:
    res->q[0] = mp->qp[0][i];
    res->q[1] = mp->qp[1][i];
    res->q[2] = mp->qp[2][i];
    res->q[3] = mp->qp[3][i];
    break;
  case APLC_OCT:
    for (j=0; j<8; j++)
      res->o[j] = mp->qp[j][i];
    break;
  default:
    fprintf(aplcerr, "type %d\n", type);
    aplc_error("[aplc_mp2res] impossible condition");
  }
}

/* setmp - get a value into storage for a variable 
   - take it from a res_struct and put it in a mp_struct 
*/
extern void
aplc_setmp(union res_struct * res, union mp_struct * mp, int i, int type)
{
  int j;

  switch (type) {
    case APLC_CHAR:
    *(mp->cp + i) = res->c;
    break;
  case APLC_BOOL:
  case APLC_INT:
    *(mp->ip + i) = res->i;
    break;
  case APLC_REAL:
    *(mp->rp + i) = res->r;
    break;
  case APLC_COMPLEX:
    mp->zp[0][i] = res->z[0];
    mp->zp[1][i] = res->z[1];
    break;
  case APLC_QUAT:
    mp->qp[0][i] = res->q[0];
    mp->qp[1][i] = res->q[1];
    mp->qp[2][i] = res->q[2];
    mp->qp[3][i] = res->q[3];
    break;
  case APLC_OCT:
    for (j=0; j<8; j++)
      mp->op[j][i] = res->o[j];
    break;
  default:
    fprintf(aplcerr, "type %d\n", type);
    aplc_error("[aplc_setmp] impossible condition");
  }
}

/* sws
   copy an entire trs to another
   - value still points to the original 
*/
extern void
aplc_duptrs(struct trs_struct *res, struct trs_struct *in)
{
  union mp_struct mptmp;

  res->type = in->type;
  res->rank = in->rank;
  aplc_vectalloc(&mptmp, res->rank, APLC_INT);
  res->shape = mptmp.ip;
  aplc_cpvec(res->shape, res->rank, in->shape);
  res->size = in->size;
  res->alloc_ind =  APLC_ALLOC_NF;
  res->value = in->value;
  res->scalar = in->scalar;
  return;
}


/* copy a (single) trs value to another trs 
   res(i) = inp(j)
*/
extern void
aplc_cptrsval(struct trs_struct *res, int i, 
	 struct trs_struct *inp, int j) 
{
  /* assume the same type for now... */
  switch(inp->type) {
  case APLC_CHAR:
    res->value.cp[i] = inp->value.cp[j];
    break;
  case APLC_BOOL:
  case APLC_INT:
    res->value.ip[i] = inp->value.ip[j];
    break;
  case APLC_REAL:
    res->value.rp[i] = inp->value.rp[j];
    break;
  default:
    fprintf(aplcerr, "type %d\n", inp->type);
    aplc_error("[aplc_cptrsval] impossible condition");
  }
}

/* 
   copy a res value to a trs 
   trs(i) = res
*/
extern void
aplc_cpres2trs(struct trs_struct *res, int i, union res_struct *inp)
{
  /* assume the same type for now... */
  switch(res->type) {
  case APLC_CHAR:
    res->value.cp[i] = inp->c;
    break;
  case APLC_BOOL:
  case APLC_INT:
    res->value.ip[i] = inp->i;
    break;
  case APLC_REAL:
    res->value.rp[i] = inp->r;
    break;
  default:
    fprintf(aplcerr, "type %d\n", res->type);
    aplc_error("[aplc_cpres2trs] impossible condition");
  }
}

/* sws 
   vectalloc - allocate a vector - main memory allocation interface 
   (renamed from valloc)  

   complex: stored as [r i], so 
   zp[0] points to the whole, 
   zp[1] points to the second half
*/
extern void
aplc_vectalloc(union mp_struct * mp, int size, int type)
{
  void *c = (void *) 0;
  int j;

  /* quietly ignore requests for no space! */
  /* sws  changed to always give space for 1 */
  if (size <= 0)
    size = 1;
    /*return;*/

  switch (type) {
  case APLC_CHAR:
    c = malloc((unsigned) size);
    mp->cp = (char *) c;
    break;

  case APLC_BOOL:
  case APLC_INT:
    /* mp->ip = (int *) (c = APLC_IMALLOC(size));*/
    c = (void *)(mp->ip = APLC_IMALLOC(size));
    break;

  case APLC_REAL:
    /*mp->rp = (double *) (c = APLC_DMALLOC(size));*/
    c = (void *) (mp->rp = APLC_DMALLOC(size));
    break;

  case APLC_COMPLEX:
    c = (void *) (mp->zp[0] = APLC_DMALLOC(2*size));
    mp->zp[1] = mp->zp[0] + size;
    break;

  case APLC_QUAT:
    c = (void *) (mp->qp[0] = APLC_DMALLOC(4*size));
    mp->qp[1] = mp->qp[0] + size;
    mp->qp[2] = mp->qp[1] + size;
    mp->qp[3] = mp->qp[2] + size;
    break;

  case APLC_OCT:
    c = (void *) (mp->op[0] = APLC_DMALLOC(8*size));
    for (j=1; j<8; j++)
      mp->op[j] = mp->op[j-1] + size;
    break;

  default:
    fprintf(aplcerr, "type %d\n", type);
    aplc_error("[aplc_vectalloc] impossible case");
    break;
  }
  if (c == (void *) 0) {
    fprintf(aplcerr, "request for type %d, size %d\n", type, size);
    aplc_error("[aplc_vectalloc] out of memory allocation space");
  }
}

/* 
   promote types in a numeric vector 
   - currently only int->real
*/
extern void
aplc_vectpromote(union mp_struct * mp, int size, int type, int newtype )
{
  int i;
  union mp_struct mptemp;

  switch(newtype) {
  default:
  case APLC_CHAR:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    /* error */
    aplc_error("[aplc_vectpromote] illegal types");
    break;
  case APLC_BOOL:
  case APLC_INT:
    /* nothing to do */ 
    break;
  case APLC_REAL:
    switch(type) {
    default:
      /* error */
      aplc_error("[aplc_vectpromote] illegal types");
      break;
    case APLC_BOOL:
    case APLC_INT:
      /* save old stuff */
      mptemp.ip = mp->ip;
      /* re allocate space */
      aplc_vectalloc(mp, size, APLC_REAL);
      /* copy */
      for (i = size - 1; i >= 0; i--)
	mp->rp[i] = (double) mptemp.ip[i];
      /* free */
      free(mptemp.ip); 
      break;
    }
    break;
  }
  return;
}

#ifdef SUNOS
/* some special alloc routines to meet sparc alignment requirements 
   - assume this is needed for all sunos machines
   - I don't have any experience with, say, sunos on x86 machines
   - assume this won't hurt
*/

void *
aplc_imalloc(int size)
{
  void *i;
  int nsize;
#if MEMDEBUG
  int in;
  double id;
#endif

  /* adjust size - want size*4 divisible by 8 */
  /* nsize = (8/4)*ceil(size*4/8.0);*/
  /* adjust size - want size*4 divisible by 16 */
  nsize = (16/4)*ceil(size*4/16.0);
#if MEMDEBUG
  printf("[aplc_imalloc] size = %d, nsize = %d\n", size, nsize);  
#endif
  i = memalign(8, (unsigned) nsize*sizeof(int));
#if MEMDEBUG
  in = (int) i;
  id = in/8.0;
  printf("[aplc_imalloc] i = %d, i/8 = %g\n", in, id);  
#endif
  return(i);  
}


/* realloc routines that use memalign, to ensure correct allignment 

   - these assume that allocations come in chunks of APLC_IBUFSIZE
     so if the request is for size, the old size was
     size - APLC_IBUFSIZE
     and both old and new are the same type
*/
extern void *
aplc_drealloc(double *ip, int size)
{
  double *newip, *nipt, *ipt;
  char *c;
  int i, oldsize;

  /* create new storage */
  /* newip = (double *) (c = APLC_DMALLOC(size));*/
  c = (char *) (newip = (double *) APLC_DMALLOC(size));
  if (c == (char *) 0) {
    fprintf(aplcerr, "request for size %d\n", size);
    aplc_error("[aplc_drealloc] out of memory allocation space");
  }
  /* copy old to new */
  oldsize = size - APLC_IBUFSIZE;
  for (i = 0, ipt = ip, nipt = newip; i < oldsize; i++) {
    *nipt++ = *ipt++;
  }

  /* free old stuff */
  free(ip);

  return (newip);
}

extern void *
aplc_irealloc(int *ip, int size)
{
  int *newip, *nipt, *ipt;
  char *c;
  int i, oldsize;

  /* create new storage */
  /* newip = (int *) (c = APLC_IMALLOC(size));*/
  c = (char *) (newip = (int *) APLC_IMALLOC(size));
  if (c == (char *) 0) {
    fprintf(aplcerr, "request for size %d\n", size);
    aplc_error("[aplc_irealloc] out of memory allocation space");
  }
  /* copy old to new */
  oldsize = size - APLC_IBUFSIZE;
  for (i = 0, nipt = newip, ipt = ip; i < oldsize; i++) {
    *nipt++ = *ipt++;
  }

  /* free old stuff */
  free(ip);

  return (newip);
}

#endif

/* sws
   vectrealloc - reallocate a vector 
   - main memory allocation interface */
extern void
aplc_vectrealloc(union mp_struct * mp, int size, int type)
{
  void *c = (void *) 0;

  switch (type) {
  case APLC_CHAR:
    mp->cp = c = realloc(mp->cp, (unsigned) size);
    break;

  case APLC_BOOL:
  case APLC_INT:
    /* mp->ip = (int *) (c = APLC_IREALLOC(size));*/
    c = (char *) (mp->ip = (int *) APLC_IREALLOC(size));
    break;

  case APLC_REAL:
    /* mp->rp = (double *) (c = APLC_DREALLOC(size));*/
    c = (char *) (mp->rp = (double *) APLC_DREALLOC(size));
    break;

  default:
    fprintf(aplcerr, "type %d\n", type);
    aplc_error("[aplc_vectrealloc] impossible case");
    break;
  }
  if (c == (char *) 0) {
    fprintf(aplcerr, "request for type %d, size %d\n", type, size);
    aplc_error("[aplc_vectrealloc] out of memory allocation space");
  }
}

/* vsize - compute the size of an object
   - product of the shapes, minimum of 1
 */
extern int
aplc_vsize(int rank, int *shape)
{
  register int size;

  size = 1;
  for (rank--; rank >= 0; rank--)
    size *= *(shape + rank);
  return (size);
}

/* 
   talloc - allocate storage for values in a trs structure 
   - assume that the rank and shape have been set already
   - assume the size has been determined already
   - return the size 
*/
extern int
aplc_talloc(struct trs_struct * trs)
{
  /* trs->size = aplc_vsize(trs->rank, trs->shape);*/
  /* ignores 0 size requests */
  aplc_vectalloc(&trs->value, trs->size, trs->type);
  trs->alloc_ind = APLC_ALLOC_F;
  return (trs->size);
}


/* sws */
/* detalloc - unallocate storage in a trs structure
              now free both the value and the shape
              also set the pointer values to 0 so no more freeing 
              can happen 
 */
extern void
aplc_detalloc(struct trs_struct * trs)
{
  int n;

  /* ignore requests to free 
     - nill pointers
     - un allocated 
     - not freeable */
  if ( (trs == NILTRS) ||
       (trs->alloc_ind == APLC_UNALLOC) ||
       /*(trs->alloc_ind == APLC_UNALLOC_COPY) ||*/
       (trs->alloc_ind == APLC_ALLOC_NF) ) {

    /* printf("[aplc_detalloc] arg is nill\n"); */
    /* printf("[aplc_detalloc] arg is not freeable\n"); */
    return;
  }

#if 0
  /* test case - do nothing */
  return;
#endif

  /* calculate size */
  /* n = aplc_vsize(trs->rank, trs->shape);*/
  n = trs->size;

  /* free the shape */
  if ( trs->shape != (int *) 0) {
    if ( trs->rank < 1 ) {
      /* scalars - don't free shape */
      trs->shape = (int *) 0;
    }
    /* watch out for zildes - static, no value */
    else if ( (trs->rank == 1) && (trs->shape[0] == 0) )
      return;
    else {
      /* normal vector or array case */
      free(trs->shape);
      trs->rank = 0;
      trs->shape = (int *) 0;
    }
  }

  /* now free the values */
  /* watch out for 0 size entities */
  if ( n < 1 )
    return;
  /* printf("\ntype %d\n", trs->type); */
  switch (trs->type) {
  case APLC_UNDEF:
  case APLC_UKTYPE:
    break;
  case APLC_BOOL:
  case APLC_INT:
    free ( trs->value.ip );
    break;
  case APLC_REAL:
    free ( trs->value.rp );
    break;
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    /* need something here eventually */
    break;
  case APLC_CHAR:
    free( (trs->value).cp );
    break;
  default:
    aplc_error("[aplc_detalloc] impossible case");
    break;
  }
  /* now re-initialize */
  trs->type = APLC_UKTYPE;
  trs->value.ip = (int *) 0;
}

/* just free the shape of a trs
   - be careful of stuff */
extern void
aplc_free_shape(struct trs_struct * trs)
{
  /* int n;*/

  if (trs == NILTRS) {
    /* printf("[aplc_detalloc] arg is nill\n"); */
    return;
  }
  if (trs->alloc_ind == APLC_ALLOC_NF) {
    /* printf("[aplc_detalloc] arg is not freeable\n"); */
    return;
  }

  /* calculate size */
  /* n = aplc_vsize(trs->rank, trs->shape);*/

  /* free the shape */
  if ( trs->shape != (int *) 0) {
    if ( trs->rank < 1 ) {
      /* scalars - don't free shape */
      trs->shape = (int *) 0;
    }
    /* watch out for zildes - static, no value */
    else if ( (trs->rank == 1) && (trs->shape[0] == 0) )
      return;
    else {
      /* normal vector or array case */
      free(trs->shape);
      trs->rank = 0;
      trs->shape = (int *) 0;
    }
  }

}

/* cpvec - copy an integer vector */
extern void
aplc_cpvec(register int *to, int size, register int *from)
{
  for (; size; size--)
    *to++ = *from++;
}

/* cpwo - copy an integer vector without a specific element */
extern void
aplc_cpwo(register int *to, int wo, int size, register int *from)
{
  int i;

  /* fix due to jbww UKC 6/87 */
  for (i = 0; i < size; i++) {
    if (i != wo)
      *to++ = *from;
    from++;
  }
}

/* sws
   cp2str - copy a char vector to a string */
extern void
aplc_cp2str(char *s, struct trs_struct *trs) 
{
  int i, n;
  char *v;

  switch (trs->type) {
  case APLC_CHAR:
    /* n = aplc_vsize(trs->rank, trs->shape);*/
    n = trs->size;
    /*printf("size %d", n);*/
    v = (trs->value).cp;
    for (i=0; i<n; i++)
      s[i] = *v++;
    s[i] = '\0';
    /*printf(" [%s]\n", s);*/
    break;

  default:
    /* error */
    aplc_error("[aplc_cp2str] input not character data");
    break;
  }
}

/* esubi - return the i'th element in the expansion vector */
extern int
aplc_esubi(int i, int rank, int *shape)
{
  register int val;

  val = 1;
  for (rank--; rank > i; rank--)
    val *= *(shape + rank);
  return (val);
}

/* end of runmem.c */
