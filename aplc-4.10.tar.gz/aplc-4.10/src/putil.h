/*
	APL Compiler

	print utilities
	Samuel W.  Sirlin (sws)

	The APL Compiler is Public Domain

	It may be freely redistributed as long as this notice of
	authorship is retained with the sources.

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever */

#ifndef _PUTIL
#define _PUTIL

extern int use_axis_node( int type );

extern char *str_class(enum classes xx);

void prstatenode(struct statenode * code);
void prtcode(struct statenode * code);
extern char *str_rank(int rank);
extern char *str_type_name(int type);
extern char *prtoken(int type);

#endif
/* end of putil.h */
