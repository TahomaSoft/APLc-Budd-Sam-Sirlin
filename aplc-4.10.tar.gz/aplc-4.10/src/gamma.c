/*
CS    REAL FUNCTION GAMMA(X)
CD    DOUBLE PRECISION FUNCTION DGAMMA(X)
C----------------------------------------------------------------------
C
C This routine calculates the GAMMA function for a real argument X.
C   Computation is based on an algorithm outlined in reference 1.
C   The program uses rational functions that approximate the GAMMA
C   function to at least 20 significant decimal digits.  Coefficients
C   for the approximation over the interval (1,2) are unpublished.
C   Those for the approximation for X .GE. 12 are from reference 2.
C   The accuracy achieved depends on the arithmetic system, the
C   compiler, the intrinsic functions, and proper selection of the
C   machine-dependent constants.
C
C
C*******************************************************************
C*******************************************************************
C
C Explanation of machine-dependent constants
C
C beta   - radix for the floating-point representation
C maxexp - the smallest positive power of beta that overflows
C XBIG   - the largest argument for which GAMMA(X) is representable
C          in the machine, i.e., the solution to the equation
C                  GAMMA(XBIG) = beta**maxexp
C XINF   - the largest machine representable floating-point number;
C          approximately beta**maxexp
C EPS    - the smallest positive floating-point number such that
C          1.0+EPS .GT. 1.0
C XMININ - the smallest positive floating-point number such that
C          1/XMININ is machine representable
C
C     Approximate values for some important machines are:
C
C                            beta       maxexp        XBIG
C
C CRAY-1         (S.P.)        2         8191        966.961
C Cyber 180/855
C   under NOS    (S.P.)        2         1070        177.803
C IEEE (IBM/XT,
C   SUN, etc.)   (S.P.)        2          128        35.040
C IEEE (IBM/XT,
C   SUN, etc.)   (D.P.)        2         1024        171.624
C IBM 3033       (D.P.)       16           63        57.574
C VAX D-Format   (D.P.)        2          127        34.844
C VAX G-Format   (D.P.)        2         1023        171.489
C
C                            XINF         EPS        XMININ
C
C CRAY-1         (S.P.)   5.45E+2465   7.11E-15    1.84E-2466
C Cyber 180/855
C   under NOS    (S.P.)   1.26E+322    3.55E-15    3.14E-294
C IEEE (IBM/XT,
C   SUN, etc.)   (S.P.)   3.40E+38     1.19E-7     1.18E-38
C IEEE (IBM/XT,
C   SUN, etc.)   (D.P.)   1.79D+308    2.22D-16    2.23D-308
C IBM 3033       (D.P.)   7.23D+75     2.22D-16    1.39D-76
C VAX D-Format   (D.P.)   1.70D+38     1.39D-17    5.88D-39
C VAX G-Format   (D.P.)   8.98D+307    1.11D-16    1.12D-308
C
C*******************************************************************
C*******************************************************************
C
C Error returns
C
C  The program returns the value XINF for singularities or
C     when overflow would occur.  The computation is believed
C     to be free of underflow and overflow.
C
C
C  Intrinsic functions required are:
C
C     INT, DBLE, EXP, LOG, REAL, SIN
C
C
C References: "An Overview of Software Development for Special
C              Functions", W. J. Cody, Lecture Notes in Mathematics,
C              506, Numerical Analysis Dundee, 1975, G. A. Watson
C              (ed.), Springer Verlag, Berlin, 1976.
C
C              Computer Approximations, Hart, Et. Al., Wiley and
C              sons, New York, 1968.
C
C  Latest modification: October 12, 1989
C
C  Authors: W. J. Cody and L. Stoltz
C           Applied Mathematics Division
C           Argonne National Laboratory
C           Argonne, IL 60439
C
C----------------------------------------------------------------------

Translated into c by SW Sirlin, for apl2c, August 9, 1991

*/

/* declare external routines */
extern double exp(double);
extern double floor(double);
extern double log(double);
extern double sin(double);

/* declaration for functions here */
extern double aplc_gamma(double x);


extern double 
aplc_gamma(double x)
{
  int i, n;
  int parity;
  double fact, res, sum, xden, xnum, y, y1, ysq, z;

/*
C----------------------------------------------------------------------
C  Mathematical constants
C----------------------------------------------------------------------
*/
  double pi = 3.1415926535897932384626434;
  double sqrtpi = 0.9189385332046727417803297;

/*
C----------------------------------------------------------------------
C  Machine dependent parameters
C----------------------------------------------------------------------
*/
  double xbig = 171.624;
  double xminin = 2.23e-308;
  double eps = 2.22e-16;
  double xinf = 1.79e308;

/*
C----------------------------------------------------------------------
C  Numerator and denominator coefficients for rational minimax
C     approximation over (1,2).
C----------------------------------------------------------------------
*/
  double p[8] = {
    -1.71618513886549492533811e+0, 2.47656508055759199108314e+1,
    -3.79804256470945635097577e+2, 6.29331155312818442661052e+2,
    8.66966202790413211295064e+2, -3.14512729688483675254357e+4,
    -3.61444134186911729807069e+4, 6.64561438202405440627855e+4
  };

  double q[8] = {
    -3.08402300119738975254353e+1, 3.15350626979604161529144e+2,
    -1.01515636749021914166146e+3, -3.10777167157231109440444e+3,
    2.25381184209801510330112e+4, 4.75584627752788110767815e+3,
    -1.34659959864969306392456e+5, -1.15132259675553483497211e+5
  };

/*
C----------------------------------------------------------------------
C  Coefficients for minimax approximation over (12, INF).
C----------------------------------------------------------------------
*/
  double c[7] = {
    -1.910444077728e-03, 8.4171387781295e-04,
    -5.952379913043012e-04, 7.93650793500350248e-04,
    -2.777777777777681622553e-03, 8.333333333333333331554247e-02,
    5.7083835261e-03
  };

/*
C----------------------------------------------------------------------
C  Statement functions for conversion between integer and float
C----------------------------------------------------------------------
*/
  parity = 0;
  fact = 1.0;
  n = 0;
  y = x;

  if (y <= 0.0) {

/*
C----------------------------------------------------------------------
C  Argument is negative
C----------------------------------------------------------------------
*/
    y = -x;
    y1 = floor(y);
    res = y - y1;
    if (res != 0.0) {
      if (y1 != floor(y1 / 2.0) * 2.0)
	parity = 1;
      fact = -pi / sin(pi * res);
      y = y + 1.0;
    } else {
      res = xinf;
      goto jump;
    }
  }
/*
C----------------------------------------------------------------------
C  Argument is positive
C----------------------------------------------------------------------
*/
  if (y < eps) {
/*
C----------------------------------------------------------------------
C  Argument .LT. EPS
C----------------------------------------------------------------------
*/
    if (y >= xminin)
      res = 1.0 / y;
    else {
      res = xinf;
      goto jump;
    }
  } else if (y < 12.0) {
    y1 = y;
    if (y < 1.0) {
/*
C----------------------------------------------------------------------
C  0.0 .LT. argument .LT. 1.0
C----------------------------------------------------------------------
*/
      z = y;
      y = y + 1.0;
    } else {
/*
C----------------------------------------------------------------------
C  1.0 .LT. argument .LT. 12.0, reduce argument if necessary
C----------------------------------------------------------------------
*/
      n = ((int) floor(y)) - 1;
      y = y - (double) n;
      z = y - 1.0;
    }
/*
C----------------------------------------------------------------------
C  Evaluate approximation for 1.0 .LT. argument .LT. 2.0
C----------------------------------------------------------------------
*/
    xnum = 0.0;
    xden = 1.0;
    for (i = 0; i <= 7; i++) {
      xnum = (xnum + p[i]) * z;
      xden = xden * z + q[i];
    }
    res = xnum / xden + 1.0;
    if (y1 < y) {
/*
C----------------------------------------------------------------------
C  Adjust result for case  0.0 .LT. argument .LT. 1.0
C----------------------------------------------------------------------
*/
      res = res / y1;
    } else if (y1 > y) {
/*
C----------------------------------------------------------------------
C  Adjust result for case  2.0 .LT. argument .LT. 12.0
C----------------------------------------------------------------------
*/
      for (i = 1; i <= n; i++) {
	res = res * y;
	y = y + 1.0;
      }
    }
  } else {
/*
C----------------------------------------------------------------------
C  Evaluate for argument .GE. 12.0,
C----------------------------------------------------------------------
*/
    if (y <= xbig) {
      ysq = y * y;
      sum = c[6];
      for (i = 0; i <= 5; i++) {
	sum = sum / ysq + c[i];
      }
      sum = sum / y - y + sqrtpi;
      sum = sum + (y - 0.5) * log(y);
      res = exp(sum);
    } else {
      res = xinf;
      goto jump;
    }
  }
/*
C----------------------------------------------------------------------
C  Final adjustments and return
C----------------------------------------------------------------------
*/
  if (parity)
    res = -res;
  if (fact != 1)
    res = fact / res;
jump:
  return (res);
}

/*
C ---------- Last line of GAMMA ----------
*/
