/*
	APL compiler

	structures and definitions for code trees.
	tim budd
*/

#ifndef _CTREE
#define _CTREE

/* parse tree processing modes */
enum pmodes {SHAPE, COMBINE, VALUE, FINISH};

/* types of operations for the code trees */

enum codeops {
	asgn,		/* assignment */
	castop,		/* cast operator */
	cnst,		/* constants - index into constant tables */
	condop,		/* conditional operation */
	dsop,		/* dyadic scalar ops */
	deref, 		/* pointer dereference */
	icnst,		/* actual integer constant (not index) */
	idptr,		/* pointer to an identifier, with fields */
	iptr,		/* index register value */
	ixorgin,	/* index origin */
	memptr,		/* memory pointer */
	msop,		/* monadic scalar ops */
	postinc,	/* postincrement (for pointers) */
	ref,		/* pointer ref */
	resptr,		/* result register pointer */
	tcnst,		/* type constant */
	trsptr,		/* type/rank/shape register pointer */
	trsvptr 	/* trs.value pointer */
	};

enum tfields { ctypefield, crankfield, cshapefield, cvalfield };

struct codetree {
	enum codeops cop;
	union {
		struct codetree *cleft;
		int cindex;
		char *cident;
		} c0;
	union {
		struct codetree *cright;
		enum tfields ctfield;
		} c1;
	union {
		int ctype;
		enum sops csop;
		struct codetree *cmiddle;
		} c2;
	};

#endif
/* end of ctree.h */






