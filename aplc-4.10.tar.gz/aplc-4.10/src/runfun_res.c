/*
	APL Compiler

        sam sirlin

	Run time system
	functions operating on res structs

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.


*/

/*

  experimental stuff

monadic

  "aplc_not",

  "aplc_floor", "aplc_ceil", 
  "aplc_conj", "aplc_neg", "aplc_sign", 
  "aplc_mag", "aplc_recip", "aplc_exp",
  "aplc_nlog", "aplc_pim", "aplc_fact",

dyadic

  "aplc_min", "aplc_max", 
  "aplc_plus", "aplc_minus", "aplc_times", 
  "aplc_residue", "aplc_divide", "aplc_power",
  "aplc_log", "aplc_circle", "aplc_binomial",

  "aplc_and", "aplc_or", "aplc_nand", "aplc_nor", 
  "aplc_lt", "aplc_le", "aplc_eq", "aplc_ne", "aplc_ge", "aplc_gt"};

 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "aplc.h"

/* -------------------------------------------------------- */
/* -------------------------------------------------------- */
static void zprint(char *s, union res_struct *z);

extern void aplc_zero_z(union res_struct *res);
extern void aplc_unit_z(union res_struct *res);

double aplc_atan2(double y, double x);
static double zangle(union res_struct * res);

extern void aplc_exp_res_z(union res_struct *res, union res_struct *a);
extern void aplc_ln_res_z(union res_struct *res, union res_struct *a);

extern void aplc_square_res_z(union res_struct *res, union res_struct *a);
extern void aplc_sqrt_res_z(union res_struct *res, union res_struct *a);

extern void aplc_times_res_z(union res_struct *res, union res_struct *a, 
			     union res_struct *b);
extern void aplc_divide_res_z(union res_struct *res, union res_struct *a, 
		 union res_struct *b);

/* -------------------------------------------------------- */
static void qprint(char *s, union res_struct *q);

extern void aplc_equate_q(union res_struct *res, union res_struct *val);
extern void aplc_negate_q(union res_struct *res, union res_struct *val);
extern void aplc_conj_q(union res_struct *res, union res_struct *val);

extern void aplc_Is_q(union res_struct *res, union res_struct *a, double s);
extern void aplc_Iq(union res_struct *res, union res_struct *a);
extern void aplc_Isq(union res_struct *res, union res_struct *a, double s);

extern void aplc_zero_q(union res_struct *res);
extern void aplc_unit_q(union res_struct *res);

static double qangle(union res_struct * res);

extern void aplc_square_res_q(union res_struct *res, union res_struct *a);
extern void aplc_sqrt_res_q(union res_struct *res, union res_struct *a);

extern void aplc_recip_res_q(union res_struct *res, union res_struct *q);
extern void aplc_exp_res_q(union res_struct *res, union res_struct *val);
extern void aplc_ln_res_q(union res_struct *res, union res_struct *q);

extern void aplc_sin_res_q(union res_struct *res, union res_struct *q);
extern void aplc_cos_res_q(union res_struct *res, union res_struct *q);
extern void aplc_tan_res_q(union res_struct *res, union res_struct *q);

extern void aplc_sinh_res_q(union res_struct *res, union res_struct *q);
extern void aplc_cosh_res_q(union res_struct *res, union res_struct *q);
extern void aplc_tanh_res_q(union res_struct *res, union res_struct *q);

extern void aplc_add_res_q(union res_struct *res, union res_struct *lval, 
			   union res_struct * rval);
extern void aplc_sub_res_q(union res_struct *res, union res_struct *lval, 
			   union res_struct * rval);

extern void aplc_q_times_r(union res_struct *res, union res_struct *val, 
			   double r);

extern void aplc_times_res_q(union res_struct *res, 
			     union res_struct *lval, 
			     union res_struct * rval);

extern void aplc_divide_res_q(union res_struct *res, union res_struct *lval, 
			      union res_struct * rval);


/* -------------------------------------------------------- */
/* -------------------------------------------------------- */
static void oprint(char *s, union res_struct *q);

extern void aplc_equate_o(union res_struct *res, union res_struct *val);
extern void aplc_negate_o(union res_struct *res, union res_struct *val);
extern void aplc_conj_o(union res_struct *res, union res_struct *val);

extern void aplc_Is_o(union res_struct *res, union res_struct *a, double s);
extern void aplc_Io(union res_struct *res, union res_struct *a);
extern void aplc_Iso(union res_struct *res, union res_struct *a, double s);

extern void aplc_zero_o(union res_struct *res);
extern void aplc_unit_o(union res_struct *res);

static double oangle(union res_struct * res);

extern void aplc_square_res_o(union res_struct *res, union res_struct *a);
extern void aplc_sqrt_res_o(union res_struct *res, union res_struct *a);

extern void aplc_recip_res_o(union res_struct *res, union res_struct *q);
extern void aplc_exp_res_o(union res_struct *res, union res_struct *val);
extern void aplc_ln_res_o(union res_struct *res, union res_struct *q);

extern void aplc_sin_res_o(union res_struct *res, union res_struct *q);
extern void aplc_cos_res_o(union res_struct *res, union res_struct *q);
extern void aplc_tan_res_o(union res_struct *res, union res_struct *q);

extern void aplc_sinh_res_o(union res_struct *res, union res_struct *q);
extern void aplc_cosh_res_o(union res_struct *res, union res_struct *q);
extern void aplc_tanh_res_o(union res_struct *res, union res_struct *q);

extern void aplc_add_res_o(union res_struct *res, union res_struct *lval, 
			   union res_struct * rval);
extern void aplc_sub_res_o(union res_struct *res, union res_struct *lval, 
			   union res_struct * rval);

extern void aplc_o_times_r(union res_struct *res, union res_struct *val, 
			   double r);

extern void aplc_times_res_o(union res_struct *res, 
			     union res_struct *lval, 
			     union res_struct * rval);

extern void aplc_divide_res_o(union res_struct *res, union res_struct *lval, 
			      union res_struct * rval);

/* -------------------------------------------------------- */
/* -------------------------------------------------------- */
/* Quaternion notes 

   Quaternion multiplication is not comutative, hence we have a choice
   as to which result to take. I've taken the right to left approach
   of apl here.

  q mult order

   - order of mult is right to left

   k <- j*i

or the order is left to right (more traditional seeming)

   k <- i*j


 */
/* default is right-to-left */
#define RLMORDER 1


/* if nonzero, check for some domain errors... 
   won't catch them all */
#define DCHECKS 1


/* -------------------------------------------------------- */
/* functional defs */

/* complex */
 
#define NORM_respz(res) sqrt(res->z[0]*res->z[0] + \
			    res->z[1]*res->z[1])

#define NORM2_respz(res) (res->z[0]*res->z[0] + \
			    res->z[1]*res->z[1])

#define NORM_resz(res) sqrt(res.z[0]*res.z[0] + \
			     res.z[1]*res.z[1])

#define NORM2_resz(res) (res.z[0]*res.z[0] + \
			 res.z[1]*res.z[1])


/* -------------------------------------------------------- */
/* quaternion */

#define NORM_respq(res) sqrt( res->q[0]*res->q[0] + \
			     res->q[1]*res->q[1] + \
			     res->q[2]*res->q[2] + \
			     res->q[3]*res->q[3])

/* get norm of vector part alone */
#define NORM_v_respq(res) sqrt( res->q[1]*res->q[1] + \
			        res->q[2]*res->q[2] + \
			        res->q[3]*res->q[3])

#define NORM2_respq(res) ( res->q[0]*res->q[0] + \
			     res->q[1]*res->q[1] + \
			     res->q[2]*res->q[2] + \
			     res->q[3]*res->q[3])

/* get norm of vector part alone */
#define NORM2_v_respq(res) (  res->q[1]*res->q[1] + \
			     res->q[2]*res->q[2] + \
			     res->q[3]*res->q[3])

/* -------------------------------------------------------- */
#define NORM_resq(res) sqrt( res.q[0]*res.q[0] + \
			     res.q[1]*res.q[1] + \
			     res.q[2]*res.q[2] + \
			     res.q[3]*res.q[3])

#define NORM_v_resq(res) sqrt( \
			     res.q[1]*res.q[1] + \
			     res.q[2]*res.q[2] + \
			     res.q[3]*res.q[3])

#define NORM2_resq(res) ( res.q[0]*res.q[0] + \
			  res.q[1]*res.q[1] + \
			  res.q[2]*res.q[2] + \
			  res.q[3]*res.q[3])

/* -------------------------------------------------------- */
/* -------------------------------------------------------- */
/* octonion */

#define NORM_respo(res) sqrt( res->o[0]*res->o[0] + \
			     res->o[1]*res->o[1] + \
			     res->o[2]*res->o[2] + \
			     res->o[3]*res->o[3] + \
			     res->o[4]*res->o[4] + \
			     res->o[5]*res->o[5] + \
			     res->o[6]*res->o[6] + \
			     res->o[7]*res->o[7])

/* get norm of vector part alone */
#define NORM_v_respo(res) sqrt( res->o[1]*res->o[1] + \
			     res->o[2]*res->o[2] + \
			     res->o[3]*res->o[3] + \
			     res->o[4]*res->o[4] + \
			     res->o[5]*res->o[5] + \
			     res->o[6]*res->o[6] + \
			     res->o[7]*res->o[7])

#define NORM2_respo(res) ( res->o[0]*res->o[0] + \
			     res->o[1]*res->o[1] + \
			     res->o[2]*res->o[2] + \
			     res->o[3]*res->o[3] + \
			     res->o[4]*res->o[4] + \
			     res->o[5]*res->o[5] + \
			     res->o[6]*res->o[6] + \
			     res->o[7]*res->o[7])

/* get norm of vector part alone */
#define NORM2_v_respo(res) (  res->o[1]*res->o[1] + \
			     res->o[2]*res->o[2] + \
			     res->o[3]*res->o[3] + \
			     res->o[4]*res->o[4] + \
			     res->o[5]*res->o[5] + \
			     res->o[6]*res->o[6] + \
			     res->o[7]*res->o[7])

/* -------------------------------------------------------- */
#define NORM_reso(res) sqrt( res.o[0]*res.o[0] + \
			     res.o[1]*res.o[1] + \
			     res.o[2]*res.o[2] + \
			     res.o[3]*res.o[3] + \
			     res.o[4]*res.o[4] + \
			     res.o[5]*res.o[5] + \
			     res.o[6]*res.o[6] + \
			     res.o[7]*res.o[7])

#define NORM_v_reso(res) sqrt( \
			     res.o[1]*res.o[1] + \
			     res.o[2]*res.o[2] + \
			     res.o[3]*res.o[3] + \
			     res.o[4]*res.o[4] + \
			     res.o[5]*res.o[5] + \
			     res.o[6]*res.o[6] + \
			     res.o[7]*res.o[7])

#define NORM2_reso(res) ( res.o[0]*res.o[0] + \
			     res.o[1]*res.o[1] + \
			     res.o[2]*res.o[2] + \
			     res.o[3]*res.o[3] + \
			     res.o[4]*res.o[4] + \
			     res.o[5]*res.o[5] + \
			     res.o[6]*res.o[6] + \
			     res.o[7]*res.o[7])


/* -------------------------------------------------------- */
/* -------------------------------------------------------- */
/* monadic */


extern void
aplc_not_res(union res_struct * res,  
	     union res_struct * resin, int type)
{
  aplc_cktype2(res, APLC_BOOL, resin,type);
  res->i = !res->i;
  return;
}

extern void
aplc_floor_res(union res_struct * res,  
	       union res_struct * resin, int type)
{
  double rem[8];
  double sum;
  int i, j;

  switch (type) {
  case APLC_BOOL:
  case APLC_INT:
    res->i = resin->i;
    break;
  case APLC_REAL:
    res->i = (int) floor(resin->r);
    break;
  case APLC_COMPLEX:
    res->z[0] = floor(resin->z[0]);
    res->z[1] = floor(resin->z[1]);
    rem[0] = resin->z[0] - res->z[0];
    rem[1] = resin->z[1] - res->z[1];
    sum = rem[0]+rem[1];
    /* each rem is in [0,1), so sum is in [0,2) */ 
    if ( (sum >= 1.0) || aplc_toleq(sum, 1.0) ) {
      if (rem[0] >= rem[1] )
	res->z[0] += 1.0;
      else
	res->z[1] += 1.0;
    }
    break;
  case APLC_QUAT:
    /* not sure about this... */
    sum = 0.0;
    for (i=0, j=0; i<4; i++) {
      res->q[i] = floor(resin->q[i]);
      rem[i] =  resin->q[i] - res->q[i];
      sum += rem[i];
      /* keep track of max rem element, in j */
      if (rem[i] > rem[j])
	j = i;
    }
    /* each rem is in [0,1), so sum is in [0,4) */ 
    if ( (sum >= 1.0) || aplc_toleq(sum, 1.0) ) {
      res->q[j] += 1.0;
    }
    break;
  case APLC_OCT:
    /* not sure about this... */
    sum = 0.0;
    for (i=0, j=0; i<8; i++) {
      res->o[i] = floor(resin->o[i]);
      rem[i] =  resin->o[i] - res->o[i];
      sum += rem[i];
      /* keep track of max rem element, in j */
      if (rem[i] > rem[j])
	j = i;
    }
    /* each rem is in [0,1), so sum is in [0,8) */ 
    if ( (sum >= 1.0) || aplc_toleq(sum, 1.0) ) {
      res->o[j] += 1.0;
    }
    break;
  }
  return;
}

extern void
aplc_ceil_res(union res_struct * res,  
	      union res_struct * resin, int type)
{
  double rem[8];
  double sum;
  int i, j;

  switch (type) {
  case APLC_BOOL:
  case APLC_INT:
    res->i = resin->i;
    break;
  case APLC_REAL:
    res->i = (int) ceil(resin->r);
    break;
  case APLC_COMPLEX:
    res->z[0] = ceil(resin->z[0]);
    res->z[1] = ceil(resin->z[1]);
    rem[0] = res->z[0] - resin->z[0];
    rem[1] = res->z[1] - resin->z[1];
    sum = rem[0]+rem[1];
    if ( (sum >= 1.0) || aplc_toleq(sum, 1.0) ) {
      if (rem[0] >= rem[1] )
	res->z[0] -= 1.0;
      else
	res->z[1] -= 1.0;
    }
    break;
  case APLC_QUAT:
    /* not sure about this... */
    sum = 0.0;
    for (i=0, j=0; i<4; i++) {
      res->q[i] = ceil(resin->q[i]);
      rem[i] =  res->q[i] - resin->q[i];
      sum += rem[i];
      if (rem[i] > rem[j])
	j = i;
    }
    if ( (sum >= 1.0) || aplc_toleq(sum, 1.0) ) {
      res->q[j] -= 1.0;
    }
    break;
  case APLC_OCT:
    /* not sure about this... */
    sum = 0.0;
    for (i=0, j=0; i<4; i++) {
      res->o[i] = ceil(resin->o[i]);
      rem[i] =  res->o[i] - resin->o[i];
      sum += rem[i];
      if (rem[i] > rem[j])
	j = i;
    }
    if ( (sum >= 1.0) || aplc_toleq(sum, 1.0) ) {
      res->o[j] -= 1.0;
    }
    break;
  }
  return;
}

extern void
aplc_conj_res(union res_struct * res,  
	      union res_struct * resin, int type)
{
  switch (type) {
  case APLC_BOOL:
  case APLC_INT:
    res->i = resin->i;
    break;
  case APLC_REAL:
    res->r = resin->r;
    break;
  case APLC_COMPLEX:
    res->z[0] = resin->z[0];
    res->z[1] = -resin->z[1];
    break;
  case APLC_QUAT:
    aplc_conj_q(res, resin);
    break;
  case APLC_OCT:
    aplc_conj_o(res, resin);
    break;
  }

  return;
}

extern void
aplc_neg_res(union res_struct * res,  
	     union res_struct * resin, int type)
{
  int i;

  switch (type) {
  case APLC_BOOL:
  case APLC_INT:
    res->i = -resin->i;
    break;
  case APLC_REAL:
    res->r = -resin->r;
    break;
  case APLC_COMPLEX:
    res->z[0] = -resin->z[0];
    res->z[1] = -resin->z[1];
    break;
  case APLC_QUAT:
    res->q[0] = -resin->q[0];
    res->q[1] = -resin->q[1];
    res->q[2] = -resin->q[2];
    res->q[3] = -resin->q[3];
    break;
  case APLC_OCT:
    for (i=0; i<8; i++)
      res->o[i] = - resin->o[i];
    break;
  }

  return;
}

extern void
aplc_sign_res(union res_struct * res,  
	      union res_struct * resin, int type)
{
  double mag;
  int i;

  switch (type) {
  case APLC_BOOL:
  case APLC_INT:
    if (resin->i < 0)
      res->i = -1;
    else if (resin->i == 0)
      res->i = 0;
    else
      res->i = 1;
    break;
  case APLC_REAL:
    if (resin->r < 0.0)
      res->i = -1;
    else if (resin->r == 0.0)
      res->i = 0;
    else
      res->i = 1;
    break;
  case APLC_COMPLEX:
    /* direction */
    mag = NORM_respz(resin);
    if (1.0 == 1.0 + mag) {
      res->z[0] = 0.0;
      res->z[1] = 0.0;
    } else {
      res->z[0] = resin->z[0]/mag;
      res->z[1] = resin->z[1]/mag;
    }
    break;
  case APLC_QUAT:
    mag = NORM_respq(resin);
    if (1.0 == 1.0 + mag) {
      res->q[0] = 0.0;
      res->q[1] = 0.0;
      res->q[2] = 0.0;
      res->q[3] = 0.0;
    } else {
      res->q[0] = resin->q[0]/mag;
      res->q[1] = resin->q[1]/mag;
      res->q[2] = resin->q[2]/mag;
      res->q[3] = resin->q[3]/mag;
    }
    break;
  case APLC_OCT:
    mag = NORM_respo(resin);
    if (1.0 == 1.0 + mag) {
      for (i=0; i<8; i++)
	res->o[i] = 0.0;
    } else {
      for (i=0; i<8; i++)
	res->o[i] = resin->o[i]/mag;
    }
    break;
  }

  return;
}

extern void
aplc_mag_res(union res_struct * res,  
	     union res_struct * resin, int type)
{
  switch (type) {
  case APLC_BOOL:
  case APLC_INT:
    if (resin->i < 0)
      res->i = -resin->i;
    else
      res->i = resin->i;
    break;
  case APLC_REAL:
    if (resin->r < 0)
      res->r = -resin->r;
    else
      res->r = resin->r;
    break;
  case APLC_COMPLEX:
    res->r = NORM_respz(resin);
    break;
  case APLC_QUAT:
    res->r = NORM_respq(resin);
    break;
  case APLC_OCT:
    res->r = NORM_respo(resin);
    break;
  }

  return;
}

extern void
aplc_recip_res(union res_struct * res,  
	       union res_struct * resin, int type)
{
  double x;
  union res_struct rtemp;

  switch (type) {
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
    aplc_cktype2(res, APLC_REAL, resin,type);
#if DCHECKS
    /* check for domain errors */
    if ( res->r ==0.0 ) {
      printf("[runop] %% %g\n", res->r);
      aplc_error("%%: domain error");
    }
#endif
    res->r = 1.0 / res->r;
    break;
  case APLC_COMPLEX:
    aplc_cktype2(res, APLC_COMPLEX, resin,type);
    x = NORM2_respz(res);
#if DCHECKS
    if ( 1 == 1+x ) {
      printf("[runop] %% %gi%g\n", res->z[0], res->z[1]);
      aplc_error("%%: domain error");
    }
#endif
    res->z[0] =  res->z[0]/x;
    res->z[1] = -res->z[1]/x;
  break;
  case APLC_QUAT:
    aplc_cktype2(&rtemp, APLC_QUAT, resin,type);
    aplc_recip_res_q(res, &rtemp);
    break;
  case APLC_OCT:
    aplc_cktype2(&rtemp, APLC_OCT, resin,type);
    aplc_recip_res_o(res, &rtemp);
    break;
  }
  return;
}

extern void
aplc_exp_res(union res_struct * res,  
	     union res_struct * resin, int type)
{
  union res_struct rtemp;

  switch (type) {
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
    aplc_cktype2(res, APLC_REAL, resin,type);
    res->r = exp(res->r);
    break;
  case APLC_COMPLEX:
    aplc_cktype2(&rtemp, APLC_COMPLEX, resin,type);
    aplc_exp_res_z(res, &rtemp);
    break;
  case APLC_QUAT:
    aplc_cktype2(&rtemp, APLC_QUAT, resin,type);
    aplc_exp_res_q(res, &rtemp);
    break;
  case APLC_OCT:
    aplc_cktype2(&rtemp, APLC_OCT, resin,type);
    aplc_exp_res_o(res, &rtemp);
    break;
  }
  return;
}

extern void
aplc_nlog_res(union res_struct * res,  
	      union res_struct * resin, int type)
{
  union res_struct rtemp;

  switch (type) {
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
    aplc_cktype2(res, APLC_REAL, resin,type);
#if DCHECKS
    /* check for domain errors */
    if ( !(res->r >0) ) {
      printf("[aplc_nlog] log %g\n", res->r);
      aplc_error("log: domain error");
    }
#endif
    res->r = log(res->r);
    break;
  case APLC_COMPLEX:
    aplc_cktype2(&rtemp, APLC_COMPLEX, resin,type);
    aplc_ln_res_z(res, &rtemp);
    break;
  case APLC_QUAT:
    aplc_cktype2(&rtemp, APLC_QUAT, resin,type);
    aplc_ln_res_q(res, &rtemp);
    break;
  case APLC_OCT:
    aplc_cktype2(&rtemp, APLC_OCT, resin,type);
    aplc_ln_res_o(res, &rtemp);
    break;
  }
  return;
}

/* pi * */
extern void
aplc_pim_res(union res_struct * res,  
	     union res_struct * resin, int type)
{
  int i;

  switch (type) {
  case APLC_BOOL:
  case APLC_INT:
    res->r = PI * (double) resin->i;
    break;
  case APLC_REAL:
    res->r = PI * resin->r;
    break;
  case APLC_COMPLEX:
    res->z[0] = PI*resin->z[0];
    res->z[1] = PI*resin->z[1];
    break;
  case APLC_QUAT:
    res->q[0] = PI*resin->q[0];
    res->q[1] = PI*resin->q[1];
    res->q[2] = PI*resin->q[2];
    res->q[3] = PI*resin->q[3];
    break;
  case APLC_OCT:
    for (i=0; i<8; i++)
      res->o[i] = PI*resin->o[i];
    break;
  }
  return;
}

extern void
aplc_fact_res(union res_struct * res,  
	      union res_struct * resin, int type)
{
  switch (type) {
  case APLC_BOOL:
  case APLC_INT:
    if (resin->i < 0) {
      fprintf(aplcerr,"[aplc_msopv] domain error in !, argument (%d) < 0\n", 
	      resin->i);
      aplc_error("domain error in !, argument < 0");
    }
    else
      res->i = aplc_fact(resin->i);
    break;
  case APLC_REAL:
    res->r = aplc_gamma(1 + resin->r);
    break;
  default:
    aplc_error("[aplc_fact_res] illegal types for op");
  }

  return;
}



/* -------------------------------------------------------- */
/* dyadic */

extern void
aplc_min_res(union res_struct * res, union res_struct * lval, 
	     int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_CHAR:
    if (rnval.c < (res->c = lnval.c))
      res->c = rnval.c;
    break;
  case APLC_BOOL:
  case APLC_INT:
    if (rnval.i < (res->i = lnval.i))
      res->i = rnval.i;
    break;
  case APLC_REAL:
    if (rnval.r < (res->r = lnval.r))
      res->r = rnval.r;
    break;
  default:
    aplc_error("[aplc_min_res] illegal types for op");
  }
  return;
}

extern void
aplc_max_res(union res_struct * res, union res_struct * lval, 
	     int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;

  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_CHAR:
    if (rnval.c > (res->c = lnval.c))
      res->c = rnval.c;
    break;
  case APLC_BOOL:
  case APLC_INT:
    if (rnval.i > (res->i = lnval.i))
      res->i = rnval.i;
    break;
  case APLC_REAL:
    if (rnval.r > (res->r = lnval.r))
      res->r = rnval.r;
    break;
  default:
    aplc_error("[aplc_minus_res] illegal types for op");
  }
  return;
}


extern void
aplc_plus_res(union res_struct * res, union res_struct * lval, 
	      int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;
  int i;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_BOOL:
  case APLC_INT:
    res->i = lnval.i + rnval.i;
    break;
  case APLC_REAL:
    res->r = lnval.r + rnval.r;
    break;
  case APLC_COMPLEX:
    res->z[0] = lnval.z[0] + rnval.z[0];
    res->z[1] = lnval.z[1] + rnval.z[1];
    break;
  case APLC_QUAT:
    res->q[0] = lnval.q[0] + rnval.q[0];
    res->q[1] = lnval.q[1] + rnval.q[1];
    res->q[2] = lnval.q[2] + rnval.q[2];
    res->q[3] = lnval.q[3] + rnval.q[3];
    break;
  case APLC_OCT:
    for (i=0; i<8; i++)
      res->o[i] = lnval.o[i] + rnval.o[i];
    break;
  default:
    aplc_error("[aplc_plus_res] illegal types for op");
  }
  return;
}


extern void
aplc_minus_res(union res_struct * res, union res_struct * lval, 
	       int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;
  int i;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_BOOL:
  case APLC_INT:
    res->i = lnval.i - rnval.i;
    break;
  case APLC_REAL:
    res->r = lnval.r - rnval.r;
    break;
  case APLC_COMPLEX:
    res->z[0] = lnval.z[0] - rnval.z[0];
    res->z[1] = lnval.z[1] - rnval.z[1];
    break;
  case APLC_QUAT:
    res->q[0] = lnval.q[0] - rnval.q[0];
    res->q[1] = lnval.q[1] - rnval.q[1];
    res->q[2] = lnval.q[2] - rnval.q[2];
    res->q[3] = lnval.q[3] - rnval.q[3];
    break;
  case APLC_OCT:
    for (i=0; i<8; i++)
      res->o[i] = lnval.o[i] - rnval.o[i];
    break;
  default:
    aplc_error("[aplc_minus_res] illegal types for op");
  }
  return;
}

extern void
aplc_times_res(union res_struct * res, union res_struct * lval, 
	       int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_BOOL:
  case APLC_INT:
    res->i = lnval.i * rnval.i;
    break;
  case APLC_REAL:
    res->r = lnval.r * rnval.r;
    break;
  case APLC_COMPLEX:
    aplc_times_res_z(res, &lnval, &rnval);
    break;
  case APLC_QUAT:
    aplc_times_res_q(res, &lnval, &rnval);
    break;
  case APLC_OCT:
    aplc_times_res_o(res, &lnval, &rnval);
    break;
  default:
    aplc_error("[aplc_times_res] illegal types for op");
  }
  return;
}

extern void
aplc_residue_res(union res_struct * res, union res_struct * lval, 
		 int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;
  double temp;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_BOOL:
  case APLC_INT:
    if (lnval.i != 0)
      res->i = rnval.i - lnval.i *
	floor(((double) rnval.i) / ((double) lnval.i));
    else
      res->i = rnval.i;
    break;
  case APLC_REAL:
    if (lnval.r != 0.0) {
      /*res->r = rnval.r - lnval.r * floor(rnval.r / lnval.r);*/
      if (aplc_isnearintd( rnval.r/lnval.r , &temp))
	res->r = 0.0;
      else 
	res->r = rnval.r - lnval.r * temp;
    } else
      res->r = rnval.r;
    break;
  default:
    aplc_error("[aplc_residue_res] type error for mod function");
  }

  return;
}

extern void
aplc_divide_res(union res_struct * res, union res_struct * lval, 
		int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;
  switch (maxtype) {
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
    aplc_cktype2(&lnval, APLC_REAL, lval, ltype);
    aplc_cktype2(&rnval, APLC_REAL, rval, rtype);
#if DCHECKS
    /* check for domain errors */
    if ( rnval.r == 0.0 ) {
      printf("[aplc_divde_res] %g %% %g\n", lnval.r, rnval.r);
      aplc_error("%%: domain error");
    }
#endif
#ifdef WEB_MOD
    if ( (rnval.r ==0.0) && (lnval.r==0.0) ) {
      res->r = 1.0 ;   /*  0%0 special case is useful  jbww 96_10 */
    } else   
      res->r = lnval.r / rnval.r;
#else
    res->r = lnval.r / rnval.r;
#endif
    break;
  case APLC_COMPLEX:
    aplc_cktype2(&lnval, APLC_COMPLEX, lval, ltype);
    aplc_cktype2(&rnval, APLC_COMPLEX, rval, rtype);
#if 0 
    printf("[aplc_divide] %gi%g %% %gi%g\n", 
	   lnval.z[0],lnval.z[1], 
	   rnval.z[0],rnval.z[1]);
#endif
    aplc_divide_res_z(res, &lnval, &rnval);
    break;
  case APLC_QUAT:
    aplc_cktype2(&lnval, APLC_QUAT, lval, ltype);
    aplc_cktype2(&rnval, APLC_QUAT, rval, rtype);
    aplc_divide_res_q(res, &lnval, &rnval);
    break;
  case APLC_OCT:
    aplc_cktype2(&lnval, APLC_OCT, lval, ltype);
    aplc_cktype2(&rnval, APLC_OCT, rval, rtype);
    aplc_divide_res_o(res, &lnval, &rnval);
    break;
  default:
    aplc_error("[aplc_divide_res] illegal types for op");
  }
  return;
}

extern void
aplc_power_res(union res_struct * res, union res_struct * lval, 
	       int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;
  union res_struct logl, rtemp;
  double mag;
  int i;

  maxtype = (ltype > rtype) ? ltype : rtype;
  switch (maxtype) {
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
    aplc_cktype2(&lnval, APLC_REAL, lval, ltype);
    aplc_cktype2(&rnval, APLC_REAL, rval, rtype);
    res->r = pow(lnval.r, rnval.r);
    break;
  case APLC_COMPLEX:
    aplc_cktype2(&lnval, APLC_COMPLEX, lval, ltype);
    aplc_cktype2(&rnval, APLC_COMPLEX, rval, rtype);
    /* exp(r ln(a)) */
    mag = NORM_resz(lnval);
    if (1.0 == 1.0 + mag) {
      /* 0^x = 0 */
      res->z[0] = 0.0;
      res->z[1] = 0.0;
      break;
    }
    aplc_ln_res_z(&logl, &lnval);
    aplc_times_res_z(&rtemp, &logl, &rnval);
    aplc_exp_res_z(res, &rtemp);
    break;
  case APLC_QUAT:
    aplc_cktype2(&lnval, APLC_QUAT, lval, ltype);
    aplc_cktype2(&rnval, APLC_QUAT, rval, rtype);
    /* exp(r ln(a)) */
    mag = NORM_resq(lnval);
    if (1.0 == 1.0 + mag) {
      /* 0^x = 0 */
      res->q[0] = 0.0;
      res->q[1] = 0.0;
      res->q[2] = 0.0;
      res->q[3] = 0.0;
      break;
    }
    aplc_ln_res_q(&logl, &lnval);
    aplc_times_res_q(&rtemp, &logl, &rnval);
    aplc_exp_res_q(res, &rtemp);
    break;
  case APLC_OCT:
    aplc_cktype2(&lnval, APLC_OCT, lval, ltype);
    aplc_cktype2(&rnval, APLC_OCT, rval, rtype);
    /* exp(r ln(a)) */
    mag = NORM_reso(lnval);
    if (1.0 == 1.0 + mag) {
      /* 0^x = 0 */
      for (i=0; i<8; i++)
	res->o[i] = 0.0;
      break;
    }
    aplc_ln_res_o(&logl, &lnval);
    aplc_times_res_o(&rtemp, &logl, &rnval);
    aplc_exp_res_o(res, &rtemp);
    break;
  }
  return;
}

extern void
aplc_log_res(union res_struct * res, union res_struct * lval, 
	     int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;
  union res_struct rt1, rt2, rt3;
  double mag;

  maxtype = (ltype > rtype) ? ltype : rtype;
  switch (maxtype) {
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
    aplc_cktype2(&lnval, APLC_REAL, lval, ltype);
    aplc_cktype2(&rnval, APLC_REAL, rval, rtype);
#if DCHECKS
    /* check for domain errors */
    if ( ! (rnval.r >0) && (lnval.r>0) ) {
      printf("[aplc_log_res] %g log %g\n", lnval.r, rnval.r);
      aplc_error("log: domain error");
    }
#endif
    res->r = log(rnval.r) / log(lnval.r);
    break;
  case APLC_COMPLEX:
    aplc_cktype2(&lnval, APLC_COMPLEX, lval, ltype);
    aplc_cktype2(&rnval, APLC_COMPLEX, rval, rtype);
    aplc_ln_res_z(&rt1, &lnval); 
    aplc_ln_res_z(&rt2, &rnval); 
#if DCHECKS
    /* check for domain errors */
    mag = NORM2_resz(rt1);
    if (1.0 == 1.0 + mag) {
      aplc_error("log: domain error");
    }
#endif
    aplc_divide_res_z(res,  &rt2, &rt1);
    break;
  case APLC_QUAT:
    aplc_cktype2(&lnval, APLC_QUAT, lval, ltype);
    aplc_cktype2(&rnval, APLC_QUAT, rval, rtype);
    aplc_ln_res_q(&rt1, &lnval); 
    aplc_ln_res_q(&rt2, &rnval); 
#if DCHECKS
    /* check for domain errors */
    mag = NORM2_resq(rt1);
    if (1.0 == 1.0 + mag) {
      aplc_error("log: domain error");
    }
#endif
    /*aplc_divide_res_z(res,  &rt2, &rt1);*/
    /* 1/rt1 * rt2 */
    aplc_recip_res_q(&rt3, &rt1);
    aplc_times_res_q(res, &rt3, &rt2);
    break;
  case APLC_OCT:
    aplc_cktype2(&lnval, APLC_OCT, lval, ltype);
    aplc_cktype2(&rnval, APLC_OCT, rval, rtype);
    aplc_ln_res_o(&rt1, &lnval); 
    aplc_ln_res_o(&rt2, &rnval); 
#if DCHECKS
    /* check for domain errors */
    mag = NORM2_reso(rt1);
    if (1.0 == 1.0 + mag) {
      aplc_error("log: domain error");
    }
#endif
    /* 1/rt1 * rt2 */
    aplc_recip_res_o(&rt3, &rt1);
    aplc_times_res_o(res, &rt3, &rt2);
    break;
  }
  return;
}

extern void
aplc_circle_res(union res_struct * res, union res_struct * lval, 
		int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;
  union res_struct rt1, rt2, rt3;
  int i;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, APLC_INT, lval, ltype);
  switch (maxtype) {
    /* --------------------------------------------- */
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
    aplc_cktype2(&rnval, APLC_REAL, rval, rtype);
    switch (lval->i) {
    default:
      fprintf(aplcerr,"(%d circle)\n", lval->i);
      aplc_error("[aplc_circle_res] illegal circular function");
      break;
    case -7:
      if ((rnval.r < 1.0) & (rnval.r > -1.0))
	res->r = atanh(rnval.r);
      else {
	fprintf(aplcerr,"(%d circle %g)\n", lval->i, res->r);
	aplc_error("[aplc_circle_res] domain error");
      }
      break;
    case -6:
      res->r = acosh(rnval.r);
      break;
    case -5:
      res->r = asinh(rnval.r);
      break;
    case -4:
      res->r = sqrt((-1) + rnval.r * rnval.r);
      break;
    case -3:
      res->r = atan(rnval.r);
      break;
    case -2:
      res->r = acos(rnval.r);
      break;
    case -1:
      res->r = asin(rnval.r);
      break;
    case 0:
      res->r = sqrt(1 - rnval.r * rnval.r);
      break;
    case 1:
      res->r = sin(rnval.r);
      break;
    case 2:
      res->r = cos(rnval.r);
      break;
    case 3:
#if DCHECKS
      /* check for domain errors */
      if ( 1.0 == 1.0 + cos(rnval.r) ) {
	printf("tan %g\n", rnval.r); 
	aplc_error("tan: domain error");
      }
#endif
      /* res->r = sin(rnval.r) / cos(rnval.r);*/
      res->r = tan(rnval.r);
      break;
    case 4:
      res->r = sqrt(1 + rnval.r * rnval.r);
      break;
    case 5:
      res->r = sinh(rnval.r);
      break;
    case 6:
      res->r = cosh(rnval.r);
      break;
    case 7:
      res->r = tanh(rnval.r);
      break;
    }
    break;
    /* --------------------------------------------- */
  case APLC_COMPLEX:
    aplc_cktype2(&rnval, APLC_COMPLEX, rval, rtype);
    switch (lval->i) {
    default:
      aplc_error("[aplc_circle_res] illegal circular function");
      break;
    case -12:
      /* exp( i*r ) */
      rt1.z[0] = -rnval.z[1];
      rt1.z[1] =  rnval.z[0];
      aplc_exp_res_z(res, &rt1);
      break;
    case -11:
      /*  i*r */
      res->z[0] = -rnval.z[1];
      res->z[1] =  rnval.z[0];
      break;
    case -10:
      /* +r */
      res->z[0] =  rnval.z[0];
      res->z[1] = -rnval.z[1];
      break;
    case -9:
      /* r */
      res->z[0] = rnval.z[0];
      res->z[1] = rnval.z[1];
      break;
    case -8:
      /* - sqrt( _1 - r^2 ) */
      aplc_square_res_z(&rt1, &rnval);
      rt1.z[0] = -1.0 - rt1.z[0];
      rt1.z[1] = -rt1.z[1];
      aplc_sqrt_res_z(res, &rt1);
      res->z[0] = -res->z[0];
      res->z[1] = -res->z[1];
      break;
    case -7:
      /* arctanh */ 
      /* 0.5*( log(1+a) - log(1-a) ) */
      rt1.z[0] = 1.0 + rnval.z[0];
      rt1.z[1] =  rnval.z[1];
      if (1.0 == 1.0 + NORM_resz(rt1) ) {
	zprint("z", &rnval); 
	zprint("num", &rt1); 
	aplc_error("[aplc_circle_res] atanh domain error");
      }
      aplc_ln_res_z(res, &rt1);
      rt2.z[0] = 1.0 - rnval.z[0];
      rt2.z[1] =  - rnval.z[1];
      if (1.0 == 1.0 + NORM_resz(rt2) ) {
	zprint("z", &rnval); 
	zprint("den", &rt2); 
	aplc_error("[aplc_circle_res] atanh domain error");
      }
      aplc_ln_res_z(&rt3, &rt2);
      res->z[0] = 0.5*(res->z[0] - rt3.z[0]);
      res->z[1] = 0.5*(res->z[1] - rt3.z[1]);
#if 0
      /* v = sqrt(1+a)/sqrt(1-a) = sqrt( (1+a)/(1-a) ) */
      /* v = sqrt( (1+a)/(1-a) ) */
      rt2.z[0] = 1.0 - rnval.z[0];
      rt2.z[1] =  - rnval.z[1];
      if (1.0 == 1.0 + NORM_resz(rt2) ) {
	zprint("z", &rnval); 
	zprint("den", &rt2); 
	aplc_error("[aplc_circle_res] atanh domain error");
      }
      rt1.z[0] = 1.0 + rnval.z[0];
      rt1.z[1] = rnval.z[1];
      aplc_divide_res_z(&rt3, &rt1, &rt2);
      aplc_sqrt_res_z(&rt1, &rt3);
      /* z = ln(v) */
      aplc_ln_res_z(res, &rt1);
#endif
      break;
    case -6:
      /* arcosh */ 
      /* = 2*log( sqrt( (z+1)/2 ) + sqrt( (z11)/2 ) ) */

      /* v = a + sqrt(a^2 - 1) */
      aplc_square_res_z(&rt1, &rnval);
      rt1.z[0] = rt1.z[0] - 1.0;
      rt1.z[1] = rt1.z[1];
      aplc_sqrt_res_z(&rt2, &rt1);
      rt2.z[0] += rnval.z[0];
      rt2.z[1] += rnval.z[1];
      /* z = ln(v) */
      aplc_ln_res_z(res, &rt2);
      /* make sure real part is >= 0 */
      if (0.0 > res->z[0]) {
	res->z[0] = - res->z[0];
	res->z[1] = - res->z[1];
      } 
      if (1.0 == 1.0 + res->z[0]) {
	res->z[0] = 0.0;
	res->z[1] = fabs(res->z[1]);
      }
      break;
    case -5:
      /* arcsinh */ 
      /* v = a + sqrt(1 + a^2) */
      aplc_square_res_z(&rt1, &rnval);
      rt1.z[0] = 1.0 + rt1.z[0];
      rt1.z[1] = rt1.z[1];
      aplc_sqrt_res_z(&rt2, &rt1);
      rt2.z[0] += rnval.z[0];
      rt2.z[1] += rnval.z[1];
      /* z = ln(v) */
      aplc_ln_res_z(res, &rt2);
      break;
    case -4:
      /* sqrt(-1+r^2)
       (1+r)*sqrt( (r-1)/r+1)) */ 
#if 0
      aplc_square_res_z(&rt1, &rnval);
      rt1.z[0] = -1.0 + rt1.z[0];
      aplc_sqrt_res_z(res, &rt1);
#endif
      rt2.z[0] = rnval.z[0] + 1.0;
      rt2.z[1] = rnval.z[1];
      if (1.0 == 1.0 + NORM_resz(rt2)) {
	res->z[0] = 0.0;
	res->z[1] = 0.0;
	return;
      }
      rt1.z[0] = rnval.z[0] - 1.0;
      rt1.z[1] = rnval.z[1];
      aplc_divide_res_z(&rt3, &rt1, &rt2);
      aplc_sqrt_res_z(&rt1, &rt3);
      aplc_times_res_z(res, &rt2, &rt1);
      break;
    case -3:
      /* arctan */ 
      /* v = sqrt(1 + i*a)/sqrt(1 - i*a) */
      /* v = sqrt( (1 + i*a)/(1 - i*a) ) */
      rt1.z[0] = 1.0 - rnval.z[1];
      rt1.z[1] = rnval.z[0];
      rt2.z[0] = 1.0 + rnval.z[1];
      rt2.z[1] =  - rnval.z[0];
      if (1.0 == 1.0 + NORM_resz(rt2) ) {
	aplc_error("[aplc_circle_res] atan domain error");
      }
      aplc_divide_res_z(&rt3, &rt1, &rt2);
      aplc_sqrt_res_z(&rt2, &rt3);
      /* z = -i* ln(v) */
      aplc_ln_res_z(&rt1, &rt2);
      res->z[0] =  rt1.z[1];
      res->z[1] = -rt1.z[0];
      break;
    case -2:
      /* arcos */ 
      /* v = a + sqrt(a^2 - 1) */
      aplc_square_res_z(&rt1, &rnval);
      rt1.z[0] = rt1.z[0] - 1.0;
      rt1.z[1] = rt1.z[1];
      aplc_sqrt_res_z(&rt2, &rt1);
      rt2.z[0] += rnval.z[0];
      rt2.z[1] += rnval.z[1];
      /* z = -i* ln(v) */
      aplc_ln_res_z(&rt1, &rt2);
      res->z[0] =  rt1.z[1];
      res->z[1] = -rt1.z[0];
      /* make sure real part is >= 0 */
      if (res->z[0] < 0.0) {
	res->z[0] = -res->z[0];
	res->z[1] = -res->z[1];
      }	
      if (1.0 == 1.0 + res->z[0]) {
	res->z[0] = 0.0;
	res->z[1] = fabs(res->z[1]);
      }
      break;
    case -1:
      /* arcsin */ 
      /* v = i*a + sqrt(1 - a^2) */
      aplc_square_res_z(&rt1, &rnval);
      rt1.z[0] = 1.0 - rt1.z[0];
      rt1.z[1] = - rt1.z[1];
      aplc_sqrt_res_z(&rt2, &rt1);
      rt2.z[0] -= rnval.z[1];
      rt2.z[1] += rnval.z[0];
      /* z = -i* ln(v) */
      aplc_ln_res_z(&rt1, &rt2);
      res->z[0] =  rt1.z[1];
      res->z[1] = -rt1.z[0];
      break;
    case 0:
      /* sqrt(1 - r^2) */ 
      aplc_square_res_z(&rt1, &rnval);
      rt1.z[0] = 1.0 - rt1.z[0];
      rt1.z[1] = -rt1.z[1];
      aplc_sqrt_res_z(res, &rt1);
      break;
    case 1:
      /* sin */
      res->z[0] = sin(rnval.z[0])*cosh(rnval.z[1]);
      res->z[1] = cos(rnval.z[0])*sinh(rnval.z[1]);
      break;
    case 2:
      /* cos */
      res->z[0] =  cos(rnval.z[0])*cosh(rnval.z[1]);
      res->z[1] = -sin(rnval.z[0])*sinh(rnval.z[1]);
      break;
    case 3:
      /* tan */ 
      /* cos */
      rt2.z[0] =  cos(rnval.z[0])*cosh(rnval.z[1]);
      rt2.z[1] = -sin(rnval.z[0])*sinh(rnval.z[1]);
#if DCHECKS
      /* check for domain errors */
      if ( 1.0 == 1.0 + NORM_resz(rt2) ) {
	zprint("tan", &rnval); 
	zprint("cos", &rt2); 
	aplc_error("tan: domain error");
      }
#endif
      /* sin */
      rt1.z[0] = sin(rnval.z[0])*cosh(rnval.z[1]);
      rt1.z[1] = cos(rnval.z[0])*sinh(rnval.z[1]);
      /* divide */
      aplc_divide_res_z(res, &rt1, &rt2);
      break;
    case 4:
      /* sqrt(1+r^2) */ 
      aplc_square_res_z(&rt1, &rnval);
      rt1.z[0] = 1.0 + rt1.z[0];
      aplc_sqrt_res_z(res, &rt1);
      break;
    case 5:
      /* sinh */ 
      res->z[0] = sinh(rnval.z[0])*cos(rnval.z[1]);
      res->z[1] = cosh(rnval.z[0])*sin(rnval.z[1]);
      break;
    case 6:
      /* cosh */
      res->z[0] = cosh(rnval.z[0])*cos(rnval.z[1]);
      res->z[1] = sinh(rnval.z[0])*sin(rnval.z[1]);
      break;
    case 7:
      /* tanh */ 
      /* get cosh */
      rt2.z[0] = cosh(rnval.z[0])*cos(rnval.z[1]);
      rt2.z[1] = sinh(rnval.z[0])*sin(rnval.z[1]);
#if DCHECKS
      /* check for domain errors */
      if ( 1.0 == 1.0 + NORM_resz(rt2) ) {
	zprint("tanh", &rnval); 
	zprint("cosh", &rt2); 
	aplc_error("tanh: domain error");
      }
#endif
      /* get sinh */
      rt1.z[0] = sinh(rnval.z[0])*cos(rnval.z[1]);
      rt1.z[1] = cosh(rnval.z[0])*sin(rnval.z[1]);
      /* divide */
      aplc_divide_res_z(res, &rt1, &rt2);
      break;
    case 8:
      /* sqrt( _1 - r^2 ) */
      aplc_square_res_z(&rt1, &rnval);
      rt1.z[0] = -1.0 - rt1.z[0];
      rt1.z[1] = -rt1.z[1];
      aplc_sqrt_res_z(res, &rt1);
      break;
    case 9:
      /* real( r ) */
      res->z[0] = rnval.z[0];
      res->z[1] = 0.0;
      break;
    case 10:
      /* |r */
      res->z[0] = NORM_resz(rnval);
      res->z[1] = 0.0;
      break;
    case 11:
      /* imag( r ) */
      res->z[0] = rnval.z[1];
      res->z[1] = 0.0;
      break;
    case 12:
      /* arc( r ) */
      res->z[0] = zangle(&rnval);
      res->z[1] = 0.0;
#if 0
      zprint("rnval", &rnval);
      zprint("res", res);
      printf("y<0 %d\n", rnval.z[1]<0);
      printf("y>0 %d\n", rnval.z[1]>0);
      printf("atan2(%g, %g) = %g\n", rnval.z[1],rnval.z[0], 
	     atan2(rnval.z[1], rnval.z[0]));
      printf("atan2(-%g, %g) = %g\n", rnval.z[1],rnval.z[0], 
	     atan2(-rnval.z[1], rnval.z[0]));
#endif
      break;
    }
    break;
    /* --------------------------------------------- */
  case APLC_QUAT:
    aplc_cktype2(&rnval, APLC_QUAT, rval, rtype);
    /* aplc_error("circle: domain error");*/
    switch (lval->i) {
    default:
      aplc_error("[aplc_circle_res] illegal circular function");
      break;
    case -12:
      /* exp( r ) */
      aplc_exp_res_q(res, &rnval);
#if 0
      /* exp( i*r ) */
      aplc_Iq(&rt1, &rnval);
      aplc_exp_res_q(res, &rt1);
#endif
      break;
    case -11:
      /* r */
      aplc_equate_q(res, &rnval);
#if 0
      /*  i*r */
      aplc_Iq(res, &rnval);
#endif
      break;
    case -10:
      /* +r */
      aplc_conj_q(res, &rnval);
      break;
    case -9:
      /* r */
      aplc_equate_q(res, &rnval);
      break;
    case -8:
      /* - sqrt( _1 - r^2 ) */
      aplc_square_res_q(&rt1, &rnval);
      rt1.q[0] = -1.0 - rt1.q[0];
      rt1.q[1] = -rt1.q[1];
      rt1.q[2] = -rt1.q[2];
      rt1.q[3] = -rt1.q[3];
      aplc_sqrt_res_q(res, &rt1);
      aplc_negate_q(res, res);
      break;
    case -7:
      /* arctanh */ 
      /* 0.5*( log(1+a) - log(1-a) ) */
      aplc_equate_q(&rt1, &rnval);
      rt1.q[0] += 1.0;
      /*qprint("rt1", &rt1); */
      if (1.0 == 1.0 + NORM_resq(rt1) ) {
	qprint("q", &rnval); 
	qprint("num", &rt1); 
	aplc_error("[aplc_circle_res] atanh domain error");
      }
      aplc_ln_res_q(res, &rt1);
      /* qprint("ln rt1", res); */
      aplc_negate_q(&rt2, &rnval);
      rt2.q[0] += 1.0;
      /*qprint("rt2", &rt2); */
      if (1.0 == 1.0 + NORM_resq(rt2) ) {
	qprint("q", &rnval); 
	qprint("den", &rt2); 
	aplc_error("[aplc_circle_res] atanh domain error");
      }
      aplc_ln_res_q(&rt3, &rt2);
      /*qprint("ln rt2", &rt3); */
      aplc_sub_res_q(&rt1, res, &rt3);
      /*qprint("ln(rt1) - ln(rt2)", &rt1); */
      aplc_q_times_r(res, &rt1, 0.5);
#if 0
      /* v = sqrt(1+a)/sqrt(1-a) */
      aplc_negate_q(&rt2, &rnval);
      rt2.q[0] += 1.0; 
      if (1.0 == 1.0 + NORM_resq(rt2) ) {
	qprint("q", &rnval); 
	qprint("den", &rt2); 
	aplc_error("[aplc_circle_res] atanh domain error");
      }
      aplc_equate_q(&rt1, &rnval);
      rt1.q[0] += 1.0;
      aplc_divide_res_q(&rt3, &rt1, &rt2);
      aplc_sqrt_res_q(&rt1, &rt3);
      /* z = ln(v) */
      aplc_ln_res_q(res, &rt1);
#endif
      break;
    case -6:
      /* arcosh */ 
      /* v = a + sqrt(a^2 - 1) */
      aplc_square_res_q(&rt1, &rnval);
      rt1.q[0] = rt1.q[0] - 1.0;
      aplc_sqrt_res_q(&rt2, &rt1);
      aplc_add_res_q(&rt2, &rt2, &rnval);
      /* z = ln(v) */
      aplc_ln_res_q(res, &rt2);
      /* make sure real part is >= 0 */
      if (0.0 > res->q[0]) {
	aplc_negate_q(res, res);
      } 
      if (1.0 == 1.0 + res->q[0]) {
	res->q[0] = 0.0;
	/* res->z[1] = fabs(res->z[1]);*/
      }
      break;
    case -5:
      /* arcsinh */ 
      /* v = a + sqrt(1 + a^2) */
      aplc_square_res_q(&rt1, &rnval);
      rt1.q[0] += 1.0;
      aplc_sqrt_res_q(&rt2, &rt1);
      aplc_add_res_q(&rt2, &rt2, &rnval);
      /* z = ln(v) */
      aplc_ln_res_q(res, &rt2);
      break;
    case -4:
      /* sqrt(-1+r^2)
	 (1+r)*sqrt( (r-1)/r+1)) */ 
#if 0
      aplc_square_res_q(&rt1, &rnval);
      rt1.q[0] = -1.0 + rt1.q[0];
      aplc_sqrt_res_q(res, &rt1);
#endif
      aplc_equate_q(&rt2, &rnval);
      rt2.q[0] = rnval.q[0] + 1.0;
      if (1.0 == 1.0 + NORM_resq(rt2)) {
	aplc_zero_q(res);
	return;
      }
      aplc_equate_q(&rt1, &rnval);
      rt1.q[0] = rnval.q[0] - 1.0;
      aplc_divide_res_q(&rt3, &rt1, &rt2);
      aplc_sqrt_res_q(&rt1, &rt3);
      aplc_times_res_q(res, &rt2, &rt1);
      break;
    case -3:
      /* arctan */ 
      /* v = sqrt(1 + I*a)/sqrt(1 - I*a)
	  = sqrt( (1 + I*a)/(1 - I*a) ) */
      aplc_Isq(&rt2, &rnval, -1.0);
      rt2.q[0] += 1.0;
      if (1.0 == 1.0 + NORM_resq(rt2) ) {
	aplc_error("[aplc_circle_res] atan domain error");
      }
      aplc_Isq(&rt1, &rnval, 1.0);
      rt1.q[0] += 1.0;
      aplc_divide_res_q(&rt3, &rt1, &rt2);
      aplc_sqrt_res_q(&rt2, &rt3);
      /* z = -I* ln(v) */
      aplc_ln_res_q(&rt1, &rt2);
      aplc_Isq(res, &rt1, -1.0);
      break;
    case -2:
      /* arcos */ 
      /* v = a + sqrt(a^2 - 1) */
      aplc_square_res_q(&rt1, &rnval);
      rt1.q[0] -= 1.0;
      aplc_sqrt_res_q(&rt2, &rt1);
      aplc_add_res_q(&rt2, &rt2, &rnval);
      /* z = -I* ln(v) */
      aplc_ln_res_q(&rt1, &rt2);
      aplc_Isq(res, &rt1, -1.0);
      /* make sure real part is >= 0 */
      if (res->q[0] < 0.0) {
	aplc_negate_q(res, res);
      }	
      if (1.0 == 1.0 + res->q[0]) {
	res->q[0] = 0.0;
	/* res->z[1] = fabs(res->z[1]);*/
      }
      break;
    case -1:
      /* arcsin */ 
      /* v = I*a + sqrt(1 - a^2) */
      aplc_square_res_q(&rt1, &rnval);
      aplc_negate_q(&rt2, &rt1);
      rt2.q[0] += 1.0;
      aplc_sqrt_res_q(&rt1, &rt2);
      aplc_Iq(&rt2, &rnval);
      aplc_add_res_q(&rt3, &rt2, &rt1);
      /* z = -I* ln(v) */
      aplc_ln_res_q(&rt1, &rt3);
      aplc_Isq( res, &rt1, -1.0);
      break;
    case 0:
      /* sqrt(1 - r^2) */ 
      aplc_square_res_q(&rt1, &rnval);
      rt1.q[0] = 1.0 - rt1.q[0];
      rt1.q[1] = -rt1.q[1];
      rt1.q[2] = -rt1.q[2];
      rt1.q[3] = -rt1.q[3];
      aplc_sqrt_res_q(res, &rt1);
      break;
    case 1:
      /* sin */
      aplc_sin_res_q(res, &rnval);
      break;
    case 2:
      /* cos */
      aplc_cos_res_q(res, &rnval);
      break;
    case 3:
      /* tan */ 
      aplc_tan_res_q(res, &rnval);
      break;
    case 4:
      /* sqrt(1+r^2) */ 
      aplc_square_res_q(&rt1, &rnval);
      rt1.q[0] = 1.0 + rt1.q[0];
      aplc_sqrt_res_q(res, &rt1);
      break;
    case 5:
      /* sinh */ 
      aplc_sinh_res_q(res, &rnval);
      break;
    case 6:
      /* cosh */
      aplc_cosh_res_q(res, &rnval);
      break;
    case 7:
      /* tanh */ 
      aplc_tanh_res_q(res, &rnval);
      break;
    case 8:
      /* sqrt( _1 - r^2 ) */
      aplc_square_res_q(&rt1, &rnval);
      rt1.q[0] = -1.0 - rt1.q[0];
      rt1.q[1] = -rt1.q[1];
      rt1.q[2] = -rt1.q[2];
      rt1.q[3] = -rt1.q[3];
      aplc_sqrt_res_q(res, &rt1);
      break;
    case 9:
      /* real( r ) */
      res->q[0] = rnval.q[0];
      res->q[1] = 0.0;
      res->q[2] = 0.0;
      res->q[3] = 0.0;
      break;
    case 10:
      /* |r */
      res->q[0] = NORM_resq(rnval);
      res->q[1] = 0.0;
      res->q[2] = 0.0;
      res->q[3] = 0.0;
      break;
    case 11:
      /* imag( r ) */
      res->q[0] = 0.0;
      res->q[1] = rnval.q[1];
      res->q[2] = rnval.q[2];
      res->q[3] = rnval.q[3];
      break;
    case 12:
      /* arc( r ) */
      /* return complex number x such that q = ^x */
      aplc_ln_res_q(res, &rnval);
      res->q[0] = 0.0;/* zero out magnitude part */
#if 0
      res->q[0] = qangle(&rnval);
      res->q[1] = 0.0;
      res->q[2] = 0.0;
      res->q[3] = 0.0;
#endif
      break;
    }
    break;

    /* --------------------------------------------- */
  case APLC_OCT:
    aplc_cktype2(&rnval, APLC_OCT, rval, rtype);
    /* aplc_error("circle: domain error");*/
    switch (lval->i) {
    default:
      aplc_error("[aplc_circle_res] illegal circular function");
      break;
    case -12:
      /* exp( r ) */
      aplc_exp_res_o(res, &rnval);
#if 0
      /* exp( i*r ) */
      aplc_Io(&rt1, &rnval);
      aplc_exp_res_o(res, &rt1);
#endif
      break;
    case -11:
      /* r */
      aplc_equate_o(res, &rnval);
#if 0
      /*  i*r */
      aplc_Io(res, &rnval);
#endif
      break;
    case -10:
      /* +r */
      aplc_conj_o(res, &rnval);
      break;
    case -9:
      /* r */
      aplc_equate_o(res, &rnval);
      break;
    case -8:
      /* - sqrt( _1 - r^2 ) */
      aplc_square_res_o(&rt1, &rnval);
      rt1.o[0] = -1.0 - rt1.o[0];
      for (i=1; i<8; i++)
	rt1.o[i] = -rt1.o[i];
      aplc_sqrt_res_o(res, &rt1);
      aplc_negate_o(res, res);
      break;
    case -7:
      /* arctanh */ 
      /* 0.5*( log(1+a) - log(1-a) ) */
      aplc_equate_o(&rt1, &rnval);
      rt1.o[0] += 1.0;
      /*oprint("rt1", &rt1); */
      if (1.0 == 1.0 + NORM_reso(rt1) ) {
	oprint("o", &rnval); 
	oprint("num", &rt1); 
	aplc_error("[aplc_circle_res] atanh domain error");
      }
      aplc_ln_res_o(res, &rt1);
      /* qprint("ln rt1", res); */
      aplc_negate_o(&rt2, &rnval);
      rt2.o[0] += 1.0;
      /*oprint("rt2", &rt2); */
      if (1.0 == 1.0 + NORM_reso(rt2) ) {
	oprint("o", &rnval); 
	oprint("den", &rt2); 
	aplc_error("[aplc_circle_res] atanh domain error");
      }
      aplc_ln_res_o(&rt3, &rt2);
      /*qprint("ln rt2", &rt3); */
      aplc_sub_res_o(&rt1, res, &rt3);
      /*qprint("ln(rt1) - ln(rt2)", &rt1); */
      aplc_o_times_r(res, &rt1, 0.5);
#if 0
      /* v = sqrt(1+a)/sqrt(1-a) */
      aplc_negate_o(&rt2, &rnval);
      rt2.o[0] += 1.0; 
      if (1.0 == 1.0 + NORM_reso(rt2) ) {
	oprint("o", &rnval); 
	oprint("den", &rt2); 
	aplc_error("[aplc_circle_res] atanh domain error");
      }
      aplc_equate_o(&rt1, &rnval);
      rt1.o[0] += 1.0;
      aplc_divide_res_o(&rt3, &rt1, &rt2);
      aplc_sqrt_res_o(&rt1, &rt3);
      /* z = ln(v) */
      aplc_ln_res_o(res, &rt1);
#endif
      break;
    case -6:
      /* arcosh */ 
      /* v = a + sqrt(a^2 - 1) */
      aplc_square_res_o(&rt1, &rnval);
      rt1.o[0] = rt1.o[0] - 1.0;
      aplc_sqrt_res_o(&rt2, &rt1);
      aplc_add_res_o(&rt2, &rt2, &rnval);
      /* z = ln(v) */
      aplc_ln_res_o(res, &rt2);
      /* make sure real part is >= 0 */
      if (0.0 > res->o[0]) {
	aplc_negate_o(res, res);
      } 
      if (1.0 == 1.0 + res->o[0]) {
	res->o[0] = 0.0;
      }
      break;
    case -5:
      /* arcsinh */ 
      /* v = a + sqrt(1 + a^2) */
      aplc_square_res_o(&rt1, &rnval);
      rt1.o[0] += 1.0;
      aplc_sqrt_res_o(&rt2, &rt1);
      aplc_add_res_o(&rt2, &rt2, &rnval);
      /* z = ln(v) */
      aplc_ln_res_o(res, &rt2);
      break;
    case -4:
      /* sqrt(-1+r^2)
	 (1+r)*sqrt( (r-1)/r+1)) */ 
      aplc_equate_o(&rt2, &rnval);
      rt2.o[0] = rnval.o[0] + 1.0;
      if (1.0 == 1.0 + NORM_reso(rt2)) {
	aplc_zero_o(res);
	return;
      }
      aplc_equate_o(&rt1, &rnval);
      rt1.o[0] = rnval.o[0] - 1.0;
      aplc_divide_res_o(&rt3, &rt1, &rt2);
      aplc_sqrt_res_o(&rt1, &rt3);
      aplc_times_res_o(res, &rt2, &rt1);
      break;
    case -3:
      /* arctan */ 
      /* v = sqrt(1 + I*a)/sqrt(1 - I*a)
	  = sqrt( (1 + I*a)/(1 - I*a) ) */
      aplc_Iso(&rt2, &rnval, -1.0);
      rt2.o[0] += 1.0;
      if (1.0 == 1.0 + NORM_reso(rt2) ) {
	aplc_error("[aplc_circle_res] atan domain error");
      }
      aplc_Iso(&rt1, &rnval, 1.0);
      rt1.o[0] += 1.0;
      aplc_divide_res_o(&rt3, &rt1, &rt2);
      aplc_sqrt_res_o(&rt2, &rt3);
      /* z = -I* ln(v) */
      aplc_ln_res_o(&rt1, &rt2);
      aplc_Iso(res, &rt1, -1.0);
      break;
    case -2:
      /* arcos */ 
      /* v = a + sqrt(a^2 - 1) */
      aplc_square_res_o(&rt1, &rnval);
      rt1.o[0] -= 1.0;
      aplc_sqrt_res_o(&rt2, &rt1);
      aplc_add_res_o(&rt2, &rt2, &rnval);
      /* z = -I* ln(v) */
      aplc_ln_res_o(&rt1, &rt2);
      aplc_Iso(res, &rt1, -1.0);
      /* make sure real part is >= 0 */
      if (res->o[0] < 0.0) {
	aplc_negate_o(res, res);
      }	
      if (1.0 == 1.0 + res->o[0]) {
	res->o[0] = 0.0;
      }
      break;
    case -1:
      /* arcsin */ 
      /* v = I*a + sqrt(1 - a^2) */
      aplc_square_res_o(&rt1, &rnval);
      aplc_negate_o(&rt2, &rt1);
      rt2.o[0] += 1.0;
      aplc_sqrt_res_o(&rt1, &rt2);
      aplc_Io(&rt2, &rnval);
      aplc_add_res_o(&rt3, &rt2, &rt1);
      /* z = -I* ln(v) */
      aplc_ln_res_o(&rt1, &rt3);
      aplc_Iso( res, &rt1, -1.0);
      break;
    case 0:
      /* sqrt(1 - r^2) */ 
      aplc_square_res_o(&rt1, &rnval);
      rt1.o[0] = 1.0 - rt1.o[0];
      for (i=1; i<8; i++)
	rt1.o[i] = -rt1.o[i];
      aplc_sqrt_res_o(res, &rt1);
      break;
    case 1:
      /* sin */
      aplc_sin_res_o(res, &rnval);
      break;
    case 2:
      /* cos */
      aplc_cos_res_o(res, &rnval);
      break;
    case 3:
      /* tan */ 
      aplc_tan_res_o(res, &rnval);
      break;
    case 4:
      /* sqrt(1+r^2) */ 
      aplc_square_res_o(&rt1, &rnval);
      rt1.o[0] = 1.0 + rt1.o[0];
      aplc_sqrt_res_o(res, &rt1);
      break;
    case 5:
      /* sinh */ 
      aplc_sinh_res_o(res, &rnval);
      break;
    case 6:
      /* cosh */
      aplc_cosh_res_o(res, &rnval);
      break;
    case 7:
      /* tanh */ 
      aplc_tanh_res_o(res, &rnval);
      break;
    case 8:
      /* sqrt( _1 - r^2 ) */
      aplc_square_res_o(&rt1, &rnval);
      rt1.o[0] = -1.0 - rt1.o[0];
      for (i=1; i<8; i++)
	rt1.o[i] = -rt1.o[i];
      aplc_sqrt_res_o(res, &rt1);
      break;
    case 9:
      /* real( r ) */
      res->o[0] = rnval.o[0];
      for (i=1; i<8; i++)
	res->o[i] = 0.0;
      break;
    case 10:
      /* |r */
      res->o[0] = NORM_reso(rnval);
      for (i=1; i<8; i++)
	res->o[i] = 0.0;
      break;
    case 11:
      /* imag( r ) */
      res->o[0] = 0.0;
      for (i=1; i<8; i++)
	res->o[i] = rnval.o[i];
      break;
    case 12:
      /* return complex number x such that q = ^x */
      aplc_ln_res_o(res, &rnval);
      res->o[0] = 0.0;/* zero out magnitude part */
#if 0
      /* arc( r ) */
      res->o[0] = oangle(&rnval);
      for (i=1; i<8; i++)
	res->o[i] = 0.0;
      break;
#endif
    }
    break;
  }
  return;
}

extern void
aplc_binomial_res(union res_struct * res, union res_struct * lval, 
		  int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_BOOL:
  case APLC_INT:
    res->i = aplc_binomiali(lnval.i, rnval.i);
    break;
  case APLC_REAL:
    res->r = aplc_binomialr(lnval.r, rnval.r);
    break;
  default:
    aplc_error("[aplc_binomial_res] illegal types for op");
  }
  return;
}

/* logicals */

extern void
aplc_and_res(union res_struct * res, union res_struct * lval, 
	     int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, APLC_BOOL, lval, ltype);
  aplc_cktype2(&rnval, APLC_BOOL, rval, rtype);
  res->i = (lnval.i && rnval.i);
  return;
}

extern void
aplc_or_res(union res_struct * res, union res_struct * lval, 
	    int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, APLC_BOOL, lval, ltype);
  aplc_cktype2(&rnval, APLC_BOOL, rval, rtype);
  res->i = (lnval.i || rnval.i);
  return;
}

extern void
aplc_nand_res(union res_struct * res, union res_struct * lval, 
	      int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, APLC_BOOL, lval, ltype);
  aplc_cktype2(&rnval, APLC_BOOL, rval, rtype);
  res->i = !(lnval.i && rnval.i);
  return;
}

extern void
aplc_nor_res(union res_struct * res, union res_struct * lval, 
	     int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, APLC_BOOL, lval, ltype);
  aplc_cktype2(&rnval, APLC_BOOL, rval, rtype);
  res->i = !(lnval.i || rnval.i);
  return;
}

/* comparison */

extern void
aplc_lt_res(union res_struct * res, union res_struct * lval, 
	    int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_CHAR:
    res->i = lnval.c < rnval.c;
    break;
  case APLC_BOOL:
  case APLC_INT:
    res->i = lnval.i < rnval.i;
    break;
  case APLC_REAL:
    res->i = lnval.r < rnval.r;
    break;
  default:
    aplc_error("[aplc_lt_res] illegal types for op");
  }
  return;
}

extern void
aplc_le_res(union res_struct * res, union res_struct * lval, 
	    int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_CHAR:
    res->i = lnval.c <= rnval.c;
    break;
  case APLC_BOOL:
  case APLC_INT:
    res->i = lnval.i <= rnval.i;
    break;
  case APLC_REAL:
    res->i = lnval.r <= rnval.r;
    break;
  default:
    aplc_error("[aplc_le_res] illegal types for op");
  }
  return;
}

static int
types_diff(int type1, int type2)
{
  if (type1 == type2)
    return 0;
  /* char can't match anything else */
  if ( (type1 == APLC_CHAR) || (type2 == APLC_CHAR) )
    return 1;
  return 0;
}

extern void
aplc_eq_res(union res_struct *res, 
	    union res_struct *lval, int ltype, 
	    union res_struct *rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;
  int i;

  if (types_diff(ltype, rtype)) {
    res->i = 0;
    return;
  }
  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_CHAR:
    res->i = lnval.c == rnval.c;
    break;
  case APLC_BOOL:
  case APLC_INT:
    res->i = lnval.i == rnval.i;
    break;
  case APLC_REAL:
    res->i = lnval.r == rnval.r;
    break;
  case APLC_COMPLEX:
    res->i = (lnval.z[0] == rnval.z[0]) && (lnval.z[1] == rnval.z[1]);
    break;
  case APLC_QUAT:
    res->i = 1;
    for (i=0; i<4; i++)
      res->i = res->i && (lnval.q[i] == rnval.q[i]);
    break;
  case APLC_OCT:
    res->i = 1;
    for (i=0; i<8; i++)
      res->i = res->i && (lnval.o[i] == rnval.o[i]);
    break;
  default:
    aplc_error("[aplc_eq_res] illegal types for op");
  }
  return;
}

extern void
aplc_ne_res(union res_struct * res, union res_struct * lval, 
	    int ltype, union res_struct * rval, int rtype)
{
  int i, maxtype;
  union res_struct lnval, rnval;

  if (types_diff(ltype, rtype)) {
    res->i = 1;
    return;
  }
  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_CHAR:
    res->i = lnval.c != rnval.c;
    break;
  case APLC_BOOL:
  case APLC_INT:
    res->i = lnval.i != rnval.i;
    break;
  case APLC_REAL:
    res->i = lnval.r != rnval.r;
    break;
  case APLC_COMPLEX:
    res->i = (lnval.z[0] != rnval.z[0]) || (lnval.z[1] != rnval.z[1]);
    break;
  case APLC_QUAT:
    res->i = 1;
    for (i=0; i<4; i++)
      res->i = res->i || (lnval.q[i] != rnval.q[i]);
    break;
  case APLC_OCT:
    res->i = 1;
    for (i=0; i<8; i++)
      res->i = res->i || (lnval.o[i] != rnval.o[i]);
    break;
  default:
    aplc_error("[aplc_ne_res] illegal types for op");
  }
  return;
}

extern void
aplc_ge_res(union res_struct * res, union res_struct * lval, 
	    int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_CHAR:
    res->i = lnval.c >= rnval.c;
    break;
  case APLC_BOOL:
  case APLC_INT:
    res->i = lnval.i >= rnval.i;
    break;
  case APLC_REAL:
    res->i = lnval.r >= rnval.r;
    break;
  default:
    aplc_error("[aplc_ge_res] illegal types for op");
  }
  return;
}

extern void
aplc_gt_res(union res_struct * res, union res_struct * lval, 
	    int ltype, union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;

  maxtype = (ltype > rtype) ? ltype : rtype;
  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_CHAR:
    res->i = lnval.c > rnval.c;
    break;
  case APLC_BOOL:
  case APLC_INT:
    res->i = lnval.i > rnval.i;
    break;
  case APLC_REAL:
    res->i = lnval.r > rnval.r;
    break;
  default:
    aplc_error("[aplc_gt_res] illegal types for op");
  }
  return;
}


/* -------------------------------------------------------- */
/* -------------------------------------------------------- */
/* special routines for complex numbers */

static void
zprint(char *s, union res_struct *z)
{
  printf("%s [ %g %g ]\n",s, z->z[0], z->z[1]);
  return;
}


/* set res = 0 */
extern void
aplc_zero_z(union res_struct *res)
{
  res->z[0] = 0.0;
  res->z[1] = 0.0;
  return;
} 

/* set res = 1 */
extern void
aplc_unit_z(union res_struct *res)
{
  res->z[0] = 1.0;
  res->z[1] = 0.0;
  return;
} 

/* special version of atan
   - handles essentially 0 x 
   - in this case atan2 can depend on the sign of x
*/
double
aplc_atan2(double y, double x)
{
  if (1.0 == 1.0 + y) {
    if (x < 0.0)
      return PI;
    else
      return 0.0;
  } else
    return atan2(y,x);
}

/* get the angle of a complex number */
static double
zangle(union res_struct * res)
{
  /*return atan2(res->z[1], res->z[0]);*/
  return aplc_atan2(res->z[1], res->z[0]);
}  


extern void
aplc_exp_res_z(union res_struct *res, union res_struct *a)
{
  double x;

  x = exp(a->z[0]);
  res->z[0] =  x*cos(a->z[1]);
  res->z[1] =  x*sin(a->z[1]);
  return;
}

extern void
aplc_ln_res_z(union res_struct *res, union res_struct *a)
{
  double mag;

  mag = NORM_respz(a);
#if DCHECKS
  /* check for domain errors */
  if ( 1.0 == 1.0 + mag ) {
    printf("[aplc_ln] log %g\n", mag);
    aplc_error("log: domain error");
  }
#endif
  res->z[0] = log(mag);
  res->z[1] = zangle(a);
  return;
}

extern void
aplc_square_res_z(union res_struct *res, union res_struct *a)
{
  res->z[0] = a->z[0]*a->z[0] - a->z[1]*a->z[1];
  res->z[1] = 2*a->z[0]*a->z[1];
  return;
}

extern void
aplc_sqrt_res_z(union res_struct *res, union res_struct *a)
{
  double mag, theta;

  if (1.0 == 1.0 + a->z[1]) {
    /* sqrt(real) */
    if (a->z[0]> 0.0) {
      res->z[0] = sqrt(a->z[0]);
      res->z[1] = 0.0;
    } else {
      res->z[0] = 0.0;
      res->z[1] = sqrt(-a->z[0]);
    }
    return;
  }
  if (1.0 == 1.0 + a->z[0]) {
    /* sqrt(imag) */
    if (a->z[1] > 0.0 ) {
      res->z[0] = sqrt(0.5*a->z[1]);
      res->z[1] = res->z[0];
    } else {
      res->z[0] = sqrt(-0.5*a->z[1]);
      res->z[1] = -res->z[0];
    }
    return;
  }
  /* fully complex */
  mag = sqrt( NORM_respz(a) );
  theta = 0.5*zangle(a);
  res->z[0] = mag*cos(theta);
  res->z[1] = mag*sin(theta);
  return;
}


/* -------------------------------------------------------- */

extern void
aplc_times_res_z(union res_struct *res, union res_struct *a, 
		 union res_struct *b)
{
  res->z[0] = a->z[0]*b->z[0] - a->z[1]*b->z[1];
  res->z[1] = a->z[0]*b->z[1] + a->z[1]*b->z[0];
  return;
}

extern void
aplc_divide_res_z(union res_struct *res, union res_struct *a, 
		 union res_struct *b)
{
  double x;

  x = NORM2_respz(b);
#if DCHECKS
  /* check for domain errors */
  if (1.0 == 1.0 + x ) {
    printf("[aplc_divide] %gi%g %% %gi%g\n", 
	   a->z[0],a->z[1], 
	   b->z[0],b->z[1]);
    aplc_error("%%: domain error");
  }
#endif
  res->z[0] = (a->z[0]*b->z[0] + a->z[1]*b->z[1])/x;
  res->z[1] = (-a->z[0]*b->z[1] + a->z[1]*b->z[0])/x;
  return;
}

/* -------------------------------------------------------- */
/* -------------------------------------------------------- */
/* special routines just for quat */

static void
qprint(char *s, union res_struct *q)
{
  printf("%s [ %g %g %g %g ]\n",s,
	 q->q[0], q->q[1], q->q[2], q->q[3]);
  return;
}


/* set res = val */
extern void
aplc_equate_q(union res_struct *res, union res_struct *val)
{
  res->q[0] = val->q[0];
  res->q[1] = val->q[1];
  res->q[2] = val->q[2];
  res->q[3] = val->q[3];
  return;
} 

/* set res = -val */
extern void
aplc_negate_q(union res_struct *res, union res_struct *val)
{
  res->q[0] = -val->q[0];
  res->q[1] = -val->q[1];
  res->q[2] = -val->q[2];
  res->q[3] = -val->q[3];
  return;
} 

/* set res = +val */
extern void
aplc_conj_q(union res_struct *res, union res_struct *val)
{
  res->q[0] =  val->q[0];
  res->q[1] = -val->q[1];
  res->q[2] = -val->q[2];
  res->q[3] = -val->q[3];
  return;
} 

/* set res = s*I(a) = s*unit(imag(a))
 */
extern void
aplc_Is_q(union res_struct *res, union res_struct *a, double s)
{
  double magv;

  magv = NORM_v_respq(a);
  if (1.0 == 1.0 + magv) {
    /* q is real,  pick i as imaginary axis */
    res->q[0] = 0.0; 
    res->q[1] = s;
    res->q[2] = 0.0;
    res->q[3] = 0.0;
    return;
  } 
  res->q[0] =  0.0;
  magv = s/magv;
  res->q[1] = magv*a->q[1];
  res->q[2] = magv*a->q[2];
  res->q[3] = magv*a->q[3];
  return;
} 

/* set res = I(val)*a, where I = unit(imag(a))
 */
extern void
aplc_Iq(union res_struct *res, union res_struct *a)
{
  double magv;

  magv = NORM_v_respq(a);
  if (1.0 == 1.0 + magv) {
    /* purely real */
    res->q[0] = 0.0; 
    res->q[1] = a->q[0];
    res->q[2] = 0.0;
    res->q[3] = 0.0;
    return;
  } 
  res->q[0] =  -magv;
  magv = a->q[0]/magv;
  res->q[1] = magv*a->q[1];
  res->q[2] = magv*a->q[2];
  res->q[3] = magv*a->q[3];
  return;
} 

/* set res = s*I(val)*a, where I = unit(imag(a))
 */
extern void
aplc_Isq(union res_struct *res, union res_struct *a, double s)
{
  double magv;

  magv = NORM_v_respq(a);
  if (1.0 == 1.0 + magv) {
    /* purely real */
    res->q[0] = 0.0; 
    res->q[1] = s*a->q[0];
    res->q[2] = 0.0;
    res->q[3] = 0.0;
    return;
  } 
  res->q[0] =  -s*magv;
  magv = s*a->q[0]/magv;
  res->q[1] = magv*a->q[1];
  res->q[2] = magv*a->q[2];
  res->q[3] = magv*a->q[3];
  return;
} 

/* set res = 0 */
extern void
aplc_zero_q(union res_struct *res)
{
  res->q[0] = 0.0;
  res->q[1] = 0.0;
  res->q[2] = 0.0;
  res->q[3] = 0.0;
  return;
} 

/* set res = 1 */
extern void
aplc_unit_q(union res_struct *res)
{
  res->q[0] = 1.0;
  res->q[1] = 0.0;
  res->q[2] = 0.0;
  res->q[3] = 0.0;
  return;
} 

/* q = R*exp(I theta) */
static double
qangle(union res_struct * res)
{
  /*return atan2( NORM_v_respq(res), res->q[0]);*/
  return aplc_atan2( NORM_v_respq(res), res->q[0]);
}  


/* r = 1/q */
extern void
aplc_recip_res_q(union res_struct *res, union res_struct *q)
{
  double x;

  x = NORM2_respq(q);
#if DCHECKS
  if ( 1.0 == 1.0 + x ) {
    printf("[runop] %% %gi%gj%gk%g\n", 
	   q->q[0], q->q[1], q->q[2], q->q[3]);
    aplc_error("%%: domain error");
  }
#endif
  res->q[0] =  q->q[0]/x;
  res->q[1] = -q->q[1]/x;
  res->q[2] = -q->q[2]/x;
  res->q[3] = -q->q[3]/x;
  return;
}

/* r = exp(val) */
extern void
aplc_exp_res_q(union res_struct *res, union res_struct *q)
{
  double vmag, s;
  double sexp;
  
  sexp = exp(q->q[0]);/* scalar exp */
  vmag = NORM_v_respq(q);
  if (1.0 == 1.0 + vmag) {
    s = 0.0;
    res->q[0] = sexp;
  } else {
    s = sexp*sin(vmag)/vmag;
    res->q[0] = sexp*cos(vmag);
  }
  res->q[1] = s*q->q[1];
  res->q[2] = s*q->q[2];
  res->q[3] = s*q->q[3];
  return;
}

/* r = ln(val) */
extern void
aplc_ln_res_q(union res_struct *res, union res_struct *q)
{
  double mag, vmag, s, alpha, sc;

  /* check for q == 0  */
  mag = NORM_respq(q);/* exp(s) */
#if DCHECKS
  if (1.0 == 1.0 + mag) {
    printf("[aplc_ln_res_q] log of q, mag %g\n", mag);
    aplc_error("log: domain error");
  }
#endif
  s = log(mag);
  vmag = NORM_v_respq(q);
  /*alpha = atan2( vmag, q->q[0] );*/
  alpha = aplc_atan2( vmag, q->q[0] );
  if (1.0 == 1.0 + vmag) {
    /* purely real */
    if (q->q[0] < 0.0)
      sc = PI;
    else 
      sc = 0.0;
    res->q[0] = s;
    res->q[1] = sc;
    res->q[2] = 0.0;
    res->q[3] = 0.0;
  return;
  }
  /* else */
  sc = alpha/(sin(alpha)*mag);
  res->q[0] = s;
  res->q[1] = sc*q->q[1];
  res->q[2] = sc*q->q[2];
  res->q[3] = sc*q->q[3];
  return;
}

extern void 
aplc_sin_res_q(union res_struct *res, union res_struct *q)
{
  double magv;

  magv = NORM_v_respq(q);
  aplc_Is_q(res, q, cos(q->q[0])*sinh(magv) );
  res->q[0] = sin(q->q[0])*cosh(magv);
  return;
}

extern void 
aplc_cos_res_q(union res_struct *res, union res_struct *q)
{
  double magv;

  magv = NORM_v_respq(q);
  aplc_Is_q(res, q, -sin(q->q[0])*sinh(magv) );
  res->q[0] = cos(q->q[0])*cosh(magv);
  return;
}

/* 
   sin*1/cos 
or
   (1/cos)*sin
are the same
*/
extern void 
aplc_tan_res_q(union res_struct *res, union res_struct *q)
{
  union res_struct rts, rtc;

  aplc_cos_res_q(&rtc, q);
#if DCHECKS
  if ( 1.0 == 1.0 + NORM_resq(rtc) ) {
    qprint("q", q);
    qprint("cos(q)", &rtc);
    aplc_error("tan domain error");
  }
#endif
  aplc_sin_res_q(&rts, q);
  aplc_divide_res_q(res, &rts, &rtc);
  return;
}

extern void 
aplc_sinh_res_q(union res_struct *res, union res_struct *q)
{
  double magv;

  magv = NORM_v_respq(q);
  aplc_Is_q(res, q, cosh(q->q[0])*sin(magv) );
  res->q[0] = sinh(q->q[0])*cos(magv);
  return;
}

extern void 
aplc_cosh_res_q(union res_struct *res, union res_struct *q)
{
  double magv;

  magv = NORM_v_respq(q);
  aplc_Is_q(res, q, sinh(q->q[0])*sin(magv) );
  res->q[0] = cosh(q->q[0])*cos(magv);
  return;
}

/* 
   sinh/cosh 
*/
extern void 
aplc_tanh_res_q(union res_struct *res, union res_struct *q)
{
  union res_struct rts, rtc;

  aplc_cosh_res_q(&rtc, q);
#if DCHECKS
  if ( 1.0 == 1.0 + NORM_resq(rtc) ) {
    qprint("q", q);
    qprint("cosh(q)", &rtc);
    aplc_error("tanh domain error");
  }
#endif
  aplc_sinh_res_q(&rts, q);
  aplc_divide_res_q(res, &rts, &rtc);
  return;
}

/* square is simple since cross product term vanishes */
extern void
aplc_square_res_q(union res_struct *res, union res_struct *a)
{
  res->q[0] = a->q[0]*a->q[0] - NORM2_v_respq(a); 
  res->q[1] = 2*a->q[0]*a->q[1];
  res->q[2] = 2*a->q[0]*a->q[2];
  res->q[3] = 2*a->q[0]*a->q[3];
  return;
}

extern void
aplc_sqrt_res_q(union res_struct *res, union res_struct *a)
{
  double mag, magv, theta;

  magv = NORM_v_respq(a);
  if (1.0 == 1.0 + magv) {
    /* sqrt(real) */
    if (a->q[0]> 0.0) {
      res->q[0] = sqrt(a->q[0]);
      res->q[1] = 0.0;
      res->q[2] = 0.0;
      res->q[3] = 0.0;
    } else {
      res->q[0] = 0.0;
      res->q[1] = sqrt(-a->q[0]);
      res->q[2] = 0.0;
      res->q[3] = 0.0;
    }
    return;
  }

  /* fully complex */
  mag = sqrt( NORM_respq(a) );
  theta = 0.5*qangle(a);
  res->q[0] = mag*cos(theta);
  mag = mag*sin(theta)/magv;
  res->q[1] = mag*a->q[1];
  res->q[2] = mag*a->q[2];
  res->q[3] = mag*a->q[3];
  return;
}


/* -------------------------------------------------------- */


/* res = l + r */
extern void
aplc_add_res_q(union res_struct *res, union res_struct *lval, 
	       union res_struct * rval)
{
  res->q[0] = lval->q[0] + rval->q[0];
  res->q[1] = lval->q[1] + rval->q[1];
  res->q[2] = lval->q[2] + rval->q[2];
  res->q[3] = lval->q[3] + rval->q[3];
  return;
}

/* res = l - r */
extern void
aplc_sub_res_q(union res_struct *res, union res_struct *lval, 
	       union res_struct * rval)
{
  res->q[0] = lval->q[0] - rval->q[0];
  res->q[1] = lval->q[1] - rval->q[1];
  res->q[2] = lval->q[2] - rval->q[2];
  res->q[3] = lval->q[3] - rval->q[3];
  return;
}

/* res = val*real */
extern void
aplc_q_times_r(union res_struct *res, union res_struct *val, double r)
{
  res->q[0] = val->q[0]*r;
  res->q[1] = val->q[1]*r;
  res->q[2] = val->q[2]*r;
  res->q[3] = val->q[3]*r;
  return;
} 

/* res = l*r */
extern void
aplc_times_res_q(union res_struct *res, union res_struct *lval, 
		 union res_struct * rval)
{
#if RLMORDER
  /* R*L */
  res->q[0] = lval->q[0]*rval->q[0] - lval->q[1]*rval->q[1]  
    - lval->q[2]*rval->q[2] - lval->q[3]*rval->q[3];
  res->q[1] = lval->q[0]*rval->q[1] + lval->q[1]*rval->q[0]
    - lval->q[2]*rval->q[3] + lval->q[3]*rval->q[2];
  res->q[2] = lval->q[0]*rval->q[2] + lval->q[2]*rval->q[0]
    - lval->q[3]*rval->q[1] + lval->q[1]*rval->q[3];
  res->q[3] = lval->q[0]*rval->q[3] + lval->q[3]*rval->q[0] 
    - lval->q[1]*rval->q[2] + lval->q[2]*rval->q[1];
#else
  /* L*R */
  res->q[0] = lval->q[0]*rval->q[0] - lval->q[1]*rval->q[1]  
    - lval->q[2]*rval->q[2] - lval->q[3]*rval->q[3];
  res->q[1] = lval->q[0]*rval->q[1] + lval->q[1]*rval->q[0]
    + lval->q[2]*rval->q[3] - lval->q[3]*rval->q[2];
  res->q[2] = lval->q[0]*rval->q[2] + lval->q[2]*rval->q[0]
    + lval->q[3]*rval->q[1] - lval->q[1]*rval->q[3];
  res->q[3] = lval->q[0]*rval->q[3] + lval->q[3]*rval->q[0] 
    + lval->q[1]*rval->q[2] - lval->q[2]*rval->q[1];
#endif
  return;
}

/* res = l%r = l * (1/r) */
extern void
aplc_divide_res_q(union res_struct *res, union res_struct *lval, 
		 union res_struct * rval)
{
  double x;

  x = NORM2_respq(rval);
#if DCHECKS
  /* check for domain errors */
  if (1.0 == 1.0 + x ) {
    printf("[aplc_divide_res_q] %gi%gj%gk%g %% %gi%gj%gk%g\n", 
	   lval->q[0],lval->q[1],lval->q[2], lval->q[3],
	   rval->q[0],rval->q[1],rval->q[2],rval->q[3]);
    aplc_error("%%: domain error");
  }
#endif

#if RLMORDER
  res->q[0] = (lval->q[0]*rval->q[0] + lval->q[1]*rval->q[1]  
	       + lval->q[2]*rval->q[2] + lval->q[3]*rval->q[3])/x;
  res->q[1] = (-lval->q[0]*rval->q[1] + lval->q[1]*rval->q[0]
	       + lval->q[2]*rval->q[3] - lval->q[3]*rval->q[2])/x;
  res->q[2] = (-lval->q[0]*rval->q[2] + lval->q[2]*rval->q[0]
	       + lval->q[3]*rval->q[1] - lval->q[1]*rval->q[3])/x;
  res->q[3] = (-lval->q[0]*rval->q[3] + lval->q[3]*rval->q[0]
	       + lval->q[1]*rval->q[2] - lval->q[2]*rval->q[1])/x;
#else
  res->q[0] = (lval->q[0]*rval->q[0] + lval->q[1]*rval->q[1]  
	       + lval->q[2]*rval->q[2] + lval->q[3]*rval->q[3])/x;
  res->q[1] = (-lval->q[0]*rval->q[1] + lval->q[1]*rval->q[0]
	       - lval->q[2]*rval->q[3] + lval->q[3]*rval->q[2])/x;
  res->q[2] = (-lval->q[0]*rval->q[2] + lval->q[2]*rval->q[0]
	       - lval->q[3]*rval->q[1] + lval->q[1]*rval->q[3])/x;
  res->q[3] = (-lval->q[0]*rval->q[3] + lval->q[3]*rval->q[0]
	       - lval->q[1]*rval->q[2] + lval->q[2]*rval->q[1])/x;
#endif
  return;
}


/* -------------------------------------------------------- */
/* -------------------------------------------------------- */

/* special routines just for oct */

static void
oprint(char *s, union res_struct *q)
{
  printf("%s [ %g %g %g %g %g %g %g %g ]\n",s,
	 q->o[0], q->o[1], q->o[2], q->o[3],
	 q->o[4], q->o[5], q->o[6], q->o[7]);
  return;
}


/* set res = val */
extern void
aplc_equate_o(union res_struct *res, union res_struct *val)
{
  int i;

  for (i=0; i<8; i++)
    res->o[i] = val->o[i];
  return;
} 

/* set res = -val */
extern void
aplc_negate_o(union res_struct *res, union res_struct *val)
{
  int i;

  for (i=0; i<8; i++)
    res->o[i] = -val->o[i];
  return;
} 

/* set res = +val */
extern void
aplc_conj_o(union res_struct *res, union res_struct *val)
{
  int i;

  res->o[0] =  val->o[0];
  for (i=1; i<8; i++)
    res->o[i] = -val->o[i];
  return;
} 

/* nyd */
/* set res = s*I(a) = s*unit(imag(a))
 */
extern void
aplc_Is_o(union res_struct *res, union res_struct *a, double s)
{
  double magv;
  int i;

  magv = NORM_v_respo(a);
  if (1.0 == 1.0 + magv) {
    /* o is real,  pick i as imaginary axis */
    res->o[0] = 0.0; 
    res->o[1] = s;
    for (i=2; i<8; i++)
      res->o[i] = 0.0;
    return;
  } 
  res->o[0] =  0.0;
  magv = s/magv;
  for (i=1; i<8; i++)
    res->o[i] = magv*a->o[i];
  return;
} 

/* set res = I(val)*a, where I = unit(imag(a))
 */
extern void
aplc_Io(union res_struct *res, union res_struct *a)
{
  double magv;
  int i;

  magv = NORM_v_respo(a);
  if (1.0 == 1.0 + magv) {
    /* purely real */
    res->o[0] = 0.0; 
    res->o[1] = a->o[0];
    for (i=2; i<8; i++)
      res->o[i] = 0.0;
    return;
  } 
  res->o[0] =  -magv;
  magv = a->o[0]/magv;
  for (i=1; i<8; i++)
    res->o[i] = magv*a->o[i];
  return;
} 

/* set res = s*I(val)*a, where I = unit(imag(a))
 */
extern void
aplc_Iso(union res_struct *res, union res_struct *a, double s)
{
  double magv;
  int i;

  magv = NORM_v_respo(a);
  if (1.0 == 1.0 + magv) {
    /* purely real */
    res->o[0] = 0.0; 
    res->o[1] = s*a->o[0];
    for (i=2; i<8; i++)
      res->o[i] = 0.0;
    return;
  } 
  res->o[0] =  -s*magv;
  magv = s*a->o[0]/magv;
  for (i=1; i<8; i++)
    res->o[i] = magv*a->o[i];
  return;
} 

/* set res = 0 */
extern void
aplc_zero_o(union res_struct *res)
{
  int i;

  for (i=0; i<8; i++)
    res->o[i] = 0.0;
  return;
} 

/* set res = 1 */
extern void
aplc_unit_o(union res_struct *res)
{
  int i;

  res->o[0] = 1.0;
  for (i=1; i<8; i++)
    res->o[i] = 0.0;
  return;
} 

/* q = R*exp(I theta) */
static double
oangle(union res_struct * res)
{
  /*return atan2( NORM_v_respq(res), res->q[0]);*/
  return aplc_atan2( NORM_v_respo(res), res->o[0]);
}  


/* r = 1/q */
extern void
aplc_recip_res_o(union res_struct *res, union res_struct *q)
{
  double x;
  int i;

  x = NORM2_respo(q);
#if DCHECKS
  if ( 1.0 == 1.0 + x ) {
    oprint("[runop]", q); 
    aplc_error("%%: domain error");
  }
#endif
  res->o[0] =  q->o[0]/x;
  for (i=1; i<8; i++)
    res->o[i] = -q->o[i]/x;
  return;
}

/* r = exp(val) */
extern void
aplc_exp_res_o(union res_struct *res, union res_struct *q)
{
  double vmag, s;
  double sexp;
  int i;
  
  sexp = exp(q->o[0]);/* scalar exp */
  vmag = NORM_v_respo(q);
  if (1.0 == 1.0 + vmag) {
    s = 0.0;
    res->o[0] = sexp;
  } else {
    s = sexp*sin(vmag)/vmag;
    res->o[0] = sexp*cos(vmag);
  }
  for (i=1; i<8; i++)
    res->o[i] = s*q->o[i];
  return;
}

/* r = ln(val) */
extern void
aplc_ln_res_o(union res_struct *res, union res_struct *q)
{
  double mag, vmag, s, alpha, sc;
  int i;

  /* check for q == 0  */
  mag = NORM_respo(q);/* exp(s) */
#if DCHECKS
  if (1.0 == 1.0 + mag) {
    printf("[aplc_ln_res_o] log of o, mag %g\n", mag);
    oprint("o", q);
    aplc_error("log: domain error");
  }
#endif
  s = log(mag);
  vmag = NORM_v_respo(q);
  alpha = aplc_atan2( vmag, q->o[0] );
  if (1.0 == 1.0 + vmag) {
    /* purely real */
    if (q->o[0] < 0.0)
      sc = PI;
    else 
      sc = 0.0;
    res->o[0] = s;
    res->o[1] = sc;
    for (i=2; i<8; i++)
      res->q[i] = 0.0;
  return;
  }
  /* else */
  sc = alpha/(sin(alpha)*mag);
  res->o[0] = s;
  for (i=1; i<8; i++)
    res->o[i] = sc*q->o[i];
  return;
}

extern void 
aplc_sin_res_o(union res_struct *res, union res_struct *q)
{
  double magv;

  magv = NORM_v_respo(q);
  aplc_Is_o(res, q, cos(q->o[0])*sinh(magv) );
  res->o[0] = sin(q->o[0])*cosh(magv);
  return;
}

extern void 
aplc_cos_res_o(union res_struct *res, union res_struct *q)
{
  double magv;

  magv = NORM_v_respo(q);
  aplc_Is_o(res, q, -sin(q->o[0])*sinh(magv) );
  res->o[0] = cos(q->o[0])*cosh(magv);
  return;
}

/* 
   sin*1/cos 
or
   (1/cos)*sin
are the same
*/
extern void 
aplc_tan_res_o(union res_struct *res, union res_struct *q)
{
  union res_struct rts, rtc;

  aplc_cos_res_o(&rtc, q);
#if DCHECKS
  if ( 1.0 == 1.0 + NORM_reso(rtc) ) {
    oprint("o", q);
    oprint("cos(o)", &rtc);
    aplc_error("tan domain error");
  }
#endif
  aplc_sin_res_o(&rts, q);
  aplc_divide_res_o(res, &rts, &rtc);
  return;
}

extern void 
aplc_sinh_res_o(union res_struct *res, union res_struct *q)
{
  double magv;

  magv = NORM_v_respo(q);
  aplc_Is_o(res, q, cosh(q->o[0])*sin(magv) );
  res->o[0] = sinh(q->o[0])*cos(magv);
  return;
}

extern void 
aplc_cosh_res_o(union res_struct *res, union res_struct *q)
{
  double magv;

  magv = NORM_v_respo(q);
  aplc_Is_o(res, q, sinh(q->o[0])*sin(magv) );
  res->o[0] = cosh(q->o[0])*cos(magv);
  return;
}

/* 
   sinh/cosh 
*/
extern void 
aplc_tanh_res_o(union res_struct *res, union res_struct *q)
{
  union res_struct rts, rtc;

  aplc_cosh_res_o(&rtc, q);
#if DCHECKS
  if ( 1.0 == 1.0 + NORM_reso(rtc) ) {
    oprint("o", q);
    oprint("cosh(o)", &rtc);
    aplc_error("tanh domain error");
  }
#endif
  aplc_sinh_res_o(&rts, q);
  aplc_divide_res_o(res, &rts, &rtc);
  return;
}

extern void
aplc_square_res_o(union res_struct *res, union res_struct *a)
{
  int i;

  res->o[0] = a->o[0]*a->o[0] - NORM2_v_respo(a); 
  for (i=1; i<8; i++)
    res->o[i] = 2*a->o[0]*a->o[i];
  return;
}

extern void
aplc_sqrt_res_o(union res_struct *res, union res_struct *a)
{
  double mag, magv, theta;
  int i;

  magv = NORM_v_respq(a);
  if (1.0 == 1.0 + magv) {
    /* sqrt(real) */
    if (a->o[0]> 0.0) {
      res->o[0] = sqrt(a->o[0]);
      for (i=1; i<8; i++)
	res->o[i] = 0.0;
    } else {
      res->o[0] = 0.0;
      res->o[1] = sqrt(-a->o[0]);
      for (i=2; i<8; i++)
	res->o[i] = 0.0;
    }
    return;
  }

  /* fully complex */
  mag = sqrt( NORM_respo(a) );
  theta = 0.5*oangle(a);
  res->o[0] = mag*cos(theta);
  mag = mag*sin(theta)/magv;
  for (i=1; i<8; i++)
    res->o[i] = mag*a->o[i];
  return;
}


/* -------------------------------------------------------- */


/* res = l + r */
extern void
aplc_add_res_o(union res_struct *res, union res_struct *lval, 
	       union res_struct * rval)
{
  int i;
  
  for (i=0; i<8; i++)
    res->o[i] = lval->o[i] + rval->o[i];
  return;
}

/* res = l - r */
extern void
aplc_sub_res_o(union res_struct *res, union res_struct *lval, 
	       union res_struct * rval)
{
  int i;
  
  for (i=0; i<8; i++)
    res->o[i] = lval->o[i] - rval->o[i];
  return;
}

/* res = val*real */
extern void
aplc_o_times_r(union res_struct *res, union res_struct *val, double r)
{
  int i;
  
  for (i=0; i<8; i++)
    res->o[i] = val->o[i]*r;
  return;
} 

static double
dot(double *a, double *b, int n)
{
  int i;
  double x;

  x = 0.0;
  for (i=0; i<n; i++)
    x += a[i]*b[i];
  return x;
}

static void
stimes(double *x, double *a, double s)
{
  int i;

  for (i=0; i<3; i++)
    x[i] = a[i]*s;
  return;
}

static void
add_stimes(double *x, double *a, double s)
{
  int i;

  for (i=0; i<3; i++)
    x[i] += a[i]*s;
  return;
}

#if 0
static void
add_dot(double *x, double *a, double *b)
{
  int i;

  for (i=0; i<3; i++)
    x[i] += a[i]*b[i];
  return;
}
#endif

static void
add_cross(double *x, double *a, double *b)
{
  x[0] += a[1]*b[2] - a[2]*b[1];
  x[1] += a[2]*b[0] - a[0]*b[2];
  x[2] += a[0]*b[1] - a[1]*b[0];
  return;
}

/* res = l*r */
extern void
aplc_times_res_o(union res_struct *res, union res_struct *lval, 
		 union res_struct * rval)
{
#if RLMORDER
  /* R*L */
  res->o[0] = lval->o[0]*rval->o[0] - 
    dot( &(lval->o[1]), &(rval->o[1]), 7);

  stimes(&(res->o[1]), &(rval->o[1]), lval->o[0]);
  add_stimes(&(res->o[1]), &(lval->o[1]), rval->o[0]);
  add_cross(&(res->o[1]), &(rval->o[1]), &(lval->o[1]));
  add_stimes(&(res->o[1]), &(rval->o[5]), -lval->o[4]);
  add_stimes(&(res->o[1]), &(lval->o[5]),  rval->o[4]);
  add_cross(&(res->o[1]), &(lval->o[5]), &(rval->o[5]));

  res->o[4] = rval->o[4]*lval->o[0] 
    + dot( &(rval->o[5]), &(lval->o[1]), 3)
    + rval->o[0]*lval->o[4]
    - dot( &(lval->o[5]), &(rval->o[1]), 3);

  stimes(&(res->o[5]), &(rval->o[5]), lval->o[0]);
  add_stimes(&(res->o[5]), &(lval->o[1]), -rval->o[4]);
  add_cross(&(res->o[5]), &(lval->o[1]), &(rval->o[5]));
  add_stimes(&(res->o[5]), &(rval->o[1]), lval->o[4]);
  add_stimes(&(res->o[5]), &(lval->o[5]),  rval->o[0]);
  add_cross(&(res->o[5]), &(lval->o[5]), &(rval->o[1]));

#else
  /* L*R */
#endif
  return;
}

/* res = l%r = l * (1/r) */
extern void
aplc_divide_res_o(union res_struct *res, union res_struct *lval, 
		 union res_struct * rval)
{
  double x;
  union res_struct ri;

  x = NORM2_respo(rval);
#if DCHECKS
  /* check for domain errors */
  if (1.0 == 1.0 + x ) {
    printf("[aplc_divide_res_o] L %% R\n");
    oprint("L", lval);
    oprint("R", rval);
    aplc_error("%%: domain error");
  }
#endif
  aplc_recip_res_o(&ri, rval);
  aplc_times_res_o(res, lval, &ri);
  return;
}

/* -------------------------------------------------------- */
/* -------------------------------------------------------- */

#if 0
extern void
aplc_assign_zval( double *zout[2], double *zin[2], int index )
{
  zout[0][0] = zin[0][index];
  zout[1][0] = zin[1][index];
  return;
}
#endif

/* end */
