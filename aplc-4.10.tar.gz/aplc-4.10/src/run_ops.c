/*
	APL Compiler

        sam sirlin

	Run time system
	some ops

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.


*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "aplc.h"

/* ------------------*/
/* conversion from complex <-> real arrays */

/* monadic versions */
/* convert complex to real array */
extern void 
aplc_az(struct trs_struct * res, struct trs_struct * right)
{
  int i,j,n,rk;
  union mp_struct mptmp;

  switch (right->type) {
  default:
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_CHAR:
    /* no change ... */
    aplc_duptrs(res, right);
    break;
  case APLC_COMPLEX:
    /* type is real */
    res->type = APLC_REAL;
    rk = right->rank;
    res->rank = rk+1;
    aplc_vectalloc(&mptmp, 1, APLC_INT);
    res->shape = mptmp.ip;
    res->shape[0] = 2;
    n = 1;
    for (i=0; i<rk; i++) {
      res->shape[i+1] = right->shape[i];
      n*=right->shape[i];
    }
    res->size = 2*n;
    aplc_vectalloc(&mptmp, 2*n, APLC_REAL);
    res->value.rp = mptmp.rp;
    for (i=0; i<n; i++) {
      res->value.rp[i] = right->value.zp[0][i];
      res->value.rp[i+n] = right->value.zp[1][i];
    }
    break;
  case APLC_QUAT:
    res->type = APLC_REAL;
    rk = right->rank;
    res->rank = rk+1;
    aplc_vectalloc(&mptmp, 1, APLC_INT);
    res->shape = mptmp.ip;
    res->shape[0] = 4;
    n = 1;
    for (i=0; i<rk; i++) {
      res->shape[i+1] = right->shape[i];
      n*=right->shape[i];
    }
    res->size = 4*n;
    aplc_vectalloc(&mptmp, 4*n, APLC_REAL);
    res->value.rp = mptmp.rp;
    for (i=0; i<n; i++) {
      res->value.rp[i] = right->value.qp[0][i];
      res->value.rp[i+n] = right->value.qp[1][i];
      res->value.rp[i+2*n] = right->value.qp[2][i];
      res->value.rp[i+3*n] = right->value.qp[3][i];
    }
  break;
  case APLC_OCT:
    res->type = APLC_REAL;
    rk = right->rank;
    res->rank = rk+1;
    aplc_vectalloc(&mptmp, 1, APLC_INT);
    res->shape = mptmp.ip;
    res->shape[0] = 8;
    n = 1;
    for (i=0; i<rk; i++) {
      res->shape[i+1] = right->shape[i];
      n*=right->shape[i];
    }
    res->size = 8*n;
    aplc_vectalloc(&mptmp, 8*n, APLC_REAL);
    res->value.rp = mptmp.rp;
    for (i=0; i<n; i++) 
      for (j=0; j<8; j++) 
	res->value.rp[i+j*n] = right->value.op[j][i];
    break;
  }
  return;
}

/* convert real array to complex */
extern void 
aplc_za(struct trs_struct * res, struct trs_struct * right)
{
  int i,j,m,n,rk;
  union mp_struct mptmp;

  switch (right->type) {
  case APLC_BOOL:
  case APLC_INT:
    /* convert to real */
    break;
  case APLC_REAL:
    break;
  default:
  case APLC_CHAR:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    printf("#za right type %d\n", right->type);
    aplc_error("#za domain error; scalar right");
    break;
  }
  rk = right->rank;
  if (rk < 1)
    aplc_error("#za domain error; scalar right");
  /* later allow replication ? */

  m = right->shape[0];
  res->rank = rk-1;
  aplc_vectalloc(&mptmp, 1, APLC_INT);
  res->shape = mptmp.ip;
  n = 1;
  for (i=0; i<rk-1; i++) {
    res->shape[i] = right->shape[i+1];
    n*=res->shape[i];
  }
  switch (m) {
  default:
    printf("[#za] right shape %d\n", m);
    aplc_error("#za domain error; right shape");
    break;
  case 2:
    res->type = APLC_COMPLEX;
    aplc_vectalloc(&mptmp, n, APLC_COMPLEX);
    res->value.zp[0] = mptmp.zp[0];
    res->value.zp[1] = mptmp.zp[1];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) {
	res->value.zp[0][i] = right->value.ip[i];
	res->value.zp[1][i] = right->value.ip[i+n]; 
      }
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) {
	res->value.zp[0][i] = right->value.rp[i];
	res->value.zp[1][i] = right->value.rp[i+n]; 
      }
      break;
    }
    break;
  case 4:
    res->type = APLC_QUAT;
    aplc_vectalloc(&mptmp, n, APLC_QUAT);
    for (j=0; j<4; j++)
      res->value.qp[j] = mptmp.qp[j];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) 
	for (j=0; j<4; j++) 
	  res->value.qp[j][i] = right->value.ip[i+j*n];
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) 
	for (j=0; j<4; j++) 
	  res->value.qp[j][i] = right->value.rp[i+j*n];
      break;
    }
    break;
  case 8:
    res->type = APLC_OCT;
    aplc_vectalloc(&mptmp, n, APLC_OCT);
    for (j=0; j<8; j++)
      res->value.op[j] = mptmp.op[j];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) 
	for (j=0; j<8; j++) 
	  res->value.op[j][i] = right->value.ip[i+j*n];
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) 
	for (j=0; j<8; j++) 
	  res->value.op[j][i] = right->value.rp[i+j*n];
      break;
    }
    break;
  }
}

/* ------------------*/
/* dyadic versions 

   za2 ... not done yet...

*/
/* convert complex to real array 
   - left argument is which component to grab (index origin dependant)
   e.g. 1 1 2 #az 1i2 <->1 1 2 */
extern void 
aplc_az2(struct trs_struct * res, 
	 struct trs_struct *left, struct trs_struct *right)
{
  int i,j,k, n,rk;
  union mp_struct mptmp;

  /* left must be int */
  if ( (left->type != APLC_INT) &&
       (left->type != APLC_BOOL) ) {
    fprintf(aplcerr,"[aplc_az2] left type %d, ", left->type);
    aplc_error("#az domain error");
  }  
  if ( left->size < 1) {
    aplc_zilde(res);
    return;
  }

  /* setup size, space for result */
  res->type = APLC_REAL;
  rk = right->rank;
  res->rank = rk+1;
  aplc_vectalloc(&mptmp, 1, APLC_INT);
  res->shape = mptmp.ip;
  res->shape[0] = left->size;
  n = 1;
  for (i=0; i<rk; i++) {
    res->shape[i+1] = right->shape[i];
    n*=right->shape[i];
  }
  res->size = n*left->size;
  aplc_vectalloc(&mptmp, res->size, APLC_REAL);
  res->value.rp = mptmp.rp;

  switch (right->type) {
  default:
  case APLC_CHAR:
    aplc_error("#az domain error");
    break;
  case APLC_BOOL:
  case APLC_INT:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if (k != 0)
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.ip[i];
      }
    }
    break;
  case APLC_REAL:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if (k != 0)
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.rp[i];
      }
    }
    break;
  case APLC_COMPLEX:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if ( (k<0) || (k>1))
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.zp[k][i];
      }
    }
    break;
  case APLC_QUAT:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if ( (k<0) || (k>3))
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.qp[k][i];
      }
    }
    break;
  case APLC_OCT:
    for (i=0; i<n; i++) {
      for (j=0; j<left->size; j++) {
	k = left->value.ip[j] - aplc_ixorg;
	if ( (k<0) || (k>7))
	  res->value.rp[i+j*n] = 0.0;
	else
	  res->value.rp[i+n*j] = right->value.op[k][i];
      }
    }
    break;
  }
  return;
}

/* convert real array to complex 
   - left argument must match axis of right shape
     indicates what complex term each right goes to

e.g. 2 za2 1 <-> 0i1
     2 1 za2 1 0 <-> 0i1      

not done yet...

*/
extern void 
aplc_za2(struct trs_struct *res, 
	 struct trs_struct *left, struct trs_struct *right)
{
  int i,j,m,n,rk;
  union mp_struct mptmp;

  /* left must be int */
  if ( (left->type != APLC_INT) &&
       (left->type != APLC_BOOL) ) {
    fprintf(aplcerr,"[aplc_za2] left type %d, ", left->type);
    aplc_error("#za domain error");
  }  
  if ( left->size < 1) {
    aplc_zilde(res);
    return;
  }

  switch (right->type) {
  case APLC_BOOL:
  case APLC_INT:
    /* convert to real */
    break;
  case APLC_REAL:
    break;
  default:
  case APLC_CHAR:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
    printf("#za right type %d\n", right->type);
    aplc_error("#za domain error; scalar right");
    break;
  }
  rk = right->rank;
  if (rk < 1)
    aplc_error("#za domain error; scalar right");
  /* later allow replication ? */

  m = right->shape[0];
  res->rank = rk-1;
  aplc_vectalloc(&mptmp, 1, APLC_INT);
  res->shape = mptmp.ip;
  n = 1;
  for (i=0; i<rk-1; i++) {
    res->shape[i] = right->shape[i+1];
    n*=res->shape[i];
  }
  switch (m) {
  default:
    printf("[#za] right shape %d\n", m);
    aplc_error("#za domain error; right shape");
    break;
  case 2:
    res->type = APLC_COMPLEX;
    aplc_vectalloc(&mptmp, n, APLC_COMPLEX);
    res->value.zp[0] = mptmp.zp[0];
    res->value.zp[1] = mptmp.zp[1];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) {
	res->value.zp[0][i] = right->value.ip[i];
	res->value.zp[1][i] = right->value.ip[i+n]; 
      }
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) {
	res->value.zp[0][i] = right->value.rp[i];
	res->value.zp[1][i] = right->value.rp[i+n]; 
      }
      break;
    }
    break;
  case 4:
    res->type = APLC_QUAT;
    aplc_vectalloc(&mptmp, n, APLC_QUAT);
    for (j=0; j<4; j++)
      res->value.qp[j] = mptmp.qp[j];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) 
	for (j=0; j<4; j++) 
	  res->value.qp[j][i] = right->value.ip[i+j*n];
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) 
	for (j=0; j<4; j++) 
	  res->value.qp[j][i] = right->value.rp[i+j*n];
      break;
    }
    break;
  case 8:
    res->type = APLC_OCT;
    aplc_vectalloc(&mptmp, n, APLC_OCT);
    for (j=0; j<8; j++)
      res->value.op[j] = mptmp.op[j];
    switch (right->type) {
    default:
    case APLC_BOOL:
    case APLC_INT:
      for (i=0; i<n; i++) 
	for (j=0; j<8; j++) 
	  res->value.op[j][i] = right->value.ip[i+j*n];
      break;
    case APLC_REAL:
      for (i=0; i<n; i++) 
	for (j=0; j<8; j++) 
	  res->value.op[j][i] = right->value.rp[i+j*n];
      break;
    }
    break;
  }
}

/* ------------------*/


/* sws

   function encode. for now this looks just like residue, but
   later residue should depend on #ct

   (see the iso standard ref)

   z .is a encode c

   aplc_encode(z, a, a.type, c, c.type)

   changed are z and c

   type for c may not be handled the best possible way...
   consider integer c, real a...

*/
void
aplc_encode(union res_struct * res, union res_struct * lval, int ltype, 
	    union res_struct * rval, int rtype)
{
  int maxtype;
  union res_struct lnval, rnval;
  double temp, templ;

  maxtype = (ltype > rtype) ? ltype : rtype;

  aplc_cktype2(&lnval, maxtype, lval, ltype);
  aplc_cktype2(&rnval, maxtype, rval, rtype);
  switch (maxtype) {
  case APLC_BOOL:
  case APLC_INT:
    if (lnval.i != 0) {
      res->i = rnval.i - lnval.i *
	  floor(((double) rnval.i) / ((double) lnval.i));
      rnval.i = (rnval.i - res->i) / lnval.i;
    } else {
      res->i = rnval.i;
      rnval.i = 0;
    }
    if ((rtype == APLC_INT) || (rtype == APLC_BOOL)) {
      rval->i = rnval.i;
    } else
      fprintf(aplcerr,"case error in encode\n");
    break;
  case APLC_REAL:
    if (lnval.r != 0.0) {
      /* definition, but has trouble with large r */
      /* res->r = rnval.r - lnval.r * floor(rnval.r / lnval.r); */
      /* rnval.r = (rnval.r - res->r) / lnval.r; */
      /* alternate */
      /* rnval.r = floor(rnval.r / lnval.r); */

      /* too slow!
      temp = rnval.r;
      while (temp > lnval.r)
	temp = temp - lnval.r;
      res->r = temp;
      */
      temp = floor(rnval.r / lnval.r); 
      templ = temp*lnval.r;
      if ( templ == 1.0 + templ ) {
	res->r = 0.0;
	/* this can produce fractional results - assume ok */
	rnval.r /= lnval.r;
      } else {
	res->r = rnval.r - templ;
	rnval.r = temp;
      }
    } else {
      res->r = rnval.r;
      rnval.r = 0.0;
    }
    if ((rtype == APLC_INT) || (rtype == APLC_BOOL)) {
      rval->i = (int) rnval.r;
    } else
      rval->r = rnval.r;
    break;
  default:
    aplc_error("type error for encode function");
  }
  return;
}


/* end */
