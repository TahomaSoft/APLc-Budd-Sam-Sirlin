/*
	APL Compiler

        some common stuff for the run time utilities
        sws
*/


#ifndef _RUN_H
#define _RUN_H

/* input buffersize for reading */
/* used in runio.c and runmem.c */
/* #define APLC_IBUFSIZE 2*/
/* #define APLC_IBUFSIZE 3*/
#define APLC_IBUFSIZE 80

/* used by .bxts, .bxdl  */
#define MS_per_SEC  1000.0
#define US_per_SEC  1000000.0
#define NS_per_SEC  1000000000.0

/* some stuff for DJPC */
#ifdef DJPC

/* define u_int, for runio.c */
typedef unsigned int u_int

/* define O_NDELAY */
#ifndef O_NDELAY
#ifdef O_NONBLOCK
#define O_NDELAY  O_NONBLOCK
#else
/* what should go here?? */
#define O_NDELAY  0
#endif
#endif /* #ifndef O_NDELAY*/

#endif /* #ifdef DJPC */

#endif
/* end of run.h */
