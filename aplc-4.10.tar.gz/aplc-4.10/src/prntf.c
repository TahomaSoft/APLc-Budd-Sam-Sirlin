/* sws version of prnt.c that prints to stdout vs stderr */
/* prnt.c has since become rather obsolete... */
/* expect to call it with -n */

/* can recall the old behavior by changing this to stderr */
/* define PRTFILE stderr */
#define PRTFILE stdout

/*
	APL compiler

		print parse tree
		(used for debugging)
			timothy a. budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/
#include "parse.h"
#include "y_tab.h"
#include <stdio.h>


/* declarations */
void passinit(int verbose);
void glbvar(char *name);
void doprog(struct headnode * head, struct symnode * syms,
	    struct statenode * code);
void prnrank(int rank);
void prnshape(struct node * node);
void prnvalues(struct node * node);
void prnttrs(struct node * node);
void prntaxis(struct node * node, int indent_level);
void prntnode(struct node * node, int indent_level);
void prnodetype(struct node * node, int level);
void prsops(struct node * node);
void prsysvar(struct node * node);

/* extern int fprintf(FILE *, const char *,...);*/

/* passinit - initialize this pass (do nothing) */
void
passinit(int verbose)
{
  ;
}

/* glbvar - process a global variable name */
void
glbvar(char *name)
{
  ;
}

/* main program */
void
doprog(struct headnode * head, struct symnode * syms,
    struct statenode * code)
{
  struct symnode *s;
  struct statenode *c;
  int i;

  fprintf(PRTFILE, "\n\nFunction ");
  if (head == NILHEAD || head->fname == NILCHAR) {
    fprintf(PRTFILE, "main\n");
  } else {
    if (head->asvar != NILCHAR)
      fprintf(PRTFILE, "%s <- ", head->asvar);
    if (head->parm1 != NILCHAR)
      fprintf(PRTFILE, "%s ", head->parm1);
    fprintf(PRTFILE, "%s ", head->fname);
    if (head->parm2 != NILCHAR)
      fprintf(PRTFILE, "%s ", head->parm2);
    fprintf(PRTFILE, "\n");
  }
  fprintf(PRTFILE, "Symbols (name, type, rank)\n");
  for (s = syms; s != (struct symnode *) 0; s = s->next) {
    /* fprintf(PRTFILE, "\t%s type %s rank %d\n", s->name, types[s->type],
       s->vrank); */
    /* fprintf(PRTFILE, "\t%s: type= %s, ", s->name, types[s->type]);*/
    fprintf(PRTFILE, "\t%s: type= {%s}", s->name, str_type_name(s->type));
    fprintf(PRTFILE, " rank= ");
    prnrank(s->vrank);
    fprintf(PRTFILE, "\n");
  }
  /* list resources */
  fprintf(PRTFILE,
	  "Counts: maxtrs = %d maxmp = %d maxres = %d maxi = %d\n",
	  head->maxtrs, head->maxmp, head->maxres, head->maxi);
#if 0
  /* list constants (ignore z, q for now) */
  fprintf(PRTFILE, "Constants: i[%d], r[%d], c[%d]\n", 
	  ictop, rctop, sctop);
#else
  fprintf(PRTFILE, "Constants: i[%d], r[%d], c[%d], z[%d], q[%d], o[%d]\n", 
	  ictop, rctop, sctop, zctop, qctop, octop);
#endif
  fprintf(PRTFILE, "Label Constants: [%d]\n", lctop);

#if 1
  /* list */
  fprintf(PRTFILE, "int {"); 
  for (i=0; i<ictop; i++)
    fprintf(PRTFILE, "%d ", iconsts[i]);
  fprintf(PRTFILE, "}\n"); 

  fprintf(PRTFILE, "real {"); 
  for (i=0; i<rctop; i++)
    fprintf(PRTFILE, "%g ", rconsts[i]);
  fprintf(PRTFILE, "}\n"); 

  fprintf(PRTFILE, "complex {"); 
  for (i=0; i<zctop; i++)
    fprintf(PRTFILE, "(%g, %g) ", zconsts[0][i], zconsts[1][i]);
  fprintf(PRTFILE, "}\n"); 

  fprintf(PRTFILE, "quat {"); 
  for (i=0; i<qctop; i++)
    fprintf(PRTFILE, "(%g,%g,%g,%g) ", 
	    qconsts[0][i], qconsts[1][i], qconsts[2][i], qconsts[3][i]);
  fprintf(PRTFILE, "}\n"); 

  fprintf(PRTFILE, "oct {"); 
  for (i=0; i<octop; i++)
    fprintf(PRTFILE, "(%g,%g,%g,%g, %g,%g,%g,%g) ", 
	    oconsts[0][i], oconsts[1][i], oconsts[2][i], oconsts[3][i],
	    oconsts[4][i],oconsts[5][i],oconsts[6][i],oconsts[7][i]);
  fprintf(PRTFILE, "}\n"); 
#endif

  /* list labels */
  for (i=0; i<lctop; i++)
    printf("   %s: %d\n",lconsts[i].label_name, lconsts[i].label_num);

  /* now march through the statements */
  stmtno = 0;
  for (c = code; c != NILSTATE; c = c->nextstate) {
    fprintf(PRTFILE, "\nStatement %d\n", ++stmtno);
    if (c->label != NILCHAR) {
      for (i=0; (i<lctop) && (stmtno != lconsts[i].label_num); i++)
	;
      if (i<lctop)
	fprintf(PRTFILE, "Labeled {%s:}\n", lconsts[i].label_name);
    }
    prntnode(c->code, 0);
  }

}

/* sws  print out rank */
void
prnrank(int rank)
{
  /* fprintf(PRTFILE, " rank= %s", str_rank(rank));*/
  fprintf(PRTFILE, "{%s}", str_rank(rank));
  /* fprintf(PRTFILE, "[%d]", rank);*/
}

/* sws  list shape vector of node with known shape */
void
prnshape(struct node * node)
{
  int rank, pos, j;

  rank = node->rank.n;
  if (rank > 0) {
    pos = node->shape.n;
    /* size = 1; */
    for (j = 0; j < rank; j++)
      fprintf(PRTFILE, "%d ", iconsts[pos + j]);
  } else
    fprintf(PRTFILE, " scalar ");
}

/* print out known values of a node */
void
prnvalues(struct node * node)
{
  int rank, size, i, j;
  int shape;

  rank = node->rank.n;
  shape = node->shape.n;
  size = 1;
  for (i=0; i<rank; i++)
    size *= iconsts[shape +i];
  switch(node->type.n) {
  default: 
    fprintf(PRTFILE, "unknown node type %d\n", node->nodetype);
    break;
  case APLC_BOOL:
  case APLC_INT:
    fprintf(PRTFILE, "(int)");
    for (i=0; i<size; i++)
      fprintf(PRTFILE, " %d ", iconsts[i+node->values.n]);
    break;
  case APLC_REAL:
    fprintf(PRTFILE, "(real)");
    for (i=0; i<size; i++) {
      /* fprintf(PRTFILE, " %g ", rconsts[i+node->values.n]);*/
      /*fprintf(PRTFILE, " %22.15g ", rconsts[i+node->values.n]);*/
      fprintf(PRTFILE, " %1.15g ", rconsts[i+node->values.n]);
    }
    break;    
  case APLC_COMPLEX:
    fprintf(PRTFILE, "(complex)");
    for (i=0; i<size; i++) {
      fprintf(PRTFILE, " (%1.15g, %1.15g) ", 
	      zconsts[0][i+node->values.n], zconsts[1][i+node->values.n]);
    }
    break;
  case APLC_QUAT:
    fprintf(PRTFILE, "(quat)");
    for (i=0; i<size; i++) {
      fprintf(PRTFILE, " ("); 
      for (j=0; j<4; j++) {
	fprintf(PRTFILE, "%1.15g", qconsts[j][i+node->values.n]);
	if (j < 3)
	  fprintf(PRTFILE, ", "); 
      }
      fprintf(PRTFILE, ") "); 
    }
    break;
  case APLC_OCT:
    fprintf(PRTFILE, "(oct)");
    for (i=0; i<size; i++) {
      fprintf(PRTFILE, " ("); 
      for (j=0; j<7; j++) {
	fprintf(PRTFILE, "%1.15g", oconsts[j][i+node->values.n]);
	if (j < 6)
	  fprintf(PRTFILE, ", "); 
      }
      fprintf(PRTFILE, ") "); 
    }
    break;
  case APLC_CHAR:
    fprintf(PRTFILE, "(char)");
    fprintf(PRTFILE, "[");
    for (i=0; i<size; i++)
      fprintf(PRTFILE, "%c", sconsts[i+node->values.n]);
    fprintf(PRTFILE, "]");
    break;    
  }
}

/* print trs header information for a node 
   not all of this should print sensible values due to unions
*/
void
prnttrs(struct node * node)
{
  fprintf(PRTFILE, " [node->info %o] ", node->info);

  if (node->info & TYPEKNOWN)
    fprintf(PRTFILE, " TYPEKNOWN (%s)", str_type_name(node->type.n));
  /* fprintf(PRTFILE, " TYPEKNOWN (%s)", types[node->type.n]);*/
  if (node->info & RANKKNOWN) {
    fprintf(PRTFILE, " RANKKNOWN (");
    prnrank(node->rank.n);
    fprintf(PRTFILE, ")");
  }
  if (node->info)
    fprintf(PRTFILE, "\n   ");
  if (node->info & TYPEDECL)
    fprintf(PRTFILE, " TYPEDECL ");
  if (node->info & RANKDECL)
    fprintf(PRTFILE, " RANKDECL ");
  if (node->info & SHAPEKNOWN) {
    /* fprintf(PRTFILE," SHAPEKNOWN %d", node->shape.n); */
    fprintf(PRTFILE, " SHAPEKNOWN (");
    prnshape(node);
    fprintf(PRTFILE, ")");
  }
  if (node->info & VALUESKNOWN) {
    fprintf(PRTFILE, " VALUESKNOWN [%d]", node->values.n);
    fprintf(PRTFILE, " = ("); prnvalues(node); fprintf(PRTFILE, ")"); 
  }

  if (node->info & SEQUENTIAL)
    fprintf(PRTFILE, " SEQUENTIAL");
  if (node->info & HAVEVALUE)
    fprintf(PRTFILE, " HAVEVALUE");
  if (node->info & NOINDEX)
    fprintf(PRTFILE, " NOINDEX");
  if (node->info & MERGED)
    fprintf(PRTFILE, "\n    MERGED");
  if (node->info & ASSIGNP)
    fprintf(PRTFILE, "\n    ASSIGNP");
  if (node->info & EARLYBIND)
    fprintf(PRTFILE, "\n    EARLYBIND");

  fprintf(PRTFILE, "\n");
  /* note ptr0 is shared in a union, and may be junk */
  fprintf(PRTFILE, "\tindex= %d ptr0= %d ptr1= %d ptr2= %d ptr3= %d",
      node->index, node->a.ptr0, node->ptr1, node->ptr2, node->ptr3);
  fprintf(PRTFILE, " ptr4= %d ptr5= %d\n",
      node->ptr4, node->ptr5);
  fprintf(PRTFILE, "\tptr6= %d ptr7= %d ptr8= %d ptr9= %d",
      node->ptr6, node->ptr7, node->ptr8, node->ptr9);
  fprintf(PRTFILE, " ptr10= %d ptr11= %d\n",
      node->ptr10, node->ptr11);
  /* fprintf(PRTFILE, "\n node end \n"); */

}

void
prntaxis(struct node * node, int indent_level)
{
  if (node->a.axis != NILP)
    prntnode(node->a.axis, indent_level);
  else if (node->info & FIRSTAXIS)
    fprintf(PRTFILE, "\taxis along first position\n");
  else if (node->info & LASTAXIS)
    fprintf(PRTFILE, "\taxis along last position\n");
}


/* indent_level is
   indenting level, for prnodetype, adjusted in prntnode
 */
void
prntnode(struct node * node, int indent_level)
{
  if (node == NILP)
    error("node error");

  prnodetype(node, indent_level);
  /* next node will be indented one */
  indent_level++;

  switch (node->nodetype) {
  default:
    fprintf(PRTFILE, "node type %d\n", node->nodetype);
    /* sws, type 0 gets used in SM axis... */
    /* error("illegal node type printed"); */
    break;

  case ASSIGN:
    fprintf(PRTFILE, " Assignment to %s", node->left->a.namep);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case BCON:
  case ICON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case SCON:
    fprintf(PRTFILE, " Constant ");
    prnttrs(node);
    break;

  case LCON:
    fprintf(PRTFILE, " Label Constant ");
    /* fprintf(PRTFILE, "(%d)\n", node->values.n);*/
    fprintf(PRTFILE, "(%s %d)\n", lconsts[node->values.n].label_name,
	    lconsts[node->values.n].label_num);
    prnttrs(node);
    break;

  case BOX:
  case QQUAD:
    fprintf(PRTFILE, " Input quad ");
    prnttrs(node);
    break;

  case COMMENT:
  case EMPTSEMI:
    fprintf(PRTFILE, " Emptsemi or Comment ");
    prnttrs(node);
    break;

  case COLLECT:
  case CCOLLECT:
  case CIVEC:
  case CVEC:
  case CISCALAR:
  case CSCALAR:
    fprintf(PRTFILE, " Collect type %d ", node->nodetype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case COMPRESS:
  case EXPAND:
  case CAT:
  case LAM:
    fprintf(PRTFILE, " Compress expand cat or lam");
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case CATCH:
    fprintf(PRTFILE, " Catch");
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case DECODE:
    fprintf(PRTFILE, " Dyadic operator decode %d ",
	node->nodetype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "store\n");
    prntnode(node->store, indent_level);
    break;

  case FIDENT:
    fprintf(PRTFILE, " Function call {%s} ", node->a.namep);
    prnttrs(node);
    if (LEFT != NILP) {
      fprintf(PRTFILE, "[FIDENT left]\n");
      prntnode(node->left, indent_level);
    }
    if (RIGHT != NILP) {
      fprintf(PRTFILE, "[FIDENT right]\n");
      prntnode(node->right, indent_level);
    }
    break;

  case IDENT:
    fprintf(PRTFILE, " Identifier ");
    /* check to see if just a storage node ...use sm now */
    if (node->a.namep != NILCHAR)
      fprintf(PRTFILE, "%s", node->a.namep);
    else
      fprintf(PRTFILE, "(storage)");
    prnttrs(node);
    break;

  case INNER:
    fprintf(PRTFILE, " Inner, op %d", node->optype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case INNERCHILD:
    fprintf(PRTFILE,
	" Dyadic operator Innerchild %d, optype %d",
	node->nodetype, node->optype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "store\n");
    prntnode(node->store, indent_level);
    break;

  case IOTA:
    fprintf(PRTFILE, " Iota ");
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case MSOP:
    fprintf(PRTFILE, " MSOP %d ", node->optype);
    prsops(node);
    prnttrs(node);
    prnodetype(node, indent_level);
    prsops(node);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case REVERSE:
    fprintf(PRTFILE, " Reverse");
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case REDUCE:
  case SCAN:
    fprintf(PRTFILE, " Reduce or Scan");
    prsops(node);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case ROTATE:
    fprintf(PRTFILE, " Rotate %d ", node->nodetype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntaxis(node, indent_level);
    break;

  case SM:
    fprintf(PRTFILE, " Sm [;]\n");
    prnttrs(node);
    if (LEFT != NILP) {
      prnodetype(node, indent_level);
      fprintf(PRTFILE, "left\n");
      prntnode(node->left, indent_level);
    }
    if (RIGHT != NILP) {
      prnodetype(node, indent_level);
      fprintf(PRTFILE, "right\n");
      prntnode(node->right, indent_level);
    }
    if (node->a.axis != NILP) {
      prnodetype(node, indent_level);
      fprintf(PRTFILE, "axis\n");
      prntnode(node->a.axis, indent_level);
    }
    break;

  case SUBASSIGN:
    fprintf(PRTFILE, " Sub assignment to %s", node->left->a.namep);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "store\n");
    prntnode(node->store, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "axis\n");
    prntnode(node->a.axis, indent_level);
    break;

  case AVEC:
    fprintf(PRTFILE, " Atomic vector ");
    prnttrs(node);
    break;

  case ASYSVAR:
    fprintf(PRTFILE, " system variable %d ", node->nodetype);
    prsysvar(node);
    fprintf(PRTFILE, " {%d} ", node->optype);
    prnttrs(node);
    if (node->right != NILP) {
      prnodetype(node, indent_level);
      fprintf(PRTFILE, "right\n");
      prntnode(node->right, indent_level);
    }
    break;

  case SYSVAR:
    if (node->left != NILP) {
      /* dyadic function */
      fprintf(PRTFILE, " Dyadic system function %d ", node->optype);
      prnttrs(node);
      prnodetype(node, indent_level);
      fprintf(PRTFILE, "left\n");
      prntnode(node->left, indent_level);
      if (node->right != NILP) {
	prnodetype(node, indent_level);
	fprintf(PRTFILE, "right\n");
	prntnode(node->right, indent_level);
      } else
	fprintf(PRTFILE, "[error: SYSVAR right missing] ");
    } else if (node->right != NILP) {
      /* monadic function */
      fprintf(PRTFILE, " Monadic system function %d",
	  node->optype);
      prnttrs(node);
      prntnode(node->right, indent_level);
    } else {
      /* niladic, must be a system variable */
      fprintf(PRTFILE, " Sysvar %d ", node->optype);
      prsysvar(node);
      prnttrs(node);
    }
    break;

  case TCAV:
    fprintf(PRTFILE, " Sysvar %d ", node->optype);
    prsysvar(node);
    prnttrs(node);
    break;

  case BOXASSIGN:
  case DQQUAD:
  case DBOX:
  case DOMINO:
  case EXECUTE:
  case FORMAT:
  case GO:
  case QBOXAS:
  case RAVEL:
  case RHO:
  case RHORHO:
  case ROLL:
  case SORT:
  case TRANS:
    fprintf(PRTFILE, " Monadic operator %d ", node->nodetype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case MSYSFUN:
    fprintf(PRTFILE, " Monadic operator %d ", node->nodetype);
    prsysvar(node);
    fprintf(PRTFILE, " {%d} ", node->optype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case DSOP:
    fprintf(PRTFILE, " DSOP %d ", node->optype);
    prsops(node);
    prnttrs(node);
    prnodetype(node, indent_level);
    prsops(node);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    prsops(node);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case DBOXAS:
  case DQBOXAS:
  case DEAL:
  case DFORMAT:
  case DROP:
  case DTRANS:
  case ENCODE:
  case EPSILON:
  case INDEX:
  case MSOLVE:
  case OUTER:
  case RESHAPE:
  case SUB:
  case TAKE:
  case GWTAKE:
  case GWDROP:
    fprintf(PRTFILE, " Dyadic operator %d ", node->nodetype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;

  case DSYSFUN:
    /* esysfun currently unused */
  case ESYSFUN:
    fprintf(PRTFILE, " Dyadic operator %d ", node->nodetype);
    prsysvar(node);
    fprintf(PRTFILE, " {%d} ", node->optype);
    prnttrs(node);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "left\n");
    prntnode(node->left, indent_level);
    prnodetype(node, indent_level);
    fprintf(PRTFILE, "right\n");
    prntnode(node->right, indent_level);
    break;
  }
}

/* sws
   print out node type
*/

void
prnodetype(struct node * node, int level)
{
  int i;

  if (node == NILP)
    error("prnodetype node error");
  for (i = 0; i < level; i++)
    fprintf(PRTFILE, "-");
  fprintf(PRTFILE, "%s", prtoken(node->nodetype));
}

/* sws
   print out sops type
   enum sops in aplc.h
*/
void
prsops(struct node * node)
{
  switch (node->optype) {

    default:
    fprintf(PRTFILE, "\n{[prsops] unknown type %d}\n", node->optype);
    break;

  case APLC_NOT:
    fprintf(PRTFILE, "{APLC_NOT}");
    break;
  case APLC_FLOOR:
    fprintf(PRTFILE, "{APLC_FLOOR}");
    break;
  case APLC_CEIL:
    fprintf(PRTFILE, "{APLC_CEIL}");
    break;
  case APLC_PLUS:
    fprintf(PRTFILE, "{APLC_PLUS}");
    break;
  case APLC_MINUS:
    fprintf(PRTFILE, "{APLC_MINUS}");
    break;
  case APLC_TIMES:
    fprintf(PRTFILE, "{APLC_TIMES}");
    break;
  case APLC_ABS:
    fprintf(PRTFILE, "{APLC_ABS}");
    break;
  case APLC_DIVIDE:
    fprintf(PRTFILE, "{APLC_DIVIDE}");
    break;
  case APLC_EXP:
    fprintf(PRTFILE, "{APLC_EXP}");
    break;
  case APLC_LOG:
    fprintf(PRTFILE, "{APLC_LOG}");
    break;
  case APLC_CIRCLE:
    fprintf(PRTFILE, "{APLC_CIRCLE}");
    break;
  case APLC_FACT:
    fprintf(PRTFILE, "{APLC_FACT}");
    break;
  case APLC_AND:
    fprintf(PRTFILE, "{APLC_AND}");
    break;
  case APLC_OR:
    fprintf(PRTFILE, "{APLC_OR}");
    break;
  case APLC_NAND:
    fprintf(PRTFILE, "{APLC_NAND}");
    break;
  case APLC_NOR:
    fprintf(PRTFILE, "{APLC_NOR}");
    break;
  case APLC_LT:
    fprintf(PRTFILE, "{APLC_LT}");
    break;
  case APLC_LE:
    fprintf(PRTFILE, "{APLC_LE}");
    break;
  case APLC_EQ:
    fprintf(PRTFILE, "{APLC_EQ}");
    break;
  case APLC_NE:
    fprintf(PRTFILE, "{APLC_NE}");
    break;
  case APLC_GE:
    fprintf(PRTFILE, "{APLC_GE}");
    break;
  case APLC_GT:
    fprintf(PRTFILE, "{APLC_GT}");
    break;
  }
}

/* sws
   print out sysvar or function name
   enum sysvars in aplc.h
*/
void
prsysvar(struct node * node)
{
  switch (node->optype) {
  default:
    fprintf(PRTFILE, "[prsysvars] unknown type ");
    break;
  case SYS_PP:
    fprintf(PRTFILE, "{SYS_PP}");
    break;
  case SYS_PW:
    fprintf(PRTFILE, "{PW}");
    break;
  case SYS_RL:
    fprintf(PRTFILE, "{RL}");
    break;
  case SYS_IO:
    fprintf(PRTFILE, "{IO}");
    break;
  case SYS_ARG:
    fprintf(PRTFILE, "{ARG}");
    break;
  case SYS_OMAP:
    fprintf(PRTFILE, "{OMAP}");
    break;
  case SYS_TS:
    fprintf(PRTFILE, "{TS}");
    break;
  case SYS_JTS:
    fprintf(PRTFILE, "{JTS}");
    break;
  case TCBEL:
    fprintf(PRTFILE, "{TCBEL}");
    break;
  case TCBS:
    fprintf(PRTFILE, "{TCBS}");
    break;
  case TCCR:
    fprintf(PRTFILE, "{TCCR}");
    break;
  case TCDEL:
    fprintf(PRTFILE, "{TCDEL}");
    break;
  case TCESC:
    fprintf(PRTFILE, "{TCESC}");
    break;
  case TCFF:
    fprintf(PRTFILE, "{TCFF}");
    break;
  case TCHT:
    fprintf(PRTFILE, "{TCHT}");
    break;
  case TCLF:
    fprintf(PRTFILE, "{TCLF}");
    break;
  case TCNUL:
    fprintf(PRTFILE, "{TCNUL}");
    break;
  case SYS_AZ:
    fprintf(PRTFILE, "{AZ}");
    break;
  case SYS_ZA:
    fprintf(PRTFILE, "{ZA}");
    break;
  case SYS_CL:
    fprintf(PRTFILE, "{CL}");
    break;
  case SYS_DL:
    fprintf(PRTFILE, "{DL}");
    break;
  case SYS_FREE:
    fprintf(PRTFILE, "{FREE}");
    break;
  case SYS_FREAD:
    fprintf(PRTFILE, "{SYS_FREAD}");
    break;
  case SYS_PIPE:
    fprintf(PRTFILE, "{PIPE}");
    break;
  case SYS_SPAWN:
    fprintf(PRTFILE, "{SPAWN}");
    break;
  case SYS_SYS:
    fprintf(PRTFILE, "{SYS}");
    break;
  case SYS_FI:
    fprintf(PRTFILE, "{FI}");
    break;
  case SYS_VI:
    fprintf(PRTFILE, "{VI}");
    break;
  case SYS_VTYPE:
    fprintf(PRTFILE, "{VTYPE}");
    break;
  case SYS_FM:
    fprintf(PRTFILE, "{FM}");
    break;
  case SYS_OP:
    fprintf(PRTFILE, "{OP}");
    break;
  case SYS_FWRITE:
    fprintf(PRTFILE, "{SYS_FWRITE}");
    break;
  case SYS_FAPPEND:
    fprintf(PRTFILE, "{SYS_FAPPEND}");
    break;
  case SYS_LSEEK:
    fprintf(PRTFILE, "{LSEEK}");
    break;
  case SYS_FCNTL:
    fprintf(PRTFILE, "{FCNTL}");
    break;
  }
}

/* end of prntf.c */
