/*
	APL Compiler

	Code generation routines having to do with collecting values
	tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/
#include "parse.h"
#include "y_tab.h"
#include "gen.h"
#include <stdio.h>

/* colloop - make a simple collection loop */
void 
colloop(struct node * node, int indexval, int maxval)
{
  if (is_scalar(node)) {
    if (!(node->info & NOINDEX))
      setizero(indexval);
    printf("{\n");
  } else {
    /* loop indexval from 0 to maxval */
    iiloop(indexval, maxval);
  }
}

/*
	genciscalar - generate code for collecting an integer scalar
                      used in index generation
                              deal
                      tollerates vectors of length 1 also

	ptr1 - register for result, if needed
*/
void 
genciscalar(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    if (node->info & VALUESKNOWN) {
      node->values.c =
	  gicn(icnst,
	  iconsts[valvalue(node)], APLC_INT);
      return;
    }
    switchbox(RIGHT, SHAPE, 0);
    if (!(RIGHT->info & TYPEKNOWN))
      testtype(RIGHT->type.c, APLC_INT);
    if (!(RIGHT->info & RANKKNOWN))
      testsingle(RIGHT->rank.c, RIGHT->shape.c);
    if (RIGHT->info & HAVEVALUE) {
      /* we're guaranteed a pointer to memory, sort of 
	 - the type may not be known
       */
      if ((RIGHT->info & TYPEKNOWN))
	node->values.c = gmon(deref, RIGHT->values.c);
      else {
	/* type is not known - force it */
	if ( ((RIGHT->values.c)->cop == memptr) ||
	     ((RIGHT->values.c)->cop == trsptr) ) {
	  RIGHT->values.c->c2.ctype = APLC_INT;
	  node->values.c = gmon(deref, RIGHT->values.c);
	} else {
	  /* what to do here? can we get here? */
	  fprintf(stderr,"[genciscalar] unexpected condition - continuing\n"); 
	  /* resort to non-havevalue code */
	  if (!(RIGHT->info & NOINDEX))
	    setizero(RIGHT->index);
	  switchbox(RIGHT, VALUE, 0);
	  mkrktype(RIGHT, APLC_INT, node->ptr1);
	  node->values.c = RIGHT->values.c;
 	}
      }
    } else {
      if (!(RIGHT->info & NOINDEX))
	setizero(RIGHT->index);
      switchbox(RIGHT, VALUE, 0);
      mkrktype(RIGHT, APLC_INT, node->ptr1);
      node->values.c = RIGHT->values.c;
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    /* shouldn't get here */
    break;

  case FINISH:
    if (!(node->info & VALUESKNOWN))
      switchbox(RIGHT, FINISH, 0);
    break;
  }
}

/*
	gencscalar - generate code for collecting a scalar

	ptr1 - register for result, if needed
*/
void 
gencscalar(struct node * node, enum pmodes mode, int top)
{
  int type;

  switch (mode) {
  case SHAPE:
    if ( (node->info & TYPEKNOWN) && (node->type.n != APLC_ANY) ) {
      type = node->type.n;
      adjdcls(node);
      if (node->info & VALUESKNOWN) {
	if ((type == APLC_INT) || (type == APLC_BOOL)) {
	  /* sws  why do this? */
	  node->values.c = gicn(icnst,
				iconsts[valvalue(node)], APLC_INT);
	  return;
	} else {
	  /* value must be something else besides int */
	  node->values.c = gmon(deref, node->values.c);
	  return;
	}
      } else {
	/* values not known - so we must calculate */
	switchbox(RIGHT, SHAPE, 0);
	switchbox(RIGHT, VALUE, 0);
	node->values.c = RIGHT->values.c;
	return;
      }
    }
    /* type not known */ 
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 0, 0);
    if (!(RIGHT->info & RANKKNOWN))
      testrank(RIGHT->rank.c, 0);

    if (RIGHT->info & HAVEVALUE) {
      /*
	    if ((RIGHT->values.c)->cop == memptr)
		RIGHT->values.c->c2.ctype = APLC_INT;
      */
      node->values.c = 	  gmon(deref, RIGHT->values.c);
    } else {
      if (!(RIGHT->info & NOINDEX))
	setizero(RIGHT->index);
      switchbox(RIGHT, VALUE, 0);
      /*
	    mkrktype(RIGHT, APLC_INT, node->ptr1);
      */
      if (!node->info & TYPEKNOWN)
	node->ptr1 = resinreg(node, node->ptr1);
      node->values.c = RIGHT->values.c;
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    /* shouldn't get here */
    break;

  case FINISH:
    if (!(node->info & VALUESKNOWN))
      switchbox(RIGHT, FINISH, 0);
    break;
  }
}

/*
	gencivec - generate code for collecting values
		used by
		civec - collect integer vector

	ptr1 - size of right
	ptr3 - mp for values (used in loop & changed)
	ptr4 - mp for results (set to same as ptr3 originally)
	ptr5 - result register
	ptr6 - mp for shape
*/
void 
gencivec(struct node * node, enum pmodes mode, int top)
{
  int save;
  struct codetree *savetree;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);

    /* sws redone to accommodate scalar as well as scalar right */
    if (!(node->info & SHAPEKNOWN)) {
      if (RIGHT->info & RANKKNOWN) {
	if (is_scalar(RIGHT))
	  node->shape.c = gcast(cnst, gicn(icnst, 1, APLC_INT), APLC_INT);
	else
	  copychild(node, RIGHT, 0, 0, 1);
      }else {
	/* use size of right as shape */
	getsize(node->ptr1, RIGHT);
	smpalloc(node->ptr6);
	setmptoi(node->ptr6, node->ptr1);
	node->shape.c = gicn(memptr, node->ptr6, APLC_INT);
	/* below doesn't work since later things expect pointers */
	/* node->shape.c = gicn(iptr, node->ptr1, APLC_INT); */
      }
    }

    if (!(RIGHT->info & TYPEKNOWN))
      testtype(RIGHT->type.c, APLC_INT);

    /* test that rank is less than 2 */
    if (!(RIGHT->info & RANKKNOWN)) {
      testmxrank(RIGHT->rank.c, 1);

    }
    if (node->info & VALUESKNOWN)
      return;

    /* for a singleton, we can make things easier */
    if ( (is_singleton(RIGHT)) && 
	 (RIGHT->info & TYPEKNOWN) &&
	 ( (APLC_INT == rtype(RIGHT)) || (APLC_BOOL == rtype(RIGHT)) ) ) {
      switchbox(RIGHT, VALUE, 0);
      /* can do better if right is already in a res... */ 
      printf("res%d.i = ",node->ptr5);
      ctgen(RIGHT->values.c);
      seminl();
      /* since this node is havevalue, expect 
	 a pointer to the value here */
      /* node->values.c = gicn(resptr, node->ptr5, APLC_INT);*/
      node->values.c = gmon(ref, gicn(resptr, node->ptr5, APLC_INT));
      return;
    }
    /* not known singleton */

    if ((RIGHT->info & HAVEVALUE) && (RIGHT->info & TYPEKNOWN)) {
      node->values.c = RIGHT->values.c;
    } else {

      if (RIGHT->info & RANKKNOWN) {
	/* else this was setup above */
	getsize(node->ptr1, RIGHT);
      }
      savetree = looprank;
      looprank = RIGHT->rank.c;
      /* integers only */
      impalloc(node->ptr3, node->ptr1);
      mpeqmp(node->ptr4, node->ptr3);
      colloop(RIGHT, RIGHT->index, node->ptr1);
      switchbox(RIGHT, VALUE, 0);
      save = node->index;
      node->index = RIGHT->index;
      node->ptr5 = asntchk(1, node, RIGHT,
			   rtype(node), node->ptr5, node->ptr3);
      node->index = save;
      rbr();
      node->values.c = gicn(memptr, node->ptr4, rtype(node));
      looprank = savetree;
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    if ( (is_singleton(RIGHT)) && 
	 (RIGHT->info & TYPEKNOWN) &&
	 ( (APLC_INT == rtype(RIGHT)) || (APLC_BOOL == rtype(RIGHT)) ) ) {
      node->values.c = gmon(deref, node->values.c);
    } else
      leafvalue(node, node->ptr4, APLC_INT, node->ptr5);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    if (node->info & VALUESKNOWN)
      break;
    if ( (is_singleton(RIGHT)) && 
	 (RIGHT->info & TYPEKNOWN) &&
	 ( (APLC_INT == rtype(RIGHT)) || (APLC_BOOL == rtype(RIGHT)) ) ) 
      break;
#ifdef DEBUGFREE
    printf("/* -- civec finish */\n");
#endif
    if (!( (RIGHT->info & HAVEVALUE) && (RIGHT->info & TYPEKNOWN)) ) 
      mpfree(node->ptr4);
    if (!(node->info & SHAPEKNOWN)) {
      if (!(RIGHT->info & RANKKNOWN))
	mpfree(node->ptr6);
    }
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;
  }
}

/*
	gencollect - generate code for collecting values
		used by
		cvec - collect vectors
		collect - collect arbitrary objects

sws   changed to include a trs, to account for collection of unknown types

	ptr2 = size of right hand size
	ptr3 = trs pointer
	ptr4 = result register
	ptr5 = memory pointer for values/results (used in internal loop)
	ptr6 = memory pointer for values/results ( as return value )
*/
void 
gencollect(struct node * node, enum pmodes mode, int top)
{
  int save;
  struct codetree *savetree;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 1, 1);
    if (node->nodetype == CVEC)
      /* test that rank is less than 2 */
      if (!(RIGHT->info & RANKKNOWN)) {
	testmxrank(RIGHT->rank.c, 1);
      }
    if (node->info & VALUESKNOWN) {
      if ( (rtype(node) == APLC_COMPLEX) ||
	   (rtype(node) == APLC_QUAT) ||
	   (rtype(node) == APLC_OCT) ) {
	node->values = RIGHT->values;
      } 
#if 0
      printf("/* collect, valuesknown{ ");
      ctgen(node->values.c);
      printf("} right {");
      ctgen(RIGHT->values.c);
      printf("}*/\n");
#endif
      return;
    } else if (RIGHT->info & HAVEVALUE)
      node->values.c = RIGHT->values.c;
    else {
      /* general case, need to build a trs  and collect values */
      settrs(node->ptr3, node);

      if (!(node->info & TYPEKNOWN))
	node->type.c = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
      if (!(node->info & RANKKNOWN))
	node->rank.c = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
      if (!(node->info & SHAPEKNOWN))
	node->shape.c = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);

      savetree = looprank;
      looprank = RIGHT->rank.c;

      ieq(node->ptr2);
      printf("aplc_talloc(&trs%d);\n", node->ptr3);
      node->values.c = gtrs(node->ptr3, cvalfield, rtype(node));
      leafshape(node, node->ptr5);
      /* sws  setup possible pointer for return values */
      mpeqmp(node->ptr6, node->ptr5); 

      if (!is_scalar(RIGHT)) {
	getsize(node->ptr2, RIGHT);
      }
      colloop(RIGHT, RIGHT->index, node->ptr2);
      switchbox(RIGHT, VALUE, 0);
      save = node->index;
      node->index = RIGHT->index;
      node->ptr4 = asntchk(1, node, RIGHT, rtype(node),
			   node->ptr4, node->ptr5);
      node->index = save;
      rbr();

      /* don't use a trs as value, as it could be changed, and then
         free won't work */
#if 0
      node->values.c = gtrs(node->ptr3, cvalfield, rtype(node));
/*
	    leafshape(node, node->ptr5);
*/
#endif
      /* mp to trs is value of node */
      node->values.c = gicn(memptr, node->ptr6, rtype(node));

      looprank = savetree;
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    /* sws   ptr5 is corrupted in collect loop, don't use it */ 
    /* leafvalue(node, node->ptr5, rtype(node), node->ptr4); */
    leafvalue(node, node->ptr6, rtype(node), node->ptr4);
    break;

  case FINISH:
    if (node->info & VALUESKNOWN)
      break;
    switchbox(RIGHT, FINISH, 0);
    if (!(RIGHT->info & HAVEVALUE)) {
#ifdef DEBUGFREE
      printf("/* -- collect finish */\n");
#endif
      /* sws can't free ptr5, as it's corupted */
      /* mpfree(node->ptr5);*/
      /* assume any stuff needed has been copied out already */
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/*
	genccollect - generate code for collecting values
		      always collects right for localization in fns
sws   

	ptr2 = size of right hand size
	ptr3 = trs pointer
	ptr4 = result register
	ptr5 = memory pointer for values/results (used in internal loop)
	ptr6 = memory pointer for values/results ( as return value )
*/
void 
genccollect(struct node * node, enum pmodes mode, int top)
{
  int save;
  struct codetree *savetree;
  int ntype;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 1, 1);

    /*if ( is_scalar(node) && (node->info & TYPEKNOWN) ) {*/
    ntype = rtype(node);
    if ( is_scalar(node) && (node->info & TYPEKNOWN) 
	 && (ntype != APLC_COMPLEX)
	 && (ntype != APLC_QUAT) 
	 && (ntype != APLC_OCT) ) {
      /* known scalar case */
      /* trs%d.scalar.x = right value */
      switchbox(RIGHT, VALUE, 0);
      printf("trs%d.type = ", node->ptr3);
      ctgen(node->type.c);
      seminl();
      printf("trs%d.rank = 0;\n", node->ptr3);
      printf("trs%d.scalar.%s = ", node->ptr3, res_type_str(rtype(node)));
      ctgen(RIGHT->values.c);
      seminl();
      /* for compatibility */
      printf("trs%d.value.%s = &trs%d.scalar.%s;\n", 
	     node->ptr3, mp_type_str(rtype(node)),
	     node->ptr3, res_type_str(rtype(node)) );
      printf("trs%d.alloc_ind = APLC_ALLOC_NF;\n", node->ptr3);
    } else {
      /* general case, need to build a trs  and collect values */
      settrs(node->ptr3, node);

      if (!(node->info & TYPEKNOWN))
	node->type.c = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
      if (!(node->info & RANKKNOWN))
	node->rank.c = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
      if (!(node->info & SHAPEKNOWN))
	node->shape.c = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);

      savetree = looprank;
      looprank = RIGHT->rank.c;

      ieq(node->ptr2);
      printf("aplc_talloc(&trs%d);\n", node->ptr3);
      node->values.c = gtrs(node->ptr3, cvalfield, rtype(node));
      leafshape(node, node->ptr5);
      /* sws  setup possible pointer for return values */
      mpeqmp(node->ptr6, node->ptr5); 

      if (!is_scalar(RIGHT)) {
	getsize(node->ptr2, RIGHT);
      }
      colloop(RIGHT, RIGHT->index, node->ptr2);
      switchbox(RIGHT, VALUE, 0);
      save = node->index;
      node->index = RIGHT->index;
      node->ptr4 = asntchk(1, node, RIGHT, rtype(node),
			   node->ptr4, node->ptr5);
      node->index = save;
      rbr();
      looprank = savetree;
    }
    node->values.c = gicn(memptr, node->ptr6, rtype(node));
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr6, rtype(node), node->ptr4);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    /* don't need to free if scalar - never allocated */
    if ( ! (is_scalar(node) && (node->info & TYPEKNOWN)) ) {
#ifdef DEBUGFREE
      printf("/* -- ccollect finish */\n");
#endif
      /* assume any stuff needed has been copied out already */
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}


/* old version - save temporarily */
#if 0
void 
genccollect(struct node * node, enum pmodes mode, int top)
{
  int save;
  struct codetree *savetree;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 1, 1);

    /* general case, need to build a trs  and collect values */
    settrs(node->ptr3, node);

    if (!(node->info & TYPEKNOWN))
      node->type.c = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
    if (!(node->info & RANKKNOWN))
      node->rank.c = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
    if (!(node->info & SHAPEKNOWN))
      node->shape.c = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);

    savetree = looprank;
    looprank = RIGHT->rank.c;

    ieq(node->ptr2);
    printf("aplc_talloc(&trs%d);\n", node->ptr3);
    node->values.c = gtrs(node->ptr3, cvalfield, rtype(node));
    leafshape(node, node->ptr5);
    /* sws  setup possible pointer for return values */
    mpeqmp(node->ptr6, node->ptr5); 

    if (!is_scalar(RIGHT)) {
      getsize(node->ptr2, RIGHT);
    }
    colloop(RIGHT, RIGHT->index, node->ptr2);
    switchbox(RIGHT, VALUE, 0);
    save = node->index;
    node->index = RIGHT->index;
    node->ptr4 = asntchk(1, node, RIGHT, rtype(node),
			 node->ptr4, node->ptr5);
    node->index = save;
    rbr();
    looprank = savetree;
    node->values.c = gicn(memptr, node->ptr6, rtype(node));
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr6, rtype(node), node->ptr4);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
#ifdef DEBUGFREE
    printf("/* -- ccollect finish */\n");
#endif
    /* assume any stuff needed has been copied out already */
    printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;
  }
}
#endif /* old version */

/*
  genreshape - generate code for reshape (dyadic rho) operator

  ptr1 - size of right hand side
*/
void 
genreshape(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    /* need this always, as left might do something besides get shape,
       e.g. assign */
    switchbox(LEFT, SHAPE, 0);
    if (!(node->info & SHAPEKNOWN)) {
      if (!(node->info & RANKKNOWN))
	node->rank.c = gmon(deref, LEFT->shape.c);
      node->shape.c = LEFT->values.c;
    }
    switchbox(RIGHT, SHAPE, 0);
    if (!(node->info & TYPEKNOWN))
      node->type.c = RIGHT->type.c;
    if ((node->index != RIGHT->index) &&
	(!(RIGHT->info & NOINDEX)))
      getsize(node->ptr1, RIGHT);
    break;

  case COMBINE:
    break;

  case VALUE:
    if ((node->index != RIGHT->index) &&
	(!(RIGHT->info & NOINDEX)))
      iopi(RIGHT->index, node->index, "%", node->ptr1);
    switchbox(RIGHT, VALUE, 0);
    node->values.c = RIGHT->values.c;
    break;

  case FINISH:
    /* if (!(node->info & SHAPEKNOWN))*/
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    break;
  }
}

/* end of collect.c */
