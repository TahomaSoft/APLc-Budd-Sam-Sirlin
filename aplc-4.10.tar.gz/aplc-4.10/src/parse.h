/* 
	APL Compiler

	structures and definitions used by the APL compiler 

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever


This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.

*/

#ifndef _PARSE_H
#define _PARSE_H

#define PARSER
#include "aplc.h"
#include "ctree.h"

#include <string.h>


#ifdef SUNOS4
#ifndef TRADITIONAL
/* sws  sun4 declarations */

extern int fputs(const char *, FILE *);
extern void free(void *);
extern int puts(const char *);

#endif
#endif

/* sws */
/* extern char *malloc(); */
#if defined(DJPC)|defined(ST)|defined(LINUX)
/* included in std.h */
#endif
/* #if defined(SUNOS4)*/
#if HAVE_MALLOC
#include <malloc.h>
#endif

/* -------------------------------------------------------- */
/* define some limits */

/* maximum lines in a fn 
   - currently used in intra.c */
#define MAXSTMTS 500

/* max number of each type real, int, char, ... */
#define MAXCONSTS 5000

/* maximum length of a name, variable, fn, or label (actually 1 less than this) */
#define MAX_NAME_LEN 120

/* -------------------------------------------------------- */


/* structalloc - malloc a structure */
#define structalloc(type) (struct type *) malloc(sizeof(struct type ))

/* parse tree i/o constants */
#define GLSYM  01
#define MNPROG 02
#define PROG   03
#define CONSTS 04
#define STMT   05
#define ESTMT  06
#define SYMS   07
#define ESYMS 010

/* rank types */
#define NORANK  -1 /* a rank of -1 means rank is not known */
#define ANYRANK -2 /* arbitrary rank  sws*/

/* information bits

   VALUESKNOWN assumes values known at compile time, and put into a 
   static vector [irc]_fnname

   these are stored in an int, probably 32bits
   we're using 14 bits

 */
#define TYPEDECL	01   /* type was declared by user */
#define TYPEKNOWN	02   /* type is known (may have been inferred) */
#define RANKDECL	04   /* rank was declared by user */
#define RANKKNOWN      010   /* rank is known at compile time */
#define SHAPEKNOWN     020
#define VALUESKNOWN    040
#define FIRSTAXIS     0100   /* for functions with axis */
#define LASTAXIS      0200

#define SEQUENTIAL   01000   /* will access in sequential order */
#define HAVEVALUE    02000   /* will have value at end of shape phase */
#define NOINDEX      04000   /* no index register is needed for expr */
#define MERGED      010000   /* node has been merged with one higher up */
#define ASSIGNP     020000   /* previous node is assign */
#define EARLYBIND  0100000   /* assign needs to bind to ident in shape phase */

#define LEFT  (node->left)
#define RIGHT (node->right)
#define AXIS  (node->a.axis)
#define NILP (struct node *) 0
#define STORE  (node->store)

/* int or tree - either an int (if known at compile time) or 
	a code tree (if generated at run time) node */

union intortree {
  int n;
  struct codetree *c;
};

/* node - a parse tree node 
   note that optype can be sops or sysvars 
*/
struct node {
  int nodetype;               /* node type */
  int info;                   /* information associated with node */
  struct node *right, *left;  /* right and left children nodes */
  struct node *store;         /* extra child node (subassign) */
  union intortree type;	        /* type of result of node */
  union intortree rank;	        /* rank of result */
  union intortree shape;	/* shape of result */
  union intortree size;	        /* size of result */
  union intortree values;	/* values in result */
  union {
    struct node *axis;         /* axis node */
    struct symnode *symp;      /* symbol table pointer */
    char   *namep;             /* name pointer, for vars and funs */
    int    ptr0;   	       /* an extra useful pointer */
  } a;
  enum sops optype;            /* operator (for reduce, outer, etc) */
  int index;                   /* index pointer number */
  short ptr1;		       /* pointers with various meanings */
  short ptr2;
  short ptr3;
  short ptr4;
  short ptr5;
  short ptr6;
  short ptr7;
  short ptr8;
  short ptr9;
  short ptr10;
  short ptr11;
  short ptr12;
  short ptr13;
};

#define axisgiven(n) (n != NILP)

struct symnode {    /* symbol table node */
  char *name;
  int   type;
  int  vrank;
  struct symnode *next;
};

#define NILSYM (struct symnode *) 0

struct headnode {   /* function header information */
  char *fname; 		/* function name */
  char *asvar;		/* name of assigned to variable */
  char *parm1;		/* name of first parameter */
  char *parm2;		/* name of second parameter */
  int  maxtrs;		/* number of trs registers used */
  int  maxmp;		/* number of mp registers used */
  int  maxres;		/* number of res registers used */
  int  maxi;		/* number of index registers used */
} ;

#define NILHEAD (struct headnode *) 0

struct statenode {      /* statement node */
  char *label;
  struct node *code;
  struct statenode *nextstate;
  struct symnode *list;
} ;

#define NILSTATE (struct statenode *) 0

/* sws new version is a struct, not a union, 
   to keep both name and line number */
struct label_struct {
  char *label_name;
  int  label_num;
};



#define NILCHAR (char *) 0
#define DEFAULTINDEX 999

/* some global variables */
extern int stmtno;
extern int indxorgin;

#include "const.h"
#include "pass.h"
#include "psym.h"
#include "putil.h"

#endif /* PARSE_H */

