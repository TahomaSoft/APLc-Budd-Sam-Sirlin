/*
	APL Compiler

	utilities used in code generation
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/
#include "parse.h"
#include "y_tab.h"
#include "gen.h"
#include <stdio.h>


/* copychild - copy information for a child node into the parent node */
void
copychild(struct node * node, struct node * child,
    int type, int rank, int shape)
{
  if (type && !(node->info & TYPEKNOWN))
    node->type.c = child->type.c;
  if (rank && !(node->info & RANKKNOWN))
    node->rank.c = child->rank.c;
  if (shape && !(node->info & SHAPEKNOWN))
    node->shape.c = child->shape.c;
}

/* sws coptype  print which codeop we have */
char *
str_coptype(enum codeops cop)
{
  switch (cop) {
  case asgn:
    return "assignment";
    break;

  case castop:
    return "cast operator";
    break;

  case cnst:
    return "constants - index into constant tables";
    break;

  case condop:
    return "conditional operation";
    break;

  case dsop:
    return "dyadic scalar ops";
    break;

  case deref:
    return "pointer dereference";
    break;

  case icnst:
    return "actual integer constant (not index)";
    break;

  case idptr:
    return "pointer to an identifier with fields";
    break;

  case iptr:
    return "index register value";
    break;

  case ixorgin:
    return "index origin";
    break;

  case memptr:
    return "memory pointer";
    break;

  case msop:
    return "monadic scalar ops";
    break;

  case postinc:
    return "postincrement (for pointers)";
    break;

  case resptr:
    return "result register pointer";
    break;

  case tcnst:
    return "type constant";
    break;

  case trsptr:
    return "type";
    break;

  case trsvptr:
    return "trs.value pointer";
    break;

  default:
    return "unknown codeop\n";
    break;
  }
  return "unknown codeop\n";
}

#if 1
void
coptype(enum codeops cop)
{
  switch (cop) {

    case asgn:
    printf("/* assignment */\n");
    break;

  case castop:
    printf("/* cast operator */\n");
    break;

  case cnst:
    printf("/* constants - index into constant tables */\n");
    break;

  case condop:
    printf("/* conditional operation */\n");
    break;

  case dsop:
    printf("/* dyadic scalar ops */\n");
    break;

  case deref:
    printf("/* pointer dereference */\n");
    break;

  case icnst:
    printf("/* actual integer constant (not index) */\n");
    break;

  case idptr:
    printf("/* pointer to an identifier with fields */\n");
    break;

  case iptr:
    printf("/* index register value */\n");
    break;

  case ixorgin:
    printf("/* index origin */\n");
    break;

  case memptr:
    printf("/* memory pointer */\n");
    break;

  case msop:
    printf("/* monadic scalar ops */\n");
    break;

  case postinc:
    printf("/* postincrement (for pointers) */\n");
    break;

  case resptr:
    printf("/* result register pointer */\n");
    break;

  case tcnst:
    printf("/* type constant */\n");
    break;

  case trsptr:
    printf("/* type */\n");
    break;

  case trsvptr:
    printf("/* trs.value pointer */\n");
    break;

  default:
    printf("unknown codeop\n");
    break;
  }
}
#endif

/* gcant_happen - something that can't happen just did */
void
gcant_happen(char *s, int n)
{
  fprintf(stderr,
      "[%s] during code generation, impossible condition %d\n",
      s, n);
  exit(1);
}

/* rtype - return the constant known type of a node */
int
rtype(struct node * node)
{
  if (!(node->info & TYPEKNOWN))
    return (APLC_UKTYPE);
  if ((node->type.c)->cop != tcnst) {
    fprintf(stderr,"[rtype] typeknown, (node->type.c)->cop [%s] != tcnst\n",
	    str_coptype((node->type.c)->cop)); 
    gcant_happen("rtype", 10);
  }
  return ((node->type.c)->c0.cindex);
}

/* rankvalue - return the constant known rank of a node */
int
rankvalue(struct node * node)
{
  if (!(node->info & RANKKNOWN)) {
    gcant_happen("rankvalue", 111);
  }
  if ((node->rank.c)->cop != icnst)
    gcant_happen("rankvalue", 10);
  return ((node->rank.c)->c0.cindex);
}

/* shapevalue - return the constant known shape of a node */
/* sws   return value position is start location in iconsts */
int
shapevalue(struct node * node)
{
  struct codetree *child;

  if (!(node->info & SHAPEKNOWN))
    gcant_happen("shapevalue", 112);
  if ((node->shape.c)->cop != cnst)
    gcant_happen("shapevalue", 10);
  child = (node->shape.c)->c0.cleft;
  if (child->cop != icnst)
    gcant_happen("shapevalue", 1112);
  return (child->c0.cindex);
}

/* valvalue - return the constant offset of a known value */
int
valvalue(struct node * node)
{
  struct codetree *child;

  if (!(node->info & VALUESKNOWN))
    gcant_happen("valvalue", 113);
  if ((node->values.c)->cop != cnst)
    gcant_happen("valvalue", 10);
  child = (node->values.c)->c0.cleft;/* jbww UKC 6/87 */
  /* child = (node->shape.c)->c0.cleft;                   */
  if (child->cop != icnst)
    gcant_happen("valvalue", 1112);
  return (child->c0.cindex);
}

/* sws */
/* is_zilde - return true if a node is a known zilde ( .iota 0 or '') */
int
is_zilde(struct node * node)
{
  if ((node->info & RANKKNOWN) && (rankvalue(node) == 1)) {
    if (node->info & SHAPEKNOWN) {
      if (0 == iconsts[shapevalue(node)])
	return (1);
    }
  }
  return (0);
}

/* is_scalar - return true if a node is a known scalar */
int
is_scalar(struct node * node)
{
  if ((node->info & RANKKNOWN) && (rankvalue(node) == 0))
    return (1);
  return (0);
}

/* isnot_scalar - return true if a node is known not to be a scalar */
int
isnot_scalar(struct node * node)
{
  if ((node->info & RANKKNOWN) && (rankvalue(node) != 0))
    return (1);
  return (0);
}

/* is_singleton - return true if a node is a known scalar or vector of
                  length 1 
*/ 
int 
is_singleton(struct node * node) 
{ 
  if (is_scalar(node)) 
    return (1); 
  if ((node->info & RANKKNOWN) && (rankvalue(node) == 1)) 
    if (node->info & SHAPEKNOWN) 
      if (1 == iconsts[shapevalue(node)]) 
	return (1); 
  return (0); 
}

/* isnot_singleton - return true if a node is 
   known to be not a singleton (scalar or vector of length 1) 
*/ 
int 
isnot_singleton(struct node * node) 
{ 
  if (node->info & RANKKNOWN) {
    if (rankvalue(node) == 0 ) 
      return (0); 
    if (rankvalue(node) == 1 ) {
      if (node->info & SHAPEKNOWN) 
	if (1 < iconsts[shapevalue(node)]) 
	  return (1); 
      return (0); 
    }
    if (rankvalue(node) > 1 ) 
      return (1); 
  }
  return (0); 
}

/* is_vector - return true is a node is a known vector */
int
is_vector(struct node * node)
{
  if ((node->info & RANKKNOWN) && (rankvalue(node) == 1))
    return (1);
  return (0);
}

/* adjdcls - adjust declarations to tree form */
void
adjdcls(struct node * node)
{
  if (node->info & TYPEKNOWN) {
    if (APLC_ANY == node->type.n) {
      /* APLC_ANY case - type not really known */
      node->info ^= TYPEKNOWN;
      node->type.n = APLC_UKTYPE;
    } else
      node->type.c = gicn(tcnst, node->type.n, APLC_INT);
  }
  if (node->info & RANKKNOWN) {
    if (ANYRANK == node->rank.n) {
      /* ANYRANK case - rank not really known */
      node->info ^= RANKKNOWN;
      node->rank.n = NORANK;
      if (node->info & SHAPEKNOWN)
	node->info ^= SHAPEKNOWN;    /* remove possible shape info */
    } else
      node->rank.c = gicn(icnst, node->rank.n, APLC_INT);
  }
  if (node->info & SHAPEKNOWN) {
    node->shape.c =
	gcast(cnst, gicn(icnst, node->shape.n, APLC_INT), APLC_INT);
  }
  if (node->info & VALUESKNOWN) {
    node->values.c =
      gcast(cnst, gicn(icnst, node->values.n, APLC_INT), rtype(node));
  }
  return;
}

/* resinreg - make sure a value is in a register, putting it there if
              necessary.  Return the number of the register it is in 
*/

int
resinreg(struct node * node, int regval)
{
  struct codetree *tree;

  tree = node->values.c;
  if (tree->cop == resptr)
    return (tree->c0.cindex);
  else { 
    /* put into register */
    ctgen(gbin(asgn,
	    gicn(resptr, regval, rtype(node)),
	    node->values.c));
    seminl();
    node->values.c = gicn(resptr, regval, rtype(node));
  }
  return (regval);
}

/* ksize - return the size of a known shape node 
   - assumes rank and shape are known
 */
int
ksize(struct node * node)
{
  int rank, pos, size, j;

  rank = rankvalue(node);
  pos = shapevalue(node);
  size = 1;
  for (j = rank - 1; j >= 0; j--)
    size *= iconsts[pos + j];
  return (size);
}

/* getsize - generate code to 
   get the size of the node and put it into ptr i*/
void
getsize(int i, struct node * node)
{
  int rank;

  if ((node->info & RANKKNOWN) &&
      ((node->rank.c)->cop == icnst)) {
    rank = (node->rank.c)->c0.cindex;
    if (rank == 0) {
      seticon(i, 1);
      return;
    }
    if (node->info & SHAPEKNOWN) {
      seticon(i, ksize(node));
      return;
    }
    if (rank == 1) {
      ieq(i);
      ctgen(gmon(deref, node->shape.c));
      seminl();
      return;
    }
  }
  printf("i%d = aplc_vsize(", i);
  rns(node);
  rpseminl();
}

/* getsizeval - generate code to 
   just get the size of the node */
void
getsizeval(struct node * node)
{
  int rank;

  if ((node->info & RANKKNOWN) && ((node->rank.c)->cop == icnst)) {
    rank = (node->rank.c)->c0.cindex;
    if (rank == 0) {
      printf("1");
      return;
    }
    if (node->info & SHAPEKNOWN) {
      printf("%d", ksize(node));
      return;
    }
    if (rank == 1) {
      ctgen(gmon(deref, node->shape.c));
      return;
    }
  }
  printf("aplc_vsize(");
  rns(node);
  rp();
}

/* fixzero - make an uninitialized zero node */
void
fixzero(void)
{
  zeronode->nodetype = ICON;
  zeronode->info = (TYPEKNOWN | RANKKNOWN | SHAPEKNOWN | VALUESKNOWN);
  zeronode->type.c = gicn(tcnst, APLC_INT, APLC_INT);
  zeronode->rank.c = gicn(icnst, 0, APLC_INT);
  zeronode->shape.c = gcast(cnst, gicn(icnst, 1, APLC_INT), APLC_INT);
  zeronode->values.c = gicn(icnst, 0, APLC_INT);
}

/* cpshape - copy a shape vector into a new vector */

extern void
cpshape(int memval, struct node * node)
{
  if (is_vector(node)) {
    printf("*mp%d.ip = ", memval);
    ctgen(gmon(deref, node->shape.c));
    seminl();
  } else {
    /* sws  add runtime check to make sure we don't have a singleton */
    /*- want
	"if ( singleton )"
          if ( rank = 0 or (rank=1 and shape=1) ) {
 	     mp = 1;
	     }
	  else {
	   cpvec
	  }
	  */
    printf("if ");
    singleton(node);
    printf("\n*mp%d.ip = 1;\n", memval);
    elsebr();
    /* else */
    printf("aplc_cpvec(mp%d.ip, ", memval);
    rns(node);
    rpseminl();
    printf("}\n");
  }
}

/* mktmatch - make sure a given type matches another node type */
void
mktmatch(struct node * want, struct node * have, int reg)
{
  if (want->info & TYPEKNOWN)
    mkrktype(have, rtype(want), reg);
  else {
    reg = resinreg(have, reg);
    if (!cteq(want->type.c, have->type.c)) {
      printf(" /* mkmatch type check */\n");
      printf("aplc_cktype(&res%d, ", reg);
      ctgen(want->type.c);
      commasp();
      ctgen(have->type.c);
      rpseminl();
    }
    have->values.c = gicn(resptr, reg, APLC_UKTYPE);
  }
}

/* end of cutil.c */




