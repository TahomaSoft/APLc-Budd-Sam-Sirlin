/*
	APL compiler

	declarations for code trees.
        sws
*/





