/* sws    newio.h

Test for flag to pipe intermediate results as integers rather than
characters. For dos text file mode.

The functions are used in: iotree.c, pass.c, psym.c

This file just defines the old method. The new definitions may be 
found in iotree.c

*/


#ifndef _NEWIO
#define _NEWIO

#ifndef CHARINT

/* original versions of the output functions */

#define  fwriten  fwrite
#define  putcharn  putchar
#define  freadn  fread
#define  getcharn  getchar

#endif

#endif
/* end of newio.h */
