/*
	APL compiler
		parser symbol table routines
		timothy a. budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

#include <stdio.h>
#include "parse.h"


/***********************
	SYMBOL TABLES
************************/
struct symnode *symtab = NILSYM;     /* local symbols */
struct symnode *gsymtab = NILSYM;    /* global symbols */
struct symnode *fsymtab = NILSYM;    /* functions */

/* initialize local symbol table */

/* from y_tab.h */
extern void yyerror(char *c);

/* local functions */
static struct symnode *looksym(char *name, struct symnode * table);
static struct symnode *
placeid(char *name, struct symnode ** table, int type, int rank);
static void 
rmglob(char *name, struct symnode * newp);

 

extern void 
reinitsymtab(void)
{
  symtab = 0;
}

/* looksym - see if a name is in a table
             return pointer to location if found
 */
static struct symnode *
looksym(char *name, struct symnode * table)
{
  /* sws...*/
  if (name == '\0') {
    return (0);
  }
/* sws */

  for (; table != 0; table = table->next) {
    if (strcmp(name, table->name) == 0) {
      return (table);
    }
  }
  return (0);
}

/* placeid - place a new id into a symbol table */
static struct symnode *
placeid(char *name, struct symnode ** table, int type, int rank)
{
  struct symnode *x;

  x = looksym(name, *table);

  if (x != NILSYM) {
    /* already in table, update attributes */
    if (type != APLC_UKTYPE) {
      if (x->type != APLC_UKTYPE && x->type != type)
	error("conflicting type declaractions");
      else
	x->type = type;
    }
    if (rank != NORANK) {
      if (x->vrank != NORANK && x->vrank != rank)
	error("conflicting rank declaractions");
      else
	x->vrank = rank;
    }
  } else {
    x = structalloc(symnode);
    if (x == NILSYM)
      error("out of room");
    x->name = name;
    x->type = type;
    x->vrank = rank;
    x->next = *table;
    *table = x;
  }
  return (x);
}

/* lookup name in symbol tables, 
   return table where found, and pointer to location in table
*/
extern enum classes
idclass(char *name, struct symnode ** symptr)
{
  struct symnode *p;

  p = looksym(name, symtab);
  if (p) {
    *symptr = p;
    return (LOCAL);
  }
  p = looksym(name, gsymtab);
  if (p) {
    *symptr = p;
    return (GLOBAL);
  }
  p = looksym(name, fsymtab);
  if (p) {
    *symptr = p;
    return (FUNCTION);
  }
  *symptr = NILSYM;
  return (NOCLASS);
}

/* rmglob - remove a global identifier from local symbol table */
static void 
rmglob(char *name, struct symnode * newp)
{
  struct symnode *oldp;

  oldp = looksym(name, symtab);
  if (oldp != NILSYM) {
    oldp->name = '\0';
    if (oldp->type != APLC_UKTYPE)
      newp->type = oldp->type;
    if (oldp->vrank != NORANK)
      newp->vrank = oldp->vrank;
  }
}

/* enterid - enter a new id into symbol table */
extern struct symnode *
enterid(char *name, enum classes class, int type, int rank)
{
  struct symnode *x = NILSYM;

  switch (class) {
  case LABCLASS:
    x = placeid(name, &symtab, APLC_LABEL, 0);
    break;
  case PARAM:
    x = placeid(name, &symtab, type, rank);
    break;
  case LOCAL:
    x = placeid(name, &symtab, type, rank);
    break;
  case FUNCTION:
    x = placeid(name, &fsymtab, type, rank);
    rmglob(name, x);
    break;
  case GLOBAL:
    x = looksym(name, gsymtab);
    if (x == NILSYM)
      /* sws ...*/
      /* printf("%c%s\n",GLSYM,name); */
      /* printf(" %d %s\n",GLSYM,name);*/
      putcharn(GLSYM);
    printf("%s\n", name);
    /* sws  */
    x = placeid(name, &gsymtab, type, rank);
    rmglob(name, x);
    break;
  default:
    yyerror("unknown case in enterid\n");
  }
  return (x);
}

/* end of psym.c */
