/*
	APL compiler
		type / rank / shape inferencer
		timothy a. budd

                sws  this file is used for both trs.c and itrs.c,
                     the difference being the definition of INTRA
                     in the compilation of itrs.c, and adding intra.c

note:
    node->rank.n    is the integer value of the rank
    node->shape.n   is a pointer to the starting point of the shape vector in
                    iconsts
*/

#include <stdio.h>
#include <math.h>

#include "parse.h"
#include "y_tab.h"
#include "util2.h"
#include "nutil.h"


/* external variables */
/*
extern int *iconsts;
extern double *rconsts;
extern int ictop;
*/

extern int stmtno;
extern int indxorgin;

/* external functions */

#ifdef INTRA
/* stuff in intra.c */
void doassign(char *name, struct node * node);
void doident(struct node * node);
void dolcon(struct node * node);
struct symnode *getsinfo(char *name);
int mrgtype(int t1, int t2);
int mrgrank(int t1, int t2);

#endif

/* extern void error(char *);*/
/* now in gen... from nutil.c */
extern int maxtype(int ltype, int rtype);

#define is_scalar(node) ((node->info & RANKKNOWN) && (node->rank.n == 0))

/* check that type is really known */
#define TYPEisknown(node) ((node->info & TYPEKNOWN) && (node->type.n != APLC_ANY))

/* check that rank is really known */
#define RKisknown(node) ((node->info & RANKKNOWN) && (node->rank.n != NORANK) && (node->rank.n != ANYRANK))

/* scalar or vector */
#define isnot_vector(node)  (RKisknown(node) && (node->rank.n > 1))
/* scalar */
#define isnot_scalar(node)  (RKisknown(node) && (node->rank.n != 0))

/* axis value is known */
#define Axisval_known  ( (AXIS->info & TYPEKNOWN) &&  \
			 ((AXIS->type.n == APLC_INT) || (AXIS->type.n == APLC_BOOL)) &&  \
			 (AXIS->info & VALUESKNOWN) ) 

/* known not to be a number */ 
#define isnot_num(type) ( (type != APLC_UKTYPE) && \
			  (type != APLC_BOOL) && \
			  (type != APLC_INT) && \
			  (type != APLC_REAL) && \
			  (type != APLC_COMPLEX) && \
			  (type != APLC_QUAT) && \
			  (type != APLC_OCT) && \
			  (type != APLC_ANY) )

/* known empty */
#define isempty(node)  ( RKisknown(node) && \
                         (node->info & SHAPEKNOWN) && \
			 (ksize(node) == 0) )

/* local fn declarations */
static int typemake(int totype, int fromtype);
static int ranktest(struct node * node, int rank);
static int ksize(struct node * node);

static void
dsrtype(enum sops op, struct node * node, struct node * left,
    struct node * right);
static void scantype(enum sops op, struct node * node, 
		     struct node * right);

static void infaxis(struct node * node);
static void
copychild(struct node * node, struct node * child, int type,
    int rank, int shape, int value);

void doinf(struct node * node, int top);
int cpivec(int start, int size, int pos);
void catshape(struct node * node);
void lamshape(struct node * node);
void dytrans(struct node * node);
void outershape(struct node * node);

/* passinit - initialize this pass (do nothing) */
void
passinit(int verbose)
{
  /* sws */
  if (verbose) {

#ifdef INTRA
    fprintf(stderr, "Starting intra\n");
#else
    fprintf(stderr, "Starting trs\n");
#endif
  }
}

/* glbvar - process a global variable name */
void
glbvar(char *name)
{
  ;
}

#ifndef INTRA
/* doprog - process function used by trs */
void
doprog(struct headnode * head, struct symnode * syms,
    struct statenode * code)
{
  struct statenode *p;

  stmtno = 0;
  for (p = code; p != NILSTATE; p = p->nextstate) {
    stmtno++;
    doinf(p->code, 1);
  }
}

#endif

/*
  typemake
  - can an object of fromtype be made into an object of totype?
*/
static int
typemake(int totype, int fromtype)
{

  if ( (totype == APLC_UKTYPE) || (totype == APLC_ANY) )
    return (1);
  if ( (fromtype == APLC_UKTYPE) || (fromtype == APLC_ANY) )
    return (1);
  if (totype == fromtype)
    return (1);

  switch (totype) {
  case APLC_BOOL:
    break;
  case APLC_INT:
    if (fromtype == APLC_BOOL)
      return (1);
    break;
  case APLC_REAL:
    if (fromtype == APLC_BOOL || fromtype == APLC_INT)
      return (1);
    break;
  case APLC_COMPLEX:
    if (fromtype == APLC_BOOL || 
	fromtype == APLC_INT ||
	fromtype == APLC_REAL)
      return (1);
    break;
  case APLC_QUAT:
    if (fromtype == APLC_BOOL || 
	fromtype == APLC_INT ||
	fromtype == APLC_REAL ||
	fromtype == APLC_COMPLEX)
      return (1);
    break;
  case APLC_OCT:
    if (fromtype == APLC_BOOL || 
	fromtype == APLC_INT ||
	fromtype == APLC_REAL ||
	fromtype == APLC_COMPLEX ||
	fromtype == APLC_QUAT)
      return (1);
    break;
  case APLC_CHAR:
    break;
  case APLC_ANY:
    return (1);
  case APLC_UKTYPE:
    return (1);
  case APLC_LABEL:
    break;
  }
  return (0);
}

/* ranktest - see if a node is a given rank */
static int
ranktest(struct node * node, int rank)
{
  if ((node->info & RANKKNOWN) && (node->rank.n == rank))
    return (1);
  return (0);
}

/* return the size of a node - number of elements 
   - assumes rank and shape are known
   - mostly a copy of the routine in cutil.c
*/
static int
ksize(struct node * node)
{
  int rank, pos, size, j;

  rank = node->rank.n;
  pos = node->shape.n;
  size = 1;
  for (j = rank - 1; j >= 0; j--)
    size *= iconsts[pos + j];
  return (size);
}


/* mergetype
   (sws) moved here from dsrtype(APLC_NOT case) 
   type checking for catenate and sub assign
   */
static void
mergetype(struct node * node, struct node * left, struct node * right)
{
  int ltype, rtype;

  if (left->info & TYPEKNOWN)
    ltype = left->type.n;
  else
    ltype = APLC_UKTYPE;
  if (right->info & TYPEKNOWN)
    rtype = right->type.n;
  else
    rtype = APLC_UKTYPE;

  if (isempty(right)) {
    if (ltype != APLC_UKTYPE) {
      node->type.n = ltype;
      node->info |= TYPEKNOWN;
    }
    return;
  }
  if (isempty(left)) {
    if (rtype != APLC_UKTYPE) {
      node->type.n = rtype;
      node->info |= TYPEKNOWN;
    }
    return;
  }

  if ((!typemake(ltype, rtype)) && (!typemake(rtype, ltype))) {
    fprintf(stderr, "[mergetype] types %d %d, nodetype %d\n", 
	    ltype, rtype,node->nodetype);
    if (node->nodetype==CAT)
      error("illegal types for catenation");
    else if (node->nodetype==SUBASSIGN)
      error("illegal types for subassign");
    else
      error("illegal types for ???");
  }
  if ((ltype != APLC_UKTYPE) && (rtype != APLC_UKTYPE)) {
    node->type.n = maxtype(ltype, rtype);
    node->info |= TYPEKNOWN;
  }
}


/*  dsrtype
    type checking for dyadic scalar ops
*/
static void
dsrtype(enum sops op, struct node * node, struct node * left, 
	struct node * right)
{
  int ltype, rtype;

  if (left->info & TYPEKNOWN)
    ltype = left->type.n;
  else
    ltype = APLC_UKTYPE;
  if (right->info & TYPEKNOWN)
    rtype = right->type.n;
  else
    rtype = APLC_UKTYPE;

  switch (op) {
  case APLC_AND:
  case APLC_NAND:
  case APLC_NOR:
  case APLC_OR:
    if ((!typemake(APLC_BOOL, ltype)) && (!typemake(APLC_BOOL, rtype)))
      error("illegal types for logical operator");
    node->info |= TYPEKNOWN;
    node->type.n = APLC_BOOL;
    break;

  case APLC_EQ:
    /* if types not equal, result should be 0  */
    node->info |= TYPEKNOWN;
    node->type.n = APLC_BOOL;
    break;

  case APLC_NE:
    /* if types not equal, result should be 1 */
    node->info |= TYPEKNOWN;
    node->type.n = APLC_BOOL;
    break;

  case APLC_LT:
  case APLC_LE:
  case APLC_GE:
  case APLC_GT:
    if ((!typemake(ltype, rtype)) && (!typemake(rtype, ltype))) {
      error("illegal types for comparison operator");
    }
    node->info |= TYPEKNOWN;
    node->type.n = APLC_BOOL;
    break;

  case APLC_ABS:
  case APLC_CEIL:
  case APLC_FACT:
  case APLC_FLOOR:
  case APLC_MINUS:
  case APLC_PLUS:
  case APLC_TIMES:
    if ((!typemake(ltype, rtype)) && 	(!typemake(rtype, ltype))) {
      fprintf(stderr, "types %d %d\n", ltype, rtype);
      error("illegal types for arithmetic operator");
    }
    if ((ltype != APLC_UKTYPE) && (rtype != APLC_UKTYPE)) {
      node->type.n = maxtype(ltype, rtype);
      node->info |= TYPEKNOWN;
      /* promote bit to int - is this really necessary? 
         probably for +, - only */
      if (node->type.n == APLC_BOOL)
	node->type.n = APLC_INT;
    }
    break;

  case APLC_CIRCLE:
  case APLC_DIVIDE:
  case APLC_EXP:
  case APLC_LOG:
#if 0
    if ((!typemake(APLC_REAL, ltype)) && (!typemake(APLC_REAL, rtype)))
      error("illegal types for real operator");
    node->info |= TYPEKNOWN;
    node->type.n = APLC_REAL;
#endif
    if ( isnot_num(ltype) || isnot_num(rtype) )
      error("illegal types for real operator");
    if ((ltype != APLC_UKTYPE) && (rtype != APLC_UKTYPE)) {
      node->type.n = max(APLC_REAL, maxtype(ltype, rtype));
      node->info |= TYPEKNOWN;
    }
    break;

  case APLC_NOT:
    /* not used currently */
  default:
    fprintf(stderr, "dyadic scalar operator %d not done\n", op);
    exit(1);
  }
}

/*  scantype
    sws type checking for scan; modified dsrtype */
static void
scantype(enum sops op, struct node * node, struct node * right)
{
  int rtype;

  if (right->info & TYPEKNOWN)
    rtype = right->type.n;
  else
    rtype = APLC_UKTYPE;

  switch (op) {
  case APLC_AND:
  case APLC_NAND:
  case APLC_NOR:
  case APLC_OR:
    if (!typemake(APLC_BOOL, rtype))
      error("illegal types for logical operator");
    node->info |= TYPEKNOWN;
    node->type.n = APLC_BOOL;
    break;

  case APLC_EQ:
  case APLC_NE:
  case APLC_LT:
  case APLC_LE:
  case APLC_GE:
  case APLC_GT:
    if (rtype == APLC_BOOL) {
      /* result is only bool if right is bool */
      node->info |= TYPEKNOWN;
      node->type.n = APLC_BOOL;
    }
    break;

  case APLC_ABS:
  case APLC_CEIL:
  case APLC_FACT:
  case APLC_FLOOR:
  case APLC_MINUS:
  case APLC_PLUS:
  case APLC_TIMES:
    if (rtype != APLC_UKTYPE) {
      node->type.n = rtype;
      node->info |= TYPEKNOWN;
      /* promote bool to int - is this really necessary? 
         probably for +, - only */
      if (node->type.n == APLC_BOOL)
	node->type.n = APLC_INT;
    }
    break;

  case APLC_CIRCLE:
  case APLC_DIVIDE:
  case APLC_EXP:
  case APLC_LOG:
    if ( isnot_num(rtype) )
      error("illegal types for real operator");
    if (rtype != APLC_UKTYPE) {
      node->type.n = max(APLC_REAL, rtype);
      node->info |= TYPEKNOWN;
    }
    break;

  case APLC_NOT:
    /* not used currently */
  default:
    fprintf(stderr, "dyadic scalar operator %d not done\n", op);
    exit(1);
  }
}

/*
  infaxis - initialize axis node
  */
static void
infaxis(struct node * node)
{
  struct node *axis;
  int val;

  if ((node->info & FIRSTAXIS) || (node->info & LASTAXIS))
    ;/* nothing to do here */
  else {
    axis = node->a.axis;
    /* the fact that it is a cscalar will fix things */
    doinf(axis, 0);
    /* if we know the axis, perhaps we can do thing better */
    /*
    if ((axis->info & TYPEKNOWN) &&
	((axis->type.n == APLC_INT) || (axis->type.n == APLC_BOOL)) &&
	(indxorgin != DEFAULTINDEX) &&
	(axis->info & HAVEVALUE)) { */
    if ( Axisval_known ) {
      if (indxorgin != DEFAULTINDEX)
	val = iconsts[axis->values.n] - indxorgin;
      else
	val = iconsts[axis->values.n] - 1;
      if ( RKisknown(node) && (val == node->rank.n))
	node->info |= LASTAXIS;
      else if (val == 0)
	node->info |= FIRSTAXIS;
    }
  }
}

/*
  copychild - copy selected attributes from another node
*/
static void
copychild(struct node * node, struct node * child, int type,
    int rank, int shape, int value)
{
  if (type && (child->info & TYPEKNOWN)) {
    node->info |= TYPEKNOWN;
    node->type.n = child->type.n;
  }
  if (rank && (child->info & RANKKNOWN)) {
    node->info |= RANKKNOWN;
    node->rank.n = child->rank.n;
  }
  if (shape && (child->info & SHAPEKNOWN)) {
    node->info |= SHAPEKNOWN;
    node->shape.n = child->shape.n;
  }
  if (value && (child->info & VALUESKNOWN)) {
    node->info |= VALUESKNOWN;
    node->values.n = child->values.n;
  }
}

#define TDEBUG 0

/* doinf - node inferencer 

   called on the to node in a line, it proceeds down the tree to to
   the end (leaves)

*/
void
doinf(struct node * node, int top)
{
  enum sysvars optype;
  int i=0;
  int j=0;
  int sh, rk, rt, c, rkl;

#if TDEBUG && 0
    /* info for debugging */ 
    fprintf(stderr, "[trs] node %d %s\n", 
	    node->nodetype, prtoken(node->nodetype));
#endif

  switch (node->nodetype) {
  default:
    caserr("doinf", node->nodetype);
    break;

  case ASSIGN:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    if (LEFT->info & TYPEDECL) {
      node->type.n = LEFT->type.n;
      node->info |= TYPEKNOWN;
      if (!typemake(node->type.n, RIGHT->type.n))
	error("assignment type error");
    } else if (RIGHT->info & TYPEKNOWN) {
      node->type.n = RIGHT->type.n;
      node->info |= TYPEKNOWN;
    }
    if (LEFT->info & RANKDECL) {
      node->rank.n = LEFT->rank.n;
      node->info |= RANKKNOWN;
#if 0
      /* not sure about this */
      if ((RIGHT->info & RANKKNOWN) && (RIGHT->rank.n != node->rank.n))
	error("[trs] assignment rank error");
#endif
      if (RKisknown(RIGHT) && (RIGHT->rank.n != node->rank.n))
	error("[trs] assignment rank error");
    } else if (RIGHT->info & RANKKNOWN) {
      node->rank.n = RIGHT->rank.n;
      node->info |= RANKKNOWN;
    }
    if (RIGHT->info & SHAPEKNOWN) {
      /* since ranks agree, this must be ok */
      node->shape.n = RIGHT->shape.n;
      node->info |= SHAPEKNOWN;
    }

#ifdef INTRA
    doassign(LEFT->a.namep, node);
#endif

    break;

  case AVEC:
    node->type.n = APLC_CHAR;
    node->rank.n = 1;
    node->shape.n = addicon(256);
    node->info |= (TYPEKNOWN | RANKKNOWN | SHAPEKNOWN);
    break;

  case BCON:
  case ICON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case SCON:
    break;

  case BOX:
  case DBOX:
  case DQQUAD:
    if (RIGHT != NILP) {
      doinf(RIGHT, 0);
    }
    /* node->type.n = APLC_ANY; node->info |= TYPEKNOWN; */
    break;

  case QQUAD:
    node->type.n = APLC_CHAR;
    node->info |= TYPEKNOWN;
    break;

  case QBOXAS:
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1,1,1,1);
    node->info = RIGHT->info;
    node->type.n = APLC_CHAR;
    node->info |= TYPEKNOWN;
    if ( TYPEisknown(RIGHT) ) {
      if (RIGHT->type.n != APLC_CHAR) {
	fprintf(stderr, "[trs] qq assign domain error, type [%d]\n", 
		RIGHT->type.n);
	error("qq assign domain error ");
      }
    }
    break;

  case BOXASSIGN:
    doinf(RIGHT, 0);
    /* value of node is exactly right */
    copychild(node, RIGHT, 1,1,1,1);
    node->info = RIGHT->info;
    break;

  case DBOXAS:
  case DQBOXAS:
    doinf(RIGHT, 0);
    if (LEFT != NILP) { /* file name */
      doinf(LEFT, 0);
    }
    if (RIGHT->info & TYPEKNOWN) {
      node->type.n = RIGHT->type.n;
      node->info |= TYPEKNOWN;
    }
    if (RIGHT->info & RANKKNOWN) {
      node->rank.n = RIGHT->rank.n;
      node->info |= RANKKNOWN;
    }
    if (RIGHT->info & SHAPEKNOWN) {
      /* since ranks agree, this must be ok */
      node->shape.n = RIGHT->shape.n;
      node->info |= SHAPEKNOWN;
    }
    if (node->nodetype == QBOXAS || node->nodetype == DQBOXAS)
      node->ptr2 = 0;
    else
      node->ptr2 = 1;
    break;

  case CAT:
    doinf(RIGHT, 0);
    infaxis(node);
    doinf(LEFT, 0);
    mergetype(node, LEFT, RIGHT);
    /*- sws  be careful of laminate...
      later add some more intelligence to this */
    if ((node->info & FIRSTAXIS) || (node->info & LASTAXIS))
      catshape(node);
    else if ( TYPEisknown(AXIS) ) {
      if ( (AXIS->type.n == APLC_INT) || (AXIS->type.n == APLC_BOOL) )
	catshape(node);/* normal cat */
      else if (AXIS->type.n == APLC_REAL)
	lamshape(node);/* laminate ? */
      else {
	fprintf(stderr, "[trs] cat illegal type [%d]\n", AXIS->type.n);
	error("catenate axis type error ");
      }
    }
    break;

  case CATCH:
    doinf(RIGHT, 1);
    doinf(LEFT, 1);
    break;

  case CCOLLECT:
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1, 1, 1, 0);/* don't collect values */
    break;

  case COLLECT:
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1, 1, 1, 1);
    break;

  case COMMENT:
    break;

  case COMPRESS:
    doinf(RIGHT, 0);
    infaxis(node);
    doinf(LEFT, 0);
    /* first some error checks */ 
    if ((LEFT->info & TYPEKNOWN) && !typemake(LEFT->type.n, APLC_BOOL))
      error("bit type required for compression");
    /* if ((LEFT->info & RANKKNOWN) && (LEFT->rank.n > 1))*/
    if (isnot_vector(LEFT))
      error("vector required for compression");
    /* now put the right info into the current node */
    if (RIGHT->info & TYPEKNOWN) {
      node->type.n = RIGHT->type.n;
      node->info |= TYPEKNOWN;
    }
    if (RIGHT->info & RANKKNOWN) {
      node->rank.n = RIGHT->rank.n;
      if (node->rank.n == 0)
	node->rank.n = 1;
      node->info |= RANKKNOWN;
    }
    /* now refine */
    if ( (LEFT->info & VALUESKNOWN) && 
	 (RIGHT->info & SHAPEKNOWN) &&
	 ( (node->info & FIRSTAXIS) || (node->info & LASTAXIS) ||
	   Axisval_known ) ) {
      node->info |= SHAPEKNOWN;
      /* in this case we know just what right values will be used */ 
      i = LEFT->values.n;
      /* determine size, in c, by counting nonzero entries of left */
      rkl = iconsts[LEFT->rank.n];
      if (rkl == 0) {
	/* left is a scalar */
	c = iconsts[i];
	sh = 1;
      } else {
	/* left is not a scalar */
	c = 0;
	sh = iconsts[LEFT->shape.n];
	for (j = sh - 1; j >= 0; j--)
	  if (iconsts[i + j])
	    c++;
      }
      rk = RIGHT->rank.n;
      if (rk == 0) {
	/* right is a scalar; we need to add a new vector for shape, as 
	 right may not (won't?) have one */
	node->shape.n = ictop;
	addicon(1);
      } else {
	/* right is not a scalar, so we can copy it's shape to start */
	node->shape.n = cpivec(RIGHT->shape.n, rk, -1);
      }
      if (rk == 0) {
	/* scalar right, always matches any left, result is a vector */
	iconsts[node->shape.n] = c;
      } else if (rkl == 0) {
	/* scalar left, always matches any right, result is shape of
	     right. sws: unless left is 0, in which case we have zilde */
	if (c == 0)
	  iconsts[node->shape.n] = c;
      } else {
	/* neither right nor left is scalar */
	if (node->info & FIRSTAXIS) {
	  if (sh != iconsts[node->shape.n]) {
	    fprintf(stderr, "compress, firstaxis");
	    fprintf(stderr, ", left rank(%d), right rank(%d)",
		    rkl,rk);
	    fprintf(stderr, ", left shape(%d), right shape(%d)\n",
		    sh, iconsts[node->shape.n]);
	    error("length error");
	  }
	  iconsts[node->shape.n] = c;
	} else if (node->info & LASTAXIS) {
	  if (sh != iconsts[node->shape.n + rk - 1]) {
	    fprintf(stderr, "compress, lastaxis");
	    fprintf(stderr, ", left rank(%d), right rank(%d)",
		    rkl,rk);
	    fprintf(stderr, ", left shape(%d), right shape(%d)\n",
		    sh, iconsts[node->shape.n + rk - 1]);
	    error("length error");
	  }
	  iconsts[node->shape.n + rk - 1] = c;
	} else {
	  /* neither first or last axis, but must be known */
	  if (indxorgin != DEFAULTINDEX)
	    j = iconsts[AXIS->values.n] - indxorgin;
	  else
	    j = iconsts[AXIS->values.n] - 1;/* default is 1 */
	  if (sh != iconsts[node->shape.n + j]) {
	    fprintf(stderr, "compress, axis %d", j);
	    fprintf(stderr, ", left rank(%d), right rank(%d)",
		    rkl,rk);
	    fprintf(stderr, ", left shape(%d), right shape(%d)\n",
		    sh, iconsts[node->shape.n + j]);
	    error("length error");
	  }
	  iconsts[node->shape.n + j] = c;
	}
      }
    }
    break;

  case EXPAND:
    doinf(RIGHT, 0);
    infaxis(node);
    doinf(LEFT, 0);
    /* first some error checks */ 
    if ((LEFT->info & TYPEKNOWN) && !typemake(LEFT->type.n, APLC_BOOL))
      error("bit type required for expansion");
    /* if ((LEFT->info & RANKKNOWN) && (LEFT->rank.n > 1))*/
    if (isnot_vector(LEFT))
      error("vector required for expansion");
    /* now put the right info into the current node */
    if (RIGHT->info & TYPEKNOWN) {
      node->type.n = RIGHT->type.n;
      node->info |= TYPEKNOWN;
    }
    if (RIGHT->info & RANKKNOWN) {
      node->rank.n = RIGHT->rank.n;
      if (node->rank.n == 0)
	node->rank.n = 1;
      node->info |= RANKKNOWN;
    }
    /* now refine */
    if ( (LEFT->info & VALUESKNOWN) && 
	 (RIGHT->info & SHAPEKNOWN) &&
	 ( (node->info & FIRSTAXIS) || (node->info & LASTAXIS) ||
	   Axisval_known ) ) {
      node->info |= SHAPEKNOWN;
      i = LEFT->values.n;
      /* determine size, in c, by counting nonzero entries */
      rkl = iconsts[LEFT->rank.n];
      if (rkl == 0) {
	/* left is a scalar */
	c = iconsts[i];
	sh = 1;
      } else {
	/* left is not a scalar */
	c = 0;
	sh = iconsts[LEFT->shape.n];
	for (j = sh - 1; j >= 0; j--)
	  if (iconsts[i + j])
	    c++;
      }
      rk = RIGHT->rank.n;
      if (rk == 0) {
	/* right is a scalar */
	node->shape.n = ictop;
	addicon(1);
      } else {
	/* right is not a scalar */
	node->shape.n = cpivec(RIGHT->shape.n, rk, -1);
      }
      /* fprintf(stderr,"rkl = %d, rk = %d\n",rkl,rk);
      fprintf(stderr,"c = %d, sh = %d\n",c,sh); */
      if (rk == 0) {
	/* scalar right, matches any left count, result is vector */
	iconsts[node->shape.n] = sh;
      } else {
	if (node->info & FIRSTAXIS) {
	  if (c != iconsts[node->shape.n]) {
	    fprintf(stderr,
	    "expand, firstaxis, left count(%d), right shape(%d)\n",
		    c, iconsts[node->shape.n]);
	    error("length error");
	  }
	  iconsts[node->shape.n] = sh;
	} else if (node->info & LASTAXIS) {
	  if (c != iconsts[node->shape.n + rk - 1]) {
	    fprintf(stderr,
		    "expand, lastaxis, left count(%d), right shape(%d)\n",
		    c, iconsts[node->shape.n + rk - 1]);
	    error("length error");
	  }
	  iconsts[node->shape.n + rk - 1] = sh;
	} else {
	  /* neither first nor last axis, but known */
	  if (indxorgin != DEFAULTINDEX)
	    j = iconsts[AXIS->values.n] - indxorgin;
	  else
	    j = iconsts[AXIS->values.n] - 1;/* default is 1 */
	  if (c != iconsts[node->shape.n + j]) {
	    fprintf(stderr,
		    "expand, axis %d, left count(%d), right shape(%d)\n",
		    j, c, iconsts[node->shape.n + j]);
	    error("length error");
	  }
	  iconsts[node->shape.n + j] = sh;
	}
      }
    }
    break;

   case CIVEC:
    doinf(RIGHT, 0);
    if ((RIGHT->info & TYPEKNOWN) && 
	(!typemake(APLC_INT, RIGHT->type.n))) {
      /* allow known zilde */
      if ( (RIGHT->info & RANKKNOWN) &&
	   (RIGHT->info & SHAPEKNOWN) &&
	   (ksize(RIGHT) == 0) ) {
	;/* ok */
      } else 
	error("integer vector required (1)");
    }
    /*    if ((RIGHT->info & RANKKNOWN) &&
	(!(ranktest(RIGHT, 0) || ranktest(RIGHT, 1))))*/
    if (isnot_vector(RIGHT))
      error("integer vector required (2)");
    node->type.n = APLC_INT;
    node->rank.n = 1;
    node->info |= (TYPEKNOWN | RANKKNOWN);
    copychild(node, RIGHT, 0, 0, 1, 1);
    break;

  case CVEC:
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1, 0, 1, 1);
    /*    if (RIGHT->info & RANKKNOWN)
	  if (!(ranktest(RIGHT, 0) || ranktest(RIGHT, 1)))*/
    if (isnot_vector(RIGHT))
      error("vector required");
    node->rank.n = 1;
    node->info |= RANKKNOWN;
    break;

    /* sws  used in iota, roll, some axis */
    /* so vector of length 1 is ok */
  case CISCALAR:
    doinf(RIGHT, 0);
    if ((RIGHT->info & TYPEKNOWN) &&
	(!typemake(APLC_INT, RIGHT->type.n)))
      error("integer scalar required (1)");
    /* sws   allow rank 1 objects to get through */
    if (RKisknown(RIGHT)) {
      if (ranktest(RIGHT, 0));	     /* ok */
      else if (ranktest(RIGHT, 1)) {
	if (RIGHT->info & SHAPEKNOWN) {
	  if (!(1 == iconsts[RIGHT->shape.n]))
	    error("integer scalar required (2)");
	}
      } else
	error("integer scalar required (2)");
    }
    node->type.n = APLC_INT;
    node->rank.n = 0;
    /*node->shape.n = addicon(1);*/
    node->shape.n = 1;
    node->info |= (TYPEKNOWN | RANKKNOWN | SHAPEKNOWN);
    copychild(node, RIGHT, 0, 0, 0, 1);
    break;

    /* sws  only used in axis, where a vector with shape 1 will do */
  case CSCALAR:
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1, 0, 0, 1);
    /* sws   allow rank 1 objects to get through */
    if (RKisknown(RIGHT)) {
      if (ranktest(RIGHT, 0));	     /* ok */
      else if (ranktest(RIGHT, 1)) {
	if (RIGHT->info & SHAPEKNOWN) {
	  if (!(1 == iconsts[RIGHT->shape.n]))
	    error("scalar required");
	}
      } else
	error("scalar required");
    }
    node->rank.n = 0;
    /*node->shape.n = addicon(1);*/
    node->shape.n = 1;
    node->info |= (RANKKNOWN | SHAPEKNOWN);
    break;

  case DEAL:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    node->type.n = APLC_INT;
    node->rank.n = 1;
    node->info |= (TYPEKNOWN | RANKKNOWN);
    if (LEFT->info & VALUESKNOWN) {
      node->shape.n = LEFT->values.n;
      node->info |= SHAPEKNOWN;
    }
    break;

  case DECODE:
  case INNERCHILD:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    dsrtype(node->optype, node, LEFT, RIGHT);
    if (RKisknown(RIGHT) && RKisknown(LEFT)) {
      i = LEFT->rank.n;
      j = RIGHT->rank.n;
      node->rank.n = (i ? i - 1 : 0) + (j ? j - 1 : 0);
      node->info |= RANKKNOWN;
    }
    if ((RIGHT->info & SHAPEKNOWN) && (LEFT->info & SHAPEKNOWN)) {
      if ((i > 0) && (j > 0)) {
	if (iconsts[LEFT->shape.n + i - 1]
	    != iconsts[RIGHT->shape.n])
	  error("inner product shape conformability");
      }
      node->shape.n = cpivec(LEFT->shape.n, (i ? i - 1 : 0), -1);
      cpivec(RIGHT->shape.n + 1, (j ? j - 1 : 0), -1);
      node->info |= SHAPEKNOWN;
    }
    /* sws now store */
    copychild(STORE, LEFT, 1, 0, 0, 0);

    break;

  case DFORMAT:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    node->type.n = APLC_CHAR;
    node->info |= TYPEKNOWN;
    if (RIGHT->info & RANKKNOWN) {
      if (RIGHT->rank.n == 0)
	node->rank.n = 1;
      else
	node->rank.n = RIGHT->rank.n;
      node->info |= RANKKNOWN;
    }
    /* can try to generate shape as well, from left */
    break;

    /* matrix inverse - or someday perhaps pseudo inverse */
    /* based on monadic transpose */
  case DOMINO:
    doinf(RIGHT, 0);
    node->type.n = APLC_REAL;
    node->info |= TYPEKNOWN;
    copychild(node, RIGHT, 0, 1, 0, 0);
    if (RIGHT->info & SHAPEKNOWN) {
      node->shape.n = ictop;
      sh = RIGHT->shape.n;
      rk = RIGHT->rank.n;
      for (i = 1; i <= node->rank.n; i++)
	addicon(iconsts[sh + rk - i]);
      node->info |= SHAPEKNOWN;
    }
    break;

  case DROP:
  case GWDROP:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    if (is_scalar(RIGHT)) {
      copychild(node, RIGHT, 1, 0, 0, 0);
      /*fprintf(stderr, "scalar right\n");*/
      /* error("domain error - drop");*/
      if ( (LEFT->info & VALUESKNOWN) && (LEFT->info & SHAPEKNOWN) ) { 
	if (is_scalar(LEFT)) {	
	  /*fprintf(stderr, "scalar left\n");*/
	  if (iconsts[LEFT->values.n]) {
	    /* result is .iota 0 */
	    node->info |= SHAPEKNOWN;
	    node->info |= RANKKNOWN;
	    node->rank.n = 1;
	    node->shape.n = addicon(0);
	  } else {
	    /* left is 0, result is vector right */
	    node->info |= SHAPEKNOWN;
	    node->info |= RANKKNOWN;
	    node->rank.n = 1;
	    node->shape.n = addicon(1);
	    copychild(node, RIGHT, 0,0,0,1);
	  }
	} else {
	  /*fprintf(stderr, "non-scalar left\n");*/
	  /* non-scalar left, scalar right */
	  /* not done */

	}
      }
    } else { 
      copychild(node, RIGHT, 1, 1, 0, 0);
      if ((RIGHT->info & SHAPEKNOWN) && (LEFT->info & VALUESKNOWN)) {
	if (RIGHT->rank.n != iconsts[LEFT->shape.n])
	  error("conformability - drop");
	sh = RIGHT->shape.n;
	rt = LEFT->values.n;
	node->shape.n = ictop;
	for (i = 0; i < node->rank.n; i++) {
	  j = iconsts[sh + i] - abs(iconsts[rt + i]);
	  /* make sure we don't drop too much */
	  j = (j < 0) ? 0 : j;
	  addicon(j);
	}
	node->info |= SHAPEKNOWN;
      }
    }
    break;

  case DSOP:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    dsrtype(node->optype, node, LEFT, RIGHT);
    if (is_scalar(LEFT))
      copychild(node, RIGHT, 0, 1, 1, 0);
    else if (is_scalar(RIGHT))
      copychild(node, LEFT, 0, 1, 1, 0);
    else if (RKisknown(RIGHT) && RKisknown(LEFT)) {
      i = LEFT->rank.n;
      j = RIGHT->rank.n;
      if (i != j)
	error("[trs] dsop rank error");
      node->rank.n = RIGHT->rank.n;
      node->info |= RANKKNOWN;
      if ((LEFT->info & SHAPEKNOWN)
	  && (RIGHT->info & SHAPEKNOWN)) {
	for (i--; i > -0; i--)
	  if (iconsts[LEFT->shape.n + i] !=
	      iconsts[RIGHT->shape.n + i])
	    error("dsop shape error");
	node->shape.n = RIGHT->shape.n;
	node->info |= SHAPEKNOWN;
      }
    }
    break;

  case DTRANS:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    copychild(node, RIGHT, 1, 0, 0, 0);
#if 0
    /* right can be scalar if left is zilde */
    if (is_scalar(RIGHT))
      error("conformability - dyadic transpose");
#endif
    if (LEFT->info & VALUESKNOWN)
      dytrans(node);
    break;

  case EMPTSEMI:
    node->type.n = APLC_INT;
    node->rank.n = 1;
    node->info |= (TYPEKNOWN | RANKKNOWN);
    if ((node->a.axis)->info & SHAPEKNOWN) {
      node->shape.n = (node->a.axis)->shape.n + node->ptr1;
      node->info |= SHAPEKNOWN;
    }
    break;

  case ENCODE:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    if (RKisknown(RIGHT) && RKisknown(LEFT)) {
      node->rank.n = LEFT->rank.n + RIGHT->rank.n;
      node->info |= RANKKNOWN;
    }
    if ((RIGHT->info & SHAPEKNOWN) && (LEFT->info & SHAPEKNOWN)) {
      /* copy shapes, one after the other into icon list */
      /* point to start */
      node->shape.n = cpivec(LEFT->shape.n, LEFT->rank.n, -1);
      cpivec(RIGHT->shape.n, RIGHT->rank.n, -1);
      node->info |= SHAPEKNOWN;
    }
    break;

  case EPSILON:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    node->type.n = APLC_BOOL;
    node->info |= TYPEKNOWN;
    copychild(node, LEFT, 0, 1, 1, 0);
    break;

  case EXECUTE:
    doinf(RIGHT, 0);
    break;

  case FIDENT:
    if (RIGHT != NILP)
      doinf(RIGHT, 0);
    if (LEFT != NILP)
      doinf(LEFT, 0);
    break;

  case FORMAT:
    doinf(RIGHT, 0);
    node->type.n = APLC_CHAR;
    node->info |= TYPEKNOWN;
    if (RIGHT->info & TYPEKNOWN) {
      if (RIGHT->type.n == APLC_CHAR) {
	if (RIGHT->info & RANKKNOWN) {
	  node->rank.n = RIGHT->rank.n;
	  node->info |= RANKKNOWN;
	}
	if (RIGHT->info & SHAPEKNOWN) {
	  node->shape.n = RIGHT->shape.n;
	  node->info |= SHAPEKNOWN;
	}
      } else {
	if (RIGHT->info & RANKKNOWN) {
	  if (RIGHT->rank.n == 0)
	    node->rank.n = 1;
	  else
	    node->rank.n = RIGHT->rank.n;
	  node->info |= RANKKNOWN;
	}
      }
    }
    break;

  case GO:
    if (!top)
      cant("non-top level branch");
    doinf(RIGHT, 0);
    if (RIGHT->rank.n > 1)
      error("scalar required");
    if (RIGHT->nodetype == LCON) {
      node->values.n = RIGHT->values.n;
    }
    break;

    /*- sws
      this only does something for intra proceedural analysis, but I
      suspect this will have to be changed... */
  case IDENT:
#ifdef INTRA
    doident(node); /* sws  moved to intra.c */
#endif
    break;

  case INDEX:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    node->type.n = APLC_INT;
    node->info |= TYPEKNOWN;
    copychild(node, RIGHT, 0, 1, 1, 0);
    break;

  case INNER:
    doinf(RIGHT, 0);
    dsrtype(node->optype, node, RIGHT, RIGHT);
    copychild(node, RIGHT, 0, 1, 1, 0);
    break;

  case IOTA:
    doinf(RIGHT, 0);
    if ((RIGHT->info & TYPEKNOWN) && (!typemake(APLC_INT, RIGHT->type.n)))
      error("iota on non-integer");
      /*    if ((RIGHT->info & RANKKNOWN) && (RIGHT->rank.n > 0))*/
    if (isnot_scalar(RIGHT))
      error("iota on non-scalar");
    if (RIGHT->info & VALUESKNOWN) {
      if (iconsts[RIGHT->values.n] < 0)
	error("iota on negative value");
      node->shape.n = RIGHT->values.n;
      node->info |= SHAPEKNOWN;
    }
    node->type.n = APLC_INT;
    node->rank.n = 1;
    node->info |= (TYPEKNOWN | RANKKNOWN);
    break;

  case LCON:
#ifdef INTRA
    /*-- sws  label;      write down jump targets */
    dolcon(node);
#endif
    break;

  case LAM:
    error("laminate not implemented yet");
    /* sws   it is actually, in cat... */
    break;

    /* sws  solution to linear equations */
    /* based on decode */
  case MSOLVE:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    node->type.n = APLC_REAL;
    node->info |= TYPEKNOWN;
    if (RKisknown(RIGHT) && RKisknown(LEFT)) {
      i = LEFT->rank.n;
      j = RIGHT->rank.n;
      node->rank.n = (i ? i - 1 : 0) + (j ? j - 1 : 0);
      node->info |= RANKKNOWN;
      if (i > 2)
	error("[trs] rank error: msolve left argument");
      if (j > 2)
	error("[trs] rank error: msolve right argument");
    }
    if ((RIGHT->info & SHAPEKNOWN) && (LEFT->info & SHAPEKNOWN)) {
      if ((i > 0) && (j > 0)) {
	if (iconsts[LEFT->shape.n]
	    != iconsts[RIGHT->shape.n])
	  error("length error: msolve argument compatibility");
      }
    }
    if (RIGHT->info & SHAPEKNOWN) {
      if (j > 0) {
	if (iconsts[RIGHT->shape.n]
	    < iconsts[RIGHT->shape.n + j - 1])
	  error("length error: msolve right argument");
      }
      node->shape.n =
	cpivec(RIGHT->shape.n + 1, (j ? j - 1 : 0), -1);
      cpivec(LEFT->shape.n + 1, (i ? i - 1 : 0), -1);
      node->info |= SHAPEKNOWN;
    }
    break;

  case MSOP:
    doinf(RIGHT, 0);
    rt = APLC_UKTYPE;
    switch(node->optype) {
    default:
      caserr("doinf", node->nodetype);
      break;
    case APLC_NOT:
      rt = APLC_BOOL;
      break;
    case APLC_ABS:
      /* if (RIGHT->info & TYPEKNOWN)*/
      /* could be any - don't force real in that case */
      if ( TYPEisknown(RIGHT) )
	rt = min(APLC_REAL, RIGHT->type.n);
      /* type for z, q, is real */
      break;
    case APLC_PLUS:
    case APLC_MINUS:
    case APLC_FACT:
      if (RIGHT->info & TYPEKNOWN)
	rt = RIGHT->type.n;
      break;
    case APLC_TIMES:
    case APLC_FLOOR:
    case APLC_CEIL:
      /* rt = APLC_INT;*/
      if ( TYPEisknown(RIGHT) ) {
	switch(RIGHT->type.n) {
	default:
	  break;
	case APLC_BOOL:
	case APLC_INT:
	case APLC_REAL:
	  rt = APLC_INT;
	  break;
	case APLC_COMPLEX:
	  rt = APLC_COMPLEX;
	  break;
	case APLC_QUAT:
	  rt = APLC_QUAT;
	  break;
	case APLC_OCT:
	  rt = APLC_OCT;
	  break;
	}
      }
      break;
    case APLC_DIVIDE:
    case APLC_EXP:
    case APLC_LOG:
    case APLC_CIRCLE:
      /* rt = APLC_REAL;*/
      if ( TYPEisknown(RIGHT) )
	rt = max(APLC_REAL, RIGHT->type.n);
      break;
    }
    if (rt != APLC_UKTYPE) {
      node->type.n = rt;
      node->info |= TYPEKNOWN;
    }
    copychild(node, RIGHT, 0, 1, 1, 0);
    break;

  case OUTER:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    dsrtype(node->optype, node, LEFT, RIGHT);
    outershape(node);
    break;

  case RAVEL:
    doinf(RIGHT, 0);
    if (RIGHT->info & TYPEKNOWN) {
      node->type.n = RIGHT->type.n;
      node->info |= TYPEKNOWN;
    }
    node->rank.n = 1;
    node->info |= RANKKNOWN;
    if (RIGHT->info & SHAPEKNOWN) {
      node->shape.n = addicon(numin(RIGHT));
      node->info |= SHAPEKNOWN;
    }
    if (RIGHT->info & VALUESKNOWN) {
      node->values.n = RIGHT->values.n;
      node->info |= VALUESKNOWN;
    }
    break;

  case REDUCE:
    infaxis(node);
    doinf(RIGHT, 0);
    if (RKisknown(RIGHT)) {
      if (RIGHT->rank.n == 0) {
	/* right is a scalar, result is right */
	node->rank.n = 0;
      } else {
	node->rank.n = RIGHT->rank.n - 1;
      }
      node->info |= RANKKNOWN;
      if (node->rank.n == 0) {
	/* vector or scalar right, scalar result */
	/*node->shape.n = addicon(1);*/
	node->shape.n = 1;
	node->info |= SHAPEKNOWN;
      }
    }
    if (RIGHT->info & SHAPEKNOWN) {
      if (RIGHT->rank.n == 1)
	; /* scalar result, already did it above */
      else if (node->info & FIRSTAXIS) {
	node->shape.n = RIGHT->shape.n + 1;
	node->info |= SHAPEKNOWN;
      } else if (node->info & LASTAXIS) {
	node->shape.n = RIGHT->shape.n;
	node->info |= SHAPEKNOWN;
      }
      /* only do type inferencing if right isn't a singleton */
      if (RIGHT->size.n > 1)
	dsrtype(node->optype, node, RIGHT, RIGHT);
      else 
	copychild(node, RIGHT, 1,0,0,0);
    }
    break;

  case REVERSE:
    infaxis(node);
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1, 1, 1, 0);
    break;

  case RESHAPE:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    if (RIGHT->info & TYPEKNOWN) {
      node->type.n = RIGHT->type.n;
      node->info |= TYPEKNOWN;
    }
    if (LEFT->info & SHAPEKNOWN) {
      node->rank.n = iconsts[LEFT->shape.n];
      node->info |= RANKKNOWN;
    }
    if (LEFT->info & VALUESKNOWN) {
      node->shape.n = LEFT->values.n;
      node->info |= SHAPEKNOWN;
      if (RIGHT->info & SHAPEKNOWN)
	if ((numin(RIGHT) >= numin(node)) &&
	    (RIGHT->info & VALUESKNOWN)) {
	  node->values.n = RIGHT->values.n;
	  node->info |= VALUESKNOWN;
	}
    }
    break;

  case RHO:
    node->type.n = APLC_INT;
    node->rank.n = 1;
    node->info |= (TYPEKNOWN | RANKKNOWN);
    doinf(RIGHT, 0);
    if (RKisknown(RIGHT)){
      node->shape.n = addicon(RIGHT->rank.n);
      node->info |= SHAPEKNOWN;
    }
    if (RIGHT->info & SHAPEKNOWN) {
      node->values.n = RIGHT->shape.n;
      node->info |= VALUESKNOWN;
    }
    break;

    /* rank */
  case RHORHO:
    node->type.n = APLC_INT;
    node->rank.n = 0;
    node->shape.n = addicon(1);
    node->info |= (TYPEKNOWN | RANKKNOWN | SHAPEKNOWN);
    doinf(RIGHT, 0);
    if (RKisknown(RIGHT)){
      node->values.n = addicon(RIGHT->rank.n);
      node->info |= VALUESKNOWN;
    }
    break;

  case ROLL:
    doinf(RIGHT, 0);
    if ( (RIGHT->info & TYPEKNOWN) && (!typemake(APLC_INT, RIGHT->type.n)) )
      error("integer value required");
    node->type.n = APLC_INT;
    node->info |= TYPEKNOWN;
    copychild(node, RIGHT, 0, 1, 1, 0);
    break;

  case ROTATE:
    doinf(RIGHT, 0);
    infaxis(node);
    doinf(LEFT, 0);
    copychild(node, RIGHT, 1, 1, 1, 0);
    break;

  case SCAN:
    doinf(RIGHT, 0);
    infaxis(node);
    scantype(node->optype, node, RIGHT);
    copychild(node, RIGHT, 0, 1, 1, 0);
    break;

  case SM:
    if (RIGHT->nodetype == EMPTSEMI) {
      RIGHT->a.axis = node->a.axis;
      RIGHT->ptr1 = node->ptr1;
    }
    doinf(RIGHT, 0);
    if (LEFT != NILP) {
      LEFT->a.axis = node->a.axis;
      doinf(LEFT, 0);
    }
    if (LEFT == NILP)
      copychild(node, RIGHT, 0, 1, 1, 0);
    else
      outershape(node);
    break;

  case SORT:
    doinf(RIGHT, 0);
    node->type.n = APLC_INT;
    node->rank.n = 1;
    node->info |= (TYPEKNOWN | RANKKNOWN);
    copychild(node, RIGHT, 0, 0, 1, 0);
    break;

  case SUB:
    /* LR order is ok here. left is id, right is [list] */ 
    doinf(LEFT, 0);
    RIGHT->a.axis = LEFT;
    doinf(RIGHT, 0);
    copychild(node, LEFT, 1, 0, 0, 0);
    copychild(node, RIGHT, 0, 1, 1, 0);
    break;

  case SUBASSIGN:
    doinf(RIGHT, 0);
    /* ordering of L A is ok here; subid, sublist */ 
    doinf(LEFT, 0);
    AXIS->a.axis = LEFT;
    /* type of node itself is changed to right */
    /* mergetype(node, LEFT, RIGHT);*/
    if (RIGHT->info & TYPEKNOWN) {
      node->type.n = RIGHT->type.n;
      node->info |= TYPEKNOWN;
    }      
    doinf(AXIS, 1);
    mergetype(STORE, LEFT, RIGHT);
    /* sws  now get rank and shape, if available from left (ident) */
    /* probably not a good idea... */
    /* copychild(STORE, LEFT, 0, 1, 1, 0);*/
    /* sws  now deal with node itself 
       - the node shape comes from the right
       - if the right is a scalar, and axis is not, the assignment works
       - this can be extended to singletons also
       - hence to do error checking need all shapes 
     */
    if ( RKisknown(RIGHT) ){
      node->rank.n = RIGHT->rank.n;
      node->info |= RANKKNOWN;
      if ( RIGHT->info & SHAPEKNOWN ) {
	node->shape.n = RIGHT->shape.n;
	node->info |= SHAPEKNOWN;
	/* we can perhaps do some error checking */
	if ( RKisknown(AXIS) && (AXIS->info & SHAPEKNOWN) ) {
	  /* know everything, so check */
	  /* singleton right matches anything */
	  if ( 1 !=ksize(RIGHT) ) {
	    /* not a singleton - normal rank/shape checks */
	    if ( RIGHT->rank.n != AXIS->rank.n )
	      error("[trs] sub assignment rank error");	      
	    /* shape checks ... */
	  }
	}
      }
    } else if ( RKisknown(AXIS) ) {
      /* ok, right rank isn't known 
	 - so only use axis if we're sure we don't have a singleton
	 */
      if (AXIS->info & SHAPEKNOWN) {
	/* know all axis shape */
	if (1 != ksize(AXIS) ) {
	  /* not a singleton */
	  node->rank.n = AXIS->rank.n;
	  node->info |= RANKKNOWN;
	  node->shape.n = AXIS->shape.n;
	  node->info |= SHAPEKNOWN;
	}
      }
    }
    /* sws why isn't this in SUB as well? requires known left rank ? */
    if ( (LEFT->rank.n != NORANK) && (LEFT->rank.n != ANYRANK) &&
	(LEFT->rank.n != AXIS->ptr1 + 1) ) {
      fprintf(stderr, "left rank= %d, subscripts: %d\n",
	  LEFT->rank.n, AXIS->ptr3 + 1);
      error("[trs] sub assignment rank error");
    }

#ifdef INTRA
    /*- note that type can change in sub assignment,
    for example int to real */
    doassign(LEFT->a.namep, STORE);
#endif

    break;

  case DSYSFUN:
  case ESYSFUN:
  case MSYSFUN:
    if (RIGHT != NILP)
      doinf(RIGHT, 0);
    if (LEFT != NILP)
      doinf(LEFT, 0);
    optype = (enum sysvars) node->optype;
    switch(optype) {
    default:
      node->type.n = APLC_ANY;
      break;
    case SYS_AZ:
      /* output is a real array */
      node->type.n = APLC_REAL;
      node->info |= TYPEKNOWN;
      if (LEFT != NILP) {
	/* ... */
      } else {
	/* if right type and shape are known 
	 - then shape is known */
	if ( TYPEisknown(RIGHT) && (RIGHT->info & SHAPEKNOWN) ) {
	  switch (RIGHT->type.n) {
	  default:
	    break;
	  case APLC_BOOL:
	  case APLC_INT:
	  case APLC_REAL:
	  case APLC_CHAR:
	    /* no change */
	    node->rank.n = RIGHT->rank.n;
	    node->info |= RANKKNOWN;
	    node->shape.n = RIGHT->shape.n;
	    node->info |= SHAPEKNOWN;
	    break;
	  case APLC_COMPLEX:
	    node->info |= RANKKNOWN;
	    node->info |= SHAPEKNOWN;
	    rk = RIGHT->rank.n;
	    if (rk == 0) {
	      /* right is scalar, so vector, length 2 */
	      node->rank.n = 1;
	      node->shape.n = ictop;
	      addicon(2);
	    } else {
	      node->rank.n = rk+1;
	      node->shape.n = ictop;
	      addicon(2);
	      for (i=0; i<rk; i++) {
		addicon( iconsts[RIGHT->shape.n +i] );
	      }
	    }
	    break;
	  case APLC_QUAT:
	    break;
	  case APLC_OCT:
	    break;
	  }
	}
      }
      break;
    case SYS_ZA:
      /* if right shape is known, 
	 - then type and shape are known */
      break;
    case SYS_FCNTL:
      if ( TYPEisknown(LEFT) && (LEFT->type.n != APLC_CHAR) )
	error("character left argument required");
      if (isnot_vector(LEFT))
	error("scalar/vector left argument required");
      if ( (RIGHT->info & TYPEKNOWN) && (!typemake(APLC_INT, RIGHT->type.n)) )
	error("integer right argument required");
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->rank.n = 1;
      node->type.n = APLC_INT;
      node->info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_LSEEK:
      if ( TYPEisknown(LEFT) && (LEFT->type.n != APLC_CHAR) )
	error("character left argument required");
      if (isnot_scalar(LEFT))
	error("scalar left argument required");
    case SYS_CL:
      if ( (RIGHT->info & TYPEKNOWN) && (!typemake(APLC_INT, RIGHT->type.n)) )
	error("integer right argument required");
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->rank.n = 1;
      node->type.n = APLC_INT;
      node->info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_OP: 
      if (LEFT != NILP) {
#if 0
	if ( TYPEisknown(LEFT) && (LEFT->type.n != APLC_CHAR) )
	  error("character left argument required");
#endif
	if (isnot_vector(LEFT))
	  error("vector left argument required");
      }
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->rank.n = 1;
      node->type.n = APLC_INT;
      node->info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_SYS:
    case SYS_FREE:
    case SYS_VTYPE:
      node->rank.n = 0;
      node->type.n = APLC_INT;
      node->info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_FI:
      break;
    case SYS_VI:
      node->type.n = APLC_BOOL;
      break;
    case SYS_DL:
      node->rank.n = 0;
      node->type.n = APLC_REAL;
      node->info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_FREAD:
      if (isnot_vector(RIGHT))
	error("scalar/vector right argument required");
      node->rank.n = 1;
      node->type.n = APLC_CHAR;
      node->info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_FWRITE:
    case SYS_FAPPEND:
      if ( TYPEisknown(RIGHT) && (RIGHT->type.n != APLC_CHAR) )
	error("character right argument required");
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->rank.n = 0;
      node->type.n = APLC_INT;
      node->info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_READLINE:
      if (isnot_vector(RIGHT))
	error("scalar/vector right argument required");
      node->rank.n = 1;
      node->type.n = APLC_CHAR;
      node->info |= (TYPEKNOWN | RANKKNOWN);
      break;
    case SYS_SPAWN:
      /* LEFT may be scalar INT or vector or array CHAR */
      if ( TYPEisknown(RIGHT) && (RIGHT->type.n != APLC_CHAR) )
	error("character right argument required");
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->rank.n = 1;
      node->type.n = APLC_INT;
      node->info |= (TYPEKNOWN | RANKKNOWN);
      break;

    case SYS_PIPE:
      if ( TYPEisknown(LEFT) && (LEFT->type.n != APLC_CHAR) )
	error("character left argument required");
	/*      if ((LEFT->info & RANKKNOWN) && (LEFT->rank.n > 1))*/
      if (isnot_vector(LEFT))
	error("vector left argument required");
      if ((RIGHT->info & TYPEKNOWN) && (RIGHT->type.n != APLC_CHAR))
	error("character right argument required");
      /*      if ((RIGHT->info & RANKKNOWN) && (RIGHT->rank.n > 1))*/
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->rank.n = 1;
      node->type.n = APLC_CHAR;
      node->info |= (TYPEKNOWN | RANKKNOWN);
      break;

    case SYS_SS:
      if ( TYPEisknown(LEFT) && (LEFT->type.n != APLC_CHAR) )
	error("character left argument required");
	/*      if ((LEFT->info & RANKKNOWN) && (LEFT->rank.n > 1))*/
      if (isnot_vector(LEFT))
	error("vector left argument required");
      if ( TYPEisknown(RIGHT) && (RIGHT->type.n != APLC_CHAR) )
	error("character right argument required");
      /*      if ((RIGHT->info & RANKKNOWN) && (RIGHT->rank.n > 1))*/
      if (isnot_vector(RIGHT))
	error("vector right argument required");
      node->rank.n = 1;
      node->type.n = APLC_BOOL;
      node->info |= (TYPEKNOWN | RANKKNOWN);
      break;
    }
    break;

  case ASYSVAR:
  case SYSVAR:
    if (RIGHT != NILP)
      doinf(RIGHT, 0);
    optype = (enum sysvars) node->optype;
    if (optype == SYS_PP || optype == SYS_PW || optype == SYS_RL || optype == SYS_IO) {
      node->type.n = APLC_INT;
      node->rank.n = 0;
      node->shape.n = addicon(1);
      node->info |= TYPEKNOWN;
      node->info |= RANKKNOWN;
      node->info |= SHAPEKNOWN;
    } else if (optype == SYS_OMAP) {
      node->type.n = APLC_INT;
      node->rank.n = 1;
      node->shape.n = addicon(2);
      node->info |= TYPEKNOWN;
      node->info |= RANKKNOWN;
      node->info |= SHAPEKNOWN;
    } else if (optype == SYS_ARG) {
      node->type.n = APLC_CHAR;
      node->rank.n = 2;
      node->info |= TYPEKNOWN;
      node->info |= RANKKNOWN;
    } else if (optype == SYS_TS) {
      node->type.n = APLC_INT;
      node->rank.n = 1;
      node->shape.n = addicon(7);
      node->info |= TYPEKNOWN;
      node->info |= RANKKNOWN;
      node->info |= SHAPEKNOWN;
    } else
      node->type.n = APLC_ANY;
    break;

  case TAKE:
  case GWTAKE:
    doinf(RIGHT, 0);
    doinf(LEFT, 0);
    /* get - type from right
           - rank from right if not scalar */
    if ( isnot_scalar(RIGHT) )
      copychild(node, RIGHT, 1, 1, 0, 0);
    else
      copychild(node, RIGHT, 1, 0, 0, 0);
    /* if rank still not known, may get it from left shape */
    if ( ( ! (node->info & RANKKNOWN) )  
	 && (LEFT->info & RANKKNOWN) 
	 && (LEFT->info & SHAPEKNOWN) ) {
      /* get rank from left size */
      if (LEFT->rank.n == 0)
	node->rank.n = 1;
      else 
	node->rank.n = iconsts[LEFT->shape.n];
      node->info |= RANKKNOWN;
    }
    if (LEFT->info & VALUESKNOWN) {
      node->shape.n = ictop;
      rt = LEFT->values.n;
      for (i = 0; i < node->rank.n; i++)
	if (iconsts[rt + i] < 0)
	  addicon(-iconsts[rt + i]);
	else
	  addicon(iconsts[rt + i]);
      node->info |= SHAPEKNOWN;
    }
    break;

  case TCAV:
    break;

  case TRANS:
    doinf(RIGHT, 0);
    copychild(node, RIGHT, 1, 1, 0, 0);
    if (RIGHT->info & SHAPEKNOWN) {
      node->shape.n = ictop;
      sh = RIGHT->shape.n;
      rk = RIGHT->rank.n;
      for (i = 1; i <= node->rank.n; i++)
	addicon(iconsts[sh + rk - i]);
      node->info |= SHAPEKNOWN;
    }
    break;
  }

  /* just in case we haven't caught it already, catch scalars here 
     - this shouldn't be necessary, but some code does refer to
       shape.n for scalars
   */
  if (is_scalar(node)) {
#if TDEBUG
    /* info for debugging */ 
    fprintf(stderr, "scalar shape.n = %d, shapeknown %d, node %d %s\n", 
	    node->shape.n, node->info & SHAPEKNOWN, 
	    node->nodetype, prtoken(node->nodetype));
#endif
    if (0 == node->shape.n)
      node->shape.n = addicon(1);
    node->info |= SHAPEKNOWN;
  }
  /* ensure that the size is set if it is known */
  if (node->info & SHAPEKNOWN)
    node->size.n = ksize(node);
}


/* cpivec - copy an integer vector, skipping a position */
int
cpivec(int start, int size, int pos)
{
  int i, k;

  k = ictop;
  for (i = 0; i < size; i++)
    if (i + 1 != pos)
      addicon(iconsts[start + i]);
  return (k);
}

/* doesn't know about laminate... yet */
/* catshape - determine shape and rank information for catenate 
              only works for last axis currently - can improve this
*/
void
catshape(struct node * node)
{
  int i, j, ls, rs;

  if ( RKisknown(LEFT) && RKisknown(RIGHT) ) {
    i = LEFT->rank.n;
    j = RIGHT->rank.n;
    if (i == 0)
      if (j == 0) {
	node->rank.n = 1;
	node->shape.n = addicon(2);
	node->info |= SHAPEKNOWN;
      } else
	node->rank.n = RIGHT->rank.n;
    else if ((j == 0) || (i == j) || (i == j + 1))
      node->rank.n = LEFT->rank.n;
    else if (i + 1 == j)
      node->rank.n = RIGHT->rank.n;
    else {
      fprintf(stderr, "\n[catshape] ");
      fprintf(stderr, "left rank= %d, right rank= %d\n", i, j);
      error("[trs] catenate rank error");
    }
    node->info |= RANKKNOWN;
    /* now we have rank, try shape */
    if ((LEFT->info & SHAPEKNOWN) && (RIGHT->info & SHAPEKNOWN)) {
      ls = LEFT->shape.n;
      rs = RIGHT->shape.n;
      if (node->info & LASTAXIS) {
	if (i == 0)		     /* i and j are still valid */
	  if (j == 0)
	    ; /* did it already above */
	  else {
	    node->shape.n = cpivec(rs, j, -1);
	    iconsts[node->shape.n + j - 1]++;
	    node->info |= SHAPEKNOWN;
	  }
	else if (j == 0) {
	  node->shape.n = cpivec(ls, i, -1);
	  iconsts[node->shape.n + i - 1]++;
	  node->info |= SHAPEKNOWN;
	} else if (i == j) {
	  node->shape.n = cpivec(ls, i, -1);
	  iconsts[node->shape.n + i - 1] += iconsts[rs + i - 1];
	  node->info |= SHAPEKNOWN;
	  /* warning, last axis assumed */
	  for (i -= 2; i >= 0; i--)
	    if (iconsts[ls + i] != iconsts[rs + i])
	      error("catenate conformability (1)");
	} else if (i + 1 == j) {
	  node->shape.n = cpivec(ls, i, -1);
	  iconsts[node->shape.n + i - 1]++;
	  node->info |= SHAPEKNOWN;
	  for (j -= 2; j >= 0; j--)
	    if (iconsts[ls + j] != iconsts[rs + j])
	      error("catenate conformability (2)");
	} else if (i == j + 1) {
	  node->shape.n = cpivec(rs, j, -1);
	  iconsts[node->shape.n + j - 1]++;
	  node->info |= SHAPEKNOWN;
	  for (i -= 2; i >= 0; i--)
	    if (iconsts[ls + i] != iconsts[rs + i])
	      error("catenate conformability (3)");
	} else
	  error("catenate conformability (4)");
      }
    }
  }
}

/* lamshape - determine shape and rank information for catenate 
              with known non-integer axis - laminate 
 */
void
lamshape(struct node * node)
{
  double ax;
#if 0
  int i, j;
  int maxrk;
#endif

  if (!(AXIS->info & VALUESKNOWN) )
    return;/* don't know enough */

  /* assume scalar for now - later should check */
  ax = rconsts[AXIS->values.n];/* the axis value */
#if 0
  fprintf(stderr,"\n[trs] lamshape, axis = %f", ax);
#endif
  if (ax < 0)
    error("catenate/laminate axis error (<0) ");

  if ( ! (RKisknown(LEFT) && RKisknown(RIGHT) ) )
    return;

#if 0
  /* broken somehow */
  i = LEFT->rank.n;
  j = RIGHT->rank.n;
  maxrk = max(i,j);
  if ( ax > 1.0 + maxrk )
    error("catenate/laminate axis error (>max)");

  if (maxrk == 0) {
    /* both scalars */
    node->rank.n = 1;
    node->shape.n = addicon(2);
    node->info |= SHAPEKNOWN;
    node->info |= RANKKNOWN;
    return;
  }
  node->rank.n = RIGHT->rank.n + 1;
  node->info |= RANKKNOWN;
  /* give up here for now - need index origin in general to determine 
     shape
   */
#endif
}

/* dytrans - compute rank and shape for dyadic transpose */
void
dytrans(struct node * node)
{
  int size, c, s, k, i, j, *vec, *shape;

  size = iconsts[LEFT->shape.n];
  vec = &iconsts[LEFT->values.n];
  c = 0;
  s = 1;
  for (i = 1; i <= size && s == 1; i++) {
    s = 0;
    for (j = 0; j < size; j++)
      if (vec[j] == i) {
	node->rank.n = i;
	c++;
	s = 1;
      }
  }
  node->info |= RANKKNOWN;
  if (c != size)
    error("dyadic transpose value error");
  if (!(RIGHT->info & SHAPEKNOWN))
    return;
  shape = &iconsts[RIGHT->shape.n];
  node->shape.n = ictop;
  for (i = 0; i < node->rank.n; i++) {
    k = 15000;
    for (j = 0; j < size; j++)
      if (vec[j] == i + 1 && shape[j] < k)
	k = shape[j];
    addicon(k);
  }
  node->info |= SHAPEKNOWN;
}

/* outershape - generate shape information for outer product and for
                semicolons
*/
void
outershape(struct node * node)
{
  if ((LEFT->info & RANKKNOWN) && (RIGHT->info & RANKKNOWN)) {
    /* sws  watch out for anyrank */
    if ((LEFT->rank.n != ANYRANK) && (RIGHT->rank.n != ANYRANK)) {
      node->rank.n = LEFT->rank.n + RIGHT->rank.n;
      node->info |= RANKKNOWN;
    } else {
      node->rank.n = ANYRANK;
      node->info |= RANKKNOWN;
    }
  }
  if ((LEFT->info & SHAPEKNOWN) && (RIGHT->info & SHAPEKNOWN)) {
    node->shape.n = cpivec(LEFT->shape.n, LEFT->rank.n, -1);
    cpivec(RIGHT->shape.n, RIGHT->rank.n, -1);
    node->info |= SHAPEKNOWN;
  }
}

/* end of trs.c */
