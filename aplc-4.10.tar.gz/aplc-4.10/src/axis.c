/*
	APL Compiler

	Code Generation routines dealing with axis
	tim budd

        sws
        Genencode added
        gencat removed

*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/
#include "parse.h"
#include "y_tab.h"
#include "gen.h"
#include <stdio.h>

extern int *iconsts;
extern struct node *zeronode;
extern int indxorgin;


/* functions */
static void cksh(int i, struct node * child, struct codetree * tree);


/* cksh - generate a test to check shape for non-scalar */
static void
cksh(int i, struct node * child, struct codetree * tree)
{
  ieqtree(i, gcond(child->rank.c,
	  gmon(deref, tree),
	  gicn(icnst, 1, APLC_INT)));
}

/*
	axies - generate code to produce the following values

	i - the position of the axis (zero based)
	e - the expansion vector value at position i (e sub i)
	s - the shape of the node at position i (s sub i)

	the argument i, e, and s contain the index registers into which the
	associated values are to be placed.  In all three cases if the
	value is zero no code is generated to place the value.
	One of i, e or s must be non-zero.
*/

void
axies(struct node * node, struct node * axis, struct node * child,
    int i, int e, int s)
{
  int r, sh, subi, v;

  if (is_scalar(child)) {
    if (i)
      seticon(i, 1);
    if (s)
      seticon(s, 1);
    if (e)
      seticon(e, 1);
    return;
  }
  if (i && (node->info & FIRSTAXIS)) {
    setizero(i);
    i = 0;
  }
  if (e && (node->info & LASTAXIS)) {
    seticon(e, 1);
    e = 0;
  }
  if (child->info & SHAPEKNOWN) {
    r = rankvalue(child);
    sh = shapevalue(child);
    if (node->info & FIRSTAXIS) {
      if (s) {
	seticon(s, iconsts[sh]);
	s = 0;
      }
      if (e) {
	seticon(e, ksize(child) / iconsts[sh]);
	e = 0;
      }
    } else if (node->info & LASTAXIS) {
      if (i) {
	if (r == 0)
	  seticon(i, 0);
	else
	  seticon(i, r - 1);
	i = 0;
      }
      if (s) {
	seticon(s, iconsts[sh + r - 1]);
	s = 0;
      }
    } else if ((axis->info & VALUESKNOWN) &&
	(indxorgin != DEFAULTINDEX)) {
      /* get value - compute s and e */
      v = iconsts[axis->values.n] - indxorgin;
      if (i) {
	seticon(i, v);
	i = 0;
      }
      if (s) {
	seticon(s, iconsts[sh + v]);
	s = 0;
      }
      if (e) {
	ieq(e);
	printf("aplc_esubi(%d, ", v);
	rns(child);
	rpseminl();/* ); */
	e = 0;
      }
    }
  }
  if (node->info & FIRSTAXIS) {
    if (s) {
      cksh(s, child, child->shape.c);
      s = 0;
    }
    if (e) {
      ieq(e);
      if ((child->info & RANKKNOWN) &&
	  (rankvalue(child) == 2)) {
	ctgen(gmon(deref, gsop(APLC_PLUS,
		    child->shape.c, gicn(icnst, 1, APLC_INT))));
	seminl();
      } else {
	printf("aplc_esubi(0, ");
	rns(child);
	rpseminl();/* ); */
      }
      e = 0;
    }
  } else if (node->info & LASTAXIS) {
    if (i) {
      if (child->info & RANKKNOWN) {
	if (rankvalue(child) == 0)
	  seticon(i, 0);
	else
	  seticon(i, rankvalue(child) - 1);
      } else {
	ieqtree(i, gsop(APLC_MINUS, child->rank.c,
		gicn(icnst, 1, APLC_INT)));
	iflp();
	printf("i%d < 0)\n", i);
	seticon(i, 0);
      }
      if (s) {
	cksh(s, child,
	     gsop(APLC_PLUS, child->shape.c,
		  gicn(iptr, i, 0)));
	s = 0;
      }
      i = 0;
    }
    if (s) {
      cksh(s, child,
	  gsop(APLC_PLUS, child->shape.c,
	      gsop(APLC_MINUS, child->rank.c,
		  gicn(icnst, 1, 0))));
      /* sws ???       */
      s = 0;
    }
  } else if (i || s || e) {
    switchbox(axis, SHAPE, 0);
    if (i) {
      ieqtree(i, gsop(APLC_MINUS, axis->values.c, gixorg()));
      subi = i;
    } else if ((axis->values.c)->cop == iptr) {
      subi = (axis->values.c)->c0.cindex;
    } else {
      subi = e;
      ieqtree(e, gsop(APLC_MINUS, axis->values.c, gixorg()));
    }
    if (s) {
      cksh(s, child,
	  gsop(APLC_PLUS, child->shape.c,
	      gicn(iptr, subi, 0)));
      s = 0;
    }
    if (e) {
      ieq(e);
      printf("aplc_esubi(i%d, ", subi);
      rns(child);
      rpseminl();/* ); */
      e = 0;
    }
    switchbox(axis, FINISH, 0);
  }
}

/*
	asubi -
		generate code to produce the i'th element of the
	subscripts corresponding to the given axis.  Note that knowing
	i is not necessary, as e[i] and s[i] encode everything important
*/
void
asubi(struct node * node, struct node * child, int iindex, int e, int s)
{
  if (is_vector(child) || is_scalar(child))
    printf("i%d", iindex);
  else if (node->info & FIRSTAXIS)
    printf("i%d / i%d", iindex, e);
  else if (node->info & LASTAXIS)
    printf("i%d %% i%d", iindex, s);
  else
    printf("(i%d / i%d) %% i%d", iindex, e, s);	/* jbww UKC 6/87 */
  /* printf("(i%d / i%d) % i%d", iindex, e, s); */
}

/* sws  special version of asubi, doesn't simplify for children as this
        can be missleading for unequal rank cases
*/
void
asubic(struct node * node, struct node * child, int iindex, int e, int s)
{
  if (node->info & FIRSTAXIS)
    printf("i%d / i%d", iindex, e);
  else if (node->info & LASTAXIS)
    printf("i%d %% i%d", iindex, s);
  else
    printf("(i%d / i%d) %% i%d", iindex, e, s);	/* jbww UKC 6/87 */
  /* printf("(i%d / i%d) % i%d", iindex, e, s); */
}

/*
  redshape 
  - generate code for reduce shape information
  - also used by inner product
*/
void
redshape(struct node * node, struct node * axis, int i, int e, int s,
    int mpval, int rank)
{
  if (!(node->info & RANKKNOWN)) {
    ieqtree(rank, gcond(RIGHT->rank.c,
	    gsop(APLC_MINUS, RIGHT->rank.c,
		gicn(icnst, 1, APLC_INT)), RIGHT->rank.c));
    node->rank.c = gicn(iptr, rank, APLC_INT);
  }
  if (node->info & LASTAXIS)
    if (is_vector(RIGHT))
      axies(node, axis, RIGHT, 0, 0, s);
    else
      axies(node, axis, RIGHT, 0, 0, s);
  else if (node->info & FIRSTAXIS)
    axies(node, axis, RIGHT, 0, e, s);
  else
    axies(node, axis, RIGHT, i, e, s);

  if (!(node->info & SHAPEKNOWN)) {
    if (node->info & FIRSTAXIS)
      node->shape.c = gsop(APLC_PLUS, RIGHT->shape.c,
	  gicn(icnst, 1, APLC_INT));
    else if (node->info & LASTAXIS)
      node->shape.c = RIGHT->shape.c;
    else {
      printf("aplc_vectalloc(&mp%d, ", mpval);
      ctgen(node->rank.c);
      printf(", APLC_INT);\n");
      printf("aplc_cpwo(mp%d.ip, i%d, ", mpval, i);
      rns(RIGHT);
      rpseminl();/* ); */
      node->shape.c = gicn(memptr, mpval, APLC_INT);
    }
  }
}

/*
  cmpidx1 
  - generate the index into the index conversion table for
    compress (and expand)
*/
void
cmpidx1(struct node * node, struct node * child, int newindex,
    int table, int iindex, int e, int s)
{
  ieq(newindex);
  printf("*(mp%d.ip + ", table);
  asubi(node, child, iindex, e, s);
  rpseminl();/* ); */
}

/*
  cmpidx2 
  - generate the new offset into a structure based on the
    old offset for compression, expansion and catenation.
    here the size of the axis may be changed between the
    old and new offsets
*/
void
cmpidx2(struct node * node, int temp, int newindex, int iindex, int a,
    int e, int sp, int s)
{
  if (node->info & LASTAXIS)
    printf("i%d = (i%d / i%d) * i%d + i%d;\n",
	newindex, iindex, s, sp, a);
  else {
    divmod(iindex, e, temp, newindex);
    printf("i%d += ", newindex);
    if (node->info & FIRSTAXIS)
      printf("i%d * i%d;\n", a, e);
    else
      printf("((i%d / i%d) * i%d + i%d) * i%d;\n",
	  temp, s, sp, a, e);
  }
}

/*
	compshape -
		generate shape information for compress
		(also used by expand)

     mpval  pointer to shape mp (output)
     i      axis position
     sp     size of left, sL(i)

sws

   This generates a mp for the result shape, copies the child shape into 
   this, then finally fixes s[i] = sp

 */

void
compshape(struct node * node, struct node * child,
    int mpval, int i, int sp, int resp)
{

#if 1
  /* need a res counter... */
  /* sws don't allocate for scalars */
  if ((is_vector(child) || is_scalar(child))) {	
    /* res?.ip = *sp; */ 
    printf("res%d.i = i%d;\n", resp, sp);
    /* node->shape.c = gicn(resptr, resp, APLC_INT);*/
    node->shape.c = gmon(ref, gicn(resptr, resp, APLC_INT));
    return;
  }
#endif

  printf("aplc_vectalloc(&mp%d, ", mpval);
  if ((is_vector(child) || is_scalar(child))) {	/* jbww UKC 6/87 */
    /* if (is_vector(child)) { */
    printf("1, APLC_INT);\n");
    setmptoi(mpval, sp);
  } else {
    ctgen(child->rank.c);
    printf(", APLC_INT);\n");
    cpshape(mpval, child);
    if (node->info & FIRSTAXIS)
      setmptoi(mpval, sp);
    else {
      mpipieq(mpval, i);
      printf("i%d;\n", sp);
    }
  }
  /* node->shape.c = gicn(memptr, node->ptr8, APLC_INT); */
  node->shape.c = gicn(memptr, mpval, APLC_INT);
}

/*
	comploop -
		do the common loop gathering operatorations of
		compress and expand

 sws
   note that s here is really s(i) of the right side, or s'(i)
   in the notation of Budd's book.
*/
void
comploop(struct node * node, int i, int e, int s, 
	 int mpval, int sl, int resl, int resr, int rank)
{
  struct node tmpnode;

  if (!(node->info & TYPEKNOWN))
    node->type.c = RIGHT->type.c;
/* old
  if (!(node->info & RANKKNOWN))
    node->rank.c = RIGHT->rank.c;

  if (node->info & LASTAXIS)
    axies(node, node->a.axis, RIGHT, i, 0, s);
  else
    axies(node, node->a.axis, RIGHT, i, e, s);
*/
  if (node->info & RANKKNOWN) {
    if (!is_scalar(RIGHT)) {
      if (node->info & LASTAXIS)
	axies(node, node->a.axis, RIGHT, i, 0, s);
      else
	axies(node, node->a.axis, RIGHT, i, e, s);
    } else {
      /* scalar right - just set s=1 */
      ieqc(s,1);
    }
  } else {
    /* don't know, need runtime rank and check */
    node->rank.c = gicn(iptr, rank, APLC_INT);
    ieqtree(rank, RIGHT->rank.c);
    iflp();
    printf("i%d == 0)\n", rank);
    /* right scalar becomes vector */
    ieqc(rank, 1);

    if (node->info & LASTAXIS)
      axies(node, node->a.axis, RIGHT, i, 0, s);
    else
      axies(node, node->a.axis, RIGHT, i, e, s);
  }


/* sws  necessary for compress too,
        since size of left and right may not be equal
        e.g. right a scalar */
  /* if (node->nodetype == EXPAND) */
#if 0
  getsize(sl, LEFT);
  impalloc(mpval, sl);
  colloop(node, LEFT->index, sl);
  switchbox(LEFT, VALUE, 0);
  fixzero(); /* make sure zero is ok */
  dsopv(NE, node, LEFT, zeronode, resl, resl, resr);
#endif
  /* new version need :

if scalar(left)
   use sr
else ifnot scalar (left)
   use sl as above
else
   need runtime check, switch between the two at runtime
   */
  if (is_scalar(LEFT)) {
    ieqi(sl, s);
  } else if (isnot_scalar(LEFT)) {
    getsize(sl, LEFT);
  } else {
    /* run time check */
    /* sl = scalar(left) ? s : getsize(left); */
    ieq(sl);
    testscalar(LEFT); 
    printf(" ? "); 
    printf("i%d : ",s); 
    getsizeval(LEFT); 
    seminl();
  }
  if ( is_scalar(LEFT) && is_scalar(RIGHT) ) {
    printf("{\n");
  } else {
    impalloc(mpval, sl);
    colloop(node, LEFT->index, sl);
  }
  switchbox(LEFT, VALUE, 0);
  fixzero(); /* make sure zero is ok */
  /*dsopv(APLC_NE, node, LEFT, zeronode, resl, resl, resr);*/
#if 0
  {
    struct codetree *savetree;
    savetree = node->type.c;
    node->type.c = gicn(tcnst, APLC_BOOL, APLC_INT);
    node->info |= TYPEKNOWN;
    dsopv(APLC_NE, node, LEFT, zeronode, resl, resl, resr);
    node->type.c = savetree;
  }
#endif
#if 1
  /* build a temporary node to do the dsop; specify the type
     as bool - node may not be that */
  tmpnode.nodetype = node->nodetype;
  tmpnode.optype = node->optype;
  tmpnode.info = TYPEKNOWN;
  tmpnode.type.n = APLC_BOOL;
  adjdcls(&tmpnode);
  tmpnode.info |= node->info;
  tmpnode.rank.c = node->rank.c;
  tmpnode.shape.c = node->shape.c;
  tmpnode.size.n = node->size.n;
  tmpnode.index = node->index;
  tmpnode.values.c = node->values.c;
  printf("/* comploop */");
  dsopv(APLC_NE, &tmpnode, LEFT, zeronode, resl, resl, resr);
  node->values = tmpnode.values;
#endif
}

/* 
   compcheck 
   - runtime check of compatibility for compress/expand

if ( (!scalar(LEFT)) && (!scalar(RIGHT)) && ( sl != s'[i] ) )
    error 

later we may want to turn this checking off ...
    */
static void
compcheck(struct node * node, int sp)
{
  /* don't need test if we have known scalars */
  if (is_scalar(LEFT)||is_scalar(RIGHT)) 
    return;
  iflp(); 
  /* don't need this test if we know this isn't a scalar */
  if (!isnot_scalar(LEFT)) {
    lp();printf("!"); testscalar(LEFT); rp();
    printf("&&"); 
  }
  if (!isnot_scalar(RIGHT)) {
    lp();printf("!"); testscalar(RIGHT); rp();
    printf("&&");
  }
  lp();lp(); ctgen( gmon(deref, LEFT->shape.c) ); rp();
  printf(" != i%d))\n",sp);
  prerror("length error: compress, shape missmatch");

}

/*
	gencompress - generate code for compression operator

        a .is L /[i] R or L/[i] B

In the notation of the book
     A(s,  f)    shape, expansion vector
     R(s', e)

     ptr1 - ip axis position
     ptr2 - ip e sub i
     ptr3 - ip shape of right, s'[i] (sws)
     ptr4 - mp for index vector v (?mp for values of left hand side)
     ptr5 - ip for size of left (sws)
     ptr6 - result register for computing left
     ptr7 - result register for computing right
     ptr8 - mp for shape of node s
     ptr9 - ip a[i] (value of indexed element in conversion table)
------------- 
sws: new
     ptr10 - ip for rank 
     ptr11 - ip size of node = s[i] 
     ptr12 - reg for shape, if scalar
     ptr13 - reg for index vector, if scalar
     
*/
void
gencompress(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);

    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);

    /* code to determine index vector v */
    setizero(node->ptr11);
    comploop(node, node->ptr1, node->ptr2, node->ptr3,
	     node->ptr4, node->ptr5, node->ptr6, node->ptr7, 
	     node->ptr10);
    iflp();
    ctgen(node->values.c);
    if ( is_scalar(LEFT) && is_scalar(RIGHT) ) {
      /* v[j] = offsetL */
      /* printf(") {\nres%d.i = i%d;\n", node->ptr5, LEFT->index);*/
      printf(") {\nres%d.i = 0;\n", node->ptr5);
      printf("i%d++;\n", node->ptr11);
      rbr(); rbr();
    } else {
      /* v[j] = offsetL */
      printf(")\n*(mp%d.ip + i%d++) = i%d;\n",
	     node->ptr4, node->ptr11, LEFT->index);
      rbr();
    }
    if (!(node->info & SHAPEKNOWN)) {
      /* generate the result shape */
      compshape(node, RIGHT, 
		node->ptr8, node->ptr1, node->ptr11, node->ptr12);
      /* now runtime check of compatibility
	 this should fail for vector left and length-1 vector right
       */
      compcheck(node, node->ptr3);
    }
    switchbox(LEFT, FINISH, 0);
    break;

  case COMBINE:
    break;

  case VALUE:
    /* generate the actual index into the right, if needed */
    if (!(RIGHT->info & NOINDEX)) {

      /* sws add runtime check to make sure we don't have a right
         singleton */
      if ( ! isnot_singleton(RIGHT) ) {
	/* if we don't know for sure the right isn't a singleton, we
	   need to check */
	/*- want
	  "if ( singleton )"
          if ( rank = 0 or (rank=1 and shape=1) ) {
 	     (as below but with offset = 0, use i0=0)
	     }
	  else {
	  */
	printf("if ");
	singleton(RIGHT);
	printf(" {\n");

	/* singleton case */
	/* first compute a prime sub i */
	cmpidx1(node, RIGHT, node->ptr9,
	    node->ptr4, 0, node->ptr2, node->ptr11);
	/* then compute new offset */
	if (!(is_vector(RIGHT) || is_scalar(RIGHT)))
	  cmpidx2(node, LEFT->index, RIGHT->index,
	      0, node->ptr9,
	      node->ptr2, node->ptr3, node->ptr11);

	printf("}\n");
	elsebr();
      }
      /* now non-singleton case */
      /* first compute a prime sub i */
      cmpidx1(node, RIGHT, node->ptr9,
	  node->ptr4, node->index, node->ptr2, node->ptr11);
      /* then compute new offset */
      if (!(is_vector(RIGHT) || is_scalar(RIGHT)))
	cmpidx2(node, LEFT->index, RIGHT->index,
	    node->index, node->ptr9,
	    node->ptr2, node->ptr3, node->ptr11);

      /* if (!(node->info & SHAPEKNOWN)) {*/
      if ( ! isnot_singleton(RIGHT) ) {
	/* sws  matching end brace */
	printf("}\n");
      }
    }
    switchbox(RIGHT, VALUE, 0);
    node->values.c = RIGHT->values.c;
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
#ifdef DEBUGFREE
    printf("/* -- compress finish */\n");
#endif
    /* free the shape vector */
    /* if (!(node->info & SHAPEKNOWN))*/
    if ( !(node->info & SHAPEKNOWN) && 
	 !((is_vector(RIGHT) || is_scalar(RIGHT))) )
      mpfree(node->ptr8);
    if ( ! (is_scalar(LEFT) && is_scalar(RIGHT)) ) {
      /* free the index vector */
      mpfree(node->ptr4);
    }
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;
  }
}

/* sws  
   genfill - get fill element for expand */
void
genfill(int resval, struct node * node)
{
  int t;

  t = rtype(node);
  node->values.c = gicn(resptr, resval, t);

  if ((t == APLC_BOOL) || (t == APLC_INT))
    printf("res%d.i = 0;\n", resval);
  else if (t == APLC_REAL)
    printf("res%d.r = 0.0;\n", resval);
  else if (t == APLC_CHAR)
    printf("res%d.c = ' ';\n", resval);
  else {
    /* type unknown, determine at run time */
    printf("aplc_genfill(&res%d, ", resval);
    ctgen(node->type.c);
    rpseminl();/* ); */
  }
}

/*
  genexpand - generate code for expansion operator

     ptr1 - axis position
     ptr2 - e sub i
     ptr3 - s sub i (sws s')
     ptr4 - mp for values of left hand side
     ptr5 - size of left (sws s)
     ptr6 - result register for computing left
     ptr7 - result register for computing right
     ptr8 - mp for shape
     ptr9 - a sub i (value of indexed element in conversion table)
------------- sws new
     ptr10 - iptr for rank

*/
void
genexpand(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);

    setizero(RIGHT->index);

    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);

    comploop(node, node->ptr1, node->ptr2, node->ptr3,
	node->ptr4, node->ptr5, node->ptr6, node->ptr7, node->ptr10);

    mpipieq(node->ptr4, LEFT->index);
    lp();
    ctgen(node->values.c);
    printf(") ? i%d++ : -1;\n", RIGHT->index);
    rbr();
    switchbox(LEFT, FINISH, 0);
    if (!(node->info & SHAPEKNOWN))
      compshape(node, RIGHT, 
		node->ptr8, node->ptr1, node->ptr5, node->ptr12);

    if ((node->info & SEQUENTIAL) && (!(RIGHT->info & NOINDEX)))
      setizero(RIGHT->index);
    break;

  case COMBINE:
    break;

  case VALUE:
    cmpidx1(node, RIGHT, node->ptr9, node->ptr4, node->index,
	    /* sws node->ptr2, node->ptr3); */
	    node->ptr2, node->ptr5);
    printf("if (i%d >= 0) {\n", node->ptr9);

    if (node->info & SEQUENTIAL);    /* do nothing now */
    else if (!(RIGHT->info & NOINDEX)) {
      if (!(is_scalar(RIGHT) || is_vector(RIGHT)))
	cmpidx2(node, LEFT->index, RIGHT->index,
		node->index, node->ptr9, node->ptr2,
		/* sws node->ptr5, node->ptr3); */
		node->ptr3, node->ptr5);
    }
    switchbox(RIGHT, VALUE, 0);
    node->ptr6 = resinreg(RIGHT, node->ptr6);

    if (node->info & SEQUENTIAL)
      iincr(RIGHT->index);

    rbr();
    elsebr();
    /* sws  change this so it works for characters too */
    /* identity(APLC_PLUS, node->ptr6, RIGHT); */
    genfill(node->ptr6, RIGHT);
    rbr();
    node->values.c = gicn(resptr, node->ptr6, rtype(RIGHT));
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
#ifdef DEBUGFREE
    printf("/* -- expand finish */\n");
#endif
    if (!(node->info & SHAPEKNOWN))
      mpfree(node->ptr8);
    mpfree(node->ptr4);
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;
  }
}

/*
  genrotate 
  - generate code for dyadic rotate instruction
*/
void
genrotate(struct node * node, enum pmodes mode, int top)
{
/*
     ptr1 - e sub i
     ptr2 - s sub i
     ptr3 - new index for right side along axis
     ptr4 - register pointer for left
*/
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 1, 1);
    if (!(LEFT->info & TYPEKNOWN))
      testtype(LEFT->type.c, APLC_INT);
    axies(node, node->a.axis, RIGHT, 0, node->ptr1,
	node->ptr2);
    break;

  case COMBINE:
    break;

  case VALUE:
    /* compute left index */
    if (node->info & LASTAXIS)
      iopi(LEFT->index, node->index, "/",
	  node->ptr2);
    else if (node->info & FIRSTAXIS)
      iopi(LEFT->index, node->index, "%",
	  node->ptr1);
    else {
      divmod(node->index, node->ptr1,
	  RIGHT->index, LEFT->index);
      printf("i%d += (i%d / i%d) * i%d;\n",
	  LEFT->index, RIGHT->index,
	  node->ptr2, node->ptr1);
    }

    /* get value */
    switchbox(LEFT, VALUE, 0);
    if (!(LEFT->info & TYPEKNOWN))
      mkrktype(LEFT, APLC_INT, node->ptr4);
    /* node->ptr4 = resinreg(LEFT, node->ptr4); */

    /* add value to appropriate position of rhs */
    ieq(node->ptr3);
    /* lp();  jbww UKC 6/87 */
    ctgen(LEFT->values.c);
    /* if ( LEFT->info & TYPEKNOWN) ctgen(LEFT->values.c); else (void)
       printf("res%d.i", node->ptr4); */
    printf(" + ");
    asubi(node, RIGHT, node->index, node->ptr1, node->ptr2);
    seminl();

    /* make sure it is right range */
    /* sws - doesn't handle wrap around cases printf("if (i%d < 0) i%d +=
       i%d;\n", node->ptr3, node->ptr3, node->ptr2); printf("if (i%d >= i%d)
       i%d -= i%d;\n", node->ptr3, node->ptr2, node->ptr3, node->ptr2); */
    printf("if (i%d < 0) i%d = i%d - ((-i%d) %% i%d);\n",
	node->ptr3,
	node->ptr3, node->ptr2, node->ptr3, node->ptr2);
    printf("if (i%d >= i%d) i%d %%= i%d;\n",
	node->ptr3, node->ptr2, node->ptr3,
	node->ptr2);


    /* now compute right value */
    if (!is_vector(RIGHT))
      cmpidx2(node, LEFT->index, RIGHT->index,
	  node->index, node->ptr3,
	  node->ptr1, node->ptr2,
	  node->ptr2);
    switchbox(RIGHT, VALUE, 0);
    node->values.c = RIGHT->values.c;
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    break;
  }
}


/* sws

	genencode - generate code for encode

	based on gencollect/genouter

	expect that this isn't a candidate for lazy evaluation
	since values may depend on one another,
	hence generate the all values in the SHAPE phase, and just
	read them out in the VALUE phase

*/

/* setup for incrementing ips */
void
ieqic(int i)
{
  printf("i%d = i%d", i, i);
}

void
iopic(int i, char *op, int j)
{
  printf("i%d %s i%d", i, op, j);
}

/* resinreg2 - make sure a value is in a register, putting it there
               regardless (resinreg may not).
               Return the number of the register it is in */
int
resinreg2(struct node * node, int regval)
{
  struct codetree *tree;
  int type;

  tree = node->values.c;
  if (tree->cop == resptr) {
    /* already in reg, just equate them */
    /* hopefully this will catch cases where node is unknown type */
    reqr(regval, tree->c0.cindex);
    return (regval);
  }

  type = rtype(node);
  if ( (type == APLC_UNDEF) || (type == APLC_UKTYPE) )
    prerror("[resinreg2] no type defined");

  /* put into register */
  ctgen(gbin(asgn,
	     gicn(resptr, regval, rtype(node)), 
	     node->values.c));
  seminl();
  node->values.c = gicn(resptr, regval, rtype(node));
  return (regval);
}


/* from axis */
/* extern void cksh(); */

/* outer a.
  ptr0 = type of result
  ptr1 = mp for shape; mp for result
  ptr2 = size of right hand side
  ptr3 = res register for result
  ptr4 = res register for left hand side
  ptr5 = res register for right hand side
  ptr6 = rank of result;  left first index counter
  ptr7 - size of left
  ptr8 - length of first axis of left
  ptr9 - length of rest of left
  ptr10 - left rest index counter
  ptr11 - result trs

  LEFT->index RIGHT->index node->index

*/
void
genencode(struct node * node, enum pmodes mode, int top)
{
  int sh;
  struct codetree *savetree;

  switch (mode) {
  case SHAPE:
    adjdcls(node);

    /* first get type, shape */
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);

    /* type, shape is same as outer residue */
    if (!(node->info & TYPEKNOWN))
      dsopt(APLC_ABS, node, LEFT, RIGHT, node->a.ptr0);

    /* shape(result) <- shape(LEFT), shape(RIGHT) */
    if (!(node->info & SHAPEKNOWN)) {
      rkeq(node, node->ptr6);
      printf("aplc_outershape(&mp%d, ", node->ptr1);
      lrnsrrns(LEFT, RIGHT);
      rpseminl();/* ); */
      node->shape.c = gicn(memptr, node->ptr1, APLC_INT);
    }
    getsize(node->ptr2, RIGHT);
    getsize(node->ptr7, LEFT);

    /* size of left first axis */
    if (!is_scalar(LEFT)) {

      if (LEFT->info & SHAPEKNOWN) {
	sh = shapevalue(LEFT);
	seticon(node->ptr8, iconsts[sh]);
      } else
	cksh(node->ptr8, LEFT, LEFT->shape.c);
      /*-
	size of rest of left = (size of left)/(size of first axis of left)
      */
      iopi(node->ptr9, node->ptr7, "/", node->ptr8);
    }
    /* allocate space for collection of results in trs */
    settrs(node->ptr11, node);
    if (!(node->info & TYPEKNOWN))
      node->type.c = gtrs(node->ptr11, ctypefield, APLC_UKTYPE);
    if (!(node->info & RANKKNOWN))
      node->rank.c = gtrs(node->ptr11, crankfield, APLC_UKTYPE);
    if (!(node->info & SHAPEKNOWN))
      node->shape.c = gtrs(node->ptr11, cshapefield, APLC_UKTYPE);

    /* size of result - just ignore it for now ieq(node->ptr3); */
    printf("aplc_talloc(&trs%d);\n", node->ptr11);
    node->values.c = gtrs(node->ptr11, cvalfield, rtype(node));
    leafshape(node, node->ptr1);

    /* alternate? from genquad node->values.c = gicn(memptr, node->ptr11,
       rtype(node)); leafshape(node, node->ptr1); */

    /* next get values from left and right, and do the encode; 
       we need three loops for this, i,j,k:
          z[k;i;j] <- a[k;i] encode b[j]
    */
    savetree = looprank;
    /* not really sure what this is used for - hope this works */
    looprank = node->rank.c;

    /* initial index values */
    ieq(node->index);
    printf(" (i%d - 1)*i%d*i%d;\n", node->ptr8, node->ptr9, node->ptr2);
    ieq(LEFT->index);
    printf(" (i%d - 1)*i%d;\n", node->ptr8, node->ptr9);

    /* right index loop (j) */
    if (!is_scalar(RIGHT))
      iiloop(RIGHT->index, node->ptr2);

    /* left rest loop (i) */
    if (!(is_scalar(LEFT) || is_vector(LEFT)))
      iiloop(node->ptr10, node->ptr9);

    /* get right value */
    switchbox(RIGHT, VALUE, 0);
    /* put right value in temp register */
    node->ptr5 = resinreg2(RIGHT, node->ptr5);

    /* left first axis loop (k) */
    if (!is_scalar(LEFT))
      iiloop(node->ptr6, node->ptr8);

    /* get left value */
    switchbox(LEFT, VALUE, 0);
    node->ptr4 = resinreg(LEFT, node->ptr4);

    /* actually do the encode: encode(res, lres, ltype, rres, rtype) */
    printf("aplc_encode(&res%d, &res%d, ", node->ptr3, node->ptr4);
    ctgen(LEFT->type.c);
    printf(", &res%d, ", node->ptr5);
    ctgen(RIGHT->type.c);
    rpseminl();/* ); */
    /* aplc_setmp(res, mp, i, type) */
    printf("aplc_setmp(&res%d, &mp%d, i%d, ", 
	   node->ptr3, node->ptr1, node->index);
    ctgen(node->type.c);
    printf(");\n");

    /* ? node->values.c = gicn(resptr, resval, rtype(node)); */

    /* increment indices, close loops */
    if (is_scalar(LEFT)) {
      iincr(node->index);
    } else if (is_vector(LEFT)) {
      ieqic(node->index);
      printf(" - i%d * i%d;\n", node->ptr9, node->ptr2);
      ieqic(LEFT->index);
      printf(" - i%d;\n", node->ptr9);
      rbr();

      ieqic(node->index);
      printf(" + i%d * i%d + 1;\n", node->ptr7, node->ptr2);
      ieqic(LEFT->index);
      printf(" + i%d;\n", node->ptr7);
    } else {
      ieqic(node->index);
      printf(" - i%d * i%d;\n", node->ptr9, node->ptr2);
      ieqic(LEFT->index);
      printf(" - i%d;\n", node->ptr9);
      rbr();

      ieqic(node->index);
      printf(" + (i%d+1) * i%d;\n", node->ptr7, node->ptr2);
      ieqic(LEFT->index);
      printf(" + i%d + 1;\n", node->ptr7);
      rbr();

      ieqic(node->index);
      printf(" + 1 - i%d * i%d;\n", node->ptr9, node->ptr2);
      ieqic(LEFT->index);
      printf(" - i%d;\n", node->ptr9);
    }
    if (!is_scalar(RIGHT))
      rbr();

    looprank = savetree;
    break;

  case COMBINE:
    break;

  case VALUE:
    /* just read out values calculated above here (collect) */
    leafvalue(node, node->ptr1, rtype(node), node->ptr3);
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
#ifdef DEBUGFREE
    printf("/* -- encode finish */\n");
#endif
    printf("aplc_detalloc(&trs%d);\n", node->ptr11);
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;
  }
}

/* end of axis.c */
