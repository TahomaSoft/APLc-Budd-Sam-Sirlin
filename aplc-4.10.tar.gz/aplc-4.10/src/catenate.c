/*
	APL Compiler

	Code Generation routines for catenate and laminate
	Samuel W.  Sirlin (sws)

	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

#include <stdio.h>
#include "parse.h"
#include "y_tab.h"
#include "gen.h"


/* extern void error(char *c);*/


/* local functions */
static int axi(struct node * node, struct node * axis, int i, 
	       short int *reg, int taxisp);
static void axes(struct node * node, struct node * axis, int e, int sL, 
    int sR);


/* sws version of dsopt, for cat, subassign
   - get the max of two types, possibly at runtime 
     at runtime this will be in ptr ival
   - generate code for node type
*/
extern void
mergetype(struct node * node,
    struct node * left, struct node * right, int ival)
{
  if (cteq(left->type.c, right->type.c)) {
      node->type.c = left->type.c;
      return;
  }
  ieq(ival);
  printf("aplc_mergetype(");
  ctgen(left->type.c);
  commasp();
  ctgen(right->type.c);
  rpseminl();
  node->type.c = gicn(iptr, ival, 0);
}


/*
sws
	axi - generate code to produce

        reg   - (pointer to) register of axis value (if real)
	i     - (pointer to) the position of the axis (zero based)
	taxisp - (pointer to) the axis type
	taxis  - the axis type

	the argument i, contains the integer pointer into which the
	associated value is to be placed

        does nothing if LASTAXIS

	used by gencat
*/

static int 
axi(struct node * node, struct node * axis, int i, short int *reg, 
    int taxisp)
{
  int taxis;

  if (node->info & FIRSTAXIS) {
    setizero(i);
    printf("i%d = APLC_INT;\n", taxisp);
    seminl();
    taxis = APLC_INT;
  } else if (node->info & LASTAXIS) {
    setizero(i);  /* do the same as above, ignored anyway */
    printf("i%d = APLC_INT;\n", taxisp);
    taxis = APLC_INT;
  } else {
    /* axis value is not obvious, may be known */
    /* test code:
    taxis = axis->type.n;
    fprintf(stderr,"[catenate] axi, axis type =[%d]\n", 
    taxis);*/

    switchbox(axis, SHAPE, 0);
    if (axis->info & TYPEKNOWN) {
      taxis = rtype(axis);
      if ( (taxis == APLC_INT) || (taxis == APLC_BOOL) ) {
	ieqtree(i, gsop(APLC_MINUS, axis->values.c, gixorg()));
	printf("i%d = APLC_INT;\n", taxisp);
	taxis = APLC_INT;
      } else if (taxis == APLC_REAL) {
	/* put (real) value in register */
	*reg = resinreg(axis, *reg);
	/* subtract off indexorigin */
	ctgen(gbin(asgn, axis->values.c,
		gsop(APLC_MINUS, axis->values.c, gixorg())));
	seminl();
	/* alternate version... */
	/* put (real) value in register */
	/* subtract off indexorigin */
/*--
		    reg= resinreg(axis, reg);
		    printf("res%d.r = ",reg);
		    printf(" - ");
		    gixorg();
		    seminl();
*/
	printf("i%d = APLC_REAL;\n", taxisp);
	taxis = APLC_REAL;
      } else {
	fprintf(stderr,"[catenate] axi, illegal axis type =[%d]\n", 
		taxis);
	error("illegal axis type");
      }
    } else {
      /* axis type unknown */
#if 0
      printf("/* [axi] axis type unknown */\n");
      /* put value in register */
      /* doesn't work if type unknown  .uck */
      *reg = resinreg(axis, *reg);
#endif

      /* we know axis right is cscalar, so must have a mp; havevalue */
#if 0
      /* for debugging */
      printf("/* ");
      ctgen(axis->values.c);
      printf("*/\n");
#endif
      /* put in reg */
      printf("aplc_mp2res(&res%d, &", *reg);
      /* ctgen( gmon(deref, axis->values.c) );*/
      /* ctgen( axis->values.c );*/
      /* expect code tree is deref */
      if (axis->values.c->cop == resptr)
	;/* in res already */
      else if (axis->values.c->cop == deref) {
	ctgen( axis->values.c->c0.cleft );
	printf(", 0,");
	ctgen(axis->type.c);
	rpseminl();
      } else {
	fprintf(stderr," cop = %d\n", axis->values.c->cop);
	error("[catenate/axi] code tree");
      }

      /* subtract off indexorigin */
      printf("aplc_resop(&res%d, ", *reg);
      ctgen(axis->type.c);
      printf(", APLC_MINUS, ");
      ctgen(gixorg());
      rpseminl();
      taxis = APLC_UKTYPE;
      ieq(taxisp);
      ctgen(axis->type.c);
      seminl();
    }
    switchbox(axis, FINISH, 0);

  }
  return (taxis);
}

/*  sws
	axes - generate code to produce the following values

	e - the expansion vector value at position i (e sub i)
	sL - the shape of the left node at position i (s sub i)
	sR - the shape of the right node at position i (s sub i)

	the arguments e, and s contain the index registers into which the
	associated values are to be placed.

        In all three cases in the
	value is zero no code is generated to place the value.
	One of e or s must be non-zero.

        only for cases when the shape is known

        used in gencat
*/
static void 
axes(struct node * node, struct node * axis, int e, int sL, int sR)
{
  int rl, rr;

  if ((LEFT->info & SHAPEKNOWN) && (RIGHT->info & SHAPEKNOWN)) {
    if (is_scalar(LEFT)) {
      seticon(sL, 1);
      axies(node, node->a.axis, RIGHT, 0, e, sR);
    } else if (is_scalar(RIGHT)) {
      seticon(sR, 1);
      axies(node, node->a.axis, LEFT, 0, e, sL);
    } else {
      /* need to check ranks */
      rl = rankvalue(LEFT);
      rr = rankvalue(RIGHT);
      if (rl == rr) {
	axies(node, node->a.axis, LEFT, 0, e, sL);
	axies(node, node->a.axis, RIGHT, 0, 0, sR);
      } else if (rl == rr - 1) {
	seticon(sL, 1);
	axies(node, node->a.axis, RIGHT, 0, e, sR);
      } else if ((rl - 1) == rr) {
	seticon(sR, 1);
	axies(node, node->a.axis, LEFT, 0, e, sL);
      }
      /* else consider laminate */
      else
	error("[catenate/axes] rank error");
    }
  } else {
    /* error, can't find stuff; shouldn't happen */
    error("[catenate/axes] nonce error");
  }
}


/*
	gencat - generate code for catenation function
*/

/* check if sequential and no possible replication - 
(left non-scalar and right non-scalar)
(left scalar and right scalar)
*/
#define isnot_scalar(node) ((node->info & RANKKNOWN) && (rankvalue(node) != 0))
#define CATSEQ ( (node->info & SEQUENTIAL) && (\
   ( isnot_scalar(LEFT) && isnot_scalar(RIGHT) ) || \
   ( (is_scalar(LEFT)) && ( is_scalar(RIGHT)) ) ) )

/*
	ptr1 -  type
	ptr2 -  rank
	ptr3 -  shape mp
	ptr4 -  s sub i for left hand side, sL
	ptr5 -  e sub i
	ptr6 -  size along ith dimension (sum of s's)
	ptr7 -  (axis register);  result
	ptr8 -  s sub i for right hand side, sR
	ptr9 -  axis;       value in given axis
	ptr10 - axis type; temp
*/
void 
gencat(struct node * node, enum pmodes mode, int top)
{
  int taxis;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);

    /* sws  modified to always define a type */
    if (!(node->info & TYPEKNOWN)) {
      /* dsopt(APLC_NOT, node, LEFT, RIGHT, node->ptr1); */
      mergetype(node, LEFT, RIGHT, node->ptr1); 
    }
    else {
      ieq(node->ptr1);
      ctgen(node->type.c);
      seminl();
/*--  sws  don't need to modify node, since type is known
           node->type.c = gicn(iptr, node->ptr1, 0);
*/
    }

    /*  modified axies to get axis, register, axis type */
    taxis = axi(node, node->a.axis, node->ptr9, &(node->ptr7), 
		node->ptr10);

    /* check for laminate */
    if (taxis != APLC_INT) {

      /*
      for laminate, once we know how to get real value, if known, may
      make better code for now, assume everything is unknown - the
      decision of cat/lam done at run-time in catshape/lamshape
      */

      /* determine axis type, value */
      /* lamcheck(&a.type, a.value, &axis); */
      printf("aplc_lamcheck(&i%d, &res%d, &i%d);\n",
	     node->ptr10, node->ptr7, node->ptr9);
    }
    /* get e sL, sR */
    if ((!(node->info & SHAPEKNOWN)) ||
	(taxis != APLC_INT)) {
      rkeq(node, node->ptr2);
      /* 
      aplc_catshape(shape, leftrank, leftshape, rightrank, rightshape,
               axis, axisind, taxis, e, sl, sr) */
      printf("aplc_catshape(&mp%d, ", node->ptr3);
      lrnsrrns(LEFT, RIGHT);
      printf(", i%d, ", node->ptr9);
      if (node->info & FIRSTAXIS)
	printf("1");
      else if (node->info & LASTAXIS)
	printf("2");
      else
	printf("0");
      printf(", i%d", node->ptr10);
      printf(", &i%d,&i%d,&i%d", node->ptr5, node->ptr4, node->ptr8);
      rpseminl();
      node->shape.c = gicn(memptr, node->ptr3, APLC_INT);
    } else {
      axes(node, node->a.axis, node->ptr5, node->ptr4, node->ptr8);
    }

    /* compute sum of left and right along axis */
    iopi(node->ptr6, node->ptr4, "+", node->ptr8);

    /* sequential axis is special case */
    if ( CATSEQ ) {
      if (!(LEFT->info & NOINDEX))
	setizero(LEFT->index);
      if (!(RIGHT->info & NOINDEX))
	setizero(RIGHT->index);
    }
    break;
  case COMBINE:
    break;

  case VALUE:
    /* first compute asubi */
    ieq(node->ptr9);
    asubic(node, RIGHT, node->index, node->ptr5, node->ptr6);
    seminl();
    printf("if (i%d < i%d) {\n", node->ptr9, node->ptr4);

    /* left side */
    if ( ! ( CATSEQ || (LEFT->info & NOINDEX) ) ) {
     if (LEFT->info & RANKKNOWN) {
      cmpidx2(node, node->ptr10, LEFT->index, node->index,
	  node->ptr9, node->ptr5, node->ptr4, node->ptr6);
     } else {
      /* need runtime test for singleton */
      iflp();
      /* testscalar(LEFT->rank.c, LEFT->shape.c); */
      singleton(LEFT);
      rp();
      setizero(LEFT->index);
      elsebr();
      cmpidx2(node, node->ptr10, LEFT->index, node->index,
	  node->ptr9, node->ptr5, node->ptr4, node->ptr6);
      rbr();
     }
    }
    switchbox(LEFT, VALUE, 0);
    node->ptr7 = resinreg(LEFT, node->ptr7);
    if ( CATSEQ && !(LEFT->info & NOINDEX) )
	iincr(LEFT->index);

    if (!cteq(LEFT->type.c, node->type.c)) {
      /* sws  code to make types conform to maxtype */
      printf(" /* gencat left type check */\n");
      printf("aplc_cktype(&res%d, i%d, ", node->ptr7, node->ptr1);
      ctgen(LEFT->type.c);
      printf(");\n");
    }
    rbr();

    /* right side */
    elsebr();
    if ( !( CATSEQ || (RIGHT->info & NOINDEX) ) ) {
     if (RIGHT->info & RANKKNOWN) {
      printf("i%d -= i%d;\n", node->ptr9, node->ptr4);
      cmpidx2(node, node->ptr10, RIGHT->index, node->index,
	  node->ptr9, node->ptr5, node->ptr8, node->ptr6);
     } else {
      /* need runtime test for singleton */
      iflp();
      /*testscalar(RIGHT->rank.c, RIGHT->shape.c); */
      singleton(RIGHT);
      rp();
      setizero(RIGHT->index);
      elsebr();
      printf("i%d -= i%d;\n", node->ptr9, node->ptr4);
      cmpidx2(node, node->ptr10, RIGHT->index, node->index,
	  node->ptr9, node->ptr5, node->ptr8, node->ptr6);
      rbr();
     }
    }
    switchbox(RIGHT, VALUE, 0);
    node->ptr2 = resinreg(RIGHT, node->ptr7);
    if (node->ptr2 != node->ptr7)
      printf("res%d = res%d;\n", node->ptr7, node->ptr2);
    if ( ( CATSEQ && !(RIGHT->info & NOINDEX) ) )
	iincr(RIGHT->index);

    if (!cteq(RIGHT->type.c, node->type.c)) {
      /* sws  code to make types conform to maxtype */
      printf(" /* gencat right type check */\n");
      printf("aplc_cktype(&res%d, i%d, ", node->ptr7, node->ptr1);
      ctgen(RIGHT->type.c);
      printf(");\n");
    }

    rbr();
    node->values.c = gicn(resptr, node->ptr7, rtype(node));

    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    if (!(node->info & SHAPEKNOWN)) {
#ifdef DEBUGFREE
      printf("/* -- cat finish */\n");
#endif
      mpfree(node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/* end of catenate.c */




