/* acconfig.h - for inclusion in aplc_config.h.in */

#ifndef _APLC_CONFIG
#define _APLC_CONFIG

@TOP@

@BOTTOM@

#endif
/* end of acconfig.h - for inclusion in aplc_config.h.in */
