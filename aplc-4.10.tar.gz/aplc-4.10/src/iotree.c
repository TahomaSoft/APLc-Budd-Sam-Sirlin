/*
	APL compiler
		parse tree i/o utilities
		timothy a. budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/
#include <stdio.h>

#include "parse.h"
#include "y_tab.h"

/* some global variables */
int stmtno = 0;			     /* the current statement number */
char *funname = "main";		     /* the current function name */


/* error - print error message and quit 

   list current function name and statement number as well as 
   given message
*/
extern void
error(char *c)
{
  fprintf(stderr, "%s:%d:%s\n", funname, stmtno, c);
  exit(1);
}

/* putname - print a name */
void
putname(char *c)
{
  if (c != NILCHAR)
    fputs(c, stdout);
  putchar('\n');
}

/* put function header */
void
putheader(struct headnode * head)
{

/* sws check for 0 header pointer */
/*  (void) fprintf(stderr,"putheader: %d\n",head);*/

  if (head != 0) {
    fwriten((char *) head, sizeof(struct headnode), 1, stdout);
    putname(head->fname);
    putname(head->asvar);
    putname(head->parm1);
    putname(head->parm2);
  } else
    error("putheader: null header");
}

/* sws - a safe version of gets 
   used since this originally used gets
*/
char *
gets_safe(char *c)
{
  fgets(c, MAX_NAME_LEN, stdin);
  /* unlike gets, fgets can return a newline as the last char */
  if ('\n' == c[strlen(c)-1])
    c[strlen(c)-1] = '\0';
  return(c);
}

/* getfname - get function name field */
char *
getfname(char *c)
{
  c[0] = 0;
  gets_safe(c);
  if (c[0] == '\0')
    return (NILCHAR);
  else
    return (c);
}

/* get function header */
void
gethead(struct headnode * head, char *name, char *asvar,
    char *parm1, char *parm2)
{
  freadn((char *) head, sizeof(struct headnode), 1, stdin);
  head->fname = getfname(name);
  head->asvar = getfname(asvar);
  head->parm1 = getfname(parm1);
  head->parm2 = getfname(parm2);
}

/* put symbol table */
void
putsyms(struct symnode * syms)
{
  struct symnode *p;

  for (p = syms; p != 0; p = p->next) {
    if (p->name) {
      putcharn(SYMS);
      fwriten((char *) p, sizeof(struct symnode), 1, stdout);
      putname(p->name);
    }
  }
  putcharn(ESYMS);
}

/* read symbol table */
struct symnode *
getsyms(void)
{
  struct symnode *fs, *os, *cs;
  char iname[MAX_NAME_LEN];
  int c;

  fs = 0;
  os = (struct symnode *) 0;/* initialize for lint */
  while ((c = getcharn()) == SYMS) {
    /* (void) fprintf(stderr, "getsyms: char read is %d\n", c); */
    cs = structalloc(symnode);
    freadn((char *) cs, sizeof(struct symnode), 1, stdin);
    gets_safe(iname);
    /* (void) fprintf(stderr,"getsyms: iname read is %s\n", iname);*/
    cs->name = (char *) malloc((unsigned) (1 + strlen(iname)));
    cs->next = NILSYM;
    strcpy(cs->name, iname);
    if (fs == NILSYM)
      fs = os = cs;
    else
      os->next = cs;
    os = cs;
  }
  if (c != ESYMS) {
    fprintf(stderr, "getsyms: char is %d\n", c);
    error("bad symbol table format");
  }
  return (fs);
}

/* free symbol table */
void
fresyms(struct symnode * syms)
{
  if (syms != (struct symnode *) 0) {
    if (syms->next != (struct symnode *) 0)
      fresyms(syms->next);
    free((char *) syms);
  }
}

/* put lcon */
void 
put_lcon(void)
{
  int i;

  if (lctop) {
    for (i = 0; i<lctop; i++) {
      /* putcharn(SYMS);*/
      fwriten((char *) &(lconsts[i]), sizeof(struct label_struct), 1, stdout);
      putname(lconsts[i].label_name);
    }
    /* putcharn(ESYMS);*/
  }
}

void
get_lcon(void)
{
  char iname[MAX_NAME_LEN];
  int i;

  for (i=0; i<lctop; i++) {
    freadn((char *) &(lconsts[i]), sizeof(struct label_struct), 1, stdin);
    gets_safe(iname);
    lconsts[i].label_name = (char *) malloc((unsigned) (1 + strlen(iname)));
    strcpy(lconsts[i].label_name, iname);
  }
}

/* put constants */
void
putconsts(void)
{
  int a[7], i;

  putcharn(CONSTS);

  a[0] = strlen(sconsts);
  a[1] = lctop;
  a[2] = ictop;
  a[3] = rctop;
  a[4] = zctop;
  a[5] = qctop;
  a[6] = octop;
  fwriten((char *) a, sizeof(int), 7, stdout);
  for (i = 0; i < a[0]; i++)
    putcharn(sconsts[i]);
#if 0
  /* old method */
  if (a[1])
    fwriten((char *) lconsts, sizeof(union label_struct), lctop, stdout);
#else
  put_lcon();
#endif
  if (a[2])
    fwriten((char *) iconsts, sizeof(int), (unsigned) ictop, stdout);
  if (a[3])
    fwriten((char *) rconsts, sizeof(double), (unsigned) rctop, stdout);
  if (a[4]) {
    fwriten((char *) zconsts[0], sizeof(double), (unsigned) zctop, stdout);
    fwriten((char *) zconsts[1], sizeof(double), (unsigned) zctop, stdout);
  }
  if (a[5]) {
    for(i =0; i<4; i++)
      fwriten((char *) qconsts[i], sizeof(double), 
	      (unsigned) qctop, stdout);
  }
  if (a[6]) {
    for(i =0; i<8; i++)
      fwriten((char *) oconsts[i], sizeof(double), 
	      (unsigned) octop, stdout);
  }
  return;
}

/* read constants */
extern void
rdconsts(void)
{
  int a[7], i;

  if (getcharn() != CONSTS)
    error("bad format reading constants");
  freadn((char *) a, sizeof(int), 7, stdin);
  sctop = a[0];
  lctop = a[1];
  ictop = a[2];
  rctop = a[3];
  zctop = a[4];
  qctop = a[5];
  octop = a[6];
  for (i = 0; i < sctop; i++)
    sconsts[i] = getcharn();
  sconsts[i] = 0;
#if 0
  /* old */
  if (lctop)
    freadn((char *) lconsts, sizeof(union label_struct), a[1], stdin);
#else
  get_lcon();
#endif
  if (ictop)
    freadn((char *) iconsts, sizeof(int), (unsigned) a[2], stdin);
  if (rctop)
    freadn((char *) rconsts, sizeof(double), (unsigned) a[3], stdin);
  if (zctop) {
    freadn((char *) zconsts[0], sizeof(double), (unsigned) a[4], stdin);
    freadn((char *) zconsts[1], sizeof(double), (unsigned) a[4], stdin);
  }
  if (qctop) {
    for (i=0; i<4; i++)
      freadn((char *) qconsts[i], sizeof(double), 
	     (unsigned) a[5], stdin);
  }
  if (octop) {
    for (i=0; i<8; i++)
      freadn((char *) oconsts[i], sizeof(double), 
	     (unsigned) a[6], stdin);
  }
  return;
}

/* put out code */
void
putcode(struct statenode * code)
{
  struct statenode *p;

  for (p = code; p != NILSTATE; p = p->nextstate) {
    putcharn(STMT);
    fwriten((char *) &p->label, sizeof(char *), 1, stdout);
    putnode(p->code);
  }
  putcharn(ESTMT);
}

/* free storage used by code */
void
frecode(struct statenode * code)
{
  if (code->nextstate != NILSTATE)
    frecode(code->nextstate);
  frenode(code->code);
  free((char *) code);
}

/* read code */
struct statenode *
rdcode(void)
{
  struct statenode *sp, *op, *fp;
  char c;

  /* sws */
  /*	(void) fprintf(stderr,"[rdcode] \n");*/

  fp = (struct statenode *) 0;/* initialize for lint */
  op = NILSTATE;
  while ((c = getcharn()) == STMT) {
    sp = structalloc(statenode);
    freadn((char *) &sp->label, sizeof(char *), 1, stdin);
    sp->code = innode();
    sp->nextstate = NILSTATE;
    sp->list = NILSYM;
    if (op == NILSTATE)
      op = fp = sp;
    else
      op->nextstate = sp;
    op = sp;
    /*	fprintf(stderr,"[rdcode] read 1 stmt\n");*/

  }
  if (c != ESTMT) {
    fprintf(stderr, "[rdcode] last character is %d\n", c);
    fprintf(stderr, "[rdcode] expect %d\n", ESTMT);
    error("[iotree/rdcode] bad format");
  }
  return (fp);
}

/* put out node */
void
putnode(struct node * node)
{
  fwriten((char *) node, sizeof(struct node), 1, stdout);

  switch (node->nodetype) {
  default:
    fprintf(stderr, "putnode: node type %d\n", node->nodetype);
    error("illegal node type output");

  case IDENT:
    puts(node->a.namep);
    break;

  case BCON:
  case ICON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case LCON:
  case SCON:
  case AVEC:
  case TCAV:
  case QQUAD:
  case BOX:
  case EMPTSEMI:
  case COMMENT:
    break;

  case REVERSE:
  case REDUCE:
  case SCAN:
    if (axisgiven(node->a.axis))
      putnode(node->a.axis);
    putnode(node->right);
    break;

  case COMPRESS:
  case EXPAND:
  case ROTATE:
  case CAT:
  case LAM:
  case CATCH:
    putnode(node->left);
    if (axisgiven(node->a.axis))
      putnode(node->a.axis);
    putnode(node->right);
    break;

  case FIDENT:
    if (LEFT != NILP)
      putnode(node->left);
    if (RIGHT != NILP)
      putnode(node->right);
    puts(node->a.namep);
    break;

  case SM:
    if (LEFT != NILP)
      putnode(node->left);
    if (axisgiven(node->a.axis))
      putnode(node->a.axis);
    if (RIGHT != NILP)
      putnode(node->right);
    break;

  case ASYSVAR:
  case SYSVAR:
    if (node->left != NILP)
      putnode(node->left);
    if (node->right != NILP)
      putnode(node->right);
    break;

  case SUBASSIGN:
    putnode(node->left);
    putnode(node->right);
    putnode(node->a.axis);
    putnode(node->store);
    break;

  case BOXASSIGN:
  case CIVEC:
  case COLLECT:
  case CCOLLECT:
  case CISCALAR:
  case CSCALAR:
  case CVEC:
  case DQQUAD:
  case DBOX:
  case DOMINO:
  case EXECUTE:
  case FORMAT:
  case GO:
  case INNER:
  case IOTA:
  case MSOP:
  case MSYSFUN:
  case QBOXAS:
  case RAVEL:
  case RHO:
  case RHORHO:
  case ROLL:
  case SORT:
  case TRANS:
    putnode(node->right);
    break;

  case DECODE:
  case INNERCHILD:
    putnode(node->left);
    putnode(node->right);
    putnode(node->store);
    break;

  case ASSIGN:
  case CGOTO:
  case DBOXAS:
  case DEAL:
  case DFORMAT:
  case DQBOXAS:
  case DROP:
  case DSOP:
  case DSYSFUN:
  case DTRANS:
  case ENCODE:
  case EPSILON:
  case ESYSFUN:
  case INDEX:
  case MSOLVE:
  case OUTER:
  case RESHAPE:
  case SUB:
  case TAKE:
  case GWTAKE:
  case GWDROP:
    putnode(node->left);
    putnode(node->right);
    break;
  }
}

/* read nodes */
struct node *
innode(void)
{
  struct node *node;
  char name[MAX_NAME_LEN];

  /* try to allocate space */
  node = structalloc(node);

  if (node == (struct node *) 0)
    error("no room for parse tree");
  /* get stuff */
  freadn((char *) node, sizeof(struct node), 1, stdin);

  switch (node->nodetype) {
  default:
    fprintf(stderr, "node type %d\n", node->nodetype);
    error("illegal node type input");

  case IDENT:
    gets_safe(name);
    node->a.namep = (char *) malloc((unsigned) (1 + strlen(name)));
    strcpy(node->a.namep, name);
    break;

  case BCON:
  case ICON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case LCON:
  case SCON:
  case AVEC:
  case TCAV:
  case QQUAD:
  case BOX:
  case EMPTSEMI:
  case COMMENT:
    break;

  case REDUCE:
  case REVERSE:
  case SCAN:
    if (axisgiven(node->a.axis))
      node->a.axis = innode();
    node->right = innode();
    break;

  case COMPRESS:
  case EXPAND:
  case ROTATE:
  case CAT:
  case LAM:
  case CATCH:
    node->left = innode();
    if (axisgiven(node->a.axis))
      node->a.axis = innode();
    node->right = innode();
    break;

  case FIDENT:
    if (LEFT != NILP)
      node->left = innode();
    if (RIGHT != NILP)
      node->right = innode();
    gets_safe(name);
    node->a.namep = (char *) malloc((unsigned) (1 + strlen(name)));
    strcpy(node->a.namep, name);
    break;

  case SM:
    if (LEFT != NILP)
      node->left = innode();
    if (axisgiven(node->a.axis))
      node->a.axis = innode();
    if (RIGHT != NILP)
      node->right = innode();
    break;

  case ASYSVAR:
  case SYSVAR:
    if (node->left != NILP)
      node->left = innode();
    if (node->right != NILP)
      node->right = innode();
    break;

  case SUBASSIGN:
    node->left = innode();
    node->right = innode();
    node->a.axis = innode();
    node->store = innode();
    break;

  case BOXASSIGN:
  case CIVEC:
  case COLLECT:
  case CCOLLECT:
  case CISCALAR:
  case CSCALAR:
  case CVEC:
  case DBOX:
  case DOMINO:
  case DQQUAD:
  case EXECUTE:
  case FORMAT:
  case GO:
  case INNER:
  case IOTA:
  case MSOP:
  case QBOXAS:
  case RHO:
  case RHORHO:
  case ROLL:
  case MSYSFUN:
  case RAVEL:
  case SORT:
  case TRANS:
    node->right = innode();
    break;

  case DECODE:
  case INNERCHILD:
    node->left = innode();
    node->right = innode();
    node->store = innode();
    break;

  case ASSIGN:
  case CGOTO:
  case DBOXAS:
  case DEAL:
  case DFORMAT:
  case DQBOXAS:
  case DROP:
  case DSOP:
  case DSYSFUN:
  case DTRANS:
  case ENCODE:
  case EPSILON:
  case ESYSFUN:
  case INDEX:
  case MSOLVE:
  case OUTER:
  case RESHAPE:
  case SUB:
  case TAKE:
  case GWTAKE:
  case GWDROP:
    node->left = innode();
    node->right = innode();
    break;
  }
  return (node);
}

/* free storage taken by node */
void
frenode(struct node * node)
{
  switch (node->nodetype) {
    default:
    fprintf(stderr, "node type %d\n", node->nodetype);
    error("frenode: illegal node type freed");

  case IDENT:
  case BCON:
  case ICON:
  case RCON:
  case ZCON:
  case QCON:
  case OCON:
  case LCON:
  case SCON:
  case AVEC:
  case TCAV:
  case QQUAD:
  case BOX:
  case EMPTSEMI:
  case COMMENT:
    break;

  case REVERSE:
  case REDUCE:
  case SCAN:
    if (axisgiven(node->a.axis))
      frenode(node->a.axis);
    frenode(node->right);
    break;

  case COMPRESS:
  case EXPAND:
  case ROTATE:
  case CAT:
  case LAM:
  case CATCH:
    frenode(node->left);
    if (axisgiven(node->a.axis))
      frenode(node->a.axis);
    frenode(node->right);
    break;

  case FIDENT:
    if (LEFT != NILP)
      frenode(node->left);
    if (RIGHT != NILP)
      frenode(node->right);
    break;

  case SM:
    if (LEFT != NILP)
      frenode(node->left);
/*
    if (AXIS != NILP)
      frenode(node->a.axis);
*/
    if (RIGHT != NILP)
      frenode(node->right);
    break;

  case ASYSVAR:
  case SYSVAR:
    if (node->left != NILP)
      frenode(node->left);
    if (node->right != NILP)
      frenode(node->right);
    break;

  case SUBASSIGN:
    frenode(node->left);
    frenode(node->right);
    frenode(node->a.axis);
    frenode(node->store);
    break;

  case BOXASSIGN:
  case CISCALAR:
  case CIVEC:
  case COLLECT:
  case CCOLLECT:
  case CSCALAR:
  case CVEC:
  case DQQUAD:
  case DBOX:
  case DOMINO:
  case EXECUTE:
  case FORMAT:
  case GO:
  case INNER:
  case IOTA:
  case MSOP:
  case MSYSFUN:
  case QBOXAS:
  case RAVEL:
  case RHO:
  case RHORHO:
  case ROLL:
  case SORT:
  case TRANS:
    frenode(node->right);
    break;

  case DECODE:
    frenode(node->left);
    frenode(node->right);
    frenode(node->store);
    break;

  case ASSIGN:
  case CGOTO:
  case DBOXAS:
  case DQBOXAS:
  case DSOP:
  case DEAL:
  case DFORMAT:
  case DROP:
  case DSYSFUN:
  case DTRANS:
  case ENCODE:
  case EPSILON:
  case ESYSFUN:
  case INDEX:
  case INNERCHILD:
  case MSOLVE:
  case OUTER:
  case RESHAPE:
  case SUB:
  case TAKE:
  case GWTAKE:
  case GWDROP:
    frenode(node->left);
    frenode(node->right);
    break;
  }
  free((char *) node);
}

/* sws  collect code writing functions 6/91 */
/* used in pass.c
           apl.y / yy_tab.c (parser)
*/
extern void
writecode(int top, struct headnode * head,
    struct symnode * syms, struct statenode * code)
{

#ifdef CHARINT
  printf("\n");
  putcharn((char) top);
  printf("\n");
#else
  putcharn((char) top);
#endif

  putheader(head);
  putsyms(syms);
  putconsts();
  putcode(code);
}

/* sws

Test for flag to pipe intermediate results as integers rather than
characters. For dos text file mode.

The functions are used in: iotree.c, pass.c, psym.c

*/

#ifdef CHARINT
/* sws */
/* write c*n chars as ints */
void
fwriten(char *p, int n, int c, FILE * iop)
{
  int i, s;

  s = n * c;
  for (i = 0; i < s; i++) {
    /* (void) fprintf(iop,"%5d",*(p+i) ); */
    printf("%5d", *(p + i));
  }
}

/* sws */
/* put a single char as an int */
void
putcharn(char c)
{
  printf("%5d ", c);
}

/* sws */
/* read n*c chars as ints */
void
freadn(char *p, int n, int c, FILE * iop)
{
  int i, val, s;

  s = n * c;
  for (i = 0; i < s; i++) {
    /* (void) fscanf(iop,"%d", &val );*/
    scanf("%d", &val);
    *(p + i) = val;
    /* (void) fprintf(stderr,"freadn charn is %d \n",val ); */
  }
}

/* sws */
/* get a single char as an int */
int
getcharn(void)
{
  int val;

  if (scanf("%d", &val) != EOF) {
    /* (void) fprintf(stderr,"charn is %d\n",val ); */
    return (val);
  } else
    return ((int) EOF);
}

#endif


/* end of iotree.c */
