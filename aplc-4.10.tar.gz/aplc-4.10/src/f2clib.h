/* for sgi only? */

#ifndef _F2CLIB
#define _F2CLIB

#define pow_di(x,i)  pow(x,(double) i)
#define d_lg10(x)    log10(x)
#define d_sign(x,y)  ((y>=0.0) ? fabs(x) : -fabs(x))

#endif
