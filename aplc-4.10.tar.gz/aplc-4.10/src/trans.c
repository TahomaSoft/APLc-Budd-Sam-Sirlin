/*
	APL Compiler

	Generate code for those operators that can be merge into
	a single accessor
	(rotation, transpose, etc)
	tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

#include <stdio.h>
#include "parse.h"
#include "gen.h"

/* local functions */
static void topmerge(struct node * node);
static void prqsd(struct node * node);
static void midmerge(struct node * node, struct node * child);
static void mergevalue(struct node * node, struct node * child);
static void freemerge(struct node * node);


/* topmerge -
	we are at the top of a mergeable unit -
	create the initial values for the vectors q, s and d
	(q,t,d) in the book
*/

 /* remember the top of the current stack of mergeable operators 

    sws: Note that this was originally used throughout - clearly
    incorrect if there is more than 1 structural function after
    merging Hence this is now used only in the first pass, then
    pointed to in store.  */
static struct node *topnode;

/* this is called during the shape phase, only by the top node in a
   set of merged structural nodes

   sws: note this allocates stuff in 3 mp's, that need to be freed
   later..  

	ptr1 - q
	ptr2 - s
	ptr3 - d

	ptr8 - rank

*/
static void
topmerge(struct node * node)
{

  topnode = node;
  node->store = node;
  if (!(node->info & NOINDEX)) {
    ieq(node->ptr8);
    printf("aplc_qsdalloc(");
    ctgen(node->rank.c);
    printf(", &mp%d, &mp%d, &mp%d);\n",
	node->ptr1, node->ptr2, node->ptr3);
    switchbox(node, COMBINE, 0);
  }
}

/* prqsd - print out the q, s and d arguments in a function call */
static void
prqsd(struct node * node)
{
  printf("mp%d.ip, mp%d.ip, mp%d.ip",
      node->ptr1, node->ptr2, node->ptr3);
}

/* midmerge 

   - called in the COMBINE phase of a merged node, shape phase
   - called originally from topmerge 
   - this traverses down the merge list, modifying q,s,d as it goes.
    
    note that shape calculations are done first, traversing up the
    node list

   sws: note that accessor allocates space that needs to be freed 

	ptr4 - alpha
	ptr5 - delta

*/
static void
midmerge(struct node * node, struct node * child)
{
  /* save topnode */
  node->store = topnode;

  if (is_mergeable(child))
    switchbox(child, COMBINE, 0);
  else if (!(child->info & NOINDEX)) {
    ieq(node->ptr4);		     /* alpha */
    printf("aplc_accessor(");
    rns(topnode);
    commasp();
    rns(child);
    printf(", &mp%d, ", node->ptr5);
    prqsd(node);
    rpseminl();
    if (topnode->info & SEQUENTIAL)
      ieqi(child->index, node->ptr4);
  }
}

/*
  mergevalue - do value phase processing of mergeable node 
  called during the value phase
  here use store rather than topnode


	ptr4 - alpha
	ptr5 - delta
	ptr6 - temporary variable
	ptr7 - counter
	ptr8 - rank

	ptr10 - result

*/
static void
mergevalue(struct node * node, struct node * child)
{
  /* take care of trivial case first */
  if (is_mergeable(child) || (child->info & NOINDEX)) {
    switchbox(child, VALUE, 0);
    node->values.c = child->values.c;
    return;
  }
  /* now we can get down to business */

/*  if (!(topnode->info & SEQUENTIAL)) {*/
  if (!(STORE->info & SEQUENTIAL)) {
    ieqi(node->ptr6, node->index);
    ieqi(child->index, node->ptr4);
    izloop(node->ptr7, node->ptr8);
    printf("i%d += i%d * *(mp%d.ip + i%d);\n",
	child->index, node->ptr6, node->ptr5, node->ptr7);
    printf("i%d /= *(", node->ptr6);
    /* ctgen(topnode->shape.c);*/
    ctgen(STORE->shape.c);
    printf(" + i%d);\n", node->ptr7);
    rbr();
  }
  switchbox(child, VALUE, 0);
  node->values.c = child->values.c;

/*  if (topnode->info & SEQUENTIAL) {*/
  if (STORE->info & SEQUENTIAL) {
    resinreg(node, node->ptr10);
    /* tmp = *(res_shape +(res_rank-1)); */
    ieq(node->ptr6);
    /*ctgen(gmon(deref, gsop(APLC_PLUS, topnode->shape.c,*/
    ctgen(gmon(deref, gsop(APLC_PLUS, STORE->shape.c,
			   gsop(APLC_MINUS, gicn(iptr, node->ptr8, APLC_INT),
				gicn(icnst, 1, APLC_INT)))));
    seminl();
    izloop(node->ptr7, node->ptr8);
    printf("i%d += *(mp%d.ip + i%d);\n",
	   child->index, node->ptr5, node->ptr7);
    printf("if (0 == ((i%d + 1) %% i%d))\n",
	   STORE->index, node->ptr6);
    /*	topnode->index, node->ptr6);*/
    printf("i%d *= ", node->ptr6);
    /*    ctgen(gmon(deref, gsop(APLC_PLUS, topnode->shape.c,*/
    ctgen(gmon(deref, gsop(APLC_PLUS, STORE->shape.c,
			   gsop(APLC_MINUS, gicn(iptr, node->ptr7, APLC_INT),
				gicn(icnst, 1, APLC_INT)))));
    seminl();
    printf("else\nbreak;\n}\n");
  }
}

/* freemerge -
	free up the storage used by the merged operands
        only called by non-merged nodes 

	ptr1 - q
	ptr2 - s
	ptr3 - d

	ptr5 - delta

 */
static void
freemerge(struct node * node)
{
#ifdef DEBUGFREE
  printf("/* -- free the accessor junk */\n");
#endif
  /* these are created by topmerge, for qsdalloc */
  if (!(node->info & NOINDEX)) {
    mpfree(node->ptr1);
    mpfree(node->ptr2);
    mpfree(node->ptr3);
  }
  /* this is created by accessor, put in by midmerge 
     note that child of midmerge is always right...
     */
  if (!(RIGHT->info & NOINDEX) )
    mpfree(node->ptr5);
#ifdef DEBUGFREE
  printf("/* -- */\n");
#endif
}

/*
  gentrans -
  generate code for monadic transpose
*/
void
gentrans(struct node * node, enum pmodes mode, int top)
{
/*
	ptr1 - q
	ptr2 - s
	ptr3 - d
	ptr4 - alpha
	ptr5 - delta
	ptr6 - temporary variable
	ptr7 - counter
	ptr8 - rank
	ptr9 - shape
	ptr10 - result
*/
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 1, 0);
    if (!(node->info & SHAPEKNOWN)) {
      setrank(node->ptr8, node);
      impalloc(node->ptr9, node->ptr8);
      izloop(node->ptr7, node->ptr8);
      mpipieq(node->ptr9, node->ptr7);
      printf("*(");
      ctgen(RIGHT->shape.c);
      printf(" + (i%d - i%d) - 1);\n", node->ptr8, node->ptr7);
      rbr();
      node->shape.c = gicn(memptr, node->ptr9, APLC_INT);
    }
    if (!(node->info & MERGED))
      topmerge(node);
    break;

  case COMBINE:
    printf("aplc_trmerge(");
    ctgen(node->rank.c);
    commasp();
    prqsd(node);
    rpseminl();
    midmerge(node, RIGHT);
    break;

  case VALUE:
    mergevalue(node, RIGHT);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    if (!(node->info & MERGED))
      freemerge(node);
    break;
  }
}

/*
	genreverse - generate code for monadic reversal
*/
void
genreverse(struct node * node, enum pmodes mode, int top)
{
/*
	ptr1 - q
	ptr2 - s
	ptr3 - d
	ptr4 - alpha
	ptr5 - delta
	ptr6 - temporary variable
	ptr7 - counter
	ptr8 - rank
	ptr9 - axis
	ptr10 - result
*/
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 1, 1);
    axies(node, node->a.axis, RIGHT, node->ptr9, 0, 0);
    if (!(node->info & MERGED))
      topmerge(node);
    break;

  case COMBINE:
    /* for a merged node */
    /* t' = s - t - 1 */
    /*  *(mp2.ip + i9) = ( *(shape + i9) - *(mp2.ip + i9) ) -1; */
    mpipieq(node->ptr2, node->ptr9);
    lp();
    trepi(node->shape.c, node->ptr9);
    printf(" - ");
    dmppi(node->ptr2, node->ptr9);
    printf(") -1;\n");
    /* d' = -d */
    /* *(mp3.ip + i9) = - *(mp3.ip + i9); */
    mpipieq(node->ptr3, node->ptr9);
    printf(" - ");
    dmppi(node->ptr3, node->ptr9);
    seminl();
    midmerge(node, RIGHT);
    break;

  case VALUE:
    mergevalue(node, RIGHT);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    if (!(node->info & MERGED))
      freemerge(node);
    break;
  }
}

/*
	gentake - generate code for take function

	ptr1 - left trs
	ptr2 - right trs
	ptr3 - result trs
	ptr4 - mp for values
	ptr5 - result values

	sws new fn based on gendfun 
*/
void
gentake(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    filtrs(node->ptr1, LEFT);
    filtrs(node->ptr2, RIGHT);

    /* aplc_take(res, left, right); */
    printf("aplc_take(");
    printf("&trs%d, &trs%d, ", node->ptr3, node->ptr1);
    printf("&trs%d", node->ptr2);
    rpseminl();

    if (!(node->info & TYPEKNOWN))
      node->type.c = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
    if (!(node->info & RANKKNOWN))
      node->rank.c = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
    if (!(node->info & SHAPEKNOWN))
      node->shape.c = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);
    node->values.c = gtrs(node->ptr3, cvalfield, rtype(node));

    if (rtype(node) == APLC_UKTYPE)
      leafshape(node, node->ptr4);
    else if ((node->info & SEQUENTIAL) && !is_scalar(node))
      leafshape(node, node->ptr4);
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node), node->ptr5);
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);

    /* deallocate the shapes of the trs's created 
     - this may need rethinking later ... */
    trs_shape_free(node->ptr1);
    trs_shape_free(node->ptr2);

    if ( !(node->info & ASSIGNP) )  {
      /* should free the trs for the result, except if the previous
	 node is assign, which will use the trs directly */
#ifdef DEBUGFREE
      printf("/* -- gendfun finish */\n");
#endif
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/*
	gengwtake - generate code for take function
*/
void
gengwtake(struct node * node, enum pmodes mode, int top)
{
/*
	ptr1 - q
	ptr2 - s
	ptr3 - d
	ptr4 - alpha
	ptr5 - delta
	ptr6 - temporary variable
	ptr7 - counter
	ptr8 - rank
	ptr9 - shape
	ptr10 - result
*/
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 1, 0);
    if (!(node->info & SHAPEKNOWN)) {
      setrank(node->ptr6, node);
      impalloc(node->ptr9, node->ptr6);
      izloop(node->ptr7, node->ptr6);
      mpipieq(node->ptr9, node->ptr7);
      printf("aplc_iabs(");
      trepi(LEFT->values.c, node->ptr7);
      rpseminl();
      rbr();
      node->shape.c = gicn(memptr, node->ptr9, APLC_INT);
    }
    if (!(node->info & MERGED))
      topmerge(node);
    break;

  case COMBINE:
    rkloop(node, node->ptr7, node->ptr6);
    ctzero(LEFT->values.c, node->ptr7, "<");
    dmppi(node->ptr2, node->ptr7);
    printf(" += ");
    trepi(RIGHT->shape.c, node->ptr7);
    printf(" + ");
    trepi(LEFT->values.c, node->ptr7);
    seminl();
    rbr();
    midmerge(node, RIGHT);
    break;

  case VALUE:
    mergevalue(node, RIGHT);
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    if (!(node->info & MERGED))
      freemerge(node);
    break;

  }
}

/*
	gendrop - generate code for drop function


	ptr1 - left trs
	ptr2 - right trs
	ptr3 - result trs
	ptr4 - mp for values
	ptr5 - result values

*/
void
gendrop(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    filtrs(node->ptr1, LEFT);
    filtrs(node->ptr2, RIGHT);

    /* aplc_drop(res, left, right); */
    printf("aplc_drop(");
    printf("&trs%d, &trs%d, ", node->ptr3, node->ptr1);
    printf("&trs%d", node->ptr2);
    rpseminl();

    if (!(node->info & TYPEKNOWN))
      node->type.c = gtrs(node->ptr3, ctypefield, APLC_UKTYPE);
    if (!(node->info & RANKKNOWN))
      node->rank.c = gtrs(node->ptr3, crankfield, APLC_UKTYPE);
    if (!(node->info & SHAPEKNOWN))
      node->shape.c = gtrs(node->ptr3, cshapefield, APLC_UKTYPE);
    node->values.c = gtrs(node->ptr3, cvalfield, rtype(node));

    if (rtype(node) == APLC_UKTYPE)
      leafshape(node, node->ptr4);
    else if ((node->info & SEQUENTIAL) && !is_scalar(node))
      leafshape(node, node->ptr4);
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr4, rtype(node),
	node->ptr5);
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);

    /* deallocate the shapes of the trs's created 
     - this may need rethinking later ... */
    trs_shape_free(node->ptr1);
    trs_shape_free(node->ptr2);

    if ( !(node->info & ASSIGNP) )  {
      /* should free the trs for the result, except if the previous
	 node is assign, which will use the trs directly */
#ifdef DEBUGFREE
      printf("/* -- drop finish */\n");
#endif
      printf("aplc_detalloc(&trs%d);\n", node->ptr3);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/*
	gengwdrop - generate code for drop function

 k drop a
 sequential access:

      for (i = a.rank-1; i >= 0; i--)
        shape[i] = a.shape[i] - aplc_iabs(k[i]);
      qsdalloc(a.rank, q,  s,  d); 

      for (i = a.rank-1; i >= 0; i--)
        if (k[i] >= 0)
	   s[i] += k[i];
      alpha = accessor(a.rank, shape, 
                       a.rank, a.shape, 
                       delta, q, s, d);

      index = alpha;  		       

      settrs(result...)
      talloc(result);

      for (i = 0; i < size; i++) {
	result = a.value.p[index];
	temp = shape[a.rank-1];
	for (j = a.rank - 1; j >= 0; j--) {
	  index += delta[i];
	  if (0 == ((i + 1) % temp))
	    temp *= shape[j-1];
	  else
	    break;
	}
      }


*/
void
gengwdrop(struct node * node, enum pmodes mode, int top)
{
/*
	ptr1 - q
	ptr2 - s
	ptr3 - d
	ptr4 - alpha
	ptr5 - delta
	ptr6 - temporary variable
	ptr7 - counter
	ptr8 - rank
	ptr9 - shape
	ptr10 - result
*/
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 1, 0);
    if (!(node->info & SHAPEKNOWN)) {
      /* ptr6 = rank */
      setrank(node->ptr6, node);
      /* allocate space for shape vector */
      impalloc(node->ptr9, node->ptr6);
      /* count down loop from rank */
      izloop(node->ptr7, node->ptr6);
      /* shape[ptr7] = r_shape[ptr7] - aplc_iabs( left[ptr7] ) */
      mpipieq(node->ptr9, node->ptr7);
      trepi(RIGHT->shape.c, node->ptr7);
      printf(" - aplc_iabs(");
      trepi(LEFT->values.c, node->ptr7);
      rpseminl();
      rbr();
      /* assign this shape */
      node->shape.c = gicn(memptr, node->ptr9, APLC_INT);
    }
    if (!(node->info & MERGED))
      topmerge(node);
    break;

  case COMBINE:
    if (is_scalar(LEFT->right)) {
      if (LEFT->info & VALUESKNOWN) {
	top = iconsts[valvalue(LEFT)];
	if (top > 0) {		     /* jbww ukc 6/87 */
	  /* if (top < 0) { */
	  printf("*mp%d.ip += %d;\n",
	      node->ptr2, top);
	}
      } else {
	ctzero(LEFT->values.c, 0, ">=");
	/* ctzero(LEFT->values.c, node->ptr7, ">=");*/
	/* need a deref here */
	/* printf("*mp%d.ip += ", node->ptr2); */
	printf("*mp%d.ip += *", node->ptr2);
	ctgen(LEFT->values.c);
	seminl();
      }
    } else {
      rkloop(node, node->ptr7, node->ptr6);
      ctzero(LEFT->values.c, node->ptr7, ">=");
      dmppi(node->ptr2, node->ptr7);
      printf(" += ");
      trepi(LEFT->values.c, node->ptr7);
      seminl();
      rbr();
    }
    midmerge(node, RIGHT);
    break;

  case VALUE:
    mergevalue(node, RIGHT);
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    if (!(node->info & MERGED))
      freemerge(node);
    break;

  }
}

/*
	gendtrans -
		generate code for dyadic transpose
*/
void
gendtrans(struct node * node, enum pmodes mode, int top)
{
/*
	ptr1 - q
	ptr2 - s
	ptr3 - d
	ptr4 - alpha
	ptr5 - delta
	ptr6 - temporary variable
	ptr7 - counter
	ptr8 - rank
	ptr9 - shape
	ptr10 - result
*/
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 1, 0, 0);
    if (!(node->info & SHAPEKNOWN)) {
      /* rkeq(node, node->ptr6);*/
      rkeq(node, node->ptr8);
      printf("aplc_dtshape(&mp%d, ", node->ptr9);
      ctgen(LEFT->values.c);
      commasp();
      rns(RIGHT);
      rpseminl();
      /* ieqi(node->ptr6, node->ptr8);*/
      node->shape.c = gicn(memptr, node->ptr9, APLC_INT);
    }
    if (!(node->info & MERGED))
      topmerge(node);
    break;

  case COMBINE:
    printf("aplc_dtmerge(");
    ctgen(LEFT->values.c);
    commasp();
    ctgen(RIGHT->rank.c);
    printf(", &mp%d, &mp%d, &mp%d);\n",
	node->ptr1, node->ptr2, node->ptr3);
    midmerge(node, RIGHT);
    break;

  case VALUE:
    mergevalue(node, RIGHT);
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    if (!(node->info & MERGED))
      freemerge(node);
    break;

  }
}

/* end of trans.c */
