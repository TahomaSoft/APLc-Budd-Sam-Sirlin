/*
	APL Compiler

	new parse tree functions for array input
	Samuel W.  Sirlin (sws)

	The APL Compiler is Public Domain It may be freely
	redistributed as long as this notice of authorship is retained
	with the sources.

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever */

#include <stdio.h>
#include <string.h>

#include "parse.h"
#include "ptree.h"
#include "y_tab.h"

/* externals from yacc */
extern void prog(struct headnode * head, struct statenode * code);
extern void yyerror(char *c);

/* local functions */
static void pr_ivec(int *s, int r, char *c);
static void pr_rvec(double *s, int r, char *c);
static void show_ivec(int *s, int r);
static void show_rvec(double *s, int r);
static void show_shapes(struct node *x, char *n);
static void show_status(struct node *x);
static void show_consts(void);

static int isIorB(int type);
static void shiftcon(int type, int n, int start, int end);
static void mvcon(int otype, int type, int ostart, int oend, int nstart);
static int node_type(int type);

/* > 0 for debugging prints */ 
#define ARdebug 0


/* string arrays:

shape 1,2
('aa'
)

shape 2,3
('aaa'
'bbb')

shape 1,2,3
('aaa'
'bbb'
)

shape 2,2,3
('aaa'
'bbb'

'ccc'
'ddd')

shape 3,2,3
('aaa'
'bbb'

'ccc'
'ddd'

'ddd'
'fff')


*/ 
/* storage of information on char strings */
/* indication if we're in the middle of a string array */
static int building_str = 0;
/* save first last axis length for checking */
static int len_check;
/* count nl's between strings */
static int nl_count = 0;

/* numeric stuff */

static void
pr_ivec(int *s, int r, char *c)
{
  fprintf(stderr,"%s = ",c);
  show_ivec(s,r);
  fprintf(stderr,"\n");
}

static void
pr_rvec(double *s, int r, char *c)
{
  fprintf(stderr,"%s = ",c);
  show_rvec(s,r);
  fprintf(stderr,"\n");
}

static void
show_ivec(int *s, int r)
{
  int i;

  fprintf(stderr,"[");
  for (i=0; i<r; i++)
    fprintf(stderr," %d", s[i]);
  fprintf(stderr,"]");
}

static void
show_rvec(double *s, int r)
{
  int i;

  fprintf(stderr,"[");
  for (i=0; i<r; i++)
    fprintf(stderr," %g", s[i]);
  fprintf(stderr,"]");
}

static void
show_shapes(struct node *x, char *n)
{
  fprintf(stderr, "%s rank %d, shape ", n, x->rank.n);
  if (x->rank.n)
    show_ivec( &iconsts[x->shape.n], x->rank.n);
  fprintf(stderr, "\n");
}

static void
show_status(struct node *x)
{
  fprintf(stderr, "nl_count %d\n", nl_count);
  fprintf(stderr, "type %d, ", x->type.n);
  show_shapes(x,"current");
}

static void
show_consts(void)
{
  int i,k;

  pr_ivec(iconsts, ictop, "ic");
  pr_rvec(rconsts, rctop, "rc");

  fprintf(stderr,"zc = [");    
  for (i=0; i<zctop; i++) {
    fprintf(stderr,"(");    
    for (k=0; k<2; k++)
      fprintf(stderr," %g ",zconsts[k][i]);
    fprintf(stderr,")");    
  }
  fprintf(stderr,"]\n");    

}

/* start a string array 
   - we know the rank is at least 2 */
extern struct node *
ptsta(char *chars)
{
  struct node *x;
  int len;

  x = newnode(SCON);
  x->type.n = (int) APLC_CHAR;
  len = slen(chars);
  len_check = len;
  x->shape.n = addicon(1);
  addicon(len);
  x->rank.n = 2; /* at least an array */
  x->values.n = slen(sconsts);/* starting point */
  x->info |= (TYPEDECL | TYPEKNOWN | RANKDECL | RANKKNOWN |
	      SHAPEKNOWN | VALUESKNOWN);
  if (strlen(chars) + strlen(sconsts) > MAXCONSTS)
    yyerror("too many string constants");
  strcat(sconsts, chars);
  building_str = 1;
  nl_count = 1;

  free(chars);/* was built with strdup */ 
#if ARdebug >0
  fprintf(stderr,"[ptsta] len %d, [%s]\n",len, chars);
#endif
  return (x);
}

/* add a string to a string array 
   - update new_shape */
extern struct node *
addsta(struct node *x, char *chars)
{
  int len, new_rank;
  int i;

#if ARdebug >0
  show_status(x);
#endif
  len = slen(chars);
  /* check len against last axis */
  if (len !=  len_check) {
    fprintf(stderr,"[addsta] current shape ");
    show_ivec( &iconsts[x->shape.n], x->rank.n);
    fprintf(stderr,", new length %d\n", len);
    yyerror("shape error");    
  }
  if (strlen(chars) + strlen(sconsts) > MAXCONSTS)
    yyerror("too many string constants");
  strcat(sconsts, chars);

  /* consider nl's before this */
  new_rank = nl_count+1;
  if (new_rank > x->rank.n) {
    /* at least 1 new axis */
    while (new_rank > x->rank.n) { 
      addicon(1);
      for (i=x->rank.n; i>0; i--)
	iconsts[x->shape.n +i] = iconsts[x->shape.n + i-1];
      iconsts[x->shape.n] = 1;
      x->rank.n++;  
    }
    iconsts[x->shape.n]++;
  } else if (new_rank == x->rank.n) {
    /* increment current shape */
    iconsts[x->shape.n]++;
  }
  /* else lesser shape; already done */

  nl_count = 0;
  free(chars);/* was built with strdup */ 

#if ARdebug >0
  fprintf(stderr,"[addsta] len %d, [%s]\n",len, chars);
#endif
  return x;
}

/* add an nl to a string array */  
extern struct node *
addstanl(struct node * x)
{
  nl_count++;
#if ARdebug >0
  fprintf(stderr,"[addstanl] count %d\n", nl_count);
#endif
  return x;
}

/* finish a string array */
extern struct node *
finsta(struct node * x)
{
  building_str = 0;
#if ARdebug >0
  fprintf(stderr,"[finsta]\n");
  show_status(x);
#endif
  return x;
}

/* extra for numeric arrays */
/*static int vec_type = 0;*/

/* start a numeric array 
   - we know the rank is at least 2 
   - must have called ptvec() just before this */
extern struct node *
pt_na(struct node *x)
{
  len_check = iconsts[x->shape.n];
  x->rank.n = 2; /* at least an array */
  addicon(len_check);
  iconsts[x->shape.n] = 1;
  building_str = 1;
  nl_count = 1;
  x->size.n = len_check;
#if ARdebug >0
  fprintf(stderr,"[pt_na] type %d, len %d\n",x->type.n, len_check);
#endif
  return (x);
}

static int
isIorB(int type)
{
  return (type==APLC_INT) || (type == APLC_BOOL);
}

static int itemp[MAXCONSTS];

/* shift const[type] from start to top by n  
   - open up space to insert other stuff
   - don't increment top
   - numeric type only */
static void
shiftcon(int type, int n, int start, int end)
{
  int i,j;

  if (end > MAXCONSTS) {
    fprintf(stderr, "[shiftcon] type %d\n", type);
    error("too many constants");
  }
  switch(type) {
  default:
    yyerror("[shiftcon] bad type for shift");
    break;
  case APLC_BOOL:
  case APLC_INT:
    for (i=end; i>= start; i--)
      iconsts[i+n] = iconsts[i];
    break;
  case APLC_REAL:
    for (i=end; i>= start; i--)
      rconsts[i+n] = rconsts[i];
    break;
  case APLC_COMPLEX:
    for (i=end; i>= start; i--)
      for (j=0; j<2; j++)
	zconsts[j][i+n] = zconsts[j][i];
    break;
  case APLC_QUAT:
    for (i=end; i>= start; i--)
      for (j=0; j<4; j++)
	qconsts[j][i+n] = qconsts[j][i];
    break;
  case APLC_OCT: 
    for (i=end; i>= start; i--)
      for (j=0; j<8; j++)
	oconsts[j][i+n] = oconsts[j][i];
    break;
  }
  return;
}

/* move a set of constants from one type to a larger type 
   - increment new top
   - decrement old top
 */  
static void
mvcon(int otype, int type, int ostart, int oend, int nstart)
{
  int i,j,k, n, nend;

  n = 1+oend-ostart;
  nend = nstart + n - 1;
  if ((n+nstart) > MAXCONSTS) {
    fprintf(stderr, "[mvcon] type %d\n", type);
    error("too many constants");
  }
  switch(type) {
  default:
    yyerror("[mvcon] bad type");
    break;

  case APLC_BOOL:
  case APLC_INT:
    yyerror("[mvcon] bad type to int");
    break;

  case APLC_REAL:
    switch(otype) {
    default:
      yyerror("[mvcon] bad type to real");
      break;
    case APLC_BOOL:
    case APLC_INT:
      rctop +=n;
      ictop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--)
	rconsts[j] = iconsts[i];
      break;
    }
    break;

  case APLC_COMPLEX:
    switch(otype) {
    default:
      yyerror("[mvcon] bad type to complex");
      break;
    case APLC_BOOL:
    case APLC_INT:
      zctop +=n;
      ictop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	zconsts[0][j] = iconsts[i];
	for (k=1; k<2; k++)
	  zconsts[k][j] = 0.0;
      }
      break;
    case APLC_REAL:
      zctop +=n;
      rctop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	zconsts[0][j] = rconsts[i];
	for (k=1; k<2; k++)
	  zconsts[k][j] = 0.0;
      }
      break;
    }
    break;

  case APLC_QUAT:
    switch(otype) {
    default:
      yyerror("[mvcon] bad type to quat");
      break;
    case APLC_BOOL:
    case APLC_INT:
      qctop +=n;
      ictop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	qconsts[0][j] = iconsts[i];
	for (k=1; k<4; k++)
	  qconsts[k][j] = 0.0;
      }
      break;
    case APLC_REAL:
      qctop +=n;
      rctop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	qconsts[0][j] = rconsts[i];
	for (k=1; k<4; k++)
	  qconsts[k][j] = 0.0;
      }
      break;
    case APLC_COMPLEX:
      qctop +=n;
      zctop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	for (k=0; k<2; k++)
	  qconsts[k][j] = zconsts[k][i];
	for (k=2; k<4; k++)
	  qconsts[k][j] = 0.0;
      }
      break;
    }
    break;

  case APLC_OCT: 
    switch(otype) {
    default:
      yyerror("[mvcon] bad type to oct");
      break;
    case APLC_BOOL:
    case APLC_INT:
      octop +=n;
      ictop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	oconsts[0][j] = iconsts[i];
	for (k=1; k<8; k++)
	  oconsts[k][j] = 0.0;
      }
      break;
    case APLC_REAL:
      octop +=n;
      rctop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	oconsts[0][j] = rconsts[i];
	for (k=1; k<8; k++)
	  oconsts[k][j] = 0.0;
      }
      break;
    case APLC_COMPLEX:
      octop +=n;
      zctop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	for (k=0; k<2; k++)
	  oconsts[k][j] = zconsts[k][i];
	for (k=2; k<8; k++)
	  oconsts[k][j] = 0.0;
      }
      break;
    case APLC_QUAT:
      octop +=n;
      qctop -= n;
      for (i=oend, j=nend; i>= ostart; i--, j--) {
	for (k=0; k<4; k++)
	  oconsts[k][j] = qconsts[k][i];
	for (k=4; k<8; k++)
	  oconsts[k][j] = 0.0;
      }
      break;
    }
    break;
  }
  return;
}

static int
node_type(int type)
{
  int n = 0;

  switch(type) {
  default:
    break;
  case APLC_BOOL:
  case APLC_INT:
    n = ICON;
    break;
  case APLC_REAL:
    n = RCON;
    break;
  case APLC_COMPLEX:
    n = ZCON;
    break;
  case APLC_QUAT:
    n = QCON;
    break;
  case APLC_OCT: 
    n = OCON;
    break;
  }
  return n;
} 


/* add an nvec to a string array 
   - update new_shape */
extern struct node *
add_na(struct node *x, struct node *new)
{
  int len, maxtype;
  int i;
  int oend, end;
  int new_rank;

#if ARdebug >0
  fprintf(stderr,"[add_na]-\n");
  show_status(x);
#endif
  len = new->size.n;

  /* check len against last axis */
  if (len !=  len_check) {
    fprintf(stderr,"[add_na] current shape ");
    show_ivec( &iconsts[x->shape.n], x->rank.n);
    fprintf(stderr,", new length %d\n", len);
    yyerror("shape error");    
  }
  /* if new was a vector, drop shape */
  if (new->rank.n)
    ictop--; 
  /* join the data; types may not match
     note shapes tricky */
  /* get max type */
  maxtype = max(x->type.n, new->type.n);
#if ARdebug >0
  fprintf(stderr," types %d =  %d,%d\n", maxtype, 
	  x->type.n, new->type.n );
  show_status(x);
  show_shapes(new," new");
#endif
  /* if x is an int/bool
        need to shift
        if new is int/bool
           have 
	     (new scalar)
	     (x.val,x.shape,new.val)->(x.val,new.val,x.shape)
	     (new vector)
             (x.val,x.shape,new.val,new.shape)->(x.val,new.val,x.shape)
        else
           shift new
           promote x
           shift x.shape
           promote node
     if types not equal
        if xtype > newtype
           promote new
        else 
           shift new
           promote x        
           promote node
   */
  if ( isIorB(x->type.n) ) {
    if ( isIorB(new->type.n) ) {
      /* have (x.val,x.shape,new.val,new.shape)->
	      (x.val,new.val,x.shape) */
      /* save x shape */
      for (i=0; i<x->rank.n; i++)
	itemp[i] = iconsts[x->shape.n+i];
      /* copy new values to x shape */
      for (i=0; i<len; i++) 
	iconsts[x->shape.n+i] = iconsts[new->values.n+i];
#if 0
      show_ivec(&iconsts[x->values.n], x->size.n+len);
      fprintf(stderr,"\n");
#endif
      new->values.n = x->shape.n;/* temp */
      end = x->values.n + x->size.n + len;
      /* put the shape back, unchanged */
      for (i=0; i<x->rank.n; i++)
	iconsts[end+i] = itemp[i];
      /* reset pointer to x shape */
      x->shape.n = end;
      /* ensure we have the max type */
      if (new->type.n > x->type.n) {
	x->type.n = new->type.n;
	/* promote node type */
	x->nodetype = node_type(x->type.n);
      }
    } else {
      /* int -> larger */
      /*show_consts();*/
      /* shift new up by size of x */
      end = new->values.n + new->size.n;
      shiftcon(new->type.n, x->size.n, new->values.n, end);
      /* promote x from int to new, before new */ 
      oend = x->values.n + x->size.n - 1;
      mvcon(x->type.n, new->type.n, x->values.n, oend, new->values.n);
      /* show_consts();*/
      /* shift x shape down to where x was */
      for (i=0; i<x->rank.n; i++)
	iconsts[x->values.n+i] = iconsts[x->shape.n+i];
      x->shape.n = x->values.n;
      x->values.n = new->values.n;
      x->type.n = new->type.n;
      /* promote node type */
      x->nodetype = node_type(x->type.n);
    }
  } else if (x->type.n != new->type.n) {
    if (x->type.n > new->type.n) {
      /* x > new */
      /*      pr_ivec(iconsts, ictop, "ic0");
	      pr_rvec(rconsts, rctop, "rc0");*/
      oend = new->values.n + new->size.n - 1;
      end = x->values.n + x->size.n;
      mvcon(new->type.n, x->type.n, new->values.n, oend, end);
      /*      pr_ivec(iconsts, ictop, "ic1");
	      pr_rvec(rconsts, rctop, "rc1");*/
    } else {
      /* new > x */
      /*show_consts();*/
      /* shift new by size of x */
      end = new->values.n + new->size.n;
      shiftcon(new->type.n, x->size.n, new->values.n, end);
      /* promote x to new, before new */ 
      oend = x->values.n + x->size.n - 1;
      mvcon(x->type.n, new->type.n, x->values.n, oend, new->values.n);
      /*show_consts();*/
      x->values.n = new->values.n;
      x->type.n = new->type.n;
      /* promote node type */
      x->nodetype = node_type(x->type.n);
    }
  }
  /* get rid of new */
  free(new);

  /* consider nl's before this */
  new_rank = nl_count+1;
  if (new_rank > x->rank.n) {
    /* at least 1 new axis */
    while (new_rank > x->rank.n) { 
      addicon(1);
      for (i=x->rank.n; i>0; i--)
	iconsts[x->shape.n +i] = iconsts[x->shape.n + i-1];
      iconsts[x->shape.n] = 1;
      x->rank.n++;  
    }
    iconsts[x->shape.n]++;
  } else if (new_rank == x->rank.n) {
    /* increment current shape */
    iconsts[x->shape.n]++;
  }
  /* else lesser shape; already done */

  x->size.n += len;
  nl_count = 0;

#if ARdebug >0
  fprintf(stderr,"[add_na]+ len %d\n",len);
  show_status(x);
#endif
  return x;
}

/* add an nl to a string array */  
extern struct node *
add_nanl(struct node * x)
{
  nl_count++;
#if ARdebug >0
  fprintf(stderr,"[add_nanl] count %d\n", nl_count);
#endif
  return x;
}

/* finish a string array */
extern struct node *
fin_na(struct node * x)
{
  building_str = 0;
#if ARdebug >0
  fprintf(stderr,"[fin_na]\n");
  show_status(x);
#endif
  return x;
}



/* end */
