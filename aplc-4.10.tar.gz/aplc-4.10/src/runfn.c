/*
	APL Compiler

        sam sirlin

	Run time system
	routines having to do with scalar functions values

        special functions called in runop.c but missing (or wrong)
        in the pc implementation of gcc

*/
/* # include "aplc.h" */
#include <stdio.h>
#include <math.h>

/* function declarations */
double atanh(double);
double ceil(double);
double floor(double);
int system(int);

/* arc tangent */
double
atanh(double y)
{
  return (log(sqrt((1 + y) / (1 - y))));
}


/* in the following floor, ceiling, use (int) only on positive values */

/* ceiling */
double
ceil(double x)
{
  int i;
  double r;

  if (x < 0.0)
    return (-((int) -x));
  else if (x == 0.0)
    return (0.0);
  else {
    /* x > 0 */
    i = (int) x;
    r = x - (double) i;
    if (r > 0.0)
      return (1 + i);
    else
      return (i);
  }
}

/* floor */
double
floor(double x)
{
  int i;
  double r;

  if (x > 0.0)
    return ((int) x);
  else if (x == 0.0)
    return (0.0);
  else {
    /* x < 0, */
    i = (int) -x;
    r = (-x) - (double) i;
    if (r > 0.0)
      return (-(1 + i));
    else
      return (-i);
  }
}

/* just ignore this call for now */
/* system call ?? */
int
system(int p)
{
  return (0);
}

/* end of runfn.c */