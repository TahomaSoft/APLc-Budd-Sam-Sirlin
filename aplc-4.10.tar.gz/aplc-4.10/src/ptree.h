/*
	APL Compiler

	parse tree function declarations
	Samuel W.  Sirlin (sws)

	The APL Compiler is Public Domain It may be freely
	redistributed as long as this notice of authorship is retained
	with the sources.

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever */


#ifndef _PTREE
#define _PTREE


extern int slen(char *c);

char *newid(char *);
struct headnode *newhead(char *, char *, char *);
void direct(char *, struct node *);
struct statenode *newstate(char *, struct node *);
struct statenode *addstmt(struct statenode *, struct statenode *);
struct node *newnode(int);
struct node *pt1(int, struct node *);
void ptaxis(struct node *, struct node *, int);
void ptgaxis(struct node *, struct node *, int);
struct node *pt1a(int, struct node *, int, struct node *);
struct node *pt1o(int, enum sops, struct node *);
struct node *pt1ao(int, enum sops, struct node *, struct node *, int);
struct node *pt2(int, struct node *, struct node *);
struct node *pt2a(int, struct node *, int, struct node *, struct node *);
struct node *pt2o(int, enum sops, struct node *, struct node *);
struct node *pt2ao(int, enum sops, struct node *, int, 
   struct node *, struct node *);
struct node *pt2aos(int, enum sops, struct node *, int, 
   struct node *, struct node *);
struct node *ptsort(int, struct node *);

struct node *ptsvec(char *);
struct node *ptval(int, int);
struct node *aptval(struct node *);
struct node *ptvec(struct node *, int, int);

struct node *sysparm(char *);
struct node *ptvar(struct symnode *);
struct node *ptfun(struct symnode *, struct node *, struct node *);
struct node *ptnilfun(struct symnode * fun);
struct node *ptmrho(struct node *);
struct node * ptmsys(int type, enum sops op, struct node * child);
struct node *ptstore(int);
struct node *ptsub(struct node *, struct node *);
struct node *ptboxass(struct node * child);
struct node *ptboxlzass(struct node * child);
struct node *pttop(struct node *);
struct node *ptsemi(struct node *, struct node *);
struct node *pttcav(int type, enum sysvars var);

/* from ptree_s.c */

struct node *ptsta(char *chars);
struct node *addsta(struct node *x, char *chars);
struct node *addstanl(struct node * x);
struct node *finsta(struct node * x);

extern struct node *pt_na(struct node *x);
extern struct node * add_na(struct node *x, struct node *new);
extern struct node *add_nanl(struct node * x);
extern struct node *fin_na(struct node * x);

#endif
/* end of ptree.h */
