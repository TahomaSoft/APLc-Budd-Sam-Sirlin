/*
	apl compiler
		intra-procedural dataflow analysis
		timothy a. budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

#include <stdio.h>
#include "parse.h"
#include "y_tab.h"
#include "nutil.h"
#include "util2.h"


/* sws for debugging */
/* level can be 0, 1, 2 
   - right now must be 2?!
*/
#define IDEBUG 0

extern struct label_struct lconsts[];

/* extern void qsort(void *, int, unsigned, int (*ptf) (void *, void *)); */

/* from trs */
void doinf(struct node * node, int top);

extern void error(char *);

/* global variables */
static int nbranchto;
static int branchto[MAXSTMTS];

static struct symnode *currentlist;
static struct symnode *symtab;

/* local function declarations */

static struct symnode *makelist(struct symnode * syms);
static struct symnode *getsinfo(char *name);

int mrgrank(int t1, int t2);
int mrgtype(int t1, int t2);
int merge(struct symnode * list1, int up1, struct symnode * list2,
    int up2);

void doassign(char *name, struct node * node);
void doident(struct node * node);
void dolcon(struct node * node);
static void prsym(struct symnode * syms);
static void dodecl(struct node * node);

/* print out rank */
static void 
prrank(FILE *f, int n)
{
  if (n==NORANK)
    fprintf(f,"(no rank (%d))",n);
  else if(n==ANYRANK)
    fprintf(f,"(any rank (%d))",n);
  else
    fprintf(f,"%d",n);
}


/* comparison function for qsort */
/* descending order */
static int
dcomp(int *i, int *j)
{
  if ( *i < *j )
    return(1);
  else if (*i == *j)
    return(0);
  else
    return(-1);
}

/* main run routine called from pass */
void
doprog(struct headnode * head, struct symnode * syms,
    struct statenode * code)
{
  struct statenode *s, *s2;
  struct statenode *vs[MAXSTMTS];
  int countstmts = 0;
  int newstate, i, j;


#if IDEBUG
  if (head->fname == (char *) 0)
    fprintf(stderr, "\n[intra] main");
  else
    fprintf(stderr, "\n[intra] %s", head->fname);
#endif

  symtab = syms;

  /* associate a copy of the symbol table with each statement */
  /* and count the statements */
  /* and make a statlist vector */
  for (s = code, i=0; s != NILSTATE; s = s->nextstate, i++) {
    countstmts++;
    s->list = makelist(syms);
    vs[i] = s;
  }

  /* make a copy of the symbol table corresponding to the cursor */
  currentlist = makelist(syms);

  /*- now march through the code, updating the cursor, and
      make the local versions into the most general form known */
#if IDEBUG
  fprintf(stderr, "\n[intra] update local symbol tables");
#endif
  stmtno = 1;
  s = code;
  while (s != NILSTATE) {

#if IDEBUG
    fprintf(stderr, "\n[%d]", stmtno);
#endif

    /* initialize branch list */
    nbranchto = 0;
    for (i = 0; i < countstmts; i++)
      branchto[i] = 0;

    /* merge the two lists as they are */
    merge(currentlist, 1, s->list, 1);
    /* update current */
    doinf(s->code, 1);
    /* update the saved list */
    merge(currentlist, 0, s->list, 1);


#if IDEBUG
    /* sws   debugging */
    if (nbranchto > 0) {
      fprintf(stderr, "\n[intra] branchto[%d] = [", stmtno);
      for (i=0; i<nbranchto; i++)
	fprintf(stderr, " %d", branchto[i]);
      fprintf(stderr,"]\n");
    }
#endif

    if (nbranchto > 0) {
      /* there are branches we need to check */
      /* check each branch statement */
      newstate = stmtno + 1;
      for (i = 0; i < nbranchto; i++) {
	j = branchto[i]; 
#if IDEBUG
	fprintf(stderr,"\n[%d] checking branch %d",stmtno,j);
#endif	
	/* s2 = vs[j];*/
	/* sws; vs is origin 0, branches, statment numbers origin 1 */
	s2 = vs[j-1];
	if (merge(currentlist, 0, s2->list, 1) && j < newstate)
	  newstate = j;
      }
      /* now setup next state, at earliest changed branch or next */
#if IDEBUG
      fprintf(stderr,"\n[%d]next is %d",stmtno,newstate);
#endif
      if (newstate < stmtno) {
	/* check past states */
	stmtno = newstate;
	s = vs[newstate-1];
      } else {
	/* just march on */
	s = s->nextstate;
	stmtno++;
      }
    } else {
      /* no branches, just march on */
      s = s->nextstate;
      stmtno++;
    }
  }

  /* need to merge what we know into the fn top */
  fprintf(stderr,"\ninitial symbol list\n");
  prsym(syms);
  /* fprintf(stderr,"current \n");
     prsym(currentlist); */
  /* merge the curentlist with the real symtab */
  merge(currentlist, 0, syms, 1);
  fprintf(stderr,"current symbol list\n");
  prsym(syms);

  /* now go back through the code, for the purpose of adjusting idents
     - globally known things should become declarations
     */
#if IDEBUG
  fprintf(stderr,"[intra] redeclare\n");
#endif
  for (s = code, stmtno=1; s != NILSTATE; s = s->nextstate, stmtno++) {
    /* march through the nodes, just changing idents */
#if IDEBUG
    fprintf(stderr,"[%d]\n",stmtno);
#endif
    dodecl(s->code);
  }

#if IDEBUG
  fprintf(stderr,"\nintra done\n");
#endif
}

/* makelist - generate a copy of the local symbol table list */
static struct symnode *
makelist(struct symnode * syms)
{
  struct symnode *new, *onew;

  new = onew = NILSYM;
  for (; syms != NILSYM; syms = syms->next) {
    new = structalloc(symnode);
    new->next = onew;
    new->type = APLC_UKTYPE;
    new->vrank = NORANK;
    onew = new;
  }
  return (new);
}

/* getsinfo - get current symbol table info for a particular name */
static struct symnode *
getsinfo(char *name)
{
  struct symnode *s, *s2;

  for (s = symtab, s2 = currentlist;
      s != NILSYM; s = s->next, s2 = s2->next)
    if (strcmp(s->name, name) == 0) {
      return (s2);
    }
  return (NILSYM);
}


/* 
   mrgrank - find the most general category for a pair of ranks
 */
int
mrgrank(int t1, int t2)
{
  int maxrank;

  if (t1 == t2)
    maxrank = t1;
  else if (t2 == NORANK)
    maxrank = t1;
  else if (t1 == NORANK)
    maxrank = t2;
  else {
    /* two different numerical values */
    maxrank = ANYRANK;
  }
  return (maxrank);
}

/* mrgtype - find the most general category for a pair of types */
int
mrgtype(int t1, int t2)
{
  int mrmaxtype=0;
  /* int errorflag = 0;*/

  /* first check t2 for validity */
  switch (t2) {
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
  case APLC_CHAR:
  case APLC_ANY:
  case APLC_UKTYPE:
    break;
  default:
    fprintf(stderr, "\ntypes are %s(%d) %s(%d)", 
	    str_type_name(t1),t1, str_type_name(t2), t2);
    error("impossible condition in mrgtype");
  }
  if (t1 == t2)
    mrmaxtype = t1;
  else if (t2 == APLC_UKTYPE)
    mrmaxtype = t1;
  else
    switch (t1) {
    case APLC_BOOL:
    case APLC_INT:
      if (t2 == APLC_INT || t2 == APLC_BOOL)
	mrmaxtype = APLC_INT;
      else 
	mrmaxtype = APLC_ANY;
      break;
    case APLC_REAL:
    case APLC_COMPLEX:
    case APLC_QUAT:
    case APLC_OCT:
      /* t2=same case already caught above 
         don't allow anything else for now... */
      mrmaxtype = APLC_ANY;
      break;
    case APLC_CHAR:
      mrmaxtype = APLC_ANY;
      break;
    case APLC_ANY:
      mrmaxtype = APLC_ANY;
      break;
    case APLC_UKTYPE:
      mrmaxtype = t2;
      break;
    default:
      fprintf(stderr, "\ntypes are %s(%d) %s(%d)", 
	      str_type_name(t1),t1, str_type_name(t2), t2);
      error("impossible condition in mrgtype");
    }
#if 0
  if (errorflag)
    error("some error in mrgtype");
#endif
  return (mrmaxtype);
}


/* old attempt
   - currently can't make quaternion contain complex,
     as then trouble in assign q .is z
   */
#if 0
/* mrgtype - find the most general category for a pair of types */
int
mrgtype(int t1, int t2)
{
  int mrmaxtype=0;
  /* int errorflag = 0;*/

  /* first check t2 for validity */
  switch (t2) {
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
  case APLC_COMPLEX:
  case APLC_QUAT:
  case APLC_OCT:
  case APLC_CHAR:
  case APLC_ANY:
  case APLC_UKTYPE:
    break;
  default:
    fprintf(stderr, "\ntypes are %s(%d) %s(%d)", 
	    str_type_name(t1),t1, str_type_name(t2), t2);
    error("impossible condition in mrgtype");
  }
  if (t1 == t2)
    mrmaxtype = t1;
  else if (t2 == APLC_UKTYPE)
    mrmaxtype = t1;
  else
    switch (t1) {
    case APLC_BOOL:
    case APLC_INT:
      if (t2 == APLC_INT || t2 == APLC_BOOL)
	mrmaxtype = APLC_INT;
      else 
	mrmaxtype = APLC_ANY;
      break;
    case APLC_REAL:
      /* t2=real case already caught above */
      mrmaxtype = APLC_ANY;
      break;
    case APLC_COMPLEX:
      if (t2 == APLC_QUAT)
	mrmaxtype = APLC_QUAT;
      else if (t2 == APLC_OCT)
	mrmaxtype = APLC_OCT;
      else
	mrmaxtype = APLC_ANY;
      break;
    case APLC_QUAT:
      if (t2 == APLC_COMPLEX)
	mrmaxtype = APLC_QUAT;
      else if (t2 == APLC_OCT)
	mrmaxtype = APLC_OCT;
      else
	mrmaxtype = APLC_ANY;
      break;
    case APLC_OCT:
      if (t2 == APLC_COMPLEX)
	mrmaxtype = APLC_OCT;
      else if (t2 == APLC_QUAT)
	mrmaxtype = APLC_OCT;
      else
	mrmaxtype = APLC_ANY;
      break;
    case APLC_CHAR:
      mrmaxtype = APLC_ANY;
      break;
    case APLC_ANY:
      mrmaxtype = APLC_ANY;
      break;
    case APLC_UKTYPE:
      mrmaxtype = t2;
      break;
    default:
      fprintf(stderr, "\ntypes are %s(%d) %s(%d)", 
	      str_type_name(t1),t1, str_type_name(t2), t2);
      error("impossible condition in mrgtype");
    }
#if 0
  if (errorflag)
    error("some error in mrgtype");
#endif
  return (mrmaxtype);
}
#endif

/* merge - merge two symbol table lists together,
     returning 1 if any changes are noted.
     Only update a list if the corresponding ``up'' argument is 1 */

int
merge(struct symnode * list1, int up1, struct symnode * list2, int up2)
{
  int errorflag, changed;
  int t1, t2, maxt;
  int r1, r2, maxrank;

  changed = errorflag = 0;
  for (; list1 != NILSYM; list1 = list1->next, list2 = list2->next) {
    if (list2 == NILSYM)
      error("impossible merge condition");
    t1 = list1->type;
    t2 = list2->type;
    maxt = mrgtype(t1, t2);
    if (up1 && t1 != maxt) {
      changed = 1;
      list1->type = maxt;
    }
    if (up2 && t2 != maxt) {
      changed = 1;
      list2->type = maxt;
    }
    r1 = list1->vrank;
    r2 = list2->vrank;
    maxrank = mrgrank(r1, r2);
    if (up1 && r1 != maxrank) {
      changed = 1;
      list1->vrank = maxrank;
    }
    if (up2 && r2 != maxrank) {
      changed = 1;
      list2->vrank = maxrank;
    }
  }
  return (changed);
}

/* sws  routines called in itrs.c */
/* doassign - update the currentlist from an assignment */
void
doassign(char *name, struct node * node)
{
  struct symnode *s, *s2;

  for (s = symtab, s2 = currentlist;
      s != NILSYM; s = s->next, s2 = s2->next)
    if (strcmp(s->name, name) == 0) {
      if (node->info & TYPEKNOWN)
	s2->type = mrgtype(s2->type, node->type.n);
      else
	s2->type = APLC_ANY;
      if (node->info & RANKKNOWN) {
#if (IDEBUG > 1)
	fprintf(stderr, "\n[intra/asign] ");
	fprintf(stderr, "%s rank known = ", name); 
	prrank(stderr,node->rank.n);
#endif
	s2->vrank = mrgrank(s2->vrank, node->rank.n);
      } else {
	s2->vrank = ANYRANK;
#if (IDEBUG > 1)
	fprintf(stderr, "\n[intra/asign] ");
	fprintf(stderr, "%s rank unknown, now ",name); 
	prrank(stderr,s2->vrank);
#endif
      }
    }
  /*--- sws   for debugging rank inferencing: */
  switch(node->nodetype) {
  default:
    break;
  case ASSIGN:
#if (IDEBUG > 1)
    s = getsinfo(LEFT->a.namep);
    if (s) {
      if (s->type != APLC_UKTYPE) 
	fprintf(stderr, "\n[intra/asign] the type of %s is %s(%d)",
		LEFT->a.namep, str_type_name(s->type),s->type);
      if (s->vrank != NORANK)
	fprintf(stderr,"\n[intra/asign] the rank for %s is ",
		LEFT->a.namep); prrank(stderr,s->vrank);
    }
#endif
    /* now see if we can update the ident information */
    doident(LEFT);
    break;
  case SM:
    /* sub asssign store child */
#if (IDEBUG > 1)
    s = getsinfo(name);
    if (s) {
      if (s->type != APLC_UKTYPE) 
	fprintf(stderr, "\n[intra/asign] the type of %s is %s(%d)",
		name, str_type_name(s->type),s->type);
      if (s->vrank != NORANK)
	fprintf(stderr,"\n[intra/asign] the rank for %s is ",
		name); prrank(stderr,s->vrank);
    }
#endif
    break;
  }
  return;
}

/* sws   code moved here from itrs.c */
/* doident - do trs inferencing on an identifier
*/
void
doident(struct node * node)
{
  struct symnode *s;

  s = getsinfo(node->a.namep);
  if (s) {
    if (node->info & TYPEKNOWN) {
      /* must have been declared */
      if (s->type != APLC_UKTYPE) {
	node->type.n = mrgtype(node->type.n, s->type);

#if (IDEBUG > 1)
	  fprintf(stderr,"\n[intra/doident] ");
	  fprintf(stderr,"improving the type for %s to %s(%d)",
	   node->a.namep, str_type_name(node->type.n),node->type.n);
#endif
      }
    } else if (s->type != APLC_UKTYPE) {
      node->type.n = s->type;
      node->info |= TYPEKNOWN;
#if (IDEBUG > 1)
      fprintf(stderr,"\n[intra/doident] ");
      fprintf(stderr,"inferring the type for %s to %s(%d)",
	      node->a.namep, str_type_name(node->type.n), node->type.n);
#endif
    }
    if (node->info & RANKKNOWN) {
      /* must have been declared */
      if (s->vrank != NORANK) {
	node->rank.n = mrgrank(node->rank.n, s->vrank);
#if (IDEBUG > 1)
	  fprintf(stderr,"\n[intra/doident] ");
	  fprintf(stderr,"improving the rank for %s to ",
		  node->a.namep); prrank(stderr,node->rank.n);
#endif 
      }
    } else if (s->vrank != NORANK) {
      node->rank.n = s->vrank;
      node->info |= RANKKNOWN;
#if (IDEBUG > 1)
      fprintf(stderr,"\n[intra/doident] ");
      fprintf(stderr,"inferring the rank for %s to ",
	      node->a.namep); prrank(stderr,node->rank.n);
#endif
    }
  }
}

/* sws   new code  */
/* dolcon - store branch information for intra
*/
void
dolcon(struct node * node)
{
  /* assume we are in a branch statement */
  /* later add flag in go */

  /* add current value to list */
  branchto[nbranchto++] = lconsts[node->values.n].label_num;
}

/* print out a symbol table */
static void
prsym(struct symnode * syms)
{
  struct symnode *s;

  for (s = syms; s != (struct symnode *) 0; s = s->next) {
    fprintf(stderr,"\t%s: type= {%s}", s->name, str_type_name(s->type));
    fprintf(stderr," rank= %s", str_rank(s->vrank));
    fprintf(stderr,"\n");
  }
}


/* just march through a line, adjusting ident declarations */
static void
dodecl(struct node * node)
{
  struct symnode *s;

  /* fprintf(stderr,"[dodecl] %s\n", prtoken(node->nodetype)); */
  switch (node->nodetype) {
  default:
    if (LEFT != NILP) {
      /* fprintf(stderr,"[dodecl] left\n"); */
      dodecl(LEFT);
    }
    if (RIGHT != NILP) {
      /* fprintf(stderr,"[dodecl] right\n"); */
      dodecl(RIGHT);
    }
    if ( use_axis_node(node->nodetype) && (AXIS != NILP) ){
      /* fprintf(stderr,"[dodecl] axis\n"); */
      dodecl(AXIS);
    }
    break;
  case IDENT:
    /* fprintf(stderr,"[dodecl] ident\n"); */
    s = getsinfo(node->a.namep);
    if (s) {
      /* adjust type */
      if ( (s->type != APLC_UKTYPE) && (s->type != APLC_ANY) ) {
#if IDEBUG
	fprintf(stderr,"declaring the type for %s as %s(%d)\n",
		node->a.namep, str_type_name(s->type),s->type);
#endif
	node->type.n = s->type;
	node->info |= TYPEDECL;
      }
      /* adjust rank */
      if ( (s->vrank != ANYRANK) && (s->vrank != NORANK) ) {
#if IDEBUG
	fprintf(stderr,"declaring the rank for %s to ",
		node->a.namep); prrank(stderr,s->vrank); 
		fprintf(stderr,"\n");
#endif
	node->rank.n = s->vrank;
	node->info |= RANKDECL;
      }      
    }
    break;
  }
}

/* end of intra.c */
