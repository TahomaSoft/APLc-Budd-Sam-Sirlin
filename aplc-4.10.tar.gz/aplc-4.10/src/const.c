/*
	apl compiler
		constant management 
			timothy a. budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

#include "parse.h"

int giconsts[MAXCONSTS];        /* global integer program constants */
int liconsts[MAXCONSTS];        /* local integer program constants */
int *iconsts;

double grconsts[MAXCONSTS];     /* global real program constants */
double lrconsts[MAXCONSTS];     /* local real program constants */
double *rconsts;

double gzconsts[2][MAXCONSTS];     /* global complex program constants */
double lzconsts[2][MAXCONSTS];     /* local complex program constants */
double *zconsts[2];

double gqconsts[4][MAXCONSTS];     /* global quaternion program constants */
double lqconsts[4][MAXCONSTS];     /* local quaternion program constants */
double *qconsts[4];

double goconsts[8][MAXCONSTS];     /* global octonion program constants */
double loconsts[8][MAXCONSTS];     /* local octonion program constants */
double *oconsts[8];

char gsconsts[MAXCONSTS];       /* global string program constants */
char lsconsts[MAXCONSTS];       /* local string program constants */
char *sconsts;

/* label constants */
struct label_struct lconsts[MAXCONSTS];

int ictop, gictop;              /* integer constant top */
int rctop, grctop;              /* real constant top */
int zctop, gzctop;              /* complex constant top */
int qctop, gqctop;              /* quaternion constant top */
int octop, goctop;              /* octonion constant top */
int sctop, gsctop;              /* string constant top */
int lctop, glctop;              /* label constant top */

/* for debugging */
#define DEBC 0

void 
setlocalcons(void) 
{
  int i;

  /* save global information gathered so far, and set local
     pointers up */
  gictop = ictop;
  ictop = 0;
  iconsts = liconsts;

  grctop = rctop;
  rctop = 0;
  rconsts = lrconsts;

  gzctop = zctop;
  zctop = 0;
  zconsts[0] = lzconsts[0];
  zconsts[1] = lzconsts[1];

  gqctop = qctop;
  qctop = 0;
  for (i=0; i<4; i++)
    qconsts[i] = lqconsts[i];

  goctop = octop;
  octop = 0;
  for (i=0; i<8; i++)
    oconsts[i] = loconsts[i];

  gsctop = sctop;
  lctop = 0;
  sconsts = lsconsts;
  sconsts[0] = '\0';
}

void 
resetconsts(void) 
{
  int i;

  /* reset global information in place */
  ictop = gictop;
  iconsts = giconsts;

  rctop = grctop;
  rconsts = grconsts;

  zctop = gzctop;
  zconsts[0] = gzconsts[0];
  zconsts[1] = gzconsts[1];

  qctop = gqctop;
  for (i=0; i<4; i++)
    qconsts[i] = gqconsts[i];

  octop = goctop;
  for (i=0; i<8; i++)
    oconsts[i] = goconsts[i];

  sctop = gsctop;
  sconsts = gsconsts;

  lctop = 0;
}

/* ------------------------------ */
/* add a constant to the constant array */
int 
addicon(int x)
{
  iconsts[ictop++] = x;
  if (ictop > MAXCONSTS)
    error("too many integer constants");
#if 0
  fprintf(stderr,"[addicon] ictop %d\n", ictop);
#endif  
  return(ictop - 1);
}

/* ------------------------------ */
/* add a double constant to the constant array */
int 
addrcon(double x)
{
  rconsts[rctop++] = x;
  if (rctop > MAXCONSTS)
    error("too many real constants");
  return(rctop-1);
}

/* ------------------------------ */
/* add a complex constant to the constant array */
int 
addzcon(double x[2])
{
  zconsts[0][zctop] = x[0];
  zconsts[1][zctop++] = x[1];
  if (zctop > MAXCONSTS)
    error("too many complex constants");
  return(zctop-1);
}

/* (sws)
   add a real constant to the complex constant array */
int 
addr2zcon(double x)
{
  zconsts[0][zctop] = x;
  zconsts[1][zctop++] = 0.0;
  if (zctop > MAXCONSTS)
    error("too many complex constants");
  return(zctop-1);
}

/* ------------------------------ */
/* (sws)
   add a quaternion constant to the constant array */
int 
addqcon(double x[4])
{
  int i;
  
  for (i=0; i<4; i++)
    qconsts[i][qctop] = x[i];
  qctop++;
  if (qctop > MAXCONSTS)
    error("too many quaternion constants");
  return(qctop-1);
}

/* (sws)
   add a complex constant to the quat array */
int 
addz2qcon(double z[2])
{
  qconsts[0][qctop] = z[0];
  qconsts[1][qctop] = z[1];
  qconsts[2][qctop] = 0.0;
  qconsts[3][qctop] = 0.0;
  qctop++;
  if (qctop > MAXCONSTS)
    error("too many quat constants");
  return(qctop-1);
}

/* (sws)
   add a real constant to the complex constant array */
int 
addr2qcon(double x)
{
  qconsts[0][qctop] = x;
  qconsts[1][qctop] = 0.0;
  qconsts[2][qctop] = 0.0;
  qconsts[3][qctop] = 0.0;
  qctop++;
  if (qctop > MAXCONSTS)
    error("too many quat constants");
  return(qctop-1);
}

/* ------------------------------ */
/* (sws)
   add an octonion constant to the constant array */
int 
addocon(double x[8])
{
  int i;
  
  for (i=0; i<8; i++)
    oconsts[i][octop] = x[i];
  octop++;
  if (octop > MAXCONSTS)
    error("too many octonion constants");
  return(octop-1);
}

/* (sws)
   add a quat constant to the oct array */
int 
addq2ocon(double q[4])
{
  int i;

  oconsts[0][octop] = q[0];
  oconsts[1][octop] = q[1];
  oconsts[2][octop] = q[2];
  oconsts[3][octop] = q[3];
  for (i=4; i<8; i++)
    oconsts[i][octop] = 0.0;
  octop++;
  if (octop > MAXCONSTS)
    error("too many oct constants");
  return(octop-1);
}

/* (sws)
   add a complex constant to the oct array */
int 
addz2ocon(double z[2])
{
  int i;

  oconsts[0][octop] = z[0];
  oconsts[1][octop] = z[1];
  for (i=2; i<8; i++)
    oconsts[i][octop] = 0.0;
  octop++;
  if (octop > MAXCONSTS)
    error("too many oct constants");
  return(octop-1);
}

/* (sws)
   add a real constant to the oct array */
int 
addr2ocon(double r)
{
  int i;

  oconsts[0][octop] = r;
  for (i=1; i<8; i++)
    oconsts[i][octop] = 0.0;
  octop++;
  if (octop > MAXCONSTS)
    error("too many oct constants");
  return(octop-1);
}


/* ------------------------------ */
/* addlcon - add a label constant to the constant array 
   sws: should probably check for duplicates

*/
int 
addlcon(char *x)
{
#if DEBC
  fprintf(stderr,"[addlcon] %d {%s}\n", lctop+1, x);
#endif
  lconsts[lctop++].label_name = x;
  if (lctop > MAXCONSTS)
    error("too many label constants");
  return(lctop - 1);
}

/* promote an integer vector to a double vector, and 
   add a double  
*/
void 
expanivec(struct node *ivec, double r)
{
  int i, top;
  double x;

  i = ivec->values.n;
  top = ictop;
  ictop = i;
  ivec->values.n = rctop;
  for (; i < top; i++) {
    x = iconsts[i];
    addrcon(x);
  }
  addrcon(r);
}

/* promote an integer vector to a double vector */
struct node *
ivec2rvec(struct node *ivec)
{
  int i, top;

  i = ivec->values.n;
  top = ictop;
  ictop = i;
  ivec->values.n = rctop;
  for (; i < top; i++) {
    addrcon((double) iconsts[i]);
  }
  return ivec;
}

/* (sws) 
   - promote a real vector to a complex vector */
struct node *
rvec2zvec(struct node *rvec)
{
  int i, top;

  i = rvec->values.n;
  top = rctop;
  rctop = i;
  rvec->values.n = zctop;
  for (; i < top; i++) {
    addr2zcon(rconsts[i]);
  }
  return rvec;
}

/* (sws) 
   - promote a complex vector to a quaternion */
struct node *
zvec2qvec(struct node *zvec)
{
  int i, top;
  double z[2];

  i = zvec->values.n;
  top = zctop;
  zctop = i;
  zvec->values.n = qctop;
  for (; i < top; i++) {
    z[0] = zconsts[0][i];
    z[1] = zconsts[1][i];
    addz2qcon(z);
  }
  return zvec;
}

/* (sws) 
   - promote a quaternion vector to an octonion */
struct node *
qvec2ovec(struct node *qvec)
{
  int i, top;
  double q[4];

  i = qvec->values.n;
  top = qctop;
  qctop = i;
  qvec->values.n = octop;
  for (; i < top; i++) {
    q[0] = qconsts[0][i];
    q[1] = qconsts[1][i];
    q[2] = qconsts[2][i];
    q[3] = qconsts[3][i];
    addq2ocon(q);
  }
  return qvec;
}


/* (sws) 
   - promote a real vector to a complex vector, and 
   - add a number  */
void 
expanrvec(struct node *rvec, double z[2])
{
  rvec2zvec(rvec);
  addzcon(z);
}


/* end of const.c */
