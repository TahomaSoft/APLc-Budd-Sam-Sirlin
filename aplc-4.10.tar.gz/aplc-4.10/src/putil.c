/*
	APL Compiler

	print utilities
	Samuel W.  Sirlin (sws)

	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

#include "parse.h"
#include "y_tab.h"
/* #include "gen.h"*/
#include <stdio.h>


/* 

   to get through the list, we need to know which node types might use
   axis for another node

   we can't just test for a null pointer, as the axis space is a union... 
 
   */
extern int 
use_axis_node( int type )
{
  switch(type) {
  default:
    return 0;
    break;

  case COMPRESS:
  case EXPAND:
  case ROTATE:
  case CAT:
  case LAM:
  case REVERSE:
  case REDUCE:
  case SCAN:
  case SM:
    /* sm axis seems to be just ident */
  case SUBASSIGN:
    return 1;
    break;
  }
}

/* classes defined in psym.h */
extern char *
str_class(enum classes xx)
{
  switch(xx) {
  default:
  case NOCLASS:
    return "NOCLASS";
    break;
  case GLOBAL:
    return "GLOBAL";
    break;
  case PARAM:
    return "PARAM";
    break;
  case LOCAL:
    return "LOCAL";
    break;
  case FUNCTION:
    return "FUNCTION";
    break;
  case LABCLASS:
    return "LABCLASS";
    break;
  }
}


/* sws  error printing 1/91 */
void
prstatenode(struct statenode * code)
{
  fprintf(stderr, "  contents of statenode\n");
  fprintf(stderr, "   label= %s\n", code->label);
  fprintf(stderr, "    node.nodetype= %d\n", code->code->nodetype);
  fprintf(stderr, "    node.info= %d\n", code->code->info);
  fprintf(stderr, "   nextstate d= %d\n", (int) code->nextstate);
/*  (void) fprintf(stderr, "   nextstate= %s\n", (char) code->nextstate);*/
  fprintf(stderr, "   list= %s\n", code->list->name);
}

/* sws  error printing 5/91 */
void
prtcode(struct statenode * code)
{
  struct statenode *p;

  for (p = code; p != NILSTATE; p = p->nextstate) {
    fprintf(stderr, "statement\n");
    prstatenode(p);
  }
  fprintf(stderr, "end statement\n");
}


/* sws  string representation of rank */
extern char *
str_rank(int rank)
{
  char *str;
  static char tmp[20];

  if (rank == NORANK)
    str = "unknown";
  else if (rank == ANYRANK)
    str = "arbitrary";
  else {
    sprintf(tmp, "%d", rank);
    str = tmp;
  }
  return(str);
}

/* type strings 
   - must match type list in aplc.h */
/*
static char *types[7] = {
    "unknown type", "bit", "int", "real", "char", "any", "label"};
*/
/* sws  new version */
static char *types[] = { "unknown type", 
			 "bit", "bool", "int",
			 "real", "complex", "quaternion", "octave",
			 "char", "any", "nest",
			 "label"};


/* sws  string representation of type */
extern char *
str_type_name(int type)
{
  return(types[type]);
}

/* sws
get a string representation of a parser token type
*/
extern char *
prtoken(int type)
{
  char *token;
  char tmp[50];

  switch (type) {

  default:
    /*
    if ( (type>31)&&(type<128) ) {
      sprintf(tmp,"[prtoken] unknown type %c", (char)type);
    } else {
      */
    sprintf(tmp,"[prtoken] unknown type %d",type);
    token = tmp;
    break;

  case CLASS:
    token = "{CLASS}";
    break;
  case TYPE:
    token = "{TYPE}";
    break;
  case RANK:
    token = "{RANK}";
    break;
  case DEL:
    token = "{DEL}";
    break;
  case GO:
    token = "{GO}";
    break;
  case COMMENT:
    token = "{COMMENT}";
    break;
  case COLLECT:
    token = "{COLLECT}";
    break;
  case CVEC:
    token = "{CVEC}";
    break;
  case CIVEC:
    token = "{CIVEC}";
    break;
  case CSCALAR:
    token = "{CSCALAR}";
    break;
  case CISCALAR:
    token = "{CISCALAR}";
    break;
  case CCOLLECT:
    token = "{CCOLLECT}";
    break;
  case ASSIGN:
    token = "{ASSIGN}";
    break;
  case BOXASSIGN:
    token = "{BOXASSIGN}";
    break;
  case SUBASSIGN:
    token = "{SUBASSIGN}";
    break;
  case BOX:
    token = "{BOX}";
    break;
  case DBOX:
    token = "{DBOX}";
    break;
  case QQUAD:
    token = "{QQUAD}";
    break;
  case DQQUAD:
    token = "{DQQUAD}";
    break;
  case DBOXAS:
    token = "{DBOXAS}";
    break;
  case QBOXAS:
    token = "{QBOXAS}";
    break;
  case DQBOXAS:
    token = "{DQBOXAS}";
    break;
  case IDENT:
    token = "{IDENT}";
    break;
  case FIDENT:
    token = "{FIDENT}";
    break;
  case UIDENT:
    token = "{UIDENT}";
    break;
  case LCON:
    token = "{LCON}";
    break;
  case SCON:
    token = "{SCON}";
    break;
  case BCON:
    token = "{BCON}";
    break;
  case ICON:
    token = "{ICON}";
    break;
  case RCON:
    token = "{RCON}";
    break;
  case ZCON:
    token = "{ZCON}";
    break;
  case QCON:
    token = "{QCON}";
    break;
  case OCON:
    token = "{OCON}";
    break;
  case NL:
    token = "{NL}";
    break;
  case LP:
    token = "{LP}";
    break;
  case RP:
    token = "{RP}";
    break;
  case LB:
    token = "{LB}";
    break;
  case RB:
    token = "{RB}";
    break;
  case CM:
    token = "{CM}";
    break;
  case SM:
    token = "{SM}";
    break;
  case COLON:
    token = "{COLON}";
    break;
  case DOT:
    token = "{DOT}";
    break;
  case MSOP:
    token = "{MSOP}";
    break;
  case DSOP:
    token = "{DSOP}";
    break;
  case OUTER:
    token = "{OUTER}";
    break;
  case INNER:
    token = "{INNER}";
    break;
  case INNERCHILD:
    token = "{INNERCHILD}";
    break;
  case DECODE:
    token = "{DECODE}";
    break;
  case SLASH:
    token = "{SLASH}";
    break;
  case BSLASH:
    token = "{BSLASH}";
    break;
  case REDUCE:
    token = "{REDUCE}";
    break;
  case EXPAND:
    token = "{EXPAND}";
    break;
  case COMPRESS:
    token = "{COMPRESS}";
    break;
  case SCAN:
    token = "{SCAN}";
    break;
  case SORT:
    token = "{SORT}";
    break;
  case GRADEUP:
    token = "{GRADEUP}";
    break;
  case GRADEDOWN:
    token = "{GRADEDOWN}";
    break;
  case EPSILON:
    token = "{EPSILON}";
    break;
  case INDEX:
    token = "{INDEX}";
    break;
  case TRANS:
    token = "{TRANS}";
    break;
  case DTRANS:
    token = "{DTRANS}";
    break;
  case REVERSE:
    token = "{REVERSE}";
    break;
  case ROTATE:
    token = "{ROTATE}";
    break;
  case TAKE:
    token = "{TAKE}";
    break;
  case DROP:
    token = "{DROP}";
    break;
  case GWTAKE:
    token = "{GWTAKE}";
    break;
  case GWDROP:
    token = "{GWDROP}";
    break;
  case RHO:
    token = "{RHO}";
    break;
  case RHORHO:
    token = "{RHORHO}";
    break;
  case RESHAPE:
    token = "{RESHAPE}";
    break;
  case SUB:
    token = "{SUB}";
    break;
  case EMPTSEMI:
    token = "{EMPTSEMI}";
    break;
  case IOTA:
    token = "{IOTA}";
    break;
  case RAVEL:
    token = "{RAVEL}";
    break;
  case CAT:
    token = "{CAT}";
    break;
  case CATCH:
    token = "{CATCH}";
    break;
  case LAM:
    token = "{LAM}";
    break;
  case ROLL:
    token = "{ROLL}";
    break;
  case DEAL:
    token = "{DEAL}";
    break;
  case ENCODE:
    token = "{ENCODE}";
    break;
  case FORMAT:
    token = "{FORMAT}";
    break;
  case DFORMAT:
    token = "{DFORMAT}";
    break;
  case EXECUTE:
    token = "{EXECUTE}";
    break;
  case MSOLVE:
    token = "{MSOLVE}";
    break;
  case DOMINO:
    token = "{DOMINO}";
    break;
  case AVEC:
    token = "{AVEC}";
    break;
  case TCAV:
    token = "{TCAV}";
    break;
  case ASYSVAR:
    token = "{ASYSVAR}";
    break;
  case SYSVAR:
    token = "{SYSVAR}";
    break;
  case DSYSFUN:
    token = "{DSYSFUN}";
    break;
  case ESYSFUN:
    token = "{ESYSFUN}";
    break;
  case MSYSFUN:
    token = "{MSYSFUN}";
    break;
  case ALPHA:
    token = "{ALPHA}";
    break;
  case OMEGA:
    token = "{OMEGA}";
    break;
  case CGOTO:
    token = "{CGOTO}";
    break;
  }
  return (token);
}

/* end of putil.c */
