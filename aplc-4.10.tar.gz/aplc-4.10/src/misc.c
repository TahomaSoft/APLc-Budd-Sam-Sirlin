/*
	APL Compiler

	Code Generation routines for misc. functions
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/
#include "parse.h"
#include "y_tab.h"
#include "gen.h"
#include <stdio.h>

/* local declarations */
static struct codetree *subgen(struct node *, int);

/*
	geniota - generate code for monadic iota operator

	ptr1 - mp for shape
	ptr2 - value if sequential
	ptr3 - nu

	sws - the right must be an integer scalar, so why allocate
	space for it - just wastes time

*/
void
geniota(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    if (!(node->info & SHAPEKNOWN)) {
      switchbox(RIGHT, SHAPE, 0);
      if ((RIGHT->info & HAVEVALUE) &&
	  ((RIGHT->values.c)->cop == deref)) {
	/* in this case we may as well just use the value at right */
	/* strip off deref */
	node->shape.c = (RIGHT->values.c)->c0.cleft;
      } else {
	/* here we might have calculations, so it's worth it to
	collect the right in case we need to re use it */
	/* sws use a res struct */
	printf("res%d.i = ", node->ptr1);
	ctgen(RIGHT->values.c);
	seminl();
	node->shape.c = gmon(ref, gicn(resptr, node->ptr1, APLC_INT));
      } 
    } if (node->info & SEQUENTIAL) 
      ieqtree(node->ptr2, gixorg());
    break;

  case COMBINE:
    break;

  case VALUE:
    if (node->info & SEQUENTIAL)
      node->values.c = gmon(postinc, gicn(iptr, node->ptr2, 0));
    else
      node->values.c = gsop(APLC_PLUS, gicn(iptr, node->index, 0), gixorg());
    break;

  case FINISH:
    if (!(node->info & SHAPEKNOWN)) {
      switchbox(RIGHT, FINISH, 0);
    }
    break;
  }
}

/* save old version ... */
#if 0
void
geniota(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    if (!(node->info & SHAPEKNOWN)) {
      switchbox(RIGHT, SHAPE, 0);
      if ((RIGHT->info & HAVEVALUE) &&
	  ((RIGHT->values.c)->cop == deref)) {
	node->ptr3 = 0;
	/* strip off deref */
	node->shape.c = (RIGHT->values.c)->c0.cleft;
      } else {
	node->ptr3 = 1;
	smpalloc(node->ptr1);
	smpieqt(node->ptr1, RIGHT->values.c);
	node->shape.c = gicn(memptr, node->ptr1, APLC_INT);
      }
    }
    if (node->info & SEQUENTIAL)
      ieqtree(node->ptr2, gixorg());
    break;

  case COMBINE:
    break;

  case VALUE:
    if (node->info & SEQUENTIAL)
      node->values.c = gmon(postinc, gicn(iptr, node->ptr2, 0));
    else
      node->values.c = gsop(APLC_PLUS, gicn(iptr, node->index, 0), gixorg());
    break;

  case FINISH:
    if (!(node->info & SHAPEKNOWN)) {
      switchbox(RIGHT, FINISH, 0);
      if (node->ptr3) {
#ifdef DEBUGFREE
	printf("/* -- iota finish */\n");
#endif
	mpfree(node->ptr1);
#ifdef DEBUGFREE
	printf("/* -- */\n");
#endif
      }
    }
    break;
  }
}
#endif /* old version */

/*
	genravel - generate code for ravel instruction

	ptr1 - memory pointer for shape
	ptr2 - integer value for getsize

*/
void
genravel(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    if (!(node->info & TYPEKNOWN))
      node->type.c = RIGHT->type.c;
    if (!(node->info & SHAPEKNOWN)) {
      smpalloc(node->ptr1);
      getsize(node->ptr2, RIGHT);
      setmptoi(node->ptr1, node->ptr2);
      node->shape.c = gicn(memptr, node->ptr1,
	  APLC_INT);
    }
    if (RIGHT->info & HAVEVALUE)
      node->values.c = RIGHT->values.c;
    break;

  case COMBINE:
    break;

  case VALUE:
    switchbox(RIGHT, VALUE, 0);
    node->values.c = RIGHT->values.c;
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    if (!(node->info & SHAPEKNOWN)) {
#ifdef DEBUGFREE
      printf("/* -- ravel finish */\n");
#endif
      mpfree(node->ptr1);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
  }
}

/*
	genroll - generate code for random operation

	ptr1 - result register for left hand side
	ptr2 - i value

*/
void
genroll(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    copychild(node, RIGHT, 0, 1, 1);
    break;

  case COMBINE:
    break;

  case VALUE:
    switchbox(RIGHT, VALUE, 0);
    node->ptr1 = resinreg(RIGHT, node->ptr1);
    ieq(node->ptr2);
    printf("aplc_randint(res%d.i);\n", node->ptr1);
    node->values.c = gicn(iptr, node->ptr2, APLC_INT);
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    break;
  }
}

/*
	gendeal -
		generate code for deal operation

	ptr1 - mp for shape
	ptr2 - mp for values of deal
	ptr3 - register for results

*/
void
gendeal(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    switchbox(RIGHT, SHAPE, 0);
    if (!(node->info & SHAPEKNOWN)) {
      smpalloc(node->ptr1);
      smpieqt(node->ptr1, LEFT->values.c);
      node->shape.c = gicn(memptr, node->ptr1, APLC_INT);
    }
    /* allocate the space */
    printf("aplc_vectalloc(&mp%d, ", node->ptr2);
    ctgen(LEFT->values.c);
    printf(", APLC_INT);\n");
    /* now generate the values */
    printf("aplc_deal(&mp%d, ", node->ptr2);
    ctgen(LEFT->values.c);
    commasp();
    ctgen(RIGHT->values.c);
    rpseminl();
    node->values.c = gicn(memptr, node->ptr2, APLC_INT);
    break;

  case COMBINE:
    break;

  case VALUE:
    leafvalue(node, node->ptr2, APLC_INT, node->ptr3);
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
#ifdef DEBUGFREE
    printf("/* -- deal finish */\n");
#endif
    mpfree(node->ptr1);
    mpfree(node->ptr2);
#ifdef DEBUGFREE
    printf("/* -- */\n");
#endif
    break;
  }
}

/*
	gensub - generate code for subscripting operations

        LEFT[ RIGHT ]

*/
void
gensub(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    switchbox(LEFT, SHAPE, 0);
    RIGHT->a.axis = LEFT;
    switchbox(RIGHT, SHAPE, 1);
    copychild(node, LEFT, 1, 0, 0);
    copychild(node, RIGHT, 0, 1, 1);
    break;

  case COMBINE:
    break;

  case VALUE:
    switchbox(RIGHT, VALUE, 1);
    ieqtree(LEFT->index, RIGHT->values.c);
    switchbox(LEFT, VALUE, 0);
    node->values.c = LEFT->values.c;
    break;

  case FINISH:
    switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    break;
  }
}

/*
  subgen 
  - generate the shape of the current position
*/
static struct codetree *
subgen(struct node * parent, int position)
{
  return(gmon(deref, gsop(APLC_PLUS, parent->shape.c,
			   gicn(icnst, position, APLC_INT))));
}

/*
  gensemi - generate code for semicolon
            (this should be optimized a little more)

 ptr1 - position (set by parser)
 ptr2 - size of right hand side
 ptr3 - index of top (set by sub)
 ptr4 - rank
 ptr5 - shape
 ptr6 - result of children

*/
void
gensemi(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    if (LEFT != NILP) {
      LEFT->a.axis = node->a.axis;
      switchbox(LEFT, SHAPE, 0);
    }
    if (RIGHT->nodetype == EMPTSEMI)
      RIGHT->a.axis = node->a.axis;
    switchbox(RIGHT, SHAPE, 0);
    if (LEFT == NILP)
      copychild(node, RIGHT, 0, 1, 1);
    else if (!(node->info & SHAPEKNOWN)) {
      rkeq(node, node->ptr4);
      printf("aplc_outershape(&mp%d, ", node->ptr5);
      lrnsrrns(LEFT, RIGHT);
      rpseminl();
      node->shape.c = gicn(memptr, node->ptr5, APLC_INT);
    }
    if (LEFT != NILP)
      getsize(node->ptr2, RIGHT);
    break;

  case COMBINE:
    break;

  case VALUE:
    if (LEFT == NILP) {
      switchbox(RIGHT, VALUE, 0);
      mkrktype(RIGHT, APLC_INT, node->ptr6);
      if (RIGHT->nodetype == EMPTSEMI)
	node->values.c = RIGHT->values.c;
      else
	node->values.c = gsop(APLC_MINUS, RIGHT->values.c, gixorg());
    } else {
      if (!(RIGHT->info & NOINDEX))
	iopi(RIGHT->index, node->index, "%", node->ptr2);
      switchbox(RIGHT, VALUE, 0);
      mkrktype(RIGHT, APLC_INT, node->ptr6);
      if (!(LEFT->info & NOINDEX))
	iopi(LEFT->index, node->index, "/", node->ptr2);
      switchbox(LEFT, VALUE, 0);
      node->values.c = gsop(APLC_PLUS,
			    gsop(APLC_TIMES, LEFT->values.c,
				 subgen(node->a.axis, node->ptr1)),
			    RIGHT->values.c);
      if (RIGHT->nodetype == EMPTSEMI)
	;
      else
	node->values.c = gsop(APLC_MINUS, node->values.c,
			      gixorg());
    }
    break;

  case FINISH:
    if (LEFT != NILP)
      switchbox(LEFT, FINISH, 0);
    switchbox(RIGHT, FINISH, 0);
    if (! ((LEFT == NILP) || (node->info & SHAPEKNOWN)) ) {
#ifdef DEBUGFREE
      printf("/* -- semi finish */\n");
#endif
      if (!(node->info & RANKKNOWN))
        mpfree_nots(node->ptr5, node->ptr4);
      else {
        /* rank is known, can test now */
	if (node->rank.c->c0.cindex)
	  mpfree(node->ptr5);
      }
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
  }
}

/*
	genempt - generate code for the empty semicolon position

	ptr4 - shape
*/
void
genempt(struct node * node, enum pmodes mode, int top)
{
  switch (mode) {
    case SHAPE:
    adjdcls(node);
    if (!(node->info & SHAPEKNOWN)) {
      smpalloc(node->ptr4);
      smpieqt(node->ptr4,
	  subgen(node->a.axis, node->ptr1));
      node->shape.c = gicn(memptr, node->ptr4, APLC_INT);
    }
    break;

  case COMBINE:
    break;

  case VALUE:
    node->values.c = gicn(iptr, node->index, APLC_INT);
    break;

  case FINISH:
    if (!(node->info & SHAPEKNOWN)) {
#ifdef DEBUGFREE
      printf("/* -- empty finish */\n");
#endif
      mpfree(node->ptr4);
#ifdef DEBUGFREE
      printf("/* -- */\n");
#endif
    }
    break;
  }
}

/*
	gengo -
		generate code for unconditional goto

	ptr1 - size of right side
	ptr2 = result value
*/
void
gengo(struct node * node, enum pmodes mode, int top)
{
  struct codetree *savetree;

  switch (mode) {
  case SHAPE:
    adjdcls(node);
    switchbox(RIGHT, SHAPE, 0);
    getsize(node->ptr1, RIGHT);
    printf("stmtno++;\n");	     /* jbww UKC 6/87 */
    printf("if (i%d > 0) {\n", node->ptr1);
    savetree = looprank;
    looprank = RIGHT->rank.c;
    if (!(RIGHT->info & NOINDEX))
      seticon(RIGHT->index, 0);
    switchbox(RIGHT, VALUE, 0);
    mkrktype(RIGHT, APLC_INT, node->ptr2);
    printf("stmtno = ");
    ctgen(RIGHT->values.c);
    seminl();
    /* printf("break;\n");            jbww UKC 6/87 */
    rbr();
    looprank = savetree;
    break;

  case COMBINE:
    break;

  case VALUE:
    break;

  case FINISH:
    switchbox(RIGHT, FINISH, 0);
    printf("break;\n");		     /* jbww UKC 6/87 */
    break;
  }
}

/* end of misc.c */
