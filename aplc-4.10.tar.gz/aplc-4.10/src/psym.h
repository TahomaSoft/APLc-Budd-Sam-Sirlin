/*  psym.h 

1/15/97 sws add some global prototypes

*/

#ifndef _PSYM
#define _PSYM

/* identifier class types */
enum classes {NOCLASS, GLOBAL, PARAM, LOCAL, FUNCTION, LABCLASS};

extern void reinitsymtab(void);
extern enum classes idclass(char *name, struct symnode ** symptr);
extern struct symnode * 
  enterid(char *name, enum classes class, int type, int rank);

#endif
/* end of psym.h */
