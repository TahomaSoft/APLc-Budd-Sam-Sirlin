/*
	APL Compiler -
		Run Time System
		I/O routines
		tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/

/* ------------------------------------------------------------ */

#include "aplc.h"
#include "run.h"

/* ------------------------------------------------------------ */

/* sws  for file io */
#include <stdio.h>
#include <stdlib.h>

#if HAVE_STRING_H
/* sws  for trs2str */
#include <string.h>
#endif

#include <sys/types.h>

#if HAVE_FCNTL_H
/* sws for open */
#include <fcntl.h>
#endif


#if TIME_WITH_SYS_TIME 
#include <sys/time.h>
#include <time.h>
#else
#if HAVE_SYS_TIME_H
#include <sys/time.h>
#else
#include <time.h>
#endif 
#endif


#if HAVE_SYS_STAT_H 
/* sws  to get file sizes */
#include <sys/stat.h>
#endif

#if HAVE_UNISTD_H
/* jbww to get dup, pipe, fork; sws to get usleep for fbsd */
#include <unistd.h>
#endif


#if HAVE_SYS_WAIT_H 
/* jbww to get wait */
#include <sys/wait.h>
#endif

#if HAVE_TERMIOS_H 
/* jbww to get file control */
#include <termios.h>
#endif

/* for error traping */
#include <setjmp.h>

/* ------------------------------------------------------------ */
/* external functions */

/* not needed by freebsd, ... */ 
/*
extern int _flsbuf(unsigned int, FILE *);
extern int system(const char *);
extern double atof(const char *);
extern int atoi(const char *);
*/

#ifdef DJPC
extern void srand(int);
#endif

#ifdef SUNOS
extern int rand(void);
extern int fgetc(FILE *);
extern int ungetc(int, FILE *);

#ifdef SUNOS4
extern unsigned long time(time_t *);
#endif
#ifdef SUNOS5
/* solaris */
extern time_t time(time_t *);
#endif

/* in gcc stdlib */
/* extern void srand(unsigned int); */
#endif /* SUNOS */

/* ------------------------------------------------------------ */

/* switch for printing debug information */ 
#define DEBUGIO 0

#define DEBUGFI 0

/* ------------------------------------------------------------ */
/* global variables */
/* current statement number */
/* int stmtno;*/
#ifndef LINUX
/* where output is sent */
FILE *aplcout = stdout;
/* where errors are printed */
FILE *aplcerr = stderr;
#else
/* glibc 2 doesn't allow the above, as stderr, stdout are not
   constants */
/* where output is sent */
FILE *aplcout;
static void aplcout_construct (void) __attribute__((constructor));
static void aplcout_construct (void) { aplcout = stdout; }
/* where errors are printed */
FILE *aplcerr;
static void aplcerr_construct (void) __attribute__((constructor));
static void aplcerr_construct (void) { aplcerr = stderr; }
#endif


jmp_buf aplc_env;
static int trap_set = 0;

/* ------------------------------------------------------------ */
/* local variables */

/* printing precision width:  .bxpp */
static int _intwidth = 7;
/* add this to _intwidth to get the field width for reals 
-.e+000 with 1 space
*/
#define REALWIDTHX 8

/* sum of the above + margin */
#define REALWIDTHM 40
/* some char vectors */
static char ci[REALWIDTHM];
static char czt[8*REALWIDTHM];
static char cq[8][REALWIDTHM];

static char blanks[]=" ";


/* arbitrary limit of 11 pipes per spawn */
/* (we can only use half the file desciptors */
/* used by .bxspawn in runio.c */
/* if this is upped, SelCvec in .bxspawn in runio.c must be lengthened  */
#define MAXPIPES 11



/* input args */
static int aplcargc;
static char **aplcargv; 
static struct trs_struct arg;
/* command line arguments */
static char arg_avail = 0;

/* output mapping */
int _omapv[2] = {0, 0};


/* ------------------------------------------------------------ */
/* local function declarations */

static int get_typen(int type);

/*static int sprint_ns(char *c, double r);*/
static int sprint_ns(char *c, int w, int p, double r);

static void sprintf_double(char *c, char *fmc, int width, int prec, double r);

static int sprintf_double_count(char *c, char *fmc, int width, 
				int prec, double r);
static int sprintf_complex(char *text, char *fmc, int width, int prec, 
			   double *z[2], int i);
static int sprintf_quat(char *text, char *fmc, int width, int prec, 
			double *q[4], int i);
static int sprintf_oct(char *text, char *fmc, int width, int prec, 
		       double *o[8], int i);

static void format_int(char *text, int w, int x);
static void format_real(char *text, int w, int p, double *x);
static void format_complex(char *text,int wa[2], 
			  int wt, int w[2], int p, double *z[2], int i);
static void format_quat(char *text,int wa[2], 
			int wt, int w[4], int p, double *z[4], int i);
static void format_oct(char *text,int wa[8], 
		       int wt, int w[8], int p, double *z[8], int i);

static int get_act_width(char *c);

static double * dsrval(double val);
static void proint(struct trs_struct * trs, int *val);

/*static void str2trs(struct trs_struct * trs, char * str);*/
/*static int trs2str(char *str, int csize, int *is_zilde, int *did_malloc, 
		   int drop_ws, struct trs_struct *trs);*/


static int testwidth(double x, int width, int prec);


/* ------------------------------------------------------------ */
/* ------------------------------------------------------------ */

/* error - print an error message and exit 

   - seems hard to get stmtno here... must be local to each fn, yet
   this is called from withing lots of runtime fns
   
   */

/* new version */
extern void
aplc_trap(int n)
{
  trap_set = n;
  return;
}

extern void
aplc_error(char *s)
{
  if (trap_set) {
    longjmp(aplc_env, -1);
  }
  /* fprintf(aplcerr, "statement %d: apl run-time error: \n%s\n", n, s);*/
  fprintf(aplcerr, "apl run-time error: \n%s\n", s);
  exit(1);
}

#if 0
extern void
aplc_error(char *s)
{
  /* fprintf(aplcerr, "statement %d: apl run-time error: \n%s\n", n, s);*/
  fprintf(aplcerr, "apl run-time error: \n%s\n", s);
  exit(1);
}
#endif

/* sws
   perror() should print to stderr
   strerror() should return ptr to string */

/* print system error message */
/*	J.B.W.Webber@ukc.ac.uk  99_3_12  */
extern void
aplc_syserr( char * msg) 
{
  /* #if defined(DECALPHA) || defined(SGI) || defined(LINUX)*/
#if 0
  /* how are errno, sys_nerr, sys_errlist defined ? */
  fprintf(aplcerr, "apl system error: %s (%d", msg, errno);
  if ( errno > 0 && errno < sys_nerr)
    fprintf(aplcerr, ": %s)\n", sys_errlist[errno]);
  else
    fprintf(stderr, ")\n");
  exit(1);
#else
  /* no errno? */
  fprintf(aplcerr, "apl system error: %s ", msg);
  exit(1);
#endif
}

/* get the number of components in a given number type */
static int
get_typen(int type)
{
  switch(type) {
  default:
  case APLC_BOOL:
  case APLC_INT:
  case APLC_REAL:
    return 1;
    break;
  case APLC_COMPLEX:
    return 2;
    break;
  case APLC_QUAT:
    return 4;
    break;
  case APLC_OCT:
    return 8;
    break;
  }
  return 1;
}

/* use for left adjustment - not the whole answer... */
#define LAD 0

/* sws
   sprint_ns - special print for numbers

   - maintain precision (_intwidth) by varying total width

   - leave no spaces

   - on some machines (sparc/solaris, intel/linux) 
     0.0 can be signed, prints out as -0; don't allow this 

   - return size
  
   integers  " -nnnnn" (7)

   added fix for the reals, max size assuming " -x.nnnnnE-mmm" (14)
*/

static int
sprint_ns(char *c, int w, int p, double r)
{
  int sg;
  char temp[REALWIDTHM];
  int i,j;

  if (r == 0.0) {
    /* special case */
    j = 1;
    sprintf(c, "%*.0f", j, 0.0); 
    return j;
  }
  if (r < 0)
    sg = 1;
  else
    sg = 0;
  sprintf(temp, "%*.*g", w, p, r);    
  for (i=0,j=0; i<w; i++) {
    if (temp[i] != ' ')
      c[j++] = temp[i];
  }
  c[j] = '\0';
  return j;
}

/* -------------------------------------------- */
/* routines that use format strings */

/* special sprintf, for doubles */
static void
sprintf_double(char *c, char *fmc, int width, int prec, double r)
{
#if LAD
  char fms[] = "%-*.*f";  
#else
  char fms[] = "%*.*f";
#endif

  /* modify format string */
  /*fprintf(stderr,"%s %s\n", fms, fmc);*/
  fms[4] = fmc[0];
  /*fprintf(stderr,"%s %s\n", fms, fmc);*/
  /* check for special case 0, to eliminate -0 */
  if (0.0 == r)
    sprintf(c, fms, width, prec, 0.0);
  else
    sprintf(c, fms, width, prec, r);
  return;
}

/* special sprintf, for doubles 
   left adjusted
   return the actual width of non-blanks needed */
static int
sprintf_double_count(char *c, char *fmc, int width, int prec, double r)
{
#if LAD
  char fms[] = "%-*.*f"; 
#else
  char fms[] = "%*.*f";
#endif
  char temp[REALWIDTHM];
  int i, k;

  /* modify format string */
  /*fprintf(stderr,"%s %s\n", fms, fmc);*/
  fms[4] = fmc[0];
  /*fprintf(stderr,"[[%s] %d.%d[%s], %g]\n", fms,  width,prec,fmc, r);*/
  /* check for special case 0, to eliminate -0 */
  if (0.0 == r)
    sprintf(temp, fms, width, prec, 0.0);
    /*fprintf(stderr,"{%s}", c);*/
  else
    sprintf(temp, fms, width, prec, r);
  for (i=0,k=0; temp[i] != '\0'; i++) {
    if (temp[i] != ' ') {
      c[k] = temp[i];
      k++;
    }
  }
  c[k] = '\0';
  /*fprintf(stderr,"{%d,%s}", k,c);*/
  return k;
}

/* return width needed for the format 
*/
static int
sprintf_complex(char *text, char *fmc, int width, int prec, 
		double *z[2], int i)
{
  int wi[2];
  int wa[2];
  int wc, wta;
  int j,k;

  /* check for special case 0 */
  if (1.0 == 1.0 + z[1][i]) {
    /* purely real */
    wa[0] = sprintf_double_count(cq[0], fmc, width, prec, z[0][i]);
    k = width - wa[0];
    if (k > 0)
      sprintf(text,"%*.0s%s", k,blanks,cq[0]);
    else
      sprintf(text,"%s", cq[0]);
    return wa[0];
  }
  /* really complex case */
  wc = (width-1)/2;
  wta = 1;
  for (j=0; j<2; j++) {
    wi[j] = wc;
    wa[j] = sprintf_double_count(cq[j], fmc, wi[j], prec, z[j][i]);
    wta += wa[j];
  }
  k = width - wta;
  /*fprintf(stderr,"{[%s]%d,[%s]%d,%d", cq[0],wa[0],cq[1],wa[1],k);*/
  if (k > 0)
    sprintf(text,"%*.0s%si%s", k,blanks,cq[0],cq[1]);
  else if (k == 0) {
    sprintf(text,"%si%s", cq[0],cq[1]);
  } else {
    /* error */
    fprintf(aplcerr,"[DFormat] complex, width = %d (need %d), ", 
	    width, wta);
    aplc_error("DFormat domain error, field width too small");
  }
  return wta;
}

/* return width needed for the format 
*/
static int
sprintf_quat(char *text, char *fmc, int width, int prec, 
	     double *z[4], int i)
{
  int wa[4];
  int wc, wta;
  int j,k;
  char units[] = " ijk";
  char *tmp;

  wc = (width-1)/4;
  k = width;
  for (j=0; j<4; j++) {
    if (j == 0) {
      wa[j] = sprintf_double_count(cq[j], fmc, wc, prec, z[j][i]);
      k -= wa[j];
    } else {
      if ( 1.0 == 1.0 + z[j][i] )
	wa[j] = 0;
      else {
	wa[j] = sprintf_double_count(cq[j], fmc, wc, prec, z[j][i]);
	k -= 1+wa[j];
      }
    }
  }
  wta = width - k;
  if (k > 0)
    tmp = text + sprintf(text,"%*.0s%s", k,blanks, cq[0]);
  else
    tmp = text + sprintf(text,"%s", cq[0]);
  for (j=1; j<4; j++) {
    if (wa[j] > 0) 
      tmp += sprintf(tmp,"%c%s", units[j], cq[j]);
  }
  if (k < 0) {
    /* error */
    fprintf(aplcerr,"[DFormat] quat, width = %d (need %d), ", 
	    width, wta);
    aplc_error("DFormat domain error, field width too small");
  }
  return wta;
}


/* return width needed for the format 
*/
static int
sprintf_oct(char *text, char *fmc, int width, int prec, 
	    double *z[8], int i)
{
  int wa[8];
  int wc, wta;
  int j,k;
  char units[] = " ijkUIJK";
  char *tmp;

  wc = (width-1)/8;
  k = width;
  for (j=0; j<8; j++) {
    if (j == 0) {
      wa[j] = sprintf_double_count(cq[j], fmc, wc, prec, z[j][i]);
      k -= wa[j];
    } else {
      if ( 1.0 == 1.0 + z[j][i] )
	wa[j] = 0;
      else {
	wa[j] = sprintf_double_count(cq[j], fmc, wc, prec, z[j][i]);
	k -= 1+wa[j];
      }
    }
  }
  wta = width - k;
  if (k > 0)
    tmp = text + sprintf(text,"%*.0s%s", k,blanks, cq[0]);
  else
    tmp = text + sprintf(text,"%s", cq[0]);
  for (j=1; j<8; j++) {
    if (wa[j] > 0) 
      tmp += sprintf(tmp,"%c%s", units[j], cq[j]);
  }
  if (k < 0) {
    /* error */
    fprintf(aplcerr,"[DFormat] oct, width = %d (need %d), ", 
	    width, wta);
    aplc_error("DFormat domain error, field width too small");
  }
  return wta;
}

/* -------------------------------------------- */
/* printit - print a scalar object */
extern void
aplc_printit(union res_struct * res, int type, int nls)
{
  int realwidth;
  int i, w, nb;

  switch (type) {
  case APLC_CHAR:
    fprintf(aplcout,"%c", res->c);
    break;
  case APLC_BOOL:
  case APLC_INT:
    fprintf(aplcout,"%*d", _intwidth, res->i);
    break;
  case APLC_REAL:
    /* fprintf(aplcout,"%*g", _intwidth, res->r); */
    realwidth = _intwidth + REALWIDTHX;
    if (0.0 == res->r)
      fprintf(aplcout,"%*.0s0",realwidth-1,blanks);/* don't allow -0 */
    /*fprintf(aplcout," 0"); */
    else      
    fprintf(aplcout,"%*.*g", realwidth, _intwidth, res->r);
    break;
  case APLC_COMPLEX:
    /* have to remove all spaces around the i */
    realwidth = _intwidth + REALWIDTHX;
    w = sprint_ns(cq[0], realwidth, _intwidth, res->z[0]);
    w += sprint_ns(cq[1], realwidth, _intwidth, res->z[1]);
    nb = 2*realwidth - 2-w;
    if (nb > 0)
      fprintf(aplcout," %*.0s%si%s", nb,blanks,cq[0],cq[1]);
    else
      fprintf(aplcout," %si%s", cq[0],cq[1]);
    break;
  case APLC_QUAT:
    /* have to remove all spaces around the i */
    realwidth = _intwidth + REALWIDTHX;
    for (i=0, w=0; i<4; i++)
      w +=sprint_ns(cq[i], realwidth, _intwidth, res->q[i]);
    /*fprintf(aplcout," %si%sj%sk%s", cq[0],cq[1],cq[2],cq[3]);*/
    /*fprintf(aplcout," %.*s%si%sj%sk%s", (4*realwidth - 4-w),blanks,
	    cq[0],cq[1],cq[2],cq[3]);*/
    nb = 4*realwidth - 4-w;
    if (nb > 0)
      fprintf(aplcout," %*.0s%si%sj%sk%s", nb,blanks,
	      cq[0],cq[1],cq[2],cq[3]);
    else
      fprintf(aplcout," %si%sj%sk%s", cq[0],cq[1],cq[2],cq[3]);
    break;
  case APLC_OCT:
    /* have to remove all spaces around the i */
    realwidth = _intwidth + REALWIDTHX;
    for (i=0, w=0; i<8; i++)
      w +=sprint_ns(cq[i], realwidth, _intwidth, res->o[i]);
    nb = 8*realwidth - 8 - w;
    if (nb > 0)
      fprintf(aplcout," %*.0s%si%sj%sk%sU%sI%sJ%sK%s", nb,blanks,
	      cq[0],cq[1],cq[2],cq[3],
	      cq[4],cq[5],cq[6],cq[7]);
    else
      fprintf(aplcout," %si%sj%sk%sU%sI%sJ%sK%s", 
	      cq[0],cq[1],cq[2],cq[3],
	      cq[4],cq[5],cq[6],cq[7]);
    break;
  default:
    aplc_error("aplc_printit run-time type error \n");
    break;
  }
  for (; nls > 0; nls--)
    fprintf(aplcout,"\n");
}

/* aplc_bmpnl -
   figure out how many newlines to add,
   after printing a particular index */
extern int
aplc_bmpnl(int iindex, int rank, int *shape)
{
  int temp, i, counter;

  /* sws - added fix for scalar */
  if (rank <= 0)
    return (1);

  i = rank - 1;
  counter = 0;
  temp = 1;
  while (i >= 0) {
    temp *= shape[i];
    if (((iindex + 1) % temp) == 0) {
      counter++;
      i--;
    } else
      break;
  }
  /* sws - end of an array only has one nl */
  if (counter >= rank)
    counter = 1;
  return (counter);
}

/* dynamic scalar value - vector for shape/value.ip  */
extern int *
aplc_dsval(int val)
{
  union mp_struct mptemp;

  aplc_vectalloc(&mptemp, 1, APLC_INT);
  *mptemp.ip = val;
  return(mptemp.ip);
}

/* dynamic scalar value - vector, real   */
static double *
dsrval(double val)
{
  union mp_struct mptemp;

  aplc_vectalloc(&mptemp, 1, APLC_REAL);
  *mptemp.rp = val;
  return(mptemp.rp);
}

/* proint
   setup simple result structure for scalar integers 
   used by some sysvars
   changed to not allocate space
*/
static void
proint(struct trs_struct * trs, int *val)
{
  trs->type = APLC_INT;
  trs->rank = 0;
  trs->shape = aplc_ivone;
  trs->value.ip = val;
}

/* setup a trs for a string */
extern void
aplc_str2trs(struct trs_struct * trs, char * str)
{
  int i, len;

  trs->type = APLC_CHAR;
  trs->rank = 1;
  len = strlen(str);
  trs->shape = aplc_dsval(len);
  aplc_vectalloc(&trs->value, len, APLC_CHAR);
  for (i=0; i<len; i++)
    (trs->value.cp)[i] = *str++;
}

/* copy a string from a character trs, possibly dropping extra
   whitespace at the end

   - this may be convient to use when interfacing to aplc code from 
     C code 

   - assume that we have str[csize] declared outside
   - don't overwrite csize
   - return the string length
 */
extern int
aplc_trs2str(char *str, int csize, struct trs_struct *trs)
{
  int rsize;
  int is_zilde;

  /* check type */
  if ( trs->type != APLC_CHAR )
    return 0;
  /* now get length */
  is_zilde = 0; /* assume right is not zilde */
  if (trs->rank == 0)
    rsize = 1; /* scalar */
  else {
    if ((trs->rank == 1) && (trs->shape[0] == 0)) {
      is_zilde = 1; /* zilde */
      if (csize > 0)
	str[0] = '\0';
      return 0;/* quit here */
    }
    else
      rsize = trs->shape[0]; /* just read as a string */
  }
  /* now do the actual copy, at most csize-1 */
  rsize = min(rsize, csize-1);
  strncpy(str,trs->value.cp, (unsigned int) (rsize));
  str[rsize] = '\0';/* mark the string end */
  return rsize;
}

/* copy a string from a character trs, possibly dropping extra
   whitespace at the end

   - assume that we have str[csize] declared outside
   - if drop_ws == 1, then drop extra whitespace at the end
   - return the string length
   - also return is_zilde == 1 if right is zilde
   - return did_malloc==1 if we needed more space */
extern int
aplc_trs2str_sp(char *str, int csize, int *is_zilde, int *did_malloc, 
	int drop_ws, struct trs_struct *trs)
{
  int rsize;

  /* check type */
  if ( trs->type != APLC_CHAR )
    return 0;
  /* now get length */
  *is_zilde = 0; /* assume right is not zilde */
  *did_malloc = 0;
  if (trs->rank == 0)
    rsize = 1; /* scalar */
  else {
    if ((trs->rank == 1) && (trs->shape[0] == 0)) {
      *is_zilde = 1; /* zilde */
      if (csize > 0)
	str[0] = '\0';
      return 0;/* quit here */
    }
    else
      rsize = trs->shape[0]; /* just read as a string */
  }
  /* now do the actual copy */
  if (rsize < csize)
    strncpy(str,trs->value.cp, (unsigned int) rsize);
  else {
    /* need to make more room */
    str = (char *) malloc(rsize*sizeof(char)); 
    *did_malloc = 1;
    strncpy(str, trs->value.cp, (unsigned int) rsize);
  }
  if (drop_ws) {
    /* delete possible whitespace at the end */
    while ( (rsize>1) && 
	    ((str[rsize-1]==' ') || (str[rsize-1]=='\t')) ) {
      rsize--;
    }
  }
  str[rsize] = '\0';/* mark the string end */
  return rsize;
}

/* aplc_setargs - make arguments available from main 
(sws)
*/
extern void 
aplc_setargs(int argc, char *argv[])
{
  aplcargc = argc;
  aplcargv = argv;
}

/*
 sysvar - code for system variables
          may also be used for system functions, when available

 all use static storage (must not be freed) except:
 sys (which then must be freed) 
                 
*/

/* static storage for system variables */
static int sys_io_value[1]  = {1};
static int sys_pp_value[1]  = {1};
static int sys_rl_value[1]  = {1};

static int sys_omap_shape[1] = {2};
static int sys_omap_value[2] = {0, 0};

static int sys_ts_shape[1] = {7};
static int sys_ts_value[7] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0} ;

#define ISsingleton(x) (x->rank == 0) || \
                       ( (x->rank ==1) && ((x->shape)[0] == 1) )

/* sws get value of a system variable */
extern void
aplc_sysvar(enum sysvars fun, struct trs_struct * res)
{
  int i;
  union mp_struct mptemp;

  switch (fun) {
  default:
    aplc_error("[sysvar] unimplemented system variable error");
    break;

  case SYS_IO:
    sys_io_value[0] = aplc_ixorg;
    proint(res, sys_io_value);
    break;

  case SYS_PP:
    sys_pp_value[0] = _intwidth;
    proint(res, sys_pp_value);
    break;

  case SYS_RL:
#if USEMOTHER
    /* Mother */
    sys_rl_value[0] = (int) aplc_seed;
    proint(res, sys_rl_value);
#else
    /* standard rand */
    sys_rl_value[0] = rand();
    proint(res, sys_rl_value);
#endif
    break;

  case SYS_OMAP:
    /* setup a result trs in case non-top */
    res->type = APLC_INT;
    res->rank = 1;
    res->shape = sys_omap_shape;
    /* *res->shape = 2;*/
    res->value.ip = sys_omap_value;
    res->value.ip[0] = _omapv[0];
    res->value.ip[1] = _omapv[1];
    break;

  case SYS_ARG:
    {
      int j,k, rowsize;
      char *s;

      if (!arg_avail) {
	/* put argv in a local trs */
	arg.type = APLC_CHAR;
	arg.rank = 2;
	aplc_vectalloc(&mptemp, 2, APLC_INT);
	arg.shape = mptemp.ip;
	/* get size */
	rowsize = 0;
	for (i=0; i<aplcargc; i++) {
	  rowsize = max(rowsize, strlen(aplcargv[i]));
	}
	(arg.shape)[0] = aplcargc;
	(arg.shape)[1] = rowsize;
	aplc_vectalloc(&arg.value, (aplcargc)*rowsize, APLC_CHAR);
	k = 0;
	for (i=0; i< aplcargc; i++) {
	  s = aplcargv[i];
	  for (j=0; j<rowsize; j++) {
	    if (*s != '\0')
	      arg.value.cp[k] = *s++;
	    else
	      arg.value.cp[k] = ' ';
	    k++;
	  }
	}
	arg_avail = 1;
      }
      /* now use it */
      res->type = APLC_CHAR;
      res->rank = 2;
      res->shape = arg.shape;
      res->value.cp = arg.value.cp;
    }
  break;
  case SYS_TS:
    {
      /* time stamp */
#if HAVE_GETTIMEOFDAY 
      /* #if defined(FREEBSD) || defined(SUNOS5) || defined(DECALPHA) || defined(SGI) || defined(LINUX)*/
      /* sun os 4 doesn' seem to support this somehow */
      int *tme;
      /* long tmeres; */
      struct timeval tp;
      struct timezone tzp;

      gettimeofday(&tp, &tzp);
      /* tmeres = time(0);*/
      tme = (int *) localtime(&(tp.tv_sec));
      res->type = APLC_INT;
      res->rank = 1;
      res->shape = sys_ts_shape;
      /* *res->shape = 7;*/
      res->value.ip = sys_ts_value;
      /* result is the struct tm type */
      res->value.ip[0] = tme[5] + 1900;/* year */
      res->value.ip[1] = tme[4] + 1;   /* month, 1 origin */
      res->value.ip[2] = tme[3]; /* day of month, 1-31 */
      res->value.ip[3] = tme[2]; /* hour 0-23 */
      res->value.ip[4] = tme[1]; /* minute 0-59 */
      res->value.ip[5] = tme[0]; /* sec    0-60 */
      res->value.ip[6] = tp.tv_usec/1000;      /* msec */
#else /* no gettimeofday - assume localtime */
      int *tme;
      /* long tmeres; */
      unsigned long tmeres;

      tmeres = time(0);
      tme = (int *) localtime(&tmeres);
      res->type = APLC_INT;
      res->rank = 1;
      res->shape = sys_ts_shape;
      /* *res->shape = 7;*/
      res->value.ip = sys_ts_value;
      /* result is the struct tm type */
      res->value.ip[0] = tme[5] + 1900;/* year */
      res->value.ip[1] = tme[4] + 1;   /* month, 1 origin */
      res->value.ip[2] = tme[3]; /* day of month, 1-31 */
      res->value.ip[3] = tme[2]; /* hour 0-23 */
      res->value.ip[4] = tme[1]; /* minute 0-59 */
      res->value.ip[5] = tme[0]; /* sec    0-60 */
      res->value.ip[6] = 0;      /* no msec available */
#endif /* gettimeofday */
    }
  break;
  case SYS_JTS:
    {
      /* Julian time stamp */
#if HAVE_GETTIMEOFDAY 
      /* #if defined(FREEBSD) || defined(SUNOS5) || defined(SUNOS) || defined(DECALPHA) || defined(SGI) || defined(LINUX) || defined(ST)*/
      struct timezone tzp;
      struct timeval tp;
      double tnow;

      gettimeofday(&tp, &tzp);
      tnow = ((double) tp.tv_sec) + ((double)  tp.tv_usec)/US_per_SEC ;      /* sec */

      res->type = APLC_REAL;
      res->rank = 0;
      res->shape = aplc_dsval(1);
      res->value.rp = dsrval(tnow);
#else /* no gettimeofday */
      res->type = APLC_INT;
      res->rank = 0;
      res->shape = aplc_dsval(1);
      res->value.ip = 0;
#endif /* gettimeofday */
     }
  break;
  }
}

/* sws  assign value to certain system variables */
extern void
aplc_asysvar(enum sysvars fun, struct trs_struct * res,
	     struct trs_struct * right)
{
  /*int i;*/
  /*union mp_struct mptemp;*/

  if (right->type == APLC_UKTYPE)
    aplc_error("[aplc_asysvar] argument error");    

  switch (fun) {
  default:
    aplc_error("[aplc_asysvar] unimplemented system variable error");
    break;

  case SYS_IO:
    aplc_ixorg = *(right->value.ip);
    sys_io_value[0] = aplc_ixorg;
    proint(res, sys_io_value);
    break;

  case SYS_PP:
    _intwidth = *(right->value.ip);
    sys_pp_value[0] = _intwidth;
    proint(res, sys_pp_value);
    break;

  case SYS_RL:
#if USEMOTHER
    /* Mother */
    aplc_seed = ((unsigned)*(right->value.ip));
    aplc_rl_init = 1;
    sys_rl_value[0] = (int) aplc_seed;
    proint(res, sys_rl_value);
#else
    /* standard rand */
    srand((unsigned)*(right->value.ip));
    sys_rl_value[0] = rand();
    proint(res, sys_rl_value);
#endif
    break;

  case SYS_OMAP:
    /* we're changing the values */
    if ( (right->type == APLC_INT) || (right->type == APLC_BOOL) ) {
      if (ISsingleton(right)) {
	_omapv[0] = (right->value.ip)[0];
	_omapv[1] = (right->value.ip)[0];
      } else if (1 == right->rank) {
	if (2 == (right->shape)[0]) {
	  _omapv[0] = (right->value.ip)[0];
	  _omapv[1] = (right->value.ip)[1];
	} else {
	  aplc_error("[OMAP] shape error");
	}
      } else {
	aplc_error("[OMAP] rank error");
      }
      /* now reset pointers */
      if (_omapv[0] == 0)
	aplcout = stdout;
      else
	aplcout = stderr;
      if (_omapv[1] == 0)
	aplcerr = stdout;
      else
	aplcerr = stderr;
    } else {
      /* right is not APLC_INT */
      aplc_error("[OMAP] domain error");
    }
    /* setup a result trs in case non-top */
    res->type = APLC_INT;
    res->rank = 1;
    res->shape = sys_omap_shape;
    /* *res->shape = 2;*/
    res->value.ip = sys_omap_value;
    res->value.ip[0] = _omapv[0];
    res->value.ip[1] = _omapv[1];
    break;
  }
}

/* sws call system */
extern void
aplc_sys(struct trs_struct * res,
    struct trs_struct * left, struct trs_struct * right)
{
  int i;
  /*union mp_struct mptemp;*/
  char *c;

  c = malloc((unsigned)(1 + aplc_vsize(right->rank, right->shape)));
  aplc_cp2str(c, right);
  /* fprintf(aplcout,"system(%s)\n", c); */
  i = system(c);
  free(c);
#if 0
  if (0 != i) 
    aplc_error("SYS: system unavailable");
#endif
  if ((127 == i)||(-1 == i)) {
    fprintf(aplcerr, "[sys] error %d\n", i);
    aplc_syserr("[sys]: system failed");
  } 

  /* static version
      sys_sys_value[0] = i;
      proint(res, sys_sys_value);*/
      /* dynamic (freeable) version */ 
  res->type = APLC_INT;
  res->rank = 0;
  res->shape = aplc_dsval(1);
  res->value.ip = aplc_dsval(i);
}



/* delay for n sec 
   monadic; only uses right argument 
   can use:
      nanosleep
      usleep
      software loop 
   depending on the machine 
 */

extern void
aplc_dl(struct trs_struct * res, struct trs_struct * right)
{
  double delay;
  double tstart, tnow;

  switch(right->type) {
  default:
    delay = 0;
    aplc_error("[.bxdl] wrong type argument");
    break;
  case APLC_BOOL:
  case APLC_INT:
    delay = *(right->value.ip);
    break;
  case APLC_REAL:
    delay = *(right->value.rp);
    break;
  }
#if HAVE_GETTIMEOFDAY 
#if HAVE_NANOSLEEP
  /* #if defined(DECALPHA) || defined(SGI) || defined(LINUX)*/
  /* for machines that have nanosleep, timespec, timeval, timezone, gettimeofday	*/
  /* J.B.W.Webber@ukc.ac.uk  99_3_5 */
  /* sws SUNOS5 could be here, but then need to link with posix4 */
  {
    struct timezone tzp;
    struct timeval tp;
    struct timespec treq, trem;
    double tremain;
    long sec, nsec;
    
    gettimeofday(&tp, &tzp);
    tstart = ((double) tp.tv_sec) + (((double)  tp.tv_usec)/US_per_SEC)  ;      /* sec */
    /*  fprintf(aplcerr, "\n[bxdl] time: %f sec. \n", tstart); */
#ifdef LINUX
    treq.tv_sec =  (sec  = (long) floor (delay));
#else
    /* treq.tv_sec = (time_t) sec  = (long) floor (delay);*/
    treq.tv_sec = (time_t) (sec  = (long) floor (delay));
#endif
    treq.tv_nsec = nsec = (long) floor( NS_per_SEC * (delay - sec));
    /*  fprintf(aplcerr, "\n[bxdl] sleeping: %f sec. \n", delay); */
    if ( nanosleep ( &treq , &trem ) <  0 ) {
      tremain = ((double) trem.tv_sec) + ((double)  trem.tv_nsec)/NS_per_SEC  ;      /* sec */
#if DEBUGIO
      fprintf(aplcerr, "\n[bxdl] sleep cut short \n");
      fprintf(aplcerr, "[bxdl] time remaining: %f sec. \n", tremain);
#endif
    }
    gettimeofday(&tp, &tzp);
    tnow = ((double) tp.tv_sec) + ((double)  tp.tv_usec)/US_per_SEC ;      /* sec */
    /*  fprintf(aplcerr, "\n[bxdl] time: %f sec. \n", tnow); */
  }
#elif HAVE_USLEEP /* vs nannosleep */
  /*#elif defined(SUNOS5) || defined(FREEBSD) */
  /* for machines that have usleep, timeval, timezone, gettimeofday in usec */
  /* sws */
  {
    struct timezone tzp;
    struct timeval tp;

    gettimeofday(&tp, &tzp);
    tstart = ((double) tp.tv_sec) 
      + (((double)  tp.tv_usec)/US_per_SEC); /* sec */
    usleep( (u_int) (US_per_SEC*delay) );
    gettimeofday(&tp, &tzp);
    tnow = ((double) tp.tv_sec) + ((double)  tp.tv_usec)/US_per_SEC ;      /* sec */
  }
#else /* neither nannosleep or usleep */ 
  /*#elif defined (ST)*/
  /* for machines that have timeval, timezone, gettimeofday */
  /* J.B.W.Webber@ukc.ac.uk  99_3_5	*/
  {
    struct timezone tzp;
    struct timeval tp;
    int Sleep;
    double tend;

    gettimeofday(&tp, &tzp);
    tstart = ((double) tp.tv_sec) + (((double)  tp.tv_usec)/US_per_SEC)  ;      /* sec */
    tnow = tstart;
    tend = tnow + delay;
#if DEBUGIO
    fprintf(aplcerr, "\n[bxdl] time: %f sec. \n", tnow);
#endif
    Sleep = (int) floor(tend - tnow);
    if (Sleep > 0) {
#if DEBUGIO
      fprintf(aplcerr, "\n[bxdl] sleeping: %d sec. \n", Sleep);
#endif
      sleep (Sleep);
    }
    gettimeofday(&tp, &tzp);
    tnow = ((double) tp.tv_sec) + ((double)  tp.tv_usec)/US_per_SEC ;      /* sec */
    /*   fprintf(aplcerr, "\n[bxdl] time: %f sec. \n", tnow); */
    do {
      gettimeofday(&tp, &tzp);
      tnow = ((double) tp.tv_sec) + ((double)  tp.tv_usec)/US_per_SEC ;      /* sec */
    } while (tend > tnow); 
    /*  fprintf(aplcerr, "\n[bxdl] time: %f sec. \n", tnow); */
  }
#endif /* end of sleep tests */
#else  /* no gettimeofday */
  /* assume machine at least has time */
  {
    double tend;

    tstart = (double) time(0);
    tnow = tstart;
    tend = tnow + delay;
    while (tend > tnow)
      tnow = (double) time(0);
  }
#endif /* different machine options for gettimeofday */
  res->type = APLC_REAL;
  res->rank = 0;
  res->shape = aplc_dsval(1);
  res->value.rp = dsrval(tnow-tstart);
}


/* sws
   function to test field width of a double

   (width, prec) format x

   return
     1 if ok
     0 if width too small
   

   n 0  precision so far...
*/
static int
testwidth(double x, int width, int prec)
{
  int w;
  double l;

  /* first get minimum field width required */
  /* check precision */
  if (prec >= 0) {
    /* f format */

    /* first get space left of the decimal point */
    if (x > 0) {
      l = log10(x);
      w = ((l > 0) ? ceil(l) : 1);
    } else if (x < 0) {
      l = log10(-x);
      w = 1 + ((l > 0) ? ceil(l) : 1);
    } else
      w = 1;

    /* now check for decimals */
    if (prec > 0)
      w += prec + 1;
  } else {
    /* prec < 0 */
    /* e format */
    /* add space for minus mantissa */
    /* note we will have n.nnne+nn cases */
    w = (x < 0) + 5 - prec;
  }

  /* now test needed width against that supplied */
  if (width >= w)
    return (1);
  else {
    /* error */
    fprintf(aplcerr,"[DFormat] width = %d (need %d), ", width, w);
    if (prec > 0)
      fprintf(aplcerr,"number = [%1.*f]\n", prec, x);
    else if (prec == 0)
      fprintf(aplcerr,"number = [%1.0f]\n", x);
    else
      fprintf(aplcerr,"number = [%1.*e]\n", -prec - 1, x);
    aplc_error("DFormat domain error, field width too small");
    return (0);
  }
}

/* ------------------------------------------------------- */
/* dyadic format */
/* left shape cases
   - scalar: same as 0 n (after STSC)
   - vector:
       length 2
       length 2n
*/
extern void
aplc_dformat(struct trs_struct * res,
    struct trs_struct * left, struct trs_struct * right)
{
  union mp_struct mptemp;
  union mp_struct rtemp;
  int *pattern;
  int *ptemp;
  int i, j, rsize, size, coln;
  int fieldw, realwidth;
  int ltype, lrank;
  int *lshape;
  int type, rank;
  int *shape;
  int width = 0;
  int dec = 0;
  /* hope we need less than 20 */
  char pad[] = "00000000000000000000";
  int wt; 

  type = right->type;
  rank = right->rank;
  shape = right->shape;
  ltype = left->type;
  lrank = left->rank;
  lshape = left->shape;

  /* maximum width, .bxpp */
  if (_intwidth > 70)
    _intwidth = 70;

  if (type == APLC_CHAR) {
    /* just pass it on */
    res = right;
  } else {
    res->type = APLC_CHAR;
    /* setup new shape vector */
    /* check for scalar right */
    if (rank == 0) {
      res->rank = 1;
      rsize = 1;		     /* size of right */
      res->shape = aplc_dsval(1);
      coln = 1;			     /* number of columns */
    } else {
      res->rank = rank;
      aplc_vectalloc(&mptemp, rank, APLC_INT);
      res->shape = mptemp.ip;
      for (i = 0, rsize = 1; i < rank; i++) {
	res->shape[i] = shape[i];
	rsize *= shape[i];
      }
      coln = shape[rank - 1];	     /* number of columns */
    }
    /* sws  for debugging */
    /*-
      printf("\n rank %d, rsize %d, shape[0] %d, reshape[0] %d\n" ,rank,
        rsize, shape[0], res->shape[0]);
      printf("\n shape[1] %d, reshape[1] %d\n", shape[1], res->shape[1]);
      printf("\n coln %d\n", coln);
      */
    /* check length of left */
    if ((lrank != 0) && (*lshape > 2) && (*lshape != 2 * coln)) {

      fprintf(aplcerr,"lrank = %d, lshape[0] = %d, coln = %d\n",
	      lrank, *lshape, coln);
      aplc_error("[DFormat] length error");
    }
    pattern = (left->value).ip;
    switch (type) {

    default:
      aplc_error("[DFormat] domain error, unknown type");
      break;

    case APLC_BOOL:
    case APLC_INT:
      i = (res->rank) - 1;
      if (lrank == 0) {
	/* scalar */
	res->shape[i] *= _intwidth;
	width = _intwidth;
	dec = *pattern;
      } else if (lshape[0] == 2) {
	res->shape[i] *= pattern[0];
	width = pattern[0];
	dec = pattern[1];
      } else {
	ptemp = pattern;
	res->shape[i] = 0;
	for (j = 0; j < coln; j++) {
	  res->shape[i] += *ptemp;
	  ptemp += 2;
	}
      }
      size = (rsize * res->shape[i]) + 1;
      aplc_vectalloc(&mptemp, size, APLC_CHAR);
      res->value = mptemp;
      rtemp = right->value;
      if ((lrank == 0) || (lshape[0] == 2)) {
	/* only one width, dec to worry about */
	/* printf("\nwidth %d, dec %d\n", width, dec); */
	if (dec == 0) {
	  for (i = 0; i < rsize; i++) {
	    testwidth((double) *rtemp.ip, width, dec);
	    sprintf(mptemp.cp, "%*d", width, *rtemp.ip++);
	    mptemp.cp += width;
	  }
	} else if (dec > 0) {
	  fieldw = width - dec - 1;
	  testwidth((double) *rtemp.ip, width, dec);
	  if (dec > 20)
	    aplc_error("[DFormat] domain error, integer precision > 20");
	  for (i = 0; i < rsize; i++) {
	    sprintf(mptemp.cp, "%*d.%1.*s", fieldw, *rtemp.ip++,
		    dec, pad);
	    mptemp.cp += width;
	  }
	} else {
	  dec = -dec - 1;
	  for (i = 0; i < rsize; i++) {
	    testwidth((double) *rtemp.ip, width, -dec - 1);
	    sprintf(mptemp.cp, "%*.*e", width, dec,
		    (double) *rtemp.ip++);
	    mptemp.cp += width;
	  }
	}
      } else {
	/* width, dec change with each column */
	for (i = 0, j = 0; i < rsize; i++) {
	  width = pattern[j];
	  dec = pattern[j + 1];
	  testwidth((double) *rtemp.ip, width, dec);
	  if (dec > 20)
	    aplc_error("[DFormat] domain error, integer precision > 20");
	  if (dec == 0) {
	    sprintf(mptemp.cp, "%*d", width, *rtemp.ip++);
	  } else if (dec > 0) {
	    fieldw = width - dec - 1;
	    sprintf(mptemp.cp, "%*d.%1.*s", fieldw, *rtemp.ip++,
		    dec, pad);
	  } else {
	    dec = -dec - 1;
	    sprintf(mptemp.cp, "%*.*e", width, dec,
		    (double) *rtemp.ip++);
	  }
	  mptemp.cp += width;
	  j = (j + 2) % (2 * coln);
	}
      }
      break;

    case APLC_REAL:
      realwidth = _intwidth + REALWIDTHX;
      i = (res->rank) - 1;
      if (lrank == 0) {
	res->shape[i] *= _intwidth;
	width = realwidth;
	dec = *pattern;
      } else {
	if (lshape[0] == 2) {
	  res->shape[i] *= pattern[0];
	  width = pattern[0];
	  dec = pattern[1];
	} else {
	  ptemp = pattern;
	  res->shape[i] = 0;
	  for (j = 0; j < coln; j++) {
	    res->shape[i] += *ptemp;
	    ptemp += 2;
	  }
	}
      }
      size = (rsize * res->shape[i]) + 1;
      aplc_vectalloc(&mptemp, size, APLC_CHAR);
      res->value = mptemp;
      rtemp = right->value;
      if ((lrank == 0) || (lshape[0] == 2)) {
	/* only one width, dec to worry about */
	/* printf("\nwidth %d, dec %d\n", width, dec); */
	if (dec == 0) {
	  for (i = 0; i < rsize; i++) {
	    /* sws   debugging */
	    /* printf("\n[%*.0f]\n", width, (*rtemp.rp++)); */
	    if (testwidth(*rtemp.rp, width, 0)) {
	      /* sprintf(mptemp.cp, "%*.0f", width, (*rtemp.rp++));*/
	      sprintf_double(mptemp.cp, "f", width, 0, (*rtemp.rp++));
	      mptemp.cp += width;
	    }
	  }
	} else {
	  if (dec > 0) {
	    for (i = 0; i < rsize; i++) {
	      if (testwidth(*rtemp.rp, width, dec)) {
		/* sprintf(mptemp.cp, "%*.*f", width, dec, *rtemp.rp++);*/
		sprintf_double(mptemp.cp, "f", width, dec, *rtemp.rp++);
		mptemp.cp += width;
	      }
	    }
	  } else {
	    dec = -dec - 1;
	    for (i = 0; i < rsize; i++) {
	      if (testwidth(*rtemp.rp, width, -dec - 1)) {
		/* sprintf(mptemp.cp, "%*.*e", width, dec, *rtemp.rp++);*/
		sprintf_double(mptemp.cp, "e", width, dec, *rtemp.rp++);
		mptemp.cp += width;
	      }
	    }
	  }
	}
      } else {
	/* width, dec can change with each column */
	for (i = 0, j = 0; i < rsize; i++) {
	  width = pattern[j];
	  dec = pattern[j + 1];
	  testwidth(*rtemp.rp, width, dec);
	  if (dec == 0) {
	    /* sprintf(mptemp.cp, "%*.0f", width, (*rtemp.rp++));*/
	    sprintf_double(mptemp.cp, "f", width, 0, (*rtemp.rp++));
	  } else {
	    if (dec > 0) {
	      /* sprintf(mptemp.cp, "%*.*f", width, dec, *rtemp.rp++);*/
	      sprintf_double(mptemp.cp, "f", width, dec, *rtemp.rp++);
	    } else {
	      dec = -dec - 1;
	      /* sprintf(mptemp.cp, "%*.*e", width, dec, *rtemp.rp++);*/
	      sprintf_double(mptemp.cp, "e", width, dec, *rtemp.rp++);
	    }
	  }
	  mptemp.cp += width;
	  j = (j + 2) % (2 * coln);
	}
      }
      break;

    case APLC_COMPLEX:
      realwidth = _intwidth + REALWIDTHX;
      i = (res->rank) - 1;
      if (lrank == 0) {
	res->shape[i] *= _intwidth;
	width = realwidth;
	dec = *pattern;
      } else {
	if (lshape[0] == 2) {
	  res->shape[i] *= pattern[0];
	  width = pattern[0];
	  dec = pattern[1];
	} else {
	  ptemp = pattern;
	  res->shape[i] = 0;
	  for (j = 0; j < coln; j++) {
	    res->shape[i] += *ptemp;
	    ptemp += 2;
	  }
	}
      }
      size = (rsize * res->shape[i]) + 1;
      aplc_vectalloc(&mptemp, size, APLC_CHAR);
      res->value = mptemp;
      rtemp = right->value;
      if ((lrank == 0) || (lshape[0] == 2)) {
	/* only one width, dec to worry about */
	/* printf("\nwidth %d, dec %d\n", width, dec); */
	if (dec == 0) {
	  for (i = 0; i < rsize; i++) {
	    /* sws   debugging */
	    /* printf("\n[%*.0f]\n", width, (*rtemp.rp++)); */
	    /* test to make sure we have enough space */
	    wt = sprintf_complex(czt, "f", width,0, rtemp.zp, i);
	    if (wt <= width) {
	      /*sprintf_double(mptemp.cp, "f", width, 0, (*rtemp.rp++));*/
	      strcpy(mptemp.cp, czt);
	      mptemp.cp += width;
	    }
	  }
	} else {
	  /* dec != 0 */
	  if (dec > 0) {
	    for (i = 0; i < rsize; i++) {
	      wt = sprintf_complex(czt, "f", width,dec, rtemp.zp, i);
	      if (wt <= width) {
		strcpy(mptemp.cp, czt);
		/*fprintf(stderr,"[%s, %d]", czt, strlen(czt));*/
		mptemp.cp += width;
	      }
	    }
	  } else {
	    /* dec < 0, exponential format */
	    dec = -dec - 1;
	    for (i = 0; i < rsize; i++) {
	      wt = sprintf_complex(czt, "e", width,dec, rtemp.zp, i);
	      if (wt <= width) {
		strcpy(mptemp.cp, czt);
		mptemp.cp += width;
	      }
	    }
	  }
	}
      } else {
	/* width, dec can change with each column */
	for (i = 0, j = 0; i < rsize; i++) {
	  width = pattern[j];
	  dec = pattern[j + 1];
	  if (dec == 0) {
	    wt = sprintf_complex(mptemp.cp, "f", width,0, rtemp.zp, i);
	  } else {
	    if (dec > 0) {
	      wt = sprintf_complex(mptemp.cp, "f", width,dec, rtemp.zp, i);
	    } else {
	      dec = -dec - 1;
	      wt = sprintf_complex(mptemp.cp, "e", width,dec, rtemp.zp, i);
	    }
	  }
	  mptemp.cp += width;
	  j = (j + 2) % (2 * coln);
	}
      }
      break;/* end of complex case */
    case APLC_QUAT:
      realwidth = _intwidth + REALWIDTHX;
      i = (res->rank) - 1;
      if (lrank == 0) {
	res->shape[i] *= _intwidth;
	width = realwidth;
	dec = *pattern;
      } else {
	if (lshape[0] == 2) {
	  res->shape[i] *= pattern[0];
	  width = pattern[0];
	  dec = pattern[1];
	} else {
	  ptemp = pattern;
	  res->shape[i] = 0;
	  for (j = 0; j < coln; j++) {
	    res->shape[i] += *ptemp;
	    ptemp += 2;
	  }
	}
      }
      size = (rsize * res->shape[i]) + 1;
      aplc_vectalloc(&mptemp, size, APLC_CHAR);
      res->value = mptemp;
      rtemp = right->value;
      if ((lrank == 0) || (lshape[0] == 2)) {
	/* only one width, dec to worry about */
	if (dec == 0) {
	  for (i = 0; i < rsize; i++) {
	    /* sws   debugging */
	    /* printf("\n[%*.0f]\n", width, (*rtemp.rp++)); */
	    /* test to make sure we have enough space */
	    wt = sprintf_quat(czt, "f", width,0, rtemp.qp, i);
	    if (wt <= width) {
	      /*sprintf_double(mptemp.cp, "f", width, 0, (*rtemp.rp++));*/
	      strcpy(mptemp.cp, czt);
	      mptemp.cp += width;
	    }
	  }
	} else {
	  /* dec != 0 */
	  if (dec > 0) {
	    for (i = 0; i < rsize; i++) {
	      wt = sprintf_quat(czt, "f", width,dec, rtemp.qp, i);
	      if (wt <= width) {
		strcpy(mptemp.cp, czt);
		/*fprintf(stderr,"[%s, %d]", czt, strlen(czt));*/
		mptemp.cp += width;
	      }
	    }
	  } else {
	    /* dec < 0, exponential format */
	    dec = -dec - 1;
	    for (i = 0; i < rsize; i++) {
	      wt = sprintf_quat(czt, "e", width,dec, rtemp.qp, i);
	      if (wt <= width) {
		strcpy(mptemp.cp, czt);
		mptemp.cp += width;
	      }
	    }
	  }
	}
      } else {
	/* width, dec can change with each column */
	for (i = 0, j = 0; i < rsize; i++) {
	  width = pattern[j];
	  dec = pattern[j + 1];
	  if (dec == 0) {
	    wt = sprintf_quat(mptemp.cp, "f", width,0, rtemp.qp, i);
	  } else {
	    if (dec > 0) {
	      wt = sprintf_quat(mptemp.cp, "f", width,dec, rtemp.qp, i);
	    } else {
	      dec = -dec - 1;
	      wt = sprintf_quat(mptemp.cp, "e", width,dec, rtemp.qp, i);
	    }
	  }
	  mptemp.cp += width;
	  j = (j + 2) % (2 * coln);
	}
      }
      break;/* end of quat case */
    case APLC_OCT:
      realwidth = _intwidth + REALWIDTHX;
      i = (res->rank) - 1;
      if (lrank == 0) {
	res->shape[i] *= _intwidth;
	width = realwidth;
	dec = *pattern;
      } else {
	if (lshape[0] == 2) {
	  res->shape[i] *= pattern[0];
	  width = pattern[0];
	  dec = pattern[1];
	} else {
	  ptemp = pattern;
	  res->shape[i] = 0;
	  for (j = 0; j < coln; j++) {
	    res->shape[i] += *ptemp;
	    ptemp += 2;
	  }
	}
      }
      size = (rsize * res->shape[i]) + 1;
      aplc_vectalloc(&mptemp, size, APLC_CHAR);
      res->value = mptemp;
      rtemp = right->value;
      if ((lrank == 0) || (lshape[0] == 2)) {
	/* only one width, dec to worry about */
	if (dec == 0) {
	  for (i = 0; i < rsize; i++) {
	    /* sws   debugging */
	    /* test to make sure we have enough space */
	    wt = sprintf_oct(czt, "f", width,0, rtemp.op, i);
	    if (wt <= width) {
	      strcpy(mptemp.cp, czt);
	      mptemp.cp += width;
	    }
	  }
	} else {
	  /* dec != 0 */
	  if (dec > 0) {
	    for (i = 0; i < rsize; i++) {
	      wt = sprintf_oct(czt, "f", width,dec, rtemp.op, i);
	      if (wt <= width) {
		strcpy(mptemp.cp, czt);
		/*fprintf(stderr,"[%s, %d]", czt, strlen(czt));*/
		mptemp.cp += width;
	      }
	    }
	  } else {
	    /* dec < 0, exponential format */
	    dec = -dec - 1;
	    for (i = 0; i < rsize; i++) {
	      wt = sprintf_oct(czt, "e", width,dec, rtemp.op, i);
	      if (wt <= width) {
		strcpy(mptemp.cp, czt);
		mptemp.cp += width;
	      }
	    }
	  }
	}
      } else {
	/* width, dec can change with each column */
	for (i = 0, j = 0; i < rsize; i++) {
	  width = pattern[j];
	  dec = pattern[j + 1];
	  if (dec == 0) {
	    wt = sprintf_oct(mptemp.cp, "f", width,0, rtemp.op, i);
	  } else {
	    if (dec > 0) {
	      wt = sprintf_oct(mptemp.cp, "f", width,dec, rtemp.op, i);
	    } else {
	      dec = -dec - 1;
	      wt = sprintf_oct(mptemp.cp, "e", width,dec, rtemp.op, i);
	    }
	  }
	  mptemp.cp += width;
	  j = (j + 2) % (2 * coln);
	}
      }
      break;/* end of oct case */
    } /* end of switch */
  }
}

/* ------------------------------------------------------- */
/* sws 
   split out the format functions */
static void
format_int(char *text, int w, int x)
{
  if (abs(x) < 1e7)
    sprintf(text, "%*d", w, x);
  else
    sprintf(text, "%*g", w, (double) x);
  /*fprintf(stderr, "text [%s], w %d, x %d\n", text, w,x);*/
  return;
}

/* ------------------------------------------------------- */
/* sws
   format reals
   special case, some systems print -0; 
   even though -0 == 0 */
static void
format_real(char *text, int w, int p, double *x)
{
#if LAD
  if (0.0 == *x)
    sprintf(text, "%-*.2g", w, 0.0);
  else
    sprintf(text, "%-*.*g", w, p, *x);
#else
  if (0.0 == *x)
    sprintf(text, "%*.2g", w, 0.0);
  else
    sprintf(text, "%*.*g", w, p, *x);
#endif
  return;
}

/* ------------------------------------------------------- */
/* format a complex number
   input:
    total width wt      require: wt >= w[0]+w[1]+1
    width of each w[2]
    precision p
    complex array z
    index i
   output
    text
    wa[2] actual widths of each component (not counting the i) 
   */
static void
format_complex(char *text,int wa[2], 
	       int wt, int w[2], int p, double *z[2], int i)
{
  int k;

  if (1.0 == 1.0 + z[1][i]) {
    /* purely real */
    wa[0] =  sprint_ns(cq[0], w[0],p, z[0][i]);
    wa[1] = 0;
    k = wt - wa[0];
    if (k > 0)
      sprintf(text,"%*.0s%s", k,blanks,cq[0]);
    else
      sprintf(text,"%s", cq[0]);
    /*fprintf(stderr,"text [%s], wa (%d %d), wt %d, w(%d %d)\n", 
	    text,wa[0],wa[1], wt,w[0],w[1]);*/
    return;
  }
  wa[0] = sprint_ns(cq[0], w[0],p, z[0][i]);
  wa[1] = sprint_ns(cq[1], w[1],p, z[1][i]);
  k = wt - (1 + wa[0]+wa[1]);
  if (k > 0)
    sprintf(text,"%*.0s%si%s", k,blanks,cq[0],cq[1]);
  else
    sprintf(text,"%si%s", cq[0],cq[1]);
  /*fprintf(stderr,"text %s, wa (%d %d)\n", text,wa[0],wa[1]);*/
  /*fprintf(stderr,"text [%s], wa (%d %d), wt %d, w(%d %d)\n", 
	  text,wa[0],wa[1], wt,w[0],w[1]);*/
  return;
}

/* ------------------------------------------------------- */
/* format a quaternion
   input:
    total width wt      require: wt >= 1 + sum w[j]
    width of each w[4]
    precision p
   output
    text
    wa[4] actual widths
   */
static void
format_quat(char *text,int wa[4], 
	    int wt, int w[4], int p, double *z[4], int i)
{
  int j,k;
  char units[] = " ijk";
  char *tmp;

  k = wt;
  for (j=0; j<4; j++) {
    if (j == 0) {
      wa[j] = sprint_ns(cq[j], w[j],p, z[j][i]);
      k -= wa[j];
    } else {
      if ( 1.0 == 1.0 + z[j][i] )
	wa[j] = 0;
      else {
	wa[j] = sprint_ns(cq[j], w[j],p, z[j][i]);
	k -= 1+wa[j];
      }
    }
  }
  if (k > 0)
    tmp = text + sprintf(text,"%*.0s%s", k,blanks, cq[0]);
  else
    tmp = text + sprintf(text,"%s", cq[0]);
  for (j=1; j<4; j++) {
    if (wa[j] > 0) 
      tmp += sprintf(tmp,"%c%s", units[j], cq[j]);
  }
  /*fprintf(stderr,"text [%s], wa (%d %d %d %d), wt %d, w(%d %d %d %d)\n", 
	  text,wa[0],wa[1],wa[2],wa[3], 
	  wt,w[0],w[1],w[2],w[3]);*/
  return;
}

/* ------------------------------------------------------- */
/* format an octonion
   input:
    total width wt      require: wt >= 1 + sum w[j]
    width of each w[8]
    precision p
   output
    text
    wa[8] actual widths
   */

static void
format_oct(char *text,int wa[8], 
	   int wt, int w[8], int p, double *z[8], int i)
{
  int j,k;
  char units[] = " ijkUIJK";
  char *tmp;

  k = wt;
  for (j=0; j<8; j++) {
    if (j == 0) {
      wa[j] = sprint_ns(cq[j], w[j],p, z[j][i]);
      k -= wa[j];
    } else {
      if ( 1.0 == 1.0 + z[j][i] )
	wa[j] = 0;
      else {
	wa[j] = sprint_ns(cq[j], w[j],p, z[j][i]);
	k -= 1+wa[j];
      }
    }
  }
  if (k > 0)
    tmp = text + sprintf(text,"%*.0s%s", k,blanks, cq[0]);
  else
    tmp = text + sprintf(text,"%s", cq[0]);
  for (j=1; j<8; j++) {
    if (wa[j] > 0) 
      tmp += sprintf(tmp,"%c%s", units[j], cq[j]);
  }
  return;
}

/* ------------------------------------------------------- */
/* sws 
   get actual width of string */
static int
get_act_width(char *c)
{
  int i, n, w;

  /*fprintf(stderr, "c %s\n", c);*/
  n = strlen(c);
  w = 0;
  for (i=0; i<n; i++)
    if (' ' !=c[i])
      w++;
  /*fprintf(stderr, "w %d\n", w);*/
  return w;
}

/* ------------------------------------------------------- */
/* monadic format 
   - now each field is just enough to hold the largest element,
     with one space

   - still need to keep columns separate
*/
extern void
aplc_format(struct trs_struct * res, struct trs_struct * right)
{
  union mp_struct mptemp;
  union mp_struct mptemp2;
  union mp_struct mptemp3;
  int *colwidth;
  int ntype, nsize = 1;
  union mp_struct rtemp;
  int i,j,k, ic, rsize, size, coln;
  int realwidth;
  int type, rank;
  int *shape;
  int numsize;
  int wmax;
  int wi[8],wa[8];
  int *wimax;

  type = right->type;
  rank = right->rank;
  shape = right->shape;

  res->type = APLC_CHAR;
  if (type == APLC_CHAR) {
    /* just pass it on */
    res->rank = rank;
    res->shape = right->shape;
    res->size = right->size;
    res->value = right->value;
    /* indicate we shouldn't try and free */
    res->alloc_ind = APLC_ALLOC_NF;
    return;
  }

  /* maximum width, .bxpp */
  if (_intwidth > 70)
    _intwidth = 70;

  /* setup new shape vector */
  /* check for scalar right */
  if (rank == 0) {
    res->rank = 1;
    rsize = 1; /* total size */
    res->shape = aplc_dsval(1);
    coln = 1; /* number of columns */
  } else {
    res->rank = rank;
    aplc_vectalloc(&mptemp, rank, APLC_INT);
    res->shape = mptemp.ip;
    for (i = 0, rsize = 1; i < rank; i++) {
      res->shape[i] = shape[i];
      rsize = rsize * shape[i];
    }
    coln = shape[rank - 1];
  }
  /* check for zilde right */
  if (0 == rsize) {
    /* nothing to do; just pass along char zilde */
    aplc_czilde(res);
    return;
  }
  /* space for column width vector  */
  aplc_vectalloc(&mptemp2, coln, APLC_INT);
  colwidth = mptemp2.ip;
  for (i=0; i<coln; i++)
    colwidth[i] = 0;
  /* space for component width array, for complex types */
  ntype = get_typen(type);
  if (ntype >1) {
    nsize = coln*ntype;
    aplc_vectalloc(&mptemp3, nsize, APLC_INT);
    wimax = mptemp3.ip;
    for (i=0; i<nsize; i++)
      wimax[i] = 0;
  }
  /* sws  for debugging */
  /*-
    printf("\n rank %d, rsize %d, shape[0] %d,
    reshape[0] %d\n" ,rank, rsize, shape[0], res->shape[0]);
    */

  switch (type) {

  default:
    fprintf(aplcerr, "[Format] type %d \n", type);
    aplc_error("Format domain error, unknown type");
    break;

  case APLC_UNDEF:
  case APLC_UKTYPE:
    /* nothing can be done */
    res->type = type;
    res->rank = 1;
    res->shape = aplc_ivzero;
    break;

  case APLC_BOOL:
  case APLC_INT:
    i = (res->rank) - 1;
    /* first get max actual width */
    rtemp = right->value;
    for (j=0,ic=0; j<rsize; j++) {
      format_int(ci, _intwidth, rtemp.ip[j]);
      /*wmax = max(wmax, get_act_width(ci));*/
      /* increment to get space */
      colwidth[ic] = max(colwidth[ic], 1+get_act_width(ci));
      /*printf("{ic %d, colwidth %d}\n",ic,colwidth[ic]);*/
      ic = (ic+1)%coln;
    }
    /* sum to get total size */
    wmax=0;
    for (ic=0; ic<coln; ic++)
      wmax += colwidth[ic];
    res->shape[i] = wmax;
    size = (rsize * wmax)/coln + 1;
    /*printf("wmax %d, size %d\n",wmax,size);*/
    aplc_vectalloc(&mptemp, size, APLC_CHAR);
    res->value = mptemp;
    for (j= 0,ic=0; j < rsize; j++) {
      /* printf("{ic %d, colwidth %d}\n",ic,colwidth[ic]);*/
      format_int(mptemp.cp, colwidth[ic], *rtemp.ip++);
      mptemp.cp += colwidth[ic];
      ic = (ic+1)%coln;
    }
    break;

  case APLC_REAL:
    realwidth = _intwidth + REALWIDTHX;
    i = (res->rank) - 1;
    /* first get max actual width */
    rtemp = right->value;
    for (j=0,ic=0; j<rsize; j++) {
      format_real(ci, realwidth, _intwidth, &rtemp.rp[j]);
      /*wmax = max(wmax, get_act_width(ci));*/
      /* increment to get space */
      colwidth[ic] = max(colwidth[ic], 1+get_act_width(ci));
      ic = (ic+1)%coln;
    }	
    wmax=0;
    for (ic=0; ic<coln; ic++)
      wmax += colwidth[ic];
    res->shape[i] = wmax;
    size = (rsize * wmax)/coln + 1;
    aplc_vectalloc(&mptemp, size, APLC_CHAR);
    res->value = mptemp;
    rtemp = right->value;
    for (j=0,ic=0; j < rsize; j++) {
      /*format_real(mptemp.cp, wmax, _intwidth, &rtemp.rp[j]);
      mptemp.cp += wmax;*/
      format_real(mptemp.cp, colwidth[ic], _intwidth, &rtemp.rp[j]);
      mptemp.cp += colwidth[ic];
      ic = (ic+1)%coln;
    }
    break;

  case APLC_COMPLEX:
    realwidth = _intwidth + REALWIDTHX;
    i = (res->rank) - 1;
    rtemp = right->value;
    /* first get max actual width */
    numsize = 2*realwidth+1;
    for (k = 0; k < 2; k++) { 
      wi[k] = realwidth;
    }
    for (j = 0,ic=0; j < rsize; j++) {
      format_complex(czt,wa, numsize,wi, _intwidth, rtemp.zp, j);
      for (k = 0; k < 2; k++) {
	/*wimax[k] = max( wimax[k], wa[k] );*/
	wimax[ic++] = max( wimax[ic], wa[k] );
      }
      ic = ic%nsize;
    }
    /* get total size, including space of each column and whole row */
    wmax = 0;
    for (ic=0,j=0; ic < coln; ic++) {
      /* real part + space */
      colwidth[ic] += 1+wimax[j];
      wmax += 1+wimax[j++];
      /* for complex parts, add space for i only if present */
      for (k=1; k<ntype; k++) {
	if (wimax[j]>0) {
	  colwidth[ic] += 1+wimax[j];
	  wmax += 1+wimax[j];
	}
	j++;
      }
    }
    /*fprintf(stderr, "wmax %d\n", wmax);*/
    res->shape[i] = wmax;
    size = (rsize*wmax)/coln + 1;
    aplc_vectalloc(&mptemp, size, APLC_CHAR);
    res->value = mptemp;
    for (j = 0,ic=0,k=0; j < rsize; j++) {
      /* format_complex(mptemp.cp,wa, wmax,wimax, _intwidth, rtemp.zp, j);
      mptemp.cp += wmax;*/
      format_complex(mptemp.cp,wa, colwidth[ic],&(wimax[k]), _intwidth, rtemp.zp, j);
      mptemp.cp += colwidth[ic];
      ic = (ic+1)%coln;
      k = (k+ntype)%nsize;
    }
    break;
  case APLC_QUAT:
    realwidth = _intwidth + REALWIDTHX;
    i = (res->rank) - 1;
    rtemp = right->value;
    /* first get max actual width */
    numsize = 4*realwidth;
    for (k = 0; k < 4; k++) { 
      wi[k] = realwidth;
    }
    for (j = 0,ic=0; j < rsize; j++) {
      format_quat(czt,wa, numsize,wi, _intwidth, rtemp.qp, j);
      for (k = 0; k < 4; k++) {
	/*wimax[k] = max( wimax[k], wa[k] );*/
	wimax[ic++] = max( wimax[ic], wa[k] );
      }
      ic = ic%nsize;
    }
    /* get total size, including space of each column and whole row */
    wmax = 0;
    for (ic=0,j=0; ic < coln; ic++) {
      /* real part + space */
      colwidth[ic] += 1+wimax[j];
      wmax += 1+wimax[j++];
      /* for complex parts, add space for ijk only if present */
      for (k=1; k<ntype; k++) {
	if (wimax[j]>0) {
	  colwidth[ic] += 1+wimax[j];
	  wmax += 1+wimax[j];
	}
	j++;
      }
    }
    res->shape[i] = wmax;
    size = (rsize*wmax)/coln + 1;
    aplc_vectalloc(&mptemp, size, APLC_CHAR);
    res->value = mptemp;
    for (j = 0,ic=0,k=0; j < rsize; j++) {
      /*format_quat(mptemp.cp,wa, wmax,wimax, _intwidth, rtemp.qp, j);
      mptemp.cp += wmax;*/
      format_quat(mptemp.cp,wa, colwidth[ic],&(wimax[k]), _intwidth, rtemp.qp, j);
      mptemp.cp += colwidth[ic];
      ic = (ic+1)%coln;
      k = (k+ntype)%nsize;
    }
    break;
  case APLC_OCT:
    realwidth = _intwidth + REALWIDTHX;
    i = (res->rank) - 1;
    rtemp = right->value;
    /* first get max actual width */
    numsize = 8*realwidth;
    for (k = 0; k < 8; k++) { 
      wi[k] = realwidth;
    }
    for (j=0,ic=0; j < rsize; j++) {
      format_oct(czt,wa, numsize,wi, _intwidth, rtemp.op, j);
      for (k = 0; k < 8; k++) 
	wimax[ic++] = max( wimax[ic], wa[k] );
      ic = ic%nsize;
    }
    /* get total size, including space of each column and whole row */
    wmax = 0;
    for (ic=0,j=0; ic < coln; ic++) {
      /* real part + space */
      colwidth[ic] += 1+wimax[j];
      wmax += 1+wimax[j++];
      /* for complex parts, add space for ijkUIJK only if present */
      for (k=1; k<ntype; k++) {
	if (wimax[j]>0) {
	  colwidth[ic] += 1+wimax[j];
	  wmax += 1+wimax[j];
	}
	j++;
      }
    }
    res->shape[i] = wmax;
    size = (rsize*wmax)/coln + 1;
    aplc_vectalloc(&mptemp, size, APLC_CHAR);
    res->value = mptemp;
    for (j=0,ic=0,k=0; j < rsize; j++) {
      format_oct(mptemp.cp,wa, colwidth[ic],&(wimax[k]), _intwidth, rtemp.op, j);
      mptemp.cp += colwidth[ic];
      ic = (ic+1)%coln;
      k = (k+ntype)%nsize;
    }
    break;
  }
  res->size = aplc_vsize(res->rank, res->shape);
  free(mptemp2.ip);/* free the col widths */ 
  if (ntype >1)
    free(mptemp3.ip);
  return;
}

/* ------------------------------------------------------- */
/*
   function to generate numeric zilde (.io 0) in a result
   sws
*/
extern void
aplc_zilde(struct trs_struct * res)
{
  /* union mp_struct mptemp;*/

  res->type = APLC_INT;
  res->rank = 1;
  /* aplc_vectalloc(&mptemp, 1, APLC_INT);
     res->shape = mptemp.ip;
     res->shape[0] = 0;*/
  res->shape = aplc_ivzero;
  res->size = 0;
}

/* ------------------------------------------------------- */
/*
   function to generate character zilde ('') in a result
   sws
*/
extern void
aplc_czilde(struct trs_struct * res)
{
  /* union mp_struct mptemp;*/

  res->type = APLC_CHAR;
  res->rank = 1;
  /*  aplc_vectalloc(&mptemp, 1, APLC_INT);
      res->shape = mptemp.ip;
      res->shape[0] = 0;*/
  res->shape = aplc_ivzero;
  res->size = 0;
}

/* ------------------------------------------------------- */
#if 0
/* old monadic definition */
/* pipe */
extern void
aplc_pipe(struct trs_struct * res, struct trs_struct * right)
{
  char *c, *cd;
  char tmp_file[] = "apl_tmp";
  char clean[] = "rm ";
  int i;
  struct trs_struct tmp_trs;

  c = malloc((unsigned)(1 + aplc_vsize(right->rank, right->shape)));
  aplc_cp2str(c, right);
  cd = strcat(c," > ");
  cd = strcat(cd,tmp_file);
  fprintf(aplcout,"[pipe] system('%s')\n", cd); 
  i = system(cd);
  if (0 != i) 
    aplc_error("pipe: system unavailable");
  /* now read */
  aplc_str2trs(&tmp_trs, tmp_file);
  aplc_fread(res, &tmp_trs);
  /* now delete tmp file */
  cd = strcat(clean,tmp_file);
  fprintf(aplcout,"[pipe] system('%s')\n", cd); 
  i = system(cd);
  if (0 != i) 
    aplc_error("pipe: system unavailable");
}
#endif


/* ------------------------------------------------------- */
/* pipe

   Pipe data through unix command, and back in again.
   Also just pipes in, or pipes out.  jbww-UKC-11/82 
   created for Apl/11, updated for apl2c	      

   o left arg is command 
   o right is (char) data input
  
   o returns char data. J.B.W.Webber@ukc.ac.uk 99_31_02 
*/

/* for debugging output */
#define DPIPE 0

#if DPIPE
#include <errno.h>
#endif

extern void
aplc_pipe(struct trs_struct * res, struct trs_struct * left,
          struct trs_struct * right)
{
  char *cmd;
  int i;
  /* shouldn't vsize return an :  unsigned int or long  ?  */ 
  int rsize;
  int pipeout[2], pipeback[2];
  /* these are in different processes, so 2 are not needed */
  int   fkpidw, fkpidc; 
  char  *block;
  unsigned int size;
  long SizeOfInt;
/*
  int i, j;
  int size, size2;
  long size2;
  unsigned int count, size, buffers;
  char  *block, *block2;
  struct stat stbuf;
 */

  SizeOfInt = (long) sizeof (int);

  /* check right (data) argument */
  /*  this is handled in trs.c, leaf.c ... but... */
  if (right->type != APLC_CHAR)
    aplc_error("pipe: data: character argument please ");
  if (right->rank == 0)
    rsize = 1;
  else
    rsize = aplc_vsize(right->rank, right->shape);

  /* check left (command)  argument */
  /*  this is handled in trs.c, leaf.c ... but... */
  if (left->type != APLC_CHAR)
    aplc_error("pipe: command: character argument please ");
  /*
  if (left->rank == 0)
    lsize = 1;
  else {
    lsize = aplc_vsize(left->rank, left->shape);
  } */
  /* put left in cmd */
  cmd = malloc((unsigned)(1 + aplc_vsize(left->rank, left->shape)));
  aplc_cp2str(cmd, left);

  /* create a pipe for communication */ 
  if( pipe(pipeout) < 0) {
    pipeout[0] = pipeout[1] = -1;	
    aplc_error("pipe: pipeout create failed");
  }
  if( pipe(pipeback) < 0) {
    pipeback[0] = pipeback[1] = -1;	
    aplc_error("pipe: pipeback create failed");
  }
  /*  set-up command execution process 
      - try till we succeed */
#if DPIPE
  fprintf(aplcerr,"[pipe] parent; pid %d\n", getpid()); 
  /* fprintf(aplcerr,"[pipe] EAGAIN %d, ENOMEM %d\n", EAGAIN, ENOMEM); */
#endif
  /* could wait here or at the end */
  /* wait(NULL);*/

  while( ( fkpidc =  fork() ) < 0) {
    /* NOT vfork - it closes parent files */
#if DPIPE
    fprintf(aplcout,"[pipe] command forking, status %d, errno %d\n", 
	    fkpidc, errno); 
    /* sleep(1); */
#endif
    ;
  } 
#if DPIPE
  fprintf(aplcerr,"[pipe] parent or 1st child; pid %d\n", getpid()); 
#endif
  if( fkpidc == 0) {
    /* this is the 1st child */
#if DPIPE
    fprintf(aplcerr,"[pipe] 1st child; parent pid %d\n", getppid()); 
    /* fprintf(aplcout,"[pipe] (write) setup \n"); */ 
#endif
    /* spawn writing-to-pipe process	*/
    /* we nest them so wait knows when cmd finishes */
    while( ( fkpidw =  fork() ) < 0)	{
#if DPIPE
      fprintf(aplcout,"[pipe] write forking, status %d, errno %d\n", 
	      fkpidw, errno); 
#endif
      /* sleep(1); */
      ;
    } 
    if( fkpidw == 0) {
      /* this is the 2nd child */
#if DPIPE
      fprintf(aplcerr,"[pipe] 2nd child; parent pid %d\n", getppid()); 
      /* fprintf(aplcout,"[pipe] (write) setup \n"); */ 
#endif
      /* close useless files */
      if ( (  close(pipeout[0]) < 0 )
	   ||(  close(pipeback[0])< 0 )
	   ||(  close(pipeback[1])< 0 )
	   ||(  close(0)< 0 )
	   ||(  close(1)< 0 ) ) 
	aplc_error("pipe: pipe (write) close failed");
      block = right->value.cp;
      size = rsize;
      while( size > 0 ) {
	i = (size > BUFSIZ) ? BUFSIZ : size;
	write(pipeout[1], block, (unsigned) i);
	block += i;
	size  -= i;
      }
      if ( close(pipeout[1]) < 0 )	    {
	aplc_error("pipe: pipe (write end) close failed");
      } 
#if DPIPE
      fprintf(aplcerr,"[pipe] 2nd child exiting\n");
#endif
      exit(0);/* 2nd child exits */
    } else {
      /* the 1st child */
#if DPIPE
      fprintf(aplcerr,"[pipe] 1st child; 2nd child pid %d\n", fkpidw); 
      /*fprintf(aplcerr, "[pipe:write] pid %d\n", fkpidw);*/
#endif
    }
    /* the 1st child */
    /* command process */
    /* fprintf(aplcout,"[pipe] (cmd) setup \n"); */ 
    if ( close(0) < 0 )
      aplc_error("pipe: pipe (cmd in 0) close failed");
    if ( dup(pipeout[0]) < 0 ) 
      aplc_error("pipe: pipeout dup failed");
    /* we may now read 0 and get pipeout[0] */
    if ( close(1) < 0 )
      aplc_error("pipe: pipe (cmd out 1) close failed");
    if ( dup(pipeback[1]) < 0 )
      aplc_error("pipe: pipeback dup failed");
    /* we may now write 1 and go to  pipeback[1] */
    /* close useless files */
    if ( (  close(pipeout[0]) < 0 )
	 ||(  close(pipeout[1]) < 0 )
	 ||(  close(pipeback[0])< 0 )
	 ||(  close(pipeback[1])< 0 ) ) 
      aplc_error("pipe: pipe cmd close failed");
    /* actually execute the cmd */
    i = system(cmd);
    free(cmd);
#if 0
    execl( "/bin/csh", "aplpipe: csh", "-c", p->datap,   0);
    kill(9);     /* if can't,  shut down pipe  processes  */
    error("\n ...  can't execute shell\n");
    _exit(1);
#endif
#if DPIPE
    fprintf(aplcerr,"[pipe] 1st child exiting\n");
#endif
    exit(1);/* end of 1st child */
  }  else {
    /* original process */
#if DPIPE
    fprintf(aplcerr,"[pipe] parent; 1st child pid %d\n", fkpidc);
    /* fprintf(aplcerr, "[pipe:cmd] pid %d\n", fkpidc); */
#endif
  }
  /* original process */
  /*fprintf(aplcout,"[pipe] main flow ...\n"); */
  /* close useless files */
  if ( (  close(pipeout[0]) < 0 )
       ||(  close(pipeout[1]) < 0 )
       ||(  close(pipeback[1])< 0 ) ) 
    aplc_error("pipe: pipe read close failed");
  /*  now just read it back in  */
  /* fprintf(aplcout,"[pipe] (read) \n"); */ 
  /* aplc_rdfd(res, pipeback[0], 'b'); */
  aplc_rdfd(res, pipeback[0]);
  if (( close(pipeback[0])) < 0)
    aplc_error("[pipe]: pipe read close failed");
#if DPIPE
  fprintf(aplcerr,"[pipe] parent; ending\n"); 
#endif
  /* need to wait here for child to finish before going on */
  wait(NULL);
}
/* end of pipe */ 

/* ------------------------------------------------------- */
/* spawn

 Spawn a unix command, connect to stdin, stdout, etc. of spawned
 process.  Right arg is command pipeline; left arg: controls which fds
 of command command are connected to as input or output; sets
 blocking/non-blocking i/o.  Two modes: Character vector or array; for
 each fd : {NN}{i|o}{b|n} interpreted as {fd of
 command},{input|output},{blocking|non-blocking}.

	Fds .is '00in02on' .bxspawn Cmd  : connects to stdin, stderr of Cmd.	
	Fds .is N .bxspawn Cmd  : for N = 3, connects to stdin, stdout, stderr.	

 Integer N : get fds 0..N-1 :	00ib						
				01ob						
				02ob						
				03ib, with i,o then alternating (to NN=10)	

 returns integer pipe file descriptors for the current process.
 created from pipe : J.B.W.Webber@ukc.ac.uk 99_3_10,13

 note monadic code (#if 0) worked, but was not flexible enough		
 if you are trying to read this code, look at monadic code first
 */

/* for debugging; 0,1,2 */
#define SPAWNDB 0

/* dyadic code */
extern void
aplc_spawn(struct trs_struct * res, struct trs_struct * left, 
	   struct trs_struct *right) 
{
  char *cmd;
  int i;
  int rsize;
  /* shouldn't vsize return an :  unsigned int or long  ?  */ 
  int   fkpidc = 0; 
  int SelVsize, Npipe, PipeN, Flags;
  int Nfd = 0;
  char * SelCvec; 
  char  Cnum[3];
  int Pipes[2 * MAXPIPES];	/* these are the fds returned by pipe(), we only use half */ 
  int Fd[MAXPIPES];   		/* these are the fds as seen by the spawned program */ 

  /* default file descriptor selection control vector; 11 defined, could have more : */ 
  SelCvec = "00ib01ob02ob03ib04ob05ib06ob07ib08ob09ib10ob";

  /* check right (command) argument */
  /*  this is handled in trs.c, leaf.c
      if (right->type != APLC_CHAR)
      aplc_error("[spawn]: command: character argument please ");
 */
  if (right->rank == 0)
    rsize = 1;
  else {
    rsize = aplc_vsize(right->rank, right->shape);
  }
  /* check left (selection) argument */
  switch (left->type) {
  default:
    aplc_error("[spawn]: bad selection type");
    break;
  case APLC_BOOL :
  case APLC_INT :
    if (left->rank != 0) {
      if (! ((left->rank == 1) && (left->shape[0] == 1))  )
	aplc_error("[spawn]: bad selection length");
    }
    else {
      if ( (Nfd = * left->value.ip) > (MAXPIPES) )
	aplc_error("[spawn]: selection: fewer, or use character mode please ");
      /* SelCvec[4*Nfd] = '\0'; */
    }
    break;
  case APLC_CHAR : 
    SelVsize = aplc_vsize(left->rank, left->shape);
    Nfd = SelVsize / 4;
    if ( Nfd > (MAXPIPES) )
      aplc_error("[spawn]: selection: fewer pipes please (or re-compile for more) ");
    if (SelVsize != 4 * Nfd)
      aplc_error("[spawn]: selection: wrong nomber of characters");
    SelCvec = left->value.cp; 
    SelCvec = malloc((unsigned)(1 + SelVsize ));
    aplc_cp2str(SelCvec, left);
    break;
  }
#if SPAWNDB > 1
  fprintf(aplcerr, "[spawn] Nfd: %d\n", Nfd);
  fprintf(aplcerr, "[spawn] SelCvec: %s\n", SelCvec);
#endif

  /*  create pipes  */
  Npipe = 0;
  while ( Npipe < Nfd ) {
    if( pipe(& Pipes[2 * Npipe]) < 0) {
      /* we get 2 file descriptors at each call, can only use 1 */ 
      Pipes[2 * Npipe] = Pipes[1 + (2 * Npipe)] = -1;	
      aplc_error("[spawn]: pipe create failed");
    }
#if SPAWNDB > 1
    fprintf(aplcerr, "[spawn:pipe] opening fds: %d %d \n", 
	    Pipes[2 * Npipe], Pipes[1 + (2 * Npipe)] );
#endif
    Npipe++;
  }

  /*  set-up command execution process	*/
  /* fork - create child process */ 
  while( ( fkpidc =  fork() ) < 0) {
    /* NOT vfork - it closes parent files */
#if SPAWNDB > 1
    fprintf(aplcout,"[spawn] command forking \n"); 
#endif
    /* sleep(1); */
  } 
  if( fkpidc == 0) {
    /* command process */
#if SPAWNDB >0
    fprintf(aplcout,"[spawn] (cmd) setup\n");
#endif

    /* dup file descriptors, close useless files */
    Npipe = 0;
    while ( Npipe < Nfd ) {
      /* the fd number, as a string */
      Cnum[0] = SelCvec[4 * Npipe];
      Cnum[1] = SelCvec[1 + (4 * Npipe)];
      Cnum[2] = '\0'; 
      PipeN = atoi(Cnum);
#if SPAWNDB > 1
      fprintf(aplcerr, "[spawn:cmd] for fds: %s \n", Cnum );
      fprintf(aplcerr, "[spawn:cmd] for fds: %d \n", PipeN );
#endif
      if ( SelCvec[2 + (4 * Npipe)] == 'i' ) {
	/* we wish to make this input for the spawned process */
	/* dup pipe file descriptor */
#if SPAWNDB > 1
	fprintf(aplcerr, "[spawn:cmd] making fd %d a duplicate of fd %d for input to cmd \n", PipeN, Pipes[2 * Npipe] );
#endif
	close(PipeN); /* we ignore errors, as some may well be closed already */
	if ( (Fd[Npipe]  = fcntl(Pipes[2 * Npipe], F_DUPFD, PipeN) )  < 0)
	  aplc_syserr("[spawn]: dup (i) failed");
	/* close useless file */
	if ( close(Pipes[1 + (2 * Npipe)]) < 0 )
	  fprintf(aplcerr, "[spawn] close pipe (s:i) failed \n");
      } else {
	/* we wish to make this output for the spawned process */
	/* dup pipe file descriptor */
#if SPAWNDB > 1
	fprintf(aplcerr, "[spawn:cmd] making fd %d a duplicate of fd %d for output from cmd \n", PipeN, Pipes[1 + (2 * Npipe)]);
#endif
	close(PipeN); /* we ignore errors, as some may well be closed already */
	if ( (Fd[Npipe]  = fcntl(Pipes[1 + (2 * Npipe)], F_DUPFD, PipeN) )  < 0)
	  aplc_syserr("[spawn]: dup (o) failed");
	/* close useless file */
	if ( close(Pipes[2 * Npipe]) < 0 )
	  fprintf(aplcerr, "[spawn] close pipe (s:o) failed \n");
      }
      Npipe++;
    }

    cmd = malloc((unsigned)(1 + aplc_vsize(right->rank, right->shape)));
    aplc_cp2str(cmd, right);
    i = system(cmd);
    free(cmd);
    exit(1);
  }  else {
    /* caller process */
#if SPAWNDB >0
    fprintf(aplcerr, "[spawn:cmd] pid %d\n", fkpidc);
#endif
  }
#if SPAWNDB >0
  fprintf(aplcout,"[spawn] main flow ...\n");
#endif
  /* this works fine for 1 in, 1 out, but we may need more */

  /* set blocking/non-blocking */
  /* close useless files */
  /* return wanted fds */
  aplc_vectalloc(&res->value, Nfd, APLC_INT);
  Npipe = 0;
  while ( Npipe < Nfd ) {
    if ( SelCvec[2 + (4 * Npipe)] == 'i' ) {
      /* we wish to make this input for the spawned process */
      if ( SelCvec[3 + (4 * Npipe)] == 'n' ) {
	/* set non-blocking */
#if SPAWNDB > 1
	fprintf(aplcerr, "[spawn:read] making fd: %d non-blocking \n", Pipes[1 + (2 * Npipe)] );  
#endif
	if (( Flags = fcntl(Pipes[1 + (2 * Npipe)], F_GETFL,0)) < 0)
	  aplc_error("[spawn:read]: fcntl get failed");
	if (( fcntl(Pipes[1 + (2 * Npipe)],F_SETFL, (long) Flags | O_NDELAY)) < 0)
	  aplc_error("[spawn:read]: fcntl set failed");
      } else {
#if SPAWNDB > 1
	fprintf(aplcerr, "[spawn:read] making fd: %d blocking \n", Pipes[1 + (2 * Npipe)] );
#endif
	;
      }
      /* close useless file */
#if SPAWNDB > 1
      fprintf(aplcerr, "[spawn:read] closing fd: %d \n", 
	      Pipes[2 * Npipe] );  
#endif
      if ( close(Pipes[2 * Npipe]) < 0 )
	fprintf(aplcerr, "[spawn] close pipe (c:o) failed \n");
      /* return wanted fd */
      res->value.ip[Npipe] = Pipes[1 + (2 * Npipe)];
    } else {
      /* we wish to make this output for the spawned process */
      if ( SelCvec[3 + (4 * Npipe)] == 'n' ) {
	/* set non-blocking */
#if SPAWNDB > 1
	fprintf(aplcerr, "[spawn:read] making fd: %d non-blocking \n", Pipes[2 * Npipe] );  
#endif
	if (( Flags = fcntl(Pipes[2 * Npipe], F_GETFL,0)) < 0)
	  aplc_error("[spawn:read]: fcntl get failed");
	if (( fcntl(Pipes[2 * Npipe],F_SETFL, (long) Flags | O_NDELAY)) < 0)
	  aplc_error("[spawn:read]: fcntl set failed");
      } else {
#if SPAWNDB > 1
	fprintf(aplcerr, "[spawn:read] making fd: %d blocking \n", 
		Pipes[2 * Npipe] );
#endif
	;
      }
      /* close useless file */
#if SPAWNDB > 1
      fprintf(aplcerr, "[spawn:read] closing fd: %d \n", 
	      Pipes[1 + (2 * Npipe)] );
#endif
      if ( close(Pipes[1 + (2 * Npipe)]) < 0 )
	fprintf(aplcerr, "[spawn] close pipe (c:i) failed \n");
      /* return wanted fd */
      res->value.ip[Npipe] = Pipes[2 * Npipe];
    }
    Npipe++;
  }

  res->type = APLC_INT;
  if (Npipe == 1) {
    res->rank = 0;
    res->shape = aplc_ivone;
  }  else {
    res->rank = 1;
    res->shape =  aplc_dsval(Nfd);
  }
  return;
}

/* ------------------------------------------------------- */
/* spawn monadic code

   return 2 fd's:
   - res[1]: write to  cmd[stdin]  : pipeout[1] 
   - res[2]: read from cmd[stdout] : pipeback[0] 

 */
extern void
aplc_spawn_mon(struct trs_struct * res, struct trs_struct *right) 
{
  char *cmd;
  int i;
  int rsize;
  int   fkpidc = 0; 
  int pipeout[2], pipeback[2];

  /* check of right (command) argument for char 
     is handled in trs.c, leaf.c */
  if (right->rank == 0)
    rsize = 1;
  else
    rsize = aplc_vsize(right->rank, right->shape);

  /*  create pipes  */
  if( pipe(pipeout) < 0) {
    pipeout[0] = pipeout[1] = -1;	
    aplc_error("spawnm: pipeout create failed");
  }
  if( pipe(pipeback) < 0) {
    pipeback[0] = pipeback[1] = -1;	
    aplc_error("spawn: pipeback create failed");
  }

  /*  set-up command execution process	*/
  /* now fork */
  while( ( fkpidc =  fork() ) < 0) {
    /* NOT vfork - it closes parent files */
#if SPAWNDB > 1
    fprintf(aplcout,"[spawnm] command forking \n"); 
#endif
    /* sleep(1); */
  } 
  if( fkpidc == 0) {
    /* command (sub) process */
#if SPAWNDB >0
    fprintf(aplcout,"[spawnm] (cmd) setup\n");
#endif

    /* dup file descriptore */
    if ( close(0) < 0 )
      aplc_error("spawnm: pipe (cmd in 0) close failed");
    if ( dup(pipeout[0]) < 0 ) 
      aplc_error("spawnm: pipeout dup failed");
    /* we may now read 0 and get pipeout[0] */
    if ( close(1) < 0 )
      aplc_error("spawnm: pipe (cmd out 1) close failed");
    if ( dup(pipeback[1]) < 0 )
      aplc_error("spawnm: pipeback dup failed");
    /* we may now write 1 and go to  pipeback[1] */
    /* close useless files */
    if ( (  close(pipeout[0]) < 0 )
	 ||(  close(pipeout[1]) < 0 )
	 ||(  close(pipeback[0])< 0 )
	 ||(  close(pipeback[1])< 0 ) ) 
      aplc_error("spawnm: pipe cmd close failed");
#if SPAWNDB >0
    fprintf(aplcerr, "[spawnm:cmd] executing %s\n", cmd);
#endif
    cmd = malloc((unsigned)(1 + aplc_vsize(right->rank, right->shape)));
    aplc_cp2str(cmd, right);
    i = system(cmd);
    free(cmd);
    exit(1);
  }  else {
    /* caller process */
#if SPAWNDB >0
    fprintf(aplcerr, "[spawnm:cmd] pid %d\n", fkpidc);
#endif
  }
#if SPAWNDB >0
  fprintf(aplcout,"[spawnm] main flow ...\n");
#endif
  /* close useless files */
  if ( (  close(pipeout[0]) < 0 ) /* note we now keep pipeout[1] for writing */
       ||(  close(pipeback[1])< 0 ) ) 
    aplc_error("[spawnm]: pipe read close failed");
  /* set blocking/non-blocking 
     can be done with .bxfcntl */

  /* now just return pipe file descriptors :	*/
  /* write to  cmd[stdin]  : pipeout[1]  : res[1]	*/
  /* read from cmd[stdout] : pipeback[0] : res[2]	*/
  res->type = APLC_INT;
  res->rank = 1;
  res->shape =  aplc_dsval(2);
  aplc_vectalloc(&res->value, 2, APLC_INT);
  res->value.ip[0] = pipeout[1];
  res->value.ip[1] = pipeback[0];
  return;
}


/* ------------------------------------------------------- */
#if 0

/* define this to 
   1 monadic
   2 dyadic */
#define SPAWND 2

/* old version with both dyadic and monadic code */
extern void
aplc_spawn(struct trs_struct * res, struct trs_struct * left, 
	   struct trs_struct *right) 
{
  char *cmd;
  int i;
  int rsize;
  /* shouldn't vsize return an :  unsigned int or long  ?  */ 
  int   fkpidc = 0; 
  /* for monadic version */
  /*  int pipeout[2], pipeback[2]; */
  /* extra for dyadic version */
  int SelVsize, Nfd, Npipe, PipeN, Flags;
  char * SelCvec; 
  char  Cnum[3];
  int Pipes[2 * MAXPIPES];	/* these are the fds returned by pipe(), we only use half */ 
  int Fd[MAXPIPES];   		/* these are the fds as seen by the spawned program */ 


  /* default file descriptor selection control vector; 11 defined, could have more : */
  SelCvec = "00ib01ob02ob03ib04ob05ib06ob07ib08ob09ib10ob";

  /* check right (command) argument */
  /*  this is handled in trs.c, leaf.c
      if (right->type != APLC_CHAR)
      aplc_error("[spawn]: command: character argument please ");
 */
  if (right->rank == 0)
    rsize = 1;
  else {
    rsize = aplc_vsize(right->rank, right->shape);
  }

#if 2==SPAWND /* dyadic */
  /* check left (selection) argument */
  switch (left->type) {
  default:
    aplc_error("[spawn]: bad selection type");
    break;
  case APLC_BOOL :
  case APLC_INT :
    if (left->rank != 0) {
      if (! ((left->rank == 1) && (left->shape[0] == 1))  )
	aplc_error("[spawn]: bad selection length");
    }
    else {
      if ( (Nfd = * left->value.ip) > (MAXPIPES) )
	aplc_error("[spawn]: selection: fewer, or use character mode please ");
      /* SelCvec[4*Nfd] = '\0'; */
    }
    break;
  case APLC_CHAR : 
    SelVsize = aplc_vsize(left->rank, left->shape);
    Nfd = SelVsize / 4;
    if ( Nfd > (MAXPIPES) )
      aplc_error("[spawn]: selection: fewer pipes please (or re-compile for more) ");
    if (SelVsize != 4 * Nfd)
      aplc_error("[spawn]: selection: wrong nomber of characters");
    SelCvec = left->value.cp; 
    SelCvec = malloc((unsigned)(1 + SelVsize ));
    aplc_cp2str(SelCvec, left);
    break;
  }

  /*V	fprintf(aplcerr, "[spawn] Nfd: %d\n", Nfd);   */
  /*V	fprintf(aplcerr, "[spawn] SelCvec: %s\n", SelCvec);   */

#endif /* dyadic */

  /* this works fine for 1 in, 1 out, but we may need more */
#if 1==SPAWND
  /*  create pipes  */
  if( pipe(pipeout) < 0) {
    pipeout[0] = pipeout[1] = -1;	
    aplc_error("spawn: pipeout create failed");
  }
  if( pipe(pipeback) < 0) {
    pipeback[0] = pipeback[1] = -1;	
    aplc_error("spawn: pipeback create failed");
  }
#endif /* monadic */

#if 2==SPAWND /* dyadic */
  /*  create pipes  */
  Npipe = 0;
  while ( Npipe < Nfd ) {
    if( pipe(& Pipes[2 * Npipe]) < 0) {
      /* we get 2 file descriptors at each call, can only use 1 */ 
      Pipes[2 * Npipe] = Pipes[1 + (2 * Npipe)] = -1;	
      aplc_error("[spawn]: pipe create failed");
    }
    /*V	fprintf(aplcerr, "[spawn:pipe] opening fds: %d %d \n", Pipes[2 * Npipe], Pipes[1 + (2 * Npipe)] );  */
    Npipe++;
  }
#endif /* dyadic */

  /*  set-up command execution process	*/
  cmd = malloc((unsigned)(1 + aplc_vsize(right->rank, right->shape)));
  aplc_cp2str(cmd, right);
#if 0
  while( ( fkpidc =  fork() ) < 0) {
    /* NOT vfork - it closes parent files */
    /* fprintf(aplcout,"[spawn] command forking \n"); 
       sleep(1); */
    ;
  } 
#endif
  if( fkpidc == 0) {
    /* command process */
#if SPAWNDB >0
    fprintf(aplcout,"[spawn] (cmd) setup\n");
#endif

    /* this works fine for 1 in, 1 out, but we may need more */
#if 1==SPAWND
    /* dup file descriptore */
    if ( close(0) < 0 )
      aplc_error("spawn: pipe (cmd in 0) close failed");
    if ( dup(pipeout[0]) < 0 ) 
      aplc_error("spawn: pipeout dup failed");
    /* we may now read 0 and get pipeout[0] */
    if ( close(1) < 0 )
      aplc_error("spawn: pipe (cmd out 1) close failed");
    if ( dup(pipeback[1]) < 0 )
      aplc_error("spawn: pipeback dup failed");
    /* we may now write 1 and go to  pipeback[1] */
    /* close useless files */
    if ( (  close(pipeout[0]) < 0 )
	 ||(  close(pipeout[1]) < 0 )
	 ||(  close(pipeback[0])< 0 )
	 ||(  close(pipeback[1])< 0 ) ) 
      aplc_error("spawn: pipe cmd close failed");
#endif /* monadic */

#if 2==SPAWND /* dyadic */
    /* dup file descriptors, close useless files */
    Npipe = 0;
    while ( Npipe < Nfd ) {
      Cnum[0] = SelCvec[4 * Npipe];
      Cnum[1] = SelCvec[1 + (4 * Npipe)];
      Cnum[2] = '\0'; 
      PipeN = atoi(Cnum);
      /*V fprintf(aplcerr, "[spawn:cmd] for fds: %s \n", Cnum );  */
      /*V fprintf(aplcerr, "[spawn:cmd] for fds: %d \n", PipeN );  */
      if ( SelCvec[2 + (4 * Npipe)] == 'i' ) {
	/* we wish to make this input for the spawned process */
	/* dup pipe file descriptor */
	/*V	fprintf(aplcerr, "[spawn:cmd] making fd %d a duplicate of fd %d for input to cmd \n", PipeN, Pipes[2 * Npipe] );  */
	(void) close(PipeN); /* we ignore errors, as some may well be closed already */
	if ( (Fd[Npipe]  = fcntl(Pipes[2 * Npipe], F_DUPFD, PipeN) )  < 0)
	  aplc_syserr("[spawn]: dup (i) failed");
	/* close useless file */
	if ( close(Pipes[1 + (2 * Npipe)]) < 0 )
	  fprintf(aplcerr, "[spawn] close pipe (s:i) failed \n");
      } else {
	/* we wish to make this output for the spawned process */
	/* dup pipe file descriptor */
	/*V	fprintf(aplcerr, "[spawn:cmd] making fd %d a duplicate of fd %d for output from cmd \n", PipeN, Pipes[1 + (2 * Npipe)]); */
	close(PipeN); /* we ignore errors, as some may well be closed already */
	if ( (Fd[Npipe]  = fcntl(Pipes[1 + (2 * Npipe)], F_DUPFD, PipeN) )  < 0)
	  aplc_syserr("[spawn]: dup (o) failed");
	/* close useless file */
	if ( close(Pipes[2 * Npipe]) < 0 )
	  fprintf(aplcerr, "[spawn] close pipe (s:o) failed \n");
      }
      Npipe++;
    }
#endif /* dyadic */

    i = system(cmd);
    free(cmd);
#if 0	/* no: we may just have killed it deliberately, die quietly */
    if (0 != i) { 
      aplc_syserr("[spawn:sys]: failed");
      /* fprintf(aplcerr, "[spawn:sys] error %d\n", i) */;
      /* aplc_error("[spawn]: system unavailable"); */
    } 
#endif
    exit(1);
  }  else {
    /* caller process */
#if SPAWNDB >0
    fprintf(aplcerr, "[spawn:cmd] pid %d\n", fkpidc);
#endif
  }
#if SPAWNDB >0
  fprintf(aplcout,"[spawn] main flow ...\n");
#endif
  /* this works fine for 1 in, 1 out, but we may need more */
#if 1==SPAWND
  /* close useless files */
  if ( (  close(pipeout[0]) < 0 )	/* note we now keep pipeout[1] for writing */
       ||(  close(pipeback[1])< 0 ) ) 
    aplc_error("[spawn]: pipe read close failed");
  /* make the useful ones non-blocking, or we just have a poor .bxpipe */
  /* set blocking/non-blocking */
  /* no, more versatile if done with .bxfcntl */
  /*
    if (( Flags = fcntl(pipeout[1], F_GETFL,0)) < 0)
    aplc_error("[spawn:write]: fcntl get failed");
    if (( fcntl(pipeout[1],F_SETFL, (long) Flags | O_NDELAY)) < 0)
    aplc_error("[spawn:write]: fcntl set failed");

    if (( Flags = fcntl(pipeback[0], F_GETFL,0)) < 0)
    aplc_error("[spawn:read]: fcntl get failed");
    if (( fcntl(pipeback[0],F_SETFL, (long) Flags | O_NDELAY))  < 0)
    aplc_error("[spawn:read]: fcntl set failed");
 */

  /* now just return pipe file descriptors :	*/
  /* write to  cmd[stdin]  : pipeout[1]  : res[1]	*/
  /* read from cmd[stdout] : pipeback[0] : res[2]	*/
#endif /* monadic */

#if 2==SPAWND /* dyadic */
  /* set blocking/non-blocking */
  /* close useless files */
  /* return wanted fds */
  aplc_vectalloc(&res->value, Nfd, APLC_INT);
  Npipe = 0;
  while ( Npipe < Nfd ) {
    if ( SelCvec[2 + (4 * Npipe)] == 'i' ) {
      /* we wish to make this input for the spawned process */
      if ( SelCvec[3 + (4 * Npipe)] == 'n' ) {
	/* set non-blocking */
	/*V fprintf(aplcerr, "[spawn:read] making fd: %d non-blocking \n", Pipes[1 + (2 * Npipe)] );  */
	if (( Flags = fcntl(Pipes[1 + (2 * Npipe)], F_GETFL,0)) < 0)
	  aplc_error("[spawn:read]: fcntl get failed");
	if (( fcntl(Pipes[1 + (2 * Npipe)],F_SETFL, (long) Flags | O_NDELAY)) < 0)
	  aplc_error("[spawn:read]: fcntl set failed");
      } else {
	/*V fprintf(aplcerr, "[spawn:read] making fd: %d blocking \n", Pipes[1 + (2 * Npipe)] );  */
	;
      }
      /* close useless file */
      /*V fprintf(aplcerr, "[spawn:read] closing fd: %d \n", Pipes[2 * Npipe] );  */
      if ( close(Pipes[2 * Npipe]) < 0 )
	fprintf(aplcerr, "[spawn] close pipe (c:o) failed \n");
      /* return wanted fd */
      res->value.ip[Npipe] = Pipes[1 + (2 * Npipe)];
    } else {
      /* we wish to make this output for the spawned process */
      if ( SelCvec[3 + (4 * Npipe)] == 'n' ) {
	/* set non-blocking */
	/*V fprintf(aplcerr, "[spawn:read] making fd: %d non-blocking \n", Pipes[2 * Npipe] );  */
	if (( Flags = fcntl(Pipes[2 * Npipe], F_GETFL,0)) < 0)
	  aplc_error("[spawn:read]: fcntl get failed");
	if (( fcntl(Pipes[2 * Npipe],F_SETFL, (long) Flags | O_NDELAY)) < 0)
	  aplc_error("[spawn:read]: fcntl set failed");
      } else {
	/*V fprintf(aplcerr, "[spawn:read] making fd: %d blocking \n", Pipes[2 * Npipe] );  */
	;
      }
      /* close useless file */
      /*V fprintf(aplcerr, "[spawn:read] closing fd: %d \n", Pipes[1 + (2 * Npipe)] );  */
      if ( close(Pipes[1 + (2 * Npipe)]) < 0 )
	fprintf(aplcerr, "[spawn] close pipe (c:i) failed \n");
      /* return wanted fd */
      res->value.ip[Npipe] = Pipes[2 * Npipe];
    }
    Npipe++;
  }
#endif /* dyadic */

  res->type = APLC_INT;
  if (Npipe == 1) {
    res->rank = 0;
    res->shape = aplc_ivone;
  }  else {
    res->rank = 1;
    res->shape =  aplc_dsval(Nfd);
  }
  return;
}
#endif /* #if 0 */

/* ------------------------------------------------------- */
/* string search function -
   find all locations of copies of right string in left
*/
extern void
aplc_strsrch(struct trs_struct * res,
    struct trs_struct * left, struct trs_struct * right)
{
  union mp_struct mptemp, ltext, rstring;
  int i, j, k, lsize, rsize;

  if (left->rank == 0)
    lsize = 1;
  else
    lsize = left->shape[0];

  if (right->rank == 0)
    rsize = 1;
  else
    rsize = right->shape[0];

  res->type = APLC_INT;
  res->rank = 1;
  res->shape = aplc_dsval(lsize);

  aplc_vectalloc(&mptemp, lsize, APLC_INT);
  res->value.ip = mptemp.ip;

  ltext = left->value;
  rstring = right->value;
  for (i = 0; i < lsize; i++) {
    if (ltext.cp[i] == rstring.cp[0]) {
      /* found a possible match */
      if (rsize == 1)
	res->value.ip[i] = 1;	     /* scalar right */
      else {
	/* look for whole right string at point i */
	j = i;
	k = 0;
	while ((j < lsize) && (k < rsize)
	    && (ltext.cp[j] == rstring.cp[k])) {
	  j++;
	  k++;
	}
	/* now see if we found it */
	if (k == rsize)
	  res->value.ip[i] = 1;
	else
	  res->value.ip[i] = 0;
      }
    } else
      res->value.ip[i] = 0;
  }
}

/* ------------------------------------------------------- */
/* type - type of argument
   for now just return a scalar (later nest/vector?)
*/
extern void
aplc_type(struct trs_struct * res, struct trs_struct * right)
{
  proint(res, &(right->type));
}


/* ------------------------------------------------------ */
/* ------------------------------------------------------ */
/* sws
   aplc_print_trs
   - print a trs structure
   - for debugging 
   */
void
aplc_print_trs(struct trs_struct * res) 
{
  int i, s;

  printf("type %d, rank %d\n", res->type, res->rank);
  printf("shape ");
  if (res->rank != 0) {
    for (i=0; i<res->rank; i++)
      printf(" %d", res->shape[i]);
    printf("\n");
  }
  else
    printf("(scalar)\n");
  printf("values {");
  s = aplc_vsize(res->rank, res->shape);
  for (i=0; i<s; i++)
    switch(res->type) {
    default:
      printf(" ?");
      break;
    case APLC_BOOL:
    case APLC_INT:
      printf(" %d", res->value.ip[i]);
      break;
    case APLC_REAL:
      printf(" %g", res->value.rp[i]);
      break;
    case APLC_CHAR:
      printf(" %c", res->value.cp[i]);
      break;
    }
  printf("}\n");
}

/* end of runio.c */
