/* nutil.h

sws 1/15/97
 
*/

#ifndef _NUTIL
#define _NUTIL

/* from nutil.c */
int maxtype(int ltype, int rtype);
int commute(enum sops op);
int is_icon(struct node * node);
int is_mergeable(struct node * node);
int is_parm(char *name);

#endif
/* end of nutil.h */
