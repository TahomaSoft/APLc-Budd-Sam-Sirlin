/*
	APL compiler
		driver for internal passes
		timothy a. budd

	recognizes the following flags
		-n 	don't print out processed parse tree
				(used only on last pass)

		-idigit	set index origin to digit
		-v      verbose output off (sws)
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/
#include <stdio.h>
#include "parse.h"

/* global variables */
int *iconsts, ic[MAXCONSTS];	       /* integer constants */
double *rconsts, rc[MAXCONSTS];	       /* real constants */
double *zconsts[2], zc[2][MAXCONSTS]; /* complex constants */
double *qconsts[4], qc[4][MAXCONSTS]; /* quaternion constants */
double *oconsts[8], oc[8][MAXCONSTS]; /* octonion constants */
char *sconsts, sc[MAXCONSTS];	       /* string constants */
struct label_struct lconsts[MAXCONSTS]; /* label constants */
int ictop, rctop, zctop, qctop, octop, sctop, lctop; /* top of arrays */
int indxorgin;			     /* index origin */
struct headnode head;		     /* header for current function */
extern char *funname;		     /* function name */


/* local function declarations */
int main(int argc, char **argv);

/* read parse tree in, process it, print it back out */
int
main(int argc, char **argv)
{
  int c;
  char name[120], asvar[120], parm1[120], parm2[120];
  struct statenode *code;
  struct symnode *syms;
  int i, output, verbose;

  /* sws...for debugging fprintf(stderr,"[pass]\n"); */
  output = 1;
  verbose = 1;
  indxorgin = DEFAULTINDEX;

  /* sws... */
  for (i = 1; i < argc; i++) {
    if (argv[i][0] == '-')
      switch (argv[i][1]) {
      case 'n':
	output = 0;
	break;
      case 'i':
	indxorgin = argv[i][2] - '0';
	break;
      case 'v':
	verbose = 0;
	break;
      }
  }

  passinit(verbose);

 /* this kludge necessary in order to   */
 /* insure conformable declarations for */
 /* constant arrays                     */
  iconsts = ic;
  rconsts = rc;

  zconsts[0] = &(zc[0][0]);
  zconsts[1] = &(zc[1][0]);
  for (i=0; i<4; i++)
    qconsts[i] = &(qc[i][0]);
  for (i=0; i<8; i++)
    oconsts[i] = &(oc[i][0]);

  sconsts = sc;

  while ((c = getcharn()) != (int) EOF) {
    /* sws... fprintf(stderr,"pass; c %d\n", c); */

    switch (c) {
    case GLSYM:
      gets_safe(name);
      glbvar(name);
      if (output) {
	/* printf("%c%s\n", GLSYM, name); */
	putcharn(GLSYM);
	printf("%s\n", name);
      }
      break;

    case MNPROG:
      /* sws... fprintf(stderr,"pass: mnprog\n"); */
      gethead(&head, name, asvar, parm1, parm2);
      funname = "main";
      if (verbose)
	fprintf(stderr, "   %s\n", funname);
      syms = getsyms();
      rdconsts();
      code = rdcode();
      /* sws prtcode(code); */
      doprog(&head, syms, code);
      if (output) {
	/* sws collect this into one function */
	writecode(MNPROG, &head, syms, code);
      }
      /* sws: added these here rather than in doprog */
      fresyms(syms);
      frecode(code);
      break;

    case PROG:
      /* sws... fprintf(stderr,"pass: prog\n"); */
      gethead(&head, name, asvar, parm1, parm2);
      funname = head.fname;
      if (verbose)
	fprintf(stderr, "   %s\n", funname);
      syms = getsyms();
      rdconsts();
      code = rdcode();
      doprog(&head, syms, code);
      if (output) {
	/* sws collect this into one function */
	writecode(PROG, &head, syms, code);
      }
      /* sws */
      fresyms(syms);
      frecode(code);
      break;

    case 10:
      /* sws ignore extra newline */
      fprintf(stderr, "internal pass: newline read (ignoring)\n");
      break;

    default:
      fprintf(stderr, "internal pass:unknown character read %d\n", c);
      exit(1);
    }
  }
  /* sws... fprintf(stderr,"[pass end]\n"); */
  exit(0);
}

/* end of pass.c */
