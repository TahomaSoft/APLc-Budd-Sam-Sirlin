
#ifndef _UTIL2
#define _UTIL2

extern void caserr(char *where, int num);
extern void cant (char *where);
extern int mergetop(struct node *node);
extern int mergebot(struct node *node);
extern int numin(struct node *node);

#endif
/* end of util2.h */
