/*
	APL Compiler

	Utility routines having to do with nodes
	tim budd
*/

/*
	The APL Compiler is Public Domain
	It may be freely redistributed as long as this notice of authorship
	is retained with the sources.

		Tim Budd
		Oregon State University
		Department of Computer Science
		Corvallis, Oregon 97331 USA

	No guarantees are given as to the suitablity of this code for any
	purposes whatsoever
*/
# include <stdio.h>
# include <string.h>
# include "parse.h"
# include "y_tab.h"
# include "gen.h"

extern struct headnode head;

/* maxtype - return the maximum type of two types */
int 
maxtype(int ltype, int rttype)
{
  /* should check that types are legal */
  if (rttype > ltype)
    return rttype;
  return ltype;
}

/* commute - see if operator commutes
   sws: remove +,*, so the expected order of operations is preserved 
   * doesn't commute for quaternions or octonions
   + may not associate numerically, so order matters
 */
int 
commute(enum sops op)
{
#if 0
  /* original */
  if (op == APLC_FLOOR || op == APLC_CEIL || 
      op == APLC_PLUS || op == APLC_TIMES ||
      op == APLC_AND || op == APLC_OR || 
      op == APLC_NAND || op == APLC_NOR)
    return(1);
#else
  if (op == APLC_FLOOR || op == APLC_CEIL || 
      op == APLC_AND || op == APLC_OR || 
      op == APLC_NAND || op == APLC_NOR)
    return(1);
#endif
  return(0);
}

/* is_icon - see if a node is an integer constant */
int 
is_icon(struct node *node)
{
    return((node->nodetype == BCON) ||
	(node->nodetype == ICON));
}

/* is_mergeable - see if a node can be merged into a single accessor */
int 
is_mergeable(struct node *node)
{
    switch(node->nodetype){
    case TRANS:
    case DTRANS:
      /* only gw cases here */
    case GWTAKE:
    case GWDROP:
    case REVERSE:
	return(1);
	break;
    default:
	return(0);
	break;
    }
}

/* is_parm - see if a name is a parameter */
int 
is_parm(char *name)
{
    if (head.asvar != NILCHAR)
	if (strcmp(head.asvar, name) == 0)
	    return(1);
    if (head.parm1 != NILCHAR)
	if (strcmp(head.parm1, name) == 0)
	    return(1);
    if (head.parm2 != NILCHAR)
	if (strcmp(head.parm2, name) == 0)
	    return(1);
    return(0);
}
