#include "aplc.h"
static struct trs_struct trs_n1, trs_n2;
/* ------------- user ------------- */
int i_user[4] = {0, 1, 1, 1};
char c_user[] = {'a','b'};
int
user(struct trs_struct *c, struct trs_struct *a, struct trs_struct *b)
{
int stmtno;
struct trs_struct trs1; 
union mp_struct mp1, mp2; 
union res_struct res0, res1, res2, res3, res4; 
int i0 = 0;/* for singleton indices */
int i1, i2, i3, i4; /* end of declarations */

trs1.type = APLC_UKTYPE;
trs1.alloc_ind = APLC_UNALLOC;
/* asvar c: type= {real}, rank= {arbitrary} */ 
c->type = APLC_UKTYPE;
c->alloc_ind = APLC_UNALLOC;

stmtno = 1;
while (stmtno)
 switch(stmtno) {
default: stmtno = 0;
   break;
case 1: stmtno = 1;
aplc_trace("user", 1);
{
(res1.c = c_user[0]);
aplc_printit(&res1, APLC_CHAR, 1);
}
case 2: stmtno = 2;
aplc_trace("user", 2);
if (a->type == APLC_UKTYPE) aplc_error("undefined value (a) used");
mp2 = a->value;
i1 = aplc_vsize(a->rank, a->shape);
for (i2 = 0; i2 < i1; i2++) {
aplc_getmp(&res2, &mp2, 
(((a->rank == 0) || (a->rank == 1) && (*a->shape ==1) )  ? 0: i2 )
, a->type);
aplc_printit(&res2, a->type, aplc_bmpnl(i2, a->rank, a->shape));
}
case 3: stmtno = 3;
aplc_trace("user", 3);
{
(res1.c = c_user[1]);
aplc_printit(&res1, APLC_CHAR, 1);
}
case 4: stmtno = 4;
aplc_trace("user", 4);
if (b->type == APLC_UKTYPE) aplc_error("undefined value (b) used");
mp2 = b->value;
i1 = aplc_vsize(b->rank, b->shape);
for (i2 = 0; i2 < i1; i2++) {
aplc_getmp(&res2, &mp2, 
(((b->rank == 0) || (b->rank == 1) && (*b->shape ==1) )  ? 0: i2 )
, b->type);
aplc_printit(&res2, b->type, aplc_bmpnl(i2, b->rank, b->shape));
}
case 5: stmtno = 5;
aplc_trace("user", 5);
/* asgn shape */
if (a->type == APLC_UKTYPE) aplc_error("undefined value (a) used");
mp2 = a->value;
/* asgn shape val */
aplc_settrs(&trs1, APLC_REAL, a->rank, a->shape);
i1 = aplc_talloc(&trs1);
mp1.rp = trs1.value.rp;
for (i2 = 0; i2 < i1; i2++) {
aplc_getmp(&res4, &mp2, 
(((a->rank == 0) || (a->rank == 1) && (*a->shape ==1) )  ? 0: i2 )
, a->type);
aplc_msopv(&res3, EXP, &res4, a->type);
 /* asntchk mkrktype */
(*mp1.rp++  = res3.r);
}
/* asgn fin */
aplc_detalloc( c);
aplc_assign( c, &trs1);
stmtno = 0;
}
return(0);
}

