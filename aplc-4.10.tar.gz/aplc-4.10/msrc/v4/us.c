#include "aplc.h"
int i_user[10] = {0, 1, 1, 1, 1, 1, 1, 1, 1, 1} 
;
char c_user[] = { 
'a','b'};
int user(c, a, b)
struct trs_struct *c, *a, *b;
{
struct trs_struct trs1; 
union mp_struct mp1, mp2; 
union res_struct res0, res1, res2, res3, res4; 
int i0 = 0;/* for singleton indices */
int i1, i2, i3, i4; 
/* declations for known scalars */
/* end of declarations */

inittrs(&trs1);
/* asvar c: type= {unknown type}, rank= {unknown} */ 
inittrs(c);

stmtno = 1;
while (stmtno)
 switch(stmtno) {
default: stmtno = 0; break;
case 1: stmtno = 1;
trace("user", 1);
{
(res1.c = c_user[0]);
printit(&res1, APLC_CHAR, 1);
}
case 2: stmtno = 2;
trace("user", 2);
if (a->type == APLC_UKTYPE) aplc_error("undefined value (a) used");
mp2 = a->value;
i1 = vsize(a->rank, a->shape);
for (i2 = 0; i2 < i1; i2++) {
getmp(&res2, &mp2, 
(((a->rank == 0) || (a->rank == 1) && (*a->shape ==1) )  ? 0: i2 )
, a->type);
printit(&res2, a->type, bmpnl(i2, a->rank, a->shape));
}
case 3: stmtno = 3;
trace("user", 3);
{
(res1.c = c_user[1]);
printit(&res1, APLC_CHAR, 1);
}
case 4: stmtno = 4;
trace("user", 4);
if (b->type == APLC_UKTYPE) aplc_error("undefined value (b) used");
mp2 = b->value;
i1 = vsize(b->rank, b->shape);
for (i2 = 0; i2 < i1; i2++) {
getmp(&res2, &mp2, 
(((b->rank == 0) || (b->rank == 1) && (*b->shape ==1) )  ? 0: i2 )
, b->type);
printit(&res2, b->type, bmpnl(i2, b->rank, b->shape));
}
case 5: stmtno = 5;
trace("user", 5);
if (a->type == APLC_UKTYPE) aplc_error("undefined value (a) used");
mp2 = a->value;
settrs(&trs1, APLC_REAL, a->rank, a->shape);
i1 = talloc(&trs1);
mp1.rp = trs1.value.rp;
for (i2 = 0; i2 < i1; i2++) {
getmp(&res4, &mp2, 
(((a->rank == 0) || (a->rank == 1) && (*a->shape ==1) )  ? 0: i2 )
, a->type);
msopv(&res3, EXP, &res4, a->type);
 /* asntchk mkrktype */
(*mp1.rp++  = res3.r);
}
detalloc( c);
assign( c, &trs1);
stmtno = 0;
}
}
